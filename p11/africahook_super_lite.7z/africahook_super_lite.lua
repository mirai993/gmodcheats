require("zxcmodule")

jit.flush()
RunConsoleCommand("stopsound")

local Angle                             = Angle 
local Material                          = Material 
local Vector                            = Vector 
local Color                             = Color
local Player                            = Player
local Entity                            = Entity

local pairs                             = pairs
local ipairs                            = ipairs 

local IsValid                           = IsValid

local tostring                          = tostring 
local tonumber                          = tonumber

local CurTime                           = CurTime
local IsFirstTimePredicted              = IsFirstTimePredicted

local Lerp                              = Lerp 
local LerpAngle                         = LerpAngle

local vgui, gui                         = vgui, gui
local string, table                     = string, table
local util, http, file                  = util, http, file
local surface, draw                     = surface, draw
local render, cam                       = render, cam
local input, hook, net                  = input, hook, net
local math, bit                         = math, bit
local ents, player                      = ents, player
local game, engine                      = game, engine
local team                              = team

local team_GetColor                     = team.GetColor 
local team_GetName                      = team.GetName

local surface_DrawLine                  = surface.DrawLine
local surface_DrawOutlinedRect          = surface.DrawOutlinedRect
local surface_DrawPoly                  = surface.DrawPoly
local surface_DrawRect                  = surface.DrawRect
local surface_DrawText                  = surface.DrawText
local surface_DrawTexturedRect          = surface.DrawTexturedRect
local surface_DrawTexturedRectRotated   = surface.DrawTexturedRectRotated
local surface_GetTextSize               = surface.GetTextSize
local surface_PlaySound                 = surface.PlaySound
local surface_SetAlphaMultiplier        = surface.SetAlphaMultiplier
local surface_SetDrawColor              = surface.SetDrawColor
local surface_SetFont                   = surface.SetFont
local surface_SetMaterial               = surface.SetMaterial
local surface_SetTextColor              = surface.SetTextColor
local surface_SetTextPos                = surface.SetTextPos
local surface_CreateFont                = surface.CreateFont

local math_abs                          = math.abs
local math_Round                        = math.Round
local math_floor                        = math.floor
local math_ceil                         = math.ceil
local math_min                          = math.min
local math_max                          = math.max
local math_Clamp                        = math.Clamp
local math_sin                          = math.sin
local math_cos                          = math.cos
local math_tan                          = math.tan
local math_rad                          = math.rad
local math_Rand                         = math.Rand
local math_deg                          = math.deg
local math_atan2                        = math.atan2
local math_random                       = math.random
local math_huge                         = math.huge
local math_sqrt                         = math.sqrt

local math_Approach                     = math.Approach
local math_NormalizeAngle               = math.NormalizeAngle
local math_DistanceSqr                  = math.DistanceSqr

local hook_Add                          = hook.Add
local hook_Remove                       = hook.Remove
local hook_GetTable                     = hook.GetTable

local bor                               = bit.bor

local vgui_Create                       = vgui.Create
local vgui_Register                     = vgui.Register

local table_Count                       = table.Count

local gui_ActivateGameUI                = gui.ActivateGameUI
local gui_HideGameUI                    = gui.HideGameUI
local gui_OpenURL                       = gui.OpenURL

local string_find                       = string.find
local string_format                     = string.format
local string_len                        = string.len
local string_sub                        = string.sub
local string_lower                      = string.lower
local StartsWith                        = string.StartWith
local string_ToColor                    = string.ToColor

local table_concat                      = table.concat
local table_insert                      = table.insert
local table_remove                      = table.remove
local table_RemoveByValue               = table.RemoveByValue
local table_sort                        = table.sort

local TraceHull                         = util.TraceHull    
local TraceLine                         = util.TraceLine

local file_Exists                       = file.Exists
local file_Delete                       = file.Delete
local file_Read                         = file.Read
local file_Write                        = file.Write

local cam_Start3D                       = cam.Start3D
local cam_End3D                         = cam.End3D
local cam_Start3D2D                     = cam.Start3D2D
local cam_End3D2D                       = cam.End3D2D
local cam_Start2D                       = cam.Start2D
local cam_End2D                         = cam.End2D
local cam_IgnoreZ                       = cam.IgnoreZ

local input_IsKeyDown                   = input.IsKeyDown
local input_IsMouseDown                 = input.IsMouseDown
local input_GetCursorPos                = input.GetCursorPos

local TickInterval                      = engine.TickInterval()
local ActiveGamemode                    = engine.ActiveGamemode()

local render_MaterialOverride           = render.MaterialOverride
local render_SetColorModulation         = render.SetColorModulation
local render_SetBlend                   = render.SetBlend
local render_SuppressEngineLighting     = render.SuppressEngineLighting
local render_DrawBeam                   = render.DrawBeam
local render_SetMaterial                = render.SetMaterial

local player_GetAll                     = player.GetAll
local ents_GetAll                       = ents.GetAll

local scrw                              = ScrW()
local scrh                              = ScrH()
local scrwc                             = scrw / 2
local scrhc                             = scrh / 2
local me                                = LocalPlayer()
local ultimate                          = {}

// custom funcs

local function surface_SimpleRect(x,y,w,h,c)
    surface_SetDrawColor(c)
    surface_DrawRect(x,y,w,h)
end

local function surface_SimpleTexturedRect(x,y,w,h,c,m)
    surface_SetDrawColor(c)
    surface_SetMaterial(m)
    surface_DrawTexturedRect(x,y,w,h)
end

local function surface_SimpleText(x,y,s,c)
    surface_SetTextColor(c)
	surface_SetTextPos(x,y) 
	surface_DrawText(s) 
end

local function SmoothMaterial(path)
    return Material( path, "noclamp smooth" )
end

// fonts

surface_CreateFont( "tbfont", {	font = "Open Sans", extended = false,size = 15,weight = 100,additive = false,} )
surface_CreateFont("veranda", { font = "Verdana", size = 12, antialias = false, outline = true } )
surface_CreateFont("veranda_scr", { font = "Verdana", size = ScreenScale( 9 ), antialias = false, outline = true } )

ultimate.Colors = 

{

}

for i = 0,255 do  // 50 shades of grey
    ultimate.Colors[i] = Color(i,i,i,255)
end

/*
    Cached shit 
*/

ultimate.cached = {}

ultimate.Materials = {}

ultimate.Materials["Gradient"] = SmoothMaterial("gui/gradient_up")
ultimate.Materials["Gradient down"] = SmoothMaterial("gui/gradient_down")
ultimate.Materials["Gradient right"] = SmoothMaterial("gui/gradient")
ultimate.Materials["Alpha grid"] = SmoothMaterial("gui/alpha_grid.png")

// CONFIG 

ultimate.cfg = { vars = {}, binds = {}, colors = {} }

ultimate.cfg.vars["Enable aimbot"] = false
ultimate.cfg.vars["Aim on key"] = false
ultimate.cfg.binds["Aim on key"] = 0
ultimate.cfg.vars["Silent aim"] = true
ultimate.cfg.vars["Rapid fire"] = false
ultimate.cfg.vars["Bullet time"] = false
ultimate.cfg.vars["Auto fire"] = false
ultimate.cfg.vars["pSilent"] = false
ultimate.cfg.vars["FOV Circle"] = false
ultimate.cfg.colors["FOV Circle Color"] = "255 255 255 255"
ultimate.cfg.vars["Snap lines"] = false

ultimate.cfg.vars["Nospread"] = false


ultimate.cfg.vars["Norecoil"] = false

ultimate.cfg.vars["Adjust tickcount"] = false
ultimate.cfg.vars["Extrapolation"] = false
ultimate.cfg.vars["last update"] = false
ultimate.cfg.vars["Disable taunts"] = false
ultimate.cfg.vars["Bone fix"] = false
ultimate.cfg.vars["Update Client Anim fix"] = false
ultimate.cfg.vars["Wait for simtime update"] = false

ultimate.cfg.vars["Target selection"] = 2
ultimate.cfg.vars["Hitbox selection"] = 1

ultimate.cfg.vars["Ignores-Friends"] = false
ultimate.cfg.vars["Ignores-Steam friends"] = false
ultimate.cfg.vars["Ignores-Teammates"] = false
ultimate.cfg.vars["Ignores-Admins"] = false
ultimate.cfg.vars["Ignores-Bots"] = false
ultimate.cfg.vars["Ignores-Frozen"] = false
ultimate.cfg.vars["Ignores-Nodraw"] = false
ultimate.cfg.vars["Ignores-Nocliping"] = false
ultimate.cfg.vars["Ignores-God time"] = true
ultimate.cfg.vars["Ignores-Head unhitable"] = false
ultimate.cfg.vars["Ignores-Driver"] = false


ultimate.cfg.vars["Aimbot smoothing"] = false
ultimate.cfg.vars["Smoothing"] = 0.05

ultimate.cfg.vars["Fov limit"] = false
ultimate.cfg.vars["Fov dynamic"] = false
ultimate.cfg.vars["Aimbot FOV"] = 30

ultimate.cfg.vars["Trigger bot"] = false
ultimate.cfg.binds["Trigger bot"] = 0



ultimate.cfg.vars["Baim low health"] = false
ultimate.cfg.vars["Baim health"] = 65


ultimate.cfg.vars["Wallz"] = false

ultimate.cfg.vars["Auto healthkit"] = false
ultimate.cfg.vars["Healthkit-Self heal"] = false
ultimate.cfg.vars["Healthkit-Heal closest"] = false

ultimate.cfg.vars["Knifebot"] = false
ultimate.cfg.vars["Knifebot mode"] = 1
ultimate.cfg.vars["Facestab"] = false

ultimate.cfg.vars["Multipoint"] = false
ultimate.cfg.vars["Multipoint scale"] = 0.8

// Backtrack

ultimate.cfg.vars["Backtrack"] = false
ultimate.cfg.vars["Always backtrack"] = false
ultimate.cfg.vars["Backtrack time"] = 100
ultimate.cfg.vars["Backtrack mode"] = 1

ultimate.cfg.vars["Backshoot"] = false

// Forwardtrack

ultimate.cfg.vars["Forwardtrack"] = false
ultimate.cfg.vars["Forwardtrack time"] = 100







ultimate.cfg.vars["Auto reload"] = false

// Resolver 

ultimate.cfg.vars["Resolver"] = false
ultimate.cfg.vars["Yaw mode"] = 1
ultimate.cfg.vars["Pitch resolver"] = false
ultimate.cfg.vars["Invert first shot"] = false
ultimate.cfg.vars["Resolver max misses"] = 2


// Tickbase 
ultimate.cfg.vars["Tickbase shift"] = false
ultimate.cfg.vars["Wait for unlag"] = false

ultimate.cfg.vars["Fakelag comp"] = 2

ultimate.cfg.vars["Skip fire tick"] = false

ultimate.cfg.vars["Passive recharge"] = false

ultimate.cfg.vars["Auto recharge"] = false
ultimate.cfg.vars["Wait for charge"] = false
ultimate.cfg.vars["Warp on peek"] = false

ultimate.cfg.vars["Maximum Shift Ticks"] = 48
ultimate.cfg.vars["Minimum Shift Ticks"] = 1
ultimate.cfg.binds["Tickbase shift"] = 0
ultimate.cfg.binds["Auto recharge"] = 0

// Anti aim angles
ultimate.cfg.vars["Anti aim"] = false

ultimate.cfg.vars["Yaw base"] = 1
ultimate.cfg.vars["Yaw"] = 1
ultimate.cfg.vars["Pitch"] = 1
ultimate.cfg.vars["Edge"] = 1

// Anim breakers 

ultimate.cfg.vars["Taunt spam"] = false
ultimate.cfg.vars["Taunt"] = 1

ultimate.cfg.vars["Handjob"] = false
ultimate.cfg.vars["Handjob mode"] = 1


ultimate.cfg.vars["Micromovement"] = false
ultimate.cfg.vars["On shot aa"] = false
ultimate.cfg.vars["Freestanding"] = false
ultimate.cfg.binds["freestand"] = 0
ultimate.cfg.vars["Anti aim chams"] = false


ultimate.cfg.vars["LBY min delta"] = 1
ultimate.cfg.vars["LBY break delta"] = 1


ultimate.cfg.vars["Free standing"] = false
ultimate.cfg.vars["Dancer"] = false
    ultimate.cfg.vars["Dance"] = 1
    ultimate.cfg.vars["Arm breaker"] = false
    ultimate.cfg.vars["Arm breaker mode"] = 1
    ultimate.cfg.vars["Fake duck"] = false
    ultimate.cfg.vars["Fake duck mode"] = 1
    ultimate.cfg.vars["Fake walk"] = false
    ultimate.cfg.vars["Crimwalk"] = false

    ultimate.cfg.vars["Air crouch"] = false
    ultimate.cfg.vars["Air crouch mode"] = 1

// fake lag
ultimate.cfg.vars["Fake lag"] = false

ultimate.cfg.vars["Fake lag options-Disable on ladder"] = false
ultimate.cfg.vars["Fake lag options-Disable in attack"] = false
ultimate.cfg.vars["Fake lag options-On peek"] = false
ultimate.cfg.vars["Fake lag options-Randomise"] = false

ultimate.cfg.vars["Lag mode"] = 1

ultimate.cfg.vars["Lag limit"] = 1
ultimate.cfg.vars["Lag randomisation"] = 1

ultimate.cfg.vars["Fake duck"] = false
ultimate.cfg.binds["Fake duck"] = 0

ultimate.cfg.vars["Allah fly"] = false

    
// Sequence manip
ultimate.cfg.vars["Sequence manip"] = false
ultimate.cfg.vars["OutSequence"] = 500
ultimate.cfg.binds["Sequence manip"] = 0
ultimate.cfg.vars["Sequence min random"] = false
ultimate.cfg.vars["Sequence min"] = 1

ultimate.cfg.binds["Animation freezer"] = 0
ultimate.cfg.vars["Animation freezer"] = false

ultimate.cfg.vars["Freeze on peek"] = false

ultimate.cfg.vars["Allah walk"] = false
ultimate.cfg.binds["allahwalk"] = 0

// Animfix 

ultimate.cfg.vars["Disable interpolation"] = false
ultimate.cfg.vars["Interpolation-Fast sequences"] = false


ultimate.cfg.vars["Disable Sequence interpolation"] = false


    // ESP
    ultimate.cfg.vars["Bounding box"] = false



// Movement
ultimate.cfg.vars["Bhop"] = false
ultimate.cfg.vars["Sprint"] = false
ultimate.cfg.vars["Safe hop"] = false
ultimate.cfg.vars["Edge jump"] = false
ultimate.cfg.vars["Air duck"] = false

ultimate.cfg.vars["Air strafer"] = false
ultimate.cfg.vars["Strafe mode"] = 1
ultimate.cfg.vars["Ground strafer"] = false
ultimate.cfg.vars["Fast stop"] = false
ultimate.cfg.vars["Z Hop"] = false
ultimate.cfg.binds["Z Hop"] = 0

ultimate.cfg.vars["Water jump"] = false

ultimate.cfg.vars["Auto peak"] = false
ultimate.cfg.binds["Auto peak"] = 0
ultimate.cfg.vars["Auto peak tp"] = false

ultimate.cfg.vars["Circle strafe"] = false
ultimate.cfg.binds["Circle strafe"] = 0
ultimate.cfg.vars["CStrafe ticks"] = 64
ultimate.cfg.vars["CStrafe angle step"] = 1
ultimate.cfg.vars["CStrafe angle max step"] = 10
ultimate.cfg.vars["CStrafe ground diff"] = 10

ultimate.cfg.vars["Cvar name"] = ""
ultimate.cfg.vars["Cvar int"] = "1"
ultimate.cfg.vars["Cvar str"] = ""
ultimate.cfg.vars["Cvar mode"] = 1
ultimate.cfg.vars["Cvar flag"] = 1

ultimate.cfg.vars["Net Convar"] = ""
ultimate.cfg.vars["Net Convar str"] = ""
ultimate.cfg.vars["Net Convar int"] = 1
ultimate.cfg.vars["Net Convar mode"] = 1

ultimate.cfg.vars["Name Convar"] = ""
ultimate.cfg.vars["Disconnect reason"] = "VAC banned from secure server"
ultimate.cfg.vars["Name stealer"] = false
ultimate.cfg.vars["Auto reconnect"] = false

ultimate.cfg.vars["Killsay"] = false
ultimate.cfg.vars["Killsay mode"] = 1

ultimate.cfg.vars["Chat spammer"] = false
ultimate.cfg.vars["Chat OOC"] = false

// FTPToPos abuse xd )))
ultimate.cfg.vars["FSpec Teleport"] = false
ultimate.cfg.binds["FSpec Teleport"] = 0

ultimate.cfg.vars["FSpec Masskill"] = false
ultimate.cfg.binds["FSpec Masskill"] = 0

ultimate.cfg.vars["FSpec ClickTP"] = false
ultimate.cfg.binds["FSpec ClickTP"] = 0

ultimate.cfg.vars["FSpec Velocity"] = false
ultimate.cfg.binds["FSpec Velocity"] = 0




// Visuals
ultimate.cfg.vars["Accurate bounds"] = false

ultimate.cfg.vars["Box esp"] = false
ultimate.cfg.vars["Box style"] = 1

ultimate.cfg.vars["Name"] = false
ultimate.cfg.vars["Name pos"] = 1

ultimate.cfg.vars["Usergroup"] = false
ultimate.cfg.vars["Usergroup pos"] = 1

ultimate.cfg.vars["Team"] = false
ultimate.cfg.vars["Team pos"] = 1

ultimate.cfg.vars["Health"] = false
ultimate.cfg.vars["Health bar"] = false
ultimate.cfg.vars["Health bar gradient"] = false
ultimate.cfg.vars["Health pos"] = 1
ultimate.cfg.colors["Health"] = "75 255 0 255"
ultimate.cfg.colors["Health bar gradient"] = "255 45 0 255"


ultimate.cfg.vars["Armor"] = false
ultimate.cfg.vars["Armor pos"] = 1

ultimate.cfg.vars["DarkRP Money"] = false
ultimate.cfg.vars["Money pos"] = 1

ultimate.cfg.vars["Weapon"] = false
ultimate.cfg.vars["Weapon pos"] = 1

ultimate.cfg.vars["Break LC"] = false
ultimate.cfg.vars["Break LC pos"] = 1

ultimate.cfg.vars["Simtime updated"] = false
ultimate.cfg.vars["Simtime pos"] = 1

ultimate.cfg.vars["Skeleton"] = false

// Chams
ultimate.cfg.vars["Visible chams"] = false
ultimate.cfg.vars["Visible chams w"] = false
ultimate.cfg.vars["Visible mat"] = 1
ultimate.cfg.colors["Visible chams"] = "0 255 255 255"

ultimate.cfg.vars["inVisible chams"] = false
ultimate.cfg.vars["inVisible chams w"] = false
ultimate.cfg.vars["inVisible mat"] = 1
ultimate.cfg.colors["inVisible chams"] = "255 255 0 255"

ultimate.cfg.vars["Supress lighting"] = false

ultimate.cfg.vars["Self chams"] = false
ultimate.cfg.vars["Self chams w"] = false
ultimate.cfg.vars["Self mat"] = 1
ultimate.cfg.colors["Self chams"] = "255 0 255 255"

ultimate.cfg.vars["Supress self lighting"] = false

ultimate.cfg.vars["Show records"] = false

ultimate.cfg.vars["Backtrack chams"] = false
ultimate.cfg.vars["Backtrack material"] = 1
ultimate.cfg.vars["Backtrack fullbright"] = false
ultimate.cfg.colors["Backtrack chams"] = "255 128 255 255"

ultimate.cfg.vars["Entity chams"] = false
ultimate.cfg.vars["Entity material"] = 1
ultimate.cfg.vars["Entity fullbright"] = false
ultimate.cfg.colors["Entity chams"] = "255 89 89 255"

ultimate.cfg.vars["Player outline"] = false
ultimate.cfg.vars["Entity outline"] = false
ultimate.cfg.colors["Player outline"] = "45 255 86 255"
ultimate.cfg.colors["Entity outline"] = "255 86 45 255"

ultimate.cfg.vars["Outline style"] = 1 

ultimate.cfg.vars["ESP Distance"] = 3500

// Entity Esp
ultimate.cfg.binds["Ent add"] = 0
ultimate.cfg.vars["Ent box"] = false
ultimate.cfg.vars["Ent class"] = false
ultimate.cfg.vars["Ent ESP Distance"] = 3500

// Hitmarker
ultimate.cfg.vars["Hitmarker"] = false
ultimate.cfg.vars["Hit particles"] = false
ultimate.cfg.vars["Hitnumbers"] = false

ultimate.cfg.vars["Hitsound"] = false
ultimate.cfg.vars["Killsound"] = false

ultimate.cfg.vars["Hitsound str"] = "phx/hmetal1.wav"
ultimate.cfg.vars["Killsound str"] = "phx/explode00.wav"

ultimate.cfg.colors["Hit particles"] = "255 128 235 255"
ultimate.cfg.colors["Hitmarker"] = "255 155 25 255"
ultimate.cfg.colors["Hitnumbers"] = "255 255 255 255"
ultimate.cfg.colors["Hitnumbers krit"] = "255 35 35 255"

// Name hide / visual misc

ultimate.cfg.vars["Hide name"] = false
ultimate.cfg.vars["Custom name"] = "Your mom"

ultimate.cfg.vars["Disable SADJ"] = false


// Visuals 
ultimate.cfg.vars["Tickbase indicator"] = false



ultimate.cfg.vars["Killsound"] = false

// World 
ultimate.cfg.vars["Custom sky"] = GetConVar("sv_skyname"):GetString()
ultimate.cfg.vars["Sky color"] = false 
ultimate.cfg.colors["Sky color"] = "145 185 245 255"
ultimate.cfg.vars["Wall color"] = false 
ultimate.cfg.colors["Wall color"] = "50 45 65 255"
ultimate.cfg.vars["Fullbright"] = false 
ultimate.cfg.binds["Fullbright"] = 0

// Effects
ultimate.cfg.vars["Bullet tracers"] = false 
ultimate.cfg.colors["Bullet tracers"] = "255 65 65 255"
ultimate.cfg.vars["Bullet tracers material"] = "sprites/tp_beam001" 
ultimate.cfg.vars["Tracers die time"] = 5 

// View 
ultimate.cfg.vars["Third person"] = false
ultimate.cfg.binds["Third person"] = 0
ultimate.cfg.vars["Third person collision"] = false
ultimate.cfg.vars["Third person smoothing"] = false
ultimate.cfg.vars["Third person distance"] = 150

ultimate.cfg.vars["Free camera"] = false
ultimate.cfg.binds["Free camera"] = 0
ultimate.cfg.vars["Free camera speed"] = 25




ultimate.cfg.vars["Viewmodel chams"] = false
ultimate.cfg.colors["Viewmodel chams"] = "75 95 128 255"
ultimate.cfg.vars["Viewmodel chams type"] = 1
ultimate.cfg.vars["Fullbright viewmodel"] = false


ultimate.cfg.vars["Viewmodel x"] = 0
ultimate.cfg.vars["Viewmodel y"] = 0
ultimate.cfg.vars["Viewmodel z"] = 0
ultimate.cfg.vars["Viewmodel r"] = 0



// Misc

ultimate.cfg.vars["Use spam"] = false
ultimate.cfg.vars["Flashlight spam"] = false
ultimate.cfg.vars["Auto GTA"] = false

ultimate.cfg.vars["Config name"] = "default"
ultimate.cfg.vars["Selected config"] = 1

ultimate.cfg.colors["Menu color"] = "0 0 0 255"

// Config save / load

if not file.Exists( "data/ultimate", "GAME" ) then 
    file.CreateDir("ultimate") 
end

if not file.Exists( "data/ultimate/default.txt", "GAME" ) then 
    file.Write( "data/ultimate/default.txt", util.TableToJSON( ultimate.cfg, false ) ) 
end

ultimate.configs = {}
function ultimate.fillConfigTable()
    local ftbl = file.Find( "ultimate/*.txt", "DATA" )
    ultimate.configs = {}

    if not ftbl[1] then return end

    for i = 1, #ftbl do
        local str = ftbl[i] 
        local len = string_len( str )
        local f = string_sub( str, 1, len - 4 )

        ultimate.configs[ #ultimate.configs + 1 ] = f
    end
end

ultimate.fillConfigTable()

function ultimate.SaveConfig()
    local tojs = util.TableToJSON( ultimate.cfg, false )

    file.Write( "ultimate/"..ultimate.cfg.vars["Config name"]..".txt", tojs )

    ultimate.fillConfigTable()
    ultimate.initTab("Settings")
end

function ultimate.LoadConfig()
    local str = ultimate.configs[ ultimate.cfg.vars["Selected config"] ]

    if not file.Exists( "data/ultimate/"..str..".txt", "GAME" ) then return end

    local read = file.Read( "ultimate/"..str..".txt", "DATA" )
    local totbl = util.JSONToTable( read )

    for k, v in pairs( totbl ) do

        for key, value in pairs( v ) do
            local tbl = ultimate.cfg

            if k == "vars" then
                tbl = ultimate.cfg.vars
            elseif k == "colors" then
                tbl = ultimate.cfg.colors
            elseif k == "binds" then
                tbl = ultimate.cfg.binds
            end
            
            tbl[ key ] = value
        end
    end
    ded.SetMinShift( ultimate.cfg.vars["Minimum Shift Ticks"] )
    ded.SetMaxShift( ultimate.cfg.vars["Maximum Shift Ticks"] )
    ded.SetInterpolation( ultimate.cfg.vars["Disable interpolation"] )
    ded.SetSequenceInterpolation( ultimate.cfg.vars["Disable Sequence interpolation"] )
    ded.EnableBoneFix( ultimate.cfg.vars["Bone fix"] )
    ded.EnableAnimFix( ultimate.cfg.vars["Update Client Anim fix"] )
end

/*
    GUI START
    ---------
    ELEMENTS:

    -------------------------
    Checkbox



    -------------------------
    Slider 



    -------------------------
    Combobox 



    -------------------------
    Multicombobox 

    БЛЯТЬ СВОЯ ВЕЩЬ КАК БЫ ДА

    -------------------------
    Text entry 

    Свой индикатор русского и инглиша 

    -------------------------

    Кружочек цвета по которому клик и типо окно нахуй всплывает бля

    Color picker ( RGB, HEX )

    Save / Copy / Paste options
    СВОЁ КОЛОР ПИКЕР ОМГ СВОЯ ПАЛЕТКА

    -----------------------------------------------

    Есп превью ( Модель которую можно будет подвигать и тд )

    Драг н Дроп елменты для есп превью 

    -----------------------------------------------

    Подсказки к элементам 

    Функция вызывающаяся ПОСЛЕ создания елемента! Позволит НЕСКОЛЬКО элементов засунуть в ОДИН!

    Добавить кнопочку которая будет создавать панельку в которую можно засунуть че хочешь

    -----------------------------------------------

    Выбор акцент цвета с градиентом 

    -----------------------------------------------

    Запоминание менюшкой позиций элементов после открытия чтоб видно было их
*/

/*
    Detours 
*/

do
    local PLAYER = FindMetaTable( "Player" )

    local Name_     = PLAYER.Name
    local Nick_     = PLAYER.Nick
    local GetName_  = PLAYER.GetName

    function PLAYER:Name()

        if ultimate.cfg.vars["Hide name"] and self == me then
            return ultimate.cfg.vars["Custom name"]
        end

        return Name_( self )
    end

    function PLAYER:Nick()

        if ultimate.cfg.vars["Hide name"] and self == me then
            return ultimate.cfg.vars["Custom name"]
        end

        return Nick_( self )
    end

    function PLAYER:GetName()

        if ultimate.cfg.vars["Hide name"] and self == me then
            return ultimate.cfg.vars["Custom name"]
        end

        return GetName_( self )
    end
end









ultimate.ui = {}

ultimate.validsnd = false 
ultimate.songlist = {

    [1] = "https://cdn.discordapp.com/attachments/1184783554916393042/1184783873926774854/song1.mp3",
    [2] = "https://cdn.discordapp.com/attachments/1184783554916393042/1184785905333055498/song2.mp3"



}

sound.PlayURL ( ultimate.songlist[math.random(1,#ultimate.songlist)], "noblock", function( s ) 
    if not IsValid( s ) then return end
    ultimate.validsnd = s

    ultimate.validsnd:EnableLooping( true )
end )

    






ultimate.activetab = "Aimbot"
ultimate.multicombo = false


ultimate.hint = false
ultimate.hintText = ""
ultimate.hintX = 0
ultimate.hintY = 0

do
    StoredCursorPos = {}

    function RememberCursorPosition()

        local x, y = input_GetCursorPos()

        if ( x == 0 && y == 0 ) then return end

        StoredCursorPos.x, StoredCursorPos.y = x, y

    end

    function RestoreCursorPosition()

        if ( !StoredCursorPos.x || !StoredCursorPos.y ) then return end
        input.SetCursorPos( StoredCursorPos.x, StoredCursorPos.y )

    end
end

do
    local PANEL = {}

    PANEL.FadeTime = 0

    function PANEL:Init()
        self:SetFocusTopLevel( true )
        self:SetSize( 800, 430 )

        self:SetPaintBackgroundEnabled( false )
        self:SetPaintBorderEnabled( false )
        self:DockPadding( 5, 60, 5, 5 )
        self:MakePopup()

        PANEL.TopPanel = self:Add( "DPanel" )
        PANEL.TopPanel:SetPos( 5, 30 )
        PANEL.TopPanel:SetSize( 790, 25 )
        
        function PANEL.TopPanel:Paint( w, h )
            surface_SimpleRect( 0, 24, w, 1, ultimate.Colors[ 54 ] )
        end
    end

    function PANEL:Think()
        local x,y = input_GetCursorPos()
        local mousex = math_Clamp( x, 1, scrw - 1 )
        local mousey = math_Clamp( y, 1, scrh - 1 )

        if ( self.Dragging ) then

            local x = mousex - self.Dragging[1]
            local y = mousey - self.Dragging[2]

            self:SetPos( x, y )

        end

        self:SetCursor( "arrow" )
    end

    function PANEL:IsActive()

        if ( self:HasFocus() ) then return true end
        if ( vgui.FocusedHasParent( self ) ) then return true end
    
        return false
    
    end
    

    function PANEL:OnMousePressed()
        local x,y = input_GetCursorPos()
        local screenX, screenY = self:LocalToScreen( 0, 0 )

        if (  y < ( screenY + 850 ) ) then
            self.Dragging = { x - self.x, y - self.y }
            self:MouseCapture( true )
            return
        end

    end

    function PANEL:OnMouseReleased()

        self.Dragging = nil
        self.Sizing = nil
        self:MouseCapture( false )

    end

    function PANEL:Paint(w, h)
        surface_SimpleRect(0, 0, w, h, ultimate.Colors[24])
        surface_SimpleRect(0, 0, w, 25, ultimate.Colors[54])
        surface_SetFont("tbfont")
        surface_SimpleText(8,4,"AfricaHook Super Lite",ultimate.Colors[165]) 

        
        //Kremlin hack Neo-Nazism edition beta alpha live supremacy paste v1
    end

    function PANEL:GetTopPanel()
        return PANEL.TopPanel
    end

    vgui_Register( "UFrame", PANEL, "EditablePanel" )
end

do
    local PANEL = {}

    function PANEL:Init()
        self:Dock( FILL )

        local vbar = self.VBar
        vbar:SetWide(3)
    
        vbar.Paint = nil
        vbar.btnUp.Paint = nil
        vbar.btnDown.Paint = nil
    
        function vbar.btnGrip:Paint( w, h ) 
            surface_SetDrawColor( ultimate.Colors[54] )
            surface_DrawRect( 0, 0, w, h )
        end
    end

    function PANEL:Paint( w, h )
    end

    function PANEL:OnMousePressed()
        ultimate.frame:OnMousePressed()
    end

    function PANEL:OnMouseReleased()
        ultimate.frame:OnMouseReleased()
    end

    vgui_Register( "UScroll", PANEL, "DScrollPanel" )
end

do
    local PANEL = {}

    function PANEL:Init()
        self.ItemPanel = vgui_Create( "DPanel", self )
        self.ItemPanel:Dock( FILL )
        self.ItemPanel:DockMargin( 3, 23, 3, 3 )

        self.ItemPanel.Paint = nil

        function self.ItemPanel:OnMousePressed()
            ultimate.frame:OnMousePressed()
        end
    
        function self.ItemPanel:OnMouseReleased()
            ultimate.frame:OnMouseReleased()
        end
    end

    function PANEL:Paint( w, h )
        surface_SetDrawColor( ultimate.Colors[54] )
        surface_DrawOutlinedRect( 0, 0, w, h, 1 )
   
        surface_SetFont( "tbfont" )
        surface_SimpleText( 8, 2, self.txt, ultimate.Colors[165] )

        surface_SimpleRect( 6, 20, w-12, 1, ultimate.Colors[54] )
    end

    function PANEL:OnMousePressed()
        ultimate.frame:OnMousePressed()
    end

    function PANEL:OnMouseReleased()
        ultimate.frame:OnMouseReleased()
    end

    function PANEL:GetItemPanel()
        return self.ItemPanel
    end
    
    vgui_Register( "UPanel", PANEL, "Panel" )
end

do
    local PANEL = {}

    function PANEL:Paint( w, h )
        surface_SimpleRect( 0, 0, w, h, ultimate.Colors[54] )
    end
    
    vgui_Register( "UPaintedPanel", PANEL, "Panel" )
end

do
    local PANEL = {}

    function PANEL:Init()
        self:Dock( TOP )
        self:DockMargin( 4, 4, 4, 0 )
        self:SetTall( 18 )
    end

    function PANEL:Paint( w, h )
        
    end
    
    vgui_Register( "UCBPanel", PANEL, "DPanel" )
end

do
    local PANEL = {}

    function PANEL:Init()
        self.Label:SetFont("tbfont")
        self.Label:SetTextColor(ultimate.Colors[165])

        self.Button:SetSize( 18, 18 )

        function self.Button:Paint(w,h)
            local v = self:GetChecked()

            surface_SetDrawColor(ultimate.Colors[54])

            surface_DrawOutlinedRect(0,0,w,h,1)

            if !v and !self:IsHovered() then return end

            if v then
                surface_SetDrawColor(ultimate.Colors[54])
            else
                surface_SetDrawColor(ultimate.Colors[40])
            end
                
            surface_DrawRect(3,3,w-6,h-6)
        end
    end

    function PANEL:PerformLayout()

        local x = self.m_iIndent || 0
    
        self.Button:SetSize( 18, 18 )
        self.Button:SetPos( x, math.floor( ( self:GetTall() - self.Button:GetTall() ) / 2 ) )
    
        self.Label:SizeToContents()
        self.Label:SetPos( x + self.Button:GetWide() + 9, math.floor( ( self:GetTall() - self.Label:GetTall() ) / 2 ) )
    
    end
    
    vgui_Register( "UCheckboxLabel", PANEL, "DCheckBoxLabel" )
end

do
    local PANEL = {}
    AccessorFunc(PANEL, "Value", "Value")
    AccessorFunc(PANEL, "SlideX", "SlideX")
    AccessorFunc(PANEL, "Min", "Min")
    AccessorFunc(PANEL, "Decimals", "Decimals")
    AccessorFunc(PANEL, "Max", "Max")
    AccessorFunc(PANEL, "Dragging", "Dragging")
    
    function PANEL:Init()
        self:SetMouseInputEnabled(true)
    
        self.Min = 0
        self.Max = 1
        self.SlideX = 0
        self.Decimals = 0
    
        self:SetValue(self.Min)
        self:SetSlideX(0)

        self:SetTall(15)
    end
    
    function PANEL:OnCursorMoved(x, y)
        if !self.Dragging then return end
    
        local w, h = self:GetSize()
    
        x = math_Clamp(x, 0, w) / w
        y = math_Clamp(y, 0, h) / h
    
        local value = self.Min + (self.Max - self.Min) * x
        value = math_Round(value, self:GetDecimals())
    
        self:SetValue(value)
        self:SetSlideX(x)
    
        self:OnValueChanged(value)
    
        self:InvalidateLayout()
    end
    
    function PANEL:OnMousePressed(mcode)
        self:SetDragging(true)
        self:MouseCapture(true)
    
        local x, y = self:CursorPos()
        self:OnCursorMoved(x, y)
    end
    
    function PANEL:OnMouseReleased(mcode)
        self:SetDragging(false)
        self:MouseCapture(false)
    end
    
    function PANEL:OnValueChanged(value)
    
    end

    function PANEL:Paint(w,h)
        local min, max = self:GetMin(), self:GetMax()

        surface_SetDrawColor(ultimate.Colors[54])
        surface_DrawOutlinedRect(0,0,w,h,1)
    
        surface_SetDrawColor(ultimate.Colors[54])
        surface_DrawRect(2, 2, self:GetSlideX()*w-4, h-4)
    end
    
    vgui_Register("USlider", PANEL, "Panel")
end

do
    local PANEL = {}

    function PANEL:Init()
        self:Dock(TOP)
        self:DockMargin(4,4,4,0)

        self:SetTextColor(ultimate.Colors[165])
        self:SetFont("tbfont")
    end

    function PANEL:Paint(w,h)
        if self:IsHovered() then
            surface_SetDrawColor(ultimate.Colors[35])
            surface_DrawRect(0, 0, w, h)
        end

        surface_SetDrawColor(ultimate.Colors[54])
        surface_DrawOutlinedRect(0,0,w,h,1)    
    end

    vgui_Register( "UButton", PANEL, "DButton" )
end

do
    local PANEL = {}

    function PANEL:Init()
        self:Dock(TOP)
        self:DockMargin(1,1,1,0)

        self:SetTextColor(ultimate.Colors[245])
        self:SetFont("tbfont")
    end

    function PANEL:Paint(w,h)
        if self:IsHovered() then
            surface_SetDrawColor(ultimate.Colors[35])
            surface_DrawRect(0, 0, w, h)
        end
    end

    vgui_Register( "UESPPButton", PANEL, "DButton" )
end

do
    local PANEL = {}

    function PANEL:Init()
        self:SetTall(20)
        self.DropButton.Paint = nil
    end

    function PANEL:Paint(w,h)
        surface_SetDrawColor(ultimate.Colors[25])
        surface_DrawRect(0,0,w,h)
    
        surface_SetDrawColor(ultimate.Colors[32])
        surface_DrawRect(w-25,0,25,25)
    
        surface_SetTextColor(ultimate.Colors[222])
        surface_SetTextPos(w-20,20/2-15/2)
        surface_SetFont("tbfont")
        surface_DrawText("▼")

        surface_SetDrawColor(ultimate.Colors[54])
        surface_DrawOutlinedRect(0,0,w,h)
    end

    function PANEL:OpenMenu( pControlOpener )

        if ( pControlOpener && pControlOpener == self.TextEntry ) then
            return
        end
    
        -- Don't do anything if there aren't any options..
        if ( #self.Choices == 0 ) then return end
    
        -- If the menu still exists and hasn't been deleted
        -- then just close it and don't open a new one.
        if ( IsValid( self.Menu ) ) then
            self.Menu:Remove()
            self.Menu = nil
        end
    
        -- If we have a modal parent at some level, we gotta parent to that or our menu items are not gonna be selectable
        local parent = self
        while ( IsValid( parent ) && !parent:IsModal() ) do
            parent = parent:GetParent()
        end
        if ( !IsValid( parent ) ) then parent = self end
    
        self.Menu = DermaMenu( false, parent )

        function self.Menu:Paint(w,h)
            surface_SetDrawColor(ultimate.Colors[24])
            surface_DrawRect(0,0,w,h)
            surface_SetDrawColor(ultimate.Colors[54])
            surface_DrawOutlinedRect(0,-1,w,h+1)
        end

        for k, v in pairs( self.Choices ) do
            local option = self.Menu:AddOption( v, function() self:ChooseOption( v, k ) end )
            option.txt = option:GetText()
            option:SetText("")

            function option:Paint(w,h)
                if self:IsHovered() then 
                    surface_SimpleRect(1,1,w-2,h-2,ultimate.Colors[32])
                end

                surface_SetTextColor(ultimate.Colors[165])
                surface_SimpleText(10,4,option.txt,ultimate.Colors[165])
            end   

            if ( self.Spacers[ k ] ) then
                self.Menu:AddSpacer()
            end
        end

    
        local x, y = self:LocalToScreen( 0, self:GetTall() )
    
        self.Menu:SetMinimumWidth( self:GetWide() )
        self.Menu:Open( x, y, false, self )
    
        self:OnMenuOpened( self.Menu )
    
    end
    
    function PANEL:PerformLayout(s)
        self:SetTextColor(ultimate.Colors[165])
        self:SetFont("tbfont")
    end

    vgui_Register( "UComboBox", PANEL, "DComboBox" )
end

do
    local PANEL = {}

    AccessorFunc( PANEL, "m_iSelectedNumber", "SelectedNumber" )

    function PANEL:Init()

        self:SetSelectedNumber( 0 )
        self:Dock( RIGHT )
        self:DockMargin( 4, 0, 0, 0 )
        self:SetTall( 18 )
        self:SetWide( 75 )

    end

    function PANEL:UpdateText()

        local str = input.GetKeyName( self:GetSelectedNumber() )
        if ( !str ) then str = "" end

        str = language.GetPhrase( str )

        self:SetText( "["..str.."]" )
        self:SetTextColor(ultimate.Colors[165])
        self:SetFont("tbfont")
    end

    function PANEL:Paint(w,h)
        surface_SetDrawColor(ultimate.Colors[54])
        surface_DrawOutlinedRect(0,0,w,h,1)
    end

    function PANEL:DoClick()

        self:SetText( "PRESS A KEY" )
        input.StartKeyTrapping()
        self.Trapping = true

    end

    function PANEL:DoRightClick()

        self:SetText( "[]" )
        self:SetValue( 0 )

    end

    function PANEL:SetSelectedNumber( iNum )

        self.m_iSelectedNumber = iNum
        self:UpdateText()
        self:OnChange( iNum )

    end

    function PANEL:Think()

        if ( input.IsKeyTrapping() && self.Trapping ) then

            local code = input.CheckKeyTrapping()
            if ( code ) then

                if ( code == KEY_ESCAPE ) then

                    self:SetValue( self:GetSelectedNumber() )

                else

                    self:SetValue( code )

                end

                self.Trapping = false

            end

        end

    end

    function PANEL:SetValue( iNumValue )

        self:SetSelectedNumber( iNumValue )

    end

    function PANEL:GetValue()

        return self:GetSelectedNumber()

    end

    function PANEL:OnChange()
    end

    vgui_Register( "UBinder", PANEL, "DButton" )
end

do
    local PANEL = {}

    PANEL.Color = Color(255,255,255,255)

    function PANEL:Init()
        self:Dock( RIGHT )
        self:DockMargin( 4, 0, 0, 0 )
        self:SetTall(18)
        self:SetWide(18)
        
        self:SetText("")
    end

    function PANEL:Paint(w,h)
        if self.Color.a < 255 then
            surface_SimpleTexturedRect(0,0,w,h,ultimate.Colors[255],ultimate.Materials["Alpha grid"])  
        end

        surface_SetDrawColor(self.Color)
        surface_DrawRect(0,0,w,h)
    end

    vgui_Register( "UCPicker", PANEL, "DButton" )
end

do
    local PANEL = {}

    PANEL.lifeTime = 0

    function PANEL:Paint( w, h )
        surface_SimpleRect( 0, 0, w, h, ultimate.Colors[25] )

        surface_SetDrawColor( ultimate.Colors[54] )
        surface_DrawOutlinedRect( 0, 0, w, h, 1 )
    end

    function PANEL:Init()
        self:RequestFocus()
        self:MakePopup()
    end

    function PANEL:Think()
        if self.lifeTime < 15 then self.lifeTime = self.lifeTime + 1 end

        if not self:HasFocus() and self.lifeTime >= 14 then
            self:Remove()
        end
    end

    vgui_Register( "ULifeTimeBase", PANEL, "DPanel" )
end

do
    local PANEL = {}

    function PANEL:Init()
        self:SetSize(200,200)
    end 

    function PANEL:Paint( w, h )
        surface_SimpleRect( 0, 0, w, h, ultimate.Colors[25] )

        surface_SetDrawColor( ultimate.Colors[54] )
        surface_DrawOutlinedRect( 0, 0, w, h, 1 )
    end

    vgui_Register( "UColorPanel", PANEL, "ULifeTimeBase" )
end

do
    local PANEL = {}

    function PANEL:Init()
        self:Dock( FILL )
        self:DockPadding(5, 5, 5, 5)
        self:SetPalette( false )
        self:SetWangs( false )
    end

    vgui_Register( "UColorMixer", PANEL, "DColorMixer" )
end

do
    local PANEL = {}

    function PANEL:Paint( w, h )
        surface_SetDrawColor( ultimate.Colors[24] )
        surface_DrawRect( 0, 0, w, h )

        surface_SetDrawColor( ultimate.Colors[54] )
        surface_DrawOutlinedRect( 0, 0, w, h, 1 )
    end

    vgui_Register( "USettingsPanel", PANEL, "ULifeTimeBase" )
end

do
    local PANEL = {}

    function PANEL:Init()
        self:Dock( RIGHT )
        self:DockMargin( 4, 0, 0, 0 )
        self:SetTall( 18 )
        self:SetWide( 18 )
        self:SetText( "..." )
    end

    vgui_Register( "USPanelButton", PANEL, "UButton" )
end

do
    local PANEL = {}

    function PANEL:Init()

        self.ButtonPanel = vgui_Create( "DPanel", self )
        self.ButtonPanel:Dock( TOP )
        self.ButtonPanel:DockMargin(3,3,3,2)
        self.ButtonPanel:SetTall(18)

        self.ItemPanel = vgui_Create( "DPanel", self )
        self.ItemPanel:Dock( FILL )
        self.ItemPanel:DockMargin( 3, 0, 3, 3 )

        self.ButtonPanel.Paint = nil
        self.ItemPanel.Paint = nil

        self.ActiveTab = "NIL"

        function self.ItemPanel:OnMousePressed()
            ultimate.frame:OnMousePressed()
        end
    
        function self.ItemPanel:OnMouseReleased()
            ultimate.frame:OnMouseReleased()
        end
    end

    function PANEL:Paint( w, h )
        surface_SetDrawColor( ultimate.Colors[54] )
        surface_DrawOutlinedRect( 0, 0, w, h, 1 )
   
        surface_SetFont( "tbfont" )
        surface_SimpleText( 8, 2, self.txt, ultimate.Colors[165] )

        surface_SimpleRect( 6, 20, w-12, 1, ultimate.Colors[54] )
    end

    function PANEL:OnMousePressed()
        ultimate.frame:OnMousePressed()
    end

    function PANEL:OnMouseReleased()
        ultimate.frame:OnMouseReleased()
    end

    function PANEL:GetItemPanel()
        return self.ItemPanel
    end

    function PANEL:GetButtonPanel()
        return self.ButtonPanel
    end

    vgui_Register( "UButtonBarPanel", PANEL, "Panel" )
end




// GUI FUNCS

ultimate.ui.ColorWindow = false
ultimate.ui.SettingsPan = false
ultimate.ui.MultiComboP = false

function ultimate.ui.RemovePanel( pan )
    if not pan then return end 

    pan:Remove()
    pan = false
end

function ultimate.ui.Binder( cfg, par )
    local b = vgui_Create( "UBinder", par )
    b:SetValue( ultimate.cfg.binds[ cfg ] )

    function b:OnChange()
        ultimate.cfg.binds[ cfg ] = b:GetValue()
    end

    return b
end

function ultimate.ui.ColorPicker( cfg, par, onChange )
    local b = vgui_Create( "UCPicker", par )

    function b:DoClick()
        local x, y = self:LocalToScreen( 0, self:GetTall() )

        ultimate.ui.RemovePanel( ultimate.ui.ColorWindow )

        ultimate.ui.ColorWindow = vgui_Create( "UColorPanel" )
        ultimate.ui.ColorWindow:SetPos( x+25, y-100 )

        local c = vgui_Create( "UColorMixer", ultimate.ui.ColorWindow )
        c:SetColor( string_ToColor( ultimate.cfg.colors[cfg] ) )

        c.HSV.Knob:SetSize( 5, 5 )

        function c.HSV.Knob:Paint( w, h )
            surface_SimpleRect( 0, 0, w, h, b.Color )

            surface_SetDrawColor( ultimate.Colors[255] )
            surface_DrawOutlinedRect( 0, 0, w, h, 1 )
        end

        function c:ValueChanged( col )
            b.Color = col 
            ultimate.cfg.colors[cfg] = tostring(col.r) .. " " .. tostring(col.g) .. " " .. tostring(col.b) .. " " .. tostring(col.a)
            if onChange then onChange( col ) end
        end

    end

    b.Color = string_ToColor( ultimate.cfg.colors[cfg] )
end

function ultimate.ui.SPanel( func, p )
    local b = vgui_Create( "USPanelButton", p )

    function b:DoClick()
        local mx, my = input_GetCursorPos()

        ultimate.ui.RemovePanel( ultimate.ui.SettingsPan )

        ultimate.ui.SettingsPan = vgui_Create( "USettingsPanel" )
        ultimate.ui.SettingsPan:SetPos( mx+25, my-10 )

        func()
    end
end

function ultimate.ui.Label( pan, str, postCreate )
    local p = vgui_Create( "UCBPanel", pan )

    local lbl = vgui_Create( "DLabel", p )
    lbl:SetText( str )
    lbl:SetFont( "tbfont" )
    lbl:SetTextColor( ultimate.Colors[165] )
    lbl:Dock( LEFT )
    lbl:DockMargin( 4, 2, 4, 0 )
    lbl:SizeToContents()

    if postCreate then postCreate( p ) end
end
    
function ultimate.ui.CheckBox( par, lbl, cfg, hint, bind, color, spanel, onToggle, postCreate )
    local p = vgui_Create( "UCBPanel", par )

    local c = vgui_Create( "UCheckboxLabel", p )
    c:SetText( lbl )
    c:SetPos( 0, 0 )
    c:SetValue( ultimate.cfg.vars[cfg] )

    function c:OnChange( bval )
        ultimate.cfg.vars[cfg] = bval

        if onToggle then onToggle(bval) end
    end

    if postCreate then postCreate( p ) end

    if bind then ultimate.ui.Binder( cfg, p ) end
    if color then ultimate.ui.ColorPicker( cfg, p ) end
    if spanel then ultimate.ui.SPanel( spanel, p ) end

    if hint then
        function c.Label:Paint()
            if self:IsHovered() then
                local x, y = input_GetCursorPos()

                ultimate.hint = true
                ultimate.hintText = hint
                ultimate.hintX = x + 45
                ultimate.hintY = y - 5
            end
        end
    end
end

function ultimate.ui.Slider( p, str, cfg, min, max, dec, onChange )
    local pan = vgui_Create( "DPanel", p )
    pan:Dock( TOP )
    pan:DockMargin( 4, 2, 4, 0 )
    pan:SetTall( 20 )

    function pan:Paint( w, h )
        surface_SetFont("tbfont")

        local s = ultimate.cfg.vars[cfg]
        local tw, th = surface_GetTextSize(s)
        
        surface_SimpleText(2,4,str,ultimate.Colors[165])

        surface_SimpleText(w-tw-2,4,ultimate.cfg.vars[cfg],ultimate.Colors[165])
    end

    local c = vgui_Create( "USlider", p )
    c:Dock( TOP )
    c:DockMargin( 4, 2, 4, 0 )
    c:SetMax( max )
    c:SetMin( min )
    c:SetDecimals( dec )

    c:SetValue( ultimate.cfg.vars[cfg] )

    local value, min, max = c:GetValue(), c:GetMin(), c:GetMax()

	c:SetSlideX((value - min) / (max - min))

    function c:OnValueChanged( val )
        ultimate.cfg.vars[cfg] = val

        if onChange then onChange(val) end
    end
end

function ultimate.ui.Button( str, func, p ) 
    local b = vgui_Create( "UButton", p )
    b:SetText( str )

    function b:DoClick()
        func()
    end
end

function ultimate.ui.TextEntry( str, cfg, pan, chars, postCreate )
    local lbl = vgui_Create("DLabel",pan)
    lbl:Dock(TOP)
    lbl:DockMargin(4,2,4,0)
    lbl:SetText(str)
    lbl:SetFont("tbfont")
    lbl:SetColor(ultimate.Colors[165])

    local p = vgui_Create("DPanel",pan)
    p:SetTall(25)
    p:Dock(TOP)
    p:DockMargin(4,2,4,0)

    p.Paint = function(s,w,h)
        surface_SetDrawColor(ultimate.Colors[54])
        surface_DrawOutlinedRect(0,0,w,h)
    end
	
	local txt = vgui_Create("DTextEntry",p)
	txt:Dock(FILL)
	txt:DockMargin(4,4,4,4) 
	txt:IsMultiline( false )
	txt:SetMaximumCharCount(chars)
	txt:SetPlaceholderText(str)
	txt:SetFont( "tbfont" )
    txt:SetPaintBackground(false)
    txt:SetTextColor(ultimate.Colors[165])

	if ultimate.cfg.vars[cfg] != nil and ultimate.cfg.vars[cfg] != "" then
		txt:SetValue(ultimate.cfg.vars[cfg])
	end

	function txt.Think()
		if txt:IsEditing() then return end
        if ultimate.cfg.vars[cfg] == txt:GetValue() then return end

		ultimate.cfg.vars[cfg] = txt:GetValue()
	end 

	function txt.OnValueChange()
		ultimate.cfg.vars[cfg] = txt:GetValue()
	end

    if postCreate then postCreate(p) end
end

function ultimate.ui.dropdownButton( str, v, p, a )
    local b = p:Add("DButton")
    b:Dock(TOP)
    b:SetTall(20)
    b:DockMargin(2,2,2,0)
    b:SetText("")
    
    function b:Paint(w,h)
        if self:IsHovered() then 
            surface_SimpleRect(1,1,w-2,h-2,ultimate.Colors[32])
        end

        surface_SetTextColor(ultimate.Colors[165])

        if ultimate.cfg.vars[str.."-"..v] then
            surface_SetTextColor(ultimate.Colors[235]) 
        end

        surface_SetTextPos(5,3)
        surface_SetFont("tbfont")
        surface_DrawText(v)
    end

    function b:DoClick()
        ultimate.cfg.vars[str.."-"..v] = not ultimate.cfg.vars[str.."-"..v] 
    end
end

function ultimate.ui.MultiCombo( pan, str, choices )
    local lbl = vgui_Create("DLabel",pan)
    lbl:Dock(TOP)
    lbl:DockMargin(4,1,4,0)
    lbl:SetText(str)
    lbl:SetFont("tbfont")
    lbl:SetColor(ultimate.Colors[165])

    local d = vgui_Create("DButton",pan)
    d:Dock(TOP)
    d:DockMargin(4,1,4,0)
    d:SetTall(20)
    d:SetText("")
    
    d.preview = {}

    function d:Paint(w,h)
        local preview = ""

        for k, v in pairs(choices) do
            if ultimate.cfg.vars[str.."-"..v] == true and (d.preview[v] == false or d.preview[v] == nil) and not table.HasValue(d.preview, v) then
                table_insert(d.preview,v) 
            elseif ultimate.cfg.vars[str.."-"..v] == false and (d.preview[v] == true or d.preview[v] == nil) and table.HasValue(d.preview, v) then
                table_RemoveByValue(d.preview,v)
            elseif d.preview[v] == false then 
                table_RemoveByValue(d.preview,v)
            end
        end

        preview = table_concat(d.preview,", ")

        surface_SetDrawColor(ultimate.Colors[25])
        surface_DrawRect(0,0,w,h)
    
        surface_SetTextColor(ultimate.Colors[165])
        surface_SetTextPos(8,20/2-15/2)
        surface_SetFont("tbfont")
        surface_DrawText(preview)
    
        surface_SetDrawColor(ultimate.Colors[32])
        surface_DrawRect(w-25,0,25,25)
    
        surface_SetTextColor(ultimate.Colors[165])
        surface_SetTextPos(w-20,20/2-15/2)
        surface_SetFont("tbfont")
        surface_DrawText("▼")

        surface_SetDrawColor(ultimate.Colors[54])
        surface_DrawOutlinedRect(0,0,w,h,1)
    end

    function d:DoClick()
        local x,y = self:LocalToScreen( 0, self:GetTall() )

        ultimate.ui.RemovePanel( ultimate.ui.MultiComboP )

        local ctoh = #choices
    
        ultimate.ui.MultiComboP = vgui_Create( "ULifeTimeBase" )
        ultimate.ui.MultiComboP:SetPos( x, y - 1 )
        ultimate.ui.MultiComboP:SetSize( 243, ctoh * 22 + 2 )
    
        for k, v in pairs(choices) do
            ultimate.ui.dropdownButton( str, v, ultimate.ui.MultiComboP, d.preview )
        end
    end
end

function ultimate.ui.ComboBox( pan, str, choices, cfg  )
    local lbl = vgui_Create("DLabel",pan)
    lbl:Dock(TOP)
    lbl:DockMargin(4,1,4,0)
    lbl:SetText(str)
    lbl:SetFont("tbfont")
    lbl:SetColor(ultimate.Colors[165])

    local dropdown = vgui_Create("UComboBox",pan)
    dropdown:Dock(TOP)
    dropdown:DockMargin(4,1,4,0)
    

    for k, v in ipairs(choices) do
        dropdown:AddChoice(v)
    end
    
    dropdown:SetSortItems(false)

    if ultimate.cfg.vars[cfg] <= #choices then
        dropdown:ChooseOptionID(ultimate.cfg.vars[cfg])
    else
        dropdown:ChooseOptionID(1)
    end

    function dropdown:OnSelect(index, value, data)
        ultimate.cfg.vars[cfg] = index
    end
end

function ultimate.ui.InitMT( p, postCreate )
    p.ItemPanel:Remove()

    p.ItemPanel = vgui_Create( "DPanel", p )
    p.ItemPanel:Dock( FILL )
    p.ItemPanel:DockMargin( 3, 0, 3, 3 )

    p.ItemPanel.Paint = nil

    if postCreate then postCreate( p.ItemPanel ) end
end

function ultimate.ui.MTButton( p, str, postCreate )
    surface_SetFont("tbfont")
    local w, h = surface_GetTextSize(str)

    local fw = w + 5

    local tx, ty = fw/2 - w/2, 18 / 2-h / 2 - 1

    local b = p:GetButtonPanel():Add("DButton")
    b:Dock(RIGHT)
    b:DockMargin(2,0,2,1)
    b:SetWide(fw)
    b:SetText("")
    
    function b:DoClick()
        p.ActiveTab = str
        ultimate.ui.InitMT( p, postCreate )
    end

    function b:Paint(width,height)
        if p.ActiveTab == str then
            surface_SetTextColor(235,235,235,255)
        else
            surface_SetTextColor(165,165,165,255)
        end
        
        surface_DrawRect(0,0,width,height)

        surface_SetFont("tbfont")
        surface_SetTextPos(tx,ty)
        surface_DrawText(str)
    end

    p.ActiveTab = str
    ultimate.ui.InitMT( p, postCreate )
end

ultimate.pty = { 5, 5, 5 }
do
    local xt = { 
        [1] = 5,
        [2] = 267,
        [3] = 529
    }

    function ultimate.itemPanel( str, tbl, h )
        local p = vgui_Create( "UPanel", ultimate.scrollpanel )
        p:SetPos( xt[tbl], ultimate.pty[tbl] )
        p:SetSize( 257, h )
        p.txt = str

        ultimate.pty[ tbl ] = ultimate.pty[ tbl ] + h + 5

        return p
    end

    function ultimate.itemPanelB( str, tbl, h, buttonsFunc )
        local p = vgui_Create( "UButtonBarPanel", ultimate.scrollpanel )
        p:SetPos( xt[tbl], ultimate.pty[tbl] )
        p:SetSize( 257, h )
        p.txt = str

        if buttonsFunc then buttonsFunc( p ) end

        ultimate.pty[ tbl ] = ultimate.pty[ tbl ] + h + 5

        return p
    end

end

/*
    Drag n drop 
*/

ultimate.espposes = {"Up","Down","Right","Left"}
ultimate.espelements = {"Name pos","Usergroup pos","Health pos","Armor pos","Money pos","Weapon pos","Team pos","Break LC pos","Simtime pos"}
ultimate.lastdrag = ""
ultimate.esppans = {}

ultimate.esppansposes = {
    [1] = {
        x = 85,
        y = 0,
    },
    [2] = {
        x = 85,
        y = 250,
    },
    [3] = {
        x = 170,
        y = 125,
    },
    [4] = {
        x = 0,
        y = 125,
    },
}

for i = 1, 4 do
    ultimate.esppans[i] = {}
end

function ultimate.DoDrop( self, panels, bDoDrop, Command, x, y )
    if ( bDoDrop ) then
        local newpos = self.pos
        
        for i = 1, #panels do
            local v = panels[i]

            ultimate.cfg.vars[ v:GetText() ] = newpos
            v:SetParent( self )
        end
    end
end
    
ultimate.spfuncs = {}

// PANEL CREATION

ultimate.frame = vgui_Create("UFrame")
ultimate.scrollpanel = vgui_Create("UScroll",ultimate.frame)

ultimate.tabs = {}

// Aimbot

ultimate.spfuncs[1] = function()
    ultimate.ui.SettingsPan:SetSize( 250, 26 )

    ultimate.ui.CheckBox( ultimate.ui.SettingsPan, "On key", "Aim on key", false, true )
end

ultimate.spfuncs[2] = function()
    ultimate.ui.SettingsPan:SetSize( 250, 92 )

    ultimate.ui.CheckBox( ultimate.ui.SettingsPan, "Rapid fire", "Rapid fire", "Allows to quickly fire semi-automatic weapons." )
    ultimate.ui.CheckBox( ultimate.ui.SettingsPan, "Bullet time", "Bullet time", "Aim will not work until weapon can fire." )
    ultimate.ui.CheckBox( ultimate.ui.SettingsPan, "Wait for simtime update", "Wait for simtime update" )
end

ultimate.spfuncs[3] = function()
    ultimate.ui.SettingsPan:SetSize( 250, 68 )

    ultimate.ui.ComboBox( ultimate.ui.SettingsPan, "Knifebot mode", {"Damage","Fast","Fatal"}, "Knifebot mode"  )
    ultimate.ui.CheckBox( ultimate.ui.SettingsPan, "Facestab", "Facestab" )
end

ultimate.spfuncs[4] = function()
    ultimate.ui.SettingsPan:SetSize( 250, 85 )

    ultimate.ui.Slider( ultimate.ui.SettingsPan, "Smooth amount", "Smoothing", 0, 1, 2 )
end

ultimate.spfuncs[5] = function()
    ultimate.ui.SettingsPan:SetSize( 250, 68 )

    ultimate.ui.CheckBox( ultimate.ui.SettingsPan, "Dynamic fov", "Fov dynamic" )
    ultimate.ui.Slider( ultimate.ui.SettingsPan, "Aimbot FOV", "Aimbot FOV", 0, 180, 0 )
end

ultimate.spfuncs[6] = function()
    ultimate.ui.SettingsPan:SetSize( 250, 26 )

    ultimate.ui.CheckBox( ultimate.ui.SettingsPan, "pSilent", "pSilent", "Context vector will be used to make aim completely invisible." )
end

ultimate.spfuncs[7] = function()
    ultimate.ui.SettingsPan:SetSize( 250, 46 )

    ultimate.ui.Slider( ultimate.ui.SettingsPan, "Multipoint scale", "Multipoint scale", 0.5, 1, 1 )
end

ultimate.spfuncs[8] = function()
    ultimate.ui.SettingsPan:SetSize(250,122)

    ultimate.ui.CheckBox( ultimate.ui.SettingsPan, "Always backtrack", "Always backtrack" ) 
    ultimate.ui.ComboBox( ultimate.ui.SettingsPan, "Backtrack mode", {"First ticks","Adaptive ( melee )","Scan ( pizdets )"}, "Backtrack mode" )
    ultimate.ui.Slider( ultimate.ui.SettingsPan, "Backtrack time", "Backtrack time", 0, 1000, 0 )
end

ultimate.spfuncs[9] = function()
    ultimate.ui.SettingsPan:SetSize(250,122)

    ultimate.ui.CheckBox( ultimate.ui.SettingsPan, "Disable Sequence interpolation", "Disable Sequence interpolation", false, false, false, false, function(bval) ded.SetSequenceInterpolation(bval) end ) 
    ultimate.ui.CheckBox( ultimate.ui.SettingsPan, "Bone fix", "Bone fix", false, false, false, false, function(bval) ded.EnableBoneFix(bval) end ) 
    ultimate.ui.CheckBox( ultimate.ui.SettingsPan, "Animation fix", "Update Client Anim fix", false, false, false, false, function(bval) ded.EnableAnimFix(bval) end ) 
end

ultimate.spfuncs[10] = function()
    ultimate.ui.SettingsPan:SetSize(250,200)

    ultimate.ui.CheckBox( ultimate.ui.SettingsPan, "Passive recharge", "Passive recharge" )
    ultimate.ui.CheckBox( ultimate.ui.SettingsPan, "Warp on peek", "Warp on peek" )
   
    ultimate.ui.ComboBox( ultimate.ui.SettingsPan, "Fakelag comp", {"Disable","Compensate"}, "Fakelag comp" )
    ultimate.ui.Slider( ultimate.ui.SettingsPan, "Minimum Shift Ticks", "Minimum Shift Ticks", 1, 99, 0, function( val ) ded.SetMinShift(val) end )
    ultimate.ui.Slider( ultimate.ui.SettingsPan, "Maximum Shift Ticks", "Maximum Shift Ticks", 1, 99, 0, function( val ) ded.SetMaxShift(val) end )

end

ultimate.spfuncs[30] = function()
    ultimate.ui.SettingsPan:SetSize(250,200)

    
end

function ultimate.tabs.Aimbot()
    local p = ultimate.itemPanel("Main",1,130):GetItemPanel()

    ultimate.ui.CheckBox( p, "Enable Aimbot", "Enable aimbot", false, false, false, ultimate.spfuncs[1] )
    ultimate.ui.CheckBox( p, "Auto fire", "Auto fire", "Automatically fires when targets can be damaged.", false, false, ultimate.spfuncs[2] )
    ultimate.ui.CheckBox( p, "Auto reload", "Auto reload", "Automatically reloads weapon when clip is empty." )
    ultimate.ui.CheckBox( p, "Silent aim", "Silent aim", false, false, false, ultimate.spfuncs[6] )
    
    local p = ultimate.itemPanel("Legit",1,120):GetItemPanel()

    ultimate.ui.CheckBox( p, "Aimbot smoothing", "Aimbot smoothing", false, false, false, ultimate.spfuncs[4] )
    ultimate.ui.CheckBox( p, "Fov limit", "Fov limit", false, false, false, ultimate.spfuncs[5] )
    ultimate.ui.CheckBox( p, "Trigger", "Trigger bot", false, true )


    local p = ultimate.itemPanel("Accuracy",2,110):GetItemPanel()
    
    ultimate.ui.CheckBox( p, "Norecoil", "Norecoil" )
    ultimate.ui.CheckBox( p, "Nospread", "Nospread", "Supported HL2, M9K, FAS2, CW2, SWB", false, false, ultimate.spfuncs[30] )
    ultimate.ui.CheckBox( p, "Disable interpolation", "Disable interpolation", false, false, false, ultimate.spfuncs[9], function(bval) ded.SetInterpolation(bval) end )

    local p = ultimate.itemPanel("Target selection",3,136):GetItemPanel()

    ultimate.ui.ComboBox( p, "Target selection", {"Distance","FOV"}, "Target selection" )
    ultimate.ui.MultiCombo( p, "Ignores", {"Friends","Steam friends","Teammates","Driver","Head unhitable","God time","Nocliping","Nodraw","Frozen","Bots","Admins"} )
    ultimate.ui.CheckBox( p, "Wallz", "Wallz" ) 

    local p = ultimate.itemPanel("Hitbox selection",3,134):GetItemPanel()

    ultimate.ui.ComboBox( p, "Hitbox selection", {"Head","Chest","Penis"}, "Hitbox selection")
    ultimate.ui.CheckBox( p, "Multipoint", "Multipoint", false, false, false, ultimate.spfuncs[7] )

    local p = ultimate.itemPanel("Position adjustment",2,100):GetItemPanel()

    ultimate.ui.CheckBox( p, "Adjust tickcount", "Adjust tickcount" )
    ultimate.ui.CheckBox( p, "Backtrack", "Backtrack", false, false, false, ultimate.spfuncs[8] )

    local p = ultimate.itemPanel("Visualization",2,100):GetItemPanel()
    ultimate.ui.CheckBox(p,"Aimbot FOV Circle","FOV Circle",false,false,false,false,false,function(p) ultimate.ui.ColorPicker( "FOV Circle Color", p ) end)
    ultimate.ui.CheckBox(p,"Aimbot Snaplines","Snap lines")

    
    /*
    func = function()
        ultimate.settingspan:SetSize(250,64)

        ultimate.slider("Forwardtrack time","Forwardtrack time",0,200,0,ultimate.settingspan)
    end
    ultimate.checkbox("Forwardtrack","Forwardtrack",p,false,false,false,false,func) 
    //ultimate.checkbox("Backshoot","Backshoot",p) 
    ultimate.checkbox("Auto healthkit","Auto healthkit",p:GetItemPanel())
    ultimate.multiCombo("Healthkit",{"Self heal","Heal closest"},p:GetItemPanel())
    */
end

ultimate.spfuncs[13] = function()
    ultimate.ui.SettingsPan:SetSize(250,200)

    
    ultimate.ui.CheckBox( ultimate.ui.SettingsPan, "Freestanding", "Freestanding" )
    ultimate.ui.CheckBox( ultimate.ui.SettingsPan, "Micromovement", "Micromovement" )

    //ultimate.checkbox("","Freestanding",ultimate.settingspan,"freestand")
end

ultimate.spfuncs[22] = function()
    ultimate.ui.SettingsPan:SetSize(250,200)

    ultimate.ui.Slider( ultimate.ui.SettingsPan, "Lag limit","Lag limit",1,23,0 )
    ultimate.ui.Slider( ultimate.ui.SettingsPan, "Random min","Lag randomisation",1,23,0 )
    ultimate.ui.ComboBox( ultimate.ui.SettingsPan, "Lag mode", {"Static","Adaptive","Hybrid"}, "Lag mode")
    ultimate.ui.MultiCombo( ultimate.ui.SettingsPan, "Fake lag options", {"Disable on ladder","Disable in attack","Randomise","On peek"} )
end

ultimate.spfuncs[23] = function( p )
    ultimate.ui.CheckBox( p, "Anti aim", "Anti aim", false, false, false, ultimate.spfuncs[13] )
    ultimate.ui.ComboBox( p, "Yaw base", {"Viewangles","At targets"}, "Yaw base" )
    ultimate.ui.ComboBox( p, "Yaw", {"Backward","Fake forward","Sideways","Half sideways","Fake spin","LBY","Kappa","Sway"}, "Yaw" )
    ultimate.ui.ComboBox( p, "Pitch", {"Down","Up","Zero","Fake down","Fake fake down","Fake jitter","Kizaru"}, "Pitch" )
    ultimate.ui.CheckBox( p, "On shot aa", "On shot aa" )
end

ultimate.spfuncs[24] = function( p )
    ultimate.ui.CheckBox( p, "Taunt spam", "Taunt spam" )
    ultimate.ui.ComboBox( p, "Taunt", ultimate.actCommands, "Taunt" )

    ultimate.ui.CheckBox( p, "Handjob", "Handjob" )
    ultimate.ui.ComboBox( p, "Handjob mode", {"Up","Jitter","Ultra cum"}, "Handjob mode" )

    // "Runs act command to make your model dance for other clients"
    //"Forcing istyping for animation desync"
end

function ultimate.tabs.Rage()

    local function func( p )
        ultimate.ui.MTButton( p, "Anim breakers", ultimate.spfuncs[24] )
        ultimate.ui.MTButton( p, "Angles", ultimate.spfuncs[23] )
    end

    ultimate.itemPanelB( "Anti aim",1,250, func )




    local p = ultimate.itemPanel("Fake lag",2,100):GetItemPanel()

    ultimate.ui.CheckBox( p, "Fake lag", "Fake lag", false, false, false, ultimate.spfuncs[22] )
    ultimate.ui.CheckBox( p, "Fake duck", "Fake duck", false, true )
   



    local p = ultimate.itemPanel("Aim Helpers",3,120):GetItemPanel()

    ultimate.ui.CheckBox( p, "Resolver", "Resolver" )
    ultimate.ui.CheckBox( p, "Pitch resolver", "Pitch resolver" )
 ultimate.ui.CheckBox( p, "Tickbase", "Tickbase shift", "Time shift exploit", true, false, ultimate.spfuncs[10], function(b) ded.EnableTickbaseShifting(b) end )

    

     /*
ultimate.cfg.vars["Resolver"] = false
ultimate.cfg.vars["Yaw mode"] = 1
ultimate.cfg.vars["Pitch resolver"] = false
ultimate.cfg.vars["Invert first shot"] = false
ultimate.cfg.vars["Resolver max misses"] = 2

    ultimate.combobox("Edge", {"None","Hide","Jitter"}, "Edge", p:GetItemPanel())

    ultimate.checkbox("Show AA","Anti aim chams",p:GetItemPanel())

    local p = ultimate.itemPanel("Animation breakers",1,200)

    
    

    local p = ultimate.itemPanel("Animfix",3,223)

    ultimate.cfg.vars["Interpolation-Disable interpolation"] = false
    ultimate.cfg.vars["Interpolation-Fast sequences"] = false


    ultimate.checkbox("Disable taunts","Disable taunts",p:GetItemPanel())
    ultimate.checkbox("Extrapolation","Extrapolation",p:GetItemPanel())
    ultimate.checkbox("test","last update",p:GetItemPanel())
    

    

    local p = ultimate.itemPanel("Fake lag",2,320)



    

    ultimate.checkbox("Fly hacks","Allah fly",p:GetItemPanel())

    //ultimate.checkbox("Fake lag","Fake lag",p:GetItemPanel())
    //ultimate.slider("Lag limit","Lag limit",0,23,0,p:GetItemPanel())
    //ultimate.slider("Lag randomisation","Lag randomisation",0,23,0,p:GetItemPanel())
    //ultimate.combobox("Lag mode", {"Static","Adaptive"}, "Lag mode", p:GetItemPanel())
   
    ultimate.checkbox("Michael Jackson exploit","Allah walk",p:GetItemPanel(),"allahwalk")
    ultimate.checkbox("","Fake duck",p:GetItemPanel(),"Fake duck")
   
    local p = ultimate.itemPanel("Tickbase",2,250)


    ultimate.multiCombo("Triggers",{"In Attack","On Peek","After peek"},p:GetItemPanel())

    // ultimate.checkbox("Skip fire tick","Skip fire tick",p:GetItemPanel())
    

    local p = ultimate.itemPanel( "Resolver", 3, 178 )

    ultimate.checkbox( "Enable resolver", "Resolver", p:GetItemPanel() )
    ultimate.combobox( "Yaw mode", { "Step", "Delta brute" }, "Yaw mode", p:GetItemPanel() )
    ultimate.slider( "Max misses", "Resolver max misses", 1, 6, 0, p:GetItemPanel() )
    ultimate.checkbox( "Pitch resolver", "Pitch resolver", p:GetItemPanel() )
    ultimate.checkbox( "Invert first shot", "Invert first shot", p:GetItemPanel() )
*/
end

/*local p = vgui_Create("UPanel",ultimate.scrollpanel)
    p:SetPos(5,y[1])
    p:SetSize(257,200)
    p.txt = "LBY Settings"

    ultimate.slider("LBY min delta","LBY min delta",0,360,0,p:GetItemPanel())
    ultimate.slider("LBY break delta","LBY break delta",0,360,0,p:GetItemPanel())
    */

ultimate.spfuncs[11] = function()
    ultimate.ui.SettingsPan:SetSize(250,200)
    
    //ultimate.ui.ComboBox( ultimate.ui.SettingsPan, "Style", {"Default","Outlined"}, "Box style")
end

ultimate.spfuncs[12] = function()
    ultimate.ui.SettingsPan:SetSize(250,48)
    
    ultimate.ui.CheckBox( ultimate.ui.SettingsPan, "Health bar", "Health bar" )
    ultimate.ui.CheckBox( ultimate.ui.SettingsPan, "Gradient", "Health bar gradient" )
end

ultimate.spfuncs[14] = function()
    ultimate.ui.SettingsPan:SetSize(250,256)
    
    ultimate.ui.ComboBox( ultimate.ui.SettingsPan, "Visible material", {"Flat","Textured","Selfillum","Selfillum additive","Wireframe","Metallic","Glass","Pulsing glow"}, "Visible mat")
    ultimate.ui.CheckBox( ultimate.ui.SettingsPan, "Weapon chams", "Visible chams w" )

    ultimate.ui.ComboBox( ultimate.ui.SettingsPan, "Invisible material", {"Flat","Textured","Selfillum","Selfillum additive","Wireframe","Metallic","Glass","Pulsing glow"}, "inVisible mat")
    ultimate.ui.CheckBox( ultimate.ui.SettingsPan, "inVisible chams", "inVisible chams" )
    ultimate.ui.CheckBox( ultimate.ui.SettingsPan, "Weapon chams", "inVisible chams w" )

    ultimate.ui.CheckBox( ultimate.ui.SettingsPan, "Fullbright", "Supress lighting" )
end

ultimate.spfuncs[15] = function()
    ultimate.ui.SettingsPan:SetSize(250,256)

    ultimate.ui.ComboBox( ultimate.ui.SettingsPan, "Material", {"Flat","Textured","Selfillum","Selfillum additive","Wireframe","Metallic","Glass","Pulsing glow"}, "Self mat")
    ultimate.ui.CheckBox( ultimate.ui.SettingsPan, "Weapon chams", "Self chams w" )

    ultimate.ui.CheckBox( ultimate.ui.SettingsPan, "Fullbright", "Supress self lighting" )
end

ultimate.spfuncs[16] = function()
    ultimate.ui.SettingsPan:SetSize(250,256)

    ultimate.ui.ComboBox( ultimate.ui.SettingsPan, "Material", {"Flat","Textured","Selfillum","Selfillum additive","Wireframe","Metallic","Glass","Pulsing glow"}, "Backtrack material")

    ultimate.ui.CheckBox( ultimate.ui.SettingsPan, "Fullbright", "Backtrack fullbright" )
end

ultimate.spfuncs[17] = function()
    ultimate.ui.SettingsPan:SetSize(250,256)

    ultimate.ui.ComboBox( ultimate.ui.SettingsPan, "Material", {"Flat","Textured","Selfillum","Selfillum additive","Wireframe","Metallic","Glass","Pulsing glow"}, "Entity material")

    ultimate.ui.CheckBox( ultimate.ui.SettingsPan, "Fullbright", "Entity fullbright" )
end

ultimate.spfuncs[18] = function()
    ultimate.ui.SettingsPan:SetSize(250,256)

    ultimate.ui.Slider( ultimate.ui.SettingsPan, "Die time","Tracers die time",1,10,0 )
    ultimate.ui.TextEntry( "Material", "Bullet tracers material", ultimate.ui.SettingsPan, 420 )
end

ultimate.spfuncs[19] = function()
    ultimate.ui.SettingsPan:SetSize(250,256)

    ultimate.ui.ComboBox( ultimate.ui.SettingsPan, "Material", {"Flat","Textured","Selfillum","Selfillum additive","Wireframe","Metallic","Glass","Pulsing glow"}, "Viewmodel chams type")

    ultimate.ui.CheckBox( ultimate.ui.SettingsPan, "Fullbright", "Fullbright viewmodel" )
end

ultimate.spfuncs[20] = function()
    ultimate.ui.SettingsPan:SetSize(250,256)

    ultimate.ui.CheckBox( ultimate.ui.SettingsPan, "Smoothing", "Third person smoothing" )
    ultimate.ui.CheckBox( ultimate.ui.SettingsPan, "Collision", "Third person collision" )
    ultimate.ui.Slider( ultimate.ui.SettingsPan, "Distance","Third person distance",50,220,0 )
end

ultimate.spfuncs[21] = function()
    ultimate.ui.SettingsPan:SetSize(250,256)

    ultimate.ui.Slider( ultimate.ui.SettingsPan, "Freecam speed","Free camera speed",5,100,0 )
end

function ultimate.tabs.Visuals()

    local p = ultimate.itemPanel("Player",1,230):GetItemPanel()

    ultimate.ui.CheckBox( p, "Box", "Box esp", false, false, false, ultimate.spfuncs[11] )

    ultimate.ui.CheckBox( p, "Name", "Name" )
    ultimate.ui.CheckBox( p, "Usergroup", "Usergroup" )
    ultimate.ui.CheckBox( p, "Health", "Health", false, false, true, ultimate.spfuncs[12], false, function(p) ultimate.ui.ColorPicker( "Health bar gradient", p ) end )
    ultimate.ui.CheckBox( p, "Armor", "Armor" )
    ultimate.ui.CheckBox( p, "Weapon", "Weapon" )
    ultimate.ui.CheckBox( p, "Team", "Team" )

    ultimate.ui.Slider( p, "Max distance","ESP Distance",0,100000,0 )


   
    

    local p = ultimate.itemPanel("Colored models",2,140):GetItemPanel()

    ultimate.ui.CheckBox( p, "Player chams", "Visible chams", false, false, true, ultimate.spfuncs[14], false, function(p) ultimate.ui.ColorPicker( "inVisible chams", p ) end )
    ultimate.ui.CheckBox( p, "Self chams", "Self chams", false, false, true, ultimate.spfuncs[15] )
    ultimate.ui.CheckBox( p, "Backtrack chams", "Backtrack chams", false, false, true, ultimate.spfuncs[16] )
    ultimate.ui.CheckBox( p, "Entity chams", "Entity chams", false, false, true, ultimate.spfuncs[17], false )
    ultimate.ui.CheckBox( p, "Viewmodel chams", "Viewmodel chams", false, false, true, ultimate.spfuncs[19], false )

    local p = ultimate.itemPanel("Outlines",2,115):GetItemPanel()

    ultimate.ui.CheckBox( p, "Player outline", "Player outline", false, false, true )
    ultimate.ui.ComboBox( p, "Style", { "Default", "Subtractive", "Additive" }, "Outline style" )

    local p = ultimate.itemPanel("World",3,175):GetItemPanel()

    ultimate.ui.TextEntry( "Skybox texture", "Custom sky", p, 420 )
    ultimate.ui.CheckBox( p, "Sky color", "Sky color", false, false, true )
    ultimate.ui.CheckBox( p, "Wall color", "Wall color", false, false, true )
    ultimate.ui.CheckBox( p, "Bullet tracers", "Bullet tracers", false, false, true, ultimate.spfuncs[18] )
    ultimate.ui.CheckBox( p, "Fullbright", "Fullbright", false, true )

    local p = ultimate.itemPanel("View",3,100):GetItemPanel()

    ultimate.ui.CheckBox( p, "Third person", "Third person", false, true, false, ultimate.spfuncs[20] )
    ultimate.ui.CheckBox( p, "Free camera", "Free camera", false, true, false, ultimate.spfuncs[21] )


end

ultimate.spfuncs[25] = function()
    ultimate.ui.SettingsPan:SetSize(250,256)

    ultimate.ui.ComboBox( ultimate.ui.SettingsPan, "Strafe mode", {"Legit","Rage","Multidir"}, "Strafe mode")
    ultimate.ui.CheckBox( ultimate.ui.SettingsPan, "Ground strafer", "Ground strafer" )
    ultimate.ui.CheckBox( ultimate.ui.SettingsPan, "Sin ( snake ) strafe", "Z Hop", false, true )
end

ultimate.spfuncs[26] = function()
    ultimate.ui.SettingsPan:SetSize(250,256)

    ultimate.ui.Slider( ultimate.ui.SettingsPan, "Predict ticks", "CStrafe ticks", 16, 128, 0 )
    ultimate.ui.Slider( ultimate.ui.SettingsPan, "Angle step", "CStrafe angle step", 1, 10, 0 )
    ultimate.ui.Slider( ultimate.ui.SettingsPan, "Angle max step", "CStrafe angle max step", 5, 50, 0 )
    ultimate.ui.Slider( ultimate.ui.SettingsPan, "Ground diff", "CStrafe ground diff", 1, 65, 0 )
end

ultimate.spfuncs[27] = function( p )
    ultimate.ui.CheckBox( p, "Sequence manip", "Sequence manip", false, true )
    ultimate.ui.Slider( p, "Out Sequence", "OutSequence", 1, 5000, 0 )
    ultimate.ui.CheckBox( p, "Randomise", "Sequence min random" )
    ultimate.ui.Slider( p, "Min sequence", "Sequence min", 1, 5000, 0 )

    ultimate.ui.CheckBox( p, "Animation freezer", "Animation freezer", false, true )

    ultimate.ui.TextEntry( "Name", "Name Convar", p, 250 )
    ultimate.ui.Button( "Change name", function() ded.NetSetConVar("name",ultimate.cfg.vars["Name Convar"]) end, p )
    ultimate.ui.CheckBox( p, "Name stealer", "Name stealer" )

    ultimate.ui.TextEntry( "Disconnect reason", "Disconnect reason", p, 250 )
    ultimate.ui.Button( "Disconnect", function() ded.NetDisconnect(ultimate.cfg.vars["Disconnect reason"]) end, p )
end 

function ultimate.CustomCvarVal( net )
    local m = net == 1 and "Net Convar mode" or "Cvar mode"
    local n = net == 1 and "Net Convar int" or "Cvar int"
    local s = net == 1 and "Net Convar str" or "Cvar str"

    local mode = ultimate.cfg.vars[m] 
    local num = ultimate.cfg.vars[n]
    local set = mode == 2 and math_Round( num ) or num

    if mode == 1 then set = ultimate.cfg.vars[s] end

    return set
end

ultimate.spfuncs[28] = function( p )
    ultimate.ui.TextEntry( "Cvar name", "Net Convar", p, 250 )
    ultimate.ui.Slider( p, "Cvar int", "Net Convar int", 1, 100, 2 )
    ultimate.ui.TextEntry( "Cvar str", "Net Convar str", p, 250 )

    ultimate.ui.ComboBox( p, "Set mode", {"String","Int","Float"}, "Net Convar mode")

    ultimate.ui.Button( "Send new val", function() ded.NetSetConVar( ultimate.cfg.vars["Net Convar"] ,ultimate.CustomCvarVal( 1 ) ) end, p )
end 

ultimate.FCVAR = {
    str = {
        "Archive", "Archive XBOX", "Cheat", "Client can execute", "Client DLL", "Demo", "Dont record",
        "Game DLL", "Lua client", "Lua server", "Never as string", "None", "Notify", "Not connected",
        "Printable only", "Protected", "Replicated", "Server cannot query", "Server can execute",
        "Sponly", "Unlogged", "Unregistered", "Userinfo"
    },
    int = {
        128, 16777216, 16384, 1073741824, 8, 65536, 131072, 4, 262144, 524288, 4096, 0, 256, 4194304,
        1024, 32, 8192, 536870912, 268435456, 64, 2048, 1, 512
    }
}

ultimate.spfuncs[29] = function( p )
    ultimate.ui.TextEntry( "Enter cvar name", "Cvar name", p, 500 )
    ultimate.ui.Slider( p, "Custom number", "Cvar int", 1, 1000, 2 )
    ultimate.ui.TextEntry( "Custom string", "Cvar str", p, 500 )

    ultimate.ui.ComboBox( p, "Cvar mode", {"String","Int","Float"}, "Cvar mode")
    
    ultimate.ui.Button( "Change cvar", function()
        local s = ultimate.CustomCvarVal( 0 )
        local n = ultimate.cfg.vars["Cvar name"]
        
        local flag = GetConVar(n):GetFlags()

        ded.ConVarSetFlags( n, 0 )

        RunConsoleCommand( n, s )

        ded.ConVarSetFlags( n, flag )
    end, p )

    ultimate.ui.ComboBox( p, "Cvar flag", ultimate.FCVAR.str, "Cvar flag")

    ultimate.ui.Button( "Change flag", function()
        ded.ConVarSetFlags( ultimate.cfg.vars["Cvar name"], ultimate.FCVAR.int[ ultimate.cfg.vars["Cvar flag"] ] )
        print( ultimate.cfg.vars["Cvar name"], ultimate.FCVAR.int[ ultimate.cfg.vars["Cvar flag"] ] )
    end, p )

end 

function ultimate.tabs.Misc()

    local function func( p )
        ultimate.ui.MTButton( p, "Cvar", ultimate.spfuncs[29] )
        ultimate.ui.MTButton( p, "Net cvar", ultimate.spfuncs[28] )
        ultimate.ui.MTButton( p, "Net", ultimate.spfuncs[27] )
    end

    local p = ultimate.itemPanel("Movement",1,210):GetItemPanel()

    ultimate.ui.CheckBox( p, "Bunny hop", "Bhop" )
    ultimate.ui.CheckBox( p, "Air strafer", "Air strafer", false, false, false, ultimate.spfuncs[25] )
    ultimate.ui.CheckBox( p, "Circle strafe", "Circle strafe", false, true, false, ultimate.spfuncs[26] )
    ultimate.ui.CheckBox( p, "Keep sprint", "Sprint" )
    ultimate.ui.CheckBox( p, "Fast stop", "Fast stop" )
    ultimate.ui.CheckBox( p, "Auto peak", "Auto peak", false, true )
    ultimate.ui.CheckBox( p, "Auto teleport back", "Auto peak tp" )
    ultimate.ui.CheckBox( p, "Water walk", "Water jump" )


    
    local p = ultimate.itemPanel("Chat spam",2,100):GetItemPanel()

    ultimate.ui.CheckBox( p, "Killsay", "Killsay" )
    ultimate.ui.CheckBox( p, "Spam", "Chat spammer" )

 local p = ultimate.itemPanel( "Hitmarker", 2, 215 ):GetItemPanel()

    ultimate.ui.CheckBox( p, "Hitmarker", "Hitmarker", false, false, true )
    ultimate.ui.CheckBox( p, "Hitnumbers", "Hitnumbers", false, false, true, false, false, function(p) ultimate.ui.ColorPicker( "Hitnumbers krit", p ) end )
    //ultimate.ui.CheckBox( p, "Hit particles", "Hit particles", false, false, true, ultimate.spfuncs[31] )
    ultimate.ui.CheckBox( p, "Hitsound", "Hitsound" )
    ultimate.ui.TextEntry( "Sound path", "Hitsound str", p, 420 )
    ultimate.ui.CheckBox( p, "Killsound", "Killsound" )
    ultimate.ui.TextEntry( "Sound path", "Killsound str", p, 420 )

    //ultimate.ui.ComboBox( p, "Spam mode", {"Русский сборник сказок","Rage","Multidir"}, "Spam mode")

    ultimate.itemPanelB( "Net / Cvar", 3, 345, func )


end



function ultimate.tabs.Settings()
    local p = ultimate.itemPanel("Config",1,200):GetItemPanel()

    ultimate.ui.TextEntry( "Config name", "Config name", p, 64 )

    ultimate.ui.ComboBox( p, "Config", ultimate.configs, "Selected config")

    ultimate.ui.Button( "Save config", function() ultimate.SaveConfig() end, p )
    ultimate.ui.Button( "Load config", function() ultimate.LoadConfig() end, p )

    //ultimate.ui.Label( p, "Menu color", function( p ) ultimate.ui.ColorPicker( "Menu color", p, ultimate.updateMenuColor ) end )
end


ultimate.ttable = {}

ultimate.ttable["Aimbot"] = ultimate.tabs.Aimbot
ultimate.ttable["Rage"] = ultimate.tabs.Rage
ultimate.ttable["Visuals"] = ultimate.tabs.Visuals
ultimate.ttable["Misc"] = ultimate.tabs.Misc
ultimate.ttable["Settings"] = ultimate.tabs.Settings

function ultimate.initTab(tab)
    if ultimate.scrollpanel != nil then ultimate.scrollpanel:Remove() end

    ultimate.scrollpanel = vgui_Create("UScroll",ultimate.frame)

    ultimate.pty = { 5, 5, 5 }
    // ultimate.ESPPP:Hide()
    ultimate.ttable[tostring(tab)]()
end

function ultimate.tabButton(tab,par) 
    surface_SetFont("tbfont")
    local w, h = surface_GetTextSize(tab)

    local fw = w + 35

    local tx, ty = fw/2 - w/2, 25/2-h/2 - 1

    local b = par:Add("DButton")
    b:Dock(LEFT)
    b:DockMargin(2,0,2,1)
    b:SetWide(fw)
    b:SetText("")
    
    function b:DoClick()
        ultimate.activetab = tab
        ultimate.initTab(tab)
    end

    function b:Paint(width,height)
        if ultimate.activetab == tab or self:OnDepressed() then
            surface_SetDrawColor(ultimate.Colors[54])
            surface_SetTextColor(245,245,245,255)
        elseif self:IsHovered() then
            surface_SetDrawColor(ultimate.Colors[40])
            surface_SetTextColor(225,225,225,255)
        else
            surface_SetDrawColor(ultimate.Colors[30])
            surface_SetTextColor(200,200,200,255)
        end
        
        surface_DrawRect(0,0,width,height)

        surface_SetFont("tbfont")
        surface_SetTextPos(tx,ty)
        surface_DrawText(tab)
    end
end

ultimate.tabButton("Aimbot",ultimate.frame:GetTopPanel()) 
ultimate.tabButton("Rage",ultimate.frame:GetTopPanel()) 
ultimate.tabButton("Visuals",ultimate.frame:GetTopPanel()) 
ultimate.tabButton("Misc",ultimate.frame:GetTopPanel()) 
ultimate.tabButton("Settings",ultimate.frame:GetTopPanel()) 

ultimate.ttable["Aimbot"]()

// Input 

function ultimate.IsKeyDown( key )
    if key >= 107 then
        return input_IsMouseDown( key )
    end

    return input_IsKeyDown( key )
end

function ultimate.IsMovementKeysDown( cmd )

    if cmd:KeyDown( IN_MOVERIGHT ) then
        return true 
    end 
    
    if cmd:KeyDown( IN_MOVELEFT ) then
        return true 
    end 

    if cmd:KeyDown( IN_FORWARD ) then
        return true 
    end 

    if cmd:KeyDown( IN_BACK ) then
        return true 
    end 

    return false
end

// CreateMove start
local traceStruct = {
	mask = MASK_SHOT,
	filter = me
}

do 
    local maxshift = GetConVar("sv_maxusrcmdprocessticks"):GetInt() - 1
    local tickrate = tostring(math_Round(1 / TickInterval))

	RunConsoleCommand("cl_cmdrate", tickrate)
	RunConsoleCommand("cl_updaterate", tickrate)

	RunConsoleCommand("cl_interp", "0")
	RunConsoleCommand("cl_interp_ratio", "0")

    ultimate.cfg.vars["Maximum Shift Ticks"] = maxshift
    ded.SetMaxShift(maxshift)


    ded.NetSetConVar("cl_interpolate","0")
    ded.NetSetConVar("cl_interp","0")
end

ultimate.target = nil
ultimate.targetVector = Vector(0,0,0)
ultimate.extrapolatedVector = Vector(0,0,0)
ultimate.targetBacktrack = Vector(0,0,0)
ultimate.targetAngle = Angle(0,0,0)
ultimate.targetFOV = 360
ultimate.targetHealth = 100
ultimate.targetDistance = 1337

ultimate.visualAimPos = Vector(0,0,0)

ultimate.fa = me:EyeAngles()
ultimate.silentAnglePos = me:EyePos()
ultimate.nextTick = false
ultimate.bsendpacket = true

ultimate.badSweps = {
    ["gmod_camera"] = true,
	["manhack_welder"] = true,
	["weapon_medkit"] = true,
	["gmod_tool"] = true,
	["weapon_physgun"] = true,
	["weapon_physcannon"] = true,
	["weapon_bugbait"] = true,
}

ultimate.badSeqs = {
	[ACT_VM_RELOAD] = true,
	[ACT_VM_RELOAD_SILENCED] = true,
	[ACT_VM_RELOAD_DEPLOYED] = true,
	[ACT_VM_RELOAD_IDLE] = true,
	[ACT_VM_RELOAD_EMPTY] = true,
	[ACT_VM_RELOADEMPTY] = true,
	[ACT_VM_RELOAD_M203] = true,
	[ACT_VM_RELOAD_INSERT] = true,
	[ACT_VM_RELOAD_INSERT_PULL] = true,
	[ACT_VM_RELOAD_END] = true,
	[ACT_VM_RELOAD_END_EMPTY] = true,
	[ACT_VM_RELOAD_INSERT_EMPTY] = true,
	[ACT_VM_RELOAD2] = true
}

ultimate.cones = {};
ultimate.nullVec = Vector() * -1;

function ultimate.AutoWall(dir, plyTarget)
	local weap = me:GetActiveWeapon()
	if !IsValid(weap) then return false end
	local class = weap:GetClass()
    if class == "swb_knife" or class == "swb_knife_m" then return false end

	local eyePos = me:EyePos()
	
	local function SWBAutowall()
		local normalmask = bor(CONTENTS_SOLID, CONTENTS_OPAQUE, CONTENTS_MOVEABLE, CONTENTS_DEBRIS, CONTENTS_MONSTER, CONTENTS_HITBOX, 402653442, CONTENTS_WATER)
		local wallmask = bor(CONTENTS_TESTFOGVOLUME, CONTENTS_EMPTY, CONTENTS_MONSTER, CONTENTS_HITBOX)
		local penMod = {[MAT_SAND] = 0.5, [MAT_DIRT] = 0.8, [MAT_METAL] = 1.1, [MAT_TILE] = 0.9, [MAT_WOOD] = 1.2}
		
		
		local tr = TraceLine({
			start = eyePos,
			endpos = eyePos + dir * weap.PenetrativeRange,
			filter = me,
			mask = normalmask
		})
		
		if tr.Hit and !tr.HitSky then
			local dot = -dir:Dot(tr.HitNormal)
			
			if weap.CanPenetrate and dot > 0.26 then
				tr = TraceLine({
					start = tr.HitPos,
					endpos = tr.HitPos + dir * weap.PenStr * (penMod[tr.MatType] or 1) * weap.PenMod,
					filter = me,
					mask = wallmask
				})
				
				tr = TraceLine({
					start = tr.HitPos,
					endpos = tr.HitPos + dir * 0.1,
					filter = me,
					mask = normalmask
				}) -- run ANOTHER trace to check whether we've penetrated a surface or not
				
				if tr.Hit then return false end
				
				-- FireBullets
				tr = TraceLine({
					start = tr.HitPos,
					endpos = tr.HitPos + dir * 32768,
					filter = me,
					mask = MASK_SHOT
				})
				
				return tr.Entity == plyTarget
			end
		end
		
		return false
	end
	
	local function M9KAutowall()
		if !weap.Penetration then
			return false
		end

		local function BulletPenetrate(tr, bounceNum, damage)
			if damage < 1 then
				return false
			end
			
			local maxPenetration = 14
			if weap.Primary.Ammo == "SniperPenetratedRound" then -- .50 Ammo
				maxPenetration = 20
			elseif weap.Primary.Ammo == "pistol" then -- pistols
				maxPenetration = 9
			elseif weap.Primary.Ammo == "357" then -- revolvers with big ass bullets
				maxPenetration = 12
			elseif weap.Primary.Ammo == "smg1" then -- smgs
				maxPenetration = 14
			elseif weap.Primary.Ammo == "ar2" then -- assault rifles
				maxPenetration = 16
			elseif weap.Primary.Ammo == "buckshot" then -- shotguns
				maxPenetration = 5
			elseif weap.Primary.Ammo == "slam" then -- secondary shotguns
				maxPenetration = 5
			elseif weap.Primary.Ammo == "AirboatGun" then -- metal piercing shotgun pellet
				maxPenetration = 17
			end

			local isRicochet = false
			if weap.Primary.Ammo == "pistol" or weap.Primary.Ammo == "buckshot" or weap.Primary.Ammo == "slam" then
				isRicochet = true
			else
				/*
				TODO: Predict ricochetCoin?
				if weap.RicochetCoin == 1 then
					isRicochet = true
				elseif weap.RicochetCoin >= 2 then
					isRicochet = false
				end*/
			end

			if weap.Primary.Ammo == "SniperPenetratedRound" then
				isRicochet = true
			end

			local maxRicochet = 0
			if weap.Primary.Ammo == "SniperPenetratedRound" then -- .50 Ammo
				maxRicochet = 10
			elseif weap.Primary.Ammo == "pistol" then -- pistols
				maxRicochet = 2
			elseif weap.Primary.Ammo == "357" then -- revolvers with big ass bullets
				maxRicochet = 5
			elseif weap.Primary.Ammo == "smg1" then -- smgs
				maxRicochet = 4
			elseif weap.Primary.Ammo == "ar2" then -- assault rifles
				maxRicochet = 5
			elseif weap.Primary.Ammo == "buckshot" then -- shotguns
				maxRicochet = 0
			elseif weap.Primary.Ammo == "slam" then -- secondary shotguns
				maxRicochet = 0
			elseif weap.Primary.Ammo == "AirboatGun" then -- metal piercing shotgun pellet
				maxRicochet = 8
			end

			if tr.MatType == MAT_METAL and isRicochet and weap.Primary.Ammo != "SniperPenetratedRound" then
				return false
			end

			if bounceNum > maxRicochet then
				return false
			end

			local penetrationDir = tr.Normal * maxPenetration
			if tr.MatType == MAT_GLASS or tr.MatType == MAT_PLASTIC or tr.MatType == MAT_WOOD or tr.MatType == MAT_FLESH or tr.MatType == MAT_ALIENFLESH then
				penetrationDir = tr.Normal * (maxPenetration * 2) -- WAS 200
			end

			if tr.Fraction <= 0 then
				return false
			end

			local trace = {}
			trace.endpos = tr.HitPos
			trace.start = tr.HitPos + penetrationDir
			trace.mask = MASK_SHOT
			trace.filter = me

			local trace = TraceLine(trace)

			if trace.StartSolid or trace.Fraction >= 1 then
				return false
			end

			local penTrace = {}
			penTrace.endpos = trace.HitPos + tr.Normal * 32768
			penTrace.start = trace.HitPos
			penTrace.mask = MASK_SHOT
			penTrace.filter = me

			penTrace = TraceLine(penTrace)

			if penTrace.Entity == plyTarget then return true end

			local damageMulti = 0.5
			if weap.Primary.Ammo == "SniperPenetratedRound" then
				damageMulti = 1
			elseif tr.MatType == MAT_CONCRETE or tr.MatType == MAT_METAL then
				damageMulti = 0.3
			elseif tr.MatType == MAT_WOOD or tr.MatType == MAT_PLASTIC or tr.MatType == MAT_GLASS then
				damageMulti = 0.8
			elseif tr.MatType == MAT_FLESH or tr.MatType == MAT_ALIENFLESH then
				damageMulti = 0.9
			end
			
			if penTrace.MatType == MAT_GLASS then
				bounceNum = bounceNum - 1
			end

			return BulletPenetrate(penTrace, bounceNum + 1, damage * damageMulti)
		end

		local trace = TraceLine({
			start = eyePos,
			endpos = eyePos + dir * 32768,
			filter = me,
			mask = MASK_SHOT
		})

		return BulletPenetrate(trace, 0, weap.Primary.Damage)
	end
	
    if StartsWith(class,"m9k_") then
		return M9KAutowall()
	elseif StartsWith(class,"swb_") then
		return SWBAutowall()
	end
	
	return false
end

// Hitbox selection

ultimate.parsedbones = {}

function ultimate.ParseBones( ply, bone )
    local mdl = ply:GetModel()

    if ultimate.parsedbones[ mdl ] and ultimate.parsedbones[ mdl ][ bone ] then 
        return ultimate.parsedbones[ mdl ][ bone ]
    end

    if not ultimate.parsedbones[ mdl ] then
        ultimate.parsedbones[ mdl ] = {}
    end
        
    local set = ply:GetHitboxSet()
    local bonecount = ply:GetBoneCount()

    for i = 0, bonecount - 1 do 
		local group = ply:GetHitBoxHitGroup( i, set )

        if group == nil then continue end

		if bone == group then
			ultimate.parsedbones[ mdl ][ bone ] = i

            return i
        end
	end

    for i = 0, bonecount - 1 do 
        local group = ply:GetHitBoxHitGroup( i, set )

        if group == nil then continue end

        if bone > 1 and group == 0 then
            ultimate.parsedbones[ mdl ][ bone ] = i

            return i
        end
    end


    return 0
end

function ultimate.GetBones( ply )
    local scale = ultimate.cfg.vars["Multipoint scale"]
    local bone = ultimate.ParseBones( ply, ultimate.cfg.vars["Hitbox selection"] ) 

    local pos = ply:LocalToWorld( ply:OBBCenter() )
    local set = ply:GetHitboxSet()

    local hitboxbone = ply:GetHitBoxBone( bone, set )

    if hitboxbone == nil then 
        return { pos }  
    end 

    local mins, maxs = ply:GetHitBoxBounds( bone, set )

    if not mins or not maxs then 
        return { pos } 
    end 

    local bonepos, ang = ply:GetBonePosition( hitboxbone )  

    if ultimate.cfg.vars["Multipoint"] then
        local points = {
            ( ( mins + maxs ) * 0.5 ),
            Vector( mins.x, mins.y, mins.z ),
            Vector( mins.x, maxs.y, mins.z ),
            Vector( maxs.x, maxs.y, mins.z ),
            Vector( maxs.x, mins.y, mins.z ),
            Vector( maxs.x, maxs.y, maxs.z ),
            Vector( mins.x, maxs.y, maxs.z ),
            Vector( mins.x, mins.y, maxs.z ),
            Vector( maxs.x, mins.y, maxs.z )
        }

        for i = 1, #points do
            points[ i ]:Rotate( ang )
            points[ i ] = points[ i ] + bonepos

            if i == 1 then continue end 

            points[ i ] = ( ( points[ i ] - points[1] ) * scale ) + points[ 1 ]
        end

        return points
    else 
        mins:Rotate( ang )
        maxs:Rotate( ang )

        pos = bonepos + ( ( mins + maxs ) * 0.5 )
    end

    return { pos }
end

// Visible check

local tr = {
	mask = MASK_SHOT,
	filter = me
}

function ultimate.VisibleCheck( who, where, predticks, awalldir )
    local start = me:EyePos()

    if predticks then
        start = start + ( me:GetVelocity() * TickInterval ) * predticks
    end

    tr.start = start
	tr.endpos = where
	tr.mask = MASK_SHOT

    local trace = TraceLine( tr )

    local canhit = trace.Entity == who or trace.Fraction == 1

    if !canhit and awalldir and ultimate.cfg.vars["Wallz"] then 
        return ultimate.AutoWall(awalldir, who)
    end

    if ultimate.cfg.vars["Ignores-Head unhitable"] and trace.HitGroup != 1 then return false end

    return canhit
end

// Target selection







































function ultimate.MovementFix( cmd, wish_yaw )

	local pitch = math_NormalizeAngle( cmd:GetViewAngles().x )
	local inverted = -1
	
	if ( pitch > 89 || pitch < -89 ) then
		inverted = 1
	end

	local ang_diff = math_rad( math_NormalizeAngle( ( cmd:GetViewAngles().y - wish_yaw )*inverted ) )

	local forwardmove = cmd:GetForwardMove()
	local sidemove = cmd:GetSideMove()

	local new_forwardmove = forwardmove*-math_cos( ang_diff )*inverted + sidemove*math_sin( ang_diff )
	local new_sidemove = forwardmove*math_sin( ang_diff )*inverted + sidemove*math_cos( ang_diff )

	cmd:SetForwardMove( new_forwardmove )
	cmd:SetSideMove( new_sidemove )
	
end

function ultimate.SilentAngles(cmd)
	if !ultimate.fa then ultimate.fa = cmd:GetViewAngles() end
	ultimate.fa = ultimate.fa + Angle(cmd:GetMouseY() * GetConVarNumber("m_yaw"), cmd:GetMouseX() * -GetConVarNumber("m_yaw"), 0)
	ultimate.fa.p = math_Clamp(ultimate.fa.p, -89, 89)
    ultimate.fa.r = 0
    ultimate.fa:Normalize()
end

function ultimate.CanShoot(cmd)
	local weap = me:GetActiveWeapon()
	if !IsValid(weap) then return false end
	local wact = weap:GetSequence()

    if ultimate.cfg.vars["Aim on key"] and not ultimate.IsKeyDown(ultimate.cfg.binds["Aim on key"]) then
        return false
    end

	if ultimate.badSweps[weap:GetClass()] then
		return false
	end

    if me:GetMoveType() == MOVETYPE_NOCLIP then
        return false
    end

    if ultimate.cfg.vars["Auto fire"] and cmd:KeyDown(IN_ATTACK) then
        return false
    end

	if ultimate.cfg.vars["Bullet time"] and weap:GetNextPrimaryFire() >= ded.GetServerTime(cmd) then
		return false
	end

	return weap:Clip1() != 0 and !ultimate.badSeqs[wact] 
end 

GAMEMODE["EntityFireBullets"] = function(self, p, data) 
    local w = me:GetActiveWeapon()
    local spread = data.Spread * -1
    if !w or !IsValid(w) then return end

	if ultimate.cones[w:GetClass()] == spread or spread == ultimate.nullVec then return end
    ultimate.cones[w:GetClass()] = spread;
end

function ultimate.Spread(cmd,ang,spread)
	local w = me:GetActiveWeapon()
	local class = w:GetClass()

	if (!w || !w:IsValid() || !ultimate.cones[w:GetClass()]) then return ang end


	local dir = ded.PredictSpread(cmd, ang, spread)
	local newangle = ang + dir:Angle()
	newangle:Normalize()

	return newangle
end

function ultimate.NoRecoil(ang)  
	local w = me:GetActiveWeapon()
	local c = w:GetClass()

	if StartsWith(c,"m9k_") or StartsWith(c,"bb_") or StartsWith(c,"unclen8_") then
		return ang
	else
	    ang = ang - me:GetViewPunchAngles()
    end

	return ang
end

do
      function ultimate.NoSpread(cmd, ang)
        local w = me:GetActiveWeapon()
        local class = w:GetClass()
    
        if !IsValid(w) then 
            return ang
        end
    
        if class == "swb_knife" or class == "swb_knife_m" then return ang end
    
        if StartsWith(class,"swb_") then
            local function CalculateSpread()
                local vel = me:GetVelocity():Length()
                local dir = ang:Forward()
                
                if !me.LastView then
                    me.LastView = dir
                    me.ViewAff = 0
                else
                    me.ViewAff = Lerp(0.25, me.ViewAff, (dir - me.LastView):Length() * 0.5)
                    --  me.LastView = dir
                end
                
                if IsValid(w.dt) and IsValid(w.meSpread) and w.dt.State == SWB_AIMING then
                    w.BaseCone = w.meSpread
                    
                    if w.Owner.Expertise then
                        w.BaseCone = w.BaseCone * (1 - w.Owner.Expertise["steadyme"].val * 0.0015)
                    end
                else
                    w.BaseCone = w.HipSpread
                    
                    if w.Owner.Expertise then
                        w.BaseCone = w.BaseCone * (1 - w.Owner.Expertise["wepprof"].val * 0.0015)
                    end
                end
                
                if me:Crouching() then
                    w.BaseCone = w.BaseCone * (w.dt.State == SWB_AIMING and 0.9 or 0.75)
                end
                
                w.CurCone = math_Clamp(w.BaseCone + w.AddSpread + (vel / 10000 * w.VelocitySensitivity) * (w.dt.State == SWB_AIMING and w.meMobilitySpreadMod or 1) + me.ViewAff, 0, 0.09 + w.MaxSpreadInc)
                
                if CurTime() > w.SpreadWait then
                    w.AddSpread = math_Clamp(w.AddSpread - 0.005 * w.AddSpreadSpeed, 0, w.MaxSpreadInc)
                    w.AddSpreadSpeed = math_Clamp(w.AddSpreadSpeed + 0.05, 0, 1)
                end
            end
            
            CalculateSpread()
            
            local cone = w.CurCone
            if !cone then return ang end
    
            if me:Crouching() then
                cone = cone * 0.85
            end
    
            math.randomseed(cmd:CommandNumber())
            ang = ang - Angle(math_Rand(-cone, cone), math_Rand(-cone, cone), 0) * 25
        elseif StartsWith(class,"cw_") then
            local cone = w.CurCone
            if !cone then return ang end

            math.randomseed(cmd:CommandNumber())
            ang = ang - Angle(math_Rand(-cone, cone), math_Rand(-cone, cone), 0) * 25
        elseif StartsWith(class,"fas2_") then
            math.randomseed(CurTime())
            dir = Angle(math.Rand(-w.CurCone, w.CurCone), math.Rand(-w.CurCone, w.CurCone), 0) * 25
    
            dir2 = dir 
                    
            if w.ClumpSpread and w.ClumpSpread > 0 then
                dir2 = dir + Vector(math.Rand(-1, 1), math.Rand(-1, 1), math.Rand(-1, 1)) * w.ClumpSpread
            end
    
            ang = ang - dir2
        elseif StartsWith(class,"arccw_") then
            local dir = ang:Forward()
    
            local seed1 = w:GetBurstCount()
            local seed2 = !game.SinglePlayer() and cmd:CommandNumber() or CurTime()
            
            local randSeed = util.SharedRandom(seed1, -1337, 1337, seed2) * (w:EntIndex() % 30241)
            math.randomseed(math.Round(randSeed))
            
            local spread = ArcCW.MOAToAcc * w:GetBuff("AccuracyMOA")
            local disp = w:GetDispersion() * ArcCW.MOAToAcc / 10

            w:ApplyRandomSpread(dir, disp)

            local dirry = Vector(dir.x, dir.y, dir.z)

            local randSeed = util.SharedRandom(seed1, -1337, 1337, seed2) * (w:EntIndex() % 30241)
            math.randomseed(math.Round(randSeed))

            w:ApplyRandomSpread(dirry, spread)

            return (ang:Forward() - dirry):Angle()
        elseif ultimate.cones[class] then
            local spread = ultimate.cones[class]
            return ultimate.Spread(cmd, ang, spread)
        end
    
        return ang
    end
end




// Valid targets

function ultimate.GetSortedPlayers( mode, selfpred, plypred, vischeck )
    local players   = player_GetAll()   // all players
    local eyepos    = me:EyePos()       // i will call it multiple time so why not
    local valid     = {}                // sorted lady and gentleman goes here ( niggers and faggots goes to hell )

	if selfpred then
		eyepos = eyepos + (me:GetVelocity() * TickInterval) * selfpred
	end

    for i = 1, #players do
        local sus = players[i] 

        if sus == me then continue end 
        if not sus:Alive() or sus:IsDormant() then continue end 
        if ultimate.cfg.vars["Ignores-Bots"] and sus:IsBot() then continue end 
        if ultimate.cfg.vars["Ignores-Friends"] and ultimate.cfg.friends[sus:SteamID64()] then continue end 
        if ultimate.cfg.vars["Ignores-Steam friends"] and sus:GetFriendStatus() == "friend" then continue end 
        if ultimate.cfg.vars["Ignores-Admins"] and sus:IsAdmin() then continue end 
        if ultimate.cfg.vars["Ignores-Frozen"] and sus:IsFlagSet( FL_FROZEN ) then continue end 
        if ultimate.cfg.vars["Ignores-Nodraw"] and sus:IsEffectActive( EF_NODRAW ) then continue end 
        if ultimate.cfg.vars["Ignores-God time"] and (tobool(sus:GetNWBool("LibbyProtectedSpawn")) or tobool(sus:GetNWBool("_Kyle_Buildmode"))  or sus:HasGodMode()) then continue end 
        if ultimate.cfg.vars["Ignores-Driver"] and sus:InVehicle() then continue end 


        local st = sus:Team()

        if st == TEAM_SPECTATOR or ultimate.cfg.vars["Ignores-Teammates"] and st == me:Team() then continue end 
        if ultimate.cfg.vars["Ignores-Nocliping"] and sus:IsEFlagSet(EFL_NOCLIP_ACTIVE) then continue end 

        if vischeck then
			local bone = ultimate.GetBones( sus )[1]
			local dir = me:GetShootPos() - bone
			dir:Normalize()

			if !ultimate.VisibleCheck( sus, bone, selfpred, dir ) then
				continue
			end
		end

        local pos = sus:GetPos()
        if plypred then 
            pos = pos + (sus:GetVelocity() * TickInterval) * plypred
        end

        valid[#valid+1] = { sus, pos }
    end

    if mode == 1 then
        table_sort(valid, function( a, b )
            return ( a[2] - eyepos ):LengthSqr() < ( b[2] - eyepos ):LengthSqr()       
        end)
    elseif mode == 2 then
        table_sort(valid, function( a, b )
            local aScr, bScr = a[2]:ToScreen(), b[2]:ToScreen()

            local aDist
            do
                local dx = scrwc - aScr.x
                local dy = scrhc - aScr.y
                aDist = dx * dx + dy * dy
            end
    
            local bDist
            do
                local dx = scrwc - bScr.x
                local dy = scrhc - bScr.y
                bDist = dx * dx + dy * dy
            end
    
            return aDist < bDist
        end)
    end

    if #valid == 0 then return end

    return valid
end

// Aimbot target

function ultimate.IsTickHittable( ply, cmd, tick )
    local correct = ded.GetLatency(0)

    correct = correct
    --print(correct)

    if correct > 1 then return false end


    local serverArriveTick = ded.GetServerTime(cmd) + ded.GetLatency(0) + ded.GetLatency(1)
    local diff = serverArriveTick - ultimate.btrecords[ply][tick].simulationtime

    if diff > ultimate.cfg.vars["Backtrack time"] / 1000 then return false end

    return true
end

function ultimate.FindFirstHittableTicks( ply, cmd )
    local tickcount = #ultimate.btrecords[ply]

    if !tickcount then return 1 end

    for i = 1, tickcount do
        if ultimate.IsTickHittable( ply, cmd, i ) then
            return i
        end
    end
end

do
    local lastdist, lasttick = 1337, 1

    function ultimate.FindClosestHittableTicks( ply, cmd )
        local mypos = me:EyePos()
        local records = ultimate.btrecords[ply]
        local firstticks = ultimate.FindFirstHittableTicks( ply, cmd )
        local tickcount = #records

        if !tickcount or !firstticks then return 1 end

        lastdist = math_huge
    
        for i = 1, tickcount - firstticks do
            local mt = i + firstticks

            if (records[mt].aimpos):DistToSqr(mypos) < lastdist then
                lastdist = (records[mt].aimpos):DistToSqr(mypos)
                lasttick = mt
            end
        end

        return lasttick
    end
end

ultimate.backtracktick = 0
function ultimate.SelectTarget(cmd)
    ultimate.target = nil 
    ultimate.targetVector = nil 
    ultimate.targetAngle = nil

    local plys = ultimate.GetSortedPlayers( ultimate.cfg.vars["Target selection"] )

    if !plys then return end 

    for i = 1, #plys do
		local ply = plys[i][1]

        if not ultimate.cfg.vars["Always backtrack"] then
            local bones = ultimate.GetBones( ply )

            for o = 1, #bones do
                local bone = bones[o]
                local aimAng = (bone - me:EyePos()):Angle()

                if ultimate.VisibleCheck( ply, bone, nil, aimAng:Forward() ) then 
                    return ply, bone, aimAng, false, 0
                end
            end
        end

		


        if ultimate.cfg.vars["Backtrack"] then
            local tick = ultimate.FindFirstHittableTicks( ply, cmd )

            if ultimate.cfg.vars["Backtrack mode"] == 2 then
                tick = ultimate.FindClosestHittableTicks( ply, cmd )
            end

            ultimate.backtracktick = tick

            if ultimate.btrecords[ply] and ultimate.btrecords[ply][tick] and not ply.break_lc then 
                if ultimate.IsTickHittable( ply, cmd, tick ) then
                    aimAng = (ultimate.btrecords[ply][tick].aimpos - me:EyePos()):Angle()

                    local tr = TraceLine({
                        start = me:EyePos(),
                        endpos = ultimate.btrecords[ply][tick].aimpos,
                        filter = me,
                        mask = MASK_SHOT
                    })

                    if !tr.Hit or tr.Entity == ply then
                        ultimate.target = ply 
                        ultimate.targetVector = ultimate.btrecords[ply][tick].aimpos 
                        ultimate.targetAngle = aimang   

                        return ply, ultimate.btrecords[ply][tick].aimpos, aimAng, true, tick
                    end
                end
            end
        end
	end
end


















/*
function ultimate.SelectTarget()
    local newTarget = nil 
    local newTargetPos = Vector(0,0,0)
    local newtargetBacktrack = Vector(0,0,0)
    local newTargetAngle = Angle(0,0,0)
    local newTargetFOV = 360
    local newTargetHealth = math_huge
    local newTargetDistance = math_huge
    local predvec = Vector(0,0,0)

    for k, v in pairs(player.GetAll()) do
		if ultimate.ValidateTarget(v) then
            local aimVector = ultimate.getHitbox(v)

            local meAngle = (aimVector - me:EyePos()):Angle()

            if ultimate.cfg.vars["Aim at bt"] and ultimate.btrecords[v] and ultimate.btrecords[v][2] and ultimate.canBacktrack(v) and not ultimate.cfg.vars["Bt aim vis check"] then 
                local rec = ultimate.btrecords[v][2].aimpos 

                newtargetBacktrack = rec     
                meAngle = (newtargetBacktrack - me:EyePos()):Angle()
            end
   
            meAngle:Normalize()  

            local meFov = math_abs(math_NormalizeAngle(ultimate.fa.y - meAngle.y)) + math_abs(math_NormalizeAngle(ultimate.fa.p - meAngle.p))    

            if  == 1 then
                aimVector = ultimate.getHitbox(v)
                if (me:GetPos()):DistToSqr(v:GetPos()) < newTargetDistance then
                    newTarget = v
                    newTargetPos = aimVector
                    newTargetAngle = meAngle
                    newTargetDistance = (me:GetPos()):DistToSqr(v:GetPos())     
                end 
            elseif ultimate.cfg.vars["Target selection"] == 2 then
                aimVector = ultimate.getHitbox(v)
                if meFov < newTargetFOV then
                    newTarget = v
                    newTargetPos = aimVector
                    newTargetAngle = meAngle
                    newTargetFOV = meFov      
                end
            elseif ultimate.cfg.vars["Target selection"] == 3 then
                aimVector = ultimate.getHitbox(v)
                if v:Health() < newTargetHealth then
                    newTarget = v
                    newTargetPos = aimVector
                    newTargetAngle = meAngle
                    newTargetHealth = v:Health()      
                end  
            end

            if ultimate.canBacktrack(newTarget) and ultimate.btrecords[newTarget] and ultimate.btrecords[newTarget][2] and ultimate.cfg.vars["Aim at bt"] and ultimate.cfg.vars["Always backtrack"] or ( ultimate.cfg.vars["Bt aim vis check"] and ultimate.VisibleCheck(v,aimVector) ) then
                local rec = ultimate.btrecords[newTarget][2].aimpos 

                if ultimate.canHitBacktrack(newTarget,newTargetPos,rec) then

                    newtargetBacktrack = rec     
                    newTargetAngle = (newtargetBacktrack - me:EyePos()):Angle()
                    newTargetAngle:Normalize()  

                end
            end 


            --[[if ultimate.cfg.vars["Extrapolation"] then
                local flticks = ultimate.TIME_TO_TICKS(v.ult_cur_simtime-v.ult_prev_simtime)
                flticks = math_Clamp(flticks,1,24)

                local flvec = newTargetPos

                for i = 1,flticks do
                    flvec = flvec + v:GetVelocity() * TickInterval
                end
                
                local predictedVector = flvec
                ply.predvec = predictedVector
                local meAngle = (predictedVector - me:EyePos()):Angle()
                meAngle:Normalize()  
        
                newTargetAngle = meAngle
            end]]

        end
    end

    ultimate.visualAimPos = newTargetPos

    if ultimate.cfg.vars["Extrapolation"] and ultimate.target and ultimate.targetVector then
        local t = ultimate.target 

        if t.break_lc then
            local meAngle = (ultimate.extrapolatedVector - me:EyePos()):Angle()
            meAngle:Normalize()  

            newTargetAngle = meAngle

            ultimate.visualAimPos = ultimate.extrapolatedVector
        end
    end

    

    ultimate.target = newTarget
    ultimate.targetVector = newTargetPos
    ultimate.targetBacktrack = newtargetBacktrack
    ultimate.targetAngle = newTargetAngle
    ultimate.targetFOV = newTargetFOV
    ultimate.targetHealth = newTargetHealth
    ultimate.targetDistance = newTargetDistance
end
*/



function ultimate.TIME_TO_TICKS(time)
	return math_floor(0.5 + time / TickInterval)
end

function ultimate.TICKS_TO_TIME(ticks)
    return TickInterval * ticks
end

function ultimate.ROUND_TO_TICK(time)
    return ultimate.TICKS_TO_TIME(ultimate.TIME_TO_TICKS(time))
end

// Knife bot ( Etot zaichik knifer )

ultimate.knifes = {}

ultimate.knifes[1] = {
    str = "csgo_",

    canbackstab = true,

    leftdmg = 25,
    leftdmgb = 90,
    leftdist = 64*64,

    rightdmg = 65,
    rightdmgb = 180,
    rightdist = 48*48,
}

ultimate.knifes[2] = {
    str = "swb_",

    canbackstab = false,

    leftdmg = 10,
    leftdmgb = 10,
    leftdist = 50*50,

    rightdmg = 40,
    rightdmgb = 40,
    rightdist = 50*50,
}

ultimate.knifes[3] = {
    str = "weapon_crowba",

    canbackstab = false,

    leftdmg = 10,
    leftdmgb = 10,
    leftdist = 75*75,

    rightdmg = 10,
    rightdmgb = 10,
    rightdist = 75*75,
}

function ultimate:EntityFaceBack( ent )
    local angle = me:GetAngles().y - ent:GetAngles().y

    if angle < -180 then angle = 360 + angle end

    if angle <= 90 and angle >= -90 then return true end

    return false
end

function ultimate.CanStab( ent, pos, health )
    local mypos = me:GetShootPos()
    local tbl = ultimate.knifes[1]
    local wc = me:GetActiveWeapon():GetClass()
    local canuse = false 

    for i = 1, #ultimate.knifes do
        if StartsWith(wc,ultimate.knifes[i].str) then
            canuse = true 
            tbl = ultimate.knifes[i]
            break
        end
    end 

    if not canuse then return false, false end

    if ultimate.canBacktrack( ent ) and ultimate.btrecords[ent][ultimate.backtracktick] then
        pos = ultimate.btrecords[ ent ][ ultimate.backtracktick ].aimpos
    end

    local backstab = tbl.canbackstab and ultimate:EntityFaceBack( ent ) or false
    local dist = mypos:DistToSqr( pos )
    local mode = ultimate.cfg.vars["Knifebot mode"]
    
    if mode == 1 then // Damage mode - tries to inflict biggest possible damage
        if backstab and dist < tbl.rightdist then
            return true, true
        elseif dist < tbl.leftdist and ( ( backstab and health - tbl.leftdmgb <= 0 ) or ( health - tbl.leftdmg <= 0 ) ) then
            return true, false
        elseif dist < tbl.rightdist or  ( dist < tbl.rightdist and health - tbl.leftdmg > 0 )  then 
            return true, true
        end
    elseif mode == 2 then // Fast - tries to hit fast as possible
        if dist < tbl.rightdist then
            return true, true
        elseif dist < tbl.leftdist then
            return true, false
        end
    elseif mode == 3 then // Fatal - deals only fatal damage
        if dist < tbl.leftdist and ( ( backstab and health - tbl.leftdmgb <= 0 ) or ( health - tbl.leftdmg <= 0 ) ) then
            return true, false
        elseif dist < tbl.rightdist and ( ( backstab and health - tbl.rightdmgb <= 0 ) or ( health - tbl.rightdmg <= 0 ) ) then
            return true, true
        end
    end

    return false, false
end

function ultimate.simtimeCheck( v )
    if not ultimate.cfg.vars["Wait for simtime update"] then return true end

    local st = v.simtime_updated

    return st
end

function ultimate.Aim(cmd)
    ultimate.AntiAim(cmd)
    local ply, bone, aimang, backtracking, bttick = ultimate.SelectTarget(cmd)


    if not aimang then return end

    aimang:Normalize()  

    if not ultimate.cfg.vars["Enable aimbot"] or not ply then return end

    local oldangs = Angle(aimang)

    if ultimate.cfg.vars["Always backtrack"] and not backtracking then return end

    if not ultimate.CanShoot(cmd) or not ultimate.simtimeCheck( ply ) then return end
    if not ultimate.cfg.vars["Aimbot smoothing"] and ultimate.nextTick then return end

    if ultimate.cfg.vars["Fov limit"] then
        local fov = ultimate.cfg.vars["Aimbot FOV"]

		local view = ultimate.cfg.vars["Silent aim"] and ultimate.fa or cmd:GetViewAngles()
		local ang = aimang - view

		ang:Normalize()

		ang = math_sqrt(ang.x * ang.x + ang.y * ang.y)

        if ang > fov then
		    return 
        end
    end

    // Knife bot 
    local altfire = false
    local canstab, rightstab = ultimate.CanStab( ply, bone, ply:Health() )

    if ultimate.cfg.vars["Knifebot"] and canstab then
        altfire = rightstab
    elseif ultimate.cfg.vars["Knifebot"] and not canstab then
        return 
    end

    local oldAimAng = aimang
    local finalAngle = aimang

    if ultimate.cfg.vars["Norecoil"] then
        finalAngle = ultimate.NoRecoil(finalAngle)
    end



    if ultimate.cfg.vars["Nospread"] then
        finalAngle = ultimate.NoSpread(cmd,finalAngle)
    end

    if ultimate.cfg.vars["On shot aa"] then
        finalAngle.p = -finalAngle.p - 180
        finalAngle.y = finalAngle.y + 180
    end
    
    if ultimate.cfg.vars["Facestab"] then
        local angles = ply:EyeAngles()

        finalAngle.y = angles.y
        finalAngle.p = angles.p

        altfire = true
    end

    if ultimate.cfg.vars["Aimbot smoothing"] then
        local va = cmd:GetViewAngles()
        va.r = 0

        local rat = ultimate.cfg.vars["Smoothing"] * 100
        local ret = LerpAngle( FrameTime()*rat, va, finalAngle )
        
        finalAngle = ret
    end

    --ded.SetContextMenu( cmd, ultimate.cfg.vars["pSilent"] or ultimate.cfg.vars["Facestab"] )
    if ultimate.cfg.vars["Facestab"] then
        cmd:SetViewAngles( finalAngle )
        ded.SetContextVector( cmd, oldAimAng:Forward() )
    elseif ultimate.cfg.vars["pSilent"] then
        ded.SetContextVector( cmd, oldAimAng:Forward() )
    else
        cmd:SetViewAngles( finalAngle )
    end

    if backtracking then

        local targetTime = ultimate.btrecords[ply][bttick].simulationtime
        local timeOffset = ded.GetServerTime(cmd) - targetTime

        local serverArriveTick = ded.GetServerTime(cmd) + ded.GetLatency(0) + ded.GetLatency(1)
        local diff = serverArriveTick - ultimate.btrecords[ply][bttick].simulationtime

 

        ded.NetSetConVar("cl_interpolate","1")
        ded.NetSetConVar("cl_interp",tostring(ded.GetServerTime(cmd) - targetTime))
        ded.SetInterpolationAmount(ded.GetServerTime(cmd) - targetTime)

        local tick = ultimate.TIME_TO_TICKS(ded.GetServerTime(cmd))
        ded.SetCommandTick(cmd, tick - 1)

            
  
        print("backtracking")
    elseif ultimate.cfg.vars["Adjust tickcount"] then
        local t = ultimate.TIME_TO_TICKS(ded.GetSimulationTime(ply:EntIndex()))

        ded.NetSetConVar("cl_interpolate","0")
        ded.ConVarSetNumber("cl_interp","0")
        ded.ConVarSetNumber('cl_updaterate',1 / engine.TickInterval())
        ded.ConVarSetNumber('cl_cmdrate',1 / engine.TickInterval())
        ded.SetInterpolationAmount(0)

        ded.SetCommandTick(cmd, t)
    end

    if ultimate.cfg.vars["Auto fire"] then

        local w = me:GetActiveWeapon():GetClass()

        if StartsWith( w, "m9k_" ) then
            cmd:RemoveKey( IN_SPEED )
        end

        ultimate.bsendpacket = true
        me.simtime_updated = true
        ded.UpdateClientAnimation( me:EntIndex() )

        if ultimate.cfg.vars["Resolver"] then 
            ply.aimshots = (ply.aimshots or 0) + 1
        end

        cmd:AddKey( altfire and IN_ATTACK2 or IN_ATTACK ) 

        ultimate.nextTick = true 
    end
end

function ultimate.autoReload(cmd)
    if !ultimate.cfg.vars["Auto reload"] then return end

	local wep = me:GetActiveWeapon()

	if IsValid(wep) then
		if wep.Primary then
			if wep:Clip1() == 0 and wep:GetMaxClip1() > 0 and me:GetAmmoCount(wep:GetPrimaryAmmoType()) > 0 then
				cmd:AddKey(IN_RELOAD)
			end
		end
	end
end

// adaptive Cstrafe

ultimate.last_ground_pos = 0
ultimate.cstrafe_dir = 0

function ultimate.PredictVelocity( velocity, viewangles, dir, maxspeed, accel )

	local forward = viewangles:Forward()
	local right = viewangles:Right()
	
	local fmove = 0
	local smove = ( dir == 1 ) && -10000 || 10000
	
	forward.z = 0
	right.z = 0
	
	forward:Normalize()
	right:Normalize()

	local wishdir = Vector( forward.x*fmove + right.x*smove, forward.y*fmove + right.y*smove, 0 )
	local wishspeed = wishdir:Length()
	
	wishdir:Normalize()
	
	if ( wishspeed != 0 && wishspeed > maxspeed ) then
		wishspeed = maxspeed
	end
	
	local wishspd = wishspeed
	
	if ( wishspd > 30 ) then
		wishspd = 30
	end
	
	local currentspeed = velocity:Dot( wishdir )
	local addspeed = wishspd - currentspeed
	
	if ( addspeed <= 0 ) then
		return velocity
	end
	
	local accelspeed = accel * wishspeed * TickInterval
	
	if ( accelspeed > addspeed ) then
		accelspeed = addspeed
	end
	
	return velocity + ( wishdir * accelspeed )

end
    
function ultimate.PredictMovement( viewangles, dir, angle )

	local pm

	local sv_airaccelerate = GetConVarNumber( "sv_airaccelerate" )
	local sv_gravity = GetConVarNumber( "sv_gravity" )
	local maxspeed = me:GetMaxSpeed()
	local jump_power = me:GetJumpPower()

	local origin = me:GetNetworkOrigin()
	local velocity = me:GetAbsVelocity()
	
	local mins = me:OBBMins()
	local maxs = me:OBBMaxs()

    local pticks = math_Round(ultimate.cfg.vars["CStrafe ticks"])
	
	local on_ground = me:IsFlagSet( FL_ONGROUND )
	
	for i = 1, pticks do

		viewangles.y = math_NormalizeAngle( math_deg( math_atan2( velocity.y, velocity.x ) ) + angle )

		velocity.z = velocity.z - ( sv_gravity * TickInterval * 0.5 )

		if ( on_ground ) then
		
			velocity.z = jump_power
			velocity.z = velocity.z - ( sv_gravity * TickInterval * 0.5 )
			
		end

		velocity = ultimate.PredictVelocity( velocity, viewangles, dir, maxspeed, sv_airaccelerate )
		
		local endpos = origin + ( velocity * TickInterval )

		pm = TraceHull( {
			start = origin,
			endpos = endpos,
			filter = me,
			maxs = maxs,
			mins = mins,
			mask = MASK_PLAYERSOLID
		} )
		
		if ( ( pm.Fraction != 1 && pm.HitNormal.z <= 0.9 ) || pm.AllSolid || pm.StartSolid ) then
			return false
		end
		
		if ( pm.Fraction != 1 ) then
		
			local time_left = TickInterval

			for j = 1, 2 do
			
				time_left = time_left - ( time_left * pm.Fraction )

				local dot = velocity:Dot( pm.HitNormal )
				
				velocity = velocity - ( pm.HitNormal * dot )

				dot = velocity:Dot( pm.HitNormal )

				if ( dot < 0 ) then
					velocity = velocity - ( pm.HitNormal * dot )
				end

				endpos = pm.HitPos + ( velocity * time_left )

				pm = TraceHull( {
					start = pm.HitPos,
					endpos = endpos,
					filter = me,
					maxs = maxs,
					mins = mins,
					mask = MASK_PLAYERSOLID
				} )

				if ( pm.Fraction == 1 || pm.AllSolid || pm.StartSolid ) then
					break
				end
			
			end
			
		end
		
		origin = pm.HitPos
		
		if ( ( ultimate.last_ground_pos - origin.z ) > math_Round(ultimate.cfg.vars["CStrafe ground diff"]) ) then
			return false
		end
		
		pm = TraceHull( {
			start =  Vector( origin.x, origin.y, origin.z + 2 ),
			endpos = Vector( origin.x, origin.y, origin.z - 1 ),
			filter = me,
			maxs = Vector( maxs.x, maxs.y, maxs.z * 0.5 ),
			mins = mins,
			mask = MASK_PLAYERSOLID
		} )
		
		on_ground = ( ( pm.Fraction < 1 || pm.AllSolid || pm.StartSolid ) && pm.HitNormal.z >= 0.7 )
		
		velocity.z = velocity.z - ( sv_gravity * TickInterval * 0.5 )
		
		if ( on_ground ) then
			velocity.z = 0
		end


	end

	return true

end

function ultimate.CircleStrafe( cmd )

	local angle = 0
	
	while ( ultimate.cstrafe_dir < 2 ) do
	
		angle = 0
		local path_found = false
		local step = ( ultimate.cstrafe_dir == 1 ) && math_Round(ultimate.cfg.vars["CStrafe angle step"]) || -math_Round(ultimate.cfg.vars["CStrafe angle step"])
		
		while ( true ) do
		
			if ( ultimate.cstrafe_dir == 1 ) then
			
				if ( angle > math_Round(ultimate.cfg.vars["CStrafe angle max step"]) ) then
					break
				end
			
			else
			
				if ( angle < -math_Round(ultimate.cfg.vars["CStrafe angle max step"]) ) then
					break
				end
			
			end

			if ( ultimate.PredictMovement( cmd:GetViewAngles(), ultimate.cstrafe_dir, angle ) ) then
			
				path_found = true
				break
			
			end

			angle = angle + step
		
		end
		
		if ( path_found ) then
			break
		end
		
		ultimate.cstrafe_dir = ultimate.cstrafe_dir + 1
	
	end
	
	if ( ultimate.cstrafe_dir < 2 ) then
	
		local velocity = me:GetAbsVelocity()
		local viewangles = cmd:GetViewAngles()
		
		viewangles.y = math_NormalizeAngle( math_deg( math_atan2( velocity.y, velocity.x ) ) + angle )
		
		cmd:SetViewAngles( viewangles )
		cmd:SetSideMove( ( ultimate.cstrafe_dir == 1 ) && -10000 || 10000 )
	
	else
	
		ultimate.cstrafe_dir = 0
	
	end

end

do
    local ztick = 0
    local prev_yaw = 0
    local old_yaw = 0.0

    function ultimate.AutoStrafe( cmd )
        ztick = ztick + 1

        if ( ultimate.IsKeyDown(ultimate.cfg.binds["Circle strafe"]) and ultimate.cfg.vars["Circle strafe"] ) then
        
            ultimate.CircleStrafe( cmd )
    
        elseif ( ultimate.IsKeyDown(ultimate.cfg.binds["Z Hop"]) and ultimate.cfg.vars["Z Hop"] ) then
            local handler = ztick / 3.14
            
            cmd:SetSideMove( 5000 * math_sin(handler) )
        elseif ultimate.cfg.vars["Air strafer"] and ultimate.cfg.vars["Strafe mode"] == 3 then
    
            local get_velocity_degree = function(velocity)
                local tmp = math.deg(math.atan(30.0 / velocity))
                    
                if (tmp > 90.0) then
                    return 90.0
                elseif (tmp < 0.0) then
                    return 0.0
                else
                    return tmp
                end
            end
    
            local M_RADPI = 57.295779513082
            local side_speed = 10000
            local velocity = me:GetVelocity()
            velocity.z = 0.0
    
            local forwardmove = cmd:GetForwardMove()
            local sidemove = cmd:GetSideMove()
    
            if (!forwardmove || !sidemove) then
                return
            end
    
            if(velocity:Length2D() <= 15.0 && !(forwardmove != 0 || sidemove != 0)) then
                return
            end
    
            local flip = cmd:TickCount() % 2 == 0
    
            local turn_direction_modifier = flip && 1.0 || -1.0
            local viewangles = Angle(ultimate.fa.x, ultimate.fa.y, ultimate.fa.z)
    
            if (forwardmove || sidemove) then
                cmd:SetForwardMove(0)
                cmd:SetSideMove(0)
    
                local turn_angle = math.atan2(-sidemove, forwardmove)
                viewangles.y = viewangles.y + (turn_angle * M_RADPI)
            elseif (forwardmove) then
                cmd:SetForwardMove(0)
            end
    
            local strafe_angle = math.deg(math.atan(15 / velocity:Length2D()))
    
            if (strafe_angle > 90) then
                strafe_angle = 90
            elseif (strafe_angle < 0) then
                strafe_angle = 0
            end
    
            local temp = Vector(0, viewangles.y - old_yaw, 0)
            temp.y = math.NormalizeAngle(temp.y)
    
            local yaw_delta = temp.y
            old_yaw = viewangles.y
    
            local abs_yaw_delta = math.abs(yaw_delta)
    
            if (abs_yaw_delta <= strafe_angle || abs_yaw_delta >= 30) then
                local velocity_angles = velocity:Angle()
    
                temp = Vector(0, viewangles.y - velocity_angles.y, 0)
                temp.y = math.NormalizeAngle(temp.y)
    
                local velocityangle_yawdelta = temp.y
                local velocity_degree = get_velocity_degree(velocity:Length2D() * 128)
    
                if (velocityangle_yawdelta <= velocity_degree || velocity:Length2D() <= 15) then
                    if (-velocity_degree <= velocityangle_yawdelta || velocity:Length2D() <= 15) then
                        viewangles.y = viewangles.y + (strafe_angle * turn_direction_modifier)
                        cmd:SetSideMove(side_speed * turn_direction_modifier)
                    else
                        viewangles.y = velocity_angles.y - velocity_degree
                        cmd:SetSideMove(side_speed)
                    end
                else
                    viewangles.y = velocity_angles.y + velocity_degree
                    cmd:SetSideMove(-side_speed)
                end
            elseif (yaw_delta > 0) then
                cmd:SetSideMove(-side_speed)
            elseif (yaw_delta < 0) then
                cmd:SetSideMove(side_speed)
            end
    
            local move = Vector(cmd:GetForwardMove(), cmd:GetSideMove(), 0)
            local speed = move:Length()
    
            local angles_move = move:Angle()
    
            local normalized_x = math.modf(ultimate.fa.x + 180, 360) - 180
            local normalized_y = math.modf(ultimate.fa.y + 180, 360) - 180
    
            local yaw = math.rad(normalized_y - viewangles.y + angles_move.y)
    
            if (normalized_x >= 90 || normalized_x <= -90 || ultimate.fa.x >= 90 && ultimate.fa.x <= 200 || ultimate.fa.x <= -90 && ultimate.fa.x <= 200) then
                cmd:SetForwardMove(-math.cos(yaw) * speed)
            else
                cmd:SetForwardMove(math.cos(yaw) * speed)
            end
    
            cmd:SetSideMove(math.sin(yaw) * speed)

        elseif ultimate.cfg.vars["Air strafer"] and ultimate.cfg.vars["Strafe mode"] == 2 then
            cmd:SetForwardMove(0)

            if me:IsFlagSet( FL_ONGROUND ) then
                cmd:SetForwardMove(10000)
            else
                cmd:SetForwardMove(5850 / me:GetVelocity():Length2D())
                cmd:SetSideMove((cmd:CommandNumber() % 2 == 0) && -400 || 400)
            end

            /*

local ang_diff = math_NormalizeAngle( ultimate.fa.y - prev_yaw )
            
            if ( math_abs( ang_diff ) > 0 ) then
            
                if ( ang_diff > 0 ) then
                    cmd:SetSideMove( -10000 )
                else
                    cmd:SetSideMove( 10000 )
                end
            
            else
            
                local vel = me:GetAbsVelocity()
                local vel_yaw = math_NormalizeAngle( math_deg( math_atan2( vel.y, vel.x ) ) )
                local vel_yaw_diff = math_NormalizeAngle( ultimate.fa.y - vel_yaw )
                
                if ( vel_yaw_diff > 0 ) then
                    cmd:SetSideMove( -10000 )
                else
                    cmd:SetSideMove( 10000 )
                end
    
                local viewangles = cmd:GetViewAngles() //ultimate.fa //Angle( ultimate.fa.x, ultimate.fa.y, 0 )
                viewangles.y = vel_yaw
                cmd:SetViewAngles( viewangles )
                
            end
    
            prev_yaw = ultimate.fa.y
            */
            
            
        end
    end
end



/*
    Anti aims
*/

ultimate.aatarget = nil

function ultimate.PredictedPos(ply)
    return ply:GetPos() + ply:GetVelocity() * TickInterval
end

function ultimate.PredictedEyePos()
    return me:EyePos() + me:GetVelocity() * TickInterval
end

function ultimate.GetBaseYaw()
    if not IsValid( ultimate.aatarget ) or ultimate.cfg.vars["Yaw base"] != 2 then
        return ultimate.fa.y
    end

    return math_NormalizeAngle( (ultimate.PredictedPos(ultimate.aatarget) - ultimate.PredictedEyePos()):Angle().y )
end

function ultimate.Freestand(cmd)
	if !IsValid(ultimate.aatarget) then return false end

	local headpos = me:GetBonePosition(me:LookupBone("ValveBiped.Bip01_Head1"))
	if !headpos then return end

	local selfpos = me:GetPos()
	local headoffset = Vector(selfpos.x, selfpos.y, headpos.z):Distance(headpos) + 5

	local found = true

	local pos = ultimate.aatarget:WorldToLocal(selfpos)
	local bearing = math_deg(-math_atan2(pos.y, pos.x)) + 180 + 90
	local left, right = bearing - 180 - 90, bearing - 180 + 90

	local function CheckYaw(yaw)
		yaw = math_rad(yaw)
		local x, y = math_sin(yaw), math_cos(yaw)

		local headoffsetvec = Vector(x, y, 0) * headoffset
		headoffsetvec.z = headpos.z - selfpos.z

		local tr = TraceLine({
			start = ultimate.aatarget:EyePos() + ultimate.aatarget:GetVelocity() * TickInterval * 4,
			endpos = selfpos + headoffsetvec,
			filter = ultimate.aatarget
		})

		return tr.Fraction < 1 and tr.Entity != me
	end

	local function Normalize(ang) return 360 - ang + 90 end

	local leftcheck, rightcheck = CheckYaw(left), CheckYaw(right)

	left, right = Normalize(left), Normalize(right)

	do
		local headlocal = me:WorldToLocal(headpos)
		if headlocal.x > 0 then
			left, right = right, left
		end
	end

	if leftcheck and rightcheck then
		return false
	elseif leftcheck then
		return true, left , right
	elseif rightcheck then
		return true, right, left
	end

	return false
end







ultimate.mbreal = Angle()

do
    local pitch, yaw = 0, 0 

    local pitches = { 
        [1] = 89,
        [2] = -89,
        [3] = 0,
        [4] = -180,
        [5] = 180,
    }














    local mm_side = false
    local baseyaw = 0
    local side = false
    local pitchflip = false

    local hruxisSide = 1

    local function CalcPitch()
        local cfg = ultimate.cfg.vars["Pitch"]
        local x = 0

        if cfg <= 5 then return pitches[cfg] end

        if ultimate.bsendpacket then
            pitchflip = not pitchflip
        end
        
        if cfg == 6 then
            x = pitchflip and 180 or -180
        elseif cfg == 7 then
            x = ultimate.bsendpacket and 89 or -180
        end

        return x
    end

    local function CalcYaw()
        local cfg = ultimate.cfg.vars["Yaw"] 
        local y = 0
        
        if cfg == 1 then
            y = baseyaw - 178
        elseif cfg == 2 then
            y = baseyaw + ( ultimate.bsendpacket && 0 || 178 )
        elseif cfg == 3 then
            y = baseyaw - ( ultimate.bsendpacket && 90 || -60 )
            //y = baseyaw - ( ultimate.bsendpacket && 90 || -90 )
        elseif cfg == 4 then
            y = baseyaw - ( ultimate.bsendpacket && 90 || 178 )
        elseif cfg == 5 then 
            local s = math_NormalizeAngle( CurTime() * 300 )
            y = ultimate.bsendpacket && s || ( baseyaw - 180 )
        elseif cfg == 6 then
            y = ded.GetCurrentLowerBodyYaw(me:EntIndex()) + (ultimate.bsendpacket && 180 || 0)
        elseif cfg == 7 then
            local side = CurTime()%2 * math_random(-45,45)

            y = ( baseyaw - 180 ) + (ultimate.bsendpacket and side or - side)
        elseif cfg == 8 then
            if ultimate.bsendpacket then
                hruxisSide = hruxisSide * -1
            end
    
            local swaySpeed = (ultimate.fakeLagTicks + 1) / 12 * math.pi
            local swayAmount = math_sin(CurTime() * swaySpeed) * 45
    
            y = ( baseyaw - 180 ) + 55 * hruxisSide + swayAmount * hruxisSide * -1
        end

        /*
if ultimate.cfg.vars["Jitter"] == 2 and ultimate.bsendpacket then
            local r = math_random(-45,45)
            local lbydiff = ded.GetTargetLowerBodyYaw(me:EntIndex()) - ded.GetCurrentLowerBodyYaw(me:EntIndex())

            if y + r > ded.GetTargetLowerBodyYaw(me:EntIndex()) then
                y = y + math_random(-lbydiff,lbydiff)
            else
                y = y + r
            end
             
        elseif ultimate.cfg.vars["Jitter"] == 3 and ultimate.bsendpacket then
            y = y + math_random(ded.GetCurrentLowerBodyYaw(me:EntIndex()),ded.GetTargetLowerBodyYaw(me:EntIndex()))
        end

        */
        

        return y
    end

    local function micromovement(cmd)
        if !ultimate.cfg.vars["Micromovement"] then return end
        if !me:Alive() then return end
        if !me:IsFlagSet( FL_ONGROUND ) then return end
        if cmd:KeyDown(IN_BACK) or cmd:KeyDown(IN_FORWARD) or cmd:KeyDown(IN_MOVELEFT) or cmd:KeyDown(IN_MOVERIGHT) then return end

        cmd:SetSideMove(mm_side and -15.0 or 15.0)
        mm_side = !mm_side
    end

    local function aacheck(cmd)
        if !ultimate.cfg.vars["Anti aim"] then return false end
        if cmd:KeyDown(IN_ATTACK) then return false end
        if cmd:KeyDown(IN_USE) then return false end
        if me:GetMoveType() == MOVETYPE_LADDER then return false end
        if me:GetMoveType() == MOVETYPE_NOCLIP then return false end

        return true 
    end

    function ultimate.AntiAim(cmd)
        local freestandsucc, freestandsafe, freestandunsafe 

        if ultimate.cfg.vars["Freestanding"] then
            freestandsucc, freestandsafe, freestandunsafe = ultimate.Freestand(cmd)
        end

        baseyaw = ultimate.GetBaseYaw()
        pitch = CalcPitch()
        yaw = CalcYaw()

        if freestandsucc then
            yaw = ultimate.bsendpacket and freestandunsafe or freestandsafe
        end

        if aacheck(cmd) then
            local pyAngle = Angle(pitch,yaw,0)

            micromovement(cmd)

            cmd:SetViewAngles(pyAngle)

            if ultimate.bsendpacket then
                ultimate.mbreal = pyAngle
            end
        end
    end
end

/*
    Fake lag
*/
ultimate.fakeLagTicks = 0
ultimate.fakeLagfactor = 0
ultimate.chokedTicks = 0

ultimate.peeked = false 
ultimate.peeking = false 

function ultimate.FakeLagOnPeek()
    ultimate.fakeLagTicks = 21 - ultimate.chokedTicks - 1 

    if ultimate.chokedTicks >= 20 then
        ultimate.peeked = true
		ultimate.peeking = false
		ultimate.bsendpacket = true
        me.simtime_updated = true
        ded.UpdateClientAnimation( me:EntIndex() )
		return
    end
end

function ultimate.WarpOnPeek()
	ded.StartShifting( true )
    print("WARPING")
	ultimate.peeked = true
	ultimate.peeking = false
end

function ultimate.CheckPeeking()
	local plys

	for extr = 1, 8 do
        plys = ultimate.GetSortedPlayers( 1, extr, 1, true ) 
		if plys then break end
	end

	if plys and !ultimate.peeking and !ultimate.peeked then
		ultimate.peeking = true
		ultimate.peeked = false
	elseif !plys then
		ultimate.peeking = false
		ultimate.peeked = false
	end

	if ultimate.peeking and !ultimate.peeked then
		if !ded.GetIsShifting()  and ultimate.cfg.vars["Warp on peek"] then
			ultimate.WarpOnPeek()
        elseif ultimate.cfg.vars["Freeze on peek"] then
            ded.SetOutSequenceNr( ded.GetOutSequenceNr() + ultimate.maxFreezeTicks - 1 ) 
		elseif ultimate.cfg.vars["Fake lag options-On peek"] then
			ultimate.FakeLagOnPeek()
		end
	end
end




do
    
    local function shouldlag(cmd)
        if not ultimate.cfg.vars["Fake lag"] then return false end
        if not me:Alive() then return false end
        if ultimate.cfg.vars["Fakelag comp"] == 1 and ded.GetCurrentCharge() > 0 then return false end
        if ultimate.cfg.vars["Fake lag options-Disable on ladder"] and me:GetMoveType() == MOVETYPE_LADDER then return false end
        if ultimate.cfg.vars["Fake lag options-Disable in attack"] and cmd:KeyDown(IN_ATTACK) then return false end

        if ultimate.cfg.vars["Allah fly"] and not me:IsFlagSet( FL_ONGROUND ) then
            return false
        end

        return true
    end

    function ultimate.FakeLag(cmd)
        local factor = math_Round(ultimate.cfg.vars["Lag limit"])

        if ultimate.cfg.vars["Fake lag options-Randomise"] then 
            factor =  math_random(ultimate.cfg.vars["Lag randomisation"],factor) 
        end

        local velocity = me:GetVelocity():Length2D()
        local pertick = velocity * TickInterval
        local adaptive_factor = math_Clamp(math_ceil(64 / pertick),1,factor)

        if ultimate.cfg.vars["Lag mode"] == 1 or ultimate.cfg.vars["Lag mode"] == 3 then
            ultimate.fakeLagfactor = factor
        elseif ultimate.cfg.vars["Lag mode"] == 2 then
            ultimate.fakeLagfactor = adaptive_factor
        end

        if ultimate.cfg.vars["Allah walk"] and me:IsFlagSet( FL_ONGROUND ) and ultimate.IsKeyDown(ultimate.cfg.binds["allahwalk"]) then
            ultimate.fakeLagfactor = 21
        end

        

        if shouldlag(cmd) then
            ultimate.bsendpacket = false

            if ultimate.fakeLagTicks <= 0 then
                ultimate.fakeLagTicks = ultimate.fakeLagfactor
                ultimate.bsendpacket = true
                me.simtime_updated = true
                ded.UpdateClientAnimation( me:EntIndex() )
            else
                ultimate.fakeLagTicks = ultimate.fakeLagTicks - 1
            end

        else
            if ultimate.fakeLagfactor > 0 then ultimate.fakeLagfactor = 0 end
            ultimate.bsendpacket = true
            me.simtime_updated = true
            ded.UpdateClientAnimation( me:EntIndex() )
        end
    end
end

function ultimate.ClampMovementSpeed(cmd, speed)
	local final_speed = speed;

	local squirt = math.sqrt((cmd:GetForwardMove() * cmd:GetForwardMove()) + (cmd:GetSideMove() * cmd:GetSideMove()));

	if (squirt > speed) then
		local squirt2 = math.sqrt((cmd:GetForwardMove() * cmd:GetForwardMove()) + (cmd:GetSideMove() * cmd:GetSideMove()));

		local cock1 = cmd:GetForwardMove() / squirt2;
		local cock2 = cmd:GetSideMove() / squirt2;

		local Velocity = me:GetVelocity():Length2D();

		if (final_speed + 1.0 <= Velocity) then
			cmd:SetForwardMove(0)
			cmd:SetSideMove(0)
		else
			cmd:SetForwardMove(cock1 * final_speed)
			cmd:SetSideMove(cock2 * final_speed)
        end
    end
end

function ultimate.FastWalk( cmd )
    if not ultimate.cfg.vars["Ground strafer"] then return end 
    if math_abs(cmd:GetSideMove()) > 1 or math_abs(cmd:GetForwardMove()) < 1 then return end 
    if not me:IsFlagSet( FL_ONGROUND ) then return end
    
    local moveType = me:GetMoveType()

    if moveType == MOVETYPE_NOCLIP or moveType == MOVETYPE_LADDER then return end

    local waterLevel = me:WaterLevel()

    if waterLevel >= 2 then return end
    
	cmd:SetSideMove(cmd:CommandNumber() % 2 == 0 and -5250 or 5250)
end

function ultimate.validMoveType()
    local movetype = me:GetMoveType()
    
    if not movetype then
        return false
    end
    
    return movetype != MOVETYPE_LADDER and movetype != MOVETYPE_NOCLIP and movetype != MOVETYPE_OBSERVER 
end

function ultimate.isMoving(cmd)
    if not cmd then
        return false
    end

    return cmd:KeyDown(IN_MOVELEFT) or cmd:KeyDown(IN_MOVERIGHT) or cmd:KeyDown(IN_FORWARD) or cmd:KeyDown(IN_BACK) and not cmd:KeyDown(IN_JUMP)
end

function ultimate.Stop(cmd)
    if ultimate.validMoveType() and me:IsFlagSet( FL_ONGROUND ) then

        local moving = ultimate.isMoving(cmd)

        if not moving then

            local vel = me:GetVelocity()
            local dir = vel:Angle()
                
            dir.yaw = ultimate.fa.y - dir.yaw
                
            local newmove = dir:Forward() * vel:Length2D()
        
            cmd:SetForwardMove(0 - newmove.x)
            cmd:SetSideMove(0 - newmove.y)

        end

    end
end

// Slidewalk 

function ultimate.SlideWalk( cmd )
    local ticksToStop = ultimate.fakeLagfactor





end








// Auto peak 

ultimate.startedPeeking = false 
ultimate.needToMoveBack = false
ultimate.startPeekPosition = Vector(0,0,0)

function ultimate.MoveTo( cmd, pos )
    local ang = ( pos - me:GetPos() ):Angle().y

    cmd:SetForwardMove(1000)
    cmd:SetSideMove(0)

    cmd:AddKey(IN_SPEED)

    ultimate.MovementFix( cmd, ang )
end

function ultimate.checkAutopeak( cmd )
    if ultimate.startedPeeking and cmd:KeyDown(IN_ATTACK) then 
        ultimate.needToMoveBack = true
    elseif !ultimate.startedPeeking and !cmd:KeyDown(IN_ATTACK) then
        ultimate.needToMoveBack = false
    end  
end

do
    local colorA = Color( 235, 75, 75 )
    local colorB = Color( 75, 235, 75 )

    local apmat = Material( "gui/npc.png" )

    local nullangle = Angle(0,0,0)

    function ultimate.drawAutopeak()
        local col = ultimate.needToMoveBack and colorA or colorB
    
        cam_Start3D2D( ultimate.startPeekPosition, nullangle, 0.5 )
            cam_IgnoreZ( true )

            surface_SetDrawColor( col )
            surface_SetMaterial( apmat )
            surface_DrawTexturedRect( -32, -32, 64, 64 )

            cam_IgnoreZ( false )
        cam_End3D2D()
    end
end

function ultimate.autopeakThink()
    if ultimate.IsKeyDown(ultimate.cfg.binds["Auto peak"]) then
        if not ultimate.startedPeeking then
            ultimate.startPeekPosition = me:GetPos()     
        end

        ultimate.startedPeeking = true
    else
        ultimate.startedPeeking = false
    end
end







/*// Movement 
ultimate.holdingOnGround = false 
ultimate.badMoveTypes = { 
    ["MOVETYPE_NOCLIP"] = true, ["MOVETYPE_LADDER"] = true, ["MOVETYPE_OBSERVER"] = true 
}

function ultimate.BunnyHop(cmd)
    local moveType = me:GetMoveType()
    local waterLevel = me:WaterLevel()

    if ultimate.badMoveTypes[moveType] then return end 

    if me:IsFlagSet( FL_ONGROUND ) then

        --[[if ultimate.holdingOnGround then 
            ultimate.holdingOnGround = false

            cmd:RemoveKey(IN_JUMP)
        end

        if cmd:KeyDown(IN_JUMP) then
            ultimate.holdingOnGround = true 
        end

        return ]]
    else 
        cmd:RemoveKey(IN_JUMP)
        return
    end

    //if waterLevel >= 2 then return end 
end
*/

// Sequence Manipulation 

ultimate.freezedTicks = 0
ultimate.maxFreezeTicks = GetConVar("sv_maxcmdrate"):GetInt()
function ultimate.AnimationFreezer()
    if not ultimate.IsKeyDown( ultimate.cfg.binds["Animation freezer"] ) then return end

    if ultimate.freezedTicks < ultimate.maxFreezeTicks then
        ded.SetOutSequenceNr( ded.GetOutSequenceNr() + ultimate.maxFreezeTicks - 1 ) 

        ultimate.freezedTicks = ultimate.freezedTicks + 1
    else
        ultimate.freezedTicks = 0
    end
end

ultimate.seqshit = false
function ultimate.SequenceShit(cmd)
    if not ultimate.cfg.vars["Sequence manip"] or not ultimate.IsKeyDown(ultimate.cfg.binds["Sequence manip"]) then
        
        if ultimate.seqshit then
            ultimate.seqshit = false 
        end

        return 
    end

    local amt = ultimate.cfg.vars["Sequence min random"] and math_random(ultimate.cfg.vars["Sequence min"],ultimate.cfg.vars["OutSequence"]) or ultimate.cfg.vars["OutSequence"] 

    ultimate.seqshit = true
    ultimate.bsendpacket = true
    ded.SetOutSequenceNr(ded.GetOutSequenceNr() + amt)
end

// Handjob ( arm breaker )

function ultimate.PerformHandjob( cmd )
    local mode = ultimate.cfg.vars["Handjob mode"]
    local shouldjerk = true

    if mode == 2 then
        shouldjerk = (cmd:CommandNumber() % 12) >= 6
    elseif mode == 3 then
        shouldjerk = math_random(0, 1) == 0 
    end

    ded.SetTyping(cmd, shouldjerk)
end 

// create move hook

ultimate.norf = {
    ["laserjetpack"] = true,
    ["weapon_physgun"] = true,
}

local ic = false
function ultimate.CreateMove(cmd)
    ultimate.SilentAngles(cmd)

    if ( ded.GetChokedPackets() > 14 ) then ded.SetChokedPackets( 14 ) end

    if cmd:CommandNumber() == 0 then return end

    --im retarded
    if ultimate.cfg.vars["Passive recharge"]  and not ded.GetIsShifting() and ded.GetCurrentCharge() < ultimate.cfg.vars["Maximum Shift Ticks"]  then
        ded.StartRecharging( true )
    else
        ded.StartRecharging( false)
    end

    ultimate.mbreal = cmd:GetViewAngles()

    if ultimate.cfg.vars["Silent aim"] then cmd:SetViewAngles(ultimate.fa) end

    if ded.GetIsShifting() then
        //  ded.AdjustTickbase()
        print("shifting")
    end

    if ultimate.cfg.vars["Flashlight spam"] and input_IsKeyDown( KEY_F ) then
        cmd:SetImpulse(100)
    end

    if ultimate.cfg.vars["Handjob"] then
        ultimate.PerformHandjob( cmd )
    end

    //if ultimate.cfg.vars["Fake latency"] then
    //    local amt = ultimate.cfg.vars["Max latency"]
    //    ded.SetInSequenceNr(ded.GetInSequenceNr() - amt)
    //end

    if ultimate.nextTick then 
        cmd:RemoveKey(IN_ATTACK) 
    
        ultimate.nextTick = !ultimate.nextTick 
    end

    if ( me:IsFlagSet( FL_ONGROUND ) ) then
		ultimate.last_ground_pos = me:GetNetworkOrigin().z
	end

    if ultimate.cfg.vars["Animation freezer"] then ultimate.AnimationFreezer() end
    
	ultimate.SequenceShit(cmd)

    if not ultimate.seqshit then
        ultimate.FakeLag(cmd)

        if ultimate.cfg.vars["Allah walk"] and me:IsFlagSet( FL_ONGROUND ) and ultimate.IsKeyDown(ultimate.cfg.binds["allahwalk"]) then
            
            if ultimate.fakeLagTicks != 20 then
                ultimate.ClampMovementSpeed(cmd, 0)
            else
                ultimate.ClampMovementSpeed(cmd, me:GetWalkSpeed())
            end

            //if(ultimate.fakeLagTicks <= 20) then
            //    ultimate.ClampMovementSpeed(cmd, 0)
            //    ultimate.Stop(cmd)
                //me:SetPoseParameter("move_x", 0)
	            //me:SetPoseParameter("move_y", 0)
            //else
             //   ultimate.ClampMovementSpeed(cmd, me:GetWalkSpeed())
            //end

            --print(ultimate.fakeLagTicks,me:GetVelocity():Length2D())
        end
    end

    if ultimate.cfg.vars["Fake lag options-On peek"] or ultimate.cfg.vars["Warp on peek"] or ultimate.cfg.vars["Freeze on peek"] then
        ultimate.CheckPeeking()
    end
    

    // Movement
    
    ultimate.FastWalk( cmd )

    if ultimate.cfg.vars["Sprint"] then cmd:AddKey(IN_SPEED) end

    if ( cmd:KeyDown( IN_JUMP ) ) then

		if ( !me:IsFlagSet( FL_ONGROUND ) ) and ultimate.cfg.vars["Bhop"] then
			cmd:RemoveKey( IN_JUMP )
		end

		ultimate.AutoStrafe( cmd )
	end
    
	if ultimate.cfg.vars["Fast stop"] then
        ultimate.Stop(cmd)
    end

    if ultimate.cfg.vars["Water jump"] and me:WaterLevel() > 1 then
        cmd:AddKey( IN_JUMP )
    end

    if ultimate.cfg.vars["Fake duck"] and ultimate.IsKeyDown(ultimate.cfg.binds["Fake duck"]) then
        if ultimate.fakeLagTicks > (ultimate.fakeLagfactor / 2) then
            cmd:AddKey(IN_DUCK)
        else
            cmd:RemoveKey(IN_DUCK)
        end
    end

	ded.StartPrediction(cmd)

        local wish_yaw = ultimate.fa.y 

        if ( ultimate.IsKeyDown(ultimate.cfg.binds["Circle strafe"]) and ultimate.cfg.vars["Circle strafe"] ) then
            wish_yaw = cmd:GetViewAngles().y
        end

        ultimate.Aim(cmd)
        
        if ultimate.cfg.vars["Silent aim"] then
            ultimate.MovementFix( cmd, wish_yaw )
        end

    ded.FinishPrediction()

    if ultimate.cfg.vars["Trigger bot"] and ultimate.IsKeyDown( ultimate.cfg.binds["Trigger bot"] ) then
        local tr = me:GetEyeTrace().Entity 
        
        if tr and tr:IsPlayer() then
            cmd:AddKey( IN_ATTACK )
        end
    end

    if ultimate.cfg.vars["Rapid fire"] and me:Alive() then
        local w = me:GetActiveWeapon()

        if IsValid(w) and not ultimate.norf[ w:GetClass() ] and me:KeyDown( IN_ATTACK ) then
            cmd:RemoveKey(IN_ATTACK)
        end
    end



    if ultimate.cfg.vars["Auto peak"] then
        local ppos = ultimate.startPeekPosition
        local pposd = me:GetPos():DistToSqr(ppos)

        if ultimate.needToMoveBack and pposd < 1024 then //or ultimate.IsMovementKeysDown( cmd )
            ultimate.needToMoveBack = false
        end

        if ultimate.startedPeeking then
            //if not ultimate.IsMovementKeysDown( cmd ) then
            //    ultimate.needToMoveBack = true
            //end

            if ultimate.needToMoveBack then
                ultimate.MoveTo( cmd, ppos )

                if ultimate.cfg.vars["Auto peak tp"] and ultimate.cfg.vars["Tickbase shift"] then
                    ded.StartShifting( true )
                end
            end
        end

        ultimate.checkAutopeak( cmd )
    end

    ultimate.autoReload(cmd)

    if ultimate.cfg.vars["Use spam"] then
        if cmd:KeyDown(IN_USE) then
            cmd:RemoveKey(IN_USE)
        else
            cmd:AddKey(IN_USE)
        end
    end

    if ultimate.cfg.vars["Auto GTA"] then
        local tr = me:GetEyeTrace().Entity

        if IsValid( tr ) and tr:IsVehicle() then
            cmd:AddKey(IN_USE)
        end
    end

    if ultimate.fcenabled then
        cmd:ClearMovement()
        cmd:ClearButtons()

        cmd:SetViewAngles(ultimate.fcangles)
    end

    if ultimate.bsendpacket then
        ultimate.chokedTicks = 0 
    else
        ultimate.chokedTicks = ultimate.chokedTicks + 1
    end

    if not ultimate.cfg.vars["Silent aim"] then ultimate.fa = cmd:GetViewAngles() end

    ded.SetBSendPacket(ultimate.bsendpacket)

    if ultimate.cfg.vars["Lag mode"] == 3 and ultimate.bsendpacket then
        ded.SetOutSequenceNr(ded.GetOutSequenceNr() + 8)
    end
end




hook_Add("CreateMove","ultimate.CreateMove",ultimate.CreateMove)


/*
    ESP, Chams
*/

function ultimate.IsValidPlayer(pl)
    if pl == me then return false end
    if not IsValid(pl) then return false end
    if not pl:Alive() then return false end


    return true
end

function ultimate.GetEntPos(ent)
    local min, max = ent:OBBMins(), ent:OBBMaxs()

    local points = {
        Vector( max.x, max.y, max.z ),
        Vector( max.x, max.y, min.z ),
        Vector( max.x, min.y, min.z ),
        Vector( max.x, min.y, max.z ),
        Vector( min.x, min.y, min.z ),
        Vector( min.x, min.y, max.z ),
        Vector( min.x, max.y, min.z ),
        Vector( min.x, max.y, max.z )
    }

    local MaxX, MinX, MaxY, MinY
    local isVisible = false

    for i = 1, #points do
        local v = points[i]
        local p = ent:LocalToWorld( v ):ToScreen()
        isVisible = p.visible 
        
		if MaxX != nil then
            MaxX, MaxY, MinX, MinY = math_max( MaxX, p.x ), math_max( MaxY, p.y), math_min( MinX, p.x ), math_min( MinY, p.y)
        else
            MaxX, MaxY, MinX, MinY = p.x, p.y, p.x, p.y
        end

    end

    return MaxX, MaxY, MinX, MinY, isVisible
end

function ultimate.getTextX(tw,pos)
    if pos == 1 or pos == 2 then
        return tw/2
    elseif pos == 3 then
        return 0
    elseif pos == 4 then 
        return tw
    end
end

function ultimate.getTextY(max,min,th,pos,tbpos)
    if pos == 1 then
        return min-th-th*tbpos
    elseif pos == 2 then
        return max+th*tbpos
    elseif pos == 3 then
        return min+th*tbpos
    elseif pos == 4 then
        return min+th*tbpos
    end
end

function ultimate.SortByDistance( f, s )
    return f[1]:GetPos():DistToSqr( EyePos() ) > s[1]:GetPos():DistToSqr( EyePos() )
end

local function fovCircle()
    if(!ultimate.cfg.vars["FOV Circle"]) then return end
	local center = Vector(ScrW() / 2, ScrH() / 2, 0)
	local scale = ultimate.cfg.vars["Aimbot FOV"] * 8
	surface.DrawCircle(center.x, center.y, scale, string_ToColor(ultimate.cfg.colors["FOV Circle Color"]))


end

function ultimate.DrawESP()
    local d = ultimate.cfg.vars["ESP Distance"]
    local ed = ultimate.cfg.vars["Ent ESP Distance"]
    local pos = me:GetPos()
    d = d * d
    ed = ed * ed

    surface_SetFont( "veranda" )

    for i = 1, #ultimate.entityCache do
        local v = ultimate.entityCache[ i ]

        if not IsValid( v.entity ) then return end 

        if v.position:DistToSqr( pos ) > ed then continue end

        local MaxX, MaxY, MinX, MinY, isVisible = ultimate.GetEntPos( v.entity )
        local XLen, YLen = MaxX - MinX, MaxY - MinY

        if not isVisible then continue end

        surface_SetAlphaMultiplier( v.entity:IsDormant() and 0.35 or 1 )

        surface_SetTextColor( ultimate.Colors[255] )

        if ultimate.cfg.vars["Ent box"] then
            surface_SetDrawColor( 0, 0, 0 )
            surface_DrawOutlinedRect(MinX-1,MinY-1,XLen+2,YLen+2,3)

            surface_SetDrawColor( 255, 255, 255 ) 
            surface_DrawOutlinedRect(MinX,MinY,XLen,YLen,1)
        end

        if ultimate.cfg.vars["Ent class"] then
            local tw, th = surface_GetTextSize( v.class )

            surface_SetTextPos( ( MaxX + (MinX - MaxX) / 2 ) - tw / 2 , MinY - th )
            surface_DrawText( v.class )
        end
    end

    local plys = player_GetAll()

    for i = 1, #plys do
        local v = plys[i]

        if not ultimate.IsValidPlayer(v) or not ultimate.playerCache[ v ] then continue end
        
        local vp = ultimate.playerCache[ v ].GetPos
		if vp:DistToSqr(pos) > d then continue end

        surface_SetAlphaMultiplier( v:IsDormant() and 0.35 or 1 )

        local MaxX, MaxY, MinX, MinY, isVisible = ultimate.GetEntPos( v )
        local XLen, YLen = MaxX - MinX, MaxY - MinY

        if not isVisible then continue end

        local teamcolor = ultimate.playerCache[ v ].TeamColor

        if ultimate.cfg.vars["Box esp"] then
            surface_SetDrawColor(ultimate.Colors[0])
            surface_DrawOutlinedRect(MinX-1,MinY-1,XLen+2,YLen+2,3)

            surface_SetDrawColor(teamcolor)
            surface_DrawOutlinedRect(MinX,MinY,XLen,YLen,1)
        end

        // text 

        local ttbl = { [1] = 0, [2] = 0, [3] = 0, [4] = 0 }
        local poses = { [1] = MaxX + (MinX - MaxX) / 2, [3] = MaxX+5, [4] = MinX-5 }
        poses[2] = poses[1]

        surface_SetTextColor( ultimate.Colors[255] )

        if ultimate.cfg.vars["Name"] then 
            local name = ultimate.playerCache[ v ].Name
            local pos = ultimate.cfg.vars["Name pos"]
            local tw, th = surface_GetTextSize(name)

            surface_SetTextPos(poses[pos]-ultimate.getTextX(tw,pos),ultimate.getTextY(MaxY,MinY,th,pos,ttbl[pos]))
            surface_DrawText(name)

            ttbl[pos] = ttbl[pos] + 0.8
        end

        if ultimate.cfg.vars["Usergroup"] then 
            local name = ultimate.playerCache[ v ].GetUserGroup
            local pos = ultimate.cfg.vars["Usergroup pos"]
            local tw, th = surface_GetTextSize(name)

            surface_SetTextPos(poses[pos]-ultimate.getTextX(tw,pos),ultimate.getTextY(MaxY,MinY,th,pos,ttbl[pos]))
            surface_DrawText(name)

            ttbl[pos] = ttbl[pos] + 0.8
        end

        if ultimate.cfg.vars["Weapon"] then 
            local name = ultimate.playerCache[ v ].WeaponClass
            local pos = ultimate.cfg.vars["Weapon pos"]
            local tw, th = surface_GetTextSize(name)

            surface_SetTextPos(poses[pos]-ultimate.getTextX(tw,pos),ultimate.getTextY(MaxY,MinY,th,pos,ttbl[pos]))
            surface_DrawText(name)

            ttbl[pos] = ttbl[pos] + 0.8
        end

        if ultimate.cfg.vars["Armor"] then 
            local name = ultimate.playerCache[ v ].Armor
            local pos = ultimate.cfg.vars["Armor pos"]
            local tw, th = surface_GetTextSize(name)

            surface_SetTextPos(poses[pos]-ultimate.getTextX(tw,pos),ultimate.getTextY(MaxY,MinY,th,pos,ttbl[pos]))
            surface_DrawText(name)

            ttbl[pos] = ttbl[pos] + 0.8
        end

        if ultimate.cfg.vars["Team"] then 
            local name = ultimate.playerCache[ v ].TeamName
            local pos = ultimate.cfg.vars["Team pos"]
            local tw, th = surface_GetTextSize(name)

            surface_SetTextPos(poses[pos]-ultimate.getTextX(tw,pos),ultimate.getTextY(MaxY,MinY,th,pos,ttbl[pos]))
            surface_DrawText(name)

            ttbl[pos] = ttbl[pos] + 0.8
        end

        local health = ultimate.playerCache[ v ].Health

        if ultimate.cfg.vars["Health bar"] then 
            local maxhealth = ultimate.playerCache[ v ].GetMaxHealth

			local healthfrac = math_min( health / maxhealth, 1 )
		    local height = healthfrac * YLen

            surface_SetDrawColor( 0, 0, 0 )
            surface_DrawRect( MinX-6, MinY-1, 4, YLen+2 )

			surface_SetDrawColor( string_ToColor( ultimate.cfg.colors["Health"] ) )
			surface_DrawRect(MinX - 5, MinY+YLen-height, 2, height)

            if ultimate.cfg.vars["Health bar gradient"] then 
                surface_SimpleTexturedRect( MinX - 5, MinY+YLen-height, 2, height, string_ToColor( ultimate.cfg.colors["Health bar gradient"] ) , ultimate.Materials["Gradient"] )
            end
        end

        if ultimate.cfg.vars["Health"] then 
            local pos = ultimate.cfg.vars["Health pos"]
            local tw, th = surface_GetTextSize(health)

            surface_SetTextPos(poses[pos]-ultimate.getTextX(tw,pos),ultimate.getTextY(MaxY,MinY,th,pos,ttbl[pos]))
            surface_DrawText(health)

            ttbl[pos] = ttbl[pos] + 0.8
        end

        if ultimate.cfg.vars["Break LC"] and v.break_lc then
            local name = "Breaking LC"
            local pos = ultimate.cfg.vars["Break LC pos"]
            local tw, th = surface_GetTextSize(name)

            surface_SetTextPos(poses[pos]-ultimate.getTextX(tw,pos),ultimate.getTextY(MaxY,MinY,th,pos,ttbl[pos]))
            surface_DrawText(name)

            ttbl[pos] = ttbl[pos] + 0.8
        end

        if ultimate.cfg.vars["Simtime updated"] then
            local name = v.simtime_updated and "Updated" or "Same"
            local pos = ultimate.cfg.vars["Simtime pos"]
            local tw, th = surface_GetTextSize(name)

            surface_SetTextPos(poses[pos]-ultimate.getTextX(tw,pos),ultimate.getTextY(MaxY,MinY,th,pos,ttbl[pos]))
            surface_DrawText(name)

            ttbl[pos] = ttbl[pos] + 0.8
        end

        if ultimate.cfg.vars["Skeleton"] then
            surface_SetDrawColor(color_white)

			for i = 0, v:GetBoneCount() - 1 do
				local parent = v:GetBoneParent(i)
				if !parent then continue end
				
				local bonepos = v:GetBonePosition(i)
				if bonepos == vpos then continue end
				
				local parentpos = v:GetBonePosition(parent)
				if !bonepos or !parentpos then continue end
				
				local p1, p2 = bonepos:ToScreen(), parentpos:ToScreen()
				
				surface_DrawLine(p1.x, p1.y, p2.x, p2.y)
			end
        end

        if ultimate.cfg.vars["Show records"] and ultimate.canBacktrack(v) then
            local len = #ultimate.btrecords[v]

            for i = 1, len do
                local pos = (ultimate.btrecords[v][i].aimpos):ToScreen()
                surface_SetDrawColor(ultimate.Colors[255])
                surface_DrawRect(pos.x,pos.y,2,2)
            end
        end

        
        /*
    ultimate.checkbox("","Show records",p:GetItemPanel())


        */
    
        --ultimate.cfg.vars["DarkRP Money"] = false
        --ultimate.cfg.vars["DarkRP pos"] = 1
    
    end

    surface_SetAlphaMultiplier(1)

    fovCircle()
end


surface.CreateFont("DTFont", { font = "Verdana", size = 15, antialias = false, outline = true } )
surface.CreateFont("XVIDEOS FONT", { font = "Verdana", size = 45, antialias = false, shadow = true } )


do
    local lc, blc = Color(125,255,64), Color(255,64,125)

    local indx, indy = scrw / 2 - 100, scrh/2 + 250
    local charge = 0

    local gradcolor, chargedcolor, unchargedcolor = Color(200,200,200,128), Color(0,255,128), Color(255,155,0)

    local chargestate, ccharge, chargecolor = "NOT CHARGED", 0, chargedcolor

    //local watermarkx = scrw + 245
    //local watermarkc = Color( 232, 232, 232, 235)

    function ultimate.DrawSomeShit()
        surface_SetFont("DTFont")
        
        local latency = math_Round( ( ded.GetLatency(0) + ded.GetLatency(1) ) * 1000 ) 
        local currentlby = math_Round( ded.GetCurrentLowerBodyYaw( me:EntIndex() ) ) 
        local targetlby = math_Round( ded.GetTargetLowerBodyYaw( me:EntIndex() ) ) 


        surface_SimpleText(38,scrh-120,"LC",me.break_lc and blc or lc)
        surface_SimpleText(38,scrh-140,"FT: "..ultimate.fakeLagTicks,ultimate.bsendpacket and blc or lc)
        surface_SimpleText(38,scrh-160,math_Round(me:GetVelocity():Length2D()),lc)
        surface_SimpleText(38,scrh-180,"AT: "..latency.." ms",latency > 50 and blc or lc)
        surface_SimpleText(38,scrh-200,"LBY: "..currentlby.." ("..targetlby..")",currentlby != targetlby and blc or lc)
        
        if ultimate.cfg.vars["Tickbase indicator"] then
            
            ccharge = ded.GetCurrentCharge() * 196 / ultimate.cfg.vars["Maximum Shift Ticks"] 
            charge = math_Approach(charge,ccharge,FrameTime()*700)

            if ded.GetCurrentCharge() >= ultimate.cfg.vars["Maximum Shift Ticks"] then
                chargestate = "FULLY CHARGED"
                chargecolor = chargedcolor
            elseif ded.GetIsCharging() then
                chargestate = "CHARGING"
                chargecolor = unchargedcolor
            end

            local tw, th = surface_GetTextSize(chargestate)

            surface_SetDrawColor(ultimate.Colors[12])
            surface_DrawRect(indx,indy,200,30)

            surface_SetDrawColor(chargecolor) 
            surface_DrawRect(indx+2,indy+2,charge,26)

            surface_SimpleTexturedRect(indx+2,indy+2,charge,26,gradcolor,ultimate.Materials["Gradient right"])

            surface_SimpleText(indx+2,indy-20,"CHARGE "..ded.GetCurrentCharge(),ultimate.Colors[245])
            surface_SimpleText(indx+196-tw,indy-20,chargestate,ultimate.Colors[245])
        end

        

        /*
        
        watermarkx = watermarkx - 1

        if watermarkx < -925 then
            watermarkx = scrw + 100
        end

        surface_SetFont("XVIDEOS FONT")
        surface_SimpleText(watermarkx,10,"This video was uploaded to WWW.XVIDEOS.COM",watermarkc)
        */
        local CT = CurTime()
        local FT = FrameTime() * 128

        if ultimate.cfg.vars["Hitmarker"] then
            if #ultimate.hitmarkers == 0 then return end

            local hm = string_ToColor( ultimate.cfg.colors["Hitmarker"] )
    
            surface_SetDrawColor( hm )

            for i = #ultimate.hitmarkers, 1, -1  do
                local v = ultimate.hitmarkers[ i ]
    
                if v.time < CT - 1 then table_remove( ultimate.hitmarkers, i ) continue end 
    
                v.add = math_Approach( v.add, v.add - (CT - 1) * 5, FT )

                surface_DrawLine( scrwc - v.add, scrhc - v.add, scrwc - 10 - v.add, scrhc - 10 - v.add )
                surface_DrawLine( scrwc + v.add, scrhc - v.add, scrwc + 10 + v.add, scrhc - 10 - v.add )
                surface_DrawLine( scrwc - v.add, scrhc + v.add, scrwc - 10 - v.add, scrhc + 10 + v.add )
                surface_DrawLine( scrwc + v.add, scrhc + v.add, scrwc + 10 + v.add, scrhc + 10 + v.add )
            end
        end

        if ultimate.cfg.vars["Hitnumbers"] then 
            if #ultimate.hitnums == 0 then return end

            local n, c = string_ToColor( ultimate.cfg.colors["Hitnumbers"] ), string_ToColor( ultimate.cfg.colors["Hitnumbers krit"] )
        
            surface_SetFont( "veranda_scr" )

            for i = #ultimate.hitnums, 1, -1 do
                local v = ultimate.hitnums[ i ]

                if v.time < CT - 1 then table_remove( ultimate.hitnums, i ) continue end 

                surface_SetTextColor( v.crit and c or n )

                v.add = math_Approach( v.add, v.add - (CT - 1) * 5, FT / 2 )

                surface_SetTextPos( scrwc - v.add * v.xdir, scrhc - v.add * v.ydir )
                surface_DrawText( v.dmg )
            end
        end


    end
    
    
end


hook.Add("HUDPaint", "anal2012", function()
    ultimate.DrawESP()
    ultimate.DrawSomeShit()

    // draw.SimpleText(me:GetVelocity():Length2D(),"XVIDEOS FONT",scrwc,scrhc,color_white,TEXT_ALIGN_CENTER,TEXT_ALIGN_CENTER)
end)
/*
hook.Add( "PostDrawTranslucentRenderables", "test", function()
    if ultimate.targetVector then
        render.DrawWireframeSphere( ultimate.targetVector, 0.5, 10, 10, Color( 255, 0, 64 ) )
    end
end)
*/


ultimate.kd = false
function ultimate.togglevisible()
    if ultimate.frame:IsVisible() then
        ultimate.frame:SetVisible(false)
        if ultimate.ui.MultiComboP then ultimate.ui.RemovePanel( ultimate.ui.MultiComboP ) end
        if ultimate.ui.ColorWindow then ultimate.ui.RemovePanel( ultimate.ui.ColorWindow ) end
        if ultimate.ui.SettingsPan then ultimate.ui.RemovePanel( ultimate.ui.SettingsPan ) end

        RememberCursorPosition()

        --if ultimate.validsnd then ultimate.validsnd:Pause() end
    else
        ultimate.frame:SetVisible(true)

        RestoreCursorPosition()
        --if ultimate.validsnd then ultimate.validsnd:Play() end
    end
end

// dormant esp 
--[[]

function ultimate.SetEntPos(ent,pos)
    if not IsValid(ent) or ent == me or not ent:IsDormant() then return end

    ent:SetNetworkOrigin(pos)
    ent:SetRenderOrigin(pos)
end

hook.Add( "EntityEmitSound", "EntSounds", function( data )
    local ent = data.Entity 
    local pos = data.Pos

    if ent:IsPlayer() and ent:Alive() and ent:IsDormant() then
        ultimate.SetEntPos(ent,pos)
        print(ent,pos)
    elseif ent:IsWeapon() then
        print(ent)
    end
end)

hook.Add( "PlayerStepSoundTime", "StepSounds", function( ent, type, walking )
    local pos = ent:GetPos()

    if ent:Alive() and ent:IsDormant() then
        ultimate.SetEntPos(ent,pos)
        print("steps ",ent,pos)
    end
end)
]]

hook_Add( "UpdateAnimation", "UpdateLookAt_Fix", function( ply )
    ply:SetPoseParameter("head_yaw", 0)
    ply:SetPoseParameter("head_pitch", 0)
end )



hook.Add("PrePlayerDraw", "serj.preplayerdraw", function(ply)
	if ply != me then
        ply.ChatGestureWeight = 0
		for i = 0, 13 do
			if ply:IsValidLayer(i) then
				local seqname = ply:GetSequenceName(ply:GetLayerSequence(i))
				if seqname:StartWith("taunt_") or seqname:StartWith("act_") or seqname:StartWith("gesture_") then
                    ply:SetLayerDuration(i, 0.001)
					break
				end
			end
		end
        
    /*
	elseif ply == me then
        local ndata = ultimate.GetLocalNetworkData()
        //local ntang = Angle( 0, ndata.angles_y, 0 )

        //ply:SetPoseParameter("aim_yaw", ndata.angles_y)
        //ply:SetPoseParameter("head_yaw", ndata.angles_y)

        //ply:SetPoseParameter("aim_pitch", ndata.angles_x)
        //ply:SetPoseParameter("head_pitch", ndata.angles_x)

        ply:InvalidateBoneCache()
        ply:SetupBones()

        ply:SetNetworkOrigin( ndata.origin )
        ply:SetRenderOrigin( ndata.origin )
*/

  


    

    

    
    end
end)


// Chams

CreateMaterial("textured", "VertexLitGeneric") 
CreateMaterial("flat", "UnLitGeneric")
CreateMaterial("flat_z", "UnLitGeneric",{["$ignorez"] = 1})
CreateMaterial("textured_z", "VertexLitGeneric",{["$ignorez"] = 1})

CreateMaterial( "selfillum", "VertexLitGeneric", {
    ["$basetexture"] = "vgui/white_additive",
    ["$bumpmap"] = "vgui/white_additive",
    ["$model"] = "1",
    ["$nocull"] = "0",
    ["$selfillum"] = 1,
    ["$selfIllumFresnel"] = 1,
    ["$selfIllumFresnelMinMaxExp"] = "[0 0.3 0.6]",
    ["$selfillumtint"] = "[0 0 0]",
} )

CreateMaterial( "selfillum_z", "VertexLitGeneric", {
    ["$basetexture"] = "vgui/white_additive",
    ["$bumpmap"] = "vgui/white_additive",
    ["$model"] = "1",
    ["$nocull"] = "0",
    ["$selfillum"] = 1,
    ["$selfIllumFresnel"] = 1,
    ["$selfIllumFresnelMinMaxExp"] = "[0 0.3 0.6]",
    ["$selfillumtint"] = "[0 0 0]",
    ["$ignorez"] = 1,
} )

CreateMaterial( "selfillum_a", "VertexLitGeneric", {
    ["$basetexture"] = "vgui/white_additive",
    ["$bumpmap"] = "vgui/white_additive",
    ["$model"] = "1",
    ["$nocull"] = "1",
    ["$nodecal"] = "1",
    ["$additive"] = "1",
    ["$selfillum"] = 1,
    ["$selfIllumFresnel"] = 1,
    ["$selfIllumFresnelMinMaxExp"] = "[0 0.3 0.6]",
    ["$selfillumtint"] = "[0 0 0]",
} )

CreateMaterial( "selfillum_a_z", "VertexLitGeneric", {
    ["$basetexture"] = "vgui/white_additive",
    ["$bumpmap"] = "vgui/white_additive",
    ["$model"] = "1",
    ["$nocull"] = "1",
    ["$nodecal"] = "1",
    ["$additive"] = "1",
    ["$selfillum"] = 1,
    ["$selfIllumFresnel"] = 1,
    ["$selfIllumFresnelMinMaxExp"] = "[0 0.3 0.6]",
    ["$selfillumtint"] = "[0 0 0]",
    ["$ignorez"] = 1,
} )

CreateMaterial("wireframe", "VertexLitGeneric", {
	["$wireframe"] = 1,
})
CreateMaterial("wireframe_z", "VertexLitGeneric", {
	["$wireframe"] = 1,
    ["$ignorez"] = 1,
})

CreateMaterial("metallic", "UnlitGeneric", {
	["$envmap"] = "env_cubemap",
    ["$normalmapalphaenvmapmask"] = 1,
    ["$envmapcontrast"] = 1,
    ["$color"] = "255 0 0",
})

CreateMaterial("metallic_z", "UnlitGeneric", {
    ["$envmap"] = "env_cubemap",
    ["$normalmapalphaenvmapmask"] = 1,
    ["$envmapcontrast"] = 1,
    ["$color"] = "255 0 0",
    ["$ignorez"] = 1,
})

ultimate.chamMats = {
    vis = {
        Material("!flat"), -- flat
        Material("!textured"), -- textured
        Material("!selfillum"), -- glow
        Material("!selfillum_a"), -- glow outline
        Material("!wireframe"), -- wireframe
        Material("!metallic"), -- metallic
        Material("!selfillum_a"), --  glow pulse
    },
    invis = {
        Material("!flat_z"), -- flat
        Material("!textured_z"), -- textured
        Material("!selfillum_z"), -- glow
        Material("!selfillum_a_z"), -- glow outline
        Material("!wireframe_z"), -- wireframe
        Material("!metallic_z"), -- metallic
        Material("!selfillum_a_z"), -- glow pulse
    }
}

do
    local f = (1/255)

    function ultimate.drawChams()
        local vm, invm = ultimate.cfg.vars["Visible mat"], ultimate.cfg.vars["inVisible mat"]
        local sin = math_floor( math_sin( CurTime() * 4 ) * 45 )

        local vc = string_ToColor(ultimate.cfg.colors["Visible chams"])
        local invc = string_ToColor(ultimate.cfg.colors["inVisible chams"])
        local sc = string_ToColor(ultimate.cfg.colors["Self chams"])
        
        cam_Start3D()
            for k, v in pairs(player_GetAll()) do
                if not IsValid(v) or v == me or not v:Alive() or v:IsDormant() then continue end 

                if ultimate.cfg.vars["Supress lighting"] then
                    render_SuppressEngineLighting(true)
                end

                if ultimate.cfg.vars["inVisible chams"] then
                    render_MaterialOverride(ultimate.chamMats.invis[invm])
                    render_SetColorModulation(invc.r/255,invc.g/255,invc.b/255) 

                    if invm == 7 then
                        render_SetBlend( (sin + 100) / 255 )
                    end

                    v:SetRenderMode(1)
                    v:DrawModel()

                    if ultimate.cfg.vars["inVisible chams w"] then 
                        local w = v:GetActiveWeapon()
                        if IsValid(w) then w:DrawModel() end
                    end
                end

                if ultimate.cfg.vars["Visible chams"] then
                    render_MaterialOverride(ultimate.chamMats.vis[vm])
                    render_SetColorModulation(vc.r/255,vc.g/255,vc.b/255)

                    if vm == 7 then
                        render_SetBlend( (sin + 100) / 255 )
                    end

                    v:DrawModel()

                    if ultimate.cfg.vars["Visible chams w"] then 
                        local w = v:GetActiveWeapon()
                        if IsValid(w) then w:DrawModel() end
                    end
                end

                if ultimate.cfg.vars["Supress lighting"] then
                    render_SuppressEngineLighting(false)
                end

            end

            if ultimate.cfg.vars["Self chams"] and IsValid(me) and me:Alive() then

                if ultimate.cfg.vars["Supress self lighting"] then
                    render_SuppressEngineLighting(true)
                end

                render_MaterialOverride(ultimate.chamMats.vis[ultimate.cfg.vars["Self mat"]])
                render_SetColorModulation(sc.r/255,sc.g/255,sc.b/255)

                if ultimate.cfg.vars["Self mat"] == 7 then
                    render_SetBlend( (sin + 100) / 255 )
                end

                me:SetRenderMode(1)
                me:DrawModel()

                if ultimate.cfg.vars["Self chams w"] then 
                    local w = me:GetActiveWeapon()
                    if IsValid(w) then w:DrawModel() end
                end
              
                if ultimate.cfg.vars["Supress self lighting"] then
                    render_SuppressEngineLighting(false)
                end

            end

            


        cam_End3D()

        render_SetColorModulation(1, 1, 1)
        render_SetBlend(1)
        render_MaterialOverride()
    end
end


// Client side models 

function ultimate.CS_Model(mdl)
    local model = ClientsideModel(mdl)
	model:SetNoDraw(true)

    return model
end

function ultimate.CS_Model_update(ply,model,tbl)
    if !tbl then return end

    local mdl = model
    local playerModel = ply:GetModel()
    local layers = tbl.layers 
    local velocity = ply:GetVelocity()
	local velocityYaw = math_NormalizeAngle(tbl.angles.y - math_deg(math_atan2(velocity.y, velocity.x)))
	local playbackRate = ply:GetPlaybackRate()
	local moveX = math_cos(math_rad(velocityYaw)) * playbackRate
	local moveY = -math_sin(math_rad(velocityYaw)) * playbackRate

    for i = 0, 13 do
        if mdl:IsValidLayer(i) then
            local l = layers[i]
            mdl:SetLayerCycle(l.cycle)
            mdl:SetLayerSequence(l.sequence)
            mdl:SetLayerWeight(l.weight)
        end
    end

    mdl:SetSequence(tbl.sequence)
    mdl:SetCycle(tbl.cycle)

    mdl:SetPoseParameter("aim_pitch", tbl.angles.p)
	mdl:SetPoseParameter("head_pitch", 0)
	mdl:SetPoseParameter("body_yaw", tbl.angles.y)
	mdl:SetPoseParameter("aim_yaw", 0)
		
	mdl:SetPoseParameter("move_x", moveX)
	mdl:SetPoseParameter("move_y", moveY)

    mdl:SetAngles(Angle(0,tbl.angles.y,0))
    mdl:SetModel(playerModel)
	mdl:SetPos(tbl.origin)
end

function ultimate.PostDrawTranslucentRenderables()
    ultimate.drawCSModels_backtrack()
    ultimate.drawCSModels_real()


    render_MaterialOverride()
end


// Backtracking 

ultimate.btrecords = {}


















function ultimate.canBacktrack(ply)
    if not ultimate.cfg.vars["Backtrack"] then return false end 
    if not IsValid(ply) then return false end
    if not ultimate.btrecords[ply] then return false end 
    if ply.break_lc then return false end 

    return true 
end

function ultimate.recordBacktrack(ply)
	local deadtime = CurTime() - ultimate.cfg.vars["Backtrack time"] / 1000
	
	local records = ultimate.btrecords[ply]

	if !records then
        records = {}
		ultimate.btrecords[ply] = records
	end
	
	local i = 1
	while i < #records do
		local record = records[i]
		
		if record.simulationtime < deadtime then
			table_remove(records, i)
			i = i - 1
		end
		
		i = i + 1
	end
	
	if !ply:Alive() then return end
    if ply.break_lc then return end
	
	local simulationtime = ded.GetSimulationTime(ply:EntIndex())
	local len = #records
	local simtimechanged = true

	if len > 0 then
		simtimechanged = records[len].simulationtime < simulationtime
	end
	
	if !simtimechanged then return end

	local layers = {}
	for i = 0, 13 do
		if ply:IsValidLayer(i) then
			layers[i] = {
				cycle = ply:GetLayerCycle(i),
				sequence = ply:GetLayerSequence(i),
				weight = ply:GetLayerWeight(i)
			}
		end
	end

    local eyeAngles = ply:EyeAngles()
    local x,y = eyeAngles.x, eyeAngles.y
		
	records[len + 1] = {
		simulationtime = ded.GetSimulationTime(ply:EntIndex()),
		angles = Angle(x,y,0),
		origin = ply:GetNetworkOrigin(),
		aimpos = ultimate.GetBones( ply )[1],
		sequence = ply:GetSequence(),
		cycle = ply:GetCycle(),
		layers = layers,
        latency = ply:Ping() / 1000
	}
end

ultimate.btmodel = ultimate.CS_Model("models/player/kleiner.mdl")

function ultimate.drawCSModels_backtrack()
    if not ultimate.cfg.vars["Backtrack chams"] then return end 
    if not ultimate.canBacktrack(ultimate.target) then return end

    local len = #ultimate.btrecords[ultimate.target]
    local tbl = ultimate.btrecords[ultimate.target][ultimate.backtracktick]
    local m = ultimate.btmodel

    ultimate.CS_Model_update(ultimate.target,m,tbl)

    if ultimate.cfg.vars["Backtrack fullbright"] then
        render_SuppressEngineLighting(true)
    end

    local col = string_ToColor(ultimate.cfg.colors["Backtrack chams"])
    render_MaterialOverride(ultimate.chamMats.invis[ultimate.cfg.vars["Backtrack material"]]) 
    render_SetColorModulation(col.r/255,col.g/255,col.b/255)
    m:SetRenderMode(1)
    m:DrawModel()

    if ultimate.cfg.vars["Backtrack fullbright"] then
        render_SuppressEngineLighting(false)
    end
end

ultimate.hitmarkers = {}
ultimate.hitnums = {}

gameevent.Listen( "player_hurt" )
hook_Add("player_hurt", "penissss1337", function(data)
    local health = data.health
	local priority = SERVER and data.Priority or 5
	local hurted = Player( data.userid )
	local attackerid = data.attacker

	if attackerid == me:UserID() then

        if ultimate.cfg.vars["Hitmarker"] then
            ultimate.hitmarkers[ #ultimate.hitmarkers + 1 ] = { time = CurTime(), add = 0 }
        end

        if ultimate.cfg.vars["Hitnumbers"] then
            local hp = hurted:Health() - health
            ultimate.hitnums[ #ultimate.hitnums + 1 ] = { time = CurTime(), add = 0, xdir = math_random(-1,1), ydir = math_random(-1,1), dmg = hp, crit = health <= 0 }
        end

        if ultimate.cfg.vars["Hitsound"] then
            surface_PlaySound( ultimate.cfg.vars["Hitsound str"] )
        end

        if ultimate.cfg.vars["Resolver"] then 
            hurted.aimshots = (hurted.aimshots or 0) - 1
        end

    end
end)

/*
    Player vars 
*/

function ultimate.initPlayerVars( v )
    v.ult_prev_pos = Vector()

    v.ult_prev_simtime = 0 
    v.flticks = 0 
    v.aimshots = 0
    v.missedanimticks = 0

    v.break_lc = false 
    v.simtime_updated = false 
    v.fakepitch = false

    ultimate.btrecords[v] = {}
end

for k, v in ipairs(player_GetAll()) do
	ultimate.initPlayerVars( v )
end

// Killsay 

ultimate.killsays = {
    [1] = {
        "I use this https://github.com/MorningStar9994/Glua-Scripts/blob/main/AfricaHooklite.zip",
        "AfricaHook - Protecting the local tribe since 2018",
        "Imagine getting owned by a third world cheat LOL",
        "AfricaHook - Sponsored by General Buttnaked himself",
        "Retarded MPLA faggot owned",
        "Back to picking cotton, melon muncher",
        "Retarded orc niggers getting owned as usual",
        "Look out nigger, the klan's gettin' bigger!",
        "AfricaHook - approved by Yakub himself",
        "Owning crackers since 2018 - Get Good, Get AfricaHook",
    },





}



// Init player vars 
gameevent.Listen("player_spawn")
gameevent.Listen( "player_activate" )
gameevent.Listen( "entity_killed" )

hook.Add( "entity_killed", "entity_killed", function( data ) 
	local aid = data.entindex_attacker 		
	local vid = data.entindex_killed 	

    if aid != vid and Entity(vid):IsPlayer() and aid == me:EntIndex() then
        if ultimate.cfg.vars["Killsay"] then
            local tbl = ultimate.killsays[ ultimate.cfg.vars["Killsay mode"] ]
            local str = tbl[ math_random( 1, #tbl ) ]
            RunConsoleCommand( "say", str )
        end
        
        if ultimate.cfg.vars["Killsound"] then
            surface_PlaySound( ultimate.cfg.vars["Killsound str"] )
        end

        //ultimate.ui.CheckBox( p, "", "Killsay" )
        // ultimate.ui.ComboBox( p, , {"Русский сборник сказок","Rage","Multidir"}, "Killsay mode")
    end
end )



function ultimate.updatePlayerVars( data )
    local id = data.userid  

    local ply = Player( id )

    ply.ult_prev_pos = Vector()
    // ply.ult_prev_hitbox_pos = Vector()
    
    ply.ult_prev_simtime = 0
    ply.flticks = 0
        
    ply.simtime_updated = false
    ply.break_lc = false
    ply.fakepitch = false

    ultimate.btrecords[ply] = {}
end


















// Menu hints 

function ultimate.drawOverlay()
    if not ultimate.frame:IsVisible() then return end

    if not ultimate.hint then
        ultimate.hintText = ""
        return
    end

    surface_SetTextColor(ultimate.Colors[165])
    surface_SetFont("tbfont")

    local tw, th = surface_GetTextSize(ultimate.hintText)

    surface_SetDrawColor(ultimate.Colors[35])
    surface_DrawRect(ultimate.hintX,ultimate.hintY,tw+20,th+10)
    surface_SetDrawColor(ultimate.Colors[54])
    surface_DrawOutlinedRect(ultimate.hintX,ultimate.hintY,tw+20,th+10,1)    

    surface_SetTextPos(ultimate.hintX+10,ultimate.hintY+5)
    surface_DrawText(ultimate.hintText)

    ultimate.hint = false
end


// Gamemode UpdateClientsideAnimation
--[[]
local function RunSandboxAnims(ply, velocity, maxseqgroundspeed)
    local len = velocity:Length()
	local movement = 1.0

	if ( len > 0.2 ) then
		movement = ( len / maxseqgroundspeed )
	end

	local rate = math.min( movement, 2 )

	-- if we're under water we want to constantly be swimming..
	if ( ply:WaterLevel() >= 2 ) then
		rate = math.max( rate, 0.5 )
	elseif ( !ply:IsOnGround() && len >= 1000 ) then
		rate = 0.1
	end

	ply:SetPlaybackRate( rate )

	-- We only need to do this clientside..
	if ( CLIENT ) then
		if ( ply:InVehicle() ) then
			--
			-- This is used for the 'rollercoaster' arms
			--
			local Vehicle = ply:GetVehicle()
			local Velocity = Vehicle:GetVelocity()
			local fwd = Vehicle:GetUp()
			local dp = fwd:Dot( Vector( 0, 0, 1 ) )

			ply:SetPoseParameter( "vertical_velocity", ( dp < 0 && dp || 0 ) + fwd:Dot( Velocity ) * 0.005 )

			-- Pass the vehicles steer param down to the player
			local steer = Vehicle:GetPoseParameter( "vehicle_steer" )
			steer = steer * 2 - 1 -- convert from 0..1 to -1..1
			if ( Vehicle:GetClass() == "prop_vehicle_prisoner_pod" ) then steer = 0 ply:SetPoseParameter( "aim_yaw", math.NormalizeAngle( ply:GetAimVector():Angle().y - Vehicle:GetAngles().y - 90 ) ) end
			ply:SetPoseParameter( "vehicle_steer", steer )

		end
	end
end

function GAMEMODE:UpdateAnimation(plr, velocity, maxSeqGroundSpeed)
    local hResult = self.BaseClass.UpdateAnimation(self, plr, velocity, maxSeqGroundSpeed)

    RunSandboxAnims(plr, velocity, maxSeqGroundSpeed)
    return hResult;
end
]]



/*
    Libs -> Color
*/



//function ultimate.


function ultimate.ColorLerp( first, second )
    local FT = FrameTime() * 350

    first.r = math_Approach( first.r, second.r, FT )
    first.g = math_Approach( first.g, second.g, FT )
    first.b = math_Approach( first.b, second.b, FT )
    first.a = math_Approach( first.a, second.a, FT )

    math_Round( first.r, 0 )
    math_Round( first.g, 0 )
    math_Round( first.b, 0 )
    math_Round( first.a, 0 )

    return first
end

function ultimate.ColorEqual( first, second )
    if first.r != second.r or first.g != second.g or first.b != second.b or first.a != second.a then
        return false
    end

    return true 
end





/* 
    hooks -> Think 
*/

ultimate.ekd = false
ultimate.fbkd = false

// Dancer ( act / taunt spam )

ultimate.nextact = 0
ultimate.actCommands = {"robot","muscle","laugh","bow","cheer","wave","becon","agree","disagree","forward","group","half","zombie","dance","pers","halt","salute"}

// Name changer 

do
    local cooldown = GetConVarNumber("sv_namechange_cooldown_seconds")
    local curtime = CurTime()
    local lastname = me:Name()
    local changed = 0

    local function check(pl,mn,ptbl)
        if pl == me then return false end 

        if pl:Name() == mn then return false end

        if #ptbl > 5 then
            if lastname == pl:Name() then return  false end
        end

        return true
    end

    local function changename(name)
        ded.NetSetConVar("name",name.." ")

        if changed >= 2 then
            changed = 0
            lastname = name
        else
            changed = changed + 1
        end

        curtime = CurTime() + cooldown
    end

    function ultimate.nameChanger() 
        if curtime > CurTime() then return end

        local pltbl = player_GetAll()

        local len = me:Name():len()

        local mname = string.sub(me:Name(),1,len-1)

        local i = math.random(1,#pltbl)

        if not check(pltbl[i],mname,pltbl) then return end

        changename(pltbl[i]:Name())
    end
end

do
    local tply
    local chatdelay = CurTime()
        
    function ultimate.hThink()
        if input_IsKeyDown(KEY_DELETE) and not ultimate.kd then 
            ultimate.togglevisible()
    
            CloseDermaMenus()
        end

        ultimate.kd = input_IsKeyDown(KEY_DELETE)



        if ultimate.IsKeyDown( ultimate.cfg.binds["Ent add"] ) and not ultimate.ekd then
            local tr = me:GetEyeTrace().Entity

            if IsValid( tr ) then 
                local class = tr:GetClass()

                print( ultimate.allowedClasses[ class ] )

                if not ultimate.allowedClasses[ class ] then
                    ultimate.allowedClasses[ class ] = true
                else
                    ultimate.allowedClasses[ class ] = not ultimate.allowedClasses[ class ]
                end
            end
        end

        ultimate.ekd = ultimate.IsKeyDown( ultimate.cfg.binds["Ent add"] )

        if ultimate.IsKeyDown( ultimate.cfg.binds["Fullbright"] ) and not ultimate.fbkd then
            ultimate.fbe = not ultimate.fbe
        end

        ultimate.fbkd = ultimate.IsKeyDown( ultimate.cfg.binds["Fullbright"] )

        if ultimate.cfg.vars["FSpec ClickTP"] and ultimate.IsKeyDown( ultimate.cfg.binds["FSpec ClickTP"] ) then
            local pos = me:GetEyeTrace().HitPos
            
            print(pos)

            //RunConsoleCommand( "ba", "spec" )

            RunConsoleCommand( "FTPToPos", string_format("%d, %d, %d", pos.x, pos.y, pos.z), string_format("%d, %d, %d", 0, 0, 0) )
        end

        
        
        // ultimate.cfg.vars["FSpec Teleport"] = false
        // ultimate.cfg.binds["FSpec Teleport"] = 0
        
        // ultimate.cfg.vars["FSpec Masskill"] = false
        // ultimate.cfg.binds["FSpec Masskill"] = 0
        
        // ultimate.cfg.vars["FSpec Velocity"] = false
        // ultimate.cfg.binds["FSpec Velocity"] = 0

        if ultimate.cfg.vars["Chat spammer"] and CurTime() > chatdelay then
            local s = ultimate.cfg.vars["Chat OOC"] and "// " or ""

            RunConsoleCommand("say",s.."AfricaHook Lite owning crackers since 2018")

            chatdelay = CurTime() + 0.5
        end
    
        if ultimate.cfg.vars["Name stealer"] then ultimate.nameChanger() end
    
        if ultimate.cfg.vars["Tickbase shift"] then
    
            ded.StartShifting(ultimate.IsKeyDown( ultimate.cfg.binds["Tickbase shift"] ))
    
           
            if  !ded.GetIsShifting() and ultimate.cfg.vars["Passive recharge"] and ded.GetCurrentCharge() < ultimate.cfg.vars["Maximum Shift Ticks"] then
                ded.StartRecharging(true)
            end
        end
    
        if ultimate.cfg.vars["Taunt spam"] and ultimate.nextact < CurTime() and me:Alive() and !me:IsPlayingTaunt() then 
            local act = ultimate.actCommands[ultimate.cfg.vars["Taunt"]]
    
            RunConsoleCommand("act", act)
            ultimate.nextact = CurTime() + 0.3
        end
    
        if ultimate.cfg.vars["Yaw base"] == 2 then
            tply = ultimate.GetSortedPlayers( 1, 0, 1, false ) 
    
            if tply then
                ultimate.aatarget = tply[1][1]
            end
        end

        if ultimate.cfg.vars["Auto peak"] then
            ultimate.autopeakThink()
        end
    end
end


/*
    hooks -> CalcView
*/

ultimate.vieworigin = me:EyePos()

ultimate.tpenabled = false
ultimate.tptoggled = false

ultimate.fcvector = me:EyePos()
ultimate.fcangles = me:EyeAngles()
ultimate.fcenabled = false
ultimate.fctoggled = false


/* // TODO
ultimate.checkbox("Collision","Third person collision",p:GetItemPanel())
ultimate.checkbox("Smoothing","Third person smoothing",p:GetItemPanel())

ultimate.slider("X","Viewmodel x",1,180,0,p:GetItemPanel())
ultimate.slider("Y","Viewmodel y",1,180,0,p:GetItemPanel())
ultimate.slider("Z","Viewmodel z",1,180,0,p:GetItemPanel())
ultimate.slider("Roll","Viewmodel r",1,360,0,p:GetItemPanel())
*/

function ultimate.hCalcView( ply, origin, angles, fov, znear, zfar )
    local view = {}

    local tppressed = ultimate.IsKeyDown(ultimate.cfg.binds["Third person"])
    local fcpressed = ultimate.IsKeyDown(ultimate.cfg.binds["Free camera"])

    if ultimate.cfg.vars["Third person"] and tppressed and not ultimate.tptoggled then
        ultimate.tpenabled = not ultimate.tpenabled
    end

    if ultimate.cfg.vars["Free camera"] and fcpressed and not ultimate.fctoggled then
        ultimate.fcenabled = not ultimate.fcenabled
        ultimate.fcangles = me:EyeAngles()
    elseif ultimate.fcenabled and not ultimate.cfg.vars["Free camera"] then
        ultimate.fcenabled = false
    end

    ultimate.tptoggled = tppressed
    ultimate.fctoggled = fcpressed


    if ultimate.cfg.vars["Fake duck"] and ultimate.IsKeyDown(ultimate.cfg.binds["Fake duck"]) then
        origin.z = me:GetPos().z + 64
    end

    local fangs = ultimate.cfg.vars["Silent aim"] and ultimate.fa or angles

    if ultimate.fcenabled then
        local speed = ultimate.cfg.vars["Free camera speed"]
        
        if input_IsKeyDown(KEY_W) then
            ultimate.fcvector = ultimate.fcvector + ultimate.fa:Forward() * speed
        end

        if input_IsKeyDown(KEY_S) then
            ultimate.fcvector = ultimate.fcvector - ultimate.fa:Forward() * speed
        end

        if input_IsKeyDown(KEY_A) then
            ultimate.fcvector = ultimate.fcvector - ultimate.fa:Right() * speed
        end

        if input_IsKeyDown(KEY_D) then
            ultimate.fcvector = ultimate.fcvector + ultimate.fa:Right() * speed
        end

        if input_IsKeyDown(KEY_SPACE) then
            ultimate.fcvector = ultimate.fcvector + Vector(0,0,speed)
        end

        if input_IsKeyDown(KEY_LSHIFT) then
            ultimate.fcvector = ultimate.fcvector - Vector(0,0,speed)
        end

        view.origin = ultimate.fcvector
        view.angles = fangs
        view.drawviewer = true
    else
        ultimate.fcvector = origin

        view.origin = ultimate.tpenabled and origin - ( (fangs):Forward() * ultimate.cfg.vars["Third person distance"] ) or origin
        view.angles = fangs
        view.drawviewer = ultimate.tpenabled
    end

    ultimate.vieworigin = origin

	return view
end

/*
    hooks -> CalcViewModelView
*/

function ultimate.hCalcViewModelView(wep, vm, oldPos, oldAng, pos, ang)
    pos = ultimate.vieworigin 
	ang = ultimate.cfg.vars["Silent aim"] and ultimate.fa or ang

	return pos, ang
end

/*
    hooks -> Pre / Post DrawViewModel
*/

do
    local drawing = false

    function ultimate.hPreDrawViewModel( vm, ply, w )
        if ply != me then return end

        if ultimate.cfg.vars["Viewmodel chams"] then
            local col = string_ToColor( ultimate.cfg.colors["Viewmodel chams"] )
            local mat = ultimate.chamMats.vis[ultimate.cfg.vars["Viewmodel chams type"]] 

            render_SetBlend(col.a/255)
            render_SetColorModulation(col.r/255,col.g/255,col.b/255)
            render_MaterialOverride(mat)
        end

        if ultimate.cfg.vars["Fullbright viewmodel"] then
            render_SuppressEngineLighting( true )
        end
      end
    end

        

function ultimate.hPostDrawViewModel( vm, ply, w )
    render_SetColorModulation(1, 1, 1)
    render_MaterialOverride()
    render_SetBlend(1)
    render_SuppressEngineLighting(false)
end

/*
    hooks -> RenderScene
*/

// Skybox changer 



do
    local oldsky, oldskycolor, oldwallcolor = ultimate.cfg.vars["Custom sky"], ultimate.cfg.vars["Sky color"], ultimate.cfg.vars["Wall color"]
    local oldskyclr, oldwallclr = ultimate.cfg.colors["Sky color"], ultimate.cfg.colors["Wall color"]

    local worldcollerp = string_ToColor( ultimate.cfg.colors["Wall color"] )
    local worldmats = Entity( 0 ):GetMaterials()

    local origsky = GetConVar("sv_skyname"):GetString()
    local tsides = {"lf", "ft", "rt", "bk", "dn", "up"}
    local skymat = {}

    for i = 1, 6 do 
        skymat[i] = Material("skybox/" .. origsky .. tsides[i]) 
    end

    local function setSkyboxTexture( skyname )
        for i = 1, 6 do
            local t = Material("skybox/" .. skyname .. tsides[i]):GetTexture("$basetexture")
            skymat[i]:SetTexture("$basetexture", t)
        end
    end

    local function setSkyColor( setcolor )
        local cfg = string_ToColor( ultimate.cfg.colors["Sky color"] )
        local vector = setcolor and Vector( cfg.r/255, cfg.g/255, cfg.b/255 ) or Vector( 1, 1, 1 )

        for i = 1, 6 do
            skymat[i]:SetVector( "$color", vector )
        end
    end

    local function setWallColor( setcolor )
        local cfg = string_ToColor( ultimate.cfg.colors["Wall color"] )
        worldcollerp = ultimate.ColorLerp( worldcollerp, cfg )
        local vector = setcolor and Vector( worldcollerp.r/255, worldcollerp.g/255, worldcollerp.b/255 ) or Vector( 1, 1, 1 )

        for i = 1, #worldmats do
            local value = worldmats[i]

            Material( value ):SetVector( "$color", vector )
            Material( value ):SetFloat( "$alpha", setcolor and (cfg.a / 255) or 255 )
        end
    end

    function ultimate.hRenderScene()
        local newname, newcolor, newcolor2 = ultimate.cfg.vars["Custom sky"], ultimate.cfg.vars["Sky color"], ultimate.cfg.vars["Wall color"]
        local newskyclr, newwallclr = ultimate.cfg.colors["Sky color"],ultimate.cfg.colors["Wall color"]
        
        if newskyclr != oldskyclr or newcolor != oldskycolor then
            setSkyColor( newcolor )

            oldskyclr = newskyclr
            oldskycolor = newcolor
        end

        if newwallclr != tostring( worldcollerp ) or newcolor2 != oldwallcolor then
            setWallColor( newcolor2 )

            oldwallcolor = newcolor2
        end

        if newname != oldsky then
            setSkyboxTexture( newname )
            oldsky = newname
        end
    
       

    end


end

/*
    hooks -> OnImpact ( c++ module )
*/

ultimate.bulletImpacts = {}

function ultimate.hOnImpact( data )
    ultimate.bulletImpacts[#ultimate.bulletImpacts + 1] = {
        shootTime = CurTime(),
        startPos = data.m_vStart,
        endPos = data.m_vOrigin,
        hitbox = data.m_nHitbox,
        alpha = 255
    }
end


/*
    hooks -> PostDrawOpaqueRenderables
*/

do
    local oldtrmat = ultimate.cfg.vars["Bullet tracers material"]
    local tracemat = Material("sprites/tp_beam001")

    function ultimate.hPostDrawOpaqueRenderables()
        
        if ultimate.cfg.vars["Bullet tracers"] then
            local trmat = ultimate.cfg.vars["Bullet tracers material"] 
    
            if trmat != oldtrmat then
                tracemat = Material( trmat )
                oldtrmat = trmat
            end
    
            local tracercolor = string_ToColor(ultimate.cfg.colors["Bullet tracers"])
    
            local curTime = CurTime()
            local dieTime = ultimate.cfg.vars["Tracers die time"]
    
            for i = #ultimate.bulletImpacts, 1, -1 do
                local impact = ultimate.bulletImpacts[i]

                // impact.alpha = impact.alpha - 0.15

                if (curTime - impact.shootTime) > dieTime then
                    table_remove(ultimate.bulletImpacts, i)
                    continue
                end

                tracercolor.a = impact.alpha
    
                render_SetMaterial( tracemat ) 
                render_DrawBeam( impact.startPos, impact.endPos, 4, 1, 1, tracercolor )
            end
        end

        if ultimate.cfg.vars["Auto peak"] and ultimate.startedPeeking then
            ultimate.drawAutopeak()
        end


    end 
end

/*
    hooks -> FrameStageNotify ( c++ module )
*/

// Player data tables 

ultimate.playerCache = {}
function ultimate.playerTableUpdate( ply )
    ultimate.playerCache[ ply ].Name = ply:Name()

    local t = ply:Team()

    ultimate.playerCache[ ply ].Team = t
    ultimate.playerCache[ ply ].TeamColor = team_GetColor( t ) 
    ultimate.playerCache[ ply ].TeamName = team_GetName( t )

    ultimate.playerCache[ ply ].GetUserGroup = ply:GetUserGroup()

    ultimate.playerCache[ ply ].Health = ply:Health()
    ultimate.playerCache[ ply ].GetMaxHealth = ply:GetMaxHealth()


    ultimate.playerCache[ ply ].Armor = ply:Armor()
    ultimate.playerCache[ ply ].GetMaxArmor = ply:GetMaxArmor()

    ultimate.playerCache[ ply ].GetPos = ply:GetPos()

    local w = ply:GetActiveWeapon()

    ultimate.playerCache[ ply ].WeaponClass = IsValid(w) and w:GetClass() or "Unarmed"
end

function ultimate.playerDataUpdate( ply )
    if not ultimate.playerCache[ ply ] then
        ultimate.playerCache[ ply ] = {}

        ultimate.playerTableUpdate( ply )
        return
    end

    ultimate.playerTableUpdate( ply )
end

// Entity data

ultimate.entityCache = {}
ultimate.allowedClasses = {}

function ultimate.entTableUpdate()
    local entitys = ents_GetAll()

    ultimate.entityCache = {}

    for i = 1, #entitys do
        local ent = entitys[ i ]

        if not ultimate.allowedClasses[ ent:GetClass() ] then continue end

        ultimate.entityCache[ #ultimate.entityCache + 1 ] = {
            entity = ent,
            class = ent:GetClass(),
            position = ent:GetPos(),
        }
    end
end

ultimate.cfg.vars["Ent box"] = false
ultimate.cfg.vars["Ent class"] = false

ultimate.cfg.vars["Ent ESP Distance"] = 3500


// Resolver 

ultimate.bruteYaw = { -90, 0, 90, 180, -180, 180, 90, 0, -90 }

















do
    local localData = {}

    localData.origin = Vector()

    function ultimate.FillLocalNetworkData( netdata )
        localData.origin     =   netdata[1]
    end
    
    function ultimate.GetLocalNetworkData()
        return localData
    end
end


do
    local missedTicks = 0
    local lastSimTime = 0

    local FRAME_START = 0
    local FRAME_NET_UPDATE_START = 1
    local FRAME_NET_UPDATE_POSTDATAUPDATE_START = 2
    local FRAME_NET_UPDATE_POSTDATAUPDATE_END = 3
    local FRAME_NET_UPDATE_END = 4
    local FRAME_RENDER_START = 5
    local FRAME_RENDER_END = 6

    function ultimate.hFrameStageNotify( stage )
        local plys = player.GetAll()

        if stage == FRAME_NET_UPDATE_POSTDATAUPDATE_END then

            ultimate.entTableUpdate()

            plys = player.GetAll()

            local orig = me:GetNetworkOrigin()

            local data = {}

            data[1] = orig      // last networked origin

            ultimate.FillLocalNetworkData( data )

            for i = 1, #plys do
                local v = plys[i]

                //if !v.ult_prev_pos then continue end

                local cur_simtime = ded.GetSimulationTime(v:EntIndex())
                local cur_pos = v:GetNetworkOrigin()

                --v.ult_cur_pos = cur_pos

                if not v.ult_prev_simtime then
                    v.ult_prev_simtime = cur_simtime
                    v.ult_prev_pos = cur_pos
                    // v.ult_prev_hitbox_pos = cur_pos
                    v.flticks = 0
                    v.missedanimticks = 0
                    v.simtime_updated = false 
                    v.break_lc = false
                    ultimate.btrecords[v] = {}
                    v.aimshots = 0
                    v.fakepitch = v:EyeAngles().p > 90

                elseif v.ult_prev_simtime != cur_simtime then
                    local flticks = ultimate.TIME_TO_TICKS(cur_simtime-v.ult_prev_simtime)

                    // print(v,flticks )

                    //ded.SetUpdateTicks( flticks )
                    //ded.ShouldUpdateAnimation( true )

                    v.flticks = math_Clamp(flticks,1,24)

                    v.ult_prev_simtime = cur_simtime

                    v.break_lc = cur_pos:DistToSqr(v.ult_prev_pos) > 4096

                    --if v.ult_prev_pos != v.ult_cur_pos then
                    v.ult_prev_pos = cur_pos

                    // v.ult_prev_hitbox_pos = ultimate.getHitbox(v)
                    --end 
                    v.fakepitch = v:EyeAngles().p > 90

                    v.simtime_updated = true
                else
                    v.simtime_updated = false
                end

                if ultimate.canBacktrack(v) and v != me and v.simtime_updated then
                    ultimate.recordBacktrack(v)
                end

                if v.break_lc then
                    ultimate.btrecords[ v ] = {}
                end
            end

            

        elseif stage == FRAME_RENDER_START then
            plys = player.GetAll()

            for i = 1, #plys do
                local v = plys[i]

                if v == me then continue end

                if ultimate.cfg.vars["Forwardtrack"] then
                    local predTime = ( ded.GetLatency(0) + ded.GetLatency(1)) * ultimate.cfg.vars["Forwardtrack time"]
                    ded.StartSimulation( v:EntIndex() )
    
                    local prevPos = v:GetNetworkOrigin()
                    for tick = 1, ultimate.TIME_TO_TICKS(predTime) do
                        ded.SimulateTick()
    
                        local data = ded.GetSimulationData()
                        debugoverlay.Line(prevPos, data.m_vecAbsOrigin, 0.1, color_white, true)
    
                        prevPos = data.m_vecAbsOrigin
                    end
    
                    local data = ded.GetSimulationData()

                    print(data.m_vecAbsOrigin)

                    //v:SetRenderOrigin(data.m_vecAbsOrigin)
                    //v:SetNetworkOrigin(data.m_vecAbsOrigin)
    
                    ded.FinishSimulation()
                end

                if ultimate.cfg.vars["Resolver"] then

                    local angs = Angle()
                    angs.y = ultimate.bruteYaw[ v.aimshots % #ultimate.bruteYaw + 1 ] + v:EyeAngles().y

                    v:SetRenderAngles( angs )
                    // v:SetNetworkAngles( angs )

                    ded.SetCurrentLowerBodyYaw( v:EntIndex(), angs.y )

                    if ultimate.cfg.vars["Pitch resolver"] and v.fakepitch then
                        v:SetPoseParameter( "aim_pitch", -89 )
                        v:SetPoseParameter( "head_pitch", -89 )
                    end

                    

                    // ultimate.combobox( "Yaw mode", { "Step", "Delta brute" }, "Yaw mode", p:GetItemPanel() )
                    // ultimate.slider( "Max misses", "Resolver max misses", 1, 6, 0, p:GetItemPanel() )

                    // ultimate.checkbox( "Invert first shot", "Invert first shot", p:GetItemPanel() )


                    v:InvalidateBoneCache()
                    // v:SetupBones()
                end

            end

            


	        
            // Extrapolate aim target vector 
            /*
if ultimate.cfg.vars["Extrapolation"] and ultimate.target and ultimate.targetVector then
                local t = ultimate.target 

                if t.break_lc then
                    local predTicks = ultimate.TIME_TO_TICKS( ded.GetLatency(0) + ded.GetLatency(1) ) // ultimate.TIME_TO_TICKS( ded.GetLatency(0) + ded.GetLatency(1) ) / t.flticks

                    ded.StartSimulation(t:EntIndex())
    
                    for tick = 1, predTicks do
                        ded.SimulateTick()
                    end
    
                    local data = ded.GetSimulationData()

                    print("[pre set] network" , t:GetNetworkOrigin(), "render", t:GetRenderOrigin())

                    t:SetRenderOrigin(data.m_vecAbsOrigin)
                    t:SetNetworkOrigin(data.m_vecAbsOrigin)    
    
                    // v:InvalidateBoneCache()
                    // v:SetupBones()

                    ultimate.extrapolatedVector = ultimate.getHitbox(t)

                    print("[pre finish] network" , t:GetNetworkOrigin(), "render", t:GetRenderOrigin())

                    ded.FinishSimulation()

                    print("[post finish] network" , t:GetNetworkOrigin(), "render", t:GetRenderOrigin())
               
               //ultimate.extrapolatedVector = t.ult_prev_hitbox_pos

                end
            end
            */
            


            // Anim fix 

            
            

            // [pre set] network	-453.500000 1271.375000 1.031250	render	-465.303375 1267.841431 1.031250
            // [pre finish] network	-465.303375 1267.841431 1.031250	render	-465.303375 1267.841431 1.031250
            // [post finish] network	-453.500000 1271.375000 1.000000	render	-465.303375 1267.841431 1.031250


         end
    end
end

function ultimate.hPostFrameStageNotify( stage ) 
    if stage != 3 then return end
    
    local plys = player_GetAll()

    for i = 1, #plys do
        local v = plys[i]

        if v == me then continue end
        
        ultimate.playerDataUpdate( v )
    end

end

/*
    hooks -> ShouldUpdateAnimation ( cpp )

    lua->PushNumber(globals::updateTicks);
	lua->PushUserType(self, Type::Entity);
	lua->PushNumber(globals::shouldUpdateAnimation && 1 or 0);

*/

function ultimate.hShouldUpdateAnimation( entIndex ) 
    local ent = Entity( entIndex )

    // print(ent, ent.simtime_updated, ent.flticks)

    if not ent.simtime_updated then return end

    ded.AllowAnimationUpdate( true )
    --ded.SetMissedTicks( ent.missedanimticks)
end

// AA shit
ultimate.realModel = ultimate.CS_Model( me:GetModel() )
ultimate.newModel = me:GetModel()

function ultimate.drawCSModels_real()
    if not ultimate.cfg.vars["Anti aim chams"] then return end 
    if not me:Alive() then return end

    local mymodel = me:GetModel()

    if ultimate.newModel != mymodel then
        ultimate.CS_Model( mymodel )
        ultimate.newModel = mymodel
    end

    local layers = {}

	for i = 0, 13 do
		if me:IsValidLayer(i) then
			layers[i] = {
				cycle = me:GetLayerCycle(i),
				sequence = me:GetLayerSequence(i),
				weight = me:GetLayerWeight(i)
			}
		end
	end

    local tbl = {
        layers = layers,
        angles = ultimate.mbreal,
        sequence = me:GetSequence(),
        cycle = me:GetCycle(),
        origin = me:GetNetworkOrigin(),
    }

    ultimate.CS_Model_update( me, ultimate.realModel, tbl )

    if ultimate.cfg.vars["Backtrack fullbright"] then
        render_SuppressEngineLighting(true)
    end

    local col = string_ToColor(ultimate.cfg.colors["Backtrack chams"])
    render_MaterialOverride(ultimate.chamMats.invis[ultimate.cfg.vars["Backtrack material"]]) 
    render_SetColorModulation(col.r/255,col.g/255,col.b/255)
    ultimate.realModel:SetRenderMode(1)
    ultimate.realModel:DrawModel()

    if ultimate.cfg.vars["Backtrack fullbright"] then
        render_SuppressEngineLighting(false)
    end
end

/*
    hooks -> PostDrawEffects
*/

do
    /*
            

    */

    local CopyMat		= Material("pp/copy")
    local AddMat		= Material( "pp/add" )
    local SubMat		= Material( "pp/sub" )
    local OutlineMat	= CreateMaterial("OutlineMat","UnlitGeneric",{["$ignorez"] = 1,["$alphatest"] = 1})

    local outline_mats = {
        [1] = OutlineMat,
        [2] = SubMat,
        [3] = AddMat,
        [4] = GradMat,
        [5] = BloomMat,
    }

    local subclear = {
        [2] = true,
        //[4] = true,
    }
    
    ultimate.cfg.vars["Player outline"] = false
    ultimate.cfg.vars["Entity outline"] = false
    ultimate.cfg.colors["Player outline"] = "45 255 86 255"
    ultimate.cfg.colors["Entity outline"] = "255 86 45 255"

    local StoreTexture	= render.GetScreenEffectTexture(0)
    local DrawTexture	= render.GetScreenEffectTexture(1)

    function ultimate.RenderOutline()
        local renderEnts = {}

        if ultimate.cfg.vars["Player outline"] then
            local plys = player.GetAll()

            for i = 1, #plys do 
                local v = plys[ i ]

                if not IsValid( v ) or v == me or not v:Alive() or v:IsDormant() then continue end

                renderEnts[ #renderEnts + 1 ] = v
            end
        end

        if ultimate.cfg.vars["Entity outline"] then
            for i = 1, #ultimate.entityCache do
                local v = ultimate.entityCache[ i ].entity 

                if not IsValid( v ) or v:IsDormant() then continue end
        
                renderEnts[ #renderEnts + 1 ] = v
            end
        end

        if #renderEnts == 0 then return end

        local scene = render.GetRenderTarget()
        render.CopyRenderTargetToTexture(StoreTexture)
        
        if subclear[ ultimate.cfg.vars["Outline style"] ] then
            render.Clear( 255, 255, 255, 255, true, true )
        else
            render.Clear( 0, 0, 0, 0, true, true )
        end

        render.SetStencilEnable(true)
            cam_IgnoreZ(true)
            render.SuppressEngineLighting(true)
        
            render.SetStencilWriteMask(255)
            render.SetStencilTestMask(255)
            
            render.SetStencilCompareFunction(STENCIL_ALWAYS)
            render.SetStencilFailOperation(STENCIL_KEEP)
            render.SetStencilZFailOperation(STENCIL_REPLACE)
            render.SetStencilPassOperation(STENCIL_REPLACE)
            
            cam_Start3D()
                for i = 1, #renderEnts do 
                    render.SetStencilReferenceValue( i )

                    renderEnts[i]:DrawModel()
                end
            cam_End3D()
            
            render.SetStencilCompareFunction(STENCIL_EQUAL)
            
            cam_Start2D()
                for i = 1, #renderEnts do 
                    local c = renderEnts[i]:IsPlayer() and string_ToColor( ultimate.cfg.colors["Player outline"] ) or string_ToColor( ultimate.cfg.colors["Entity outline"] ) 

				    render.SetStencilReferenceValue( i )

                    surface_SetDrawColor( c )
                    surface_DrawRect( 0, 0, scrw, scrh )
                end
            cam_End2D()
            
            render_SuppressEngineLighting(false)
            cam_IgnoreZ(false)
        render.SetStencilEnable(false)
        
        render.CopyRenderTargetToTexture(DrawTexture)

        if ultimate.cfg.vars["Outline style"] > 1 then 
            render.BlurRenderTarget( DrawTexture, 1, 1, 1 )
        end

        render.SetRenderTarget(scene)
        CopyMat:SetTexture("$basetexture",StoreTexture)
        render.SetMaterial(CopyMat)
        render.DrawScreenQuad()
        
        render.SetStencilEnable(true)
            render.SetStencilReferenceValue(0)
            render.SetStencilCompareFunction(STENCIL_EQUAL)
            
            local mat = outline_mats[ ultimate.cfg.vars["Outline style"] ]

            mat:SetTexture( "$basetexture", DrawTexture )
            render_SetMaterial( mat )
            
            for x=-1,1 do
                for y=-1,1 do
                    if x==0 and x==0 then continue end
                    
                    render.DrawScreenQuadEx(x,y,scrw,scrh)
                end
            end
        render.SetStencilEnable(false)
    end
end

function ultimate.hPostDrawEffects()
    if not ultimate.cfg.vars["Player outline"] and not ultimate.cfg.vars["Entity outline"] then return end

    ultimate.RenderOutline()
end
    
/*
    hooks -> FireBullets ( Player cpp ) 
*/

//function ultimate.hFireBullets( data )
//    PrintTable(data)
//end

/*
    Misc hooks
*/

function ultimate.DSADJ( s )
    return ultimate.cfg.vars["Disable SADJ"] and -1 or nil
end

ultimate.lmc = false 
ultimate.fbe = false

function ultimate.PreRender()
    if ultimate.cfg.vars["Fullbright"] or ultimate.fbe then
        render.SetLightingMode( 1 )
        ultimate.lmc = true
    end
end

function ultimate.PostRender()
    if ultimate.lmc then
        render.SetLightingMode( 0 )
        ultimate.lmc = false
    end
end


/*
    ConVar manipulation 
*/

// ded.ConVarSetFlags( "mat_fullbright", 0 )
ded.ConVarSetFlags( "cl_showhitboxes", 0 )




// Gamemode hooks

function GAMEMODE:CreateMove( cmd ) return true end
function GAMEMODE:CalcView( view )  return true end
function GAMEMODE:ShouldDrawLocal() return true end

// Hooks 

hook_Add( "Think",                      "hThink",                       ultimate.hThink )
hook_Add( "CalcView",                   "hCalcView",                    ultimate.hCalcView)
hook_Add( "CalcViewModelView",          "hCalcViewModelView",           ultimate.hCalcViewModelView)
hook_Add( "PreDrawViewModel",           "hPreDrawViewModel",            ultimate.hPreDrawViewModel)
hook_Add( "PostDrawViewModel",          "hPostDrawViewModel",           ultimate.hPostDrawViewModel)
hook_Add( "RenderScene",                "hRenderScene",                 ultimate.hRenderScene)
hook_Add( "PostDrawOpaqueRenderables",  "hPostDrawOpaqueRenderables",   ultimate.hPostDrawOpaqueRenderables)
hook_Add( "PostDrawEffects",            "hPostDrawEffects",             ultimate.hPostDrawEffects)

hook_Add( "OnImpact",                   "hOnImpact",                    ultimate.hOnImpact)
hook_Add( "PreFrameStageNotify",        "hFrameStageNotify",            ultimate.hFrameStageNotify)
hook_Add( "PostFrameStageNotify",       "hPostFrameStageNotify",        ultimate.hPostFrameStageNotify)

hook_Add( "ShouldUpdateAnimation",      "hShouldUpdateAnimation",       ultimate.hShouldUpdateAnimation)
//hook_Add( "FireBullets",                "hFireBullets",                 ultimate.hFireBullets)

hook_Add( "AdjustMouseSensitivity",     "hDSADJ",                       ultimate.DSADJ )

hook_Add( "RenderScreenspaceEffects", "ult_drawChams", ultimate.drawChams )
hook_Add( "PostDrawTranslucentRenderables", "ult_drawCSModels", ultimate.PostDrawTranslucentRenderables )
//hook_Add( "player_activate", "ult_playerSpawn", ultimate.updatePlayerVars )
hook_Add( "DrawOverlay", "ult_overlay", ultimate.drawOverlay )

hook_Add( "PreRender", "PreRenderHook", ultimate.PreRender )
hook_Add( "PostRender", "PostRenderHook", ultimate.PostRender )
hook_Add( "PreDrawHUD", "PreDrawHUDHook", ultimate.PostRender )

hook.Add("PreEndScene","Dildooooon",function()
    cam.Start2D()

        surface.SetDrawColor( 0, 0, 0, 255 )
        surface.DrawRect( 0, 0, 512, 512 )

        surface.SetDrawColor( 255, 0, 0, 255 )
        surface.DrawRect( 0, 0, 256, 256 )

    cam.End2D()
end)