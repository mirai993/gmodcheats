--[[
	lua/lol.txt
	-Batman | (STEAM_0:0:25159057)
	===DStream===
]]


//////////////////////////////////////
//argonMini - Garry's Mod 13 Edition!
////////////

require( "horse" )

local T = {
	weapons = {},
	targets = {},
}

local Funcs = {
['string' ] = string,
['hook'] = hook,
['table'] = table,
['math'] = math,
['timer'] = timer,
['player'] = player,
['input'] = input,
['string'] = string,
['draw'] = draw,
['team'] = team,
['surface'] = surface,
['timer'] = timer,
['concommand'] = concommand
}

local Bones = {}
Bones['Head'] = "ValveBiped.Bip01_Head1"
Bones['Pelvis'] = "ValveBiped.Bip01_Pelvis"
Bones['Spine'] = "ValveBiped.Bip01_Spine"
Bones['Spine1'] = "ValveBiped.Bip01_Spine1"
Bones['Spine2'] = "ValveBiped.Bip01_Spine2"
Bones['Spine4'] = "ValveBiped.Bip01_Spine4"
Bones['Neck1'] = "ValveBiped.Bip01_Neck1"

local function Get( func )
	if Funcs[ func ] then
		return Funcs[ func ]
	end
end

local ESPOn = CreateClientConVar( "espon", 1, true, false )
local SA = CreateClientConVar( "argon_sa", 1, true, false )
local HPBar = CreateClientConVar( "argon_hpbar", 1, true, false )
local HP = CreateClientConVar( "argon_hp", 1, true, false )
local CurrWep = CreateClientConVar( "argon_currwep", 0, true, false )
local ESPISF = CreateClientConVar( "argon_espisf", 1, true, false )
local Elev = CreateClientConVar( "argon_elev", 0, true, false )
local MoneyFind = CreateClientConVar( "argon_esp_printer", 0, true, false )
local DollarFind = CreateClientConVar( "argon_esp_money", 0, true, false )
local ShipmentFind = CreateClientConVar( "argon_esp_shipment", 0, true, false )
local ESPDist = CreateClientConVar( "argon_esp_dist", 500000, true, false )
local ESPDistOn = CreateClientConVar( "argon_esp_diston", 1, true, false )
local ESPDistMem = CreateClientConVar( "argon_esp_distmem", 500000, true, false )
local C4Check = CreateClientConVar( "argon_esp_c4", 0, true, false )

local function ColorHealth( ent )
	if ent:Health() >= 75 then
		col = Color( 102, 255, 51, 255 )
	elseif ent:Health() >= 35 and ent:Health() < 75 then
		col = Color( 255, 255, 61, 255 )
	elseif ent:Health() < 35 then
		col = Color( 255, 0, 0, 255 )
	end
end

local function ESP()
	if ESPOn:GetBool() then
		for k, v in ipairs( player.GetAll() ) do
			if v == LocalPlayer() then continue end
			--
			if ( v:Alive() ) && ( v:Team() != TEAM_SPECTATOR ) then
				if ( LocalPlayer():GetPos():Distance( v:GetPos() ) <= ESPDist:GetInt() ) then
					
					PlyLoc = v:EyePos():ToScreen()
					if ( !HP:GetBool() ) then
						draw.SimpleText( v:Nick(), "ChatFont", PlyLoc.x, PlyLoc.y, team.GetColor( v:Team() ), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER )
					else
						draw.SimpleText( v:Nick() .. ", HP: " .. v:Health(), "ChatFont", PlyLoc.x, PlyLoc.y, team.GetColor( v:Team() ), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER )
					end
					--
					if ( SA:GetBool() ) then
						if ( v:IsAdmin() && v:GetFriendStatus() != "friend" ) then
							draw.SimpleText( "*Admin*", "BudgetLabel", PlyLoc.x, PlyLoc.y - 15, Color( 0, 150, 255, 255 ), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER )
						end
					end
					--
					if ( ESPISF:GetBool() ) then
						if ( v:IsAdmin() && v:GetFriendStatus() == "friend" ) then
							draw.SimpleText( "*Friend/Admin*", "BudgetLabel", PlyLoc.x, PlyLoc.y - 15, Color( 0, 150, 255, 255 ), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER )
						elseif ( !v:IsAdmin() && v:GetFriendStatus() == "friend" ) then
							draw.SimpleText( "*Friend*", "BudgetLabel", PlyLoc.x, PlyLoc.y - 15, Color( 0, 150, 255, 255 ), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER )
						end
					end
					if ( HPBar:GetBool() ) then
						--
						ColorHealth( v )
						--
						surface.SetDrawColor( col )
						if ( !CurrWep:GetBool() ) then
							surface.DrawRect( PlyLoc.x - 13.5, PlyLoc.y + 10, v:Health() / 4, 4 )
							surface.SetDrawColor( Color( 0, 0, 0, 255 ) )
							surface.DrawOutlinedRect( PlyLoc.x - 13.5, PlyLoc.y + 10, 25, 4 )
						else
							surface.DrawRect( PlyLoc.x - 15, PlyLoc.y + 10, 4, v:Health() / 4 )
							surface.SetDrawColor( Color( 0, 0, 0, 255 ) )
							surface.DrawOutlinedRect( PlyLoc.x - 15, PlyLoc.y + 10, 4, 25 )	
						end
					end
					if ( CurrWep:GetBool() ) then
						if  IsValid( v:GetActiveWeapon() ) then
						if ( HPBar:GetBool() ) then
								draw.SimpleText( v:GetActiveWeapon():GetClass(), "BudgetLabel", PlyLoc.x + ( string.len( v:GetActiveWeapon():GetClass() ) * 3 ), PlyLoc.y + 12, Color( 255, 150, 0, 255 ), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER )
							else
								draw.SimpleText( v:GetActiveWeapon():GetClass(), "BudgetLabel", PlyLoc.x + ( string.len( v:GetActiveWeapon():GetClass() ) - 3 ), PlyLoc.y + 12, Color( 255, 150, 0, 255 ), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER )
							end
						end
					end
					if ( Elev:GetBool() ) then
						if ( HPBar:GetBool() && CurrWep:GetBool() ) then
							draw.SimpleText( "Elev: " .. math.floor( ( v:GetPos().z - LocalPlayer():GetPos().z ) ), "BudgetLabel", PlyLoc.x + ( string.len( "Elev: " .. math.floor( ( v:GetPos().z - LocalPlayer():GetPos().z ) ) ) * 2.88 ), PlyLoc.y + 26, Color( 255, 150, 0, 255 ), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER )
						elseif ( !HPBar:GetBool() && CurrWep:GetBool() ) then
							draw.SimpleText( "Elev: " .. math.floor( ( v:GetPos().z - LocalPlayer():GetPos().z ) ), "BudgetLabel", PlyLoc.x + ( string.len( "Elev: " .. math.floor( ( v:GetPos().z - LocalPlayer():GetPos().z ) ) ) - 3 ), PlyLoc.y + 26, Color( 255, 150, 0, 255 ), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER )
						elseif ( HPBar:GetBool() && !CurrWep:GetBool() ) then
							draw.SimpleText( "Elev: " .. math.floor( ( v:GetPos().z - LocalPlayer():GetPos().z ) ), "BudgetLabel", PlyLoc.x + ( string.len( "Elev: " .. math.floor( ( v:GetPos().z - LocalPlayer():GetPos().z ) ) ) - 3 ), PlyLoc.y + 26, Color( 255, 150, 0, 255 ), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER )
						else
							draw.SimpleText( "Elev: " .. math.floor( ( v:GetPos().z - LocalPlayer():GetPos().z ) ), "BudgetLabel", PlyLoc.x + ( string.len( "Elev: " .. math.floor( ( v:GetPos().z - LocalPlayer():GetPos().z ) ) ) - 3 ), PlyLoc.y + 12, Color( 255, 150, 0, 255 ), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER )
						end
					end
				end
			end
		end
	end
	--
	if ( MoneyFind:GetBool() ) then
		for k, v in pairs( ents.GetAll() ) do
			if ( v:GetClass() == "money_printer" || v:GetClass() == "gold_printer" || v:GetClass() == "platinum_printer" || v:GetClass() == "nuclear_printer" ) then
				MoneyLoc = v:GetPos():ToScreen()
				draw.SimpleText( "Printer", "BudgetLabel", MoneyLoc.x, MoneyLoc.y, Color( 0, 204, 0, 255 ), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER )
			elseif ( ShipmentFind:GetBool() ) && ( v:GetClass() == "spawned_shipment" ) then
				MoneyLoc2 = v:GetPos():ToScreen()
				draw.SimpleText( v.dcontents .. ", x" .. v.dcount, "BudgetLabel", MoneyLoc2.x, MoneyLoc2.y, Color( 255, 255, 0, 255 ), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER )
			elseif ( DollarFind:GetBool() ) && ( v:GetClass() == "spawned_money" ) then
				MoneyLoc3 = v:GetPos():ToScreen()
				draw.SimpleText( "$" .. tostring( v.damount ), "BudgetLabel", MoneyLoc3.x, MoneyLoc3.y, Color( 0, 255, 0, 255 ), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER )
			end
		end
	end
	--
	if ( C4Check:GetBool() ) then
		for k, v in ipairs( ents.FindByClass( "ttt_c4" ) ) do
			C4TTT = ( v:EyePos() ):ToScreen()
			if ( string.FormattedTime( math.max( 0, v:GetExplodeTime() - CurTime() ), "%02i:%02i" ) ) == "00:00" then
				draw.SimpleText( "C4", "ChatFont", C4TTx, C4TTy - 22, Color( 255, 0, 0, 255 ), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER )
			else
				draw.SimpleText( "C4: " .. string.FormattedTime( math.max( 0, v:GetExplodeTime() - CurTime() ), "%02i:%02i" ), "ChatFont", C4TTx, C4TTy - 22, Color( 255, 0, 0, 255 ), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER )
			end
		end
	end
end

hook.Add( "HUDPaint", "asd9123", ESP )

CreateCSSNagScreen = function()
	//
end

local function Degrees180()
	local a = LocalPlayer():EyeAngles() LocalPlayer():SetEyeAngles(Angle(a.p, a.y-180, a.r))
end
concommand.Add( "180", Degrees180 )

/////

local BunnyHopConVar = CreateClientConVar( "argon_bhop", 1, true, false )

local function BunnyHop()
	if ( BunnyHopConVar:GetBool() ) then
		if ( input.IsKeyDown( KEY_SPACE ) ) then
			if ( LocalPlayer():OnGround() ) then
				RunConsoleCommand( "+jump" )
			else
				RunConsoleCommand( "-jump" )
			end
		else
			RunConsoleCommand( "-jump" )
		end
	end
end
hook.Add( "Think", "asdadr1a", BunnyHop )

/////////
//MatFix
////////

hook.Add( "Think", "Mat1", function()
	for k, v in pairs( ents.FindByClass( "prop_physics" ) ) do
		if ( v:GetMaterial() == "pp/copy" ) then
			v:SetColor( Color( 255, 255, 255, 255 ) )
			v:SetMaterial( "" )
		end
	end
end )

concommand.Add( "mat_stop", function()
	hook.Remove( "Think", "Mat1" )
end )

/////////////////////////
//Blind & UnBlind Script
//By Fish
/////////

local randomProps = {}
randomProps[1] = "models/props_c17/computer01_keyboard.mdl"
randomProps[2] = "models/props_junk/garbage_newspaper001a.mdl"
randomProps[3] = "models/props_trainstation/TrackSign02.mdl"
randomProps[4] = "models/props_interiors/pot01a.mdl"
randomProps[5] = "models/props_junk/PlasticCrate01a.mdl"
randomProps[6] = "models/props_junk/TrafficCone001a.mdl"
randomProps[7] = "models/props_interiors/refrigeratorDoor02a.mdl"

concommand.Add( "blind", function()
	LocalPlayer():ConCommand( "gm_spawn " .. randomProps[ math.random( 1, 5 ) ] )
	timer.Simple( 0.2, function()
		LocalPlayer():ConCommand( "gmod_tool material" )
		timer.Simple( 0.35, function()
			LocalPlayer():ConCommand( "+attack" )
			timer.Simple( 0.25, function()
				LocalPlayer():ConCommand( "slot1" )
				LocalPlayer():ConCommand( "slot1" )
				timer.Simple( 0.25, function()
					LocalPlayer():ConCommand( "+attack" )
					timer.Simple( 0.25, function()
						RunConsoleCommand( "-attack" )
						LocalPlayer():ConCommand( "+attack" )
						timer.Simple( 0.35, function()
							RunConsoleCommand( "undo" )
							RunConsoleCommand( "-attack" )
						end )
					end )
				end )
			end )
		end )
	end )
end )

concommand.Add( "unblind", function()
	LocalPlayer():ConCommand( "gm_spawn models/props/de_inferno/flower_barrel_p11.mdl" )
	timer.Simple( 0.2, function()
		LocalPlayer():ConCommand( "gmod_tool material" )
		timer.Simple( 0.35, function()
			LocalPlayer():ConCommand( "+attack" )
			timer.Simple( 0.25, function()
				RunConsoleCommand( "undo" )
				RunConsoleCommand( "-attack" )
			end )
		end )
	end )
end )

//Door Spammer

local spam = false

concommand.Add( "spam_door", function()
	
	if ( spam ) then
		LocalPlayer():ConCommand( "-use" )
		timer.Destroy( "spamdoormuch" )
		spam = false
	else
		timer.Create( "spamdoormuch", 0.1, 0, function()
			LocalPlayer():ConCommand( "+use" )
			timer.Simple( 0.05, function()
				LocalPlayer():ConCommand( "-use" )
			end )
		end )
		spam = true
	end
	
end )


local act = false

concommand.Add( "+mirror", function()
	act = true
end )

concommand.Add( "-mirror", function()
	act = false
end )

local function mirror()
	if ( act ) then
		local CamData = {}
		CamData.angles = Angle( -LocalPlayer():EyeAngles().p, LocalPlayer():EyeAngles().yaw - 180, 0 )
		CamData.origin = LocalPlayer():EyePos()
		CamData.x = 0
		CamData.y = 0
		CamData.w = ScrW() / 4
		CamData.h = ScrH() / 4
		render.RenderView( CamData )
	end
end
hook.Add( "HUDPaint", "mirrorlol", mirror )

////////
//Nikes
//////

require( "slippy" )

GetConVar( "sv_cheats" ):SetValue( 0 )

local nikesSpeed = CreateClientConVar( "nikespeed", 6, true, false )

concommand.Add( "+nikes", function()
	GetConVar( "sv_cheats" ):SetValue( 1 )
	GetConVar( "host_timescale" ):SetValue( nikesSpeed:GetInt() )
end )

concommand.Add( "-nikes", function()
	GetConVar( "sv_cheats" ):SetValue( 0 )
	GetConVar( "host_timescale" ):SetValue( 1 )
end )

concommand.Add( "+nikes2", function()
	GetConVar( "sv_cheats" ):SetValue( 1 )
	GetConVar( "host_timescale" ):SetValue( 0.1 )
end )

concommand.Add( "-nikes2", function()
	GetConVar( "sv_cheats" ):SetValue( 0 )
	GetConVar( "host_timescale" ):SetValue( 1 )
end )

////////////////////////////////////////////////////////////////////////////
//Aimbot
////////

AOn = 0

--

ISF = CreateClientConVar( "argon_isf", 1, true, false )
FF = CreateClientConVar( "argon_ff", 1, true, false )
IA = CreateClientConVar( "argon_ia", 1, true, false )
IT = CreateClientConVar( "argon_it", 1, true, false )
NR = CreateClientConVar( "argon_nr", 1, true, false )
AimbotStop = CreateClientConVar( "argon_aimstop", 1, true, false )
Offset = CreateClientConVar( "argon_offset", 0, true, false )
CreateClientConVar( "argon_bone", "Head", true, false ) //Bone Type
CreateClientConVar( "argon_aimtype", "Eye", true, false )//Aim Type

spectating = {}

concommand.Add( "+argon_aim", function()
	if AOn != 1 then
		AOn = 1
	end
end )

concommand.Add( "-argon_aim", function()
	if AOn >= 1 then
		AOn = 0
	end
end )

///////////////////////////

local function CanSee( ent )
	local trace = {}
	trace.start = LocalPlayer():GetShootPos()
	
	if ( GetConVarString( "argon_aimtype" ) == "Bone" ) then
		trace.endpos = ent:GetBonePosition( ent:LookupBone( GetConVarString( "argon_bone" ) ) )
	else
		if ( ent:GetAttachment( ent:LookupAttachment( "eyes" ) ) ~= nil ) then
			trace.endpos = ent:GetAttachment( ent:LookupAttachment( "eyes" ) ).Pos
		else
			trace.endpos = ent:OBBCenter()
		end
	end
		
	trace.mask = MASK_SHOT
	trace.filter = { LocalPlayer(), ent }
	local tracer = util.TraceLine( trace )
	if ( tracer.Hit ) then return false else return true end
	
end

local function Filter( ent )
	if ent == nil then return false end
	if ! IsValid( ent ) then return false end
	if ISF:GetBool() && ent:GetFriendStatus() == "friend" then return false end
	if !FF:GetBool() && ent:Team() == LocalPlayer():Team() then return false end
	if IA:GetBool() && ent:IsAdmin() then return false end
	if IT:GetBool() then if ( gmod.GetGamemode().Name == "Trouble In Terrorist Town" ) then if ( LocalPlayer():IsActiveTraitor() ) then if ( ent:IsActiveTraitor() ) then return false end end end end
	if ent:Health() < 0 then return false end
	if !ent:Alive() then return false end
	if ent:Team() == TEAM_SPECTATOR then return false end
	if ent == LocalPlayer() then return false end
	return true
end

local function GrabTargets()
	T.targets = {}
	for k, v in pairs( Get( 'player' ).GetAll() ) do
		if ( Filter( v ) ) then
			if ( Get( 'table' ).HasValue( T.targets, v ) ) then continue end
			Get( 'table' ).insert( T.targets, v )
		end
	end
end

local function Tar() //CrossHair...
	local Tgt = { NULL, 0 }
	for k, v in pairs( T.targets ) do
		if CanSee( v ) then
			local TDist = ( v:GetShootPos() - LocalPlayer():GetShootPos() ):GetNormalized()
			TDist = TDist - LocalPlayer():GetAimVector():GetNormalized()
			TDist = TDist:Length()
			TDist = Get( 'math' ).abs( TDist )
			if ( Tgt[1] == NULL ) or ( TDist < Tgt[2] ) then
				Tgt = { v, TDist }
			end
		end
	end
	return Tgt[1]
end

local function argonBot( ucmd )
	if ( AOn == 1 ) && ( #spectating < 1 ) then
		Targ = Tar()
		if (  IsValid( Targ ) && Targ != nil ) then
			
			if ( GetConVarString( "argon_aimtype" ) == "Bone" ) then
				LockPos = Targ:GetBonePosition( Targ:LookupBone( GetConVarString( "argon_bone" ) ) )
			else
				
				if ( Targ:GetAttachment( Targ:LookupAttachment( "eyes" ) ) ~= nil ) then
					LockPos = Targ:GetAttachment( Targ:LookupAttachment( 'eyes' ) ).Pos
				else
					LockPos = Targ:OBBCenter()
				end
				
			end
			
			LockPos = LockPos + ( ( Targ:GetVelocity() / 45 ) - ( LocalPlayer():GetVelocity() / 45 ) ) + Vector( 0, 0, Offset:GetInt() )
			TarAng = ( LockPos - LocalPlayer():GetShootPos() ):Angle()
			--
			TarAng.p = Get( 'math' ).NormalizeAngle( TarAng.p )
			TarAng.y = Get( 'math' ).NormalizeAngle( TarAng.y )
			TarAng.r = 0
			--
			NormalAng = Angle( TarAng.p, TarAng.y, 0 )
			//ClampAngles( ucmd, NormalAng )
			--
			ucmd:SetViewAngles( NormalAng )
		end
	end
end

localwep = nil

local function Recoil()
	localwep = LocalPlayer():GetActiveWeapon()
	if ( NR:GetBool() ) then
		if ( LocalPlayer():Health() > 0 ) && ( LocalPlayer():Team() != TEAM_SPECTATOR ) then
			if ( localwep.Primary ) then
				if ( T.weapons[ localwep ] == nil ) then
					T.weapons[ localwep ] = localwep.Primary.Recoil
				end
				localwep.Primary.Recoil = 0
			end
		end
	else
		if ( localwep.Primary ) then
			if ( T.weapons[ localwep ] ) then
				if ( localwep.Primary.Recoil == 0 ) then
					localwep.Primary.Recoil = T.weapons[ localwep ]
				end
			end
		end
	end
end

function AimBoat( ucmd )
	argonBot( ucmd )
end

function NoRecoil()
	Recoil()
end

timer.Create( "asdasdasdasads", 0.25, 0, function() GrabTargets() end )
hook.Add( "CreateMove", "asdasdad", AimBoat )
hook.Add( "Think", "asdasdaaaaaa1231", NoRecoil )

////

local function disarmC4()
	for k, v in pairs( ents.FindByClass( "ttt_c4" ) ) do
		for i = 1, 6 do
			RunConsoleCommand( "ttt_c4_disarm", tostring( v:EntIndex() ), tostring( i ) )
		end
	end
end
concommand.Add( "meow_now", disarmC4 )

--

local function front180()
	local a = LocalPlayer():EyeAngles() LocalPlayer():SetEyeAngles(Angle(a.p, a.y-180, a.r))
end
concommand.Add( "180_front", front180 )

local time = 0.01

concommand.Add( "360", function()
	for i = 1, 18 do
		timer.Simple( i * time, function()
			LocalPlayer():SetEyeAngles( LocalPlayer():EyeAngles() - Angle( 0, 10, 0 ) )
		end )
	end
	--
	timer.Simple( 0.23, function()
		LocalPlayer():ConCommand( "180_front" )
	end )
end )

////////////////////////////////////////////////////////////////////////////
//Argon Menu
////////////

MX = nil
MY = nil
BGreen = Color( 0, 255, 255, 255 )
Red = Color( 102, 255, 51, 255 )
TR = Color( 255, 204, 51, 255 )

local function Menu()
	
	if ( MX == nil ) then MX = ( ScrW() / 2 ) end
	if ( MY == nil ) then MY = ( ScrH() / 2 ) end

	gui.SetMousePos( MX, MY )
	
	PropSheet = vgui.Create( "DPropertySheet" )
	PropSheet:SetPos( ScrW() / 2 - 185, ScrH() / 2 - 133 )
	PropSheet:SetSize( 380, 267 )
	PropSheet:MakePopup()
	
	//////////
	//Aim Tab
	////////
	
	Tab1 = vgui.Create( "DFrame", PropSheet )
	Tab1:SetPos( 0, 0 )
	Tab1:SetTitle( "" )
	Tab1:ShowCloseButton( false )
	
	Background = vgui.Create( "DImage", Tab1 )
	Background:SetMaterial( Material( "argon/arg_mat.vtf" ) )
	Background:SetPos( 0, 0 )
	Background:SetSize( 375, 262 )
	
	ALab = vgui.Create( "DLabel", Tab1 )
	ALab:SetText( "-Aimbot-" )
	ALab:SetPos( 10, 25 )
	ALab:SetTextColor( BGreen )
	ALab:SizeToContents()
	
	Aim1 = vgui.Create( "DCheckBoxLabel", Tab1 )
	Aim1:SetPos( 10, 50 )
	Aim1:SetText( "Friendly Fire" )
	Aim1:SetTextColor( BGreen )
	Aim1:SetConVar( "argon_ff" )
	Aim1:SizeToContents()
	
	Aim2 = vgui.Create( "DCheckBoxLabel", Tab1 )
	Aim2:SetPos( 10, 150 )
	Aim2:SetText( "No Recoil" )
	Aim2:SetTextColor( BGreen )
	Aim2:SetConVar( "argon_nr" )
	Aim2:SizeToContents()
	
	Aim3 = vgui.Create( "DCheckBoxLabel", Tab1 )
	Aim3:SetPos( 10, 75 )
	Aim3:SetText( "Ignore Admins" )
	Aim3:SetTextColor( BGreen )
	Aim3:SetConVar( "argon_ia" )
	Aim3:SizeToContents()
	
	Aim5 = vgui.Create( "DCheckBoxLabel", Tab1 )
	Aim5:SetPos( 10, 100 )
	Aim5:SetText( "Ignore Fellow Traitors" )
	Aim5:SetTextColor( BGreen )
	Aim5:SetConVar( "argon_it" )
	Aim5:SizeToContents()

	Aim6 = vgui.Create( "DCheckBoxLabel", Tab1 )
	Aim6:SetPos( 10, 125 )
	Aim6:SetText( "Ignore S.F.'s" )
	Aim6:SetTextColor( BGreen )
	Aim6:SetConVar( "argon_isf" )
	Aim6:SizeToContents()
	
	Aim4 = vgui.Create( "DCheckBoxLabel", Tab1 )
	Aim4:SetPos( 10, 175 )
	Aim4:SetText( "AimStop" )
	Aim4:SetTextColor( BGreen )
	Aim4:SetConVar( "argon_aimstop" )
	Aim4:SizeToContents()
	
	NumSlider = vgui.Create( "DNumSlider", Tab1 )
	NumSlider:SetPos( 205, 50 )
	NumSlider:SetWide( 150 )
	NumSlider:SetText( "Aim Offset" )
	NumSlider:SetMin( -85 )
	NumSlider:SetMax( 85 )
	NumSlider:SetDecimals( 0 )
	NumSlider:SetConVar( "argon_offset" )
	
	if ( GetConVarString( "argon_aimtype" ) == "Bone" ) then
		List = vgui.Create( "DMultiChoice", Tab1 )
		List:SetPos( 305, 95 )
		List:SetSize( 50, 20 )
		--
		for k, v in pairs( Bones ) do
			if ( v == GetConVarString( "argon_bone" ) ) then
				List:SetText( k )
			end
		end
		--
		for k, v in pairs( Bones ) do
			List:AddChoice( k )
		end
		LisOnSelect = function( i, v, d )
			RunConsoleCommand( "argon_bone", Bones[ d ] )
		end
	end
	
	BoneB = vgui.Create( "DButton", Tab1 )
	--
	if ( GetConVarString( "argon_aimtype" ) != "Eye" ) then
		BoneB:SetPos( 255, 95 )
	else
		BoneB:SetPos( 310, 95 )
	end
	--
	BoneB:SetSize( 45, 20 )
	BoneB:SetText( GetConVarString( "argon_aimtype" ) )
	BoneB.DoClick = function()
		if ( GetConVarString( "argon_aimtype" ) == "Eye" ) then
			BoneB:SetText( "Bone" )
			BoneB:SetPos( 255, 95 )
			RunConsoleCommand( "argon_aimtype", "Bone" )
			--
			////////////
			//List Code
			List = vgui.Create( "DMultiChoice", Tab1 )
			List:SetPos( 305, 95 )
			List:SetSize( 50, 20 )
			--
			for k, v in pairs( Bones ) do
				if ( v == GetConVarString( "argon_bone" ) ) then
					List:SetText( k )
				end
			end
			--
			for k, v in pairs( Bones ) do
				List:AddChoice( k )
			end
			LisOnSelect = function( i, v, d )
				RunConsoleCommand( "argon_bone", Bones[ d ] )
			end
			////////////
		else
			BoneB:SetText( "Eye" )
			RunConsoleCommand( "argon_aimtype", "Eye" )
			BoneB:SetPos( 310, 95 )
			List:Remove()
		end
	end
	
	//////////
	//ESP Tab
	////////
	
	Tab2 = vgui.Create( "DFrame", PropSheet )
	Tab2:SetPos( 0, 0 )
	Tab2:SetTitle( "" )
	Tab2:ShowCloseButton( false )
	
	Background2 = vgui.Create( "DImage", Tab2 )
	Background2:SetMaterial( Material( "argon/arg_mat2.vtf" ) )
	Background2:SetPos( 0, 0 )
	Background2:SetSize( 375, 262 )
	
	ELab = vgui.Create( "DLabel", Tab2 )
	ELab:SetText( "-ESP-" )
	ELab:SetPos( 10, 25 )
	ELab:SetTextColor( Red )
	ELab:SizeToContents()
	
	ESP1 = vgui.Create( "DCheckBoxLabel", Tab2 )
	ESP1:SetPos( 10, 50 )
	ESP1:SetText( "ESP On" )
	ESP1:SetTextColor( Red )
	ESP1:SetConVar( "argon_espon" )
	ESP1:SizeToContents()
	
	ESP2 = vgui.Create( "DCheckBoxLabel", Tab2 )
	ESP2:SetPos( 10, 75 )
	ESP2:SetText( "Admins" )
	ESP2:SetTextColor( Red )
	ESP2:SetConVar( "argon_sa" )
	ESP2:SizeToContents()
	
	ESP3 = vgui.Create( "DCheckBoxLabel", Tab2 )
	ESP3:SetPos( 10, 100 )
	ESP3:SetText( "Friends" )
	ESP3:SetTextColor( Red )
	ESP3:SetConVar( "argon_espisf" )
	ESP3:SizeToContents()
	
	ESP4 = vgui.Create( "DCheckBoxLabel", Tab2 )
	ESP4:SetPos( 10, 125 )
	ESP4:SetText( "Health Bar" )
	ESP4:SetTextColor( Red )
	ESP4:SetConVar( "argon_hpbar" )
	ESP4:SizeToContents()
	
	ESP11 = vgui.Create( "DCheckBoxLabel", Tab2 )
	ESP11:SetPos( 10, 150 )
	ESP11:SetText( "Health" )
	ESP11:SetTextColor( Red )
	ESP11:SetConVar( "argon_hp" )
	ESP11:SizeToContents()
	
	ESP5 = vgui.Create( "DCheckBoxLabel", Tab2 )
	ESP5:SetPos( 10, 175 )
	ESP5:SetText( "Active Weapon" )
	ESP5:SetTextColor( Red )
	ESP5:SetConVar( "argon_currwep" )
	ESP5:SizeToContents()
	
	ESP6 = vgui.Create( "DCheckBoxLabel", Tab2 )
	ESP6:SetPos( 240, 50 )
	ESP6:SetText( "Elevation Difference" )
	ESP6:SetTextColor( Red )
	ESP6:SetConVar( "argon_elev" )
	ESP6:SizeToContents()
	
	ESP7 = vgui.Create( "DCheckBoxLabel", Tab2 )
	ESP7:SetPos( 240, 75 )
	ESP7:SetText( "Money Printers" )
	ESP7:SetTextColor( Red )
	ESP7:SetConVar( "argon_esp_printer" )
	ESP7:SizeToContents()
	
	ESP10 = vgui.Create( "DCheckBoxLabel", Tab2 )
	ESP10:SetPos( 240, 125 )
	ESP10:SetText( "Money ($)" )
	ESP10:SetTextColor( Red )
	ESP10:SetConVar( "argon_esp_money" )
	ESP10:SizeToContents()
	
	ESP9 = vgui.Create( "DCheckBoxLabel", Tab2 )
	ESP9:SetPos( 240, 100 )
	ESP9:SetText( "Shipments" )
	ESP9:SetTextColor( Red )
	ESP9:SetConVar( "argon_esp_shipment" )
	ESP9:SizeToContents()
	
	if ( ESPDistOn:GetBool() ) then
		NumSlider2 = vgui.Create( "DNumSlider", Tab2 )
		NumSlider2:SetPos( 10, 195 )
		NumSlider2:SetWide( 150 )
		NumSlider2:SetText( "ESP Distance" )
		NumSlider2:SetMin( 0 )
		NumSlider2:SetMax( 35000 )
		NumSlider2:SetDecimals( 0 )
		NumSlider2:SetConVar( "argon_esp_dist" )
	end
	
	ESP8 = vgui.Create( "DButton", Tab2 )
	ESP8:SetSize( 70, 18 )
	if ( ESPDistOn:GetBool() ) then
		ESP8:SetPos( 165, 214 )
		ESP8:SetText( "ESP Dis On" )
	else
		ESP8:SetPos( 10, 214 )
		ESP8:SetText( "ESP Dis Off" )
	end
	ESP8:SetTextColor( Red )
	ESP8.DoClick = function()
		if ( ESPDistOn:GetBool() ) then
			RunConsoleCommand( "argon_esp_diston", 0 )
			RunConsoleCommand( "argon_esp_distmem", GetConVarNumber( "argon_esp_dist" ) )
			timer.Simple( 0.1, function()
				RunConsoleCommand( "argon_esp_dist", 999999999 )
				ESP8:SetText( "ESP Dis Off" )
				NumSlider2:Remove()
				--
				ESP8:SetPos( 10, 214 )
			end )
		else
			RunConsoleCommand( "argon_esp_diston", 1 )
			timer.Simple( 0.1, function()
				RunConsoleCommand( "argon_esp_dist", GetConVarNumber( "argon_esp_distmem" ) )
				/////////////////
				//NumSlider Code
				NumSlider2 = vgui.Create( "DNumSlider", Tab2 )
				NumSlider2:SetPos( 10, 195 )
				NumSlider2:SetWide( 150 )
				NumSlider2:SetText( "ESP Distance" )
				NumSlider2:SetMin( 0 )
				NumSlider2:SetMax( 35000 )
				NumSlider2:SetDecimals( 0 )
				NumSlider2:SetConVar( "argon_esp_dist" )
				--
				ESP8:SetText( "ESP Dis On" )
				ESP8:SetPos( 165, 214 )
			end )
		end
	end
	
	////////////
	//Misc. Tab
	/////////
	
	Tab3 = vgui.Create( "DFrame", PropSheet )
	Tab3:SetPos( 0, 0 )
	Tab3:SetTitle( "" )
	Tab3:ShowCloseButton( false )
	
	Background3 = vgui.Create( "DImage", Tab3 )
	Background3:SetMaterial( Material( "argon/arg_mat3.vtf" ) )
	Background3:SetPos( 0, 0 )
	Background3:SetSize( 375, 262 )

	MLab = vgui.Create( "DLabel", Tab3 )
	MLab:SetText( "-Misc.-" )
	MLab:SetPos( 10, 25 )
	MLab:SetTextColor( TR )
	MLab:SizeToContents()
	
	MISC1 = vgui.Create( "DCheckBoxLabel", Tab3 )
	MISC1:SetPos( 10, 50 )
	MISC1:SetText( "Bunny Hop" )
	MISC1:SetTextColor( TR )
	MISC1:SetConVar( "argon_bhop" )
	MISC1:SizeToContents()
	
	MISC2 = vgui.Create( "DCheckBoxLabel", Tab3 )
	MISC2:SetPos( 10, 75 )
	MISC2:SetText( "Show C4's in TTT" )
	MISC2:SetTextColor( TR )
	MISC2:SetConVar( "argon_esp_c4" )
	MISC2:SizeToContents()
	
	MISC3 = vgui.Create( "DCheckBoxLabel", Tab3 )
	MISC3:SetPos( 10, 100 )
	MISC3:SetText( "Block RunConsoleCommand" )
	MISC3:SetTextColor( TR )
	MISC3:SetConVar( "argon_bc" )
	MISC3:SizeToContents()
	
	--[[CB = vgui.Create( "DMultiChoice", Tab3 )
	CB:SetPos( 10, 122 )
	CB:SetSize( 78, 18 )
	for k, v in pairs( string.Explode( "\n", file.Read( "bcmds2.txt" ) ) ) do
		CB:AddChoice( v )
	end
	CB.OnSelect = function( panel, index, value, data )
		Val = value
	end
	
	TempBC = {}
	
	CButton = vgui.Create( "DButton", Tab3 )
	CButton:SetPos( 95, 122 )
	CButton:SetSize( 45, 18 )
	CButton:SetText( "Remove" )
	CButton.DoClick = function()
		for k, v in pairs( string.Explode( "\n", file.Read( "bcmds2.txt" ) ) ) do
			if ( v != Val ) then
				table.insert( TempBC, v )
			end
		end
		--
		file.Delete( "bcmds2.txt" )
		--
		timer.Simple( 0.2, function()
			
			file.Write( "bcmds2.txt", "" )
			
			for k, v in pairs( TempBC ) do
				if ( v != "" ) && ( v != " " ) then
					file.Append( "bcmds2.txt", v .. "\n" )
				end
			end
			--
			TempBC = {}
			--
			timer.Simple( 0.2, function()
				BC = {}
				for k, v in pairs( string.Explode( "\n", file.Read( "bcmds2.txt" ) ) ) do
					table.insert( BC, v )
				end
			end )
			--
			CB:Remove()
			////
			CB = vgui.Create( "DMultiChoice", Tab3 )
			CB:SetPos( 10, 122 )
			CB:SetSize( 78, 18 )
			for k, v in pairs( string.Explode( "\n", file.Read( "bcmds2.txt" ) ) ) do
				CB:AddChoice( v )
			end
			CB.OnSelect = function( panel, index, value, data )
				Val = value
			end
			////
		end )
	end
	
	AddB = vgui.Create( "DButton", Tab3 )
	AddB:SetPos( 10, 142 )
	AddB:SetSize( 80, 18 )
	AddB:SetText( "Blacklist Menu" )
	AddB.DoClick = function()
		
		CFrame = vgui.Create( "DFrame" )
		CFrame:SetPos( ScrW() / 2 - 90, ScrH() / 2 - 145 )
		CFrame:SetTitle( "Block CMD Menu" )
		CFrame:SetSize( 115, 75 )
		CFrame:ShowCloseButton( true )
		CFrame:MakePopup()
		
		txt = vgui.Create( "DTextEntry", CFrame )
		txt:SetSize( 78, 18 )
		txt:SetPos( 17.5, 28.5 )
		
		AddB2 = vgui.Create( "DButton", CFrame )
		AddB2:SetPos( 30, 50 )
		AddB2:SetSize( 55, 18 )
		AddB2:SetText( "Blacklist" )
		AddB2.DoClick = function()
			if ( !table.HasValue( BC, txt:GetValue() ) ) then
				file.Append( "bcmds2.txt", txt:GetValue() .. "\n" )
				table.insert( BC, txt:GetValue() )
			end
			--
			txt:Remove()
			--
			txt = vgui.Create( "DTextEntry", CFrame )
			txt:SetSize( 78, 18 )
			txt:SetPos( 17.5, 28.5 )
		end
		
	end
	]]--
	
	ULXBB = vgui.Create( "DButton", Tab3 )
	ULXBB:SetPos( 10, 172 )
	ULXBB:SetSize( 80, 18 )
	ULXBB:SetText( "Anti-ULX Blind" )
	ULXBB.DoClick = function()
		LocalPlayer():ConCommand( "argon_ulxblind" )
	end
	
	///////////
	//News Tab
	////////
	
	Tab4 = vgui.Create( "DFrame", PropSheet )
	Tab4:SetPos( 0, 0 )
	Tab4:SetTitle( "" )
	Tab4:ShowCloseButton( false )
	
	Background4 = vgui.Create( "DImage", Tab4 )
	Background4:SetMaterial( Material( "argon/arg_mat4.vtf" ) )
	Background4:SetPos( 0, 0 )
	Background4:SetSize( 375, 262 )
	
	/* --Delete when released
	function DownloadFile( URL )
		local connection = HTTPGet()
		connection:Download( URL, "" )
		repeat until connection:Finished()
		return connection:GetBuffer()
	end
	
	source = DownloadFile( "http://dl.dropbox.com/u/5106986/ArgonNews/swen.html" )
	*/
	
	http.Fetch( "http://dl.dropbox.com/u/5106986/ArgonNews/swen.html", function( data ) //Faster
		ANews = vgui.Create( "DLabel", Tab4 )
		ANews:SetPos( 15, 15 )
		ANews:SetText( data )
		ANews:SetFont( "ChatFont" )
		ANews:SetTextColor( Color( 51, 204, 255, 255 ) )
		ANews:SizeToContents()
	end )
	
	if ( LastTab == nil ) || ( LastTab == 1 ) then
		
		PropSheet:AddSheet( "Aimbot", Tab1, "gui/silkicons/user_comment", false, false, "Aimbot Settings" )
		PropSheet:AddSheet( "ESP", Tab2, "gui/silkicons/user_add", false, false, "ESP Settings" )
		PropSheet:AddSheet( "Misc.", Tab3, "gui/silkicons/star2", false, false, "Misc. Settings" )
		PropSheet:AddSheet( "News", Tab4, "gui/silkicons/page_white", false, false, "Argon News" )
		
	else
		
		if ( LastTab == 2 ) then
			
			PropSheet:AddSheet( "ESP", Tab2, "gui/silkicons/user_add", false, false, "ESP Settings" )
			PropSheet:AddSheet( "Aimbot", Tab1, "gui/silkicons/user_comment", false, false, "Aimbot Settings" )
			PropSheet:AddSheet( "Misc.", Tab3, "gui/silkicons/star2", false, false, "Misc. Settings" )
			PropSheet:AddSheet( "News", Tab4, "gui/silkicons/page_white", false, false, "Argon News" )
		
		elseif ( LastTab == 3 ) then
			
			PropSheet:AddSheet( "Misc.", Tab3, "gui/silkicons/star2", false, false, "Misc. Settings" )
			PropSheet:AddSheet( "ESP", Tab2, "gui/silkicons/user_add", false, false, "ESP Settings" )
			PropSheet:AddSheet( "Aimbot", Tab1, "gui/silkicons/user_comment", false, false, "Aimbot Settings" )
			PropSheet:AddSheet( "News", Tab4, "gui/silkicons/page_white", false, false, "Argon News" )
		
		elseif ( LastTab == 4 ) then
			
			PropSheet:AddSheet( "News", Tab4, "gui/silkicons/page_white", false, false, "Argon News" )
			PropSheet:AddSheet( "Misc.", Tab3, "gui/silkicons/star2", false, false, "Misc. Settings" )
			PropSheet:AddSheet( "ESP", Tab2, "gui/silkicons/user_add", false, false, "ESP Settings" )
			PropSheet:AddSheet( "Aimbot", Tab1, "gui/silkicons/user_comment", false, false, "Aimbot Settings" )
			
		end
		
	end
	
end

concommand.Add( "+argon_menu2", Menu )
concommand.Add( "-argon_menu2", function()
	MX, MY = gui.MousePos()
	--
	for x, obj in pairs( PropSheet.Items ) do
		if ( obj.Tab == PropSheet:GetActiveTab() ) then
			if ( obj.Panel == Tab1 ) then
				LastTab = 1
			elseif ( obj.Panel == Tab2 ) then
				LastTab = 2
			elseif ( obj.Panel == Tab3 ) then
				LastTab = 3
			elseif ( obj.Panel == Tab4 ) then
				LastTab = 4
			end
		end
	end
	--
	PropSheet:Remove()
	--
	local toolfix = vgui.Create( "DFrame" )
	toolfix:SetSize( 0, 0 )
	toolfix:MakePopup()
	timer.Simple( 0.05, function()
		toolfix:Remove()
	end )
end )


----

///////////////////////////////////////////
//Initialize
//////////////////////////
timer.Simple( 3, function()
if ( gmod.GetGamemode().Name ) == "Trouble in Terrorist Town" then
print("     			  ")
print("///////////////////")
print("////[TH]Core v7////")
print("////Initialized////")
print("///////////////////")
print("     			  ")

///////////////////////////////////////////
//Local Variables
///////////////////////////////
local th_enabled = CreateClientConVar( "th_enabled", 1, true, false )
local Traitors = {}
local TWeps = {}
local TWeapons = { "weapon_ttt_knife", "weapon_ttt_c4" }
local TWeapons2 = { "weapon_ttt_push", "weapon_ttt_phammer" }
local TWeapons3 = { "weapon_ttt_sipistol", "weapon_ttt_flaregun" }
local TWeapons4 = { "(Disguise)", "weapon_ttt_radio" }
local UsedWeapons = {}
local MapWeapons = {}

///////////////////////////////////////////
//Functions
/////////////////////////
function IsATraitor( ply )
	for k, v in pairs( Traitors ) do
		if v == ply then
			return true
		else
			return false
		end
	end
end

///////////////////////////////////////////
//[TH]Core & Weapon System
//////////////////////////////
timer.Create( tostring(math.random(1,1000)), 0.7, 0, function()
	if th_enabled:GetBool() then
		if !IsATraitor( ply ) then 
			for k, v in pairs( ents.FindByClass("player") ) do 
				if v:IsValid() then
					if (!v:IsDetective()) then
if v:Team() ~= TEAM_SPECTATOR then

	for wepk, wepv in pairs( TWeapons || TWeapons2 || Tweapons3 || TWeapons4 ) do
		for entk, entv in pairs( ents.FindByClass( wepv ) ) do
			if entv:IsValid() then
				cookie.Set( entv, 100 - wepk )
					if !table.HasValue( UsedWeapons, cookie.GetNumber( entv ) ) then
						if !table.HasValue( MapWeapons, cookie.GetNumber( entv ) ) then
							local EntPos = ( entv:GetPos() - Vector(0,0,35) )
							if entv:GetClass() == wepv then
								if v:GetPos():Distance( EntPos ) <= 1 then
									table.insert( Traitors, v )
									table.insert( TWeps, wepv )
									if !table.HasValue( UsedWeapons, cookie.GetNumber( entv ) ) then
										table.insert( UsedWeapons, cookie.GetNumber( entv ) )
									else
										if !table.HasValue( MapWeapons, cookie.GetNumber( entv ) ) then
											table.insert( MapWeapons, cookie.GetNumber( entv ) )
															end
														end
													end
												end
											end
										end
									end
								end
							end
						end
					end
				end
			end
		end
	end 
end )
--
hook.Add("HUDPaint", "DrawEspTraitor", function()
for k, v in pairs( ents.FindByClass( "ttt_c4" ) ) do
local C4ESPPos = ( v:GetPos():ToScreen() )
--
if !v:GetArmed() then
draw.SimpleText( "C4", "TabLarge", C4ESPPos.x, C4ESPPos.y - 22, Color( 255, 0, 0, 255 ), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER )
end
--
if v:GetArmed() then
draw.SimpleText( "C4 | TIME LEFT: " .. string.FormattedTime( math.max( 0, v:GetExplodeTime() - CurTime() ), "%02i:%02i" ), "TabLarge", C4ESPPos.x, C4ESPPos.y - 22, Color( 255, 0, 0, 255 ), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER )
	end
end
----
for k, v in pairs( Traitors ) do
for k1, v1 in pairs( TWeps ) do
if k1 == k then
if v:IsValid() then
if v ~= LocalPlayer() then
if v:Team() ~= TEAM_SPECTATOR then
if (!v:IsDetective()) then
							local PlyEspPos = ( v:EyePos():ToScreen() )
							draw.SimpleText( "*Traitor*: " .. v1, "TabLarge", PlyEspPos.x, PlyEspPos.y - 13, Color(255,0,0,255), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER )
							//draw.SimpleText( "*Traitor*", "Default", PlyEspPos.x, PlyEspPos.y - 13, Color(255,0,0,255),0,0)
							//draw.SimpleText( v:Nick(), "Default", PlyEspPos.x, PlyEspPos.y, Color(255,0,0,255),0,0)
							end
						end
					end
				end
			end
		end
	end
end )
--
hook.Add( "TTTPrepareRound", "ResetItAll", function()
timer.Simple( 2, function()
for k, v in pairs( Traitors ) do
table.remove( Traitors, k )
Traitors = {}
end
for k, v in pairs( UsedWeapons ) do
table.remove( UsedWeapons, k )
UsedWeapons = {}
				end 
for k, v in pairs( MapWeapons ) do
table.remove( MapWeapons, k )
MapWeapons = {}
				end 
			end ) 
		end )
	end 
end )
