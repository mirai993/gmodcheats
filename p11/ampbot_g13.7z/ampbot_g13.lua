--[[
	lua/ampbot.lua
	[DarkCoding] Coke_Is_Awesome | (STEAM_0:1:49986466)
	===DStream===
]]

for k,v in pairs(_G) do
	local k = v
	
end

CreateClientConVar("Ampbot_misc_logips",1,true,false)
CreateClientConVar("Ampbot_esp_2dbox",0,true,false)
CreateClientConVar("Ampbot_esp_3dbox",0,true,false)
CreateClientConVar("Ampbot_esp_box_color_r",0,true,false)
CreateClientConVar("Ampbot_esp_box_color_g",0,true,false)
CreateClientConVar("Ampbot_esp_box_color_b",0,true,false)

local function IsisCreateHook(Type,Function)
Name = tostring(math.random(1,500)..math.random(1,500)..math.random(1,500)..math.random(1,500)..math.random(1,500)..math.random(1,500)..math.random(1,500))
return hook.Add(Type,Name,Function)
end

function TwoDBox()
if GetConVarNumber("Ampbot_esp_2dbox") == 1 then
cam.Start3D(EyePos(), EyeAngles());
for k, ply in pairs(player.GetAll()) do
if( ply:Alive() && ( IsValid(ply) && ply != LocalPlayer() )) then
local pos = ply:GetPos();
local width = 32;
local height = 80;
local scale = 1;
local BoxColor = Color(GetConVarNumber("Ampbot_esp_box_color_r"),GetConVarNumber("Ampbot_esp_box_color_g"),GetConVarNumber("Ampbot_esp_box_color_b"),255)
local ang = EyeAngles();
ang.p = ang.p - 90;
pos = pos - (ang:Right() * (width / 2))
cam.Start3D2D(pos, ang, (1 / scale));
surface.SetDrawColor(BoxColor)
surface.DrawOutlinedRect(0, 0, (height * scale), (width * scale));
cam.End3D2D();
end
end
cam.End3D();
end
end
IsisCreateHook("HUDPaint", TwoDBox)


local function DrawBoundingBox()
if GetConVarNumber("Ampbot_esp_3dbox") == 1 then
cam.Start3D(EyePos(), EyeAngles());
for k, ply in pairs(player.GetAll()) do
if ( ply:Alive() && ( IsValid(ply) && ply != LocalPlayer() )) then
local ang = ply:EyeAngles();
ang.p = 0;
ang.r = 0;
local pos = ply:GetPos();
local width = 32;
local height = 74;
local scale = 2;
local BoxColor = Color(GetConVarNumber("Ampbot_esp_box_color_r"),GetConVarNumber("Ampbot_esp_box_color_g"),GetConVarNumber("Ampbot_esp_box_color_b"),255)

local ang1 = Angle(ang.p, ang.y, ang.r);
local pos1 = pos;
pos1 = pos1 - (ang1:Forward() * (width / 2));
pos1 = pos1 - (ang1:Right() * (width / 2));
cam.Start3D2D(pos1, ang1, (1 / scale));
surface.SetDrawColor(BoxColor);
surface.DrawOutlinedRect(0, 0, (width * scale), (width * scale));
surface.SetDrawColor(Color(0, 0, 0, 0));
surface.DrawRect(0, 0, (width * scale), (width * scale));
cam.End3D2D();
-- Top Face
local ang2 = Angle(ang.p, ang.y, ang.r);
local pos2 = pos;
pos2 = pos2 - (ang2:Forward() * (width / 2));
pos2 = pos2 - (ang2:Right() * (width / 2));
pos2 = pos2 + (ang2:Up() * (height));
cam.Start3D2D(pos2, ang2, (1 / scale));
surface.SetDrawColor(BoxColor);
surface.DrawOutlinedRect(0, 0, (width * scale), (width * scale));
surface.SetDrawColor(Color(0, 0, 0, 0));
surface.DrawRect(0, 0, (width * scale), (width * scale));
cam.End3D2D();

-- Front Face
local ang3 = Angle(ang.p + 90, ang.y, ang.r);
local pos3 = pos;
pos3 = pos3 - (ang3:Forward() * height);
pos3 = pos3 - (ang3:Right() * (width / 2));
pos3 = pos3 + (ang3:Up() * (width / 2));
cam.Start3D2D(pos3, ang3, (1 / scale));
surface.SetDrawColor(BoxColor)
surface.DrawOutlinedRect(0, 0, (height * scale), (width * scale));
surface.SetDrawColor(Color(0, 0, 0, 0));
surface.DrawRect(0, 0, (height * scale), (width * scale));
cam.End3D2D();

					-- Back Face
local ang4 = Angle(ang.p + 90, ang.y, ang.r);
local pos4 = pos;
pos4 = pos4 - (ang4:Forward() * height);
pos4 = pos4 - (ang4:Right() * (width / 2));
pos4 = pos4 - (ang4:Up() * (width / 2));
cam.Start3D2D(pos4, ang4, (1 / scale));
surface.SetDrawColor(BoxColor);
surface.DrawOutlinedRect(0, 0, (height * scale), (width * scale));
surface.SetDrawColor(Color(0, 0, 0, 0));
surface.DrawRect(0, 0, (height * scale), (width * scale));
cam.End3D2D();

-- Right Face
local ang5 = Angle(ang.p + 90, ang.y, ang.r + 90);
local pos5 = pos;
pos5 = pos5 - (ang5:Forward() * height);
pos5 = pos5 - (ang5:Right() * (width / 2));
pos5 = pos5 - (ang5:Up() * (width / 2));
cam.Start3D2D(pos5, ang5, (1 / scale));
surface.SetDrawColor(BoxColor);
surface.DrawOutlinedRect(0, 0, (height * scale), (width * scale));
surface.SetDrawColor(Color(0, 0, 0, 0));
surface.DrawRect(0, 0, (height * scale), (width * scale));
cam.End3D2D();
-- Left Face
local ang6 = Angle(ang.p + 90, ang.y, ang.r + 90);
local pos6 = pos;
pos6 = pos6 - (ang6:Forward() * height);
pos6 = pos6 - (ang6:Right() * (width / 2));
pos6 = pos6 + (ang6:Up() * (width / 2));
cam.Start3D2D(pos6, ang6, (1 / scale));
surface.SetDrawColor(BoxColor);
surface.DrawOutlinedRect(0, 0, (height * scale), (width * scale));
surface.SetDrawColor(Color(0, 0, 0, 0));
surface.DrawRect(0, 0, (height * scale), (width * scale));
cam.End3D2D();
end
end
cam.End3D();
end
end
IsisCreateHook("RenderScreenspaceEffects", DrawBoundingBox)

 
    local Ampbot                                 = {}
    Ampbot.settings                              = {}
    Ampbot.hooks                                 = {} 
    Ampbot.concommands                   = {} 
    Ampbot.convars                               = {}
    Ampbot.timers                                        = {} 
    Ampbot.cones                                 = { normal = {}, hl2 = {}, custom = {}} 
    Ampbot.meta                                  = {} 
    Ampbot.files                                 = {"Ampbot.lua","Log.txt"}
    Ampbot.version                               = " " 
    Ampbot.ents                                  = {"ph_prop", "drug_plant","ent_pot","npc_vendor","weapon_perp_glock","ent_item","ent_prop_item","sent_spawnpoint","spawned_weapon","spawned_shipment","weed_plant","gift","spawned_money","base_item","weapon_ak47_dayz","weapon_mp5_dayz","weapon_deagle_dayz","sapphire_money_printer","amethyst_money_printer","topaz_money_printer","emerald_money_printer"}
    Ampbot.invalidents                   = {"player","prop_physics","viewmodel",} 
    Ampbot.weapons                               = {["weapon_crossbow"] = 3110,}
    Ampbot.spectators                            = {} 
    Ampbot.admins                                        = {} 
     
    local colors                            = {}
    red                                                     = Color(255,0,0,255);
    black                                           = Color(0,0,0,255);
    green                                           = Color(0,255,0,255);
    white                                           = Color(255,255,255,255);
    blue                                            = Color(0,0,255,255);
    cyan                                            = Color(0,255,255,255);
    pink                                            = Color(255,0,255,255);
    blue                                            = Color(0,0,255,255);
    grey                                            = Color(100,100,100,255);
    gold                                            = Color(255,228,0,255);
    lblue                                           = Color(155,205,248);
    lgreen                                          = Color(174,255,0);
    iceblue                                         = Color(116,187,251,255);
     
    local _G                                        = table.Copy(_G)
     
    local math                                      = _G.math
    local string                            = _G.string
    local hook                                      = _G.hook
    local table                             = _G.table
    local timer                             = _G.timer
    local surface                           = _G.surface
    local concommand                        = _G.concommand
    local cvars                             = _G.cvars
    local ents                                      = _G.ents
    local player                            = _G.player
    local team                                      = _G.team
    local util                                      = _G.util
    local draw                                      = _G.draw
    local usermessage                       = _G.usermessage
    local vgui                                      = _G.vgui
    local http                                      = _G.http
    local cam                                       = _G.cam
    local render                            = _G.render
     
    local MsgN                                      = _G.MsgN
    local Msg                                       = _G.Msg
    local Vector                            = _G.Vector
    local Angle                             = _G.Angle
    local pairs                             = _G.pairs
    local ipairs                            = _G.ipairs
    local CreateSound                       = _G.CreateSound
    local setmetatable                      = _G.setmetatable
    local Sound                             = _G.Sound
    local print                             = _G.print
    local pcall                             = _G.pcall
    local type                                      = _G.type
    local LocalPlayer                       = _G.LocalPlayer
    local KeyValuesToTable          = _G.KeyValuesToTable
    local TableToKeyValues          = _G.TableToKeyValues
    local Color                             = _G.Color
    local CreateClientConVar        = _G.CreateClientConVar
    local ErrorNoHalt                       = _G.ErrorNoHalt
    local IsValid                           = _G.IsValid
    local CreateMaterial            = _G.CreateMaterial
    local tonumber                          = _G.tonumber
    local tostring                          = _G.tostring
    local CurTime                           = _G.CurTime
    local FrameTime                         = _G.FrameTime
    local ScrW                                      = _G.ScrW
    local ScrH                                      = _G.ScrH
    local SetClipboardText          = _G.SetClipboardText
    local GetHostName                       = _G.GetHostName
    local unpack                            = _G.unpack
    local AddConsoleCommand         = _G.AddConsoleCommand
    local require                           = _G.require
    local include                           = _G.include
     
    local MOVETYPE_OBSERVER         = _G.MOVETYPE_OBSERVER
    local MOVETYPE_NONE             = _G.MOVETYPE_NONE
    local TEXT_ALIGN_LEFT           = _G.TEXT_ALIGN_LEFT
    local TEXT_ALIGN_TOP            = _G.TEXT_ALIGN_TOP
    local TEXT_ALIGN_RIGHT          = _G.TEXT_ALIGN_RIGHT
    local TEXT_ALIGN_BOTTOM         = _G.TEXT_ALIGN_BOTTOM
    local IN_JUMP                           = _G.IN_JUMP
    local IN_FORWARD                        = _G.IN_FORWARD
    local IN_BACK                           = _G.IN_BACK
    local IN_MOVERIGHT                      = _G.IN_MOVERIGHT
    local IN_MOVELEFT                       = _G.IN_MOVELEFT
    local IN_SPEED                          = _G.IN_SPEED
    local IN_DUCK                           = _G.IN_DUCK
    local TEAM_SPECTATOR            = 1002
     
    -- old [detour]
    local old_filecdir                      = file.CreateDir;
    local old_filedel                       = file.Delete;
    local old_fileexist             = file.Exists;
    local old_fileexistex           = file.ExistsEx;
    local old_filefind                      = file.Find;
    local old_filefinddir           = file.FindDir;
    local old_filefindil            = file.FindInLua;
    local old_fileisdir                     = file.IsDir;
    local old_fileread                      = file.Read;
    local old_filerename            = file.Rename;
    local old_filesize                      = file.Size;
    local old_filetfind                     = file.TFind;
    local old_filetime                      = file.Time;
    local old_filewrite             = file.Write;
    local old_dbginfo                       = debug.getinfo;
    local old_dbginfo                       = debug.getupvalue;
    local old_cve                           = ConVarExists;
    local old_gcv                           = GetConVar;
    local old_gcvn                          = GetConVarNumber;
    local old_gcvs                          = GetConVarString;
    local old_rcc                           = RunConsoleCommand;
    local old_hookadd                       = hook.Add;
    local old_hookrem                       = hook.Remove;
    local old_ccadd                         = concommand.Add;
    local old_ccrem                         = concommand.Remove;
    local old_cvaracc                       = cvars.AddChangeCallback;
    local old_cvargcvc                      = cvars.GetConVarCallbacks;
    local old_cvarchange            = cvars.OnConVarChanged;
    local old_require                       = require;
    local old_eccommand             = engineConsoleCommand;
     
     
    --Fonts--
    surface.CreateFont("ESPFont",{font = "ScoreboardText", size = 17, weight = 400, antialias = 0})
    surface.CreateFont("ESPFont_Small",{font = "Default", size = 12, weight = 200, antialias = 0})
    surface.CreateFont("Logo",{font = "ScoreboardText", size = 17, weight = 400, antialias = 0})
    surface.CreateFont("Ampbot_ScoreboardText",{font = "ScoreboardText", size = 15, weight = 700, antialias = 0})
    surface.CreateFont("Ampbot_coolvetica",{font = "coolvetica", size = 16, weight = 500, antialias = 0})
    surface.CreateFont("Ampbot_hvh",{font = "ScoreboardTextt", size = 15, weight = 1000, antialias = 1})
     
    --Materials--
    function Ampbot:CreateMaterial()
    local BaseInfo = {
    ["$basetexture"] = "models/debug/debugwhite",
    ["$model"]       = 1,
    ["$translucent"] = 1,
    ["$alpha"]       = 1,
    ["$nocull"]      = 1,
    ["$ignorez"]     = 1
    }      
    local mat      
    if GetConVarString("Ampbot_ESP_Chams_Material") == "Solid" then
            mat = CreateMaterial( "Ampbot_solid", "VertexLitGeneric", BaseInfo )
    elseif GetConVarString("Ampbot_ESP_Chams_Material") == "Wireframe" then
            mat = CreateMaterial( "Ampbot_wire", "Wireframe", BaseInfo )
    end
       return mat // return the var to the function
    end
     
    /**************************************
    Name: Logger
    Purpose: Logs functions and shit
    **************************************/
    concommand.Add("Ampbot_StartLog",function() -- file.Exists is being bad, this is an alternative
    file.Write("Ampbot/log.txt","Log created: ("..os.date()..") \n")
    end)
     
    function Log(msg)
    file.Append("Ampbot/log.txt","["..os.date().."]: "..msg.."\n")
    end
    Log("Loading....")
     
     
    /*******************************************
    Name: Print/Chat functions
    Purpose: Notify the user of what's going on
    ********************************************/
    function Ampbot.Print(msg)
            print("[Ampbot] "..msg)
    end
     
    function Ampbot.Notify(dosound,col,msg)
            if col then
                    col = col
            end
    chat.AddText(
    iceblue, "[Ampbot] ",
    col, msg)
            if dosound == sound then
                    local beep = Sound( "/buttons/button17.wav" )
                    local beepsound = CreateSound( LocalPlayer(), beep )
                    beepsound:Play()
            end
    end
     
    /***********************************************
    Name: Hook functions
    Purpose: Add hooks and protect from anticheats
    ************************************************/
     
    -- Addhook
    local function AddHook(Type,Function)
            Name = Type.." | "..math.random(1,1000),math.random(1,2000),math.random(1,3000) -- Simple hook names
            Ampbot.Print("[ADDED] Hook: ["..Type.."] | Name: "..Name.."")
            return old_hookadd(Type,Name,Function)
    end
     
    -- RemoveHook
    local function RemoveHook(Type,Function)
            Ampbot.Print("[REMOVED] Hook: ["..Type.."]")
            return old_hookadd(Type,Function)
    end
     
    /**********************************
    Name: File Shit
    Purpose: Anything relating to file.
    ***********************************/
    -- Write file
    function AddFile(Name,Data)
            Ampbot.Print("[WROTE] File: "..Name.."")
            return old_filewrite(Name,Data)
    end
     
    /**************
    Random String
    **************/
    function RandomString( len )
            local ret = ""
                    for i = 1 , len do
                            ret = ret .. string.char( math.random( 65 , 116 ) )
            end
            return ret
    end
     
    /**********************
    Name: Timer shit
    Purpose: Anything timer
    ***********************/
    function AddTimer( sec, rep, func )
            local index = RandomString( 10 )       
            Ampbot.timers[ index ] = sec
            timer.Create( index, sec, rep, func )
    end
     
    /******************************************
    Name: ConCommand Shit
    Purpose: Anything related to concommands
    ********************************************/
     
    function AddCMD(Name,Function)
            Ampbot.Print("[ADDED] ConCommand: "..Name.."")
            return old_ccadd(Name,Function)
    end
     
    function RemoveCMD(Name)
            Ampbot.Print("[REMOVED] ConCommand: "..Name.."")
            return old_ccrem(Name)
    end
     
    /*******************************************
    Name: ConVars
    Purpose: Anything with ConVars
    ********************************************/
     
    -- AddConVar
    function AddConVar(convar,str,save,data)
            return CreateClientConVar("Ampbot_"..convar,str,true,false), Ampbot.Print("[ADDED] ConVar: Ampbot_"..convar.." ["..str.."]")
    end
     
    /**************************************
    Name: Entity Shit
    Purpose: Anything to do with entities
    ***************************************/
    -- entity finder [addent]
    function AddEnt(entclass)
            if(!table.HasValue(Ampbot.ents,entclass)) then
                    table.insert(Ampbot.ents,entclass)
                    Ampbot.Print("[ADDED] Ent: "..entclass.." to ESP")
                    file.Write("Ampbot/ents.txt", glon.encode( Ampbot.ents ))
            end
    end
     
    -- entity finder [removeent]
    function RemoveEnt(entclass)
            for k, v in pairs(Ampbot.ents) do
                    if(string.Trim(v) == entclass) then
                            Ampbot.ents[k] = nil
                            Ampbot.Print("[REMOVED] Ent: "..entclass.." from the ESP")
                    end
            end
            file.Write("Ampbot/ents.txt", glon.encode( Ampbot.ents ))
    end
     
    -- entity finder [clear ents]
    function ClearEnts()
            Ampbot.ents = {}
            file.Write("Ampbot/ents.txt", glon.encode( Ampbot.ents ))
    end
     
    -- entity finder [IsCustomEnt()]
    function IsCustomEnt( entclass )
            return table.HasValue( Ampbot.ents, entclass )
    end
     
     
    /**************************
    Name: Derma shit
    Purpose: Anything Derma
    ***************************/
    function AddCheckBox( text, cvar, parent, x, y, tt )
    local checkbox = vgui.Create( "DCheckBoxLabel", parent )
    checkbox:SetPos( x, y )
    checkbox:SetText( text )
    checkbox:SetConVar( cvar )
    checkbox:SetTextColor(white)
    checkbox:SetTooltip( tt or "No Tool Tip" )
    checkbox:SizeToContents()      
    end
     
    // AddSlider for the derma
    function AddSlider( text, cvar, parent, min, max, decimals, x, y, wide, tt )
    local slider = vgui.Create( "DNumSlider" )
    slider:SetParent( parent )
    slider:SetPos( x, y )
    slider:SetWide( wide )
    slider:SetText( text )
    --slider:SetTextColor(BLACK)
    slider:SetMin( min )
    slider:SetMax( max )
    slider:SetDecimals( decimals )
    slider:SetConVar( cvar )
    slider:SetTooltip( tt or "No Tool Tip" )
    end
     
    Gradient = surface.GetTextureID( "gui/gradient" )
    function DrawBox( x, y, wide, tall, dropsize )
            draw.RoundedBoxEx( 4, x, y, wide, dropsize, iceblue, true, true, false, false )
            draw.RoundedBoxEx( 4, x, y + dropsize, wide, tall - dropsize, Color( 0, 0, 0, 100 ), false, false, true, true )
    end
     
    /*************************
    Name: CreatePos
    Purpose: Create a position
    Credits: BaconBot
    ***************************/
    function CreatePos(v)
    local ply = LocalPlayer()
    local center = v:LocalToWorld( v:OBBCenter() )
    local min, max = v:OBBMins(), v:OBBMaxs()
    local dim = max - min   local z = max + min    
    local frt       = ( v:GetForward() ) * ( dim.y / 2 )
    local rgt       = ( v:GetRight() ) * ( dim.x / 2 )
    local top       = ( v:GetUp() ) * ( dim.z / 2 )
    local bak       = ( v:GetForward() * -1 ) * ( dim.y / 2 )
    local lft       = ( v:GetRight() * -1 ) * ( dim.x / 2 )
    local btm       = ( v:GetUp() * -1 ) * ( dim.z / 2 )
    local s = 1
    local FRT       = center + frt / s + rgt / s + top / s; FRT = FRT:ToScreen()
    local BLB       = center + bak / s + lft / s + btm / s; BLB = BLB:ToScreen()
    local FLT       = center + frt / s + lft / s + top / s; FLT = FLT:ToScreen()
    local BRT       = center + bak / s + rgt / s + top / s; BRT = BRT:ToScreen()
    local BLT       = center + bak / s + lft / s + top / s; BLT = BLT:ToScreen()
    local FRB       = center + frt / s + rgt / s + btm / s; FRB = FRB:ToScreen()
    local FLB       = center + frt / s + lft / s + btm / s; FLB = FLB:ToScreen()
    local BRB       = center + bak / s + rgt / s + btm / s; BRB = BRB:ToScreen()   
    local z = 100
    if ( v:Health() <= 50 ) then z = 100 end
    local x, y = ( ( v:Health() / 100 ) ), 1
    if ( v:Health() <= 0 ) then x = 1 end
    local FRT3      = center + frt + rgt + top / x; FRT3 = FRT3; FRT3 = FRT3:ToScreen()
    local BLB3      = center + bak + lft + btm / x; BLB3 = BLB3; BLB3 = BLB3:ToScreen()
    local FLT3      = center + frt + lft + top / x; FLT3 = FLT3; FLT3 = FLT3:ToScreen()
    local BRT3      = center + bak + rgt + top / x; BRT3 = BRT3; BRT3 = BRT3:ToScreen()
    local BLT3      = center + bak + lft + top / x; BLT3 = BLT3; BLT3 = BLT3:ToScreen()
    local FRB3      = center + frt + rgt + btm / x; FRB3 = FRB3; FRB3 = FRB3:ToScreen()
    local FLB3      = center + frt + lft + btm / x; FLB3 = FLB3; FLB3 = FLB3:ToScreen()
    local BRB3      = center + bak + rgt + btm / x; BRB3 = BRB3; BRB3 = BRB3:ToScreen()    
    local x, y, z = 1.1, 0.9, 1
    local FRT2      = center + frt / y + rgt / z + top / x; FRT2 = FRT2:ToScreen()
    local BLB2      = center + bak / y + lft / z + btm / x; BLB2 = BLB2:ToScreen()
    local FLT2      = center + frt / y + lft / z + top / x; FLT2 = FLT2:ToScreen()
    local BRT2      = center + bak / y + rgt / z + top / x; BRT2 = BRT2:ToScreen()
    local BLT2      = center + bak / y + lft / z + top / x; BLT2 = BLT2:ToScreen()
    local FRB2      = center + frt / y + rgt / z + btm / x; FRB2 = FRB2:ToScreen()
    local FLB2      = center + frt / y + lft / z + btm / x; FLB2 = FLB2:ToScreen()
    local BRB2      = center + bak / y + rgt / z + btm / x; BRB2 = BRB2:ToScreen() 
    local maxX = math.max( FRT.x,BLB.x,FLT.x,BRT.x,BLT.x,FRB.x,FLB.x,BRB.x )
    local minX = math.min( FRT.x,BLB.x,FLT.x,BRT.x,BLT.x,FRB.x,FLB.x,BRB.x )
    local maxY = math.max( FRT.y,BLB.y,FLT.y,BRT.y,BLT.y,FRB.y,FLB.y,BRB.y )
    local minY = math.min( FRT.y,BLB.y,FLT.y,BRT.y,BLT.y,FRB.y,FLB.y,BRB.y )
    local minYhp2 = math.min( FRT.y,BLB.y,FLT.y,BRT.y,BLT.y,FRB.y,FLB.y,BRB.y )
    local maxXhp = math.max( FRT3.x,BLB3.x,FLT3.x,BRT3.x,BLT3.x,FRB3.x,FLB3.x,BRB3.x )
    local minXhp = math.min( FRT3.x,BLB3.x,FLT3.x,BRT3.x,BLT3.x,FRB3.x,FLB3.x,BRB3.x )
    local maxYhp = math.max( FRT3.y,BLB3.y,FLT3.y,BRT3.y,BLT3.y,FRB3.y,FLB3.y,BRB3.y )
    local minYhp = math.min( FRT3.y,BLB3.y,FLT3.y,BRT3.y,BLT3.y,FRB3.y,FLB3.y,BRB3.y )     
    local maxX2 = math.max( FRT2.x,BLB2.x,FLT2.x,BRT2.x,BLT2.x,FRB2.x,FLB2.x,BRB2.x )
    local minX2 = math.min( FRT2.x,BLB2.x,FLT2.x,BRT2.x,BLT2.x,FRB2.x,FLB2.x,BRB2.x )
    local maxY2 = math.max( FRT2.y,BLB2.y,FLT2.y,BRT2.y,BLT2.y,FRB2.y,FLB2.y,BRB2.y )
    local minY2 = math.min( FRT2.y,BLB2.y,FLT2.y,BRT2.y,BLT2.y,FRB2.y,FLB2.y,BRB2.y )
    return maxX, minX, maxY, minY, maxX2, minX2, maxY2, minY2, minYhp, maxYhp
    end
     
     
    /*************************************
    Name: PlayerVisible
    Purpose: Check if a player is visible
    *************************************/
    local function CanSee(ply)
        local trace = {start = LocalPlayer():GetShootPos(),endpos = {}}
        local tr = util.TraceLine(trace)
        if tr.Fraction == 1 then
            return true
        else
            return false
        end    
    end
     
    /**********************************
    Name: GetColors
    Purpose: Make a cool color!
    ***********************************/
    local function GetColorCrosshair()
            if LocalPlayer():GetEyeTrace().Entity:IsPlayer() then
                    return 0,255,0,255
            end
            if LocalPlayer():GetEyeTrace().Entity:IsNPC() then
                    return 0,0,255,255
            end
            return team.GetColor(LocalPlayer():Team())
    end
     
    local function GetColorVisible(e)
            if CanSee(e) then
                    return 0,255,0,255
            end
            if !CanSee(e) then
                    return 255,0,0,255
            end
    end
     
     
    /**************************************
    Name: Number shit
    Purpose: Format number, round number, etc
    **************************************/
    function CommaValue(amount)
            local formatted = amount
            while true do  
                    formatted, k = string.gsub(formatted, "^(-?%d+)(%d%d%d)", '%1,%2')
                    if (k==0) then
                            break
                    end
            end
            return formatted
    end
     
    function RoundNum(val, decimal)
            if (decimal) then
                    return math.floor( (val * 10^decimal) + 0.5) / (10^decimal)
            else
                    return math.floor(val+0.5)
            end
    end
     
    function FormatNum(amount, decimal, prefix, neg_prefix)
            local str_amount,  formatted, famount, remain
            decimal = decimal or 2
            neg_prefix = neg_prefix or "-"
            famount = math.abs(RoundNum(amount,decimal))
            famount = math.floor(famount)
            remain = RoundNum(math.abs(amount) - famount, decimal)
            formatted = CommaValue(famount)
            if (decimal > 0) then
                    remain = string.sub(tostring(remain),3)
                    formatted = formatted .. "." .. remain .. string.rep("0", decimal - string.len(remain))
            end
            formatted = (prefix or "") .. formatted
            if (amount<0) then
                    if (neg_prefix=="()") then
                            formatted = "("..formatted ..")"
                    else
                            formatted = neg_prefix .. formatted
                    end
            end
            return formatted
    end
     
    function ConvertTime(sSeconds)
            local nSeconds = tonumber(sSeconds)
            if nSeconds <= 0 then
                            return 0;
                    else
                            local nHours = string.format("%02.f", math.floor(nSeconds/3600));
                            local nMins = string.format("%02.f", math.floor(nSeconds/60 - (nHours*60)));
                            local nSecs = string.format("%02.f", math.floor(nSeconds - nHours*3600 - nMins *60));
                    if tonumber( nHours ) > 0 then
                            return nHours..":"..nMins..":"..nSecs
                    elseif tonumber( nMins ) > 0 and tonumber( nHours ) == 0 then
                            return nMins..":"..nSecs
                    elseif tonumber( nSecs ) > 0 and tonumber( nMins ) == 0 then
                            return nMins..":"..nSecs
                    end
            end
    end
     
    /**********************
    Name: DrawText
    Purpose: Draws text...
    **********************/
    function Ampbot.DrawText( text, font, x, y, colour, xalign, yalign )
            if (font == nil) then font = "Default" end
            if (x == nil) then x = 0 end
            if (y == nil) then y = 0 end   
            local curX = x
            local curY = y
            local curString = ""   
            surface.SetFont(font)
            local sizeX, lineHeight = surface.GetTextSize("\n")    
            for i=1, string.len(text) do
                    local ch = string.sub(text,i,i)
                    if (ch == "\n") then
                            if (string.len(curString) > 0) then
                                    draw.SimpleText(curString, font, curX, curY, colour, xalign, yalign)
                            end                    
                            curY = curY + (lineHeight/2)
                            curX = x
                            curString = ""
                    elseif (ch == "\t") then
                            if (string.len(curString) > 0) then
                                    draw.SimpleText(curString, font, curX, curY, colour, xalign, yalign)
                            end
                            local tmpSizeX,tmpSizeY =  surface.GetTextSize(curString)
                            curX = math.ceil( (curX + tmpSizeX) / 50 ) * 50
                            curString = ""
                    else
                            curString = curString .. ch
                    end
            end    
            if (string.len(curString) > 0) then
                    draw.SimpleText(curString, font, curX, curY, colour, xalign, yalign)
            end
    end
     
    local function FillRGBA(x,y,w,h,col)
        surface.SetDrawColor( col.r, col.g, col.b, col.a );
        surface.DrawRect( x, y, w, h );
    end
     
    local function OutlineRGBA(x,y,w,h,col)
        surface.SetDrawColor( col.r, col.g, col.b, col.a );
        surface.DrawOutlinedRect( x, y, w, h );
    end
     
    /*********************
    Name: IsVehicle
    Purpose: Find vehicles
    *********************/
    function Ampbot.IsVehicle( e )      
            local ply = LocalPlayer()      
            if ( string.find( e:GetClass(), "prop_vehicle_" ) && ply:GetMoveType() ~= 0 ) then
                    return true
            end
            return false
    end
     
    /***************************
    Name: SetColors
    Purpose: Set Colors
    ****************************/
    function SetColors(e)
            local ply, class, model = LocalPlayer(), e:GetClass(), e:GetModel()
            local col      
            if ( e:IsPlayer() ) then
                    col = Color(0,255,0,255)
            elseif ( e:IsNPC() ) then
                    col = Color( 255, 0, 0, 20 )           
            elseif IsCustomEnt( e:GetClass() ) then
                    col = Color( 0, 200, 255, 50 )         
            else
                    col = Color( 255, 255, 255, 255 )              
            end    
            return col
    end
     
    /******************************
    Name: Get Admin Type
    Purpose: Get Admin Type..
    *******************************/
    local function GetAdminType(e)
            if e:IsAdmin() && !e:IsSuperAdmin() then
                    return " [Admin] "
            elseif( e:IsSuperAdmin() ) then
                    return " [SuperAdmin] "
            end
            return " "
    end
     
    /*******************************************
    Name: Anti-Cheat bypasses
    Purpose: Bypass shitty LUA anti-cheats
    ********************************************/
     
    Ampbot.Print("[Anti-Cheat] Detected by: Cherry's AC (Working on a bypass method)")
    Ampbot.Print("[Anti-Cheat] Detected by: LIFEPUNCH Anti-Cheat")
    Ampbot.Print("[Anti-Cheat] Will bypass: SourceMod Anti-Cheat") -- SHOULD bypass by default, haven't got any problems yet.
     
     
    /****************************
    Name: Create ConVars
    Purpose: Create ConVars..
    *****************************/
    AddConVar("ESP_Info",0)
    AddConVar("ESP_Box",0)
    AddConVar("ESP_HPBar",0)
    AddConVar("ESP_Skeleton",0)
    AddConVar("ESP_Tracer",0)
    AddConVar("ESP_Crosshair",0)
    AddConVar("ESP_Chams",0)
    AddConVar("ESP_Chams_Material","Solid")
    AddConVar("ESP_Ents",0)
    AddConVar("ESP_Distance",1000)
    AddConVar("ESP_Info_Type","info")
     
	AddConVar("PERP_Fuel",0)
	AddConVar("PERP_Druggy",0)
	AddConVar("PERP_Weed",0)
	AddConVar("PERP_RPNames",0)
	AddConVar("PERP_PlayerInfo",0)
	 
    AddConVar("MISC_Bunnyhop",0)
    AddConVar("MISC_TTT",0)
    AddConVar("MISC_ChatSpam",0)
    AddConVar("MISC_ChatSpam_Msg"," ")
    AddConVar("MISC_AntiAFK",0)
    AddConVar("MISC_CSNoclip",0)
    AddConVar("MISC_Thirdperson",0)
    AddConVar("MISC_RPGod",0)
    AddConVar("MISC_Namechanger",0)
    AddConVar("MISC_ShowNotifications",0)
    AddConVar("MISC_SpeedHack_Speed",3.5)
    AddConVar("MISC_ShowSpec",0)
    AddConVar("MISC_ShowAdmins",0)
          
    AddConVar("AIM_Friendly",0)
    AddConVar("AIM_Steam",0)
    AddConVar("AIM_Admins",0)
    AddConVar("AIM_Auto",0)
    AddConVar("AIM_NoRecoil",0)
    AddConVar("AIM_Offset",0)
    AddConVar("AIM_AimSpot","Eye")
    AddConVar("AIM_Trigger",0)
    AddConVar("AIM_Silent",0)
    AddConVar("AIM_SH",0)
    AddConVar("AIM_Anti",0)
     
     
     
    /***********************************
    concommands to find entities and shit
    **************************************/
     
    AddCMD("_ents",function()
    PrintTable(ents.GetAll())
    end)
     
    AddCMD("_players",function()
    PrintTable(player.GetAll())
    end)
     
     
/**********************
Set some ConVars to 0
**********************/
old_rcc("Ampbot_PERP_Fuel","0")
old_rcc("Ampbot_PERP_Druggy","0")
old_rcc("Ampbot_PERP_Weed","0")
old_rcc("Ampbot_PERP_RPNames","0")
old_rcc("Ampbot_PERP_PlayerInfo","0")
old_rcc("Ampbot_MISC_ChatSpam","0")
old_rcc("Ampbot_ESP_Tracer","0")



/*******************
Start of cheat
*******************/

--[[
	CHAMS
]]--

-- distance check
function IsCloseEnough(ent)
	local dist = ent:GetPos():Distance( LocalPlayer():GetPos() )
	if( dist <= GetConVarNumber("Ampbot_ESP_Distance") and ent:GetPos() != Vector( 0, 0, 0 ) ) then
		return true
	end
	return false	
end

function Chams()
local mat = Ampbot:CreateMaterial()
	if GetConVarNumber("Ampbot_ESP_Chams") == 1 then
		for k,v in pairs(player.GetAll()) do
			local TCol = team.GetColor(v:Team())
			if IsValid(v) and v:Health() > 0 and v:Team() != TEAM_SPECTATOR and IsCloseEnough(v) then
			//Players
			cam.Start3D(EyePos(),EyeAngles())
			render.SuppressEngineLighting( true )
			render.SetColorModulation( ( TCol.r * ( 1 / 255 ) ), ( TCol.g * ( 1 / 255 ) ), ( TCol.b * ( 1 / 255 ) ) )
			render.MaterialOverride( mat )
			v:DrawModel()
			render.SuppressEngineLighting( false )
			render.SetColorModulation(1,1,1)
			render.MaterialOverride( )
			v:DrawModel()
			cam.End3D()
			end
		end
	end
end


local IsLock = false;
--[[ 
	ESP
]]--
function ESP()
	for k, e in pairs( player.GetAll() ) do
local TeamColor = team.GetColor(e:Team())
local HPColor = Color(255,255,255,255)
local Dist = e:GetPos():Distance(LocalPlayer():GetPos());
local wep = "Unknown"
local SteamID = e:SteamID()
local Name = e:Nick()
local hvhpos = ( e:GetPos() + Vector( 0, 0, 130 ) ):ToScreen();
if GetConVarNumber("Ampbot_PERP_RPNames") == 1 then
	Name = e:GetRPName()
else
	Name = e:Nick()
end
local maxX, minX, maxY, minY, maxX2, minX2, maxY2, minY2, minYhp, maxYhp = CreatePos( e )
-- This is bad
if e:Health() >= 90 then HPColor = Color(0,255,0,255)
	elseif e:Health() >= 70 then HPColor = Color(255,255,0,255)
	elseif e:Health() >= 50 then HPColor = Color(255,165,0,255)
	elseif e:Health() >= 30 then HPColor = Color(255,140,0,255)
	elseif e:Health() >= 20 then HPCOlor = Color(255,69,0,255)
	elseif e:Health() >= 10 then HPColor = Color(255,0,0,255)
	else HPColor = Color(255,0,0,255)
end
draw.SimpleTextOutlined(" ","Logo",1285,15,Color(2,0,0,255),4,1,1,red)
		if ( e:IsPlayer() && e:Alive() && e != LocalPlayer() && IsCloseEnough(e) ) then
			if e:GetActiveWeapon() != nil then
				if type(e:GetActiveWeapon()) == "Weapon" then
					if e:GetActiveWeapon() and e:GetActiveWeapon():IsValid() then
						wep = e:GetActiveWeapon():GetPrintName()
						
							-- ESP INFO
							if (GetConVarNumber("Ampbot_ESP_Info") == 1 && GetConVarString("Ampbot_ESP_Info_Type") == "info") then
								draw.SimpleTextOutlined( Name..GetAdminType(e), "Ampbot_coolvetica", maxX2, minY2, TeamColor,4,1,1,Color(0,0,0))
								draw.SimpleTextOutlined( "H: " .. e:Health(), "ESPFont_Small", maxX2, minY2 + 10, HPColor, 4,1, 1, black )
								draw.SimpleTextOutlined( "D: " .. math.floor(Dist), "ESPFont_Small", maxX2, minY2 + 20, iceblue, 4, 1, 1, black )
								draw.SimpleTextOutlined( "W: " .. wep, "ESPFont_Small", maxX2, minY2 + 30, iceblue, 4, 1, 1, black)
								if e:GetFriendStatus() == "friend" then
									draw.SimpleTextOutlined( "[Friend]", "ESPFont_Small", maxX2, minY2 - 10, iceblue, 4, 1,1,black)
								end
									if e:IsAdmin() then
										draw.SimpleText("[Admin]","ESPFont_Small",maxX2,minY2 -20,cyan,4,1,1,black)
									end
							elseif GetConVarString("Ampbot_ESP_Info_Type") == "hvh" then
								draw.SimpleTextOutlined(e:Nick().." ["..e:Health().."]","Default",hvhpos.x,hvhpos.y,TeamColor,4,.5,.5,black,TEXT_ALIGN_CENTER)
							end
							
							-- ESP BOX --
							if GetConVarNumber("Ampbot_ESP_Box") == 1 then
								surface.SetDrawColor(0,0,255,255)				
								surface.DrawLine( maxX, maxY, maxX, minY )
								surface.DrawLine( maxX, minY, minX, minY )					
								surface.DrawLine( minX, minY, minX, maxY )
								surface.DrawLine( minX, maxY, maxX, maxY )
							end
							-- ESP SKELETON --
							local bones = {
							{ S = "ValveBiped.Bip01_Head1", E = "ValveBiped.Bip01_Neck1" },
							{ S = "ValveBiped.Bip01_Neck1", E = "ValveBiped.Bip01_Spine4" },
							{ S = "ValveBiped.Bip01_Spine4", E = "ValveBiped.Bip01_Spine2" },
							{ S = "ValveBiped.Bip01_Spine2", E = "ValveBiped.Bip01_Spine1" },
							{ S = "ValveBiped.Bip01_Spine1", E = "ValveBiped.Bip01_Spine" },
							{ S = "ValveBiped.Bip01_Spine", E = "ValveBiped.Bip01_Pelvis" },
							
							{ S = "ValveBiped.Bip01_Spine4", E = "ValveBiped.Bip01_L_UpperArm" },
							{ S = "ValveBiped.Bip01_L_UpperArm", E = "ValveBiped.Bip01_L_Forearm" },
							{ S = "ValveBiped.Bip01_L_Forearm", E = "ValveBiped.Bip01_L_Hand" },

							{ S = "ValveBiped.Bip01_Spine4", E = "ValveBiped.Bip01_R_UpperArm" },
							{ S = "ValveBiped.Bip01_R_UpperArm", E = "ValveBiped.Bip01_R_Forearm" },
							{ S = "ValveBiped.Bip01_R_Forearm", E = "ValveBiped.Bip01_R_Hand" },

							{ S = "ValveBiped.Bip01_Pelvis", E = "ValveBiped.Bip01_L_Thigh" },
							{ S = "ValveBiped.Bip01_L_Thigh", E = "ValveBiped.Bip01_L_Calf" },
							{ S = "ValveBiped.Bip01_L_Calf", E = "ValveBiped.Bip01_L_Foot" },
							{ S = "ValveBiped.Bip01_L_Foot", E = "ValveBiped.Bip01_L_Toe0" },

							{ S = "ValveBiped.Bip01_Pelvis", E = "ValveBiped.Bip01_R_Thigh" },
							{ S = "ValveBiped.Bip01_R_Thigh", E = "ValveBiped.Bip01_R_Calf" },
							{ S = "ValveBiped.Bip01_R_Calf", E = "ValveBiped.Bip01_R_Foot" },
							{ S = "ValveBiped.Bip01_R_Foot", E = "ValveBiped.Bip01_R_Toe0" },
							}
							if GetConVarNumber("Ampbot_ESP_Skeleton") == 1 then
								for k, v in pairs( bones ) do
									local sPos, ePos = e:GetBonePosition( e:LookupBone( v.S ) ):ToScreen(), e:GetBonePosition( e:LookupBone( v.E ) ):ToScreen()
										if e:IsPlayer() and !e:IsNPC() then
											surface.SetDrawColor(team.GetColor(e:Team()))
										end
										surface.DrawLine(sPos.x,sPos.y,ePos.x,ePos.y)
								end
							end
							-- ESP TRACER --
							if GetConVarNumber("Ampbot_ESP_Tracer") == 1 then	
								cam.Start3D( EyePos() , EyeAngles())
								render.SetMaterial( Material( "trails/laser" ) )
								StartPos = LocalPlayer():GetActiveWeapon():GetPos()
								EndPos = e:GetBonePosition(e:LookupBone("ValveBiped.Bip01_Head1"))
								render.DrawBeam(StartPos, EndPos , 3, 0, 0, Color(0,255,0,255))
								cam.End3D()
							end
							
							-- ESP CROSSHAIR --
							if GetConVarNumber("Ampbot_ESP_Crosshair") == 1 then
								local x, y = ScrW() / 2, ScrH() / 2	
								local Speed = 1
								surface.SetDrawColor(GetColorCrosshair()) 
								CHPosx = math.Clamp(LocalPlayer():GetEyeTrace().HitPos:ToScreen().x,0,ScrW())
								CHPosy = math.Clamp(LocalPlayer():GetEyeTrace().HitPos:ToScreen().y,0,ScrH())
								mathsin = math.sin(CurTime()*Speed)*4
								mathcos = math.cos(CurTime()*Speed)*4
								mathsin2 = math.sin(CurTime()*Speed+0.1)*4
								mathcos2 = math.cos(CurTime()*Speed+0.1)*4
								mathsin3 = math.sin(CurTime()*Speed-0.1)*4
								mathcos3 = math.cos(CurTime()*Speed-0.1)*4
								surface.DrawLine( CHPosx+mathcos*2,CHPosy+mathsin*2,CHPosx+mathcos*5,CHPosy+mathsin*5 );
								surface.DrawLine( CHPosx-mathcos*2,CHPosy-mathsin*2,CHPosx-mathcos*5,CHPosy-mathsin*5 );
								surface.DrawLine( CHPosx+mathsin*2,CHPosy-mathcos*2,CHPosx+mathsin*5,CHPosy-mathcos*5 );
								surface.DrawLine( CHPosx-mathsin*2,CHPosy+mathcos*2,CHPosx-mathsin*5,CHPosy+mathcos*5 );
							end
					end
				end
			end
		end
	end
	for _, v in ipairs( ents.GetAll() ) do
		if( v:IsValid() and IsCustomEnt( v:GetClass() )) then
			if GetConVarNumber("Ampbot_ESP_Ents") == 1 then
				local wepn = v:GetClass()
				local wname = string.Replace(wepn,"weapon_","")
				wname = string.Replace(wname,"_"," ")
				wname = string.upper(wname)
				local entpos = v:GetPos():ToScreen()
				draw.SimpleTextOutlined(""..wname.."", "Logo", entpos.x + 50, entpos.y - 15, color_red, TEXT_ALIGN_CENTER, TEXT_ALIGN_LEFT, .6, black )
				surface.SetDrawColor(255,0,255,255)
				surface.DrawLine(entpos.x,entpos.y,entpos.x,entpos.y-10)
				surface.DrawLine(entpos.x,entpos.y,entpos.x+10,entpos.y)
			end
		end                    
	end
end 

/************
Radar
************/
function DoChecksRadar( e )
	local ply, val = LocalPlayer(), 0	
	if ( e:IsPlayer() && e:GetMoveType() == MOVETYPE_OBSERVER ) then return false end	
	if ( !e:IsValid() || !e:IsPlayer() && !e:IsNPC() || e == ply ) then return false end
	if ( e:IsPlayer() && !e:Alive() ) then return false end
	if ( e:IsNPC() && e:GetMoveType() == 0 ) then return false end
	if ( e:IsWeapon() && e:GetMoveType() == 0 ) then return false end	
	return true	
end

local RRadar

function Radar()	
	local Radar = vgui.Create( "DFrame" )
	Radar:SetSize( 250, 250 )	
	local rW, rH, x, y = Radar:GetWide(), Radar:GetTall(), ScrW() / 2, ScrH() / 2	
	local sW, sH = ScrW(), ScrH()
	Radar:SetPos( sW - rW - 0.1, sH - rH - ( sH - rH ) + 30 )
	Radar:SetTitle( " " )
	Radar:SetVisible( true )
	Radar:SetDraggable( true )
	Radar:ShowCloseButton( false )
	Radar:MakePopup()
	Radar.Paint = function()
		draw.RoundedBox( 2, 0, 0, rW, rH, Color( 0, 0, 0, 100 ) )
		surface.SetDrawColor( 255, 255, 255, 255 )
		--surface.DrawOutlinedRect( 0, 0, rW, rH )		
		local ply = LocalPlayer()		
		local radar = {}
		radar.h		= 250
		radar.w		= 250
		radar.org	= 1000		
		local x, y = ScrW() / 2, ScrH() / 2		
		local half = rH / 2
		local xm = half
		local ym = half		
		surface.DrawLine( xm, ym - 100, xm, ym + 100 )
		surface.DrawLine( xm - 100, ym, xm + 100, ym )		
		for k, e in pairs( ents.GetAll() ) do
			if ( DoChecksRadar(e) ) then				
				local s = 6
				local col = SetColors(e)
				local color = Color( col.r, col.g, col.b, 100 )
				local plyfov = ply:GetFOV() / ( 70 / 1.13 )
				local zpos, npos = ply:GetPos().z - ( e:GetPos().z ), ( ply:GetPos() - e:GetPos() )			
				npos:Rotate( Angle( 180, ( ply:EyeAngles().y ) * -1, -180 ) )
				local iY = npos.y * ( radar.h / ( ( radar.org * ( plyfov  * ( ScrW() / ScrH() ) ) ) + zpos * ( plyfov  * (ScrW() / ScrH() ) ) ) )
				local iX = npos.x * ( radar.w / ( ( radar.org * ( plyfov  * ( ScrW() / ScrH() ) ) ) + zpos * ( plyfov  * (ScrW() / ScrH() ) ) ) )								
				local pX = ( radar.w / 2 )
				local pY = ( radar.h / 2 )			
				local posX = pX - iY - ( s / 2 )
				local posY = pY - iX - ( s / 2 )				
				local text = e:GetClass()				
				if ( e:IsPlayer() ) then 
					text = e:Nick() .. " ["..e:Health().."]"
				elseif ( e:IsNPC() ) then
					text = ""
				elseif (IsCustomEnt(e:GetClass())) then
					text = "Logo"
				end					
				if iX < ( radar.h / 2 ) && iY < ( radar.w / 2 ) && iX > ( -radar.h / 2 ) && iY > ( -radar.w / 2 ) then				
					draw.RoundedBox( s, posX, posY, s, s, color )
					Ampbot.DrawText(
						text,
						"Logo",
						pX - iY - 4,
						pY - iX - 15 - ( s / 2 ),
						color,
						1,
						TEXT_ALIGN_TOP
					)
				end
			end
		end
	end
	Radar:SetMouseInputEnabled( false )
	Radar:SetKeyboardInputEnabled( false )	
	RRadar = Radar
end
Radar()

    /**************************
    NOTIFICATIONS!
    YES, Bringing them back.
    **************************/
    function Notifications()
    local NotifPos = 5
            if GetConVarNumber("Ampbot_MISC_ShowNotifications") == 1 then
                    draw.RoundedBox( 8, -10, 0, 10000, 30, Color(0,0,0,100))
                   
                    if Aimbot == 1 then
                            draw.SimpleText("| Aimbot: ON", "Logo", 0,NotifPos, Color(0,255,0,255))
                    else
                            draw.SimpleText("| Aimbot: OFF", "Logo", 0, NotifPos, Color(255,0,0,255))
                    end
                   
                    if GetConVarNumber("Ampbot_AIM_Auto") == 1 then
                            draw.SimpleText("| Autoshoot: ON", "Logo", 100,NotifPos, Color(0,255,0,255))
                    else
                            draw.SimpleText("| Autoshoot: OFF", "Logo", 100, NotifPos, Color(255,0,0,255))
                    end
                   
                    if GetConVarNumber("Ampbot_AIM_Trigger") == 1 then
                            draw.SimpleText("| TriggerBot: ON", "Logo", 220,NotifPos, Color(0,255,0,255))
                    else
                            draw.SimpleText("| TriggerBot: OFF", "Logo", 220, NotifPos, Color(255,0,0,255))
                    end
                   
                    if GetConVarNumber("Ampbot_AIM_NoRecoil") == 1 then
                            draw.SimpleText("| No Recoil: ON", "Logo", 340,NotifPos, Color(0,255,0,255))
                    else
                            draw.SimpleText("| No Recoil: OFF", "Logo", 340,NotifPos, Color(255,0,0,255))
                    end
                   
                    if GetConVarNumber("Ampbot_AIM_Admins") == 1 then
                            draw.SimpleText("| Target Admins: ON", "Logo", 450,NotifPos, Color(0,255,0,255))
                    else
                            draw.SimpleText("| Target Admins: OFF", "Logo", 450,NotifPos, Color(255,0,0,255))
                    end
                   
                    if GetConVarNumber("Ampbot_AIM_Friendly") == 1 then
                            draw.SimpleText("| Friendly Fire: ON", "Logo", 590,NotifPos, Color(0,255,0,255))
                    else
                            draw.SimpleText("| Friendly Fire: OFF", "Logo", 590,NotifPos, Color(255,0,0,255))
                    end
                   
                    if GetConVarNumber("Ampbot_AIM_Steam") == 1 then
                            draw.SimpleText("| Target Steam Friends: ON", "Logo", 720,NotifPos, Color(0,255,0,255))
                    else
                            draw.SimpleText("| Target Steam Friends: OFF", "Logo", 720, NotifPos, Color(255,0,0,255))
                    end
            end
    end
     
     
    /*****************************************
    Name: Aimbot/Aim functions
    Purpose: Aim for you, because you suck
    Credits: faggot
    *******************************************/
     
    local Tb  = table.Copy( file )
    local Tbs = table.Copy( string )
    local Uw = {}
    local Mw = {}
    local function PlyPos( ply )
    local min = ply:OBBMins()
    local max = ply:OBBMaxs()
           
    local Spots = {
            Vector( min.x, min.y, min.z ),
            Vector( min.x, min.y, max.z ),
            Vector( min.x, max.y, min.z ),
            Vector( min.x, max.y, max.z ),
            Vector( max.x, min.y, min.z ),
            Vector( max.x, min.y, max.z ),
            Vector( max.x, max.y, min.z ),
            Vector( max.x, max.y, max.z )
    }      
    local minX = ScrW() * 2
    local minY = ScrH() * 2
    local maxX = 0
    local maxY = 0
     
            for k,v in pairs( Spots ) do
            local ToScreen = ply:LocalToWorld( v ):ToScreen()
            minX = math.min( minX, ToScreen.x )
            minY = math.min( minY, ToScreen.y )
            maxX = math.max( maxX, ToScreen.x )
            maxY = math.max( maxY, ToScreen.y )
            end
            return minX, minY, maxX, maxY
    end
    AddCMD("+Ampbot_Aim",function()
    Aimon = 1
    end)
     
    AddCMD("-Ampbot_Aim",function()
    Aimon = 0
    IsLock = false
    end)
     
    local function AimSpot(targ)
            if GetConVarString("Ampbot_AIM_AimSpot") == "Eye" then
            local eye = targ:LookupAttachment("eyes")
                    if eye then
                    local pos = targ:GetAttachment(eye)
                            if pos then return pos.Pos end
                    end
            end    
            if GetConVarString("Ampbot_AIM_AimSpot") == "Bone" then
            local bone = targ:LookupBone("ValveBiped.Bip01_Head1")
                    if bone then
                    local pos = targ:GetBonePosition(bone)
                            if pos then return pos end
                    end
            end    
            if GetConVarString("Ampbot_AIM_AimSpot") == "Center" then
            local center = targ:OBBCenter()
                    if center then
                    local pos = targ:LocalToWorld(center)
                            if pos then return pos end
                    end
            end
           
    return targ:LocalToWorld(targ:OBBCenter())
     
    end
     
    local function Exception(ent)
            if (ent == LocalPlayer()) then return false end
            if (ent:Team() == TEAM_SPECTATOR) then return false end
            if (ent:GetMoveType() == MOVETYPE_OBSERVER) then return false end
            if (!ent:Alive() ) then return false end
            if (ent:InVehicle()) then return false end
            if (GetConVarNumber("Ampbot_AIM_Friendly") == 0 && ent:Team() == LocalPlayer():Team()) then return false end  
            if (GetConVarNumber("Ampbot_AIM_Steam") == 0 && ent:GetFriendStatus() == "friend" ) then return false end
    return true
    end
     
    local function Visible(ply)
    local tracedata = {}
            tracedata.start = LocalPlayer():GetShootPos()
            tracedata.endpos = AimSpot(ply) - Vector(0,0,GetConVarNumber("Ampbot_AIM_Offset"))
            tracedata.mask = MASK_SHOT
            tracedata.filter = {ply , LocalPlayer()}
            Trace = util.TraceLine(tracedata)
            if Trace.Hit then return false else return true end
    end
     
     
    local function Aimbot(ucmd)
            if Aimon == 1 then             
                    local ArchAngel = Angle(0,0,0)
                    local target;
                    local distance = math.huge;
                    for _, ply in pairs(player.GetAll()) do
                            if (ply != LocalPlayer() and ply:Alive() and Visible(ply) and Exception(ply)) then
                                    local thedist = ply:GetPos():DistToSqr(LocalPlayer():GetPos());
                                    if (thedist < distance) then
                                            distance = thedist;
                                            target = ply;
                                    end
                            end
                    end
                    if target != nil then
                           
                    local Aimspot = AimSpot(target) - Vector(0,0,GetConVarNumber("Ampbot_AIM_Offset"))
                    Aimspot = Aimspot + target:GetVelocity() / 45 - LocalPlayer():GetVelocity() / 45
                    Angel = (Aimspot - LocalPlayer():GetShootPos()):GetNormal():Angle()
                    Angel.p = math.NormalizeAngle( Angel.p )
                    Angel.y = math.NormalizeAngle( Angel.y )
                            ArchAngel = Angle( Angel.p, Angel.y, 0 )
                                    debug.getregistry()["CUserCmd"].SetViewAngles(ucmd, ArchAngel)
                                    IsLock = 1
                            if GetConVarNumber("Ampbot_AIM_Auto") == 1 then
                    ucmd:SetButtons(bit.bor(ucmd:GetButtons(),IN_ATTACK))
                            end
                            if GetConVarNumber("Ampbot_AIM_SH") == 1 then
                                    ucmd:SetButtons(bit.bor(ucmd:GetButtons(),IN_ATTACK2))  
                            end
                    end
            end
    end
     

	 
    function NameChanger()
            if GetConVarNumber("Ampbot_MISC_Namechanger") == 1 then
                    AddTimer( 1, 1, function()
                            Ampbot.chat(dosound,white,"nope");
                    end )
            end
    end
     
    function Misc()
            if GetConVarNumber("Ampbot_MISC_BunnyHop") == 1 then
                    if input.IsKeyDown(KEY_SPACE) then
                            if LocalPlayer():IsOnGround() then
                                    old_rcc("+Jump")
                                    timer.Create("Bhop",0.01, 0 ,function() old_rcc("-Jump") end)
                            end
                    end
            end
            if GetConVarNumber("Ampbot_AIM_NoRecoil") == 1 then
                    if LocalPlayer():GetActiveWeapon().Primary then
                            LocalPlayer():GetActiveWeapon().Primary.Recoil = 0
                    end
            end
            if GetConVarNumber("Ampbot_MISC_ChatSpam") == 1 then
                    LocalPlayer():ConCommand("say "..GetConVarString("Ampbot_MISC_ChatSpam_Msg"))
            end
            if GetConVarNumber("Ampbot_MISC_RPGod") == 1 then
                    if LocalPlayer():Health() < 100 then
                            LocalPlayer():ConCommand("say /buyhealth"); -- spam buyhealth
                    end
            end
    end
     
    function ShowNotifi()
            -- now spectating
            for k, v in pairs(player.GetAll()) do
                    if (IsValid(v:GetObserverTarget()) and v:GetObserverTarget():IsPlayer() and v:GetObserverTarget() == LocalPlayer()) then
                            if(not table.HasValue(Ampbot.spectators, v)) then
                                    table.insert(Ampbot.spectators, v);
                                    if GetConVarNumber("Ampbot_MISC_ShowSpec") == 1 then
                                            Ampbot.Notify(true,red,""..v:Nick().." is now spectating you!")
                                            surface.PlaySound("buttons/blip1.wav")
                                    end
                            end
                    end
            end
            -- no longer spectating
            for k, v in pairs(Ampbot.spectators) do
                    if (not IsValid(v) or not IsValid(v:GetObserverTarget()) or not v:GetObserverTarget():IsPlayer() or (v:GetObserverTarget() ~= LocalPlayer())) then
                            table.remove(Ampbot.spectators, k);
                            if GetConVarNumber("Ampbot_MISC_ShowSpec") == 1 then
                                    Ampbot.Notify(true,green,""..v:Nick().." is no longer spectating you!")
                            end
                    end
            end
            -- admin join
            if GetConVarNumber("Ampbot_MISC_ShowAdmins") == 1 then
                    for k, v in pairs(player.GetAll()) do
                            if (v:IsAdmin() and not table.HasValue(Ampbot.admins, v)) then
                                    table.insert(Ampbot.admins, v);
                                    Ampbot.Notify(true,white,"Admin " .. v:Nick() .. " has joined!")
                                    surface.PlaySound("buttons/blip1.wav");
                            end
                    end
            end
    end
     
     
    local commands = { "forward" , "back" , "jump" , "moveleft" , "moveright", "duck" }
    function AntiAfk()
            if GetConVarNumber("Ampbot_MISC_AntiAFK") == 1 then
                    local command1 = table.Random( commands )
                    local command2 = table.Random( commands )
                    AddTimer( 1, 1, function()
                            old_rcc( "+"..command1 )
                            old_rcc( "+"..command2 )
                    end )
                    AddTimer( 2, 1, function()
                            old_rcc("-"..command1 )
                            old_rcc("-"..command2 )
                    end )
            end
    end
    AddTimer( 5 , 0 , function() AntiAfk() end )
     
// Traitor finder functions
local Traitors = {};
local PlayerIsTraitor = false
timer.Simple( 3, function()
        if ( gmod.GetGamemode().Name ) == "Trouble in Terrorist Town" then
                local TWeapons = { "weapon_ttt_c4", "weapon_ttt_knife", "weapon_ttt_phammer", "weapon_ttt_sipistol", "weapon_ttt_flaregun", "weapon_ttt_push", "weapon_ttt_radio", "weapon_ttt_teleport", "(Disguise)" }
                local UsedWeapons = {}
                local MapWeapons = {}
function IsATraitor( ply )
        for k, v in pairs( Traitors ) do
                if v == ply then
                        return true
                else
                        return false
                end
        end
end
 
timer.Create("TTT", 0.8, 0, function()
        if GetConVarNumber("Ampbot_MISC_TTT") == 1 then
                if !IsATraitor( ply ) then
                        for k, v in pairs( ents.FindByClass( "player" ) ) do
                                if IsValid( v ) then
                                        if (!v:IsDetective()) then
                                                if v:Team() ~= TEAM_SPECTATOR then
                                                        for wepk, wepv in pairs( TWeapons ) do
                                                                for entk, entv in pairs( ents.FindByClass( wepv ) ) do
                                                                        if IsValid( entv ) then
                                                                                cookie.Set( entv, 100 - wepk )
                                                                                if !table.HasValue( UsedWeapons, cookie.GetNumber( entv ) ) then
                                                                                        if !table.HasValue( MapWeapons, cookie.GetNumber( entv ) ) then
                                                                                                local EntPos = ( entv:GetPos() - Vector(0,0,35) )
                                                                                                        if entv:GetClass() == wepv then
                                                                                                                if v:GetPos():Distance( EntPos ) <= 1 then
                                                                                                                        table.insert( Traitors, v )
                                                                                                                        Ampbot.Notify(sound,red,v:Nick() .. " has traitor weapon: " .. wepv )
                                                                                                                        if !table.HasValue( UsedWeapons, cookie.GetNumber( entv ) ) then
                                                                                                                                table.insert( UsedWeapons, cookie.GetNumber( entv ) )
                                                                                                                        else
                                                                                                                        if !table.HasValue( MapWeapons, cookie.GetNumber( entv ) ) then
                                                                                                                                table.insert( MapWeapons, cookie.GetNumber( entv ) )
                                                                                                                        end
                                                                                                                end
                                                                                                        end
                                                                                                end
                                                                                        end
                                                                                end
                                                                        end
                                                                end
                                                        end
                                                end
                                        end
                                end
                        end
                end
        end
end )
 
AddHook("HUDPaint",function()
        if GetConVarNumber("Ampbot_MISC_TTT") == 1 then
                for k, e in pairs( Traitors ) do
                        local maxX, minX, maxY, minY, maxX2, minX2, maxY2, minY2, minYhp, maxYhp = CreatePos( e )
                        if IsValid( e ) then
                                if e:Team() ~= TEAM_SPECTATOR then
                                        if ( !e:IsDetective() ) then
                                                PlayerIsTraitor = true
                                                draw.SimpleTextOutlined( "[TRAITOR]", "ESPFont", maxX2, minY2 -20, red, 4, 1, 1, black )
                                        end
                                end
                        end
                end
        end
end )
 
AddHook("TTTPrepareRound",function()
timer.Simple( 2, function()
        for k, v in pairs( Traitors ) do
                table.remove( Traitors, k )
                Traitors = {}
        end
                for k, v in pairs( UsedWeapons ) do
                        table.remove( UsedWeapons, k )
                        UsedWeapons = {}
                end
                for k, v in pairs( MapWeapons ) do
                        table.remove( MapWeapons, k )
                        MapWeapons = {}
                end
        end )
end )
        end
end )
     
local function PlayerConnect( name, ip )
	if GetConVarNumber("Ampbot_misc_logips") == 1 then
	surface.PlaySound("ambient/levels/canals/drip4.wav")
	chat.AddText(
	Color(116,187,251,255), "[Ampbot] ",
	Color(150,150,150,255), tostring( name .. "'s IP: " .. ip ) )
	end
end
IsisCreateHook("PlayerConnect", PlayerConnect)

// Mute Players

if CLIENT then

    surface.CreateFont( "NameDefault",
    {
        font        = "Helvetica",
        size        = 20,
        weight      = 800
    })

	concommand.Add("ampbotm_menu", function()	

	local plyrs = player.GetAll()
	local FrameWidth = 500
	local FrameHeight = 350
	local windowTitle = ""
	local muteAdmins = 0

	if (GetConVarString("ampbotm_mute_admins") == "0") then
		windowTitle = " "
		muteAdmins = 0
	else
		windowTitle = " "
		muteAdmins = 1

	end

	DermaFrame = vgui.Create( "DFrame" )
	DermaFrame:SetPos( (ScrW()/2)-100,(ScrH()/2)-100 )
	DermaFrame:SetWidth(FrameWidth)
	DermaFrame:SetHeight(FrameHeight)
	DermaFrame:SetTitle( windowTitle )
	DermaFrame:SetVisible( true )
	DermaFrame:SetDraggable( true )
	DermaFrame:ShowCloseButton( true )
	DermaFrame:Center()
	DermaFrame:SetDeleteOnClose(true)
	DermaFrame:MakePopup()
	function DermaFrame:Paint()
    surface.SetDrawColor( 0, 0, 0, 150 )
    surface.DrawRect( 0, 0, DermaFrame:GetWide(), DermaFrame:GetTall() )
	end
	

	DermaScrollPanel = vgui.Create("DPanelList", DermaFrame)
	DermaScrollPanel:SetPos(6, 25)
	DermaScrollPanel:SetSize(FrameWidth-12, FrameHeight-50-12)
	DermaScrollPanel:SetSpacing(2)
	DermaScrollPanel:SetPadding(2)
	DermaScrollPanel:SetVisible(true)
	DermaScrollPanel:EnableHorizontal(false)
	DermaScrollPanel:EnableVerticalScrollbar(true)

	local scrollWide = DermaScrollPanel:GetWide()

	function CreatePlayerPanels()

	for id, pl in pairs( plyrs ) do

			pl.PlayerPanel = vgui.Create("DPanel")
			pl.PlayerPanel:SetWide(scrollWide)
			pl.PlayerPanel:SetVisible(true)

			pl.PlayerPanelWide = pl.PlayerPanel:GetWide()

			pl.NameLabel = vgui.Create( "DLabel", pl.PlayerPanel )
			pl.NameLabel:SetFont("NameDefault")
			pl.NameLabel:SetText(pl:Nick())
			pl.NameLabel:SetWide(pl.PlayerPanelWide - 50)
			pl.NameLabel:SetPos(3,3)
			pl.NameLabel:SetColor(Color(0,0,0,255))

			pl.Mute = vgui.Create( "DImageButton", pl.PlayerPanel )
			pl.Mute:SetSize( 20, 20 )

			pl.Muted = pl:IsMuted()

			if ( pl.Muted ) then
				pl.Mute:SetImage( "icon32/muted.png" )
			else
				pl.Mute:SetImage( "icon32/unmuted.png" )
			end

			pl.Mute.DoClick = function()

			pl:SetMuted( !pl.Muted )

			DermaScrollPanel:Clear()

			CreatePlayerPanels()

			if ( pl.Muted ) then
				pl.Mute:SetImage( "icon32/muted.png")

			else
				pl.Mute:SetImage( "icon32/unmuted.png" )
			end
			end

			DermaScrollPanel:AddItem(pl.PlayerPanel)

			pl.PlayerPanel:InvalidateLayout(true)
			pl.PlayerPanel.PerformLayout = function()
			pl.PlayerPanelWide = pl.PlayerPanel:GetWide()
			pl.NameLabel:SetWide(pl.PlayerPanelWide - 50)
			pl.Mute:SetPos(pl.PlayerPanelWide - 20 - 3,3)
			pl.NameLabel:SetPos(3,3)
			end

			if (pl:IsAdmin() and muteAdmins == 0) then
				pl.Mute:SetDisabled(true)
			else
				pl.Mute:SetDisabled(false)
			end
	end
	end

	CreatePlayerPanels()

	muteAllPanel = vgui.Create("DPanel", DermaFrame)
	muteAllPanel:SetWide(scrollWide)
	muteAllPanel:SetVisible(true)
	muteAllPanel:SetBackgroundColor(Color(70,192,255,255))

	muteAllPanelWide = muteAllPanel:GetWide()

	muteAllLabel = vgui.Create( "DLabel", muteAllPanel )
	muteAllLabel:SetFont("NameDefault")
	muteAllLabel:SetText("Mute All")
	muteAllLabel:SetWide(muteAllPanelWide - 50)
	muteAllLabel:SetPos(3,3)
	muteAllLabel:SetColor(Color(0,0,0,255))

	muteAllMuteButton = vgui.Create( "DImageButton", muteAllPanel )
	muteAllMuteButton:SetSize( 20, 20 )
	muteAllMuteButton:SetImage( "icon32/muted.png" )
	muteAllMuteButton.DoClick = function()

		for id2, pl2 in pairs( plyrs ) do
			if (pl2:IsAdmin() and muteAdmins == 0) then
				if (pl2:IsMuted() == true) then
					pl2:SetMuted(false)
				end
			else
				if (pl2:IsMuted() == false) then
					pl2:SetMuted(true)
				end
			end

		end

		DermaScrollPanel:Clear()

		CreatePlayerPanels()
	end

	muteAllUnMuteButton = vgui.Create( "DImageButton", muteAllPanel )
	muteAllUnMuteButton:SetSize( 20, 20 )

	muteAllUnMuteButton:SetImage( "icon32/unmuted.png" )

	muteAllUnMuteButton.DoClick = function()

		for id2, pl2 in pairs( plyrs ) do
			if (pl2:IsMuted() == true) then
				pl2:SetMuted(false)
			end
		end

		DermaScrollPanel:Clear()

		CreatePlayerPanels()
	end

	muteAllPanel:SetPos(6,FrameHeight-25-6)

	muteAllPanel:InvalidateLayout(true)
	muteAllPanel.PerformLayout = function()
	muteAllPanelWide = muteAllPanel:GetWide()
	muteAllLabel:SetWide(muteAllPanelWide - 50)
	muteAllMuteButton:SetPos(muteAllPanelWide - 26 - 20,3)
	muteAllUnMuteButton:SetPos(muteAllPanelWide - 20 - 3,3)
	muteAllLabel:SetPos(3,3)
	end

end)
end

CreateConVar("ampbotm_text_command", "mute", {FCVAR_REPLICATED})


if SERVER then
    hook.Add("PlayerSay", "ampbotmMutePlayers", function(Player, Text, Public)

		local textCommand = "!" .. GetConVar("ampbotm_text_command"):GetString()

        if Text[1] == "!" then

            Text = Text:lower()

            if Text == textCommand then
			Player:ConCommand("ampbotmMute")
                return ""
            end
        end
    end)
end

//

/***************************************
Name: PERP Hack
Purpose: hacks and exploits for PERP
***************************************/
local WeedGrowTime = 60 * 20
function PERP_Druggy()
	local buying = GetGlobalInt("perp_druggy_buy", 0 )
	local selling = GetGlobalInt("perp_druggy_sell", 0 )	
	local cantrobbank = GetGlobalBool("perp_bank_robbing_timer")
	local moneyinbank = GetGlobalInt("perp_realtor_money")	
	if GetConVarNumber("Ampbot_PERP_Druggy") == 1 then
		local posx = 17
		local posy = 15
		DrawBox( posx, posy, 122, 60, 20 )
		draw.SimpleText("Druggy", "ESPFont", posx + 61, posy + 1, Color( 255, 255, 255, 255 ), TEXT_ALIGN_CENTER )
			local buyingtbl = {
				"Buying Weed",
				"Buying Meth",
				"Buying Shrooms",
				"Buying LSD",
				"Buying Shrooms",
				"Buying Cocaine",
			}
			buyingtbl[0] = "Not Buying"
			draw.SimpleText( buyingtbl[buying], "ESPFont", posx + 61, posy + 42, white, TEXT_ALIGN_CENTER, TEXT_ALIGN_TOP )
			local sellingtbl = {
				"Selling Seeds",
				"Selling LSD",
				--"Selling Muscle",
				"Selling Shrooms",
				"Selling Cocaine",
			}
			sellingtbl[0] = "Not Selling"
			draw.SimpleText( sellingtbl[selling], "ESPFont", posx + 61, posy + 62, white, TEXT_ALIGN_CENTER, TEXT_ALIGN_TOP)
	end
end

timer.Remove("DoFuel");
timer.Create("DoFuel",5,0,function()
	if GetConVarNumber("Ampbot_PERP_Fuel") == 1 then
		DoFuel();
	end
end)

function PERP_Weed()
	if GetConVarNumber("Ampbot_PERP_Weed") == 1 then
		local plants = {}
		for k, ent in pairs( ents.FindByClass("ent_pot") ) do
			table.insert( plants, ent )
		end
		for k, ent in pairs( ents.FindByClass("ent_coca") ) do
			table.insert( plants, ent )
		end
		local col = nil
		for k, ent in pairs( plants ) do
			local pos = ent:GetPos() + Vector(0, 0, 10)
			local ang = ent:GetAngles()
			local drawpos = pos:ToScreen()
			local timeleft = 85564
			if( ent:GetClass() == "ent_coca" ) then col = Color( 0, 0, 255 ) else col = Color( 255, 0, 0 ) end
			if( ent.dt != nil ) then
				timeleft = ent:GetTable().GrowthTime - ( CurTime() - ent.dt.SpawnTime )
			elseif( ent:GetTable().SpawnTime != nil ) then
				timeleft = ent:GetTable().GrowthTime - (CurTime() - ent:GetTable().SpawnTime)
			end
			if( LocalPlayer():GetShootPos():Distance( pos ) <= 4000 ) then
				if( timeleft > 1 and timeleft != 85564 ) then
					draw.SimpleText( ConvertTime( timeleft ) , "ESPFont_Small", drawpos.x, drawpos.y, col, 1, 1 )
				elseif( timeleft != 85564 ) then
					draw.SimpleText( "DONE!", "ESPFont", drawpos.x, drawpos.y, green, 1, 1 )
				end
			end
		end
	end
end

// player info (yourself)
function PERP_PlayerInfo()
	if GetConVarNumber("Ampbot_PERP_PlayerInfo") == 1 then
		draw.RoundedBox( 0, 17, 80, 175, 200, Color(0,0,0,70) )
		draw.SimpleText("PERP INFO", "Ampbot_ScoreboardText", 60,90, white, 1, 1 )
		draw.SimpleText("HP: "..LocalPlayer():Health(), "Ampbot_ScoreboardText", 55,110, white, 1, 1 )
		draw.SimpleText("Armor: "..LocalPlayer():Armor(), "Ampbot_ScoreboardText", 55,130, white, 1, 1 )	
		draw.SimpleText("Bank: "..FormatNum( LocalPlayer():GetBank(), 2, "$" ), "Ampbot_ScoreboardText", 75,150, white, 1, 1 )
	end
end

// speed hackz


    /*************************
    MENU FUNCTIONS
    *************************/
concommand.Add( "Ampbot_menu", function()
	Menu = vgui.Create( "DFrame")
	Menu:SetSize( 390, 450 )
	Menu:SetTitle("                                                    Ampbot v3")
	Menu:Center()
	Menu:MakePopup()
	function Menu:Paint()
    surface.SetDrawColor( 0, 0, 0, 150 )
    surface.DrawRect( 0, 0, Menu:GetWide(), Menu:GetTall() )
	end
		
		local AdvTab = vgui.Create( "DPropertySheet", Menu)
        AdvTab:SetPos( 5, 25 )
        AdvTab:SetSize( 380, 415 )
		function AdvTab:Paint()
		surface.SetDrawColor( 0, 0, 0, 0 )
		surface.DrawRect( 0, 0, AdvTab:GetWide(), AdvTab:GetTall() )
		end
	

	local Page1 = vgui.Create( "DImage" )
	AdvTab:AddSheet( "Aimbot", Page1, "gui/silkicons/bomb", false, false, "Aimbot Settings" )
	
	local Aim2 = vgui.Create( "DCheckBoxLabel", Page1 )
	Aim2:SetPos( 10, 30 )
	Aim2:SetText( "Autoshoot" )
	Aim2:SetConVar("Ampbot_aim_Auto")
	Aim2:SetValue(GetConVarNumber("Ampbot_aim_Auto"))
	Aim2:SizeToContents()
	
	local Aim3 = vgui.Create( "DCheckBoxLabel", Page1 )
	Aim3:SetPos( 10, 50 )
	Aim3:SetText( "Friendly Fire" )
	Aim3:SetConVar("Ampbot_aim_Friendly")
	Aim3:SetValue(GetConVarNumber("Ampbot_aim_Friendly"))
	Aim3:SizeToContents()
	
	local Aim4 = vgui.Create( "DCheckBoxLabel", Page1 )
	Aim4:SetPos( 10, 70 )
	Aim4:SetText( "Ignore Steam Friends" )
	Aim4:SetConVar("Ampbot_Aim_Steam")
	Aim4:SetValue(GetConVarNumber("Ampbot_Aim_Steam"))
	Aim4:SizeToContents()
	
	local Aim6 = vgui.Create( "DCheckBoxLabel", Page1 )
	Aim6:SetPos( 10, 90 )
	Aim6:SetText( "No Recoil" )
	Aim6:SetConVar("Ampbot_aim_NoRecoil")
	Aim6:SetValue(GetConVarNumber("Ampbot_aim_NoRecoil"))
	Aim6:SizeToContents()

	local Aim7 = vgui.Create( "DCheckBoxLabel", Page1 )
	Aim7:SetPos( 10, 110 )
	Aim7:SetText( "Silent Aim" )
	Aim7:SetConVar("Ampbot_aim_silent")
	Aim7:SetValue(GetConVarNumber("Ampbot_aim_silent"))
	Aim7:SizeToContents()
	
	local Aim9 = vgui.Create( "DCheckBoxLabel", Page1 )
	Aim9:SetPos( 10, 130 )
	Aim9:SetText( "Anti-Aim" )
	Aim9:SetConVar("Ampbot_aim_anti")
	Aim9:SetValue(GetConVarNumber("Ampbot_aim_anti"))
	Aim9:SizeToContents()
	
	local Aim10 = vgui.Create( "DCheckBoxLabel", Page1 )
	Aim10:SetPos( 10, 150 )
	Aim10:SetText( "Stronghold Mode" )
	Aim10:SetConVar("Ampbot_aim_sh")
	Aim10:SetValue(GetConVarNumber("Ampbot_aim_sh"))
	Aim10:SizeToContents()
	
	local TextAim1 = vgui.Create("DLabel")
	TextAim1:SetText( "Aimspot" )
	TextAim1:SetParent( Page1 )
	TextAim1:SetWide(100)
	TextAim1:SetPos(265,340)
	TextAim1:SetTextColor(Color(255,255,255,100))
	
	local ListAim1 = vgui.Create( "DComboBox" )
	ListAim1:SetPos( 250, 360 )
	ListAim1:SetParent( Page1 )
	ListAim1:SetSize( 100, 20 )
	ListAim1:AddChoice( "Bone" )
	ListAim1:AddChoice( "Center" )
	ListAim1:AddChoice( "Eye" )
	ListAim1:SetConVar( "Ampbot_aim_aimspot" )
	
	local FixView = vgui.Create("DButton")
	FixView:SetPos( 132, 350 )
	FixView:SetParent( Page1 )
	FixView:SetSize( 95, 25 )
	FixView:SetText( "Reset Aim Position" )
	FixView.DoClick = function()
	RunConsoleCommand( "FixView" )
	end
	
	local OffSet1 = vgui.Create( "DNumSlider" )
	OffSet1:SetPos( 10, 170 )
	OffSet1:SetParent( Page1 )
	OffSet1:SetWide( 200 )
	OffSet1:SetText( "Angle Offset" )
	OffSet1:SetMin( 0 )
	OffSet1:SetMax( 360 )
	OffSet1:SetDecimals( 0 )
	OffSet1:SetConVar( "Ampbot_aim_offset" )
	
	//
	local Page2 = vgui.Create( "DImage" )
	AdvTab:AddSheet( "ESP", Page2, "gui/silkicons/group", false, false, "ESP Settings" )

	local ESP1 = vgui.Create( "DCheckBoxLabel", Page2 )
	ESP1:SetPos( 10, 10 )
	ESP1:SetText( "Player Info" )
	ESP1:SetConVar("Ampbot_esp_info")
	ESP1:SetValue(GetConVarNumber("Ampbot_esp_info"))
	ESP1:SizeToContents()
	
	local ESP2 = vgui.Create( "DCheckBoxLabel", Page2 )
	ESP2:SetPos( 10, 30 )
	ESP2:SetText( "Player Chams" )
	ESP2:SetConVar("Ampbot_esp_chams")
	ESP2:SetValue(GetConVarNumber("Ampbot_esp_chams"))
	ESP2:SizeToContents()
	
	local ESPs = vgui.Create( "DCheckBoxLabel", Page2 )
	ESPs:SetPos( 10, 50 )
	ESPs:SetText( "Skeleton" )
	ESPs:SetConVar("Ampbot_esp_skeleton")
	ESPs:SetValue(GetConVarNumber("Ampbot_esp_skeleton"))
	ESPs:SizeToContents()
	
	local ESP3 = vgui.Create( "DCheckBoxLabel", Page2 )
	ESP3:SetPos( 10, 70 )
	ESP3:SetText( "Health Bar" )
	ESP3:SetConVar("Ampbot_esp_hpbar")
	ESP3:SetValue(GetConVarNumber("Ampbot_esp_hpbar"))
	ESP3:SizeToContents()
	
	local ESP4 = vgui.Create( "DCheckBoxLabel", Page2 )
	ESP4:SetPos( 10, 90 )
	ESP4:SetText( "2D Player Box" )
	ESP4:SetConVar("Ampbot_esp_2dbox")
	ESP4:SetValue(GetConVarNumber("Ampbot_esp_2dbox"))
	ESP4:SizeToContents()
	
	local ESP5 = vgui.Create( "DCheckBoxLabel", Page2 )
	ESP5:SetPos( 10, 110 )
	ESP5:SetText( "3D Player Box" )
	ESP5:SetConVar("Ampbot_esp_3dbox")
	ESP5:SetValue(GetConVarNumber("Ampbot_esp_3dbox"))
	ESP5:SizeToContents()

	local ESP6 = vgui.Create( "DCheckBoxLabel", Page2 )
	ESP6:SetPos( 10, 130 )
	ESP6:SetText( "Tracers" )
	ESP6:SetConVar("Ampbot_esp_tracer")
	ESP6:SetValue(GetConVarNumber("Ampbot_esp_tracer"))
	ESP6:SizeToContents()

	local Distance3 = vgui.Create( "DNumSlider" )
	Distance3:SetPos( 10, 150 )
	Distance3:SetParent( Page2 )
	Distance3:SetWide( 200 )
	Distance3:SetText( "ESP Distance" )
	Distance3:SetMin( 1 )
	Distance3:SetMax( 25380 )
	Distance3:SetDecimals( 0 )
	Distance3:SetConVar( "Ampbot_esp_distance" )
	
	local ENTMenu1 = vgui.Create("DButton")
	ENTMenu1:SetPos( 132, 350 )
	ENTMenu1:SetParent( Page2 )
	ENTMenu1:SetSize( 95, 25 )
	ENTMenu1:SetText( "Entities Menu" )
	ENTMenu1.DoClick = function()
	RunConsoleCommand( "Ampbot_ESP_menu" )
	end
	
	//
	local Page3 = vgui.Create( "DImage" )
	AdvTab:AddSheet( "Miscellaneous", Page3, "gui/silkicons/world", false, false, "Misc Settings" )
	
	local Misc1 = vgui.Create( "DCheckBoxLabel", Page3 )
	Misc1:SetPos( 10, 10 )
	Misc1:SetText("Crosshair")
	Misc1:SetConVar("Ampbot_esp_crosshair")
	Misc1:SetValue(GetConVarNumber("Ampbot_esp_crosshair"))
	Misc1:SizeToContents()
	
	local Misc2 = vgui.Create( "DCheckBoxLabel", Page3 )
	Misc2:SetPos( 10, 30 )
	Misc2:SetText( "Bunnyhop" )
	Misc2:SetConVar("Ampbot_misc_bunnyhop")
	Misc2:SetValue(GetConVarNumber("Ampbot_misc_bunnyhop"))
	Misc2:SizeToContents()

	local Misc4 = vgui.Create( "DCheckBoxLabel", Page3 )
	Misc4:SetPos( 10, 50 )
	Misc4:SetText( "Log IP's" )
	Misc4:SetConVar("Ampbot_misc_logips")
	Misc4:SetValue(GetConVarNumber("Ampbot_misc_logips"))
	Misc4:SizeToContents()
	
	local Misc6 = vgui.Create( "DCheckBoxLabel", Page3 )
	Misc6:SetPos( 10, 70 )
	Misc6:SetText( "Chat Spam" )
	Misc6:SetConVar("Ampbot_misc_chatspam")
	Misc6:SetValue(GetConVarNumber("Ampbot_misc_chatspam"))
	Misc6:SizeToContents()
	
	local Misc7Text = vgui.Create("DLabel")
	Misc7Text:SetText( "Chat Spam Message" )
	Misc7Text:SetParent( Page3 )
	Misc7Text:SetWide(200)
	Misc7Text:SetPos(10,330)
	Misc7Text:SetTextColor(Color(255,255,255,100))
	
	local Misc7 = vgui.Create( "DTextEntry", Page3 )
	Misc7:SetPos( 10, 350 )
	Misc7:SetTall(15)
	Misc7:SetWide(225)
	Misc7:SetConVar("Ampbot_misc_chatspam_msg")
	Misc7:SetValue(GetConVarNumber("Ampbot_misc_chatspam_msg"))
	Misc7:SetEnterAllowed( true )
	
	local Misc8 = vgui.Create( "DCheckBoxLabel", Page3 )
	Misc8:SetPos( 10, 90 )
	Misc8:SetText( "Notification Bar" )
	Misc8:SetConVar("Ampbot_MISC_ShowNotifications")
	Misc8:SetValue(GetConVarNumber("Ampbot_MISC_ShowNotifications"))
	Misc8:SizeToContents()
	
	local Misc9 = vgui.Create( "DCheckBoxLabel", Page3 )
	Misc9:SetPos( 10, 110 )
	Misc9:SetText( "Show Spectators" )
	Misc9:SetConVar("Ampbot_MISC_ShowSpec")
	Misc9:SetValue(GetConVarNumber("Ampbot_MISC_ShowSpec"))
	Misc9:SizeToContents()
	
	local Misc91 = vgui.Create( "DCheckBoxLabel", Page3 )
	Misc91:SetPos( 10, 130 )
	Misc91:SetText( "Show Admins" )
	Misc91:SetConVar("Ampbot_MISC_ShowAdmins")
	Misc91:SetValue(GetConVarNumber("Ampbot_MISC_ShowAdmins"))
	Misc91:SizeToContents()
	
	local Misc10 = vgui.Create( "DCheckBoxLabel", Page3 )
	Misc10:SetPos( 10, 150 )
	Misc10:SetText( "TTT Mode" )
	Misc10:SetConVar("Ampbot_MISC_TTT")
	Misc10:SetValue(GetConVarNumber("Ampbot_MISC_TTT"))
	Misc10:SizeToContents()
	
	local Speedhack = vgui.Create( "DNumSlider" )
	Speedhack:SetPos( 10, 170 )
	Speedhack:SetParent( Page3 )
	Speedhack:SetWide( 200 )
	Speedhack:SetText( "SpeedHack Speed" )
	Speedhack:SetMin( 1 )
	Speedhack:SetMax( 10 )
	Speedhack:SetDecimals( 1 )
	Speedhack:SetConVar( "Ampbot_MISC_SpeedHack_Speed" )
	
	local ReloadHooksButton = vgui.Create("DButton",Page3)
	ReloadHooksButton:SetText("Reload Hooks")
	ReloadHooksButton:SetPos( 10, 290 )
	ReloadHooksButton:SetSize( 200, 25)
	ReloadHooksButton.DoClick = function()
	Ampbot.hooks:reload()
	Ampbot.Notify(green,"Reloaded hooks.")
	end
	
	local PrintAd = vgui.Create("DButton")
	PrintAd:SetPos( 10, 210 )
	PrintAd:SetParent( Page3 )
	PrintAd:SetSize( 200, 25 )
	PrintAd:SetText( "Print Ranks" )
	PrintAd.DoClick = function()
	RunConsoleCommand( "ampbot_printadmins" )
	end
	
	local Mutep1= vgui.Create("DButton")
	Mutep1:SetPos( 10, 250 )
	Mutep1:SetParent( Page3 )
	Mutep1:SetSize( 200, 25 )
	Mutep1:SetText( "Mute Players" )
	Mutep1.DoClick = function()
	RunConsoleCommand( "ampbotm_menu" )
	end
	
	//
	local Page4 = vgui.Create( "DImage" )
	AdvTab:AddSheet( "Customize", Page4, "gui/silkicons/wrench", false, false, "Customize ESP" )
	
	local Cust4 = vgui.Create( "DNumSlider" )
	Cust4:SetPos( 10, 130 )
	Cust4:SetParent( Page4 )
	Cust4:SetWide( 200 )
	Cust4:SetText( "[ESP Box Color] Red" )
	Cust4:SetMin( 1 )
	Cust4:SetMax( 255 )
	Cust4:SetDecimals( 0 )
	Cust4:SetConVar( "Ampbot_esp_box_color_r" )
		
	local Cust5 = vgui.Create( "DNumSlider" )
	Cust5:SetPos( 10, 170 )
	Cust5:SetParent( Page4 )
	Cust5:SetWide( 200 )
	Cust5:SetText( "[ESP Box Color] Green" )
	Cust5:SetMin( 1 )
	Cust5:SetMax( 255 )
	Cust5:SetDecimals( 0 )
	Cust5:SetConVar( "Ampbot_esp_box_color_g" )
	
	local Cust6 = vgui.Create( "DNumSlider" )
	Cust6:SetPos( 10, 210 )
	Cust6:SetParent( Page4 )
	Cust6:SetWide( 200 )
	Cust6:SetText( "[ESP Box Color] Blue" )
	Cust6:SetMin( 1 )
	Cust6:SetMax( 255 )
	Cust6:SetDecimals( 0 )
	Cust6:SetConVar( "Ampbot_esp_box_color_b" )
end )

//
concommand.Add( "Ampbot_ESP_menu", function()
	local EntPanel = vgui.Create( "DFrame" )
	EntPanel:SetPos( ScrW()/2 - 250, ScrH()/2 - 200 )
	EntPanel:SetSize( 500, 400 )
	EntPanel:SetTitle( "Custom Entities" )
	EntPanel:SetVisible( true )
	EntPanel:SetDraggable( false )
	EntPanel:ShowCloseButton( true )
	EntPanel:MakePopup()
	function EntPanel:Paint()
    surface.SetDrawColor( 0, 0, 0, 150 )
    surface.DrawRect( 0, 0, EntPanel:GetWide(), EntPanel:GetTall() )
	end
	
	local NonEnts = vgui.Create( "DListView", EntPanel )
	NonEnts:SetPos( 20, 45 )
	NonEnts:SetSize( 150, EntPanel:GetTall() - 70 )
	NonEnts:SetMultiSelect(true)
	--NonEnts:SetMultiple( false )
	
	local AddEnt = vgui.Create( "DButton", EntPanel )
	AddEnt:SetPos( EntPanel:GetWide()/2 - 50, EntPanel:GetTall()/2 - 65 )
	AddEnt:SetSize( 100, 30 )
	AddEnt:SetText( "Add Ent ->" )
	
	local Added = vgui.Create( "DComboBox", EntPanel )
	Added:SetPos( EntPanel:GetWide() - 170, 45 )
	Added:SetSize( 150, EntPanel:GetTall() - 70 )
	--Added:SetMultiSelect(true)
	--Added:SetMultiple( false )
		
	local RemoveEnt = vgui.Create( "DButton", EntPanel )
	RemoveEnt:SetPos( EntPanel:GetWide()/2 - 50, EntPanel:GetTall()/2 + 25 )
	RemoveEnt:SetSize( 100, 30 )
	RemoveEnt:SetText( "<- Remove Ent" )

	local function RefreshCombo()
		NonEnts:Clear()
		Added:Clear()
		local listedn = {}
		for k, v in pairs( ents.GetAll() ) do
			if( IsValid( v ) and !IsCustomEnt( v:GetClass() ) and !table.HasValue( listedn, v:GetClass() ) and !table.HasValue( Ampbot.invalidents, v:GetClass() ) and string.Left( v:GetClass(), 8 ) != "class C_" and string.Left( v:GetClass(), 5 ) != "func_" and string.Left( v:GetClass(), 4 ) != "env_") then
				local item = DPanelList:AddItem( v:GetClass() )
				itement = v
				table.insert( listedn, v:GetClass() )
			end
		end
		
		local listeda= {}
		for k, v in pairs( Ampbot.ents ) do
			local item = DListView:AddLine( v )
			itement = v
			table.insert( listeda, v )
		end
	end
	RefreshCombo()
	
	local Clear = vgui.Create( "DButton", EntPanel )
	Clear:SetPos( EntPanel:GetWide()/2 - 45, EntPanel:GetTall() - 85 )
	Clear:SetSize( 90, 30 )
	Clear:SetText( "Clear" )
	Clear.DoClick = function()
		ClearEnts()
		RefreshCombo()
	end
	
	AddEnt.DoClick = function()
		if( #NonEnts:GetSelected() != 0 ) then
			AddEnt( NonEnts:GetSelectedLine().ent:GetClass() )
			RefreshCombo()
		end
	end
	
	RemoveEnt.DoClick = function()
		if( #Added:GetSelected() != 0 ) then
			RefreshCombo()
		end
	end
end)
    /**********************
    Name: Hooks
    Purpose: Hook shit
    ***********************/
     
function hooks_hudpaint()
ESP()
PERP_Druggy()
PERP_PlayerInfo()
Notifications()
end

function hooks_postdraw()
Chams()
end

function hooks_think()
Misc();
NameChanger();
ShowNotifi();
end

function hooks_renderscreenspaceeffects()
end

function hooks_calcview()
end

function hooks_createmove(ucmd)
Aimbot(ucmd)
end

function Ampbot.hooks:load()
Log("Loaded hooks")
AddHook("HUDPaint",hooks_hudpaint)
AddHook("PostDrawEffects",hooks_postdraw)
AddHook("Think",hooks_think)
AddHook("CalcView",hooks_calcview)
AddHook("RenderScreenspaceEffects",hooks_renderscreenspaceeffects)
AddHook("CreateMove",hooks_createmove)
end
Ampbot.hooks:load(); -- load them

function Ampbot.hooks:unload()
RemoveHook("HUDPaint",hooks_hudpaint)
RemoveHook("CalcView",hooks_calcview)
RemoveHook("PostDrawEffects",hooks_postdraw)
RemoveHook("Think",hooks_think)
RemoveHook("RenderScreenspaceEffects",hooks_renderscreenspaceeffects)
RemoveHook("CreateMove",hooks_createmove)
end

function Ampbot.hooks:reload()
Log("Reloaded hooks")
Ampbot.hooks:unload()
Ampbot.hooks:load()
end

function unload()
Log("Unloaded.")
Ampbot.hooks:unload()
old_rcc("-Ampbot_Menu")
RemoveCMD("+Ampbot_Menu")
RemoveCMD("-Ampbot_Menu")
RemoveCMD("+Ampbot_Aim")
RemoveCMD("-Ampbot_Aim")
RemoveCMD("+Ampbot_Speed")
RemoveCMD("-Ampbot_Speed")
RemoveCMD("Ampbot_Menu_Toggle")
timer.Destroy("TTT")
end
     
    /*******
    RUN LAST
    ********/
     
    Ampbot.Notify(dosound,white,"loaded successfully.")
    Log("Loaded!")
