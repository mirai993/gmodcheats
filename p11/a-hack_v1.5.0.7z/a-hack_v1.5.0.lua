// Made by Assault_Trooper
// Version 1.5

local Hack = "[A-Hack] "
local Version = "v1.5"
local Mode = 1
local Distance = 999999999
local tracedata = {}
local Letters = { "b", "c", "d", "f", "g", "h", "j", "k", "l", "m", "n", "p", "q", "r", "s", "t", "v", "w", "x", "y", "z" }  
local Times = { 5, 6, 7, 8, 9 }
local Number = table.Random( Times )
local random = false
Locks = true
local Ready = false
local Spammer = false
local DarkRPEntities = {"money_printer", "drug_lab", "gunlab", "microwave", "spawned_shipment", "food", "melon", "drug", "spawned_weapon"}

local BannedWeapons = {"weapon_physcannon", "weapon_physgun", "weapon_frag", "weapon_real_cs_smoke", "arrest_stick", "unarrest_stick", "stunstick",
"weapon_real_cs_flash", "weapon_real_cs_grenade", "spidermans_swep", "manhack_welder", "laserpointer", "remotecontroller", "med_kit",
"door_ram", "pocket", "weaponchecker", "lockpick", "keypad_cracker", "keys", "weapon_real_cs_knife", "gmod_tool", "gmod_camera", "weapon_crowbar",
"weapon_stunstick", "weapon_knife", "weapon_rpg", "weapon_fishing_rod", "none"}

local AutoSF = ""
local AutoAF = ""
local NoRecoilF = ""
local EspF = ""
local ForceVarF = ""
local SpeedhackF = ""
local NameChangerF = ""
local TimerF = ""
local HookProtF = ""
local SpamF = ""

local HookHideF = { "" }

local SafeTypes = { "Think", "HUDPaint", "CreateMove", "InitPostEntity" }
local SafeNames = { AutoSF, AutoAF, NoRecoilF, EspF, ForceVarF, SpeedhackF, NameChangerF, TimerF, HookProtF, SpamF }

for i=1, Number do

AutoSF = AutoSF .. table.Random( Letters )
AutoAF = AutoAF .. table.Random( Letters )
NoRecoilF = NoRecoilF .. table.Random( Letters )
EspF = EspF .. table.Random( Letters )
ForceVarF = ForceVarF .. table.Random( Letters )
SpeedhackF = SpeedhackF .. table.Random( Letters )
NameChangerF = NameChangerF .. table.Random( Letters )
TimerF = TimerF .. table.Random( Letters )
HookProtF = HookProtF .. table.Random( Letters )
SpamF = SpamF .. table.Random( Letters )

end

local Teams = CreateClientConVar("ah_teams", "0", true, false)
local AimMode = CreateClientConVar("ah_aimbot_bone", "1", true, false)
local Cheats = CreateClientConVar("ah_cheats", "0", true, false)
local Changer = CreateClientConVar("ah_changer", "0", true, false)
local Speed = CreateClientConVar("ah_speed", "1", false, false)
local Norecoil = CreateClientConVar("ah_norecoil", "0", true, false)
local Friends = CreateClientConVar("ah_aimbot_friends", "0", true, false)
local AutoShoot = CreateClientConVar("ah_autoshoot", "0", true, false)
local Aiming = CreateClientConVar("ah_aimbot", "0", true, false)
local Enabled = CreateClientConVar("ah_esp", "0", true, false)
local Enemies = CreateClientConVar("ah_esp_enemies", "0", true, false)
local WEnemies = CreateClientConVar("ah_esp_wireframe_enemies", "0", true, false)
local DarkRPEsp = CreateClientConVar("ah_esp_darkrp", "0", true, false)
local HooksProt = CreateClientConVar("ah_hooks", "0", true, false)
local HookHide = CreateClientConVar("ah_hookhide", "0", true, false)
local NameChange = CreateClientConVar("ah_name", "0", true, false)
local AntiHook = CreateClientConVar("ah_antihook", "0", true, false)
local TimeStop = CreateClientConVar("ah_timestop", "0", true, false)
local TeamColors = CreateClientConVar("ah_esp_team", "0", true, false)
local Mute = CreateClientConVar("ah_mute", "0", true, false)
local LockTarget = CreateClientConVar("ah_aimbot_lock", "0", true, false)
local Crosshair = CreateClientConVar("ah_crosshair", "0", true, false)

print( Hack .. Version .. " loaded" )

hook.Add("Think", "Fag", function()

if HookHide:GetInt() == 1 then

HookHideF = { "GetTable" }

else

HookHideF = { "HookHideFF" }

end

_G["HookHideF"] = function()

return nil

end

end )

concommand.Add( "ah_spammer", function( ply, cmd, args )

hook.Add( "Think", SpamF, function()

if args[1] and LocalPlayer():GetCount( "props" ) < GetConVar( "sbox_maxprops" ):GetInt() then

RunConsoleCommand( "gm_spawn", args[1] )

end

end )

end )

concommand.Add( "ah_chatspammer", function( ply, cmd, args )

hook.Add( "Think", SpamF, function()

if args[1] then

RunConsoleCommand( "say", args[1] )

end

end )

end )

concommand.Add("ah_reload", function()

for k,v in pairs ( SafeNames ) do

nam = v

	for k,v in pairs ( SafeTypes ) do
	
	typ = v
	
		for k,v in pairs ( SafeNames ) do
		
		hook.Remove( typ, nam )
		
		end
	
	end

end

end )

hook.Add("Think", AutoSF, function()

if LocalPlayer():Alive() and AutoShoot:GetInt() == 1 then

local pos = LocalPlayer():GetShootPos()
local ang = LocalPlayer():GetAimVector()

tracedata.start = pos
tracedata.endpos = pos+(ang * Distance)
tracedata.filter = LocalPlayer()

local trace = util.TraceLine(tracedata)

target = trace.Entity

if WeaponCheck() and ModeCheck() and AmmoCheck() then

LocalPlayer():ConCommand("wait 1; +attack; wait 3; -attack; wait 1")

end
end

end )

function ModeCheck()

if target:IsPlayer() and target:InVehicle() then return false end

if Teams:GetInt() == 1 then

if target:IsPlayer() and target:Team() == LocalPlayer():Team() then return false end

end

if Mode == 1 then
if !target:IsNPC() and !target:IsPlayer() then

return false

end

elseif Mode == 2 then
if !target:IsPlayer() then

return false

end

elseif Mode == 3 then
if !target:IsNPC() then

return false

end
end

return true

end

hook.Add("Think", NoRecoilF, function()

if Norecoil:GetInt() == 1 and WeaponCheck() and LocalPlayer():Alive() and LocalPlayer():GetActiveWeapon():IsValid() and
LocalPlayer():GetActiveWeapon().Primary then

LocalPlayer():GetActiveWeapon().Primary.Recoil = 0

else return end

end )



function AmmoCheck()

if Ammo() == 0 then

return false

else

return true

end

end


function Ammo()

if LocalPlayer() and LocalPlayer():GetActiveWeapon() and LocalPlayer():GetActiveWeapon():IsValid() then
 
	actwep = LocalPlayer():GetActiveWeapon()
	
	if ( ! actwep ) then return -1 end
 
	return actwep:Clip1()
	
end
	
end

function TargetCheck( ent )

if LockTarget:GetInt() == 1 then

hook.Add("Think", "lol", function()

	if Locks then

	local Trace = LocalPlayer():GetEyeTrace().Entity
	local Victim = Trace:EntIndex()
	
	Locks = false

	end
	
end )

if !ent:EntIndex() == Victim then return false end

end

if Friends:GetInt() == 1 then

if ent:IsPlayer() and ent:IsValid() then

if ent:GetFriendStatus() == "friend" then return false end

end

end

if Teams:GetInt() == 1 then

if ent:IsPlayer() and ent:Team() == LocalPlayer():Team() then return false end

end

if ent:IsNPC() and ent:GetMoveType() == 0 then return false end

if !ent:IsValid() or !ent:IsNPC() and !ent:IsPlayer() or LocalPlayer() == ent then return false end

if ent:IsPlayer() and !ent:Alive() then return false end

if ent:IsPlayer() and ent:InVehicle() then return false end

	if Mode == 1 then

if ent:IsNPC() or ent:IsPlayer() then return true end
	
	elseif Mode == 2 then

if ent:IsPlayer() then return true end
if ent:IsNPC() then return false end

	elseif Mode == 3 then

if ent:IsNPC() then return true end
if ent:IsPlayer() then return false end

	end

end	

function BonePosition( ent )

if AimMode:GetInt() == 1 then

local hbone = ent:LookupBone("ValveBiped.Bip01_Head1")
return ent:GetBonePosition( hbone )

elseif AimMode:GetInt() == 2 then

local hbone = ent:LookupBone("ValveBiped.Bip01_Spine")
return ent:GetBonePosition( hbone )

elseif AimMode:GetInt() == 3 then

local hbone = ent:LookupBone("ValveBiped.Bip01_R_Calf")
return ent:GetBonePosition( hbone )

end
	
end	

function TargetVisible( ent )

local trace = {start = LocalPlayer():GetShootPos(),endpos = BonePosition( ent ),filter = {LocalPlayer(), ent},mask = 1174421507}
local tr = util.TraceLine(trace)
	
target = tr.Entity
	
if target:IsWorld() then return false end
	
if tr.Fraction == 1 then
		
	return true
	
else
	    
	return false
		
end	
	
end

function GetTarget()

local position = LocalPlayer():EyePos()
local angle = LocalPlayer():GetAimVector()
local tar = {0,0}
	
for _, ent in pairs( ents.GetAll() ) do
		
	if LocalPlayer():Alive() and WeaponCheck() and TargetCheck( ent ) and TargetVisible( ent ) and AmmoCheck() then
			
	local targetpos = ent:EyePos()
	local editor = ( targetpos - position ):Normalize()
			
	editor = editor - angle
	editor = editor:Length()
	editor = math.abs( editor )
			
	if editor < tar[2] or tar[1] == 0 then
	tar = {ent, editor}

	end
end
end
	
return tar[1]

end

local Aimed = _R["CUserCmd"].SetViewAngles

hook.Add("CreateMove", AutoAF, function( UCMD )				
	
if Aiming:GetInt() == 1 and WeaponCheck() then
	
	local targ = GetTarget()
	if targ == 0 then return end
	
    local velocity = targ:GetVelocity() or Vector(0,0,0)
        
	Aimed( UCMD, ( ( BonePosition( targ ) + velocity * 10 * FrameTime() ) - LocalPlayer():GetShootPos() ):Angle() )
		
	local trace = LocalPlayer():GetEyeTrace()

end

end )

function WeaponCheck()

if !LocalPlayer():Alive() then return false end

if LocalPlayer():Alive() and LocalPlayer():GetActiveWeapon():IsValid() then

Weapon = LocalPlayer():GetActiveWeapon():GetClass()

else return false

end

if table.HasValue( BannedWeapons, Weapon ) then

return false

else

return true

end

end

hook.Add("Think", SpeedhackF, function()

if Cheats:GetInt() == 1 then

ForceConVar( CreateConVar( "sv_cheats", "" ), "1" )

end

ForceConVar( CreateConVar( "host_timescale", "" ), tostring( Speed:GetInt() ) )

end )

concommand.Add("+ah_menu", function()

panel = vgui.Create("DFrame")
panel:SetSize(560, 290)
panel:SetPos(ScrW() / 3, ScrH() / 3)
panel:SetTitle( Hack .. "Menu " .. Version )
panel:SetVisible( true )
panel:SetDraggable( true )
panel:ShowCloseButton( true )
panel:MakePopup()

local PropertySheet = vgui.Create( "DPropertySheet" )
PropertySheet:SetParent( panel )
PropertySheet:SetPos( 10, 30 )
PropertySheet:SetSize( 540, 240 )

local base1 = vgui.Create("DFrame")
base1:SetDraggable( false )
base1:ShowCloseButton( false )
base1:SetTitle( "Aimbot Options" )

local base2 = vgui.Create("DFrame")
base2:SetDraggable( false )
base2:ShowCloseButton( false )
base2:SetTitle( "Wallhack Options" )

local base4 = vgui.Create("DFrame")
base4:SetDraggable( false )
base4:ShowCloseButton( false )
base4:SetTitle( "Miscellaneous" )

local base5 = vgui.Create("DFrame")
base5:SetDraggable( false )
base5:ShowCloseButton( false )
base5:SetTitle( "Player Stats" )

local base6 = vgui.Create("DFrame")
base6:SetDraggable( false )
base6:ShowCloseButton( false )
base6:SetTitle( "Defensive Options" )

local base7 = vgui.Create("DFrame")
base7:SetDraggable( false )
base7:ShowCloseButton( false )
base7:SetTitle( "Spammer Options" )

local PlayerList = vgui.Create("DListView")
PlayerList:SetParent(base5)
PlayerList:SetPos(10, 30)
PlayerList:SetSize(510, 170)
PlayerList:SetMultiSelect(false)
PlayerList:AddColumn("Name")
PlayerList:AddColumn("Health")
PlayerList:AddColumn("Armor")
PlayerList:AddColumn("Team")
PlayerList:AddColumn("Class")
 
for k,v in pairs( player.GetAll() ) do

if v:IsSuperAdmin() then
admin = "Super Admin"
elseif v:IsAdmin() then
admin = "Admin"
else
admin = "Player"
end
   
PlayerList:AddLine( v:Nick(), v:Health(), v:Armor() , team.GetName( v:Team() ), admin)
   
end

PropertySheet:AddSheet( "Aimbot", base1, "gui/silkicons/star", false, false, "Aimbot Options" )
PropertySheet:AddSheet( "Wallhack", base2, "gui/silkicons/user", false, false, "Wallhack Options" ) 
PropertySheet:AddSheet( "Miscellaneous", base4, "gui/silkicons/plugin", false, false, "Miscellaneous options" ) 
PropertySheet:AddSheet( "Player List", base5, "gui/silkicons/group", false, false, "List of current players" ) 
PropertySheet:AddSheet( "Defense", base6, "gui/silkicons/shield", false, false, "Set the defensive options" ) 
PropertySheet:AddSheet( "Spam Options", base7, "gui/silkicons/wrench", false, false, "Spammer settings" ) 

local SpeedSlider = vgui.Create("DNumSlider", base4)
SpeedSlider:SetPos( 150, 40 )
SpeedSlider:SetSize( 100, 500 )
SpeedSlider:SetMax( 10 )
SpeedSlider:SetMin( 1 )
SpeedSlider:SetDecimals( 0 )
SpeedSlider:SetConVar( "ah_speed" )
SpeedSlider:SetText("Speed")

local BoneSlider = vgui.Create( "DNumSlider", base4 )
BoneSlider:SetPos( 150, 100 )
BoneSlider:SetSize( 100, 500 )
BoneSlider:SetMax( 3 )
BoneSlider:SetMin( 1 )
BoneSlider:SetDecimals( 0 )
BoneSlider:SetConVar( "ah_aimbot_bone" )
BoneSlider:SetText("Bone")

local CheatsToggle = vgui.Create( "DCheckBoxLabel", base4 )
CheatsToggle:SetPos( 10, 40 )
CheatsToggle:SetText( "Cheats" )
CheatsToggle:SetConVar( "ah_cheats" )
CheatsToggle:SetValue( Cheats:GetInt() )
CheatsToggle:SizeToContents()

local MuteToggle = vgui.Create( "DCheckBoxLabel", base4 )
MuteToggle:SetPos( 10, 70 )
MuteToggle:SetText( "Mute all" )
MuteToggle:SetConVar( "ah_mute" )
MuteToggle:SetValue( Mute:GetInt() )
MuteToggle:SizeToContents()

local ChangerToggle = vgui.Create( "DCheckBoxLabel", base4 )
ChangerToggle:SetPos( 10, 100 )
ChangerToggle:SetText( "Name Changer" )
ChangerToggle:SetConVar( "ah_changer" )
ChangerToggle:SetValue( Changer:GetInt() )
ChangerToggle:SizeToContents()

local HookToggle = vgui.Create( "DCheckBoxLabel", base6 )
HookToggle:SetPos( 10, 40 )
HookToggle:SetText( "Protect Hooks" )
HookToggle:SetConVar( "ah_hooks" )
HookToggle:SetValue( HooksProt:GetInt() )
HookToggle:SizeToContents()

local DestHooks = vgui.Create( "DButton", base4 )
DestHooks:SetPos( 300, 50 )
DestHooks:SetText( "Destroy Hooks" )
DestHooks:SetSize( 130, 30 )
DestHooks.DoClick = function()

RunConsoleCommand( "ah_reload" )

end

local HookHideToggle = vgui.Create( "DCheckBoxLabel", base6 )
HookHideToggle:SetPos( 10, 70 )
HookHideToggle:SetText( "Hide Hooks" )
HookHideToggle:SetConVar( "ah_hookhide" )
HookHideToggle:SetValue( HookHide:GetInt() )
HookHideToggle:SizeToContents()

local AntiHookToggle = vgui.Create( "DCheckBoxLabel", base6 )
AntiHookToggle:SetPos( 10, 100 )
AntiHookToggle:SetText( "Remove Harmful Hooks" )
AntiHookToggle:SetConVar( "ah_antihook" )
AntiHookToggle:SetValue( AntiHook:GetInt() )
AntiHookToggle:SizeToContents()

local TimeStopToggle = vgui.Create( "DCheckBoxLabel", base6 )
TimeStopToggle:SetPos( 10, 130 )
TimeStopToggle:SetText( "Block timers" )
TimeStopToggle:SetConVar( "ah_timestop" )
TimeStopToggle:SetValue( TimeStop:GetInt() )
TimeStopToggle:SizeToContents()

local AutoshootToggle = vgui.Create( "DCheckBoxLabel", base1 )
AutoshootToggle:SetPos( 10, 60 )
AutoshootToggle:SetText( "Autoshoot" )
AutoshootToggle:SetConVar( "ah_autoshoot" )
AutoshootToggle:SetValue( AutoShoot:GetInt() )
AutoshootToggle:SizeToContents()

local LockToggle = vgui.Create( "DCheckBoxLabel", base1 )
LockToggle:SetPos( 10, 90 )
LockToggle:SetText( "Lock Target" )
LockToggle:SetConVar( "ah_aimbot_lock" )
LockToggle:SetValue( LockTarget:GetInt() )
LockToggle:SizeToContents()

local EspToggle = vgui.Create( "DCheckBoxLabel", base2 )
EspToggle:SetPos( 10,50 )
EspToggle:SetText( "Wallhack" )
EspToggle:SetConVar( "ah_esp" )
EspToggle:SetValue( Enabled:GetInt() )
EspToggle:SizeToContents()

local NorecoilToggle = vgui.Create( "DCheckBoxLabel", base1 )
NorecoilToggle:SetPos( 10,120 )
NorecoilToggle:SetText( "No-Recoil" )
NorecoilToggle:SetConVar( "ah_norecoil" )
NorecoilToggle:SetValue( Norecoil:GetInt() )
NorecoilToggle:SizeToContents()

local FriendsToggle = vgui.Create( "DCheckBoxLabel", base1 )
FriendsToggle:SetPos( 10,180 )
FriendsToggle:SetText( "Ignore Friends" )
FriendsToggle:SetConVar( "ah_aimbot_friends" )
FriendsToggle:SetValue( Friends:GetInt() )
FriendsToggle:SizeToContents()

local EspTeamsToggle = vgui.Create( "DCheckBoxLabel", base2 )
EspTeamsToggle:SetPos( 10,80 )
EspTeamsToggle:SetText( "Wallhack Team Colors" )
EspTeamsToggle:SetConVar( "ah_esp_team" )
EspTeamsToggle:SetValue( TeamColors:GetInt() )
EspTeamsToggle:SizeToContents()

local DarkRPEspToggle = vgui.Create( "DCheckBoxLabel", base2 )
DarkRPEspToggle:SetPos( 10, 110 )
DarkRPEspToggle:SetText( "DarkRP Entities" )
DarkRPEspToggle:SetConVar( "ah_esp_darkrp" )
DarkRPEspToggle:SetValue( DarkRPEsp:GetInt() )
DarkRPEspToggle:SizeToContents()

local AimbotToggle = vgui.Create( "DCheckBoxLabel", base1 )
AimbotToggle:SetPos( 10,30 )
AimbotToggle:SetText( "Aimbot" )
AimbotToggle:SetConVar( "ah_aimbot" )
AimbotToggle:SetValue( Aiming:GetInt() )
AimbotToggle:SizeToContents()

local TeamToggle = vgui.Create( "DCheckBoxLabel", base1 )
TeamToggle:SetPos( 10, 150 )
TeamToggle:SetText( "Team-Mode" )
TeamToggle:SetConVar( "ah_teams" )
TeamToggle:SetValue( Teams:GetInt() )
TeamToggle:SizeToContents()

local spambox = vgui.Create("DTextEntry", base7, "Message")  
spambox:SetSize( 150, 25)  
spambox:SetPos( 130, 40)  
spambox:SetKeyboardInputEnabled( true )  
spambox:SetEnabled( true )   
spambox.MessageBox = spambox  

local SpamButton = vgui.Create( "DButton", base7 )
SpamButton:SetPos( 20, 40 )
SpamButton:SetSize( 100, 25 )
SpamButton:SetText( "Spam Prop" )
SpamButton.DoClick = function()

RunConsoleCommand( "ah_spammer", spambox:GetValue() )
LocalPlayer():ChatPrint(Hack .. "Spamming prop: " .. spambox:GetValue() )
 
end

local SpamButton = vgui.Create( "DButton", base7 )
SpamButton:SetPos( 20, 80 )
SpamButton:SetSize( 100, 25 )
SpamButton:SetText( "Spam Chat" )
SpamButton.DoClick = function()

RunConsoleCommand( "ah_chatspammer", spambox:GetValue() )
 
end

local SpamButton = vgui.Create( "DButton", base7 )
SpamButton:SetPos( 20, 120 )
SpamButton:SetSize( 100, 25 )
SpamButton:SetText( "Stop Spam" )
SpamButton.DoClick = function()

hook.Remove( "Think", SpamF )
 
end

mode1 = vgui.Create( "DButton", base1 )
mode1:SetPos( 200, 40 )
mode1:SetSize( 140, 40 )
mode1:SetText( "Aimbot: All" )
mode1.DoClick = function()

Mode = 1
LocalPlayer():ChatPrint( Hack .. "Aimbot Mode: All" )
 
end

mode2 = vgui.Create( "DButton", base1 )
mode2:SetPos( 200, 100 )
mode2:SetSize( 140, 40 )
mode2:SetText( "Aimbot: Player" )
mode2.DoClick = function()

Mode = 2
LocalPlayer():ChatPrint( Hack .. "Aimbot Mode: Player" )
 
end

mode3 = vgui.Create( "DButton", base1 )
mode3:SetPos( 200, 160 )
mode3:SetSize( 140, 40 )
mode3:SetText( "Aimbot: NPC" )
mode3.DoClick = function()

Mode = 3
LocalPlayer():ChatPrint( Hack .. "Aimbot Mode: NPC" )
 
end

local label1 = vgui.Create( "Label", panel )
label1:SetPos( 205, 261 )
label1:SetSize( 140, 40 )
label1:SetText( "Created by Assault_Trooper" )

end )

concommand.Add("-ah_menu", function()

panel:Remove()

end )

hook.Add("Think", NameChangerF, function()

if NameChange:GetInt() == 1 then

RunConsoleCommand( "setinfo", "name", nametext )

end

if Changer:GetInt() == 1 then

RunConsoleCommand("setinfo", "name", table.Random( player.GetAll() ):Nick() .. " ")

end

end )

hook.Add("HUDPaint", EspF, function()

if DarkRPEsp:GetInt() == 1 then

for k, ent in pairs( ents.GetAll() ) do
		
	if ValidEntity(ent) and table.HasValue( DarkRPEntities, ent:GetClass() ) then
			
		local pos = ( ent:GetPos() ):ToScreen()	
		
		draw.DrawText(ent:GetClass() , "ScoreboardText", pos.x, pos.y - 10, Color( 50, 200, 50, 255 ) ,1)
	
	end
		
end
end
	
if Enabled:GetInt() == 1 then

for k,v in pairs ( player.GetAll() ) do
	
	local pos = v:GetPos() + Vector(0,0,90)
	pos = pos:ToScreen()
	
	if v == LocalPlayer() then
	
	name = ""
	dead = ""
	
	else
	
	name = v:Nick()
	dead = "*Dead*"
	
	end
	
	if TeamColors:GetInt() == 1 then
	
	if v:Alive() then
	
	color = team.GetColor( v:Team() )
	dcolor = Color( 0, 0, 0, 0 )
	
	else
	
	color = Color( 0, 0, 0, 255 )
	dcolor = Color( 0, 0, 0, 255 )
	
	end
	
	else
	
	if v:Alive() then
	
	color = Color( 255, 255, 255, 255 )
	dcolor = Color( 0, 0, 0, 0 )
	
	else
	
	color = Color( 0, 0, 0, 255 )
	dcolor = Color( 0, 0, 0, 255 )
	
	end
	
	end
	
	draw.DrawText(dead, "ScoreboardText", pos.x, pos.y + 10, dcolor,1)
	
	
	draw.DrawText(name, "ScoreboardText", pos.x, pos.y - 10, color,1)
	
	
end
	
end
	
end )
