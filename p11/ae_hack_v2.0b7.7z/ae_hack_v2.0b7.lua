--[[
	EXECUTABLE_PATH/scripts/AEDevBeta7.lua [#67247 (#67247), 4211350290]
	..-[AX] SnowBoi | STEAM_0:1:69145936 <31.52.47.113:27005> | [12.01.14 09:28:36PM]
	===BadFile===
]]

surface.PlaySound("ambient/fire/ignite.wav")


LocalPlayer():PrintMessage( HUD_PRINTTALK, "[AE]Owner of AE: Cokeman" )
								chat.AddText(Color(10,60,250), "[AE] Client Updated by Snow Boi")
LocalPlayer():PrintMessage( HUD_PRINTTALK, "[AE]Credits:" )
LocalPlayer():PrintMessage( HUD_PRINTTALK, "[AE]BarmyAaron" )
LocalPlayer():PrintMessage( HUD_PRINTTALK, "[AE]Snow Boi" )
LocalPlayer():PrintMessage( HUD_PRINTTALK, "[AE]Commands:" )
LocalPlayer():PrintMessage( HUD_PRINTTALK, "[AE]Tab and Q to open Menu" )
LocalPlayer():PrintMessage( HUD_PRINTTALK, "[AE]E to quit Menu" )
LocalPlayer():PrintMessage( HUD_PRINTTALK, "[AE]Hold o to flashlight spam" )
LocalPlayer():PrintMessage( HUD_PRINTTALK, "[AE]Hold 3 For Aimbot" )
LocalPlayer():PrintMessage( HUD_PRINTTALK, "[AE]Hold Space for bhop" )
LocalPlayer():PrintMessage( HUD_PRINTTALK, "--------------------------" )
		chat.AddText(Color(255,0,100), "[AE] Loaded version: Beta 7!")
						chat.AddText(Color(250,100,0), "[AE] Client Hidden and protected from server!")
								LocalPlayer():PrintMessage( HUD_PRINTTALK, "--------------------------" )

								




local Cokehack = {Menu = {tabs = {}, b = {}}}
local menu = Cokehack.Menu
 
Cokehack.Settings = {
        aimbot                  = true;
        aimbot_fov              = 180;
        aimbot_bone             = "ValveBiped.Bip01_Head1";
       
        triggerbot              = true;
       
        esp                             = true;
        esp_ply                 = true;
        esp_ply_name    = true;
        esp_ply_rank    = true;
        esp_ply_health  = true;
        esp_ply_dist    = true;
        esp_player_dist = 4000;
        esp_ent                 = true;
        esp_ent_dist    = 3000;
       
        darkrp_god              = false;
        flashlight_spam = true;
        bunnyhop                = false;
		spam               = false;
		ae               = false;
	    afk              = false;
		propspam         = false;
		animation        = false;
		auto        = false;
	    spamadminchat  = false;
		crash  = false;
		nolag  = true;
		reset  = false;
		WeedGrowTime  = false;
		Weed  = false;
		Fule  = false;
		playerinfo  = false;
		ray = false;
		kill = false;
		crashl = false;
		mply = false;
		
}
 
 
 
Cokehack.Whitelist = {
}
Cokehack.Entities = {
        "money_printer";
        "spawned_money";
        "ent_pot_leaf";
        "ent_coca_leaf";
        "topaz_money_printer";
        "sapphire_money_printer";
        "ruby_money_printer";
        "emerald_money_printer";
        "amethyst_money_printer";
        "drug_pot_seeds";
        "perp_di";
}
Cokehack.Phrases = {
        " Cokeman is a gangsta";
        " Chicken Nuggets";
        " Black Man";
        " Dude wtf anticheat cant catch me";
        " AE is the best";
        " Is so AX";
		" Its not snowing";
		" You can close it by pressing E";
		" This is a menu";
		" Aaron was here";
		" Chicken Mc,Nuglets";
		" ALEX IS A DONKEY";
		" You are playing 'Insert shit server name here'";
		" Dat power";
		" Dont get banned";
		" Dont play with fire";
		" BECAUSE YOLO";
		" This is a random phrase";
}
 
Cokehack.Bones = {
        head = "ValveBiped.Bip01_Head1";
        spine = "ValveBiped.Bip01_Spine";
}
 
surface.CreateFont("Trebuchet19cat", {font="TabLarge", size=13, weight=700})
surface.CreateFont("Trebuchetcat", {font="TabLarge", size=10, weight=700})
 
function Cokehack.CloneTable( src ) --cbot
        local new = {}
        for k, v in pairs( src ) do
                local newf = rawget(src, k);
                if( type( newf ) == "table" and v ~= src ) then
                        new[k] = Cokehack.CloneTable( v );
                else
                        new[k] = newf;
                end
        end
 
        return new;
end
 
Cokehack.table                   = Cokehack.CloneTable( table );
Cokehack.hook                    = Cokehack.CloneTable( hook );
Cokehack.math                    = Cokehack.CloneTable( math );
Cokehack.surface                 = Cokehack.CloneTable( surface );
Cokehack.draw                    = Cokehack.CloneTable( draw );
 
local table                     = Cokehack.table;
local hook                              = Cokehack.hook;
local math                              = Cokehack.math;
local surface                   = Cokehack.surface;
local draw                              = Cokehack.draw;
 
function Cokehack.GetShootPos(ent)
        local eyes = ent:LookupAttachment("eyes");
        if(eyes ~= 0) then
                eyes = ent:GetAttachment(eyes);
                if(eyes and eyes.Pos) then
                        return eyes.Pos, eyes.Ang;
                end
        end
end
 
function Cokehack.GetVisible(ent)
        local pos = LocalPlayer():GetShootPos()
        local ang = LocalPlayer():GetAimVector()
        local trace = {start = LocalPlayer():GetShootPos(), endpos = Cokehack.GetShootPos(ent), filter = {LocalPlayer(), ent}, mask = 1174421507};
        local tr = util.TraceLine(trace);
        return(tr.Fraction == 1);
end
 
function Cokehack.Whitelisted(ent)
        if table.HasValue(Cokehack.Whitelist, ent:SteamID())     then return true
        else return false end
end
 
function Cokehack.Target(v)
        if v:IsPlayer() then
                if (Cokehack.GetVisible(v) and (not Cokehack.Whitelisted(v)) and v:Alive() and (v:Health() > 0) and v:Team() ~= TEAM_SPECTATOR) then
                        if (v ~= LocalPlayer() and LocalPlayer():Alive() and LocalPlayer():Team() ~= TEAM_SPECTATOR) then
                                if string.find(gmod.GetGamemode().Name, "Stronghold") then
                                        if (v:Team() ~= LocalPlayer():Team()) then
                                                return true
                                        end
                                else
                                        return true
                                end
                        end
                end
        end
        return false
end
 
function Cokehack.ESP(typ, v)
        if typ == "player" then
                if v:Alive() && v:Health() >= 1 && v ~= LocalPlayer() && /*LocalPlayer():Alive() &&*/ LocalPlayer():Team() ~= TEAM_SPECTATOR then
                        return true
                else
                        return false
                end
        elseif typ == "entity" then
                if IsValid(v) then
                        return true
                end
        end
end
 
function Cokehack.Rank(v)
        if v:IsAdmin() or v:IsSuperAdmin() then
                return "[A] "
        else return "" end
end
 
function Cokehack.Get(value)
        if not(Cokehack.Settings[value]) then return end
       
        if Cokehack.Settings[value] == true then
                return "enabled"
        elseif Cokehack.Settings[value] == false then
                return "disabled"
        elseif Cokehack.Settings[value] == "ValveBiped.Bip01_Head1" then
                return "head"
        elseif Cokehack.Settings[value] == "ValveBiped.Bip01_Spine4" then
                return "spine"
        else
                return Cokehack.Settings[value]
        end
end
 
function Cokehack.Set(value, value2)
        if value2 == "enabled" then
                Cokehack.Settings[value] = true
        elseif value2 == "disabled" then
                Cokehack.Settings[value] = false
        elseif value2 == "head" then
                Cokehack.Settings[value] = "ValveBiped.Bip01_Head1"
        elseif value2 == "spine" then
                Cokehack.Settings[value] = "ValveBiped.Bip01_Spine4"
        else
                Cokehack.Settings[value] = value2
        end
end
 
function Cokehack.GetBone()
        local b = Cokehack.Settings["aimbot_bone"]
        if b == "head" then
                return Cokehack.Bones["head"]
        elseif b == "spine" then
                return Cokehack.Bones["spine"]
        end
        return nil
end
 
function Cokehack.CreateTab(txt, szw, szh, psw, psh, parent, func)
        if(not parent) then return; end
        local panel = vgui.Create("DPanel", menu.frame);
        panel:SetPos(120,25);
        panel:SetSize(375,405);
        if menu.curwin == txt then panel:SetVisible(true) else panel:SetVisible(false) end
        panel.Paint = function()
                local line = "__________________________________________________________________________"
                surface.SetDrawColor( 70, 0, 20, 155 )
                surface.DrawRect( 0, 0, panel:GetWide(), panel:GetTall() )
                surface.CreateFont("shmenufont", {font="coolvetica", size=64, weight=500});
                surface.CreateFont("shmenufont2", {font="coolvetica", size=24, weight=500});
                draw.SimpleText(txt, "shmenufont", 10, 10, Color(255, 255, 00, 235), TEXT_ALIGN_LEFT);
                --draw.SimpleText(line, "MenuLarge", 50, 60, Color(3,3,0,200), TEXT_ALIGN_CENTER)
                if txt == "ESP" then
                        draw.SimpleText("Player ESP", "shmenufont2", 5, 100, Color(255,00,00,235), TEXT_ALIGN_LEFT);
                        draw.SimpleText("Entity ESP", "shmenufont2", 5, 250, Color(255,00,00,235), TEXT_ALIGN_LEFT);
                end
        end
        local button = vgui.Create("DButton", parent);
        button:SetText(txt);
        button:SetSize(szw, szh);
        button:SetPos(psw, psh);
        button.Paint = function(self) derma.SkinHook("PaintOver", "Button", self) end
        button:SetVisible(true);
        button.DoClick = func or function()
                for k,v in pairs(menu.tabs) do
                        if v ~= panel then
                                v:SetVisible(false)
                        end
                end
                panel:SetVisible(true)
                menu.curwin = txt
				                surface.PlaySound("ambient/levels/canals/drip4.wav");
        end
        return panel, button;
end
 
function Cokehack.AddFeature(parent, id, typ, text, val, option1, option2, option3, option4, option5)
        if not(parent) or not(typ) then return; end
        local posy = (55+(id*25))
        if typ == "button" then
                if Cokehack.Settings[val] == nil then return end
                if text ~= nil then
                        local label = vgui.Create("DLabel", parent)
                        label:SetText(text)
                        label:SetPos(5,posy)
                        label:SizeToContents(false)
                end
 
                local button = vgui.Create("DButton", parent)
                if Cokehack.Get(val) == option1 then
                        button:SetText(option1)
                else
                        button:SetText(option2)
                end
                button:SetSize(80,20)
                if id == 0 then
                        button:SetPos(285,45)
                else
                        button:SetPos(285,posy)
                end
                button.DoClick = function()
                        if button:GetText() == option1 then
                                button:SetText(option2); Cokehack.Set(val, option2)
                        else
                                button:SetText(option1); Cokehack.Set(val, option1)
                        end
                end
                return button, label
        elseif typ == "dbutton" then
                local button = vgui.Create("DButton", parent)
                button:SetPos(option1,option2)
                button:SetSize(option3,option4)
                button:SetText(text)
                button.DoClick = option5
                return button
        elseif typ == "slider" then
                local slider = vgui.Create("DNumSlider", parent)
                slider:SetPos(5, posy-10)
                slider:SetText(text)
                slider:SetMinMax(option1, option2)
                slider:SetWide(372.5)
                slider:SetDecimals( 0 )
                slider:SetValue(Cokehack.Get(val))
                slider.OnValueChanged = function(panel, value)
                        local c = tonumber(value)
                        Cokehack.Set(val, math.Round(c))
                end
                return slider;
        elseif typ == "label" then
                local label = vgui.Create("DLabel", parent)
                label:SetText(text)
                label:SetPos(5,posy)
                label:SizeToContents(false)
        end
end
 
function Cokehack.DrMenu()
        if(menu.frame) then menu.frame:Remove(); end
       
        menu.frame = vgui.Create("DFrame");
        menu.frame:SetPos(ScrW()/2-630, ScrH()/2-285);
        menu.frame:SetSize(500, 435);
        menu.frame:SetTitle("AE Hack Alpha Beta 7"..Cokehack.Phrases[math.random(1, table.Count(Cokehack.Phrases))]);
		        menu.frame.Paint = function()
                surface.SetDrawColor(138,192,132,150)
                surface.DrawRect(0, 0,menu.frame:GetWide(),menu.frame:GetTall())
                surface.SetDrawColor(0,255,0,255)
                surface.DrawOutlinedRect(0,0,menu.frame:GetWide(),menu.frame:GetTall())
        end

        menu.frame:SetVisible(true);
        menu.frame:SetDraggable(true);
        menu.frame:SetSizable(false);
        menu.frame:ShowCloseButton(false);
        menu.frame:SetBackgroundBlur(false)
        menu.frame:MakePopup();


 
        menu.buttons = vgui.Create("DPanel", menu.frame)
        menu.buttons:SetPos(5, 25)
        menu.buttons:SetSize(111,406)

        menu.buttons.Paint = function()
                surface.SetDrawColor(10,10,10,255)
                            
        end
 
        menu.tabs.aimbot, menu.b.aimbot         =       Cokehack.CreateTab("Aimbot", 80, 20, 15, 10, menu.buttons)
        menu.tabs.pesp, menu.b.pesp             =       Cokehack.CreateTab("ESP", 80, 20, 15, 30, menu.buttons)
        menu.tabs.misc, menu.b.misc             =       Cokehack.CreateTab("Misc", 80, 20, 15, 50, menu.buttons)
		menu.tabs.perp, menu.b.perp             =       Cokehack.CreateTab("Perp", 80, 20, 15, 70, menu.buttons)
		menu.tabs.cm, menu.b.cm                 =       Cokehack.CreateTab("commands", 80, 20, 15, 90, menu.buttons)
		menu.tabs.an, menu.b.an                 =       Cokehack.CreateTab("Animation WIP", 80, 20, 15, 110, menu.buttons)
       
        local mta      =   menu.tabs.aimbot
        local mtp      =   menu.tabs.pesp
        local mtm      =   menu.tabs.misc
		local perp     =   menu.tabs.perp
		local cm	   =   menu.tabs.cm
		local an       =   menu.tabs.an		
        -- aimbot tab
        Cokehack.AddFeature(mta, 1, "button", "Aimbot", "aimbot", "enabled", "disabled")
        Cokehack.AddFeature(mta, 2, "button", "Aim-bone", "aimbot_bone", "head", "spine")
        Cokehack.AddFeature(mta, 3, "slider", "Aim FOV", "aimbot_fov", 1, 180)
        Cokehack.AddFeature(mta, 4, "button", "Triggerbot Can Be Detected!", "triggerbot", "enabled", "disabled")
       
        -- esp tab
        Cokehack.AddFeature(mtp, 0, "button", nil, "esp", "enabled", "disabled")
       
        Cokehack.AddFeature(mtp, 2, "button", "Enabled", "esp_player", "enabled", "disabled")
        Cokehack.AddFeature(mtp, 3, "button", "Show Name", "esp_ply_name", "enabled", "disabled")
        Cokehack.AddFeature(mtp, 4, "button", "Show Rank", "esp_ply_rank", "enabled", "disabled")
        Cokehack.AddFeature(mtp, 5, "button", "Show Health", "esp_ply_health", "enabled", "disabled")
        Cokehack.AddFeature(mtp, 6, "button", "Show Distance", "esp_ply_dist", "enabled", "disabled")
        Cokehack.AddFeature(mtp, 7, "slider", "Distance", "esp_player_dist", 0, 16000)
        Cokehack.AddFeature(mtp, 9, "button", "Enabled", "esp_ent", "enabled", "disabled")
        Cokehack.AddFeature(mtp, 10, "slider", "Distance", "esp_ent_dist", 0, 16000)
        Cokehack.AddFeature(mtp, 11, "button", "Tracers", "esplas", "enabled", "disabled")
		Cokehack.AddFeature(mtp, 12, "button", "Crosshair", "crosshair", "enabled", "disabled")
      
        -- misc tab
        Cokehack.AddFeature(mtm, 1, "button", "Flashlight Spam", "flashlight_spam", "enabled", "disabled")
        Cokehack.AddFeature(mtm, 2, "button", "DarkRP God Exploit", "darkrp_god", "enabled", "disabled")
        Cokehack.AddFeature(mtm, 3, "button", "Bunnyhop", "bunnyhop", "enabled", "disabled")
		Cokehack.AddFeature(mtm, 4, "button", "Spam", "spam", "enabled", "disabled")
		Cokehack.AddFeature(mtm, 5, "button", "AE was here", "ae", "enabled", "disabled")
		Cokehack.AddFeature(mtm, 6, "button", "AFK Fxing", "afk", "enabled", "disabled")
		Cokehack.AddFeature(mtm, 7, "button", "Propspam", "propspam", "enabled", "disabled")
		Cokehack.AddFeature(mtm, 8, "button", "Auto pistol", "auto", "enabled", "disabled")
		Cokehack.AddFeature(mtm, 9, "button", "Spam AdminChat", "spamadminchat", "enabled", "disabled")
		Cokehack.AddFeature(mtm, 10, "button", "Crash", "crash", "enabled", "disabled")
		Cokehack.AddFeature(mtm, 11, "button", "Nolag", "nolag", "enabled", "disabled")
		Cokehack.AddFeature(mtm, 12, "button", "Resetlag", "reset", "enabled", "disabled")
		
		
		--An
		 Cokehack.AddFeature(an, 1, "button", "Animation", "animation", "enabled", "disabled")
		 Cokehack.AddFeature(an, 2, "button", "stacker", "crash1", "enabled", "disabled")
		
		--Perp Hacks tab
		Cokehack.AddFeature(perp, 1, "button", "WeedGrowTime", "WeedGrowTime", "enabled", "disabled")
		Cokehack.AddFeature(perp, 2, "button", "Weed", "Weed", "enabled", "disabled")
		Cokehack.AddFeature(perp, 4, "button", "Fuel", "Fuel", "enabled", "disabled")
		Cokehack.AddFeature(perp, 3, "button", "playerinfo", "playerinfo", "enabled", "disabled")
		
		
		-- Commands
		Cokehack.AddFeature(cm, 1, "button", "kill", "kill", "enabled", "disabled")
		Cokehack.AddFeature(cm, 2, "button", "Rejoin", "ray", "enabled", "disabled")
		Cokehack.AddFeature(cm, 3, "button", "Stacker", "crashl", "enabled", "disabled")	
		Cokehack.AddFeature(cm, 4, "button", "Music", "mply", "enabled", "disabled")
		
		 

		 
		 
end
 
hook.Add("Think", "CokeMENU", function()
        if(input.IsKeyDown(KEY_TAB) && input.IsKeyDown(KEY_Q) && !menu.frame)then
                Cokehack.DrMenu()
				surface.PlaySound("buttons/button1.wav")
        elseif(menu.frame && input.IsKeyDown(KEY_E))then
                menu.frame:Remove(); menu.frame = nil
                Cokehack.Menu = {}
        end
end)
 
hook.Add("Think", "CokeBOT", function()
        -- triggerbot
        if(Cokehack.Settings["triggerbot"] && input.IsKeyDown(KEY_2)) then
                local pos = LocalPlayer():GetShootPos()
                local ang = LocalPlayer():GetAimVector()
                local tracedata = {}
                tracedata.start = pos
                tracedata.endpos = pos+(ang*9999999999999)
                local trace = util.TraceLine(tracedata)
                if(trace.HitNonWorld) then
                        target = trace.Entity
                        if(target:IsPlayer() and (not Cokehack.Whitelisted(target))) then
                                RunConsoleCommand("+attack")
                                timer.Simple(0.000000000000000000001, function() RunConsoleCommand("-attack") end)
                        end
                end
        end
        -- aimbot [ need bone changing support ]
        if(Cokehack.Settings["aimbot"] && input.IsKeyDown(KEY_2)) /*or Cokehack.Settings["alert"]*/ then
                for k,v in pairs(player.GetAll()) do
                        /*if Cokehack.Settings["aimbot"] && input.IsKeyDown(KEY_2) then*/
                        local bone = Cokehack.Settings["aimbot_bone"];
                                if Cokehack.Target(v) then
                                        local head = v:LookupBone(bone)
                                        local fov = Cokehack.Settings["aimbot_fov"]
                                        if fov == 0 then
                                                local headpos,targetheadang = v:GetBonePosition(head)
                                                LocalPlayer():SetEyeAngles((headpos - LocalPlayer():GetShootPos()):Angle())
                                        else
                                                local lpang = LocalPlayer():GetAngles();
                                                local ang = (v:GetPos() - LocalPlayer():GetPos()):Angle();
                                                local ady = math.abs(math.NormalizeAngle(lpang.y - ang.y))
                                                local adp = math.abs(math.NormalizeAngle(lpang.p - ang.p ))
                                                if not(ady > fov or adp > fov) then
                                                        local headpos,targetheadang = v:GetBonePosition(head)
                                                        if headpos != nil and targetheadang != nil then
                                                        LocalPlayer():SetEyeAngles((headpos - LocalPlayer():GetShootPos()):Angle())
                                                        end
                                                end
                                        end
                                end
                               
                        --end
                        /*if Cokehack.Settings["alert"] then
                                local d = Cokehack.Settings["alert_dist"]
                                if v ~= LocalPlayer() and (v:GetPos():Distance(LocalPlayer():GetPos()) < d) then
                                       
                                end
                        end*/
                end
        end
        if Cokehack.Settings["flashlight_spam"] and input.IsKeyDown(KEY_O) then
                RunConsoleCommand("impulse", "100")
        end
       
        if Cokehack.Settings["darkrp_god"] and LocalPlayer():Health() < 100 and LocalPlayer():Alive() then
                RunConsoleCommand("say", "/buyhealth")
        end
		
		if Cokehack.Settings["ae"] then
                RunConsoleCommand("say", "/ooc AE was  HERE")
				end
	   if Cokehack.Settings["crash"] then
       local CRASHALL = CreateClientConVar("CrashAllClients", "0", true, false)
	   local function doCRSHALL()
        if CRASHALL:GetBool() then
 
                RunConsoleCommand("_DarkRP_DoAnimation", "-1921")
        end
end
timer.Create("allgo", 0, 0, doCRSHALL)
				end
	  
	   if Cokehack.Settings["Weed"]  then
        function PERP_Weed()
        if GetConVarNumber("ae_PERP_Weed") == 1 then
                local plants = {}
                for k, ent in pairs( ents.FindByClass("ent_pot") ) do
                        table.insert( plants, ent )
                end
                for k, ent in pairs( ents.FindByClass("ent_coca") ) do
                        table.insert( plants, ent )
                end
                local col = nil
                for k, ent in pairs( plants ) do
                        local pos = ent:GetPos() + Vector(0, 0, 10)
                        local ang = ent:GetAngles()
                        local drawpos = pos:ToScreen()
                        local timeleft = 85564
                        if( ent:GetClass() == "ent_coca" ) then col = Color( 0, 0, 255 ) else col = Color( 255, 0, 0 ) end
                        if( ent.dt != nil ) then
                                timeleft = ent:GetTable().GrowthTime - ( CurTime() - ent.dt.SpawnTime )
                        elseif( ent:GetTable().SpawnTime != nil ) then
                                timeleft = ent:GetTable().GrowthTime - (CurTime() - ent:GetTable().SpawnTime)
                        end
                        if( LocalPlayer():GetShootPos():Distance( pos ) <= 4000 ) then
                                if( timeleft > 1 and timeleft != 85564 ) then
                                        draw.SimpleText( ConvertTime( timeleft ) , "ESPFont_Small", drawpos.x, drawpos.y, col, 1, 1 )
                                elseif( timeleft != 85564 ) then
                                        draw.SimpleText( "DONE!", "ESPFont", drawpos.x, drawpos.y, green, 1, 1 )
                                end
                        end
                end
        end
end	 
end  
	  
	  
		if Cokehack.Settings["auto"] and (input.IsMouseDown(MOUSE_LEFT)) then		

                    timer.Simple(00.00001, function() RunConsoleCommand("-attack") end)
    RunConsoleCommand("+attack")
					timer.Simple(00.00001, function() RunConsoleCommand("-attack") end)
	RunConsoleCommand("+attack")
                    timer.Simple(00.00001, function() RunConsoleCommand("-attack") end)
	RunConsoleCommand("+attack")
					timer.Simple(00.00001, function() RunConsoleCommand("-attack") end)
	end
	
	
			if Cokehack.Settings["crash1"] and input.IsKeyDown(KEY_F) then		

                    timer.Simple(0.00001, function() RunConsoleCommand("-attack") end)
    RunConsoleCommand("+attack")
					timer.Simple(0.00001, function() RunConsoleCommand("-attack") end)
	RunConsoleCommand("+attack")
                    timer.Simple(0.00001, function() RunConsoleCommand("-attack") end)
	RunConsoleCommand("+attack")
					timer.Simple(0.00001, function() RunConsoleCommand("-attack") end)
	RunConsoleCommand("-attack")
	end

        if Cokehack.Settings["animation"]  then
		
	    local function doZombie ()

        if Enabled13:GetBool() then

                RunConsoleCommand("_DarkRP_DoAnimation", "1632")

        end

end

 

timer.Create("anim13", 1, 0, doZombie)
end


         if Cokehack.Settings["propspam"] then
				RunConsoleCommand("gm_spawn", "models/props_c17/chair02a.mdl")
				
				
			
			
        end
		

		 if Cokehack.Settings["reset"] then
				local function Reset()
	nolag = false
	RunConsoleCommand("r_3dsky", 1)
	RunConsoleCommand("r_WaterDrawReflection", 1)
	RunConsoleCommand("r_waterforcereflectentities", 1)
	RunConsoleCommand("r_teeth", 1)
	RunConsoleCommand("r_shadows", 1)
	RunConsoleCommand("r_ropetranslucent", 1)
	RunConsoleCommand("r_maxmodeldecal", 50) --50
	RunConsoleCommand("r_maxdlights", 32)--32
	RunConsoleCommand("r_decals", 2048)--2048
	RunConsoleCommand("r_drawmodeldecals", 1)
	RunConsoleCommand("r_drawdetailprops", 1)
	RunConsoleCommand("r_decal_cullsize", 1000)
	RunConsoleCommand("r_worldlights", 1)
	RunConsoleCommand("r_flashlightrender", 1)
	RunConsoleCommand("cl_forcepreload", 0)
	RunConsoleCommand("cl_ejectbrass", 1)
	RunConsoleCommand("cl_show_splashes", 1)
	RunConsoleCommand("cl_detaildist", 1200)
	--RunConsoleCommand("mat_fastnobump", 0)
	RunConsoleCommand("mat_filterlightmaps", 1)
	RunConsoleCommand("r_threaded_renderables", 0)
	RunConsoleCommand("r_threaded_client_shadow_manager", 0)
	--RunConsoleCommand("mat_filtertextures", 1)
	RunConsoleCommand("r_drawflecks", 1)
	RunConsoleCommand("r_WaterDrawRefraction", 0)
	--RunConsoleCommand("mat_showlowresimage", 0)
	RunConsoleCommand("r_dynamic", 1)
	for k,v in pairs(removes) do
		for a,b in pairs(ents.FindByClass(v)) do
			b:SetNoDraw(false)
		end
	end
	concommand.Add("coke_resetlag", Reset)
end

			
			
        end
		
		if Cokehack.Settings["spamadminchat"] then
				RunConsoleCommand("say", "@ Admin I need help")

			
			
        end
		
		if Cokehack.Settings["nolag"] then
	    local nolag = false
        local function StopLag()
	nolag = true
	RunConsoleCommand("r_3dsky", 0)
	RunConsoleCommand("r_WaterDrawReflection", 0)
	RunConsoleCommand("r_waterforcereflectentities", 0)
	RunConsoleCommand("r_teeth", 0)
	RunConsoleCommand("r_shadows", 0)
	RunConsoleCommand("r_ropetranslucent", 0)
	RunConsoleCommand("r_maxmodeldecal", 0) --50
	RunConsoleCommand("r_maxdlights", 0)--32
	RunConsoleCommand("r_decals", 0)--2048
	RunConsoleCommand("r_drawmodeldecals", 0)
	RunConsoleCommand("r_drawdetailprops", 0)
	RunConsoleCommand("r_worldlights", 0)
	RunConsoleCommand("r_flashlightrender", 0)
	RunConsoleCommand("cl_forcepreload", 1)
	RunConsoleCommand("r_threaded_renderables", 1)
	RunConsoleCommand("r_threaded_client_shadow_manager", 1)
	RunConsoleCommand("snd_mix_async", 1)
	RunConsoleCommand("cl_ejectbrass", 0)
	RunConsoleCommand("cl_detaildist", 0)
	RunConsoleCommand("cl_show_splashes", 0)
	--RunConsoleCommand("mat_fastnobump", 1)
	RunConsoleCommand("mat_filterlightmaps", 0)
	--RunConsoleCommand("mat_filtertextures", 0)
	RunConsoleCommand("r_drawflecks", 0)
	RunConsoleCommand("r_dynamic", 0)
	RunConsoleCommand("r_WaterDrawRefraction", 0)
	--RunConsoleCommand("mat_showlowresimage", 1)

	for k,v in pairs(removes) do
		for a,b in pairs(ents.FindByClass(v)) do
			b:SetNoDraw(true)
		end
	end
concommand.Add("ae_stoplag", StopLag)
end


			
			
        end
		
		
		
		
		 if Cokehack.Settings["spam"] then
				RunConsoleCommand("say", "too much info")
			
			
        end
       
        if Cokehack.Settings["bunnyhop"] and input.IsKeyDown(KEY_SPACE) then
                if(LocalPlayer():OnGround())then
                        LocalPlayer():ConCommand("+jump")
                        timer.Simple(0.01, function()
                                LocalPlayer():ConCommand("-jump")
                        end)
                end
        end
end)

hook.Add("FinishChat", "bhpenabler", function()
	if bhopoff then
		RunConsoleCommand("ae_bunnyhop", 1)
		bhopoff = false
	end
end)
 
 
 
hook.Add("HUDPaint", "CokeHUD", function()
        if Cokehack.Settings["esp"] then
                for k,v in pairs(ents.GetAll()) do
                        if Cokehack.Settings["esp_ply"] && v:IsPlayer() then
                                if(Cokehack.ESP("player", v) and v:GetPos():Distance(LocalPlayer():GetPos()) < (Cokehack.Settings["esp_player_dist"]))then
                                        local ESP = (v:EyePos()):ToScreen()
                                        local name,health,rank,col,distance = "","","","",""
                                        local outcol = Color(0,0,0,255)
                                        local white = Color(255,255,255,255)
                                        local outcol2 = outcol
                                        if Cokehack.Settings["esp_ply_name"] then
                                                if v.GetRPName then name = v:GetRPName()
                                                else name = v:Nick() end
                                        end
                                        if v:Nick() ~= name then rank = " "..v:Nick() end
                                        if Cokehack.Settings["esp_ply_rank"] then
                                                if v:IsSuperAdmin() then
                                                        rank = "[Super Admin]"..rank
                                                elseif v:IsAdmin() then
                                                        rank = "[Admin]"..rank
                                                elseif v:IsUserGroup("moderator") or v:IsUserGroup("mod") then
                                                        rank = "[Moderator]"..rank
                                                elseif v:IsUserGroup("vip") or v:IsUserGroup("donator") then
                                                        rank = "[Donator]"..rank
                                                end
                                        end
                                        if Cokehack.Settings["esp_ply_health"] then
                                                health = v:Health().."H - "..v:Armor().."A"
                                        end
                                        if Cokehack.Settings["esp_ply_dist"] then
                                                distance = v:GetPos():Distance(LocalPlayer():GetPos())
                                                distance = math.Round(distance).." m"
                                        end
                                        col = team.GetColor(v:Team())
                                        if(col.r <= 50 and col.g <= 50 and col.b <= 50) then
                                                outcol2 = Color(200,200,200,255)
                                        end
                                        if col.a <= 50 then
                                                col = Color(col.r,col.g,col.b, 255)
                                        end
                                        draw.SimpleTextOutlined(rank, "Trebuchetcat", ESP.x, ESP.y -46, col, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER, 1, outcol2)
                                        draw.SimpleTextOutlined(name, "Trebuchet19cat", ESP.x, ESP.y - 34, col, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER, 1, outcol2)
                                        draw.SimpleTextOutlined(health, "Trebuchetcat", ESP.x, ESP.y -22, white, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER, 1, outcol)
                                        draw.SimpleTextOutlined(distance, "Trebuchetcat", ESP.x, ESP.y - 10, white, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER, 1, outcol)
                                end
                        end
                        if (Cokehack.Settings["esp_ent"] and Cokehack.ESP("entity", v) and (v:GetPos():Distance(LocalPlayer():GetPos()) < Cokehack.Settings["esp_ent_dist"]))then
                                for k,e in pairs(Cokehack.Entities) do
                                        if e == v:GetClass() then
                                                local ESP = (v:EyePos()):ToScreen()
                                                draw.SimpleTextOutlined(v:GetClass(), "Trebuchet19cat", ESP.x, ESP.y - 46, Color(255,0,0,255), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER, 1, Color(0,0,0,255))
                                        end
                                end
                        end
                end
        end
end)
 
 
 
concommand.Add("defcon", function()
        local z = {"player"}
        local t = {}
        for k,v in pairs(ents.GetAll()) do
                if not table.HasValue(t, v:GetClass()) then
                        table.insert(t, v:GetClass())
                end
        end
        for e,x in pairs(t) do
                if !table.HasValue(z, x) then
                        print(x)
                end
        end
end)
 
concommand.Add("Cokehack", function()
        local darkrpvar = true
        print("Player Cash Amounts")
        for k,v in pairs(player.GetAll()) do
                if not(v.DarkRPVars and v.DarkRPVars.money)and(darkrpvar == true) then
                        darkrpvar = false
                end
                if v ~= LocalPlayer() then
                        print("    "..v:Nick().." : "..tostring(v.DarkRPVars.money))
                end
        end
        if darkrpvar == false then
                print("    Unable to get player cash amounts.")
        end
end)
 
concommand.Add("Cokeapult", function()
        PrintTable(player.GetAll()[3]:GetTable())
end)
/**************************************
Name: SHIT SNOW HAS ADDED
Purpose: HACKS AND SHIT
**************************************/



/**************************************
Name: Rotater DONT ADD TO MENU
Purpose: Does 180 and shit
**************************************/

local function Rotate180()
	ae_NOAUTOPICKUP = true
	timer.Simple(0.5, function() ae_NOAUTOPICKUP = false end)

	if hook.GetTable().CreateMove and hook.GetTable().CreateMove.PickupEnt then
		hook.Remove("CreateMove", "PickupEnt")
		hook.Remove("CalcView", "Ididntseeit")
		timer.Simple(0.05, function()
			local a = LocalPlayer():EyeAngles() LocalPlayer():SetEyeAngles(Angle(a.p, a.y-180, a.r))
		end)
		return
	end
	local a = LocalPlayer():EyeAngles() LocalPlayer():SetEyeAngles(Angle(a.p, a.y-180, a.r))
end
concommand.Add("ae_180", Rotate180)



/**************************************
Name: De Lagger
Purpose: Removes useless shit that garrys added to raise FPS
**************************************/

local removes = {"env_steam",
"func_illusionary",
"beam",
"class C_BaseEntity",
"env_sprite",
"class C_ShadowControl",
"class C_ClientRagdoll",
"func_illusionary",
"class C_PhysPropClientside",
}

local nolag = false

local function StopLag()
	nolag = true
	RunConsoleCommand("r_3dsky", 0)
	RunConsoleCommand("r_WaterDrawReflection", 0)
	RunConsoleCommand("r_waterforcereflectentities", 0)
	RunConsoleCommand("r_teeth", 0)
	RunConsoleCommand("r_shadows", 0)
	RunConsoleCommand("r_ropetranslucent", 0)
	RunConsoleCommand("r_maxmodeldecal", 0) --50
	RunConsoleCommand("r_maxdlights", 0)--32
	RunConsoleCommand("r_decals", 0)--2048
	RunConsoleCommand("r_drawmodeldecals", 0)
	RunConsoleCommand("r_drawdetailprops", 0)
	RunConsoleCommand("r_worldlights", 0)
	RunConsoleCommand("r_flashlightrender", 0)
	RunConsoleCommand("cl_forcepreload", 1)
	RunConsoleCommand("r_threaded_renderables", 1)
	RunConsoleCommand("r_threaded_client_shadow_manager", 1)
	RunConsoleCommand("snd_mix_async", 1)
	RunConsoleCommand("cl_ejectbrass", 0)
	RunConsoleCommand("cl_detaildist", 0)
	RunConsoleCommand("cl_show_splashes", 0)
	--RunConsoleCommand("mat_fastnobump", 1)
	RunConsoleCommand("mat_filterlightmaps", 0)
	--RunConsoleCommand("mat_filtertextures", 0)
	RunConsoleCommand("r_drawflecks", 0)
	RunConsoleCommand("r_dynamic", 0)
	RunConsoleCommand("r_WaterDrawRefraction", 0)
	--RunConsoleCommand("mat_showlowresimage", 1)

	for k,v in pairs(removes) do
		for a,b in pairs(ents.FindByClass(v)) do
			b:SetNoDraw(true)
		end
	end

end
concommand.Add("ae_stoplag", StopLag)

local function Reset()
	nolag = false
	RunConsoleCommand("r_3dsky", 1)
	RunConsoleCommand("r_WaterDrawReflection", 1)
	RunConsoleCommand("r_waterforcereflectentities", 1)
	RunConsoleCommand("r_teeth", 1)
	RunConsoleCommand("r_shadows", 1)
	RunConsoleCommand("r_ropetranslucent", 1)
	RunConsoleCommand("r_maxmodeldecal", 50) --50
	RunConsoleCommand("r_maxdlights", 32)--32
	RunConsoleCommand("r_decals", 2048)--2048
	RunConsoleCommand("r_drawmodeldecals", 1)
	RunConsoleCommand("r_drawdetailprops", 1)
	RunConsoleCommand("r_decal_cullsize", 1000)
	RunConsoleCommand("r_worldlights", 1)
	RunConsoleCommand("r_flashlightrender", 1)
	RunConsoleCommand("cl_forcepreload", 0)
	RunConsoleCommand("cl_ejectbrass", 1)
	RunConsoleCommand("cl_show_splashes", 1)
	RunConsoleCommand("cl_detaildist", 1200)
	--RunConsoleCommand("mat_fastnobump", 0)
	RunConsoleCommand("mat_filterlightmaps", 1)
	RunConsoleCommand("r_threaded_renderables", 0)
	RunConsoleCommand("r_threaded_client_shadow_manager", 0)
	--RunConsoleCommand("mat_filtertextures", 1)
	RunConsoleCommand("r_drawflecks", 1)
	RunConsoleCommand("r_WaterDrawRefraction", 0)
	--RunConsoleCommand("mat_showlowresimage", 0)
	RunConsoleCommand("r_dynamic", 1)
	for k,v in pairs(removes) do
		for a,b in pairs(ents.FindByClass(v)) do
			b:SetNoDraw(false)
		end
	end
end
concommand.Add("coke_resetlag", Reset)

/**************************************
Name: Hot key script
Purpose: Allows you to make Hotkeys and shit...
**************************************/

sql.Query("CREATE TABLE IF NOT EXISTS MultiKeyBinds('firstkey' INTEGER NOT NULL, 'secondkey' TEXT NOT NULL, 'commandname' TEXT NOT NULL, PRIMARY KEY('firstkey', 'secondkey'));")

local FirstButtons = {ctrl = KEY_LCONTROL, alt = KEY_LALT, shift = KEY_LSHIFT, space = KEY_SPACE}
local Binds = {}

local SQLBinds = sql.Query("SELECT * FROM MultiKeyBinds;")
if SQLBinds then
	for k,v in pairs(SQLBinds) do
		Binds[k] = {}
		Binds[k].firstkey = tonumber(v.firstkey)
		Binds[k].secondkey = string.lower(v.secondkey)
		Binds[k].commandname = v.commandname
	end
end

local AddGUI

local function Add(ply, cmd, args)
	if not args[1] then AddGUI() return end
	if not args[3] then print("Not enough arguments") return "Not enough arguments" end
	if not FirstButtons[string.lower(args[1])] then print("First key has to be shift, ctrl, alt or space") return "First key has to be shift, ctrl, alt or space" end

	local bind = {firstkey = FirstButtons[string.lower(args[1])], secondkey = string.lower(args[2]), commandname = args[3]}
	for k,v in pairs(Binds) do
		if v.firstkey == bind.firstkey and v.secondkey == bind.secondkey then
			Binds[k].commandname = bind.commandname

			sql.Query("UPDATE MultiKeyBinds SET commandname = "..sql.SQLStr(bind.commandname).." WHERE firstkey = "..bind.firstkey .." AND secondkey = "..sql.SQLStr(bind.secondkey)..";")
			print("Keybind updated!")
			return "Keybind updated!"
		end
	end
	table.insert(Binds, bind)

	sql.Query("INSERT INTO MultiKeyBinds VALUES(".. bind.firstkey ..", "..sql.SQLStr(bind.secondkey)..", "..sql.SQLStr(bind.commandname)..");")
	print("Keybind made!")
	return "Keybind made!"
end
concommand.Add("ae_hotkey", Add, function() return "ae_hotkey <Ctrl/alt/shift/space> \"<bind other key>\" \"<command>\"" end)

AddGUI = function()
	local firstkey, secondkey, commandname

	local function _3()
		Derma_StringRequest("Command name",
		[[ What will be the command that will be executed when you press the hotkey?
		NOTE: Some commands are blocked! Examples of blocked commands: quit, ent_*,
		lua_run_cl etc.]], "",
		function(text) commandname = text

			local text = Add(LocalPlayer(), "fuck you", {firstkey, secondkey, commandname})
			chat.AddText(Color(0, 255, 0, 255), text)
		end)
	end

	local function _2()
		hook.Add("HUDPaint", "TEMPHotKey", function()
			draw.DrawText([[Press the second key for the hotkey
			Note: The key must already be bound to something!
			If it's not it won't work!

			Well who would use a hotkey with an unbound key anyway]], "HUDNumber5", ScrW()/2, ScrH()/2, Color(0,0,255,255), TEXT_ALIGN_CENTER)
		end)

		hook.Add("PlayerBindPress", "TEMPHotKey", function(ply, bind, pressed)
			hook.Remove("HUDPaint", "TEMPHotKey")
			hook.Remove("PlayerBindPress", "TEMPHotKey")
			secondkey = string.lower(bind)
			_3()
			return true
		end)
	end

	Derma_Query([[What will be the first key for the hotkey?]], "First key",
		"ctrl", function() firstkey = "ctrl" _2() end,
		"alt", function() firstkey = "alt" _2() end,
		"shift", function() firstkey = "shift" _2() end,
		"space", function() firstkey = "space" _2() end)

end

local RemoveGUI
local function Remove(ply, cmd, args)
	if not args[1] then RemoveGUI() return end
	if not args[2] then print("Not enough arguments") return "Not enough arguments" end
	if not FirstButtons[string.lower(args[1])] then print("First key has to be shift, ctrl, alt or space") return "First key has to be shift, ctrl, alt or space" end

	for k,v in pairs(Binds) do
		if v.firstkey == FirstButtons[string.lower(args[1])] and v.secondkey == string.lower(args[2]) then
			sql.Query("DELETE FROM MultiKeyBinds WHERE firstkey = "..v.firstkey.." AND secondkey = "..sql.SQLStr(v.secondkey)..";")
			table.remove(Binds, k)
			print("Keybind removed!")
			return "Keybind Removed!"
		end
	end
	print("Keybind not found!")
	return "Keybind not found!"
end
concommand.Add("ae_Unhotkey", Remove, function() return "ae_Unhotkey <ctrl/alt/shift/space> \"bind other key\"" end)

RemoveGUI = function()
	local frame = vgui.Create("DFrame")
	frame:SetTitle( "Remove hotkeys" )
	frame:SetSize( 480, 200 )
	frame:Center()
	frame:SetVisible( true )
	frame:MakePopup( )

	local HotKeyList = vgui.Create("DListView", frame)
	HotKeyList:SetSize(470, 170)
	HotKeyList:SetPos(5, 25)
	HotKeyList:AddColumn("First key")
	HotKeyList:AddColumn("Second key")
	HotKeyList:AddColumn("command")
	HotKeyList:SetMultiSelect(false)

	local NumToKey = {[KEY_LCONTROL] = "ctrl", [KEY_LALT] = "alt", [KEY_LSHIFT] = "shift", [KEY_SPACE] = "space"}

	for k,v in pairs(Binds) do
		HotKeyList:AddLine(NumToKey[v.firstkey], v.secondkey, v.commandname)
	end

	function HotKeyList:OnClickLine(line)
		line:SetSelected(true)
		local text = Remove(LocalPlayer(), "get out", {line:GetValue(1), line:GetValue(2)})
		chat.AddText(Color(0, 255, 0, 255), text)

		HotKeyList:RemoveLine(HotKeyList:GetSelectedLine())
	end
end

concommand.Add("ae_hotkeyList", function() PrintTable(Binds) end)

hook.Add("PlayerBindPress", "ae_hotkey", function(ply, bind, pressed)

	for k,v in pairs(Binds) do
		if input.IsKeyDown(v.firstkey) and string.lower(bind) == string.lower(v.secondkey) and pressed then
			RunConsoleCommand(unpack(string.Explode(" ", v.commandname)))-- Using RunConsoleCommand instead of LocalPlayer():ConCommand to prevent unnecessary blocking
			return true
		end
	end
end)


/**************************************
Name: Error Replacer
Purpose: Replaces Errors With stacks of bricks
**************************************/

CreateClientConVar("ae_replaceErrors", 1, true, false)
/*hook.Add("Think", "ReplaceErrors", function()
	if not tobool(GetConVarNumber("ae_replaceErrors")) then return end
	for k,ent in pairs(ents.GetAll()) do -- FindByModel doesn't work
		if IsValid(ent) and string.lower(ent:GetModel() or "") == "models/error.mdl" and ent:GetClass() ~= "trace1" and ent:GetClass() ~= "ent_checkpoint" and ent:GetClass() ~= "ent_start" and ent:GetClass() ~= "ent_finish" and not ent:IsWeapon() then
			if ent.ErrorModel then
				ent:SetNoDraw(true)
			else

				local mins, maxs = ent:OBBMins(), ent:OBBMaxs()
				local difference = maxs - mins
				ent.ErrorModel = ClientsideModel("models/props_debris/concrete_cynderblock001.mdl", RENDER_GROUP_OPAQUE_ENTITY)
				if not ent.ErrorModel then return end
				ent.ErrorModel:SetMaterial("effects/security_noise2")
				ent.ErrorModel:SetPos(ent:GetPos())
				ent.ErrorModel:SetAngles(ent:GetAngles())
				ent.ErrorModel:SetParent(ent)
				ent.ErrorModel:SetColor(ent:GetColor())

				ent.ErrorModel:SetModelScale(Vector(difference.x/16,difference.y/8,difference.z/8))
				ent.ErrorModel:Spawn()
				ent.ErrorModel:Activate()

				ent:CallOnRemove("RemoveErrorModel", function(ent) SafeRemoveEntity(ent.ErrorModel) end)
			end
		end
	end
end)*/


/**************************************
Name: Snow Logger
Purpose: Logs functions and shit
**************************************/
concommand.Add("ae_StartLog",function()
file.Write("ae/log.txt","Log created: ("..os.date()..") \n")
end)
 
function Log(msg)
file.Append("ae/log.txt","["..os.date().."]: "..msg.."\n")
end
Log("Loading....")


/**************************************
Name: ATM hack
Purpose: Gets ATM details
**************************************/



concommand.Add( "atm_getmoney", function(ply, cmd, args)

	local name = args[1]
	local money = args[2]

	if not money or not name then
		chat.AddText( nil, cmd.." name money" )
		return
	end

	local vict
	for k,v in pairs(player.GetAll()) do
		if string.find( v:Nick(), name ) then
			vict = v
			break
		end
	end

	if not IsValid(vict) then
		chat.AddText( nil, "No player found with "..name.." in their name." )
                return
	end

	chat.AddText( nil, "Attempting to take $"..money.." from "..vict:Nick().."." )
	RunConsoleCommand( "rp_atm_withdraw", "", vict:UniqueID(), money )

end )

concommand.Add("atm_takemoney", function(players, command, args)
	for k, v in pairs(player.GetAll()) do
		RunConsoleCommand("atm_getmoney", ""..v:GetName().."", args[1])
	end
end)




	
	
	/********************************************************
Name: Hide the cheat from client
Purpose: Don't show the where the cheat loads from, etc
*********************************************************/
function error(...) snow.Notify(red,"Error in the Lua script!") end
function Error(...) snow.Notify(red,"Error in the Lua script!") end
function ErrorNoHalt(...) snow.Notify(red,"Error in the Lua script!") end





-- Client side noclip
local SW = {}
 
SW.Enabled = false
SW.ViewOrigin = Vector( 0, 0, 0 )
SW.ViewAngle = Angle( 0, 0, 0 )
SW.Velocity = Vector( 0, 0, 0 )
 
function SW.CalcView( ply, origin, angles, fov )
        if ( !SW.Enabled ) then return end
        if ( SW.SetView ) then
                SW.ViewOrigin = origin
                SW.ViewAngle = angles
               
                SW.SetView = false
        end
        return { origin = SW.ViewOrigin, angles = SW.ViewAngle }
end
hook.Add( "CalcView", "SpiritWalk", SW.CalcView )
 
function SW.CreateMove( cmd )
        if ( !SW.Enabled ) then return end
       
        // Add and reduce the old velocity.
        local time = FrameTime()
        SW.ViewOrigin = SW.ViewOrigin + ( SW.Velocity * time )
        SW.Velocity = SW.Velocity * 0.95
       
        // Rotate the view when the mouse is moved.
        local sensitivity = 0.022
        SW.ViewAngle.p = math.Clamp( SW.ViewAngle.p + ( cmd:GetMouseY() * sensitivity ), -89, 89 )
        SW.ViewAngle.y = SW.ViewAngle.y + ( cmd:GetMouseX() * -1 * sensitivity )
       
        // What direction we're going to move in.
        local add = Vector( 0, 0, 0 )
        local ang = SW.ViewAngle
        if ( cmd:KeyDown( IN_FORWARD ) ) then add = add + ang:Forward() end
        if ( cmd:KeyDown( IN_BACK ) ) then add = add - ang:Forward() end
        if ( cmd:KeyDown( IN_MOVERIGHT ) ) then add = add + ang:Right() end
        if ( cmd:KeyDown( IN_MOVELEFT ) ) then add = add - ang:Right() end
        if ( cmd:KeyDown( IN_JUMP ) ) then add = add + ang:Up() end
        if ( cmd:KeyDown( IN_DUCK ) ) then add = add - ang:Up() end
       
        // Speed.
        add = add:GetNormal() * time * 500
        if ( cmd:KeyDown( IN_SPEED ) ) then add = add * 2 end
       
        SW.Velocity = SW.Velocity + add
       
        // This stops us looking around crazily while spiritwalking.
        if ( SW.LockView == true ) then
                SW.LockView = cmd:GetViewAngles()
        end
        if ( SW.LockView ) then
                cmd:SetViewAngles( SW.LockView )
        end
       
        // This stops us moving while spiritwalking.
        cmd:SetForwardMove( 0 )
        cmd:SetSideMove( 0 )
        cmd:SetUpMove( 0 )
end
hook.Add( "CreateMove", "SpiritWalk", SW.CreateMove )
 
function SW.Toggle()
        SW.Enabled = !SW.Enabled
        SW.LockView = SW.Enabled
        SW.SetView = true
       
        local status = { [ true ] = "ON", [ false ] = "OFF" }
        print( "AE-FLY " .. status[ SW.Enabled ] )
end
concommand.Add( "ae_fly", SW.Toggle )
 
concommand.Add( "Dev_pos", function() print( SW.ViewOrigin ) end )




-- Crosshair

 CreateClientConVar("ae_advcrosshair", 1, true, false)
CreateClientConVar("ae_advcrosshair_hitmarker", 1, true, false)
CreateClientConVar("ae_advcrosshair_info", 1, true, false)


function advcrosshair()
	if GetConVarNumber("ae_advcrosshair") == 1 then
		local x = ScrW()*.5
		local y = ScrH()*.5
			target = LocalPlayer():GetEyeTrace().Entity
		if LocalPlayer():Alive() and LocalPlayer():GetActiveWeapon():IsValid() and (target:IsPlayer() or target:IsNPC()) then
			crosscolor = Color(220,60,90, 150)
			surface.SetDrawColor(crosscolor)
			if GetConVarNumber("ae_advcrosshair_info") == 1 then
				draw.DrawText("Heath: "..target:Health(), "Trebuchet18", x, y +25, Color(255,255,255, 150), 1)

			end
			if GetConVarNumber("ae_advcrosshair_hitmarker") == 1 then
				if LocalPlayer():KeyDown(IN_ATTACK) and LocalPlayer():GetActiveWeapon():Clip1() > 0 then
					surface.SetDrawColor(255,255,255)
					surface.DrawLine(x+15, y+15, x+8, y+8)
					surface.DrawLine(x-15, y-15, x-8, y-8)
					surface.DrawLine(x-15, y+15, x-8, y+8)
					surface.DrawLine(x+15, y-15, x+8, y-8)
				end
			end

		else
			crosscolor = Color(255,255,255, 150)
		end

		/*for _, v in pairs(player.GetAll()) do
			vtarget = v:GetEyeTrace().Entity
			if vtarget:IsPlayer() then
				if LocalPlayer():Alive() and v:GetActiveWeapon():Clip1() > 0 then
					if vtarget:Name() == LocalPlayer():Name() then
						draw.DrawText(vtarget:Name().." is aiming a weapon at you", "Trebuchet18", x, y +35, Color(255,255,255, 150), 1)
					end
				end
			end
		end*/



		surface.SetDrawColor(crosscolor)
		local gap = 15
		local length = gap + 10
		surface.DrawLine( x - length, y, x - gap, y )
		surface.DrawLine( x + length, y, x + gap, y )
		surface.DrawLine( x, y - length, x, y - gap )
		surface.DrawLine( x, y + length, x, y + gap )
		surface.SetDrawColor(0, 255, 0)
		surface.DrawLine( x +2 , y, x -2, y)
		surface.DrawLine( x , y +2, x , y-2)
	end
end
hook.Add("HUDPaint", "advcrosshair", advcrosshair)




-- Witness box
    local Cap = math.cos(math.rad(45))
    local Offset = Vector(0, 0, 32)
    local Trace = {}

    function Draw()
    	local Time = os.time() - 1
    	local Witnesses = 0
    	local BeingWitnessed = true
    	local Texture = surface.GetTextureID("gui/silkicons/emoticon_smile")

    	if Time < os.time() then
    		Time = os.time() + .5
    		Witnesses = 0
    		BeingWitnessed = false
    		for k, pla in pairs(player.GetAll()) do
    			if pla:IsValid() and pla != LocalPlayer() then
    				Trace.start  = LocalPlayer():EyePos() + Offset
    				Trace.endpos = pla:EyePos() + Offset
    				Trace.filter = {pla, LocalPlayer()}

    				TraceRes = util.TraceLine(Trace)

    				if !TraceRes.Hit then
    					if (pla:EyeAngles():Forward():Dot((LocalPlayer():EyePos() - pla:EyePos())) > Cap) then
    						Witnesses = Witnesses + 1
    						BeingWitnessed = true

    					end
    				end
    			end
    		end
    	end

    	surface.SetFont("BudgetLabel")
    	if BeingWitnessed then
    		surface.SetTextColor(255, 000, 000, 255)
    		Texture = surface.GetTextureID("gui/silkicons/cross")
    	else
    		surface.SetTextColor(000, 255, 000, 255)
    		Texture = surface.GetTextureID("gui/silkicons/emoticon_smile")
    	end
    	local Text = "Witnesses: "..tostring(Witnesses)
    	local Width, Height = surface.GetTextSize(Text)

    	surface.SetDrawColor(80, 80, 80, 180)
    	surface.DrawRect(ScrW()/2 - (Width/2 + 24), 4, Width + 28, Height + 8)
    	surface.SetDrawColor(0, 0, 0, 255)
        surface.DrawOutlinedRect(ScrW()/2 - (Width/2 + 24), 4, Width + 28, Height + 8)

    	surface.SetTexture(Texture)
    	surface.SetDrawColor(255, 255, 255, 255)
    	surface.DrawTexturedRect(ScrW()/2 - (Width/2 + 20), 8, 16, 16)
    	surface.SetTextPos(ScrW()/2 - Width/2, 8)
    	surface.DrawText(Text)
    end
    hook.Add("HUDPaint", "WitnessesBox", Draw)
	
	
/*---------------------------------------------------------------------------
Very hacky script that logs the things you spawn and allows you to undo any entity in the undo list.
---------------------------------------------------------------------------*/

local FakeUM = {}
local function MakeFakeUM()
	FakeUM = {}
	function FakeUM:ReadLong()
		return self.ID
	end
	function FakeUM:ReadString()
		return self.Ent
	end
end

local undoTable
local LastCreated = {} -- Sometimes OnEntityCreated gets called before AddUndo arrives. In that case catch the prop.

hook.Add("InitPostEntity", "LogUndoTable", function()
	local usermessageHooks = debug.getupvalues(usermessage.Hook).Hooks
	local AddUndo = usermessageHooks.AddUndo.Function
	local Undone = usermessageHooks.Undone.Function

	usermessage.Hook("AddUndo", function(um)
		local ID, Ent = um:ReadLong(), um:ReadString()
		local Match = string.match(Ent, "Prop .(.*).")
		if Match then
			hook.Call("ae_SpawnedProp", nil, Match, ID, Ent)
		end
		for k,v in pairs(LastCreated) do
			if IsValid(v) and not v.IsMine and string.lower(v:GetModel() or "") == string.lower(Match or "") then
				v.IsMine = true
				table.remove(LastCreated, k)
				hook.Call("ae_ActuallySpawnedProp", nil, v)

				local wep = LocalPlayer():GetActiveWeapon()
				if IsValid(wep) and wep:GetClass() == "weapon_physgun" and input.IsMouseDown(MOUSE_FIRST) and LocalPlayer():GetEyeTrace().Entity == v then
					hook.Call("PhysgunPickup", nil, LocalPlayer(), v)
				end
				break
			end
		end

		MakeFakeUM()

		FakeUM.ID = ID
		FakeUM.Ent = Ent
		AddUndo(FakeUM) -- original AddUndo so that doesn't break
		undoTable = undo.GetTable()
		undoTable[1].IsTaken = false
	end)

	usermessage.Hook("Undone", function(um)
		local ID = um:ReadLong()

		for k,v in pairs(undoTable or {}) do
			local Match = string.match(v.Name, "Prop .(.*).")
			if v.Key == ID and Match then
				hook.Call("Falco_RemovedProp", nil, Match)
			end
		end

		MakeFakeUM()
		FakeUM.ID = ID
		Undone(FakeUM)
	end)
end)

hook.Add("OnEntityCreated", "IActuallySpawnedProp", function(prop)
	if not IsValid(prop) or prop:GetClass() ~= "prop_physics" then return end

	for k, v in pairs(undo.GetTable()) do
		local Match = string.lower(string.match(v.Name, "Prop .(.*).") or "")
		if v.IsTaken == false and not prop.IsMine and Match == string.lower(prop:GetModel() or "") then
			hook.Call("Falco_ActuallySpawnedProp", nil, prop)
			prop.IsMine = true
			undo.GetTable()[k].IsTaken = true

			local wep = LocalPlayer():GetActiveWeapon()
			if IsValid(wep) and wep:GetClass() == "weapon_physgun" and input.IsMouseDown(MOUSE_FIRST) and LocalPlayer():GetEyeTrace().Entity == prop then
				hook.Call("PhysgunPickup", nil, LocalPlayer(), prop)
			end
			return
		end
	end

	local Index = table.insert(LastCreated, prop)
	timer.Simple(0.2, function() LastCreated[Index] = nil end)
end)

hook.Add("PhysgunPickup", "FPickupProp", function(ply, prop)
	if not prop.IsMine then return end
	LocalPlayer().IsHolding = prop
end)

hook.Add("PhysgunDrop", "FDropProp", function(ply, prop)
	ply.IsHolding = nil
end)

concommand.Add("ae_undonum", function(ply,cmd,args)
	local num = tonumber(args[1])
	local Undo = undo.GetTable()
	if not num or not Undo[num] then return end

	RunConsoleCommand("gmod_undonum", Undo[num].Key)
end)


local LastSpawned = ""
local BlockedModels = {}
local Falco_Alternatives = {}
Falco_Alternatives["models/props_c17/lockers001a.mdl"] = "models/props/CS_militia/refrigerator01.mdl"
Falco_Alternatives["models/props_junk/gascan001a.mdl"] = "models/props_junk/metal_paintcan001a.mdl"
Falco_Alternatives["models/props_wasteland/laundry_dryer001.mdl"] = "models/props_rooftop/dome_copper.mdl"
Falco_Alternatives["models/props_rooftop/dome_copper.mdl"] = "models/props/CS_militia/crate_stackmill.mdl"
Falco_Alternatives["models/props_combine/combine_fence01a.mdl"] = "models/props_c17/utilitypole01b.mdl"
Falco_Alternatives["models/props_combine/breen_tube.mdl"] = "models/props/de_nuke/CoolingTower.mdl"
Falco_Alternatives["models/props/de_tides/gate_large.mdl"] = "models/props/de_train/Lockers_Long.mdl"
Falco_Alternatives["models/props/cs_militia/skylight_glass_p6.mdl"] = "models/props_debris/concrete_chunk02b.mdl"
Falco_Alternatives["models/props_rooftop/roof_vent002.mdl"] = "models/props/cs_assault/FireHydrant.mdl"
Falco_Alternatives["models/props_debris/walldestroyed03a.mdl"] = "models/props_junk/iBeam01a_cluster01.mdl"
Falco_Alternatives["models/props_wasteland/interior_fence002d.mdl"] = "models/props/de_inferno/lattice.mdl"
Falco_Alternatives["models/props_junk/sawblade001a.mdl"] = "models/props/CS_militia/skylight_glass_p6.mdl"
Falco_Alternatives["models/props/cs_militia/refrigerator01.mdl"] = "models/props_c17/furnitureStove001a.mdl"
Falco_Alternatives["models/props_vents/vent_large_grill001.mdl"] = "models/cheeze/pcb2/pcb6.mdl"
Falco_Alternatives["models/props/de_train/lockers_long.mdl"] = "models/props_lab/blastdoor001c.mdl"
Falco_Alternatives["models/props_canal/canal_bars004.mdl"] = "models/props/CS_militia/sheetrock_leaning.mdl"
Falco_Alternatives["models/xqm/coastertrack/slope_225_2.mdl"] = "models/xqm/coastertrack/slope_225_1.mdl"
Falco_Alternatives["models/xqm/coastertrack/slope_225_1.mdl"] = "models/hunter/misc/cone4x1.mdl"
Falco_Alternatives["models/xqm/coastertrack/slope_90_1.mdl"] = "models/hunter/misc/cone2x1.mdl"
Falco_Alternatives["models/hunter/tubes/tube1x1x6.mdl"] = "models/props_docks/dock03_pole01a.mdl"
Falco_Alternatives["models/props_phx/construct/metal_angle360.mdl"] = "models/props_junk/trashdumpster02b.mdl"

function FSpawnModel(Model, DontSpawn)
	local check = string.lower(Model)
	if not DontSpawn then
		LastSpawned = string.lower(Model)
	end
	while(table.HasValue(BlockedModels, check) and Falco_Alternatives[check]) do
		check = string.lower(Falco_Alternatives[check])
	end
	if not DontSpawn then RunConsoleCommand("gm_spawn", check) end
	return check, table.HasValue(BlockedModels, check)
end

hook.Add("PlayerBindPress", "SpawnModel", function(ply, bind, pressed, extraArg)
	local TheBind = string.Explode(' ', bind)
	if not TheBind[1] or string.lower(TheBind[1]) ~= "gm_spawn" or not pressed or extraArg then return end
	local DoSpawn = hook.Call("PlayerBindPress", nil, ply, bind, pressed, true)
	if not DoSpawn then FSpawnModel(TheBind[2]) end
	return true
end)

hook.Add("InitPostEntity", "HookIntoFPP", function()
	if not FPP then return end
	local notify = FPP.AddNotify
	function FPP.AddNotify(str, type)
		if LastSpawned ~= '' and (str == "The model of this entity is in the black list!" or str == "The model of this entity is not in the white list!" or
			str == "Your prop is ghosted because it is too big. Interract with it to unghost it.") then
			table.insert(BlockedModels, string.lower(LastSpawned))
			if Falco_Alternatives[string.lower(LastSpawned)] then
				FSpawnModel(Falco_Alternatives[string.lower(LastSpawned)])
			end
		end
		return notify(str, type)
	end
end)







/*---------------------------------------------------------------------------
Removes the spawn effect of props
---------------------------------------------------------------------------*/

if SERVER then
	AddCSLuaFile("cl_OverridePropEffect.lua")
	return
end

local Disable = CreateClientConVar( "cl_disable_spawn_effects", "1", true, false )
if not tobool(Disable:GetInt()) then return end
local function Override()
	effects.Register( { Init = function() end, Think = function() end, Render = function() end }, "propspawn" )

	DoPropSpawnedEffect = function( ent )
	end
end

timer.Create("OverrideProp", 30, 0, Override)

hook.Add( "InitPostEntity", "PostGamemodeLoaded.OverridePropEffect", Override )
timer.Simple(3, Override)


//require("cvar2")

function Falco_ForceVar(var, value)
	//cvar2.SetValue(var, value)
end
concommand.Add("falco_bypass", function(ply, cmd, args)
	//Falco_ForceVar(args[1], args[2])
end)
concommand.Add("falco_forcevar", function(ply, cmd, args)
	//Falco_ForceVar(args[1], args[2])
end)
	


				
				
        if Cokehack.Settings["kill"] then
	RunConsoleCommand("kill","")
end




         if Cokehack.Settings["mply"] then
		 playermenu = true
		 end

local SoundEnt
local SongLength
local RunningSong		= ""
local Seconds			= 0
local name 				= ""
function Playermenu()

	DermaPanel1 = vgui.Create( "DFrame" )
	DermaPanel1:SetPos( 50,25 )
	DermaPanel1:SetSize( 300, 525 )
	DermaPanel1:SetTitle( "AE player" )
	DermaPanel1:SetDeleteOnClose(true)
	DermaPanel1:SetVisible( true )
	DermaPanel1:SetDraggable( true )
	DermaPanel1:ShowCloseButton( true )
	DermaPanel1:MakePopup()

	local DermaListView = vgui.Create("DListView")  
	DermaListView:SetParent(DermaPanel1)  
	DermaListView:SetPos(12.5, 37.5)  
	DermaListView:SetSize(275, 362.5)  
	DermaListView:SetMultiSelect(false)
	DermaListView:AddColumn("Name") // Add column     

	local list = file.Find("sound/songs/*.mp3", "MOD")  
	for k,v in pairs(list) do
	DermaListView:AddLine(v)
	end


	function DermaListView:OnRowSelected( LineID, Line )  
	   name = Line:GetColumnText( 1 )
	end

	local DermaButton = vgui.Create( "DButton", DermaPanel1 )    
	DermaButton:SetText( "Play" )  
	DermaButton:SetPos( 12.5, 412.5 )  
	DermaButton:SetSize( 100, 25 )  
	DermaButton.DoClick = function()
	surface.PlaySound( "ui/buttonclick.wav" )
	SongLength = math.ceil(SoundDuration("songs/"..name))
	RunningSong = name
	play_song("songs/"..name)
	--RunConsoleCommand( "play", "songs/"..name )
	end

	local DermaButton = vgui.Create( "DButton", DermaPanel1 )    
	DermaButton:SetText( "Stop" )  
	DermaButton:SetPos( 187.5, 412.5 )  
	DermaButton:SetSize( 100, 25 )  
	DermaButton.DoClick = function()
		surface.PlaySound( "ui/buttonclick.wav" )
		stop_song()
		Seconds = 0
		SongLength = nil
	end

	local Panel = vgui.Create( "DPanel", DermaPanel1 )
	Panel:SetPos( 12.5, 450 )
	Panel:SetSize( 275, 65 )

	DSongTitle = vgui.Create( "DLabel", Panel )
	DSongTitle:SetPos( 7.5, 2.5 )
	DSongTitle:SetSize( 260, 20 )
	DSongTitle:SetColor(Color(0,20,0,255))
	DSongTitle:SetText( "Now Playing: N/A" )

	local DLabel = vgui.Create( "DLabel", Panel )
	DLabel:SetPos( 7.5, 22.5 )
	DLabel:SetSize( 150, 20 )
	DLabel:SetColor(Color(0,0,0,255)) 
	DLabel:SetText( "Volume" )

	local DTimer = vgui.Create( "DLabel", Panel )
	DTimer:SetPos( 125, 35 )
	DTimer:SetSize( 150, 20 )
	DTimer:SetColor(Color(0,0,0,255)) 
	DTimer:SetText("Song Time: 00:00 / 00:00")
			
	local DermaSlider = vgui.Create("Slider", DermaPanel1)
	DermaSlider:SetPos( 15, 480 ) 
	DermaSlider:SetWide( 100 )
	--DermaSlider:SetText( "Volume" )
	DermaSlider:SetMin(0.1)
	DermaSlider:SetMax(1.0)
	DermaSlider:SetValue(1.0)
	DermaSlider:SetDecimals( 2 )
	DermaSlider.OnValueChanged = function( panel, value )
		SoundEnt:ChangeVolume( value, 1 )
	end

	if !timer.Exists("musicplayertimer3") then
		timer.Destroy("musicplayertimer3")
	end

	timer.Create("musicplayertimer3", 1, 0, function()
		Seconds = Seconds + 1
		if DermaPanel1:IsVisible() == true then
			if SongLength == nil then
				DSongTitle:SetText( "Now Playing: N/A" )
				DTimer:SetText("Song Time: 00:00 / 00:00")
			else
				DSongTitle:SetText( "Now Playing: " .. RunningSong)
				DTimer:SetText("Song Time: " .. string.ToMinutesSeconds(Seconds) .. " / " .. string.ToMinutesSeconds(SongLength))
			end
		end
	end)

end

function Hidemenu()
	if DermaPanel1:IsVisible() == true then
		DermaPanel1:SetVisible(false)
	end
end

function play_song(song_name)
	if file.Find("sound/"..song_name, "MOD") then
		if SoundEnt == nil or SoundEnt:IsPlaying() == false then
			Seconds = 0
			SoundEnt = CreateSound(LocalPlayer(), Sound(song_name))
			SoundEnt:PlayEx(1.0,100)
			SongLength = math.ceil(SoundDuration(song_name))
		else
			SoundEnt:Stop()
			Seconds = 0
			SoundEnt = CreateSound(LocalPlayer(), Sound(song_name))
			SoundEnt:PlayEx(1.0,100)
		end
	end
end

function stop_song()
	if SoundEnt:IsPlaying() == true then
		SoundEnt:Stop()
	end
end

concommand.Add("mp3", Playermenu)
concommand.Add("+mp3", Playermenu)
concommand.Add("-mp3", Hidemenu)

local ae = { Menu = { t = {}; b = {}; c = 0;}; Alive = {}; Spectators = {};}
local snoweps = "weapon_physgun"
// Laser Sight \\
function ae.Barrel( )
if GetConVarNumber( "ae_removelaser" ) >= 1 then return end
local ViewModel = LocalPlayer():GetViewModel()
local Attach = ViewModel:LookupAttachment( '1' )
if( !LocalPlayer():Alive() || LocalPlayer():GetActiveWeapon() == NULL ) then return; end
if ( Attach == 0 ) then Attach = ViewModel:LookupAttachment( 'muzzle' ) end
if LocalPlayer():GetActiveWeapon():GetClass() == snoweps then
-- //if( !table.HasValue( LaserSightAllowed, LocalPlayer():GetActiveWeapon():GetClass() ) ) then return; end
cam.Start3D( EyePos(), EyeAngles() )
render.SetMaterial(Material("sprites/physbeam"))
render.DrawBeam( ViewModel:GetAttachment( Attach ).Pos, LocalPlayer():GetEyeTrace().HitPos, 5, 0, 0, Color(50, 255, 50, 255) )
local Size = math.random() * 1.35
render.SetMaterial(Material("sprites/redglow1"))
render.DrawQuadEasy(LocalPlayer():GetEyeTrace().HitPos, (EyePos() -  LocalPlayer():GetEyeTrace().HitPos):GetNormal(), 30, 30, Color(235,80,80,235) )
cam.End3D()
else

end
end
hook.Add( 'HUDPaint', '\2\3', ae.Barrel )
 
CreateClientConVar( "ae_removelaser", 0, true, false )



function sayThatName(victim, inflictor, killer) //Use the same arguments as the original function you're hooking to
	if killer:IsPlayer()then --Only prints the killer if he was a player.
		victim:PrintMessage(HUD_PRINTTALK, killer:Nick().." killed you!\n")
	end
end
hook.Add("PlayerDeath","informTheVictims",sayThatName)
 
 
 