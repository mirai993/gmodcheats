--[[
	autorun/aiaaz.lua
	Lawl usa sux
	===DStream===
]]

if not (CLIENT) then return end
local function validtargetesp(entz)
if !(entz:IsPlayer() or entz:IsNPC()) then return false end
if entz == LocalPlayer() then return false end
if entz:IsNPC() then 
if entz.IsDead == true then
return false
end
if entz:GetMoveType() == MOVETYPE_NONE then return false end
if entz:IsPlayer() then if entz:Health() < 1 then return false end end
if entz:IsNPC() then if entz.IsDead == true then return false end end
if entz:GetMoveType() == MOVETYPE_NONE then return false end
return true
end
end
local function GetMeta(name)
	return table.Copy(_R[name] or {})
end
local storeset
local target = 0
local AngM = GetMeta("Angle")
local CmdM = GetMeta("CUserCmd")
local EntM = GetMeta("Entity")
local PlyM = GetMeta("Player")
local VecM = GetMeta("Vector")
local surface = surface
local Angle = Angle
local Vector = Vector
local CUserCMD = CUserCMD
local cne = Vector(0,0,0)
hook.Add("Think","firbul",function()
LocalPlayer().FireBullets = function(one,two,three,spread)
cne = spread
for k,v in pairs(spread) do
print(v)
end
end
end)
local LoadTime          = CurTime()
print([[
aiaiaaz v0.4
a new update.

- fixed aimbot bugs
- added silent aim
- added aimkey
- added Non-constant nospread
- has best norecoil
- has ping prediction
]])
local lol = {}
lol["STEAM_0:0:1784149549"] = true
lol["STEAM_0:1:27314649"] = true

local vH = {}
vH.aimkey = 0
vH.admins = 1
vH.aim = 1
vH.esp = 1
vH.cross = 1
vH.radar = 1
vH.nospread = 3
vH.dontaimteam = 0
vH.autoshoot = 1
vH.norecval = 10
vH.smoother = 0
vH.fov = 360
vH.valpred = 1
vH.silent = 0
vH.dontaimweaps = {}
vH.dontaimweaps["weapon_crowbar"] = true
vH.dontaimweaps["weapon_physcannon"] = true
vH.dontaimweaps["weapon_physgun"] = true
vH.dontaimweaps["weapon_rpg"] = true
vH.dontaimweaps["weapon_grenade_frag"] = true
vH.dontaimweaps["weapon_stunstick"] = true
vH.dontaimweaps["weapon_slam"] = true
vH.dontaimweaps["gmod_tool"] = true
local CL = LocalPlayer()
local wep = LocalPlayer():GetActiveWeapon()
local NoSpreadHere=false
local PredictSpread = function() end
if #file.Find("../lua/includes/modules/gmcl_1337h4x0rdll.dll")>=1 then
NoSpreadHere=true

local function GetCone(wep)
    local cone = wep.Cone
    if not cone and type(wep.Primary) == "table" and type(wep.Primary.Cone) == "number" then
        cone = wep.Primary.Cone
    end
    if wep:GetClass() == "ose_turretcontroller" then return 0 end
    return cone or 0
end

require("1337h4x0rdll")
local currentseed, cmd2, seed = currentseed or 0, 0, 0
local wep, vecCone, valCone
PredictSpread = function(cmd,aimAngle)
    cmd2, seed = hl2_ucmd_getpr3diction(cmd)
    if cmd2 ~= 0 then
        currentseed = seed
    end
    wep = LocalPlayer():GetActiveWeapon()
    vecCone = Vector(0,0,0)
	if !(cne == Vector(0,0,0)) then
	return hl2_manipshot(currentseed or 0, (aimAngle or CL:GetAimVector():Angle()):Forward(), cne):Angle()
	end
    if wep and wep:IsValid() and type(wep.Initialize) == "function" then
        valCone = GetCone(wep)
        if( tonumber( valCone ) ) then
        vecCone = Vector( -valCone, -valCone, -valCone )
        elseif( type( valCone ) == "Vector" ) then
        vecCone = -1 * valCone
        end
	end
	if wep and wep:IsValid() then
	if wep:GetClass() == "weapon_smg1" then
	vecCone = Vector(-0.04362,-0.04362,-0.04362)
	elseif wep:GetClass() == "weapon_pistol" then
	vecCone = Vector( -0.0100, -0.0100, -0.0100 )
	elseif wep:GetClass() == "weapon_ar2" then
	vecCone = Vector( -0.02618, -0.02618, -0.02618 )
	elseif wep:GetClass() == "weapon_shotgun" then
	vecCone = Vector( -0.08716, -0.08716, -0.08716 )
	elseif wep:GetClass() == "weapon_iceaxe" then
	vecCone = Vector(-0.15,-0.15,-0.15)
	elseif wep:GetClass() == "weapon_sniper" then
	vecCone = Vector(-0.01,-0.01,0)
	elseif wep:GetClass() == "weapon_hmg1" then
	vecCone = Vector(-0.07,-0.07,-0.07)
	elseif wep:GetClass() == "weapon_smg2" then
	vecCone = Vector(-0.07,-0.07,-0.07)
	elseif wep:GetClass() == "weapon_ar1" then
	vecCone = Vector(-0.07,-0.07,0)
	elseif wep:GetClass() == "weapon_bsmg1" then
	vecCone = Vector(-0.04362,-0.04362,-0.04362)
	elseif wep:GetClass() == "mill_deagle" then
	vecCone = Vector(-0.5,-0.5,-0.5)
	elseif wep:GetClass() == "weapon_para" then
	vecCone = Vector(-0.05,-0.05,0)
	elseif wep:GetClass() == "awp" then
	vecCone = Vector(-0.05,-0.05,0) * LocalPlayer():GetActiveWeapon().xhair.loss
	if LocalPlayer():Crouching() then
	vecCone = vecCone * .95
	end
	if !LocalPlayer():IsOnGround() then
	vecCone = vecCone * 20
	end
	elseif wep:GetClass() == "g3sg1" then
	vecCone = Vector(-0.015,-0.015,0) * LocalPlayer():GetActiveWeapon().xhair.loss
	if LocalPlayer():Crouching() then
	vecCone = vecCone * .95
	end
	if !LocalPlayer():IsOnGround() then
	vecCone = vecCone * 20
	end
	elseif wep:GetClass() == "scout" then
	vecCone = Vector(-0.05,-0.05,0) * LocalPlayer():GetActiveWeapon().xhair.loss
	if LocalPlayer():Crouching() then
	vecCone = vecCone * .95
	end
	if !LocalPlayer():IsOnGround() then
	vecCone = vecCone * 20
	end
	elseif wep:GetClass() == "sg550" then
	vecCone = Vector(-0.004,-0.004,0) * LocalPlayer():GetActiveWeapon().xhair.loss
	if LocalPlayer():Crouching() then
	vecCone = vecCone * .95
	end
	if !LocalPlayer():IsOnGround() then
	vecCone = vecCone * 20
	end
	end
	end
    return hl2_manipshot(currentseed or 0, (aimAngle or CL:GetAimVector():Angle()):Forward(), vecCone):Angle()
end
else
print("cant find dec0")
PredictSpread = function(cmd,aimAngle)
return aimAngle
end
end
local function changenorecval()
if vH.norecval > 101 then
vH.norecval = 1
else
vH.norecval = vH.norecval + 1
end
end
local dontaim = {"npc_hunter","npc_dog","npc_monk","npc_alyx","npc_mossman","npc_barney","npc_eli","npc_gman","npc_citizen","npc_turret_floor","npc_grenade_frag","rebelturret","npc_vortigaunt","npc_barnacle","npc_barnacle_tongue_tip","npc_kleiner","npc_satchel","npc_rollermine"}
local function changepredval()
if vH.valpred > 5 then
vH.valpred = 0
else
vH.valpred = vH.valpred + 0.1
end
end

local function smoothens(input,input2)
if vH.smoother == 0 then
return input2
else
		local view2 = Angle(0,0,0)
		view2.p = math.Approach( input.p, input2.p, vH.smoother*FrameTime() )
		view2.y = math.Approach( input.y, input2.y, vH.smoother*FrameTime() )
		return view2
end
end
local function box( e )
	local ply, pos = LocalPlayer(), nil
	local center = e:LocalToWorld( e:OBBCenter() )
	local min, max = e:OBBMins(), e:OBBMaxs()
	local dim = max - min
	local z = max + min
	
	local frt	= ( e:GetForward() ) * ( dim.y / 2 )
	local rgt	= ( e:GetRight() ) * ( dim.x / 2 )
	local top	= ( e:GetUp() ) * ( dim.z / 2 )
	local bak	= ( e:GetForward() * -1 ) * ( dim.y / 2 )
	local lft	= ( e:GetRight() * -1 ) * ( dim.x / 2 )
	local btm	= ( e:GetUp() * -1 ) * ( dim.z / 2 )
	
	local d, v = math.Round( e:GetPos():Distance( ply:GetShootPos() ) )
	v = d / 30
	
	pos = e:LocalToWorld( top + top ) + Vector( 0, 0, v + 10 )
	if ( e:IsWeapon() ) then pos = e:LocalToWorld( e:OBBCenter() ) end
	
	local FRT 	= center + frt + rgt + top; FRT = FRT:ToScreen()
	local BLB 	= center + bak + lft + btm; BLB = BLB:ToScreen()
	local FLT	= center + frt + lft + top; FLT = FLT:ToScreen()
	local BRT 	= center + bak + rgt + top; BRT = BRT:ToScreen()
	local BLT 	= center + bak + lft + top; BLT = BLT:ToScreen()
	local FRB 	= center + frt + rgt + btm; FRB = FRB:ToScreen()
	local FLB 	= center + frt + lft + btm; FLB = FLB:ToScreen()
	local BRB 	= center + bak + rgt + btm; BRB = BRB:ToScreen()
	
	pos = pos:ToScreen()
	
	local maxX = math.max( FRT.x,BLB.x,FLT.x,BRT.x,BLT.x,FRB.x,FLB.x,BRB.x )
	local minX = math.min( FRT.x,BLB.x,FLT.x,BRT.x,BLT.x,FRB.x,FLB.x,BRB.x )
	local maxY = math.max( FRT.y,BLB.y,FLT.y,BRT.y,BLT.y,FRB.y,FLB.y,BRB.y)
	local minY = math.min( FRT.y,BLB.y,FLT.y,BRT.y,BLT.y,FRB.y,FLB.y,BRB.y )
	
	return maxX, minX, maxY, minY
end

aimmodels = {
        ["models/combine_scanner.mdl"] = "Scanner.Body",
        ["models/hunter.mdl"] = "MiniStrider.body_joint",
        ["models/combine_turrets/floor_turret.mdl"] = "Barrel",
        ["models/dog.mdl"] = "Dog_Model.Eye",
        ["models/antlion.mdl"] = "Antlion.Body_Bone",
        ["models/antlion_guard.mdl"] = "Antlion_Guard.Body",
        ["models/antlion_worker.mdl"] = "Antlion.Head_Bone",
        ["models/zombie/fast_torso.mdl"] = "ValveBiped.HC_BodyCube",
        ["models/zombie/fast.mdl"] = "ValveBiped.HC_BodyCube",
        ["models/headcrabclassic.mdl"] = "HeadcrabClassic.SpineControl",
        ["models/headcrabblack.mdl"] = "HCBlack.body",
        ["models/headcrab.mdl"] = "HCFast.body",
        ["models/zombie/poison.mdl"] = "ValveBiped.Headcrab_Cube1",
        ["models/zombie/classic.mdl"] = "ValveBiped.HC_Body_Bone",
        ["models/zombie/classic_torso.mdl"] = "ValveBiped.HC_Body_Bone",
        ["models/zombie/zombie_soldier.mdl"] = "ValveBiped.HC_Body_Bone",
        ["models/combine_strider.mdl"] = "Combine_Strider.Body_Bone",
        ["models/lamarr.mdl"] = "HeadcrabClassic.SpineControl"
}
local bones = {
	// Main body
	{ S = "ValveBiped.Bip01_Head1", E = "ValveBiped.Bip01_Neck1" },
	{ S = "ValveBiped.Bip01_Neck1", E = "ValveBiped.Bip01_Spine4" },
	{ S = "ValveBiped.Bip01_Spine4", E = "ValveBiped.Bip01_Spine2" },
	{ S = "ValveBiped.Bip01_Spine2", E = "ValveBiped.Bip01_Spine1" },
	{ S = "ValveBiped.Bip01_Spine1", E = "ValveBiped.Bip01_Spine" },
	{ S = "ValveBiped.Bip01_Spine", E = "ValveBiped.Bip01_Pelvis" },
	
	// Left Arm
	{ S = "ValveBiped.Bip01_Spine2", E = "ValveBiped.Bip01_L_UpperArm" },
	{ S = "ValveBiped.Bip01_L_UpperArm", E = "ValveBiped.Bip01_L_Forearm" },
	{ S = "ValveBiped.Bip01_L_Forearm", E = "ValveBiped.Bip01_L_Hand" },
	
	// Right Arm
	{ S = "ValveBiped.Bip01_Spine2", E = "ValveBiped.Bip01_R_UpperArm" },
	{ S = "ValveBiped.Bip01_R_UpperArm", E = "ValveBiped.Bip01_R_Forearm" },
	{ S = "ValveBiped.Bip01_R_Forearm", E = "ValveBiped.Bip01_R_Hand" },
	
	// Left leg
	{ S = "ValveBiped.Bip01_Pelvis", E = "ValveBiped.Bip01_L_Thigh" },
	{ S = "ValveBiped.Bip01_L_Thigh", E = "ValveBiped.Bip01_L_Calf" },
	{ S = "ValveBiped.Bip01_L_Calf", E = "ValveBiped.Bip01_L_Foot" },
	{ S = "ValveBiped.Bip01_L_Foot", E = "ValveBiped.Bip01_L_Toe0" },
	
	// Right leg
	{ S = "ValveBiped.Bip01_Pelvis", E = "ValveBiped.Bip01_R_Thigh" },
	{ S = "ValveBiped.Bip01_R_Thigh", E = "ValveBiped.Bip01_R_Calf" },
	{ S = "ValveBiped.Bip01_R_Calf", E = "ValveBiped.Bip01_R_Foot" },
	{ S = "ValveBiped.Bip01_R_Foot", E = "ValveBiped.Bip01_R_Toe0" },
}

local function boneesp( e,drawcolor )
	if ( !e:IsPlayer() ) then return end
	if drawcolor then
	surface.SetDrawColor( drawcolor )
	else
	surface.SetDrawColor( 0, 255, 0, 255 )
	end
	for k, v in pairs( bones ) do
		local sPos, ePos = e:GetBonePosition( e:LookupBone( v.S ) ):ToScreen(), e:GetBonePosition( e:LookupBone( v.E ) ):ToScreen()
		
		surface.DrawLine( sPos.x, sPos.y, ePos.x, ePos.y )
	end
end
local function HeadPos(ply) 
    if ValidEntity(ply) then 
if (ply:GetClass()=="npc_tripmine") && (ply:GetClass()=="npc_satchel") && (ply:GetClass()=="npc_grenade_frag") then
return false
end
return ply:LookupBone(ply:LookupBone((aimmodels[ ply:GetModel() ] or "ValveBiped.Bip01_Head1"))) 
    else return end 
end
local function Visible(ply) 
    local trace = {start = LocalPlayer():GetShootPos(),endpos = HeadPos(ply),filter = {LocalPlayer(), ply}} 
    local tr = util.TraceLine(trace) 
	local u = LocalPlayer():GetCurrentCommand( )
		if (u:GetButtons() & IN_ATTACK > 0) then
		--[[if tr.MatType == 87 then
		local trace2 = {start = (tr.HitPos*2),endpos = HeadPos(ply),filter = {LocalPlayer(), ply}} 
		local tr2 = util.TraceLine(trace) 
		if tr2.Fraction == 1 then 
        return true 
		else 
		local trace3 = {start = (tr.HitPos/2),endpos = HeadPos(ply),filter = {LocalPlayer(), ply}} 
		local tr3 = util.TraceLine(trace) 
		if tr3.Fraction == 1 then 
        return true 
		else 
        return false 
		end 
		end
	return true		
	end]]--
	--return true
	end
if tr.Fraction == 1 then 
return true 
else 
return false 
end    
end
local tar = nil
local current = 1
local correctView = Angle( 0, 0, 0 )
local silent = Angle( 0, 0, 0 )
local view = Angle( 0, 0, 0 )
local SetViewAngles = _R["CUserCmd"].SetViewAngles
local function fovcheck(input,input2)
if (vH.fov/2) < 180 then
local angY = math.abs( math.NormalizeAngle( input.y - input2.y ) )
local angP = math.abs( math.NormalizeAngle( input.p - input2.p ) )
if angY < (vH.fov/2)+1 && angP < (vH.fov/2)+1 then
return true
else
return false
end
else
return true
end
end
local function checkteam(pl)
if vH.dontaimteam == 1 then
if LocalPlayer():Team() == pl:Team() then
return false
end
else
return true
end
end
local cppweaps = {}
cppweaps["weapon_357"] = true
cppweaps["weapon_smg1"] = true
cppweaps["weapon_ar2"] = true
cppweaps["weapon_shotgun"] = true
cppweaps["weapon_pistol"] = true
cppweaps["weapon_crossbow"] = true
cppweaps["weapon_rpg"] = true
local cppweapsrec = {}
cppweapsrec["weapon_357"] = 0.8
cppweapsrec["weapon_smg1"] = 1
cppweapsrec["weapon_ar2"] = 1.03
cppweapsrec["weapon_shotgun"] = 1
cppweapsrec["weapon_pistol"] = 1
cppweapsrec["weapon_crossbow"] = 1
local function anglepunch()
if (!(LocalPlayer():GetActiveWeapon() == nil) && ValidEntity(LocalPlayer():GetActiveWeapon())) then
if cppweaps[LocalPlayer():GetActiveWeapon():GetClass()] then
return (((LocalPlayer():GetPunchAngle( )) or Angle(0,0,0))*(cppweapsrec[LocalPlayer():GetActiveWeapon():GetClass()] or 0.8))
else
return Angle(0,0,0)
end
else
return Angle(0,0,0)
end
end
local function validtarget(entz)
if !ValidEntity(entz) then return false end
for k,v in pairs(dontaim) do
if entz:GetClass() == v then return false end
end
if entz:IsPlayer() then if checkteam(entz) then else return false end end
if !(entz:IsPlayer() or entz:IsNPC()) then return false end
if entz == LocalPlayer() then return false end
if !Visible(entz) then return false end
if entz:IsPlayer() then if !(entz:Alive()) then return false end end
if entz:GetMoveType() == MOVETYPE_NONE then return false end
return true
end
local function GetMeta(name)
	return table.Copy(_R[name] or {})
end
local VecM = GetMeta("Vector")
local function get(a,b)
return math.deg(math.acos(VecM["Dot"](a, b)))
end
local function FindTarget()
local wtf
	local targets = player.GetAll()
	for i, ent in pairs(targets) do
		if validtarget(ent) then
			wtf = ent
		end
	end
	return wtf
end
PredictWeapons = {
		["weapon_crossbow"] = 3110,
	}

function WeaponPrediction( e, pos )
	local ply = LocalPlayer()
	if ( ValidEntity( e ) && ( type( e:GetVelocity() ) == "Vector" ) ) then
	if ValidEntity(ply:GetActiveWeapon()) then
		local dis, wep = e:GetPos():Distance( ply:GetPos() ), ply:GetActiveWeapon():GetClass()
		if ( wep && PredictWeapons[ wep ]  ) then
			local t = (dis / 3500) + 0.05
					local mul = 0.0075
					local pos = ( pos + e:GetVelocity() * t )
			pos = pos - (e:GetVelocity() * mul)
			local crossbowspeed = (LocalPlayer():GetCurrentCommand():GetViewAngles()):Forward() * 3500
			local time2crossbow = (pos:Length() - LocalPlayer():GetPos():Length() )/(((crossbowspeed):Length()) - ((e:GetVelocity()):Length()))
			pos.z = pos.z
			return pos
		end
	end
	end
	return pos
end
local function validtarget2(entz)
if !ValidEntity(entz) then return false end
if !(entz:IsPlayer() or entz:IsNPC()) then return false end
if entz == LocalPlayer() then return false end
if entz:IsNPC() then 
if entz.IsDead == true then
return false
end
end
if entz:IsPlayer() then if entz:Health() < 1 then return false end end
if entz:IsPlayer() then if !checkteam(entz) then return false end end
if entz:IsNPC() then if entz.IsDead == true then return false end end
return true
end
local function Bot( u )
		local ply = LocalPlayer()
		if LocalPlayer():Alive() then
		local ply = LocalPlayer()
		local mouse = Angle(u:GetMouseY() * GetConVarNumber("m_pitch"), u:GetMouseX() * -GetConVarNumber("m_yaw"),0) or Angle(0,0,0)
        correctView = correctView + mouse
		end
		correctView.p = math.Clamp(math.NormalizeAngle( correctView.p ),-89,89)
		correctView.y = math.NormalizeAngle( correctView.y )
		local ply = LocalPlayer()
		if vH.nospread == 2 then
			view = PredictSpread(u,correctView)
		else
			view = correctView
		end
		if vH.nospread == 3 then
		if (u:GetButtons() & IN_ATTACK > 0) then
		--if ( ply:GetActiveWeapon():Clip1() >= 1 ) then
			view = PredictSpread(u,view)
		--end
		end
		end
		if (u:GetButtons() & IN_ATTACK > 0) then
		--if ( ply:GetActiveWeapon():Clip1() >= 1 ) then
			view = view-anglepunch()
		--end
		else
		if !(u:GetButtons() & IN_USE > 0) then
		view = view --+Vector(180,180,180)
		end
		end
		view.p = math.NormalizeAngle( view.p )
		view.y = math.NormalizeAngle( view.y )
		SetViewAngles( u, view)
		if vH.aimkey == 1 then
		if (u:GetButtons() & IN_ATTACK > 0) then
		--if ( ply:GetActiveWeapon():Clip1() >= 1 ) then
		else
		return end
		--else return end
		end
		if vH.aim==1 then else return end
		if ValidEntity(LocalPlayer():GetActiveWeapon()) then
		if vH.dontaimweaps[LocalPlayer():GetActiveWeapon():GetClass()] then return end
		else
		return
		end
		local trget = FindTarget()
		if trget && ValidEntity(trget) then
		local targetheadpos = HeadPos(trget)
		local velocity = trget:GetVelocity() or Vector(0,0,0)
		local velocityplayer = ply:GetVelocity() or Vector(0,0,0)
		local ang = (((WeaponPrediction( trget,targetheadpos+(velocity * 0.0024* (LocalPlayer():Ping() or 0) )) + velocity*vH.valpred*FrameTime())- (ply:GetShootPos()+velocityplayer*vH.valpred*FrameTime())):Angle())
		if vH.silent == 0 then
		correctView = (((targetheadpos - (ply:GetShootPos())):Angle()))
		end
		if vH.autoshoot == 1 then
			RunConsoleCommand( "+attack" )
			timer.Simple( 0.05, function() RunConsoleCommand( "-attack" ) end )
		end
		if (vH.nospread == 1) or (vH.nospread == 2) then
			ang = PredictSpread(u,ang)
		end
		if vH.nospread == 3 then
		if (u:GetButtons() & IN_ATTACK > 0) then
		--if ( ply:GetActiveWeapon():Clip1() >= 1 ) then
			ang = PredictSpread(u,ang)
		--end
		end
		end
		if (u:GetButtons() & IN_ATTACK > 0) then
		--if ( ply:GetActiveWeapon():Clip1() >= 1 ) then
			ang = ang-anglepunch()
		--end
		end
		if vH.silent == 1 then
		local move = Vector(CmdM["GetForwardMove"](u), CmdM["GetSideMove"](u), 0)
		local norm = VecM["GetNormal"](move)
		local set = AngM["Forward"](VecM["Angle"](norm) + (ang - correctView)) * VecM["Length"](move)
		CmdM["SetForwardMove"](u, set.x)
		CmdM["SetSideMove"](u, set.y)
		end
		ang.p = math.NormalizeAngle(ang.p)
		ang.y = math.NormalizeAngle(ang.y)
		SetViewAngles( u, ang )
		end
		end
hook.Add("CreateMove","nospreadnaim",Bot)
	local function NoRecoil( u, o )
		return { origin = o, angles = correctView}
	end
	hook.Add( "CalcView","lol", NoRecoil )

local varmenu = {}
varmenu.current = 1
varmenu.showmenu = 0
local radar = {}
function DrawFadingColorBoxradar(x,y,w,h,alpha,mode)
if mode== 2 then
	local calculater = h/100
	local calculate = h/200
	local calculate2 = h/200
		for i=0,h do
		surface.SetDrawColor( 200-i/calculate, 200-i/calculate, 200-i/calculate, alpha)
		surface.DrawLine( x, i+y, x+w, i+y )
		end
else
	local calculater = h/100
	local calculate = h/200
	local calculate2 = h/200
		for i=0,h do
		surface.SetDrawColor( i/calculate, i/calculate, i/calculate, alpha)
		surface.DrawLine( x, i+y, x+w, i+y )
		end
end
end
function DrawRotatingCrosshair(x,y,time,length,gap)
    surface.DrawLine(
        x + (math.sin(math.rad(time)) * length),
        y + (math.cos(math.rad(time)) * length),
        x + (math.sin(math.rad(time)) * gap),
        y + (math.cos(math.rad(time)) * gap)
    )
end
local function drawbradar()
surface.SetDrawColor( 0, 0, 0, 255 ); -- 68,68,68,255
surface.DrawRect( 0, 0, 200, 200 ); 
DrawFadingColorBoxradar(0,0,200,30,255,2)
DrawFadingColorBoxradar(0,200-31,200,30,255,1)
surface.SetDrawColor( 90, 106, 79, 255 ); 
surface.DrawOutlinedRect( 0, 0, 200, 200 ); 
surface.DrawLine( 10, 100, 190, 100 ); 
surface.DrawLine( 100, 10, 100, 190 );
		local time = (CurTime()*2) * -180
		DrawRotatingCrosshair(100,100,time,90,0)
--Default values
radar.w = 200
radar.h = 200
radar.x = 0
radar.y = 0
radar.alphascale = 0.6
radar.bgcolor = Color(255,0,0,255)
radar.fgcolor = Color(0,0,255,255)
radar.dangercolour = Color(220,0,0,255)
radar.dangerblipcolour = Color(255,255,0,255)
radar.screendetail = 64
radar.screenrotation = 0
radar.hazardmode = false    --doesnt work

radar.radius = 5000

radar.player_show = true
radar.player_color = Color(0,150,255,255)
surface.CreateFont("Arial",64,400,false,false,"RadarPlayerLabel")
radar.player_fontcolor = Color(255,255,255,255)
radar.player_showname = true
radar.player_showhealth = true
radar.player_showarmor = false --TO DO
radar.player_showammo = true


radar.scanfor = {"player", "blastfungus", "rpg_missile", "crossbow_bolt", "npc_", "sent_", "prop_vehicle_"}		-- What should the radar look for?  Accepts partial names.
radar.dangerous = {"sent_nuke_missile", "sent_nuke_detpack"}    --doesnt work

radar.bgcolorbak = radar.bgcolor
radar.fgcolorbak = radar.fgcolor
radar.player_colorbak = radar.player_color


local color_ascale = function(col,scale) return Color(col.r,col.g,col.b,col.a*scale) end

	local ETable = {}
	local PulseRadar = false

	local lpl = LocalPlayer()
	
	
	if ( radar.player_show ) then
	local vertices = {}
	for i=1,radar.screendetail do
		local shift = math.fmod(CurTime()*radar.screenrotation,360)
		local sizescale = 1
		local tab = {}
		tab.x = radar.x+radar.w/2 + math.cos(math.Deg2Rad((360/radar.screendetail)*i+shift)) * radar.w/2 * sizescale
		tab.y = radar.y+radar.h/2 + math.sin(math.Deg2Rad((360/radar.screendetail)*i+shift)) * radar.h/2 * sizescale
		tab.u = 0
		tab.v = 0
		table.insert(vertices,tab)
	end
	local players = {}

	for k,ent in pairs(ents.GetAll()) do

			if ent:IsValid() then
				local type = ent:GetClass()

				for k, v in ipairs(radar.scanfor) do
					if string.find(type,v) then
						table.insert(players,ent)
					end
				end
			end
		end
		for i, pl in ipairs(players) do
			local cx = radar.x+radar.w/2
			local cy = radar.y+radar.h/2
			local vdiff = pl:GetPos()-lpl:GetPos()
			local dummy = nil
				if pl:IsPlayer() then
					if ( pl:Alive() and lpl~=pl ) then
						local px = (vdiff.x/radar.radius)
						local py = (vdiff.y/radar.radius)
						local z = math.sqrt( px*px + py*py )
						local phi = math.Deg2Rad( math.Rad2Deg( math.atan2( px, py ) ) - math.Rad2Deg( math.atan2( lpl:GetAimVector().x, lpl:GetAimVector().y ) ) - 90 )
						px = math.cos(phi)*z
						py = math.sin(phi)*z
						draw.RoundedBox( 0, math.Clamp(cx+px*radar.w/2-4,0,190), math.Clamp(cy+py*radar.h/2-4,0,190), 8, 8, Color(0,100,255,255) )
						surface.SetDrawColor( 0,0,0,255 )
						surface.DrawOutlinedRect( math.Clamp(cx+px*radar.w/2-4,0,190), math.Clamp(cy+py*radar.h/2-4,0,190), 8, 8)
					end
				end
				if ((not pl:IsPlayer()) and pl:IsValid() ) then

				    local isDangerous = false
					if ( radar.hazardmode ) then
						for k,v in ipairs(radar.dangerous) do
						    if (pl:GetClass() == v) then
						        table.insert(ETable,pl)
						        isDangerous = true
							end
						end
					end
					
					local px = (vdiff.x/radar.radius)
					local py = (vdiff.y/radar.radius)
					local z = math.sqrt( px*px + py*py )
					local phi = math.Deg2Rad( math.Rad2Deg( math.atan2( px, py ) ) - math.Rad2Deg( math.atan2( lpl:GetAimVector().x, lpl:GetAimVector().y ) ) - 90 )
					px = math.cos(phi)*z
					py = math.sin(phi)*z

					if (isDangerous == false) then
						draw.RoundedBox( 0, math.Clamp(cx+px*radar.w/2-4,0,190), math.Clamp(cy+py*radar.h/2-4,0,190), 8, 8, Color(255,255,255,255) )
						surface.SetDrawColor( 0,0,0,255 )
						surface.DrawOutlinedRect( math.Clamp(cx+px*radar.w/2-4,0,190), math.Clamp(cy+py*radar.h/2-4,0,190), 8, 8)
					if pl:IsNPC() then
					if validtargetesp(pl) then
						if( Visible(pl) ) then
                        drawColor = Color( 255, 0, 0, 255 )
						else
                        drawColor = Color( 0, 255, 255, 255 )
						end
						draw.RoundedBox( 0, math.Clamp(cx+px*radar.w/2-4,0,190), math.Clamp(cy+py*radar.h/2-4,0,190), 8, 8, drawColor)
						surface.SetDrawColor( 0,0,0,255 )
						surface.DrawOutlinedRect( math.Clamp(cx+px*radar.w/2-4,0,190), math.Clamp(cy+py*radar.h/2-4,0,190), 8, 8)
					end
					end
					end


					if radar.player_showname then

						local nametag = ""
						if string.find(pl:GetClass(),"blastfungus") then nametag = ""
						elseif string.find(pl:GetClass(),"npc_") then nametag = string.sub(pl:GetClass(),5)
						elseif string.find(pl:GetClass(),"sent_") then nametag = string.sub(pl:GetClass(),6)
						elseif string.find(pl:GetClass(),"prop_vehicle_") then nametag = string.sub(pl:GetClass(),14)
						else nametag = pl:GetClass()
						end

						local nametable = string.Explode("_",nametag)
						nametag = table.concat(nametable," ")
						local nametag1 = string.sub(nametag,0,1)
						local nametag2 = string.sub(nametag,2)
						nametag1 = string.upper(nametag1)
						nametag = nametag1..nametag2


					end
				end
   			end
	 	end
   		local count = table.Count(ETable)
   		
   		if ( count > 0 ) then
   		for k,pl in ipairs(ETable) do
   			local cx = radar.x+radar.w/2
			local cy = radar.y+radar.h/2
			local vdiff = pl:GetPos()-lpl:GetPos()
			
   			local px = (vdiff.x/radar.radius)
			local py = (vdiff.y/radar.radius)
			local z = math.sqrt( px*px + py*py )
			local phi = math.Deg2Rad( math.Rad2Deg( math.atan2( px, py ) ) - math.Rad2Deg( math.atan2( lpl:GetAimVector().x, lpl:GetAimVector().y ) ) - 90 )
			px = math.cos(phi)*z
			py = math.sin(phi)*z
						draw.RoundedBox( 0, math.Clamp(cx+px*radar.w/2-4,0,190), math.Clamp(cy+py*radar.h/2-4,0,190), 8, 8, color_ascale(radar.player_color,255) )
						surface.SetDrawColor( 0,0,0,255 )
						surface.DrawOutlinedRect( math.Clamp(cx+px*radar.w/2-4,0,190), math.Clamp(cy+py*radar.h/2-4,0,190), 8, 8)
		end
			
			radar.bgcolor = Color(255,255,255,0)
			radar.fgcolor = Color(60,60,60,100)
			
			PulseRadar = true
		end
end

local function drawesp() 
if vH.esp == 1 then
        for k, v in pairs(ents.GetAll()) do 
            if( ValidEntity(v) and v ~= LocalPlayer() ) then
                if( v:IsNPC() ) then 
				if validtargetesp(v) then
                    local drawColor = Color(255, 255, 255, 255); 
                    local drawPosit = v:GetPos():ToScreen(); 
                    local vis = ""
                    if( Visible(v) ) then 
						vis = "Visible"
                        drawColor = Color( 255, 0, 0, 255 ); 
                    else 
						vis = "Invisible"
                        drawColor = Color( 0, 255, 255, 255 ); 
                    end
					if v==FindTarget() then
					drawColor = Color( 255, 255, 0, 255 ); 
					end
					surface.SetDrawColor(drawColor)
					local head = HeadPos(v):ToScreen()
					local maxX, minX, maxY, minY = box(v)
					local lol = maxY-minY
					local minz, maxz = v:OBBMins(), v:OBBMaxs()
					minz = (v:GetPos()+minz):ToScreen()
					maxz = (v:GetPos()+maxz):ToScreen()
					surface.DrawLine( maxX, maxY, maxX, minY )
					surface.DrawLine( maxX, minY, minX, minY )
					
					surface.DrawLine( minX, minY, minX, maxY )
					surface.DrawLine( minX, maxY, maxX, maxY )

                    local textData = {} 
                     
                    textData.pos = {} 
                    textData.pos[1] = drawPosit.x; 
                    textData.pos[2] = maxY+10; 
                    textData.color = drawColor; 
                    textData.text = v:GetClass(); 
                    textData.font = "DefaultFixed"; 
                    textData.xalign = TEXT_ALIGN_CENTER; 
                    textData.yalign = TEXT_ALIGN_CENTER; 
                    draw.Text( textData ); 
                    textData.pos = {} 
                    textData.pos[1] = drawPosit.x; 
                    textData.pos[2] = maxY+25; 
                    textData.color = drawColor; 
                    textData.text = vis; 
                    textData.font = "DefaultFixed"; 
                    textData.xalign = TEXT_ALIGN_CENTER; 
                    textData.yalign = TEXT_ALIGN_CENTER; 
                    draw.Text( textData );
					boneesp( v,drawColor )
					end
					elseif( v:IsPlayer() and v:Health() > 0 and v:Alive() ) then 
                    local drawColor = team.GetColor(v:Team()); 
                    local drawPosit = v:GetPos():ToScreen(); 
                     
                    if( Visible(v) ) then 
                        drawColor.a = 255; 
                    else 
                        drawColor.r = 255 - drawColor.r; 
                        drawColor.g = 255 - drawColor.g; 
                        drawColor.b = 255 - drawColor.b; 
                    end 
					if v==FindTarget() then
					drawColor = Color( 255, 255, 0, 255 ); 
					end
					boneesp( v,drawColor )
                    surface.SetDrawColor(drawColor)
                    local textData = {} 
                    local maxX, minX, maxY, minY = box(v)
					local lol = maxY-minY
					surface.SetDrawColor(drawColor)
					surface.DrawLine( maxX, maxY, maxX, minY )
					surface.DrawLine( maxX, minY, minX, minY )
					
					surface.DrawLine( minX, minY, minX, maxY )
					surface.DrawLine( minX, maxY, maxX, maxY )
                    textData.pos = {} 
                    textData.pos[1] = drawPosit.x; 
                    textData.pos[2] = maxY+10; 
                    textData.color = drawColor; 
                    textData.text = v:GetName(); 
                    textData.font = "DefaultFixed"; 
                    textData.xalign = TEXT_ALIGN_CENTER; 
                    textData.yalign = TEXT_ALIGN_CENTER; 
                     
                    draw.Text( textData ); 
					local max_armor = 100; 
                     
                    if( v:Armor() > max_armor ) then 
                       max_armor = v:Armor(); 
                    end 
                    if v:GetActiveWeapon() then if ValidEntity(v:GetActiveWeapon()) then
					if v:GetActiveWeapon():GetClass() == "weapon_ak47" then
					draw.SimpleText( "b" , "CSKillIcons", drawPosit.x, maxY+35, drawColor, TEXT_ALIGN_CENTER, TEXT_ALIGN_LEFT, 1)
					elseif v:GetActiveWeapon():GetClass() == "weapon_para" then
					draw.SimpleText( "z" , "CSKillIcons", drawPosit.x, maxY+35, drawColor, TEXT_ALIGN_CENTER, TEXT_ALIGN_LEFT, 1)
					elseif v:GetActiveWeapon():GetClass() == "weapon_mp5" then
					draw.SimpleText( "x" , "CSKillIcons", drawPosit.x, maxY+35, drawColor, TEXT_ALIGN_CENTER, TEXT_ALIGN_LEFT, 1)
					elseif v:GetActiveWeapon():GetClass() == "weapon_m4" then
					draw.SimpleText( "w" , "CSKillIcons", drawPosit.x, maxY+35, drawColor, TEXT_ALIGN_CENTER, TEXT_ALIGN_LEFT, 1)
					elseif v:GetActiveWeapon():GetClass() == "weapon_glock" then
					draw.SimpleText( "c" , "CSKillIcons", drawPosit.x, maxY+35, drawColor, TEXT_ALIGN_CENTER, TEXT_ALIGN_LEFT, 1)
					elseif v:GetActiveWeapon():GetClass() == "weapon_tmp" then
					draw.SimpleText( "d" , "CSKillIcons", drawPosit.x, maxY+35, drawColor, TEXT_ALIGN_CENTER, TEXT_ALIGN_LEFT, 1)
					elseif v:GetActiveWeapon():GetClass() == "weapon_deagle" then
					draw.SimpleText( "f" , "CSKillIcons", drawPosit.x, maxY+35, drawColor, TEXT_ALIGN_CENTER, TEXT_ALIGN_LEFT, 1)
					elseif v:GetActiveWeapon():GetClass() == "weapon_pumpshotgun" then
					draw.SimpleText( "k" , "CSKillIcons", drawPosit.x, maxY+35, drawColor, TEXT_ALIGN_CENTER, TEXT_ALIGN_LEFT, 1)
					end
					end
					end
					if v:Alive() then
					local center = Vector( x,y, 0 )
                    local mx = max_armor; 
                    local mw = v:Armor(); 
                    local drw = mw / lol
                    local drawPosHealth = drawPosit; 
					surface.SetDrawColor(0,0,0,255)
					surface.DrawRect(maxX+2,minY-1,6,lol+2)
					surface.SetDrawColor(255-(mw*2+50),mw*2+50,0,255)
					surface.DrawRect(maxX+3,minY-(mw/drw)+(mx/drw),4,mw/drw)
					local max_health = 100; 
                     
                    if( v:Health() > max_health ) then 
						max_health = v:Health(); 
                    end 
                    
                    local mx = max_health; 
                    local mw = v:Health(); 
                    local drw = mx / lol
                    local drawPosHealth = drawPosit; 
					surface.SetDrawColor(0,0,0,255)
					surface.DrawRect(minX-8,minY-1,6,lol+2)
					surface.SetDrawColor(255-(mw*2+50),mw*2+50,0,255)
					surface.DrawRect(minX-7,minY-(mw/drw)+(mx/drw),4,mw/drw)
					end
					end
    end 
	end
	end
	end
	local function admintype(plys)
	local admintypez = ""
	if plys:IsAdmin() then
	admintypez = "Admin"
	end
	if plys:IsSuperAdmin() then
	admintypez = "Super Admin"
	end
	return admintypez
	end
local function adminsget()
local adminnum = 0
local lawl = 15
for k, plys in pairs(player.GetAll()) do
if plys:IsAdmin() then
adminnum = adminnum + 1
end
end
	    --surface.SetDrawColor( 90, 106, 79, 255 ); 
		--surface.DrawRect( ScrW()-200, 0, 200, 20*(adminnum+1)+1 ); 
		surface.SetDrawColor( 0, 0, 0, 255 ); -- 68, 68, 68, 255
		surface.DrawRect( ScrW()-199, 18, 200, 20*(adminnum+1)+1 ); 
				
		DrawFadingColorBoxradar(ScrW()-199,0,200,17,255,2)
		DrawFadingColorBoxradar(ScrW()-199,20*(adminnum+1)+1,200,17,255,1)
		
		surface.SetDrawColor( 75, 81, 71, 255 ); 
		draw.SimpleTextOutlined( "Admins", "Default", ScrW()-100, 16/2, Color( 180, 180, 180, 255 ), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER, 1, Color( 0, 0, 0, 255 ) )
local lawl = 15
for k, plys in pairs(player.GetAll()) do
if plys:IsAdmin() then
adminnum = adminnum + 1
plyscolor = team.GetColor(plys:Team())
draw.SimpleText(plys:GetName().." ["..admintype(plys).."]", "TabLarge", ScrW()-190, lawl+5, plyscolor)
lawl = lawl + 10
end
end
surface.SetDrawColor( 90, 106, 79, 255 ); 
surface.DrawOutlinedRect( ScrW()-200, 0, 200, 20*(adminnum+1)); 
end
local function lol()
		--admin list
		if vH.admins == 1 then
		--adminsget()
		end
		--esp
		if vH.esp == 1 then
		drawesp()
		end
		--menu
		if varmenu.showmenu == 1 then
	    --surface.SetDrawColor( 90, 106, 79, 255 ); 
		--surface.DrawRect( ScrW()/2-100, 0, 200, 16*10+1 ); 
		surface.SetDrawColor( 0, 0, 0, 255 ); -- 68,68,68,255
		surface.DrawRect( ScrW()/2-100, 15, 200, 16*9-3 ); 
		DrawFadingColorBoxradar(ScrW()/2-100,0,200,30,255,2)
		DrawFadingColorBoxradar(ScrW()/2-100,16*10-30,200,30,255,1)
		surface.SetDrawColor( 0, 100, 200, 255 ); 
		if varmenu.current == 1 then
		surface.DrawRect(ScrW()/2-99,16,198,16); 
		elseif varmenu.current == 2 then
		surface.DrawRect(ScrW()/2-99,16*2,198,16); 
		elseif varmenu.current == 3 then
		surface.DrawRect(ScrW()/2-99,16*3,198,16); 
		elseif varmenu.current == 4 then
		surface.DrawRect(ScrW()/2-99,16*4,198,16); 
		elseif varmenu.current == 5 then
		surface.DrawRect(ScrW()/2-99,16*5,198,16); 
		elseif varmenu.current == 6 then
		surface.DrawRect(ScrW()/2-99,16*6,198,16); 
		elseif varmenu.current == 7 then
		surface.DrawRect(ScrW()/2-99,16*7,198,16); 
		elseif varmenu.current == 8 then
		surface.DrawRect(ScrW()/2-99,16*8,198,16); 
		elseif varmenu.current == 9 then
		surface.DrawRect(ScrW()/2-99,16*9,198,16); 
		end
		draw.SimpleTextOutlined( "valveHacks for GMOD by BB9", "Default", ScrW()/2, 16/2, Color( 180, 180, 180, 255 ), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER, 1, Color( 0, 0, 0, 255 ) )
		draw.SimpleTextOutlined( "Aimbot: "..vH.aim, "Default", ScrW()/2-80, 16/2+16, Color( 255, 255, 255, 255 ), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER, 1, Color( 0, 0, 0, 255 ) )
		draw.SimpleTextOutlined( "Crosshair: "..vH.cross, "Default", ScrW()/2-80, 16/2+(16*2), Color( 255, 255, 255, 255 ), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER, 1, Color( 0, 0, 0, 255 ) )
		draw.SimpleTextOutlined( "ESP: "..vH.esp, "Default", ScrW()/2-80, 16/2+(16*3), Color( 255, 255, 255, 255 ), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER, 1, Color( 0, 0, 0, 255 ) )
		draw.SimpleTextOutlined( "Radar: "..vH.radar, "Default", ScrW()/2-80, 16/2+(16*4), Color( 255, 255, 255, 255 ), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER, 1, Color( 0, 0, 0, 255 ) )
		draw.SimpleTextOutlined( "NoSpread: "..vH.nospread, "Default", ScrW()/2-80, 16/2+(16*5), Color( 255, 255, 255, 255 ), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER, 1, Color( 0, 0, 0, 255 ) )
		draw.SimpleTextOutlined( "NoRecoil Value: "..(vH.norecval/10), "Default", ScrW()/2-80, 16/2+(16*6), Color( 255, 255, 255, 255 ), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER, 1, Color( 0, 0, 0, 255 ) )
		draw.SimpleTextOutlined( "AutoShoot: "..vH.autoshoot, "Default", ScrW()/2-80, 16/2+(16*7), Color( 255, 255, 255, 255 ), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER, 1, Color( 0, 0, 0, 255 ) )
		draw.SimpleTextOutlined( "ValPred: "..vH.valpred, "Default", ScrW()/2-80, 16/2+(16*8), Color( 255, 255, 255, 255 ), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER, 1, Color( 0, 0, 0, 255 ) )
		draw.SimpleTextOutlined( "Silent Aim: "..vH.silent, "Default", ScrW()/2-80, 16/2+(16*9), Color( 255, 255, 255, 255 ), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER, 1, Color( 0, 0, 0, 255 ) )
		surface.SetDrawColor( 90, 106, 79, 255 ); 
		surface.DrawOutlinedRect( ScrW()/2-101, 0, 202, 162 ); 
		end
		--crosshair
		if vH.cross == 1 then
		--[[surface.SetDrawColor( 255, 255, 255, 255 ); 
		surface.DrawLine(ScrW()/2-15,ScrH()/2,ScrW()/2-5,ScrH()/2)
		surface.DrawLine(ScrW()/2,ScrH()/2+5,ScrW()/2,ScrH()/2+15)
		surface.DrawLine(ScrW()/2+5,ScrH()/2,ScrW()/2+15,ScrH()/2)
		surface.DrawLine(ScrW()/2,ScrH()/2-15,ScrW()/2,ScrH()/2-5)]]
		surface.SetDrawColor(255,255,255,255)
		surface.DrawLine(ScrW()/2,ScrH()/2-10,ScrW()/2,ScrH()/2+10)
		surface.DrawLine(ScrW()/2-10,ScrH()/2,ScrW()/2+10,ScrH()/2)
		local h = 20
		local x = ScrW()/2
		local y = ScrH()/2-30
		local calculate = h/255
		local calculate2 = h/255
		for i=0,h do
		surface.SetDrawColor( i/calculate, i/calculate, i/calculate, 255)
		surface.DrawLine( x, i+y, x+1, i+y )
		end
		local h = 20
		local x = ScrW()/2
		local y = ScrH()/2+10
		local calculate = h/255
		local calculate2 = h/255
		for i=0,h do
		surface.SetDrawColor( 255-i/calculate, 255-i/calculate, 255-i/calculate, 255)
		surface.DrawLine( x, i+y, x+1, i+y )
		end
		local h = 20
		local x = ScrW()/2-30
		local y = ScrH()/2
		local calculate = h/255
		local calculate2 = h/255
		for i=0,h do
		surface.SetDrawColor( i/calculate, i/calculate, i/calculate, 255)
		surface.DrawLine( x+i, y, x+i, y+1 )
		end
		local h = 20
		local x = ScrW()/2+10
		local y = ScrH()/2
		local calculate = h/255
		local calculate2 = h/255
		for i=0,h do
		surface.SetDrawColor( 255-i/calculate, 255-i/calculate, 255-i/calculate, 255)
		surface.DrawLine( x+i, y, x+i, y+1 )
		end
		end
		--radar
		if vH.radar == 1 then
		--drawbradar()
		end
end
hook.Add("HUDPaint","menuespandcrosshair",lol)
local timerruns = 1
function unhookz()
timerruns = 0
	hook.Remove("RenderScreenspaceEffects","bChams")
	hook.Remove( "HUDPaint","menuespandcrosshair" )
	hook.Remove( "CalcView","lol" )
	hook.Remove( "HUDPaint","crosshair")
	hook.Remove( "Think","aimbot" )
	hook.Remove( "CreateMove","nospreadnaim" )
	print("Unloaded Hooks")
end
local function KeyPress()
if timerruns == 1 then
timer.Simple(0.1,function () KeyPress() end)
end
    if( input.IsKeyDown( KEY_DELETE ) ) then
	timerruns = 0
	print("Destroyed timer")
unhookz()
	print("Unloaded Hooks")
	end
    if( input.IsKeyDown( KEY_INSERT ) ) then
	if varmenu.showmenu == 0 then
	varmenu.showmenu = 1
	else
	varmenu.showmenu = 0
	end
    end
	if varmenu.showmenu == 1 then
	if( input.IsKeyDown( KEY_DOWN ) ) then
	if varmenu.current == 1 then
	varmenu.current = 2
	elseif varmenu.current == 2 then
	varmenu.current = 3
	elseif varmenu.current == 3 then
	varmenu.current = 4
	elseif varmenu.current == 4 then
	varmenu.current = 5
	elseif varmenu.current == 5 then
	varmenu.current = 6
	elseif varmenu.current == 6 then
	varmenu.current = 7
	elseif varmenu.current == 7 then
	varmenu.current = 8
	elseif varmenu.current == 8 then
	varmenu.current = 9
	elseif varmenu.current == 9 then
	varmenu.current = 1
	end
	end
	if( input.IsKeyDown( KEY_UP ) ) then
	if varmenu.current == 9 then
	varmenu.current = 8
	elseif varmenu.current == 8 then
	varmenu.current = 7
	elseif varmenu.current == 7 then
	varmenu.current = 6
	elseif varmenu.current == 6 then
	varmenu.current = 5
	elseif varmenu.current == 5 then
	varmenu.current = 4
	elseif varmenu.current == 4 then
	varmenu.current = 3
	elseif varmenu.current == 3 then
	varmenu.current = 2
	elseif varmenu.current == 2 then
	varmenu.current = 1
	elseif varmenu.current == 1 then
	varmenu.current = 9
	end
	end
	if( input.IsKeyDown( KEY_RIGHT ) ) then
	if varmenu.current == 1 then
	if vH.aim == 1 then
	vH.aim = 0
	else
	vH.aim = 1
	end
	elseif varmenu.current == 2 then
	if vH.cross == 1 then
	vH.cross = 0
	else
	vH.cross = 1
	end
	elseif varmenu.current == 3 then
	if vH.esp == 1 then
	vH.esp = 0
	else
	vH.esp = 1
	end
	elseif varmenu.current == 4 then
	if vH.radar == 1 then
	vH.radar = 0
	else
	vH.radar = 1
	end
	elseif varmenu.current == 5 then
	if vH.nospread == 1 then
	vH.nospread = 2
	elseif vH.nospread == 2 then
	vH.nospread = 3
	elseif vH.nospread == 3 then
	vH.nospread = 0
	else
	vH.nospread = 1
	end
	elseif varmenu.current == 6 then
	changenorecval()
	elseif varmenu.current == 7 then
	if vH.autoshoot == 1 then
	vH.autoshoot = 0
	else
	vH.autoshoot = 1
	end
	elseif varmenu.current == 8 then
	changepredval()
	elseif varmenu.current == 9 then
	if vH.silent == 1 then
	vH.silent = 0
	else
	vH.silent = 1
	end
	end
	end
	end
	end
KeyPress()
local function bMaterial()
local Texture = {
  ["$basetexture"] = "models/debug/debugwhite", -- models/debug/debugwhite
  ["$model"]       = 1,
  ["$translucent"] = 1,
  ["$alpha"]       = 1,
  ["$nocull"]      = 1,
  ["$ignorez"]  = 1
}
local Texture2 = {
  ["$basetexture"] = "models/debug/debugwhite", -- models/debug/debugwhite
  ["$model"]       = 1,
  ["$translucent"] = 1,
  ["$alpha"]       = 1,
  ["$nocull"]      = 1
}
   
local material = CreateMaterial( "b_solid", "VertexLitGeneric", Texture )
local material2 = CreateMaterial( "b_solid2", "VertexLitGeneric", Texture2 )

return material,material2

end
local function bChams()
for k, v in pairs( ents.FindByClass("npc_*") ) do
if validtargetesp(v) then
if ValidEntity( v ) then
cam.Start3D( EyePos(), EyeAngles() )
local m,m2 = bMaterial()
render.SuppressEngineLighting( true )
render.SetColorModulation( 0, 0, 255 )
SetMaterialOverride( m )
v:DrawModel()
render.SuppressEngineLighting( false )
render.SetColorModulation( 255, 0, 0 )
SetMaterialOverride(m2)
v:DrawModel()
SetMaterialOverride(0)
cam.End3D()
			end
			end
		end
		end
hook.Add( "RenderScreenspaceEffects", "bChams", bChams )
LoadTime = math.floor(LoadTime - CurTime())
if LoadTime < 0 then
	LoadTime = -LoadTime
end
print("[aiaiaaz v0.2] | Loaded in "..LoadTime.." seconds")
print("                                   By BB9")
local function lol2()
local ply = LocalPlayer()
local angz = ply:GetShootPos()+ply:GetAimVector()
local x = (angz):ToScreen().x
local y = (angz):ToScreen().y
if LocalPlayer():Alive() then
local self = {}
local ViewModel = LocalPlayer():GetViewModel()
	if not ViewModel:IsValid() then return end
	self.EjectionPort = ViewModel:GetAttachment("1")
	if not self.EjectionPort then return end
 
	self.Angle = self.EjectionPort.Ang
	self.Forward = self.Angle:Forward()
	self.Position = self.EjectionPort.Pos
local angz2 = self.Position
local x2 = (angz2):ToScreen().x
local y2 = (angz2):ToScreen().y
surface.SetDrawColor(0,100,255,255)
surface.DrawLine(x,y,x2,y2)
surface.SetDrawColor(255,255,255,255)
	local center = Vector( x,y, 0 )
for i = 1,50 do
	local scale = Vector( i/10, i/10, 0 )
	local segmentdist = 360 / ( 2 * math.pi * math.max( scale.x, scale.y ) / 2 )
 
	for a = 0, 360 - segmentdist, segmentdist do
		surface.DrawLine( center.x + math.cos( math.rad( a ) ) * scale.x, center.y - math.sin( math.rad( a ) ) * scale.y, center.x + math.cos( math.rad( a + segmentdist ) ) * scale.x, center.y - math.sin( math.rad( a + segmentdist ) ) * scale.y )
	end
end
end
end
hook.Add("HUDPaint","crosshair",lol2)