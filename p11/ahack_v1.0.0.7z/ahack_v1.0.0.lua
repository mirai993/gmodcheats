--[[
		   _    _            _    
     /\   | |  | |          | |   
    /  \  | |__| | __ _  ___| | __
   / /\ \ |  __  |/ _` |/ __| |/ /
  / ____ \| |  | | (_| | (__|   < 
 /_/    \_\_|  |_|\__,_|\___|_|\_\

 Created by Atheon and originally released at MPGH. 
--]]

//I hear this makes the hack load faster, i didnt actually check the O times but whatever.
local hook = hook
local derma = derma
local surface = surface
local vgui = vgui
local input = input
local util = util
local cam = cam
local render = render
local math = math
local draw = draw

local AHack = {}
AHack.Active = CreateClientConVar("AHack_Active", 1, true, false)
AHack.Version = "1.0.0"
AHack.Ply = LocalPlayer()
AHack.TTT = (GAMEMODE and GAMEMODE.Name and string.find(GAMEMODE.Name, "Terror") and true) or false
AHack.DarkRP = (GAMEMODE and GAMEMODE.Name and string.find(GAMEMODE.Name, "DarkRP") and true) or false

//Converts a string of a color (ex. "Color(255, 255, 255, 255)") into an actual color, and returns the color.
AHack.GetColorFromString = function(words)
	//I probably shouldve just used string.explode...well.......
	if type(words) != "string" then return Color(255, 255, 255, 255) end
	words = "return "..words
	local func = CompileString(words, "GettingColors", true)
	local good, color = pcall(func)
	if good and type(color) == "table" and color.r and color.g and color.b and color.a then
		return color
	else
		return Color(255, 255, 255, 255)
	end
end

AHack.Aimbot = {}
AHack.Aimbot.CurTarget = nil
AHack.Aimbot.Vars = {}
AHack.Aimbot.Vars["Active"] = CreateClientConVar("AHack_Aimbot_Active", 0, true, false)
AHack.Aimbot.Vars["AttackNPCs"] = CreateClientConVar("AHack_Aimbot_AttackNPCs", 0, true, false)
AHack.Aimbot.Vars["AttackPlayers"] = CreateClientConVar("AHack_Aimbot_AttackPlayers", 0, true, false)
AHack.Aimbot.Vars["Prediction"] = CreateClientConVar("AHack_Aimbot_Prediction", 0, true, false)
AHack.Aimbot.Vars["AimOnKey"] = CreateClientConVar("AHack_Aimbot_AimOnKey", 0, true, false)
AHack.Aimbot.Vars["AimOnKey_Key"] = CreateClientConVar("AHack_Aimbot_AimOnKey_Key", "MOUSE_LEFT", true, false)
AHack.Aimbot.Vars["MaxAngle"] = CreateClientConVar("AHack_Aimbot_MaxAngle", 180, true, false)
AHack.Aimbot.Vars["Preferance"] = CreateClientConVar("AHack_Aimbot_Preferance", "Distance", true, false)
AHack.Aimbot.Vars["AntiSnap"] = CreateClientConVar("AHack_Aimbot_AntiSnap", 0, true, false)
AHack.Aimbot.Vars["AntiSnapSpeed"] = CreateClientConVar("AHack_Aimbot_AntiSnapSpeed", 4, true, false)
AHack.Aimbot.Vars["AutoShoot"] = CreateClientConVar("AHack_Aimbot_AutoShoot", 0, true, false)

AHack.ESP = {}
AHack.ESP.Vars = {}
AHack.ESP.Vars["Active"] = CreateClientConVar("AHack_ESP_Active", 0, true, false)
AHack.ESP.Vars["Players"] = CreateClientConVar("AHack_ESP_Players", 0, true, false)
AHack.ESP.Vars["NPCs"] = CreateClientConVar("AHack_ESP_NPCs", 0, true, false)
AHack.ESP.Vars["Name"] = CreateClientConVar("AHack_ESP_Name", 0, true, false)
AHack.ESP.Vars["Weapons"] = CreateClientConVar("AHack_ESP_Weapons", 0, true, false)
AHack.ESP.Vars["Distance"] = CreateClientConVar("AHack_ESP_Distance", 0, true, false)
AHack.ESP.Vars["Health"] = CreateClientConVar("AHack_ESP_Health", 0, true, false)
AHack.ESP.Vars["MaxDistance"] = CreateClientConVar("AHack_ESP_MaxDistance", 0, true, false)
AHack.ESP.Vars["Box"] = CreateClientConVar("AHack_ESP_Box", 0, true, false)
AHack.ESP.Vars["ShowTraitors"] = CreateClientConVar("AHack_ESP_ShowTraitors", 0, true, false)

AHack.Wallhack = {}
AHack.Wallhack.Vars = {}
AHack.Wallhack.Vars["Active"] = CreateClientConVar("AHack_Wallhack_Active", 0, true, false)
AHack.Wallhack.Vars["Players"] = CreateClientConVar("AHack_Wallhack_Players", 0, true, false)
AHack.Wallhack.Vars["NPCs"] = CreateClientConVar("AHack_Wallhack_NPCs", 0, true, false)
AHack.Wallhack.Vars["Weapons"] = CreateClientConVar("AHack_Wallhack_Weapons", 0, true, false)
AHack.Wallhack.Vars["Light"] = CreateClientConVar("AHack_Wallhack_Light", 0, true, false)
AHack.Wallhack.Vars["MaxDistance"] = CreateClientConVar("AHack_Wallhack_MaxDistance", 0, true, false)

AHack.Misc = {}
AHack.Misc.Vars = {}
AHack.Misc.Vars["ShowAdmins"] = CreateClientConVar("AHack_Misc_ShowAdmins", 0, true, false)
AHack.Misc.Vars["Crosshair"] = CreateClientConVar("AHack_Misc_Cross", 0, true, false)
AHack.Misc.Vars["NoRecoil"] = CreateClientConVar("AHack_Misc_NoRecoil", 0, true, false)
AHack.Misc.Vars["ShowSpectators"] = CreateClientConVar("AHack_Misc_ShowSpectators", 0, true, false)
AHack.Misc.Vars["BunnyHop"] = CreateClientConVar("AHack_Misc_BunnyHop", 0, true, false)
AHack.Misc.Vars["BunnyHop_Key"] = CreateClientConVar("AHack_Misc_BunnyHop_Key", "KEY_SPACE", true, false)
AHack.Misc.Vars["AutoReload"] = CreateClientConVar("AHack_Misc_AutoReload", 0, true, false)
AHack.Misc.Vars["AutoPistol"] = CreateClientConVar("AHack_Misc_AutoPistol", 0, true, false)
AHack.Misc.Vars["BuyHealth"] = CreateClientConVar("AHack_Misc_BuyHealth", 0, true, false)
AHack.Misc.Vars["BuyHealth_Minimum"] = CreateClientConVar("AHack_Misc_BuyHealth_Minimum", 80, true, false)
AHack.Misc.Vars["TraitorFinder"] = CreateClientConVar("AHack_Misc_TraitorFinder", 0, true, false)

AHack.Style = {}
AHack.Style.Vars = {}
AHack.Style.Vars["BoundingBox"] = {}
AHack.Style.Vars["BoundingBox"].var = CreateClientConVar("AHack_Style_BoundingBox", "Color(255, 0, 0, 255)", true, false)
AHack.Style.Vars["BoundingBox"].color = AHack.GetColorFromString(AHack.Style.Vars["BoundingBox"].var:GetString())
AHack.Style.Vars["ESPText"] = {}
AHack.Style.Vars["ESPText"].var = CreateClientConVar("AHack_Style_ESPText", "Color(255, 255, 255, 255)", true, false)
AHack.Style.Vars["ESPText"].color = AHack.GetColorFromString(AHack.Style.Vars["ESPText"].var:GetString())
AHack.Style.Vars["Crosshair"] = {}
AHack.Style.Vars["Crosshair"].var = CreateClientConVar("AHack_Style_Cross", "Color(255, 255, 255, 255)", true, false)
AHack.Style.Vars["Crosshair"].color = AHack.GetColorFromString(AHack.Style.Vars["Crosshair"].var:GetString())

//This is all the bones i look for in the order im looking for them. Feel free to change the order if you want to attack the foot before the head or something like that.
AHack.Bones = {
"ValveBiped.Bip01_Head1",
"ValveBiped.Bip01_Neck1",
"ValveBiped.Bip01_Spine4",
"ValveBiped.Bip01_Spine2",
"ValveBiped.Bip01_Spine1",
"ValveBiped.Bip01_Spine",
"ValveBiped.Bip01_R_UpperArm",
"ValveBiped.Bip01_R_Forearm",
"ValveBiped.Bip01_R_Hand",
"ValveBiped.Bip01_L_UpperArm",
"ValveBiped.Bip01_L_Forearm",
"ValveBiped.Bip01_L_Hand",
"ValveBiped.Bip01_R_Thigh",
"ValveBiped.Bip01_R_Calf",
"ValveBiped.Bip01_R_Foot",
"ValveBiped.Bip01_R_Toe0",
"ValveBiped.Bip01_L_Thigh",
"ValveBiped.Bip01_L_Calf",
"ValveBiped.Bip01_L_Foot",
"ValveBiped.Bip01_L_Toe0"
}

//A list of all keyboard keys, for binding
AHack.Keys = {
[0] = "KEY_NONE",
[1] = "KEY_0",
[2] = "KEY_1",
[3] = "KEY_2",
[4] = "KEY_3",
[5] = "KEY_4",
[6] = "KEY_5",
[7] = "KEY_6",
[8] = "KEY_7",
[9] = "KEY_8",
[10] = "KEY_9",
[11] = "KEY_A",
[12] = "KEY_B",
[13] = "KEY_C",
[14] = "KEY_D",
[15] = "KEY_E",
[16] = "KEY_F",
[17] = "KEY_G",
[18] = "KEY_H",
[19] = "KEY_I",
[20] = "KEY_J",
[21] = "KEY_K",
[22] = "KEY_L",
[23] = "KEY_M",
[24] = "KEY_N",
[25] = "KEY_O",
[26] = "KEY_P",
[27] = "KEY_Q",
[28] = "KEY_R",
[29] = "KEY_S",
[30] = "KEY_T",
[31] = "KEY_U",
[32] = "KEY_V",
[33] = "KEY_W",
[34] = "KEY_X",
[35] = "KEY_Y",
[36] = "KEY_Z",
[37] = "KEY_PAD_0",
[38] = "KEY_PAD_1",
[39] = "KEY_PAD_2",
[40] = "KEY_PAD_3",
[41] = "KEY_PAD_4",
[42] = "KEY_PAD_5",
[43] = "KEY_PAD_6",
[44] = "KEY_PAD_7",
[45] = "KEY_PAD_8",
[46] = "KEY_PAD_9",
[47] = "KEY_PAD_DIVIDE",
[48] = "KEY_PAD_MULTIPLY",
[49] = "KEY_PAD_MINUS",
[50] = "KEY_PAD_PLUS",
[51] = "KEY_PAD_ENTER",
[52] = "KEY_PAD_DECIMAL",
[53] = "KEY_LBRACKET",
[54] = "KEY_RBRACKET",
[55] = "KEY_SEMICOLON",
[56] = "KEY_APOSTROPHE",
[57] = "KEY_BACKQUOTE",
[58] = "KEY_COMMA",
[59] = "KEY_PERIOD",
[60] = "KEY_SLASH",
[61] = "KEY_BACKSLASH",
[62] = "KEY_MINUS",
[63] = "KEY_EQUAL",
[64] = "KEY_ENTER",
[65] = "KEY_SPACE",
[66] = "KEY_BACKSPACE",
[67] = "KEY_TAB",
[68] = "KEY_CAPSLOCK",
[69] = "KEY_NUMLOCK",
[70] = "KEY_ESCAPE",
[71] = "KEY_SCROLLLOCK",
[72] = "KEY_INSERT",
[73] = "KEY_DELETE",
[74] = "KEY_HOME",
[75] = "KEY_END",
[76] = "KEY_PAGEUP",
[77] = "KEY_PAGEDOWN",
[78] = "KEY_BREAK",
[79] = "KEY_LSHIFT",
[80] = "KEY_RSHIFT",
[81] = "KEY_LALT",
[82] = "KEY_RALT",
[83] = "KEY_LCONTROL",
[84] = "KEY_RCONTROL",
[85] = "KEY_LWIN",
[86] = "KEY_RWIN",
[87] = "KEY_APP",
[88] = "KEY_UP",
[89] = "KEY_LEFT",
[90] = "KEY_DOWN",
[91] = "KEY_RIGHT",
[92] = "KEY_F1",
[93] = "KEY_F2",
[94] = "KEY_F3",
[95] = "KEY_F4",
[96] = "KEY_F5",
[97] = "KEY_F6",
[98] = "KEY_F7",
[99] = "KEY_F8",
[100] = "KEY_F9",
[101] = "KEY_F10",
[102] = "KEY_F11",
[103] = "KEY_F12",
//[104] = "KEY_CAPSLOCKTOGGLE", //THESE
//[105] = "KEY_NUMLOCKTOGGLE", //MOFOS
//[106] = "KEY_SCROLLLOCKTOGGLE", //SHOULD DIE
[107] = "KEY_XBUTTON_UP",
[108] = "KEY_XBUTTON_DOWN",
[109] = "KEY_XBUTTON_LEFT",
[110] = "KEY_XBUTTON_RIGHT",
[111] = "KEY_XBUTTON_START",
[112] = "KEY_XBUTTON_BACK",
[113] = "KEY_XBUTTON_STICK1",
[114] = "KEY_XBUTTON_STICK2",
[115] = "KEY_XBUTTON_A",
[116] = "KEY_XBUTTON_B",
[117] = "KEY_XBUTTON_X",
[118] = "KEY_XBUTTON_Y",
[119] = "KEY_XBUTTON_BLACK",
[120] = "KEY_XBUTTON_WHITE",
[121] = "KEY_XBUTTON_LTRIGGER",
[122] = "KEY_XBUTTON_RTRIGGER",
[123] = "KEY_XSTICK1_UP",
[124] = "KEY_XSTICK1_DOWN",
[125] = "KEY_XSTICK1_LEFT",
[126] = "KEY_XSTICK1_RIGHT",
[127] = "KEY_XSTICK2_UP",
[128] = "KEY_XSTICK2_DOWN",
[129] = "KEY_XSTICK2_LEFT",
[130] = "KEY_XSTICK2_RIGHT"
}
//A list of all mouse keys, for binding
AHack.MouseKeys = {
[107] = "MOUSE_LEFT",
[108] = "MOUSE_RIGHT",
[109] = "MOUSE_MIDDLE",
[110] = "MOUSE_4",
[111] = "MOUSE_5"
}
//Tells me if a specific key is pressed. Loops through both tables.
AHack.KeyPressed = function(key)
	if AHack.InChat then return false end
	
	for k = 107, 111 do
		if key == AHack.MouseKeys[k] then
			if input.IsMouseDown(k) then
				return true
			else
				return false
			end
		end
	end
	
	for k = 0, 130 do
		if key == AHack.Keys[k] then
			if input.IsKeyDown(k) then
				return true
			else
				return false
			end
		end
	end
	
	return false
end

//Very simple. If the boolean is true it returns 1. If the boolean is false then it returns 0. I dont think i ended up using this anywhere, but whatever, ill leave it here.
AHack.BoolToInt = function(bool)
	if bool then 
		return 1
	else
		return 0
	end
end

//Checking if a bone is visible, pos is the position of the bone and ent is the entity whos bone were looking for. 
AHack.BoneIsVisible = function(pos, ent)
	ent = ent or AHack.Aimbot.CurTarget
	local tracedata = {}
	tracedata.start = AHack.Ply:GetShootPos()
	tracedata.endpos = pos
	tracedata.filter = {AHack.Ply, ent}
	
	local trace = util.TraceLine(tracedata)
	if trace.HitPos:Distance(pos) < 0.005 then
		return true
	else
		return false
	end
end

//Checks all of the entities bones to find if we can see this entity or not.
AHack.CanSee = function(ent)
	for k = 1, #AHack.Bones do 
		local v = AHack.Bones[k]
		local bone = ent:LookupBone(v)
		if bone != nil then
			local pos, ang = ent:GetBonePosition(bone)
			if AHack.BoneIsVisible(pos, ent) then
				return true
			end
		end
	end
	return false
end

//This returns the next entity we should attack.
AHack.GetTarget = function()
	if AHack.Aimbot.Vars["AttackNPCs"]:GetBool() or AHack.Aimbot.Vars["AttackPlayers"]:GetBool() then
		local targets = {}
		local everything = ents.GetAll()
		for k = 1, #everything do 
			local v = everything[k]
			if AHack.Aimbot.Vars["AttackNPCs"]:GetBool() and v:IsNPC() then
				if AHack.CanSee(v) then
					table.insert(targets, {["Target"] = v, ["Pos"] = v:LocalToWorld(v:OBBCenter())})
				end
			elseif AHack.Aimbot.Vars["AttackPlayers"]:GetBool() and v:IsPlayer() and v != AHack.Ply then
				if AHack.CanSee(v) then
					table.insert(targets, {["Target"] = v, ["Pos"] = v:LocalToWorld(v:OBBCenter())})
				end
			end
		end
		
		if #targets == 0 then 
			return nil
		elseif #targets == 1 then
			return targets[1]["Target"]
		end
		
		if AHack.Aimbot.Vars["Preferance"]:GetString() == "Distance" then
			local min = {["Distance"] = AHack.Ply:GetPos():Distance(targets[1]["Pos"]), ["Target"] = targets[1]["Target"]}
			for k = 1, #targets do 
				local v = targets[k]
				
				local distance = AHack.Ply:GetPos():Distance(v["Pos"])
				if distance < min["Distance"] then
					min = {["Distance"] = distance, ["Target"] = v["Target"]}
				end
			end
			return min["Target"]
		elseif AHack.Aimbot.Vars["Preferance"]:GetString() == "Angle" then		
			local min = {["Angle"] = AHack.AngleTo(targets[1]["Pos"]), ["Target"] = targets[1]["Target"]}
			for k = 1, #targets do 
				local v = targets[k]
				
				local angle = AHack.AngleTo(v["Pos"])
				if angle < min["Angle"] then
					min = {["Angle"] = angle, ["Target"] = v["Target"]}
				end
			end
			return min["Target"]
		end
	else
		return nil
	end
end

//This returns the total angle away from the target we are, and then the pitch and yaw seperately
AHack.AngleTo = function(pos)
	local myAngs = AHack.Ply:GetAngles()
	local needed = (pos - AHack.Ply:GetShootPos()):Angle()
	
	myAngs.p = math.NormalizeAngle(myAngs.p)
	needed.p = math.NormalizeAngle(needed.p)
	
	myAngs.y = math.NormalizeAngle(myAngs.y)
	needed.y = math.NormalizeAngle(needed.y)
	
	local p = math.NormalizeAngle(needed.p - myAngs.p)
	local y = math.NormalizeAngle(needed.y - myAngs.y)
	
	return math.abs(p) + math.abs(y), {p = p, y = y}
end

//Returns true if our target meets our preferances.
AHack.ValidTarget = function()
	if AHack.Aimbot.CurTarget == nil then return false end
	if not IsValid(AHack.Aimbot.CurTarget) then return false end
	if AHack.Aimbot.CurTarget:IsPlayer() and (not AHack.Aimbot.CurTarget:Alive() or AHack.Aimbot.CurTarget:Team() == TEAM_SPECTATOR or AHack.Aimbot.CurTarget:Health() < 1) then return false end
	if not AHack.Aimbot.Vars["AttackNPCs"]:GetBool() and AHack.Aimbot.CurTarget:IsNPC() then return false end
	if not AHack.Aimbot.Vars["AttackPlayers"]:GetBool() and AHack.Aimbot.CurTarget:IsPlayer() then return false end
	if not AHack.CanSee(AHack.Aimbot.CurTarget) then return false end
	
	return true
end

AHack.Chars = {"A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M", "N", "O", "P", "Q", "R", "S", "T", "U", "V", "W", "X", "Y", "Z"}
AHack.RandomName = function(amount)
	local toReturn = ""
	local amount = amount or 10
	for i = 1, amount do
		if math.random(0, 1) == 0 then
			toReturn = toReturn..string.lower(table.Random(AHack.Chars))
		else
			toReturn = toReturn..table.Random(AHack.Chars)
		end
	end
	return toReturn
end

AHack.Traitors = {}
hook.Add("HUDPaint", AHack.RandomName(math.random(10, 15)), function()
	if AHack.Active:GetBool() then	
		local everything = ents.GetAll()
		
		local AdminInfo = {}
		AdminInfo.Widest = 0
		AdminInfo.TotalHeight = 0
		
		local SpectatorInfo = {}
		SpectatorInfo.Widest = 0
		SpectatorInfo.TotalHeight = 0
		
		for k = 1, #everything do
			v = everything[k]
			
			if AHack.Wallhack.Vars["Active"]:GetBool() and v != AHack.Ply and ((v:IsPlayer() and v:Alive() and v:Team() != TEAM_SPECTATOR and AHack.Wallhack.Vars["Players"]:GetBool()) or (v:IsNPC() and v:Health() > 0 and AHack.Wallhack.Vars["NPCs"]:GetBool())) and (AHack.Wallhack.Vars["MaxDistance"]:GetInt() == 0 or v:GetPos():Distance(AHack.Ply:GetPos()) < AHack.Wallhack.Vars["MaxDistance"]:GetInt()) then
				cam.Start3D(EyePos(), EyeAngles())
					if AHack.Wallhack.Vars["Light"]:GetBool() then
						render.SuppressEngineLighting(true)	
					end
					
					local weapon = v:GetActiveWeapon()
					if AHack.Wallhack.Vars["Weapons"]:GetBool() and IsValid(weapon) then
						weapon:DrawModel()
					end
					
					v:DrawModel()
					
					render.SuppressEngineLighting(false)
				cam.End3D()
			end
			
			if AHack.ESP.Vars["Active"]:GetBool() and v != AHack.Ply and ((v:IsPlayer() and v:Alive() and v:Team() != TEAM_SPECTATOR and AHack.ESP.Vars["Players"]:GetBool()) or (v:IsNPC() and v:Health() > 0 and AHack.ESP.Vars["NPCs"]:GetBool())) and (AHack.ESP.Vars["MaxDistance"]:GetInt() == 0 or v:GetPos():Distance(AHack.Ply:GetPos()) < AHack.ESP.Vars["MaxDistance"]:GetInt()) then										
				if AHack.ESP.Vars["Box"]:GetBool() then
					local Min, Max = v:GetCollisionBounds()
					local one = v:LocalToWorld(Min):ToScreen()
					local two = v:LocalToWorld(Vector(Min.x, Min.y, Max.z)):ToScreen()
					local three = v:LocalToWorld(Vector(Min.x, Min.y + (Max.y * 2), Min.z)):ToScreen()
					local four = v:LocalToWorld(Vector(Min.x + (Max.x * 2), Min.y, Min.z)):ToScreen()
					local five = v:LocalToWorld(Max):ToScreen()
					local six = v:LocalToWorld(Vector(Max.x, Max.y, Min.z)):ToScreen()
					local seven = v:LocalToWorld(Vector(Max.x, Max.y + (Min.y * 2), Max.z)):ToScreen()
					local eight = v:LocalToWorld(Vector(Max.x + (Min.x * 2), Max.y, Max.z)):ToScreen()				
					
					surface.SetDrawColor(AHack.Style.Vars["BoundingBox"].color)
					local function connect(tabone, tabtwo)
						surface.DrawLine(tabone.x, tabone.y, tabtwo.x, tabtwo.y)
					end
					
					connect(one, two)
					connect(three, eight)
					connect(four, seven)
					connect(six, five)
					connect(four, six)
					connect(four, one)
					connect(one, three)
					connect(three, six)
					connect(five, eight)
					connect(eight, two)
					connect(two, seven)
					connect(seven, five)
				end
				
				surface.SetFont("ESPFont")
				
				local pos = v:GetPos()	
				local poscreen = pos:ToScreen()
				local y = poscreen.y
				local function drawtext(text)
					local W, H = surface.GetTextSize(text)
					surface.SetTextPos(poscreen.x - W / 2, y) 
					surface.DrawText(text)
					
					y = y + H
				end
				
				if AHack.ESP.Vars["ShowTraitors"]:GetBool() and table.HasValue(AHack.Traitors, v) then
					surface.SetTextColor(Color(255, 0, 0, 255))
					drawtext("Traitor")
				end
				
				surface.SetTextColor(AHack.Style.Vars["ESPText"].color)
				if v:IsPlayer() then
					if AHack.ESP.Vars["Name"]:GetBool() then drawtext("Name: "..v:Nick()) end	
				else
					if AHack.ESP.Vars["Name"]:GetBool() then drawtext("Name: "..v:GetClass()) end
				end
				
				if AHack.ESP.Vars["Weapons"]:GetBool() and IsValid(v:GetActiveWeapon()) then drawtext("Weapon: "..v:GetActiveWeapon():GetClass()) end						
				if AHack.ESP.Vars["Distance"]:GetBool() then drawtext("Distance: "..pos:Distance(AHack.Ply:GetPos())) end						
				if AHack.ESP.Vars["Health"]:GetBool() then drawtext("HP: "..v:Health()) end		
			end
			
			surface.SetFont("default")
			if AHack.Misc.Vars["ShowAdmins"]:GetBool() and v:IsPlayer() and v:IsSuperAdmin() then
				local name = v:Nick().." - Super Admin"
				local W, H = surface.GetTextSize(name)
				if W > AdminInfo.Widest then
					AdminInfo.Widest = W
				end
				AdminInfo.TotalHeight = AdminInfo.TotalHeight + H
				table.insert(AdminInfo, {name = name, Height = H})
			elseif AHack.Misc.Vars["ShowAdmins"]:GetBool() and v:IsPlayer() and v:IsAdmin() then
				local name = v:Nick().." - Admin"
				local W, H = surface.GetTextSize(name)
				if W > AdminInfo.Widest then
					AdminInfo.Widest = W
				end
				AdminInfo.TotalHeight = AdminInfo.TotalHeight + H
				table.insert(AdminInfo, {name = name, Height = H})
			end
			
			if AHack.Misc.Vars["ShowSpectators"]:GetBool() and v:IsPlayer() and v:GetObserverTarget() == AHack.Ply then
				local name = v:Nick()
				local W, H = surface.GetTextSize(name)
				if W > SpectatorInfo.Widest then
					SpectatorInfo.Widest = W
				end
				SpectatorInfo.TotalHeight = SpectatorInfo.TotalHeight + H
				table.insert(SpectatorInfo, {name = name, Height = H})
			end
			
			if AHack.TTT and AHack.Misc.Vars["TraitorFinder"]:GetBool() then
				if GetRoundState() == 3 and v:IsWeapon() and type(v:GetOwner()) == "Player" and v.Buyer == nil and v.CanBuy and table.HasValue(v.CanBuy, 1) then
					local owner = v:GetOwner()
					if owner:GetRole() == 2 then
						v.Buyer = owner
					else
						AHack.Ply:PrintMessage(3, owner:Nick().." bought a traitor weapon: "..v:GetClass())
						v.Buyer = owner
						table.insert(AHack.Traitors, owner)
					end
				elseif GetRoundState() != 3 then
					table.Empty(AHack.Traitors)
				end
			end
		end
		
		surface.SetFont("default")
		surface.SetTextColor(Color(255, 255, 255, 255))							
		if AHack.Misc.Vars["ShowAdmins"]:GetBool() then 
			local Height = 20
			draw.RoundedBox(8, ScrW() - AdminInfo.Widest - 30, 10, AdminInfo.Widest + 20, AdminInfo.TotalHeight + 20, Color(0, 0, 0, 150 ) )
			for k,v in pairs(AdminInfo) do
				if k != "Widest" and k != "TotalHeight" then
					surface.SetTextPos(ScrW() - 20 - AdminInfo.Widest, Height)
					surface.DrawText(v.name)
					Height = Height + v.Height
				end
			end
		end
		
		if AHack.Misc.Vars["ShowSpectators"]:GetBool() then
			local Height = AdminInfo.TotalHeight + 50
			draw.RoundedBox(8, ScrW() - SpectatorInfo.Widest - 30, 40 + AdminInfo.TotalHeight, SpectatorInfo.Widest + 20, SpectatorInfo.TotalHeight + 20, Color(0, 0, 0, 150 ) )
			for k,v in pairs(SpectatorInfo) do
				if k != "Widest" and k != "TotalHeight" then
					surface.SetTextPos(ScrW() - 20 - SpectatorInfo.Widest, Height)
					surface.DrawText(v.name)
					Height = Height + v.Height
				end
			end
		end
		
		if AHack.Misc.Vars["Crosshair"]:GetBool() then
			local MiddleScreen = {x = surface.ScreenWidth() / 2, y = surface.ScreenHeight() / 2}
			surface.SetDrawColor(AHack.Style.Vars["Crosshair"].color)
			surface.DrawLine(MiddleScreen.x, MiddleScreen.y, MiddleScreen.x - 50, MiddleScreen.y)
			surface.DrawLine(MiddleScreen.x, MiddleScreen.y, MiddleScreen.x, MiddleScreen.y - 50)
			surface.DrawLine(MiddleScreen.x, MiddleScreen.y, MiddleScreen.x + 50, MiddleScreen.y)
			surface.DrawLine(MiddleScreen.x, MiddleScreen.y, MiddleScreen.x, MiddleScreen.y + 50)
		end
	end
end)

hook.Add("Think", AHack.RandomName(math.random(10, 15)), function()
	if AHack.Active:GetBool() then
		if AHack.Aimbot.Vars["Active"]:GetBool() then
			if not AHack.Aimbot.Vars["AimOnKey"]:GetBool() or (AHack.Aimbot.Vars["AimOnKey"]:GetBool() and AHack.KeyPressed(AHack.Aimbot.Vars["AimOnKey_Key"]:GetString())) then
				if AHack.ValidTarget() then
					for k = 1, #AHack.Bones do 
						local bone = AHack.Aimbot.CurTarget:LookupBone(AHack.Bones[k])
						if bone != nil then
							local pos, ang = AHack.Aimbot.CurTarget:GetBonePosition(bone)
							local total, needed = 300, {300, 300}
							
							if AHack.Aimbot.Vars["Prediction"]:GetBool() then
								local tarSpeed = AHack.Aimbot.CurTarget:GetVelocity() * 0.013
								local plySpeed = AHack.Ply:GetVelocity() * 0.013
								total, needed = AHack.AngleTo(pos - plySpeed + tarSpeed)
							else
								total, needed = AHack.AngleTo(pos)
							end
								
							if AHack.BoneIsVisible(pos) and total < AHack.Aimbot.Vars["MaxAngle"]:GetInt() then
								local myAngles = AHack.Ply:GetAngles()
								
								if AHack.Aimbot.Vars["AntiSnap"]:GetBool() then
									local speed = AHack.Aimbot.Vars["AntiSnapSpeed"]:GetInt()
									AHack.Ply:SetEyeAngles(Angle(math.Approach(myAngles.p, myAngles.p + needed.p, speed), math.Approach(myAngles.y, myAngles.y + needed.y, speed), 0))
								else
									AHack.Ply:SetEyeAngles(Angle(myAngles.p + needed.p, myAngles.y + needed.y, 0))
								end
								
								break
							end
						end
					end
				else
					AHack.Aimbot.CurTarget = AHack.GetTarget()
				end
			else
				AHack.Aimbot.CurTarget = nil
			end
		end
		
		if AHack.Misc.Vars["NoRecoil"]:GetBool() then
			if IsValid(AHack.Ply:GetActiveWeapon()) then
				local weapon = AHack.Ply:GetActiveWeapon()
				if weapon.Primary then
					weapon.OldRecoil = weapon.OldRecoil or weapon.Primary.Recoil or weapon.Recoil
					weapon.Primary.Recoil = 0
					weapon.Recoil = 0
				else
					weapon.OldRecoil = weapon.OldRecoil or weapon.Recoil
					weapon.Recoil = 0
				end
			end
		elseif IsValid(AHack.Ply:GetActiveWeapon()) then
			local weapon = AHack.Ply:GetActiveWeapon()
			if weapon.Primary then
				weapon.Primary.Recoil = weapon.OldRecoil or weapon.Primary.Recoil or weapon.Recoil
				weapon.Recoil = weapon.OldRecoil or weapon.Recoil or weapon.Primary.Recoil
			else
				weapon.Recoil = weapon.OldRecoil or weapon.Recoil
			end
		end
		
		if AHack.DarkRP and AHack.Misc.Vars["BuyHealth"]:GetBool() then
			if AHack.Ply:Alive() and AHack.Ply:Health() < AHack.Misc.Vars["BuyHealth_Minimum"]:GetInt() then
				AHack.Ply:ConCommand("say /buyhealth")
			end
		end
	end
end)

AHack.Misc.NextReload = CurTime()
AHack.Misc.ShootNext = true
hook.Add("CreateMove", AHack.RandomName(math.random(10, 15)), function(cmd)
	if AHack.Active:GetBool() then
		local DontShoot = {"gmod_tool", "gmod_camera", "weapon_physgun", "weapon_physcannon"}
		if AHack.Aimbot.Vars["AutoShoot"]:GetBool() and AHack.Aimbot.Vars["Active"]:GetBool() and AHack.Ply:GetEyeTrace().Entity == AHack.Aimbot.CurTarget and IsValid(AHack.Ply:GetActiveWeapon()) and not table.HasValue(DontShoot, AHack.Ply:GetActiveWeapon():GetClass()) then
			cmd:SetButtons(cmd:GetButtons() + IN_ATTACK)
		end
		
		if AHack.Misc.Vars["BunnyHop"]:GetBool() and cmd:KeyDown(IN_JUMP) and AHack.KeyPressed(AHack.Misc.Vars["BunnyHop_Key"]:GetString()) then
			cmd:SetButtons(cmd:GetButtons() - IN_JUMP)
		end
		if AHack.Misc.Vars["BunnyHop"]:GetBool() and AHack.Ply:OnGround() and AHack.KeyPressed(AHack.Misc.Vars["BunnyHop_Key"]:GetString()) then
			cmd:SetButtons(cmd:GetButtons() + IN_JUMP)
		end
		
		local DontReload = {"gmod_tool", "gmod_camera", "weapon_physgun", "weapon_physcannon", "weapon_crowbar"}
		if AHack.Misc.Vars["AutoReload"]:GetBool() and IsValid(AHack.Ply:GetActiveWeapon()) and AHack.Ply:GetActiveWeapon():Clip1() < 1 and not table.HasValue(DontReload, AHack.Ply:GetActiveWeapon():GetClass()) and AHack.Misc.NextReload < CurTime() then
			cmd:SetButtons(cmd:GetButtons() + IN_RELOAD)
		end
		
		if AHack.Misc.Vars["AutoPistol"]:GetBool() and IsValid(AHack.Ply:GetActiveWeapon()) then
			local weapon = AHack.Ply:GetActiveWeapon()
			if weapon.Primary and type(weapon.Primary.Automatic) == "boolean" and not weapon.Primary.Automatic then
				if cmd:KeyDown(IN_ATTACK) then
					if AHack.Misc.ShootNext then
						AHack.Misc.ShootNext = false
					else
						cmd:SetButtons(cmd:GetButtons() - IN_ATTACK)
						AHack.Misc.ShootNext = true
					end
				end					
			elseif type(weapon.Automatic) == "boolean" and not weapon.Automatic then
				if cmd:KeyDown(IN_ATTACK) then
					if AHack.Misc.ShootNext then
						AHack.Misc.ShootNext = false
					else
						cmd:SetButtons(cmd:GetButtons() - IN_ATTACK)
						AHack.Misc.ShootNext = true
					end
				end
			end
		end
	end
end)

//Used to see if the player is typing in chat or not. Binds arent called when you're in chat.
AHack.InChat = false
hook.Add("StartChat", AHack.RandomName(math.random(10, 15)), function()
	AHack.InChat = true
end)
hook.Add("FinishChat", AHack.RandomName(math.random(10, 15)), function()
	AHack.InChat = false
end) 

concommand.Add("AHack_Menu", function()
	//Im only using DColumnSheet because everyone used DPropertySheet. I just want to be different
	local main = vgui.Create("DFrame")
	main:SetSize(500,496)
	main:Center()
	main:SetTitle("")
	main:MakePopup()
	main:ShowCloseButton(false)
	main.Paint = function()
		draw.RoundedBox( 0, 0, 0, main:GetWide(), main:GetTall(), Color( 0, 0, 0, 150 ) )
	end
	
	local PanicButton = vgui.Create("DButton", main)
	PanicButton:SetSize(50, 20)
	PanicButton:SetPos(415, 3)
	local function Enable()
		PanicButton:SetText("Disable")
		PanicButton.DoClick = function()
			PanicButton:SetText("Enable")
			PanicButton.DoClick = Enable
			AHack.Ply:ConCommand("AHack_Active 0")
		end
		AHack.Ply:ConCommand("AHack_Active 1")
	end
	local function Disable()
		PanicButton:SetText("Enable")
		PanicButton.DoClick = function()
			PanicButton:SetText("Disable")
			PanicButton.DoClick = Disable
			AHack.Ply:ConCommand("AHack_Active 1")
		end
		AHack.Ply:ConCommand("AHack_Active 0")
	end
	if AHack.Active:GetBool() then
		PanicButton:SetText("Disable")
		PanicButton.DoClick = Disable
	else
		PanicButton:SetText("Enable")
		PanicButton.DoClick = Enable
	end
	
	local CloseButton = vgui.Create("DButton", main)
	CloseButton:SetSize(30, 20)
	CloseButton:SetPos(465, 3)
	CloseButton:SetText("X")
	CloseButton.DoClick = function()
		main:Close()
	end
	
	local title = vgui.Create("DLabel", main)
	title:SetColor(Color(255, 255, 255, 255))
	title:SetFont("TitleFont")
	title:SetText("AHack - "..AHack.Version)
	title:SizeToContents()
	title:SetPos(main:GetWide() / 2 - title:GetWide() / 2,3)	
	
	ColumnSheet = vgui.Create("DColumnSheet",main)
	ColumnSheet:SetPos(5, 25)
	ColumnSheet:SetSize(500 ,465)
	
	local y = 40
	local function ToggleOption(name, parent, var)
		local text = vgui.Create("DLabel", parent)
		text:SetColor(Color(0, 0, 0, 255))
		text:SetFont("CatagoryText")
		text:SetText(name)
		text:SizeToContents()
		text:SetPos(parent:GetWide() / 4 - text:GetWide() / 2, y)
		
		local Options = vgui.Create("DComboBox", parent)
		Options:SetSize(100, 20)
		Options:SetPos(parent:GetWide() * 0.75 - Options:GetWide() / 2, y + 5)
		Options:AddChoice("Off", 0)
		Options:AddChoice("On", 1)
		Options.OnSelect = function(panel,index,value,data)
			AHack.Ply:ConCommand(var.." "..data)
		end
		Options:SetText(Options:GetOptionText(GetConVar(var):GetInt() + 1))
		
		y = y + 40
	end
	
	local function SetKeyOption(name, parent, var)
		local text = vgui.Create("DLabel", parent)
		text:SetColor(Color(0, 0, 0, 255))
		text:SetFont("CatagoryText")
		text:SetText(name)
		text:SizeToContents()
		text:SetPos(parent:GetWide() / 4 - text:GetWide() / 2, y)
		
		local Options = vgui.Create("DButton", parent)
		Options:SetSize(100, 20)
		Options:SetPos(parent:GetWide() * 0.75 - Options:GetWide() / 2, y + 5)
		Options:SetText(GetConVar(var):GetString())
		Options.DoClick = function()
			Options:SetText("Press a key...")
			Options.Think = function()
				for k = 107, 111 do
					if input.IsMouseDown(k) then
						AHack.Ply:ConCommand(var.." "..AHack.MouseKeys[k])
						Options:SetText(AHack.MouseKeys[k])
						Options.Think = nil
					end
				end
				
				for k = 0, 130 do
					if input.IsKeyDown(k) then
						AHack.Ply:ConCommand(var.." "..AHack.Keys[k])
						Options:SetText(AHack.Keys[k])
						Options.Think = nil
					end
				end 
			end
		end
		
		y = y + 40
	end
	
	local function SetNumberOption(name, parent, var, min, max, decimals)
		local text = vgui.Create("DLabel", parent)
		text:SetColor(Color(0, 0, 0, 255))
		text:SetFont("CatagoryText")
		text:SetText(name)
		text:SizeToContents()
		text:SetPos(parent:GetWide() / 4 - text:GetWide() / 2, y)
		
		local Options = vgui.Create("DNumberWang", parent)
		Options:SetSize(100, 20)
		Options:SetPos(parent:GetWide() * 0.75 - Options:GetWide() / 2, y + 5)
		Options:SetMin(min)
		Options:SetMax(max)
		Options:SetDecimals(decimals)
		Options:SetConVar(var)
		
		y = y + 40
	end
	
	local function MultiOption(name, parent, var, tab)
		local text = vgui.Create("DLabel", parent)
		text:SetColor(Color(0, 0, 0, 255))
		text:SetFont("CatagoryText")
		text:SetText(name)
		text:SizeToContents()
		text:SetPos(parent:GetWide() / 4 - text:GetWide() / 2, y)
		
		local Options = vgui.Create("DComboBox", parent)
		Options:SetSize(100, 20)
		Options:SetPos(parent:GetWide() * 0.75 - Options:GetWide() / 2, y + 5)
		for i = 1, #tab do
			Options:AddChoice(tab[i])
		end
		Options.OnSelect = function(panel,index,value,data)
			AHack.Ply:ConCommand(var.." "..value)
		end
		Options:SetText(GetConVar(var):GetString())
		
		y = y + 40
	end
	
	//Starting the Aimbot panel
	local Aimbot = vgui.Create("DPanel")
	Aimbot:SetSize(379, 465)
	Aimbot.Paint = function()
		draw.RoundedBox( 0, 0, 0, Aimbot:GetWide(), Aimbot:GetTall(), Color( 240, 240, 240, 255 ) )
	end
	
	local title = vgui.Create("DLabel", Aimbot)
	title:SetColor(Color(0, 0, 0, 255))
	title:SetFont("CatagoryHeader")
	title:SetText("Aimbot")
	title:SizeToContents()
	title:SetPos(Aimbot:GetWide() / 2 - title:GetWide() / 2, 0)
	
	ToggleOption("Active", Aimbot, "AHack_Aimbot_Active")
	MultiOption("Preferance", Aimbot, "AHack_Aimbot_Preferance", {"Distance", "Angle"})	
	ToggleOption("Attack Players", Aimbot, "AHack_Aimbot_AttackPlayers")
	ToggleOption("Attack NPCs", Aimbot, "AHack_Aimbot_AttackNPCs")
	ToggleOption("Prediction", Aimbot, "AHack_Aimbot_Prediction")
	ToggleOption("Aim On Key", Aimbot, "AHack_Aimbot_AimOnKey")
	SetKeyOption("Key", Aimbot, "AHack_Aimbot_AimOnKey_Key")
	ToggleOption("Anti Snap", Aimbot, "AHack_Aimbot_AntiSnap")
	SetNumberOption("A-Snap Speed", Aimbot, "AHack_Aimbot_AntiSnapSpeed", 1, 5, 2)
	SetNumberOption("Max Angle", Aimbot, "AHack_Aimbot_MaxAngle", 0, 270, 0)
	ToggleOption("Auto Shoot", Aimbot, "AHack_Aimbot_AutoShoot")
	
	if y > 465 then
		Aimbot:SetTall(y)
	end
	
	//This is the best way i can find to add a scrollbar to the menu...
	AimbotList = vgui.Create( "DPanelList" )
	AimbotList:SetSize(379, 465)
	AimbotList:SetSpacing(0)
	AimbotList:EnableHorizontal(false)
	AimbotList:EnableVerticalScrollbar(true)
	AimbotList:AddItem(Aimbot)
	
	ColumnSheet:AddSheet("Aimbot", AimbotList, "icon16/application_xp_terminal.png")

	//Starting the ESP panel
	local ESP = vgui.Create("DPanel")
	ESP:SetSize(379, 465)
	ESP.Paint = function()
		draw.RoundedBox( 0, 0, 0, ESP:GetWide(), ESP:GetTall(), Color( 240, 240, 240, 255 ) )
	end
	
	local title = vgui.Create("DLabel", ESP)
	title:SetColor(Color(0, 0, 0, 255))
	title:SetFont("CatagoryHeader")
	title:SetText("ESP")
	title:SizeToContents()
	title:SetPos(ESP:GetWide() / 2 - title:GetWide() / 2, 3)
	
	y = 40
	ToggleOption("Active", ESP, "AHack_ESP_Active")
	ToggleOption("Player Info", ESP, "AHack_ESP_Players")
	ToggleOption("NPC Info", ESP, "AHack_ESP_NPCs")
	ToggleOption("Names", ESP, "AHack_ESP_Name")
	ToggleOption("Weapons", ESP, "AHack_ESP_Weapons")
	ToggleOption("Distance", ESP, "AHack_ESP_Distance")
	ToggleOption("Health", ESP, "AHack_ESP_Health")
	ToggleOption("Bounding Box", ESP, "AHack_ESP_Box")
	ToggleOption("ShowTraitors", ESP, "AHack_ESP_ShowTraitors")
	SetNumberOption("Max Distance", ESP, "AHack_ESP_MaxDistance", 0, 8000, 0)
	
	if y > 465 then
		ESP:SetTall(y)
	end
	
	ESPList = vgui.Create( "DPanelList" )
	ESPList:SetSize(379, 465)
	ESPList:SetSpacing(0)
	ESPList:EnableHorizontal(false)
	ESPList:EnableVerticalScrollbar(true)
	ESPList:AddItem(ESP)
	
	ColumnSheet:AddSheet("ESP", ESPList, "icon16/pencil.png")
	
	//Starting the Wallhack panel
	local Wallhack = vgui.Create("DPanel")
	Wallhack:SetSize(379, 465)
	Wallhack.Paint = function()
		draw.RoundedBox( 0, 0, 0, Wallhack:GetWide(), Wallhack:GetTall(), Color( 240, 240, 240, 255 ) )
	end
	
	local title = vgui.Create("DLabel", Wallhack)
	title:SetColor(Color(0, 0, 0, 255))
	title:SetFont("CatagoryHeader")
	title:SetText("Wallhack")
	title:SizeToContents()
	title:SetPos(Wallhack:GetWide() / 2 - title:GetWide() / 2, 3)
	
	y = 40
	ToggleOption("Active", Wallhack, "AHack_Wallhack_Active")
	ToggleOption("Draw Players", Wallhack, "AHack_Wallhack_Players")
	ToggleOption("Draw NPCs", Wallhack, "AHack_Wallhack_NPCs")
	ToggleOption("Draw Weapons", Wallhack, "AHack_Wallhack_Weapons")
	ToggleOption("Light Up", Wallhack, "AHack_Wallhack_Light")
	SetNumberOption("Max Distance", Wallhack, "AHack_Wallhack_MaxDistance", 0, 8000, 0)
	
	if y > 465 then
		Wallhack:SetTall(y)
	end
	
	WallhackList = vgui.Create( "DPanelList" )
	WallhackList:SetSize(379, 465)
	WallhackList:SetSpacing(0)
	WallhackList:EnableHorizontal(false)
	WallhackList:EnableVerticalScrollbar(true)
	WallhackList:AddItem(Wallhack)
	
	ColumnSheet:AddSheet("Wallhack", WallhackList, "icon16/eye.png")
	
	//Starting the Misc panel
	local Misc = vgui.Create("DPanel")
	Misc:SetSize(379, 465)
	Misc.Paint = function()
		draw.RoundedBox( 0, 0, 0, Misc:GetWide(), Misc:GetTall(), Color( 240, 240, 240, 255 ) )
	end
	
	local title = vgui.Create("DLabel", Misc)
	title:SetColor(Color(0, 0, 0, 255))
	title:SetFont("CatagoryHeader")
	title:SetText("Misc")
	title:SizeToContents()
	title:SetPos(Misc:GetWide() / 2 - title:GetWide() / 2, 3)
	
	y = 40
	ToggleOption("Show Admins", Misc, "AHack_Misc_ShowAdmins")
	ToggleOption("Crosshair", Misc, "AHack_Misc_Cross")
	ToggleOption("No Recoil", Misc, "AHack_Misc_NoRecoil")
	ToggleOption("Spectators", Misc, "AHack_Misc_ShowSpectators")
	ToggleOption("Auto Reload", Misc, "AHack_Misc_AutoReload")
	ToggleOption("Bunny Hop", Misc, "AHack_Misc_BunnyHop")
	SetKeyOption("Key", Misc, "AHack_Misc_BunnyHop_Key")
	ToggleOption("Auto Pistol", Misc, "AHack_Misc_AutoPistol")
	ToggleOption("Buy Health", Misc, "AHack_Misc_BuyHealth")
	SetNumberOption("Minimum", Misc, "AHack_Misc_BuyHealth_Minimum", 0, 100, 0)
	ToggleOption("Traitor Finder", Misc, "AHack_Misc_TraitorFinder")

	if y > 465 then
		Misc:SetTall(y)
	end
	
	MiscList = vgui.Create( "DPanelList" )
	MiscList:SetSize(379, 465)
	MiscList:SetSpacing(0)
	MiscList:EnableHorizontal(false)
	MiscList:EnableVerticalScrollbar(true)
	MiscList:AddItem(Misc)

	ColumnSheet:AddSheet("Misc", MiscList, "icon16/package.png")
	
	local function ColorOption(name, parent, tab)
		local text = vgui.Create("DLabel", parent)
		text:SetColor(Color(0, 0, 0, 255))
		text:SetFont("CatagoryText")
		text:SetText(name)
		text:SizeToContents()
		text:SetPos(parent:GetWide() / 4 - text:GetWide() / 2, y + 30)
		
		local Options = vgui.Create("DColorMixer", parent)
		Options:SetSize(150, 100)
		Options:SetPos(parent:GetWide() * 0.75 - Options:GetWide() / 2, y)
		Options:SetColor(tab.color)//AHack.GetColorFromString(GetConVar(var):GetString()))
		Options:SetWangs(false)
		Options:SetPalette(false)
		Options.ValueChanged = function(panel, color) 
			AHack.Ply:ConCommand(tab.var:GetName().." ".."Color("..color.r..","..color.g..","..color.b..","..color.a..")")
			tab.color = AHack.GetColorFromString(tab.var:GetString())
		end
		
		y = y + 110
	end
	//Starting the Style panel
	local Style = vgui.Create("DPanel")
	Style:SetSize(379, 465)
	Style.Paint = function()
		draw.RoundedBox( 0, 0, 0, Style:GetWide(), Style:GetTall(), Color( 240, 240, 240, 255 ) )
	end
	
	local title = vgui.Create("DLabel", Style)
	title:SetColor(Color(0, 0, 0, 255))
	title:SetFont("CatagoryHeader")
	title:SetText("Style")
	title:SizeToContents()
	title:SetPos(Style:GetWide() / 2 - title:GetWide() / 2, 3)
	
	y = 50
	ColorOption("Bounding Box", Style, AHack.Style.Vars["BoundingBox"])
	ColorOption("ESP Text", Style, AHack.Style.Vars["ESPText"])
	ColorOption("Crosshair", Style, AHack.Style.Vars["Crosshair"])
	
	if y > 465 then
		Style:SetTall(y)
	end
	
	StyleList = vgui.Create( "DPanelList" )
	StyleList:SetSize(379, 465)
	StyleList:SetSpacing(0)
	StyleList:EnableHorizontal(false)
	StyleList:EnableVerticalScrollbar(true)
	StyleList:AddItem(Style)
	
	ColumnSheet:AddSheet("Style", StyleList, "icon16/color_wheel.png")
end)


//Just some fonts
surface.CreateFont("TitleFont", {font = "Arial", size = 20})
surface.CreateFont("CatagoryHeader", {font = "CloseCaption_Normal", size = 34})
surface.CreateFont("CatagoryText", {font = "CloseCaption_Normal", size = 30})
surface.CreateFont("ESPFont", {font = "CloseCaption_Normal", weight = 1000, size = 15})

--[[ 
	DPropertySheet - Slightly edited so it looks good.
--]]
local PANEL = {}
AccessorFunc( PANEL, "ActiveButton", "ActiveButton" )

--[[---------------------------------------------------------
Name: Init
-----------------------------------------------------------]]
function PANEL:Init()
	self.Navigation = vgui.Create( "DScrollPanel", self )
	self.Navigation:Dock( LEFT )
	self.Navigation:SetWidth( 100 )
	self.Navigation:DockMargin( 0, 0, 10, 0 )

	self.Content = vgui.Create( "Panel", self )
	self.Content:Dock( FILL )

	self.Items = {}
end

function PANEL:UseButtonOnlyStyle()
	self.ButtonOnly = true
end

--[[---------------------------------------------------------
Name: AddSheet
-----------------------------------------------------------]]
function PANEL:AddSheet( label, panel, material )
	if ( !IsValid( panel ) ) then return end

	local Sheet = {}

	if ( self.ButtonOnly ) then
		Sheet.Button = vgui.Create( "DImageButton", self.Navigation )
	else
		Sheet.Button = vgui.Create( "DButton", self.Navigation )
	end
	Sheet.Button:SetImage( material )
	Sheet.Button.Target = panel
	Sheet.Button:Dock( TOP )
	Sheet.Button:SetText( label )
	Sheet.Button:DockMargin( 0, 0, 0, 5 )

	Sheet.Button.DoClick = function ()
		self:SetActiveButton( Sheet.Button )
	end

	Sheet.Panel = panel
	Sheet.Panel:SetParent( self.Content )
	Sheet.Panel:SetVisible( false )

	if ( self.ButtonOnly ) then
		Sheet.Button:SizeToContents()
		Sheet.Button:SetColor( Color( 150, 150, 150, 255 ) )
	end

	table.insert( self.Items, Sheet )

	if ( !IsValid( self.ActiveButton ) ) then
		self:SetActiveButton( Sheet.Button )
	end
end

--[[---------------------------------------------------------
Name: SetActiveTab
-----------------------------------------------------------]]
function PANEL:SetActiveButton( active )
	if ( self.ActiveButton == active ) then return end

	if ( self.ActiveButton && self.ActiveButton.Target ) then	
		self.ActiveButton.Target:SetVisible( false )
		self.ActiveButton:SetSelected( false )
		self.ActiveButton:SetColor( Color( 0, 0, 0, 255 ) )
	end
	self.ActiveButton = active
	active.Target:SetVisible( true )
	active:SetSelected( true )
	active:SetColor( Color( 150, 150, 150, 255 ) )

	self.Content:InvalidateLayout()
end

derma.DefineControl( "DColumnSheet", "", PANEL, "Panel" )