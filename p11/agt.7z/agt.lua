--[[
	AGT.lua
	Gangster vs Gangster
	===DStream===
]]

surface.CreateFont("arial", 12, 400, true, false, "Small")

local bhop = false
hook.Add("Think", "Bunnyhop", function()
if bhop then
     if (input.IsKeyDown( KEY_SPACE ) ) then
        if LocalPlayer():IsOnGround() then
            RunConsoleCommand("+jump")
            HasJumped = 1
        else
            RunConsoleCommand("-jump")
            HasJumped = 0
        end
    elseif bhop and LocalPlayer():IsOnGround() then
        if HasJumped == 1 then
            RunConsoleCommand("-jump")
            HasJumped = 0
        end
    end
end
end)

concommand.Add("AGT_BhopToggle", function()
if bhop then
    bhop = !bhop
    LocalPlayer():ChatPrint("AGT Bhop Disabled")
else
    bhop = !bhop
    LocalPlayer():ChatPrint("AGT Bhop Enabled")
end
end)

hook.Add("Think", "Autoshoot", function()
if autoshoot and WeaponCheck() then
    if (input.IsMouseDown( MOUSE_LEFT )) then
        LocalPlayer():ConCommand("+attack; wait 3; -attack; wait 3")
    end
end
end)

concommand.Add("AGT_AutoshootToggle", function()
if autoshoot then
    autoshoot = !autoshoot
    LocalPlayer():ChatPrint("AGT Auto-Shoot Disabled")
else
    autoshoot = !autoshoot
    LocalPlayer():ChatPrint("AGT Auto-Shoot Enabled")
end
end)

function GetTarget()
    local position = LocalPlayer():EyePos()
    local angle = LocalPlayer():GetAimVector()
    local tar = {0,0}
for _, ent in pairs( ents.GetAll() ) do
        if LocalPlayer():Alive() and WeaponCheck() and TargetCheck( ent ) and TargetVisible( ent ) and AmmoCheck() then
            local targetpos = ent:EyePos()
            local editor = ( targetpos - position ):Normalize()
            editor = editor - angle
            editor = editor:Length()
            editor = math.abs( editor )
                if editor < tar[2] or tar[1] == 0 then
                tar = {ent, editor}
                end
        end
end
return tar[1]
end

local Aimed = _R["CUserCmd"].SetViewAngles
Aiming = false
function AutoAim(UCMD)
    if input.IsMouseDown( MOUSE_5 ) then
    if Aiming then
        local targ = GetTarget()
    if targ == 0 then
        return end
    local velocity = targ:GetVelocity() or Vector(0,0,0)
    Aimed(UCMD, ( ( HeadPosition( targ ) + velocity * 2 * FrameTime() ) - LocalPlayer():GetShootPos() ):Angle() )
    end
end
end
hook.Add("CreateMove", "Autoaim", AutoAim)

concommand.Add("AGT_AimBotToggle", function()
if Aiming then
    Aiming = !Aiming
    LocalPlayer():ChatPrint("AGT AimBot Disabled")
else
    Aiming = !Aiming
    LocalPlayer():ChatPrint("AGT AimBot Enabled")
end
end)

function WeaponCheck()
local BannedWeapons = {"weapon_physcannon", "weapon_physgun", "weapon_frag", "weapon_real_cs_smoke", "arrest_stick", "unarrest_stick", "stunstick",
"weapon_real_cs_flash", "weapon_real_cs_grenade", "spidermans_swep", "manhack_welder", "laserpointer", "remotecontroller", "med_kit",
"door_ram", "pocket", "weaponchecker", "lockpick", "keypad_cracker", "keys", "weapon_real_cs_knife", "gmod_tool", "gmod_camera", "weapon_crowbar",
"weapon_stunstick", "weapon_knife", "weapon_rpg"}
    if !LocalPlayer():Alive() then
        return false end
    if LocalPlayer():Alive() and LocalPlayer():GetActiveWeapon():IsValid() then
        Weapon = LocalPlayer():GetActiveWeapon():GetClass()
    else
        return false
    end
    if table.HasValue(BannedWeapons, Weapon) then
        return false
    else
        return true
    end

end

esptoggle = false
function esp()
if esptoggle then
    for _,v in ipairs (player.GetAll()) do
    local pos = v:GetPos() + Vector(0,0,90)
    local size = ScrW() * 0.02
    local dis = math.floor(v:GetPos():Distance(LocalPlayer():GetPos()))
    pos = pos:ToScreen()
    name = v:Nick()
    health = v:Health()
    steamid = v:SteamID()
    if v:Nick() != LocalPlayer():Nick() then
        if v:Health() > 0 then
            if v:GetFriendStatus() == "friend" then
                color = Color(0,255,0,255)
            else
                color = Color(255,255,255,255)
            end
            draw.DrawText(name, "ScoreboardText", pos.x, pos.y - 45, color,1)
            draw.DrawText("HP: "..health, "ScoreboardText", pos.x, pos.y - 30, Color(255,0,0,255),1)
            draw.DrawText("Dist: "..dis, "ScoreboardText", pos.x, pos.y - 15, Color(255,255,0,255),1)
            surface.SetDrawColor(Color(0,0,255,255))
            surface.DrawLine(pos.x - size , pos.y - 30, pos.x + size, pos.y - 30)
            if v:GetActiveWeapon():IsValid() and v:GetActiveWeapon():GetPrintName() then
                draw.DrawText((v:GetActiveWeapon( ):GetPrintName()), "ScoreboardText", pos.x, pos.y, Color(255,255,0,255),1)
            else
                draw.DrawText("None", "ScoreboardText", pos.x, pos.y, Color(255,255,0,255),1)
            end
        elseif v:Health() < 1 then
            color = Color(0,0,0,255)
            draw.DrawText(name.." is dead.", "ScoreboardText", pos.x, pos.y - 45, color,1)
            draw.DrawText("Dist: "..dis, "ScoreboardText", pos.x, pos.y - 30, color,1)
        end
    end
    end
    end
    end
hook.Add("HUDPaint", "Paint", esp)

concommand.Add("AGT_ESPToggle", function()
    if esptoggle then
        esptoggle = !esptoggle
        LocalPlayer():ChatPrint("AGT ESP Disabled")
    else
        esptoggle = !esptoggle
        LocalPlayer():ChatPrint("AGT ESP Enabled")
    end
end)

cross = false
hook.Add("HUDPaint", "Cross", function()
if cross then
    for _,v in ipairs (player.GetAll()) do
    local pos = v:GetPos() + Vector(0,0,45)
    local poscrouch = v:GetPos() + Vector(0,0,45) * .586
    local sizee = ScrW() * .01
    poss = pos:ToScreen()
    posscrouch = poscrouch:ToScreen()
    if v:Nick() != LocalPlayer():Nick() then
    if v:Health() > 0 then
        if v:Crouching() then
            if v:GetFriendStatus() == "friend" then
                color = Color(0,255,0,255)
                surface.SetDrawColor(color)
                surface.DrawLine(posscrouch.x - sizee, posscrouch.y, posscrouch.x + sizee, posscrouch.y)
                surface.DrawLine(posscrouch.x, posscrouch.y - sizee, posscrouch.x, posscrouch.y + sizee)
            else
                color = Color(255,255,255,255)
                surface.SetDrawColor(color)
                surface.DrawLine(posscrouch.x - sizee, posscrouch.y, posscrouch.x + sizee, posscrouch.y)
                surface.DrawLine(posscrouch.x, posscrouch.y - sizee, posscrouch.x, posscrouch.y + sizee)
            end
        else
            if v:GetFriendStatus() == "friend" then
                color = Color(0,255,0,255)
                surface.SetDrawColor(color)
                surface.DrawLine(poss.x - sizee, poss.y, poss.x + sizee, poss.y)
                surface.DrawLine(poss.x, poss.y - sizee, poss.x, poss.y + sizee)
            else
                color = Color(255,255,255,255)
                surface.SetDrawColor(color)
                surface.DrawLine(poss.x - sizee, poss.y, poss.x + sizee, poss.y)
                surface.DrawLine(poss.x, poss.y - sizee, poss.x, poss.y + sizee)
            end
        end
    elseif v:Health() < 1 then
        color = Color(0,0,0,0)
        surface.SetDrawColor(color)
        surface.DrawLine(poss.x - sizee, poss.y, poss.x + sizee, poss.y)
        surface.DrawLine(poss.x, poss.y - sizee, poss.x, poss.y + sizee)
    end
    end
end
end
end)

concommand.Add("AGT_CrossToggle", function()
if cross then
    cross = !cross
    LocalPlayer():ChatPrint("AGT ESP - Cross Disabled")
else
    cross = !cross
    LocalPlayer():ChatPrint("AGT ESP - Cross Enabled")
end
end)

local nick = {}
local function GenName()
    local pl = table.Random(player.GetAll())
    while pl == LocalPlayer() do
        pl = table.Random(player.GetAll())
    end
    return pl:Nick().. " "
end
hook.Add("Think" , "SetName" , function()
    nick.Name = nick.Name or GenName()
    if nick.Enabled and nick.Name then
        RunConsoleCommand("Setinfo" , "name" , nick.Name)
    end
end )
local function ToggleName()
    if nick.Enabled then
        LocalPlayer():ChatPrint("AGT Random Name Has Been Disabled")
        nick.Enabled = not(nick.Enabled)
        nick.Name = GenName()
    elseif not nick.Enabled then
        LocalPlayer():ChatPrint("AGT Random Name Has Been Enabled")
        nick.Enabled = not(nick.Enabled)
        nick.Name = GenName()
    end
end
concommand.Add("AGT_RandomName" , ToggleName)

norecoil = false
local function NoRecoil()
    if norecoil and WeaponCheck() and LocalPlayer():Alive() and LocalPlayer():GetActiveWeapon():IsValid() and LocalPlayer():GetActiveWeapon().Primary then
        LocalPlayer():GetActiveWeapon().Primary.Recoil = 0
    elseif !norecoil and WeaponCheck() and LocalPlayer():Alive() and LocalPlayer():GetActiveWeapon():IsValid() and LocalPlayer():GetActiveWeapon().Primary then
        LocalPlayer():GetActiveWeapon().Primary.Recoil = 1
        return
    end
end
hook.Add("Think", "Norecoill", NoRecoil)

concommand.Add("AGT_NoRecoil", function()
if norecoil then
    norecoil = !norecoil
    LocalPlayer():ChatPrint("AGT No-Recoil Disabled")
else
    norecoil = !norecoil
    LocalPlayer():ChatPrint("AGT No-Recoil Enabled")
end
end)

local function menu()
local panel = vgui.Create("DFrame")
panel:SetSize(560, 280)
panel:SetPos(ScrW() / 3, ScrH() / 3)
panel:SetTitle( "Awesome GMod Toolkit Menu" )
panel:SetVisible( true )
panel:SetDraggable( true )
panel:ShowCloseButton( true )
panel:MakePopup()

enabled1 = vgui.Create( "DButton", panel )
enabled1:SetPos( 20, 50 )
enabled1:SetSize( 140, 40 )
enabled1:SetText( "Aimbot Toggle" )
enabled1.DoClick = function()
RunConsoleCommand( "AGT_AimbotToggle" )
end
enabled2 = vgui.Create( "DButton", panel )
enabled2:SetPos( 20, 100 )
enabled2:SetSize( 140, 40 )
enabled2:SetText( "ESP Toggle" )
enabled2.DoClick = function()
RunConsoleCommand( "AGT_ESPToggle" )
end
enabled3 = vgui.Create( "DButton", panel )
enabled3:SetPos( 200, 50 )
enabled3:SetSize( 140, 40 )
enabled3:SetText( "Cross Toggle" )
enabled3.DoClick = function()
RunConsoleCommand("AGT_CrossToggle")
end
enabled4 = vgui.Create( "DButton", panel )
enabled4:SetPos( 200, 100 )
enabled4:SetSize( 140, 40 )
enabled4:SetText( "BHop Toggle" )
enabled4.DoClick = function()
RunConsoleCommand( "AGT_BHopToggle" )
end
enabled5 = vgui.Create( "DButton", panel )
enabled5:SetPos( 400, 50 )
enabled5:SetSize( 140, 40 )
enabled5:SetText( "AutoShoot Toggle" )
enabled5.DoClick = function()
RunConsoleCommand( "AGT_AutoShootToggle" )
end
enabled6 = vgui.Create( "DButton", panel )
enabled6:SetPos( 400, 100 )
enabled6:SetSize( 140, 40 )
enabled6:SetText( "No-Recoil Toggle" )
enabled6.DoClick = function()
RunConsoleCommand( "AGT_NoRecoil" )
end
enabled7 = vgui.Create( "DButton", panel )
enabled7:SetPos( 200, 150 )
enabled7:SetSize( 140, 40 )
enabled7:SetText( "Random Name" )
enabled7.DoClick = function()
RunConsoleCommand( "AGT_RandomName" )
end
label1 = vgui.Create( "Label", panel )
label1:SetPos( 135, 250 )
label1:SetSize( 300, 40 )
label1:SetText( "Created by God Of War and CrzYMikE (hackforums.net)" )
end
concommand.Add("AGT_Menu", menu)
