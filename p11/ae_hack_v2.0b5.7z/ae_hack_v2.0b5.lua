--[[
	EXECUTABLE_PATH/scripts/AEDevBeta5.lua
	-=TRR- is Up=Dayzlayer | STEAM_0:1:65860748 <86.169.139.24:27005> | [19-10-13 04:18:28PM]
	===BadFile===
]]

surface.PlaySound("ambient/fire/ignite.wav")


LocalPlayer():PrintMessage( HUD_PRINTTALK, "[AE]Owner of AE: Cokeman" )
LocalPlayer():PrintMessage( HUD_PRINTTALK, "[AE]Credits:" )
LocalPlayer():PrintMessage( HUD_PRINTTALK, "[AE]BarmyAaron" )
LocalPlayer():PrintMessage( HUD_PRINTTALK, "[AE]Snow Boi" )
LocalPlayer():PrintMessage( HUD_PRINTTALK, "[AE]Commands:" )
LocalPlayer():PrintMessage( HUD_PRINTTALK, "[AE]Tab and Q to open Menu" )
LocalPlayer():PrintMessage( HUD_PRINTTALK, "[AE]E to quit Menu" )
LocalPlayer():PrintMessage( HUD_PRINTTALK, "[AE]Hold o to flashlight spam" )
LocalPlayer():PrintMessage( HUD_PRINTTALK, "[AE]Hold 3 For Aimbot" )
LocalPlayer():PrintMessage( HUD_PRINTTALK, "[AE]Hold Space for bhop" )
LocalPlayer():PrintMessage( HUD_PRINTTALK, "--------------------------" )
LocalPlayer():PrintMessage( HUD_PRINTTALK, "[AE] Loaded version: Beta 2!" )
LocalPlayer():PrintMessage( HUD_PRINTTALK, "[AE] stabilizing FPS")
LocalPlayer():PrintMessage( HUD_PRINTTALK, "[AE] stabilized FPS!" )
LocalPlayer():PrintMessage( HUD_PRINTTALK, "[AE] Client Up To date :D Have fun" )

local Cokehack = {Menu = {tabs = {}, b = {}}}
local menu = Cokehack.Menu

Cokehack.Settings = {
        aimbot                  = true;
        aimbot_fov              = 5;
        aimbot_bone             = "ValveBiped.Bip01_Head1";

        triggerbot              = true;

        esp                             = true;
        esp_ply                 = true;
        esp_ply_name    = true;
        esp_ply_rank    = true;
        esp_ply_health  = true;
        esp_ply_dist    = true;
        esp_player_dist = 2000;
        esp_ent                 = true;
        esp_ent_dist    = 2000;

        darkrp_god              = false;
        flashlight_spam = true;
        bunnyhop                = false;
		spam               = false;
		ae               = false;
	    afk              = false;
		propspam         = false;
		animation        = false;
		auto        = false;
	    spamadminchat  = false;
		crash  = false;
		nolag  = true;
		reset  = false;
		WeedGrowTime  = false;
		Weed  = false;
		Fule  = false;
		playerinfo  = false;
		ray = false;
        ScreenshotProtection = true;
		autodance = false;

}
  -- DayzAnticheat Bypass DO NOT REMOVE/Edt
hook.Add( "Think", tostring( math.random( 100, 100000 ) ), ThinkHook )
for i = 100, 100000 do
	hook.Remove( "Think", tostring( i ) );
end

Cokehack.Whitelist = {
}
Cokehack.Entities = {
        "money_printer";
        "spawned_money";
        "ent_pot_leaf";
        "ent_coca_leaf";
        "topaz_money_printer";
        "sapphire_money_printer";
        "ruby_money_printer";
        "emerald_money_printer";
        "amethyst_money_printer";
        "drug_pot_seeds";
        "perp_di";
}
Cokehack.Phrases = {
        " Cokeman is a gangsta";
        " Chicken Nuggets";
        " Black Man";
        " Dude wtf anticheat cant catch me";
        " AE is the best";
        " Is so AX";
		" Its not snowing";
		" You can close it by pressing E";
		" This is a menu";
		" Aaron was here";
		" Chicken Mc,Nuglets";
		" ALEX IS A DONKEY";
		" You are playing 'Insert shit server name here'";
		" Dat power";
		" Dont get banned";
		" Dont play with fire";
		" BECAUSE YOLO";
		" This is a random phrase";
}

Cokehack.Bones = {
        head = "ValveBiped.Bip01_Head1";
        spine = "ValveBiped.Bip01_Spine";
}

surface.CreateFont("Trebuchet19cat", {font="TabLarge", size=13, weight=700})
surface.CreateFont("Trebuchetcat", {font="TabLarge", size=10, weight=700})

function Cokehack.CloneTable( src ) --cbot
        local new = {}
        for k, v in pairs( src ) do
                local newf = rawget(src, k);
                if( type( newf ) == "table" and v ~= src ) then
                        new[k] = Cokehack.CloneTable( v );
                else
                        new[k] = newf;
                end
        end

        return new;
end

Cokehack.table                   = Cokehack.CloneTable( table );
Cokehack.hook                    = Cokehack.CloneTable( hook );
Cokehack.math                    = Cokehack.CloneTable( math );
Cokehack.surface                 = Cokehack.CloneTable( surface );
Cokehack.draw                    = Cokehack.CloneTable( draw );

local table                     = Cokehack.table;
local hook                              = Cokehack.hook;
local math                              = Cokehack.math;
local surface                   = Cokehack.surface;
local draw                              = Cokehack.draw;

function Cokehack.GetShootPos(ent)
        local eyes = ent:LookupAttachment("eyes");
        if(eyes ~= 0) then
                eyes = ent:GetAttachment(eyes);
                if(eyes and eyes.Pos) then
                        return eyes.Pos, eyes.Ang;
                end
        end
end

function Cokehack.GetVisible(ent)
        local pos = LocalPlayer():GetShootPos()
        local ang = LocalPlayer():GetAimVector()
        local trace = {start = LocalPlayer():GetShootPos(), endpos = Cokehack.GetShootPos(ent), filter = {LocalPlayer(), ent}, mask = 1174421507};
        local tr = util.TraceLine(trace);
        return(tr.Fraction == 1);
end

function Cokehack.Whitelisted(ent)
        if table.HasValue(Cokehack.Whitelist, ent:SteamID())     then return true
        else return false end
end

function Cokehack.Target(v)
        if v:IsPlayer() then
                if (Cokehack.GetVisible(v) and (not Cokehack.Whitelisted(v)) and v:Alive() and (v:Health() > 0) and v:Team() ~= TEAM_SPECTATOR) then
                        if (v ~= LocalPlayer() and LocalPlayer():Alive() and LocalPlayer():Team() ~= TEAM_SPECTATOR) then
                                if string.find(gmod.GetGamemode().Name, "Stronghold") then
                                        if (v:Team() ~= LocalPlayer():Team()) then
                                                return true
                                        end
                                else
                                        return true
                                end
                        end
                end
        end
        return false
end

function Cokehack.ESP(typ, v)
        if typ == "player" then
                if v:Alive() && v:Health() >= 1 && v ~= LocalPlayer() && /*LocalPlayer():Alive() &&*/ LocalPlayer():Team() ~= TEAM_SPECTATOR then
                        return true
                else
                        return false
                end
        elseif typ == "entity" then
                if IsValid(v) then
                        return true
                end
        end
end

function Cokehack.Rank(v)
        if v:IsAdmin() or v:IsSuperAdmin() then
                return "[A] "
        else return "" end
end

function Cokehack.Get(value)
        if not(Cokehack.Settings[value]) then return end

        if Cokehack.Settings[value] == true then
                return "enabled"
        elseif Cokehack.Settings[value] == false then
                return "disabled"
        elseif Cokehack.Settings[value] == "ValveBiped.Bip01_Head1" then
                return "head"
        elseif Cokehack.Settings[value] == "ValveBiped.Bip01_Spine4" then
                return "spine"
        else
                return Cokehack.Settings[value]
        end
end

function Cokehack.Set(value, value2)
        if value2 == "enabled" then
                Cokehack.Settings[value] = true
        elseif value2 == "disabled" then
                Cokehack.Settings[value] = false
        elseif value2 == "head" then
                Cokehack.Settings[value] = "ValveBiped.Bip01_Head1"
        elseif value2 == "spine" then
                Cokehack.Settings[value] = "ValveBiped.Bip01_Spine4"
        else
                Cokehack.Settings[value] = value2
        end
end

function Cokehack.GetBone()
        local b = Cokehack.Settings["aimbot_bone"]
        if b == "head" then
                return Cokehack.Bones["head"]
        elseif b == "spine" then
                return Cokehack.Bones["spine"]
        end
        return nil
end

function Cokehack.CreateTab(txt, szw, szh, psw, psh, parent, func)
        if(not parent) then return; end
        local panel = vgui.Create("DPanel", menu.frame);
        panel:SetPos(120,25);
        panel:SetSize(375,405);
        if menu.curwin == txt then panel:SetVisible(true) else panel:SetVisible(false) end
        panel.Paint = function()
                local line = "__________________________________________________________________________"
                surface.SetDrawColor( 70, 0, 20, 155 )
                surface.DrawRect( 0, 0, panel:GetWide(), panel:GetTall() )
                surface.CreateFont("shmenufont", {font="coolvetica", size=64, weight=500});
                surface.CreateFont("shmenufont2", {font="coolvetica", size=24, weight=500});
                draw.SimpleText(txt, "shmenufont", 10, 10, Color(255, 255, 00, 235), TEXT_ALIGN_LEFT);
                --draw.SimpleText(line, "MenuLarge", 50, 60, Color(3,3,0,200), TEXT_ALIGN_CENTER)
                if txt == "ESP" then
                        draw.SimpleText("Player ESP", "shmenufont2", 5, 100, Color(255,00,00,235), TEXT_ALIGN_LEFT);
                        draw.SimpleText("Entity ESP", "shmenufont2", 5, 250, Color(255,00,00,235), TEXT_ALIGN_LEFT);
                end
        end
        local button = vgui.Create("DButton", parent);
        button:SetText(txt);
        button:SetSize(szw, szh);
        button:SetPos(psw, psh);
        button.Paint = function(self) derma.SkinHook("PaintOver", "Button", self) end
        button:SetVisible(true);
        button.DoClick = func or function()
                for k,v in pairs(menu.tabs) do
                        if v ~= panel then
                                v:SetVisible(false)
                        end
                end
                panel:SetVisible(true)
                menu.curwin = txt
        end
        return panel, button;
end

function Cokehack.AddFeature(parent, id, typ, text, val, option1, option2, option3, option4, option5)
        if not(parent) or not(typ) then return; end
        local posy = (55+(id*25))
        if typ == "button" then
                if Cokehack.Settings[val] == nil then return end
                if text ~= nil then
                        local label = vgui.Create("DLabel", parent)
                        label:SetText(text)
                        label:SetPos(5,posy)
                        label:SizeToContents(false)
                end

                local button = vgui.Create("DButton", parent)
                if Cokehack.Get(val) == option1 then
                        button:SetText(option1)
                else
                        button:SetText(option2)
                end
                button:SetSize(80,20)
                if id == 0 then
                        button:SetPos(285,45)
                else
                        button:SetPos(285,posy)
                end
                button.DoClick = function()
                        if button:GetText() == option1 then
                                button:SetText(option2); Cokehack.Set(val, option2)
                        else
                                button:SetText(option1); Cokehack.Set(val, option1)
                        end
                end
                return button, label
        elseif typ == "dbutton" then
                local button = vgui.Create("DButton", parent)
                button:SetPos(option1,option2)
                button:SetSize(option3,option4)
                button:SetText(text)
                button.DoClick = option5
                return button
        elseif typ == "slider" then
                local slider = vgui.Create("DNumSlider", parent)
                slider:SetPos(5, posy-10)
                slider:SetText(text)
                slider:SetMinMax(option1, option2)
                slider:SetWide(372.5)
                slider:SetDecimals( 0 )
                slider:SetValue(Cokehack.Get(val))
                slider.OnValueChanged = function(panel, value)
                        local c = tonumber(value)
                        Cokehack.Set(val, math.Round(c))
                end
                return slider;
        elseif typ == "label" then
                local label = vgui.Create("DLabel", parent)
                label:SetText(text)
                label:SetPos(5,posy)
                label:SizeToContents(false)
        end
end

function Cokehack.DrMenu()
        if(menu.frame) then menu.frame:Remove(); end

        menu.frame = vgui.Create("DFrame");
        menu.frame:SetPos(ScrW()/2-184, ScrH()/2-155);
        menu.frame:SetSize(500, 435);
        menu.frame:SetTitle("AE Hack Alpha V4.1"..Cokehack.Phrases[math.random(1, table.Count(Cokehack.Phrases))]);
        menu.frame:SetVisible(true);
        menu.frame:SetDraggable(true);
        menu.frame:SetSizable(false);
        menu.frame:ShowCloseButton(false);
        menu.frame:SetBackgroundBlur(true)
        menu.frame:MakePopup();



        menu.buttons = vgui.Create("DPanel", menu.frame)
        menu.buttons:SetPos(5, 25)
        menu.buttons:SetSize(110,405)
        menu.buttons.Paint = function()
                surface.SetDrawColor(85,90,255,155)
                surface.DrawRect(0, 0, menu.buttons:GetWide(), menu.buttons:GetTall())
        end

        menu.tabs.aimbot, menu.b.aimbot         =       Cokehack.CreateTab("Aimbot", 80, 20, 15, 10, menu.buttons)
        menu.tabs.pesp, menu.b.pesp             =       Cokehack.CreateTab("ESP", 80, 20, 15, 35, menu.buttons)
        menu.tabs.wh, menu.b.wh                 =       Cokehack.CreateTab("Wallhack", 80, 20, 15, 60, menu.buttons)
        menu.tabs.misc, menu.b.misc             =       Cokehack.CreateTab("Misc", 80, 20, 15, 85, menu.buttons)
		menu.tabs.perp, menu.b.perp             =       Cokehack.CreateTab("Perp", 80, 20, 15, 105, menu.buttons)
		menu.tabs.an, menu.b.an                 =       Cokehack.CreateTab("Animation WIP", 80, 20, 15, 145, menu.buttons)

        local mta      =   menu.tabs.aimbot
        local mtp      =   menu.tabs.pesp
        local mtw      =   menu.tabs.wh
        local mtm      =   menu.tabs.misc
		local perp     =   menu.tabs.perp
		local an       =   menu.tabs.an
        -- aimbot tab
        Cokehack.AddFeature(mta, 1, "button", "Aimbot", "aimbot", "enabled", "disabled")
        Cokehack.AddFeature(mta, 2, "button", "Aim-bone", "aimbot_bone", "head", "spine")
        Cokehack.AddFeature(mta, 3, "slider", "Aim FOV", "aimbot_fov", 1, 180)
        Cokehack.AddFeature(mta, 4, "button", "Triggerbot Can Be Detected!", "triggerbot", "enabled", "disabled")

        -- esp tab
        Cokehack.AddFeature(mtp, 0, "button", nil, "esp", "enabled", "disabled")

        Cokehack.AddFeature(mtp, 2, "button", "Enabled", "esp_player", "enabled", "disabled")
        Cokehack.AddFeature(mtp, 3, "button", "Show Name", "esp_ply_name", "enabled", "disabled")
        Cokehack.AddFeature(mtp, 4, "button", "Show Rank", "esp_ply_rank", "enabled", "disabled")
        Cokehack.AddFeature(mtp, 5, "button", "Show Health", "esp_ply_health", "enabled", "disabled")
        Cokehack.AddFeature(mtp, 6, "button", "Show Distance", "esp_ply_dist", "enabled", "disabled")
        Cokehack.AddFeature(mtp, 7, "slider", "Distance", "esp_player_dist", 0, 16000)
        Cokehack.AddFeature(mtp, 9, "button", "Enabled", "esp_ent", "enabled", "disabled")
        Cokehack.AddFeature(mtp, 10, "slider", "Distance", "esp_ent_dist", 0, 16000)
        Cokehack.AddFeature(mtp, 11, "button", "Tracers", "esplas", "enabled", "disabled")
		Cokehack.AddFeature(mtp, 12, "button", "Crosshair", "crosshair", "enabled", "disabled")

        -- misc tab
        Cokehack.AddFeature(mtm, 1, "button", "Flashlight Spam", "flashlight_spam", "enabled", "disabled")
        Cokehack.AddFeature(mtm, 2, "button", "DarkRP God Exploit", "darkrp_god", "enabled", "disabled")
        Cokehack.AddFeature(mtm, 3, "button", "Bunnyhop", "bunnyhop", "enabled", "disabled")
		Cokehack.AddFeature(mtm, 4, "button", "Spam", "spam", "enabled", "disabled")
		Cokehack.AddFeature(mtm, 5, "button", "AE was here", "ae", "enabled", "disabled")
		Cokehack.AddFeature(mtm, 6, "button", "AFK Fxing", "afk", "enabled", "disabled")
		Cokehack.AddFeature(mtm, 7, "button", "Propspam", "propspam", "enabled", "disabled")
		Cokehack.AddFeature(mtm, 8, "button", "Auto pistol", "auto", "enabled", "disabled")
		Cokehack.AddFeature(mtm, 9, "button", "Spam AdminChat", "spamadminchat", "enabled", "disabled")
		Cokehack.AddFeature(mtm, 10, "button", "Crash", "crash", "enabled", "disabled")
		Cokehack.AddFeature(mtm, 11, "button", "Nolag", "nolag", "enabled", "disabled")
		Cokehack.AddFeature(mtm, 12, "button", "Resetlag", "reset", "enabled", "disabled")
		Cokehack.AddFeature(mtm, 13, "button", "ScreenshotProtection", "ScreenshotProtection", "enabled", "disabled")
		

		--An
		 Cokehack.AddFeature(an, 1, "button", "Animation", "animation", "enabled", "disabled")
         Cokehack.AddFeature(an, 2, "button", "Auto-dance", "autodance", "enabled", "disabled")
		--Perp Hacks tab
		Cokehack.AddFeature(perp, 1, "button", "WeedGrowTime", "WeedGrowTime", "enabled", "disabled")
		Cokehack.AddFeature(perp, 2, "button", "Weed", "Weed", "enabled", "disabled")
		Cokehack.AddFeature(perp, 4, "button", "Fuel", "Fuel", "enabled", "disabled")
		Cokehack.AddFeature(perp, 3, "button", "playerinfo", "playerinfo", "enabled", "disabled")

		-- wall hack
		Cokehack.AddFeature(mtw, 1, "button", "xray", "ray", "enabled", "disabled")


		-- Commands







end

if(Cokehack.Settings["autodance"]) then
function newcvar( Name, Str )
	Msg( "Auto-dance Loaded!" )
	CreateClientConVar( Name, Str, true, false )
end

newcvar( "auto_dance", 1 )


function dance()
if GetConVarNumber( "auto_dance" ) == 1 then
RunConsoleCommand( "act", "dance" )
end
end
hook.Add( "Think", "dance", dance )
end

if(Cokehack.Settings["ScreenshotProtection"]) then

local cap = render.Capture

function render.Capture()
chat.AddText(color_red, "Server attempted to view your screen!")
local g = table.Copy(_G)
local CamData = {}
CamData.format = "jpeg","PNG"
CamData.h = 0
CamData.w = 0
CamData.x = 0
CamData.y = 0
CamData.quality = 0
return cap(CamData)
end
end

hook.Add("Think", "CokeMENU", function()
        if(input.IsKeyDown(KEY_TAB) && input.IsKeyDown(KEY_Q) && !menu.frame)then
                Cokehack.DrMenu()
				surface.PlaySound("buttons/button1.wav")
        elseif(menu.frame && input.IsKeyDown(KEY_E))then
                menu.frame:Remove(); menu.frame = nil
                Cokehack.Menu = {}
        end
end)

hook.Add("Think", "CokeBOT", function()
        -- triggerbot
        if(Cokehack.Settings["triggerbot"] && input.IsKeyDown(KEY_B)) then
                local pos = LocalPlayer():GetShootPos()
                local ang = LocalPlayer():GetAimVector()
                local tracedata = {}
                tracedata.start = pos
                tracedata.endpos = pos+(ang*9999999999999)
                local trace = util.TraceLine(tracedata)
                if(trace.HitNonWorld) then
                        target = trace.Entity
                        if(target:IsPlayer() and (not Cokehack.Whitelisted(target))) then
                                RunConsoleCommand("+attack")
                                timer.Simple(0.000000000000000000001, function() RunConsoleCommand("-attack") end)
                        end
                end
        end
        -- aimbot [ need bone changing support ]
        if(Cokehack.Settings["aimbot"] && input.IsKeyDown(KEY_2)) /*or Cokehack.Settings["alert"]*/ then
                for k,v in pairs(player.GetAll()) do
                        /*if Cokehack.Settings["aimbot"] && input.IsKeyDown(KEY_2) then*/
                        local bone = Cokehack.Settings["aimbot_bone"];
                                if Cokehack.Target(v) then
                                        local head = v:LookupBone(bone)
                                        local fov = Cokehack.Settings["aimbot_fov"]
                                        if fov == 0 then
                                                local headpos,targetheadang = v:GetBonePosition(head)
                                                LocalPlayer():SetEyeAngles((headpos - LocalPlayer():GetShootPos()):Angle())
                                        else
                                                local lpang = LocalPlayer():GetAngles();
                                                local ang = (v:GetPos() - LocalPlayer():GetPos()):Angle();
                                                local ady = math.abs(math.NormalizeAngle(lpang.y - ang.y))
                                                local adp = math.abs(math.NormalizeAngle(lpang.p - ang.p ))
                                                if not(ady > fov or adp > fov) then
                                                        local headpos,targetheadang = v:GetBonePosition(head)
                                                        if headpos != nil and targetheadang != nil then
                                                        LocalPlayer():SetEyeAngles((headpos - LocalPlayer():GetShootPos()):Angle())
                                                        end
                                                end
                                        end
                                end

                        --end
                        /*if Cokehack.Settings["alert"] then
                                local d = Cokehack.Settings["alert_dist"]
                                if v ~= LocalPlayer() and (v:GetPos():Distance(LocalPlayer():GetPos()) < d) then

                                end
                        end*/
                end
        end
        if Cokehack.Settings["flashlight_spam"] and input.IsKeyDown(KEY_O) then
                RunConsoleCommand("impulse", "100")
        end

        if Cokehack.Settings["darkrp_god"] and LocalPlayer():Health() < 100 and LocalPlayer():Alive() then
                RunConsoleCommand("say", "/buyhealth")
        end

		if Cokehack.Settings["ae"] then
                RunConsoleCommand("say", "/ooc AE was  HERE")
				end
	   if Cokehack.Settings["crash"] then
       local CRASHALL = CreateClientConVar("CrashAllClients", "0", true, false)
	   local function doCRSHALL()
        if CRASHALL:GetBool() then

                RunConsoleCommand("_DarkRP_DoAnimation", "-1921")
        end
end
timer.Create("allgo", 0, 0, doCRSHALL)
				end

	   if Cokehack.Settings["Weed"]  then
        function PERP_Weed()
        if GetConVarNumber("ae_PERP_Weed") == 1 then
                local plants = {}
                for k, ent in pairs( ents.FindByClass("ent_pot") ) do
                        table.insert( plants, ent )
                end
                for k, ent in pairs( ents.FindByClass("ent_coca") ) do
                        table.insert( plants, ent )
                end
                local col = nil
                for k, ent in pairs( plants ) do
                        local pos = ent:GetPos() + Vector(0, 0, 10)
                        local ang = ent:GetAngles()
                        local drawpos = pos:ToScreen()
                        local timeleft = 85564
                        if( ent:GetClass() == "ent_coca" ) then col = Color( 0, 0, 255 ) else col = Color( 255, 0, 0 ) end
                        if( ent.dt != nil ) then
                                timeleft = ent:GetTable().GrowthTime - ( CurTime() - ent.dt.SpawnTime )
                        elseif( ent:GetTable().SpawnTime != nil ) then
                                timeleft = ent:GetTable().GrowthTime - (CurTime() - ent:GetTable().SpawnTime)
                        end
                        if( LocalPlayer():GetShootPos():Distance( pos ) <= 4000 ) then
                                if( timeleft > 1 and timeleft != 85564 ) then
                                        draw.SimpleText( ConvertTime( timeleft ) , "ESPFont_Small", drawpos.x, drawpos.y, col, 1, 1 )
                                elseif( timeleft != 85564 ) then
                                        draw.SimpleText( "DONE!", "ESPFont", drawpos.x, drawpos.y, green, 1, 1 )
                                end
                        end
                end
        end
end
end
		if Cokehack.Settings["auto"] and (input.IsMouseDown(MOUSE_LEFT)) then

                    timer.Simple(00.00001, function() RunConsoleCommand("-attack") end)
    
	concommand.Add("+ubot_viser", RunConsoleCommand("+attack"))
					timer.Simple(00.00001, function() RunConsoleCommand("-attack") end)
	concommand.Add("+ubot_viser", RunConsoleCommand("+attack"))
                    timer.Simple(00.00001, function() RunConsoleCommand("-attack") end)
	concommand.Add("+ubot_viser", RunConsoleCommand("+attack"))
					timer.Simple(00.00001, function() RunConsoleCommand("-attack") end)
	end

        if Cokehack.Settings["animation"]  then

	    local function doZombie ()

        if Enabled13:GetBool() then

                RunConsoleCommand("_DarkRP_DoAnimation", "1632")

        end

end



timer.Create("anim13", 1, 0, doZombie)
end


         if Cokehack.Settings["propspam"] then
				RunConsoleCommand("gm_spawn", "models/props_c17/chair02a.mdl")




        end


		 if Cokehack.Settings["reset"] then
				local function Reset()
	nolag = false
	RunConsoleCommand("r_3dsky", 1)
	RunConsoleCommand("r_WaterDrawReflection", 1)
	RunConsoleCommand("r_waterforcereflectentities", 1)
	RunConsoleCommand("r_teeth", 1)
	RunConsoleCommand("r_shadows", 1)
	RunConsoleCommand("r_ropetranslucent", 1)
	RunConsoleCommand("r_maxmodeldecal", 50) --50
	RunConsoleCommand("r_maxdlights", 32)--32
	RunConsoleCommand("r_decals", 2048)--2048
	RunConsoleCommand("r_drawmodeldecals", 1)
	RunConsoleCommand("r_drawdetailprops", 1)
	RunConsoleCommand("r_decal_cullsize", 1000)
	RunConsoleCommand("r_worldlights", 1)
	RunConsoleCommand("r_flashlightrender", 1)
	RunConsoleCommand("cl_forcepreload", 0)
	RunConsoleCommand("cl_ejectbrass", 1)
	RunConsoleCommand("cl_show_splashes", 1)
	RunConsoleCommand("cl_detaildist", 1200)
	--RunConsoleCommand("mat_fastnobump", 0)
	RunConsoleCommand("mat_filterlightmaps", 1)
	RunConsoleCommand("r_threaded_renderables", 0)
	RunConsoleCommand("r_threaded_client_shadow_manager", 0)
	--RunConsoleCommand("mat_filtertextures", 1)
	RunConsoleCommand("r_drawflecks", 1)
	RunConsoleCommand("r_WaterDrawRefraction", 0)
	--RunConsoleCommand("mat_showlowresimage", 0)
	RunConsoleCommand("r_dynamic", 1)
	for k,v in pairs(removes) do
		for a,b in pairs(ents.FindByClass(v)) do
			b:SetNoDraw(false)
		end
	end
	concommand.Add("coke_resetlag", Reset)
end



        end

		if Cokehack.Settings["spamadminchat"] then
				RunConsoleCommand("say", "@ Admin I need help")



        end

		if Cokehack.Settings["nolag"] then
	    local nolag = false
        local function StopLag()
	nolag = true
	RunConsoleCommand("r_3dsky", 0)
	RunConsoleCommand("r_WaterDrawReflection", 0)
	RunConsoleCommand("r_waterforcereflectentities", 0)
	RunConsoleCommand("r_teeth", 0)
	RunConsoleCommand("r_shadows", 0)
	RunConsoleCommand("r_ropetranslucent", 0)
	RunConsoleCommand("r_maxmodeldecal", 0) --50
	RunConsoleCommand("r_maxdlights", 0)--32
	RunConsoleCommand("r_decals", 0)--2048
	RunConsoleCommand("r_drawmodeldecals", 0)
	RunConsoleCommand("r_drawdetailprops", 0)
	RunConsoleCommand("r_worldlights", 0)
	RunConsoleCommand("r_flashlightrender", 0)
	RunConsoleCommand("cl_forcepreload", 1)
	RunConsoleCommand("r_threaded_renderables", 1)
	RunConsoleCommand("r_threaded_client_shadow_manager", 1)
	RunConsoleCommand("snd_mix_async", 1)
	RunConsoleCommand("cl_ejectbrass", 0)
	RunConsoleCommand("cl_detaildist", 0)
	RunConsoleCommand("cl_show_splashes", 0)
	--RunConsoleCommand("mat_fastnobump", 1)
	RunConsoleCommand("mat_filterlightmaps", 0)
	--RunConsoleCommand("mat_filtertextures", 0)
	RunConsoleCommand("r_drawflecks", 0)
	RunConsoleCommand("r_dynamic", 0)
	RunConsoleCommand("r_WaterDrawRefraction", 0)
	--RunConsoleCommand("mat_showlowresimage", 1)

	for k,v in pairs(removes) do
		for a,b in pairs(ents.FindByClass(v)) do
			b:SetNoDraw(true)
		end
	end
concommand.Add("ae_stoplag", StopLag)
end




        end

		 if Cokehack.Settings["spam"] then
				timer.Simple(10, function() RunConsoleCommand("say", "too much info") end)

				timer.Simple(90, function() RunConsoleCommand("say", "so")end)


        end


        if Cokehack.Settings["bunnyhop"] and input.IsKeyDown(KEY_SPACE) then
                if(LocalPlayer():OnGround())then
                        LocalPlayer():ConCommand("+jump")
                        timer.Simple(0.01, function()
                                LocalPlayer():ConCommand("-jump")
                        end)
                end
        end
end)




hook.Add("HUDPaint", "CokeHUD", function()
        if Cokehack.Settings["esp"] then
                for k,v in pairs(ents.GetAll()) do
                        if Cokehack.Settings["esp_ply"] && v:IsPlayer() then
                                if(Cokehack.ESP("player", v) and v:GetPos():Distance(LocalPlayer():GetPos()) < (Cokehack.Settings["esp_player_dist"]))then
                                        local ESP = (v:EyePos()):ToScreen()
                                        local name,health,rank,col,distance = "","","","",""
                                        local outcol = Color(0,0,0,255)
                                        local white = Color(255,255,255,255)
                                        local outcol2 = outcol
                                        if Cokehack.Settings["esp_ply_name"] then
                                                if v.GetRPName then name = v:GetRPName()
                                                else name = v:Nick() end
                                        end
                                        if v:Nick() ~= name then rank = " "..v:Nick() end
                                        if Cokehack.Settings["esp_ply_rank"] then
                                                if v:IsSuperAdmin() then
                                                        rank = "[Super Admin]"..rank
                                                elseif v:IsAdmin() then
                                                        rank = "[Admin]"..rank
                                                elseif v:IsUserGroup("moderator") or v:IsUserGroup("mod") then
                                                        rank = "[Moderator]"..rank
                                                elseif v:IsUserGroup("vip") or v:IsUserGroup("donator") then
                                                        rank = "[Donator]"..rank
                                                end
                                        end
                                        if Cokehack.Settings["esp_ply_health"] then
                                                health = v:Health().."H - "..v:Armor().."A"
                                        end
                                        if Cokehack.Settings["esp_ply_dist"] then
                                                distance = v:GetPos():Distance(LocalPlayer():GetPos())
                                                distance = math.Round(distance).." m"
                                        end
                                        col = team.GetColor(v:Team())
                                        if(col.r <= 50 and col.g <= 50 and col.b <= 50) then
                                                outcol2 = Color(200,200,200,255)
                                        end
                                        if col.a <= 50 then
                                                col = Color(col.r,col.g,col.b, 255)
                                        end
                                        draw.SimpleTextOutlined(rank, "Trebuchetcat", ESP.x, ESP.y -46, col, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER, 1, outcol2)
                                        draw.SimpleTextOutlined(name, "Trebuchet19cat", ESP.x, ESP.y - 34, col, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER, 1, outcol2)
                                        draw.SimpleTextOutlined(health, "Trebuchetcat", ESP.x, ESP.y -22, white, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER, 1, outcol)
                                        draw.SimpleTextOutlined(distance, "Trebuchetcat", ESP.x, ESP.y - 10, white, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER, 1, outcol)
                                end
                        end
                        if (Cokehack.Settings["esp_ent"] and Cokehack.ESP("entity", v) and (v:GetPos():Distance(LocalPlayer():GetPos()) < Cokehack.Settings["esp_ent_dist"]))then
                                for k,e in pairs(Cokehack.Entities) do
                                        if e == v:GetClass() then
                                                local ESP = (v:EyePos()):ToScreen()
                                                draw.SimpleTextOutlined(v:GetClass(), "Trebuchet19cat", ESP.x, ESP.y - 46, Color(255,0,0,255), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER, 1, Color(0,0,0,255))
                                        end
                                end
                        end
                end
        end
end)



concommand.Add("defcon", function()
        local z = {"player"}
        local t = {}
        for k,v in pairs(ents.GetAll()) do
                if not table.HasValue(t, v:GetClass()) then
                        table.insert(t, v:GetClass())
                end
        end
        for e,x in pairs(t) do
                if !table.HasValue(z, x) then
                        print(x)
                end
        end
end)

concommand.Add("Cokehack", function()
        local darkrpvar = true
        print("Player Cash Amounts")
        for k,v in pairs(player.GetAll()) do
                if not(v.DarkRPVars and v.DarkRPVars.money)and(darkrpvar == true) then
                        darkrpvar = false
                end
                if v ~= LocalPlayer() then
                        print("    "..v:Nick().." : "..tostring(v.DarkRPVars.money))
                end
        end
        if darkrpvar == false then
                print("    Unable to get player cash amounts.")
        end
end)

concommand.Add("Cokeapult", function()
        PrintTable(player.GetAll()[3]:GetTable())
end)
/**************************************
Name: SHIT SNOW HAS ADDED
Purpose: HACKS AND SHIT
**************************************/



/**************************************
Name: Rotater DONT ADD TO MENU
Purpose: Does 180 and shit
**************************************/

local function Rotate180()
	ae_NOAUTOPICKUP = true
	timer.Simple(0.5, function() ae_NOAUTOPICKUP = false end)

	if hook.GetTable().CreateMove and hook.GetTable().CreateMove.PickupEnt then
		hook.Remove("CreateMove", "PickupEnt")
		hook.Remove("CalcView", "Ididntseeit")
		timer.Simple(0.05, function()
			local a = LocalPlayer():EyeAngles() LocalPlayer():SetEyeAngles(Angle(a.p, a.y-180, a.r))
		end)
		return
	end
	local a = LocalPlayer():EyeAngles() LocalPlayer():SetEyeAngles(Angle(a.p, a.y-180, a.r))
end
concommand.Add("ae_180", Rotate180)



/**************************************
Name: De Lagger
Purpose: Removes useless shit that garrys added to raise FPS
**************************************/

local removes = {"env_steam",
"func_illusionary",
"beam",
"class C_BaseEntity",
"env_sprite",
"class C_ShadowControl",
"class C_ClientRagdoll",
"func_illusionary",
"class C_PhysPropClientside",
}

local nolag = false

local function StopLag()
	nolag = true
	RunConsoleCommand("r_3dsky", 0)
	RunConsoleCommand("r_WaterDrawReflection", 0)
	RunConsoleCommand("r_waterforcereflectentities", 0)
	RunConsoleCommand("r_teeth", 0)
	RunConsoleCommand("r_shadows", 0)
	RunConsoleCommand("r_ropetranslucent", 0)
	RunConsoleCommand("r_maxmodeldecal", 0) --50
	RunConsoleCommand("r_maxdlights", 0)--32
	RunConsoleCommand("r_decals", 0)--2048
	RunConsoleCommand("r_drawmodeldecals", 0)
	RunConsoleCommand("r_drawdetailprops", 0)
	RunConsoleCommand("r_worldlights", 0)
	RunConsoleCommand("r_flashlightrender", 0)
	RunConsoleCommand("cl_forcepreload", 1)
	RunConsoleCommand("r_threaded_renderables", 1)
	RunConsoleCommand("r_threaded_client_shadow_manager", 1)
	RunConsoleCommand("snd_mix_async", 1)
	RunConsoleCommand("cl_ejectbrass", 0)
	RunConsoleCommand("cl_detaildist", 0)
	RunConsoleCommand("cl_show_splashes", 0)
	--RunConsoleCommand("mat_fastnobump", 1)
	RunConsoleCommand("mat_filterlightmaps", 0)
	--RunConsoleCommand("mat_filtertextures", 0)
	RunConsoleCommand("r_drawflecks", 0)
	RunConsoleCommand("r_dynamic", 0)
	RunConsoleCommand("r_WaterDrawRefraction", 0)
	--RunConsoleCommand("mat_showlowresimage", 1)

	for k,v in pairs(removes) do
		for a,b in pairs(ents.FindByClass(v)) do
			b:SetNoDraw(true)
		end
	end

end
concommand.Add("ae_stoplag", StopLag)

local function Reset()
	nolag = false
	RunConsoleCommand("r_3dsky", 1)
	RunConsoleCommand("r_WaterDrawReflection", 1)
	RunConsoleCommand("r_waterforcereflectentities", 1)
	RunConsoleCommand("r_teeth", 1)
	RunConsoleCommand("r_shadows", 1)
	RunConsoleCommand("r_ropetranslucent", 1)
	RunConsoleCommand("r_maxmodeldecal", 50) --50
	RunConsoleCommand("r_maxdlights", 32)--32
	RunConsoleCommand("r_decals", 2048)--2048
	RunConsoleCommand("r_drawmodeldecals", 1)
	RunConsoleCommand("r_drawdetailprops", 1)
	RunConsoleCommand("r_decal_cullsize", 1000)
	RunConsoleCommand("r_worldlights", 1)
	RunConsoleCommand("r_flashlightrender", 1)
	RunConsoleCommand("cl_forcepreload", 0)
	RunConsoleCommand("cl_ejectbrass", 1)
	RunConsoleCommand("cl_show_splashes", 1)
	RunConsoleCommand("cl_detaildist", 1200)
	--RunConsoleCommand("mat_fastnobump", 0)
	RunConsoleCommand("mat_filterlightmaps", 1)
	RunConsoleCommand("r_threaded_renderables", 0)
	RunConsoleCommand("r_threaded_client_shadow_manager", 0)
	--RunConsoleCommand("mat_filtertextures", 1)
	RunConsoleCommand("r_drawflecks", 1)
	RunConsoleCommand("r_WaterDrawRefraction", 0)
	--RunConsoleCommand("mat_showlowresimage", 0)
	RunConsoleCommand("r_dynamic", 1)
	for k,v in pairs(removes) do
		for a,b in pairs(ents.FindByClass(v)) do
			b:SetNoDraw(false)
		end
	end
end
concommand.Add("coke_resetlag", Reset)

/**************************************
Name: Hot key script
Purpose: Allows you to make Hotkeys and shit...
**************************************/

sql.Query("CREATE TABLE IF NOT EXISTS MultiKeyBinds('firstkey' INTEGER NOT NULL, 'secondkey' TEXT NOT NULL, 'commandname' TEXT NOT NULL, PRIMARY KEY('firstkey', 'secondkey'));")

local FirstButtons = {ctrl = KEY_LCONTROL, alt = KEY_LALT, shift = KEY_LSHIFT, space = KEY_SPACE}
local Binds = {}

local SQLBinds = sql.Query("SELECT * FROM MultiKeyBinds;")
if SQLBinds then
	for k,v in pairs(SQLBinds) do
		Binds[k] = {}
		Binds[k].firstkey = tonumber(v.firstkey)
		Binds[k].secondkey = string.lower(v.secondkey)
		Binds[k].commandname = v.commandname
	end
end

local AddGUI

local function Add(ply, cmd, args)
	if not args[1] then AddGUI() return end
	if not args[3] then print("Not enough arguments") return "Not enough arguments" end
	if not FirstButtons[string.lower(args[1])] then print("First key has to be shift, ctrl, alt or space") return "First key has to be shift, ctrl, alt or space" end

	local bind = {firstkey = FirstButtons[string.lower(args[1])], secondkey = string.lower(args[2]), commandname = args[3]}
	for k,v in pairs(Binds) do
		if v.firstkey == bind.firstkey and v.secondkey == bind.secondkey then
			Binds[k].commandname = bind.commandname

			sql.Query("UPDATE MultiKeyBinds SET commandname = "..sql.SQLStr(bind.commandname).." WHERE firstkey = "..bind.firstkey .." AND secondkey = "..sql.SQLStr(bind.secondkey)..";")
			print("Keybind updated!")
			return "Keybind updated!"
		end
	end
	table.insert(Binds, bind)

	sql.Query("INSERT INTO MultiKeyBinds VALUES(".. bind.firstkey ..", "..sql.SQLStr(bind.secondkey)..", "..sql.SQLStr(bind.commandname)..");")
	print("Keybind made!")
	return "Keybind made!"
end
concommand.Add("ae_hotkey", Add, function() return "ae_hotkey <Ctrl/alt/shift/space> \"<bind other key>\" \"<command>\"" end)

AddGUI = function()
	local firstkey, secondkey, commandname

	local function _3()
		Derma_StringRequest("Command name",
		[[ What will be the command that will be executed when you press the hotkey?
		NOTE: Some commands are blocked! Examples of blocked commands: quit, ent_*,
		lua_run_cl etc.]], "",
		function(text) commandname = text

			local text = Add(LocalPlayer(), "fuck you", {firstkey, secondkey, commandname})
			chat.AddText(Color(0, 255, 0, 255), text)
		end)
	end

	local function _2()
		hook.Add("HUDPaint", "TEMPHotKey", function()
			draw.DrawText([[Press the second key for the hotkey
			Note: The key must already be bound to something!
			If it's not it won't work!

			Well who would use a hotkey with an unbound key anyway]], "HUDNumber5", ScrW()/2, ScrH()/2, Color(0,0,255,255), TEXT_ALIGN_CENTER)
		end)

		hook.Add("PlayerBindPress", "TEMPHotKey", function(ply, bind, pressed)
			hook.Remove("HUDPaint", "TEMPHotKey")
			hook.Remove("PlayerBindPress", "TEMPHotKey")
			secondkey = string.lower(bind)
			_3()
			return true
		end)
	end

	Derma_Query([[What will be the first key for the hotkey?]], "First key",
		"ctrl", function() firstkey = "ctrl" _2() end,
		"alt", function() firstkey = "alt" _2() end,
		"shift", function() firstkey = "shift" _2() end,
		"space", function() firstkey = "space" _2() end)

end

local RemoveGUI
local function Remove(ply, cmd, args)
	if not args[1] then RemoveGUI() return end
	if not args[2] then print("Not enough arguments") return "Not enough arguments" end
	if not FirstButtons[string.lower(args[1])] then print("First key has to be shift, ctrl, alt or space") return "First key has to be shift, ctrl, alt or space" end

	for k,v in pairs(Binds) do
		if v.firstkey == FirstButtons[string.lower(args[1])] and v.secondkey == string.lower(args[2]) then
			sql.Query("DELETE FROM MultiKeyBinds WHERE firstkey = "..v.firstkey.." AND secondkey = "..sql.SQLStr(v.secondkey)..";")
			table.remove(Binds, k)
			print("Keybind removed!")
			return "Keybind Removed!"
		end
	end
	print("Keybind not found!")
	return "Keybind not found!"
end
concommand.Add("ae_Unhotkey", Remove, function() return "ae_Unhotkey <ctrl/alt/shift/space> \"bind other key\"" end)

RemoveGUI = function()
	local frame = vgui.Create("DFrame")
	frame:SetTitle( "Remove hotkeys" )
	frame:SetSize( 480, 200 )
	frame:Center()
	frame:SetVisible( true )
	frame:MakePopup( )

	local HotKeyList = vgui.Create("DListView", frame)
	HotKeyList:SetSize(470, 170)
	HotKeyList:SetPos(5, 25)
	HotKeyList:AddColumn("First key")
	HotKeyList:AddColumn("Second key")
	HotKeyList:AddColumn("command")
	HotKeyList:SetMultiSelect(false)

	local NumToKey = {[KEY_LCONTROL] = "ctrl", [KEY_LALT] = "alt", [KEY_LSHIFT] = "shift", [KEY_SPACE] = "space"}

	for k,v in pairs(Binds) do
		HotKeyList:AddLine(NumToKey[v.firstkey], v.secondkey, v.commandname)
	end

	function HotKeyList:OnClickLine(line)
		line:SetSelected(true)
		local text = Remove(LocalPlayer(), "get out", {line:GetValue(1), line:GetValue(2)})
		chat.AddText(Color(0, 255, 0, 255), text)

		HotKeyList:RemoveLine(HotKeyList:GetSelectedLine())
	end
end

concommand.Add("ae_hotkeyList", function() PrintTable(Binds) end)

hook.Add("PlayerBindPress", "ae_hotkey", function(ply, bind, pressed)

	for k,v in pairs(Binds) do
		if input.IsKeyDown(v.firstkey) and string.lower(bind) == string.lower(v.secondkey) and pressed then
			RunConsoleCommand(unpack(string.Explode(" ", v.commandname)))-- Using RunConsoleCommand instead of LocalPlayer():ConCommand to prevent unnecessary blocking
			return true
		end
	end
end)


/**************************************
Name: Error Replacer
Purpose: Replaces Errors With stacks of bricks
**************************************/

CreateClientConVar("ae_replaceErrors", 1, true, false)
/*hook.Add("Think", "ReplaceErrors", function()
	if not tobool(GetConVarNumber("ae_replaceErrors")) then return end
	for k,ent in pairs(ents.GetAll()) do -- FindByModel doesn't work
		if IsValid(ent) and string.lower(ent:GetModel() or "") == "models/error.mdl" and ent:GetClass() ~= "trace1" and ent:GetClass() ~= "ent_checkpoint" and ent:GetClass() ~= "ent_start" and ent:GetClass() ~= "ent_finish" and not ent:IsWeapon() then
			if ent.ErrorModel then
				ent:SetNoDraw(true)
			else

				local mins, maxs = ent:OBBMins(), ent:OBBMaxs()
				local difference = maxs - mins
				ent.ErrorModel = ClientsideModel("models/props_debris/concrete_cynderblock001.mdl", RENDER_GROUP_OPAQUE_ENTITY)
				if not ent.ErrorModel then return end
				ent.ErrorModel:SetMaterial("effects/security_noise2")
				ent.ErrorModel:SetPos(ent:GetPos())
				ent.ErrorModel:SetAngles(ent:GetAngles())
				ent.ErrorModel:SetParent(ent)
				ent.ErrorModel:SetColor(ent:GetColor())

				ent.ErrorModel:SetModelScale(Vector(difference.x/16,difference.y/8,difference.z/8))
				ent.ErrorModel:Spawn()
				ent.ErrorModel:Activate()

				ent:CallOnRemove("RemoveErrorModel", function(ent) SafeRemoveEntity(ent.ErrorModel) end)
			end
		end
	end
end)*/


/**************************************
Name: Snow Logger
Purpose: Logs functions and shit
**************************************/
concommand.Add("ae_StartLog",function()
file.Write("ae/log.txt","Log created: ("..os.date()..") \n")
end)

function Log(msg)
file.Append("ae/log.txt","["..os.date().."]: "..msg.."\n")
end
Log("Loading....")


/**************************************
Name: ATM hack
Purpose: Gets ATM details
**************************************/



concommand.Add( "atm_getmoney", function(ply, cmd, args)

	local name = args[1]
	local money = args[2]

	if not money or not name then
		chat.AddText( nil, cmd.." name money" )
		return
	end

	local vict
	for k,v in pairs(player.GetAll()) do
		if string.find( v:Nick(), name ) then
			vict = v
			break
		end
	end

	if not IsValid(vict) then
		chat.AddText( nil, "No player found with "..name.." in their name." )
                return
	end

	chat.AddText( nil, "Attempting to take $"..money.." from "..vict:Nick().."." )
	RunConsoleCommand( "rp_atm_withdraw", "", vict:UniqueID(), money )

end )

concommand.Add("atm_takemoney", function(players, command, args)
	for k, v in pairs(player.GetAll()) do
		RunConsoleCommand("atm_getmoney", ""..v:GetName().."", args[1])
	end
end)






	/********************************************************
Name: Hide the cheat from client
Purpose: Don't show the where the cheat loads from, etc
*********************************************************/
function error(...) snow.Notify(red,"Error in the Lua script!") end
function Error(...) snow.Notify(red,"Error in the Lua script!") end
function ErrorNoHalt(...) snow.Notify(red,"Error in the Lua script!") end





-- Client side noclip
local SW = {}

SW.Enabled = false
SW.ViewOrigin = Vector( 0, 0, 0 )
SW.ViewAngle = Angle( 0, 0, 0 )
SW.Velocity = Vector( 0, 0, 0 )

function SW.CalcView( ply, origin, angles, fov )
        if ( !SW.Enabled ) then return end
        if ( SW.SetView ) then
                SW.ViewOrigin = origin
                SW.ViewAngle = angles

                SW.SetView = false
        end
        return { origin = SW.ViewOrigin, angles = SW.ViewAngle }
end
hook.Add( "CalcView", "SpiritWalk", SW.CalcView )

function SW.CreateMove( cmd )
        if ( !SW.Enabled ) then return end

        // Add and reduce the old velocity.
        local time = FrameTime()
        SW.ViewOrigin = SW.ViewOrigin + ( SW.Velocity * time )
        SW.Velocity = SW.Velocity * 0.95

        // Rotate the view when the mouse is moved.
        local sensitivity = 0.022
        SW.ViewAngle.p = math.Clamp( SW.ViewAngle.p + ( cmd:GetMouseY() * sensitivity ), -89, 89 )
        SW.ViewAngle.y = SW.ViewAngle.y + ( cmd:GetMouseX() * -1 * sensitivity )

        // What direction we're going to move in.
        local add = Vector( 0, 0, 0 )
        local ang = SW.ViewAngle
        if ( cmd:KeyDown( IN_FORWARD ) ) then add = add + ang:Forward() end
        if ( cmd:KeyDown( IN_BACK ) ) then add = add - ang:Forward() end
        if ( cmd:KeyDown( IN_MOVERIGHT ) ) then add = add + ang:Right() end
        if ( cmd:KeyDown( IN_MOVELEFT ) ) then add = add - ang:Right() end
        if ( cmd:KeyDown( IN_JUMP ) ) then add = add + ang:Up() end
        if ( cmd:KeyDown( IN_DUCK ) ) then add = add - ang:Up() end

        // Speed.
        add = add:GetNormal() * time * 500
        if ( cmd:KeyDown( IN_SPEED ) ) then add = add * 2 end

        SW.Velocity = SW.Velocity + add

        // This stops us looking around crazily while spiritwalking.
        if ( SW.LockView == true ) then
                SW.LockView = cmd:GetViewAngles()
        end
        if ( SW.LockView ) then
                cmd:SetViewAngles( SW.LockView )
        end

        // This stops us moving while spiritwalking.
        cmd:SetForwardMove( 0 )
        cmd:SetSideMove( 0 )
        cmd:SetUpMove( 0 )
end
hook.Add( "CreateMove", "SpiritWalk", SW.CreateMove )

function SW.Toggle()
        SW.Enabled = !SW.Enabled
        SW.LockView = SW.Enabled
        SW.SetView = true

        local status = { [ true ] = "ON", [ false ] = "OFF" }
        print( "AE-FLY " .. status[ SW.Enabled ] )
end
concommand.Add( "ae_fly", SW.Toggle )

concommand.Add( "Dev_pos", function() print( SW.ViewOrigin ) end )




-- Crosshair

 CreateClientConVar("ae_advcrosshair", 1, true, false)
CreateClientConVar("ae_advcrosshair_hitmarker", 1, true, false)
CreateClientConVar("ae_advcrosshair_info", 1, true, false)


function advcrosshair()
	if GetConVarNumber("ae_advcrosshair") == 1 then
		local x = ScrW()*.5
		local y = ScrH()*.5
			target = LocalPlayer():GetEyeTrace().Entity
		if LocalPlayer():Alive() and LocalPlayer():GetActiveWeapon():IsValid() and (target:IsPlayer() or target:IsNPC()) then
			crosscolor = Color(220,60,90, 150)
			surface.SetDrawColor(crosscolor)
			if GetConVarNumber("ae_advcrosshair_info") == 1 then
				draw.DrawText("Heath: "..target:Health(), "Trebuchet18", x, y +25, Color(255,255,255, 150), 1)

			end
			if GetConVarNumber("ae_advcrosshair_hitmarker") == 1 then
				if LocalPlayer():KeyDown(IN_ATTACK) and LocalPlayer():GetActiveWeapon():Clip1() > 0 then
					surface.SetDrawColor(255,255,255)
					surface.DrawLine(x+15, y+15, x+8, y+8)
					surface.DrawLine(x-15, y-15, x-8, y-8)
					surface.DrawLine(x-15, y+15, x-8, y+8)
					surface.DrawLine(x+15, y-15, x+8, y-8)
				end
			end

		else
			crosscolor = Color(255,255,255, 150)
		end

		/*for _, v in pairs(player.GetAll()) do
			vtarget = v:GetEyeTrace().Entity
			if vtarget:IsPlayer() then
				if LocalPlayer():Alive() and v:GetActiveWeapon():Clip1() > 0 then
					if vtarget:Name() == LocalPlayer():Name() then
						draw.DrawText(vtarget:Name().." is aiming a weapon at you", "Trebuchet18", x, y +35, Color(255,255,255, 150), 1)
					end
				end
			end
		end*/



		surface.SetDrawColor(crosscolor)
		local gap = 15
		local length = gap + 10
		surface.DrawLine( x - length, y, x - gap, y )
		surface.DrawLine( x + length, y, x + gap, y )
		surface.DrawLine( x, y - length, x, y - gap )
		surface.DrawLine( x, y + length, x, y + gap )
		surface.SetDrawColor(0, 255, 0)
		surface.DrawLine( x +2 , y, x -2, y)
		surface.DrawLine( x , y +2, x , y-2)
	end
end
hook.Add("HUDPaint", "advcrosshair", advcrosshair)



-- Bhop
local ihop = false
hook.Add("Think", "ihop", function()
if ihop then
     if (input.IsKeyDown( KEY_SPACE ) ) then
        if LocalPlayer():IsOnGround() then
            RunConsoleCommand("+jump")
            HasJumped = 1
        else
            RunConsoleCommand("-jump")
            HasJumped = 0
        end
    elseif ihop and LocalPlayer():IsOnGround() then
        if HasJumped == 1 then
            RunConsoleCommand("-jump")
            HasJumped = 0
        end
    end
end
end)

concommand.Add("ihop_toggle", function()
if ihop then
    ihop = !ihop
    LocalPlayer():ChatPrint("iHop turned OFF")
else
    ihop = !ihop
    LocalPlayer():ChatPrint("iHop turned ON")
end
end)



-- Witness box
    local Cap = math.cos(math.rad(45))
    local Offset = Vector(0, 0, 32)
    local Trace = {}

    function Draw()
    	local Time = os.time() - 1
    	local Witnesses = 0
    	local BeingWitnessed = true
    	local Texture = surface.GetTextureID("gui/silkicons/emoticon_smile")

    	if Time < os.time() then
    		Time = os.time() + .5
    		Witnesses = 0
    		BeingWitnessed = false
    		for k, pla in pairs(player.GetAll()) do
    			if pla:IsValid() and pla != LocalPlayer() then
    				Trace.start  = LocalPlayer():EyePos() + Offset
    				Trace.endpos = pla:EyePos() + Offset
    				Trace.filter = {pla, LocalPlayer()}

    				TraceRes = util.TraceLine(Trace)

    				if !TraceRes.Hit then
    					if (pla:EyeAngles():Forward():Dot((LocalPlayer():EyePos() - pla:EyePos())) > Cap) then
    						Witnesses = Witnesses + 1
    						BeingWitnessed = true

    					end
    				end
    			end
    		end
    	end

    	surface.SetFont("BudgetLabel")
    	if BeingWitnessed then
    		surface.SetTextColor(255, 000, 000, 255)
    		Texture = surface.GetTextureID("gui/silkicons/cross")
    	else
    		surface.SetTextColor(000, 255, 000, 255)
    		Texture = surface.GetTextureID("gui/silkicons/emoticon_smile")
    	end
    	local Text = "Witnesses: "..tostring(Witnesses)
    	local Width, Height = surface.GetTextSize(Text)

    	surface.SetDrawColor(80, 80, 80, 180)
    	surface.DrawRect(ScrW()/2 - (Width/2 + 24), 4, Width + 28, Height + 8)
    	surface.SetDrawColor(0, 0, 0, 255)
        surface.DrawOutlinedRect(ScrW()/2 - (Width/2 + 24), 4, Width + 28, Height + 8)

    	surface.SetTexture(Texture)
    	surface.SetDrawColor(255, 255, 255, 255)
    	surface.DrawTexturedRect(ScrW()/2 - (Width/2 + 20), 8, 16, 16)
    	surface.SetTextPos(ScrW()/2 - Width/2, 8)
    	surface.DrawText(Text)
    end
    hook.Add("HUDPaint", "WitnessesBox", Draw)


/*---------------------------------------------------------------------------
Very hacky script that logs the things you spawn and allows you to undo any entity in the undo list.
---------------------------------------------------------------------------*/

local FakeUM = {}
local function MakeFakeUM()
	FakeUM = {}
	function FakeUM:ReadLong()
		return self.ID
	end
	function FakeUM:ReadString()
		return self.Ent
	end
end

local undoTable
local LastCreated = {} -- Sometimes OnEntityCreated gets called before AddUndo arrives. In that case catch the prop.

hook.Add("InitPostEntity", "LogUndoTable", function()
	local usermessageHooks = debug.getupvalues(usermessage.Hook).Hooks
	local AddUndo = usermessageHooks.AddUndo.Function
	local Undone = usermessageHooks.Undone.Function

	usermessage.Hook("AddUndo", function(um)
		local ID, Ent = um:ReadLong(), um:ReadString()
		local Match = string.match(Ent, "Prop .(.*).")
		if Match then
			hook.Call("Falco_SpawnedProp", nil, Match, ID, Ent)
		end
		for k,v in pairs(LastCreated) do
			if IsValid(v) and not v.IsMine and string.lower(v:GetModel() or "") == string.lower(Match or "") then
				v.IsMine = true
				table.remove(LastCreated, k)
				hook.Call("Falco_ActuallySpawnedProp", nil, v)

				local wep = LocalPlayer():GetActiveWeapon()
				if IsValid(wep) and wep:GetClass() == "weapon_physgun" and input.IsMouseDown(MOUSE_FIRST) and LocalPlayer():GetEyeTrace().Entity == v then
					hook.Call("PhysgunPickup", nil, LocalPlayer(), v)
				end
				break
			end
		end

		MakeFakeUM()

		FakeUM.ID = ID
		FakeUM.Ent = Ent
		AddUndo(FakeUM) -- original AddUndo so that doesn't break
		undoTable = undo.GetTable()
		undoTable[1].IsTaken = false
	end)

	usermessage.Hook("Undone", function(um)
		local ID = um:ReadLong()

		for k,v in pairs(undoTable or {}) do
			local Match = string.match(v.Name, "Prop .(.*).")
			if v.Key == ID and Match then
				hook.Call("Falco_RemovedProp", nil, Match)
			end
		end

		MakeFakeUM()
		FakeUM.ID = ID
		Undone(FakeUM)
	end)
end)

hook.Add("OnEntityCreated", "IActuallySpawnedProp", function(prop)
	if not IsValid(prop) or prop:GetClass() ~= "prop_physics" then return end

	for k, v in pairs(undo.GetTable()) do
		local Match = string.lower(string.match(v.Name, "Prop .(.*).") or "")
		if v.IsTaken == false and not prop.IsMine and Match == string.lower(prop:GetModel() or "") then
			hook.Call("Falco_ActuallySpawnedProp", nil, prop)
			prop.IsMine = true
			undo.GetTable()[k].IsTaken = true

			local wep = LocalPlayer():GetActiveWeapon()
			if IsValid(wep) and wep:GetClass() == "weapon_physgun" and input.IsMouseDown(MOUSE_FIRST) and LocalPlayer():GetEyeTrace().Entity == prop then
				hook.Call("PhysgunPickup", nil, LocalPlayer(), prop)
			end
			return
		end
	end

	local Index = table.insert(LastCreated, prop)
	timer.Simple(0.2, function() LastCreated[Index] = nil end)
end)

hook.Add("PhysgunPickup", "FPickupProp", function(ply, prop)
	if not prop.IsMine then return end
	LocalPlayer().IsHolding = prop
end)

hook.Add("PhysgunDrop", "FDropProp", function(ply, prop)
	ply.IsHolding = nil
end)

concommand.Add("falco_undonum", function(ply,cmd,args)
	local num = tonumber(args[1])
	local Undo = undo.GetTable()
	if not num or not Undo[num] then return end

	RunConsoleCommand("gmod_undonum", Undo[num].Key)
end)


local LastSpawned = ""
local BlockedModels = {}
local Falco_Alternatives = {}
Falco_Alternatives["models/props_c17/lockers001a.mdl"] = "models/props/CS_militia/refrigerator01.mdl"
Falco_Alternatives["models/props_junk/gascan001a.mdl"] = "models/props_junk/metal_paintcan001a.mdl"
Falco_Alternatives["models/props_wasteland/laundry_dryer001.mdl"] = "models/props_rooftop/dome_copper.mdl"
Falco_Alternatives["models/props_rooftop/dome_copper.mdl"] = "models/props/CS_militia/crate_stackmill.mdl"
Falco_Alternatives["models/props_combine/combine_fence01a.mdl"] = "models/props_c17/utilitypole01b.mdl"
Falco_Alternatives["models/props_combine/breen_tube.mdl"] = "models/props/de_nuke/CoolingTower.mdl"
Falco_Alternatives["models/props/de_tides/gate_large.mdl"] = "models/props/de_train/Lockers_Long.mdl"
Falco_Alternatives["models/props/cs_militia/skylight_glass_p6.mdl"] = "models/props_debris/concrete_chunk02b.mdl"
Falco_Alternatives["models/props_rooftop/roof_vent002.mdl"] = "models/props/cs_assault/FireHydrant.mdl"
Falco_Alternatives["models/props_debris/walldestroyed03a.mdl"] = "models/props_junk/iBeam01a_cluster01.mdl"
Falco_Alternatives["models/props_wasteland/interior_fence002d.mdl"] = "models/props/de_inferno/lattice.mdl"
Falco_Alternatives["models/props_junk/sawblade001a.mdl"] = "models/props/CS_militia/skylight_glass_p6.mdl"
Falco_Alternatives["models/props/cs_militia/refrigerator01.mdl"] = "models/props_c17/furnitureStove001a.mdl"
Falco_Alternatives["models/props_vents/vent_large_grill001.mdl"] = "models/cheeze/pcb2/pcb6.mdl"
Falco_Alternatives["models/props/de_train/lockers_long.mdl"] = "models/props_lab/blastdoor001c.mdl"
Falco_Alternatives["models/props_canal/canal_bars004.mdl"] = "models/props/CS_militia/sheetrock_leaning.mdl"
Falco_Alternatives["models/xqm/coastertrack/slope_225_2.mdl"] = "models/xqm/coastertrack/slope_225_1.mdl"
Falco_Alternatives["models/xqm/coastertrack/slope_225_1.mdl"] = "models/hunter/misc/cone4x1.mdl"
Falco_Alternatives["models/xqm/coastertrack/slope_90_1.mdl"] = "models/hunter/misc/cone2x1.mdl"
Falco_Alternatives["models/hunter/tubes/tube1x1x6.mdl"] = "models/props_docks/dock03_pole01a.mdl"
Falco_Alternatives["models/props_phx/construct/metal_angle360.mdl"] = "models/props_junk/trashdumpster02b.mdl"

function FSpawnModel(Model, DontSpawn)
	local check = string.lower(Model)
	if not DontSpawn then
		LastSpawned = string.lower(Model)
	end
	while(table.HasValue(BlockedModels, check) and Falco_Alternatives[check]) do
		check = string.lower(Falco_Alternatives[check])
	end
	if not DontSpawn then RunConsoleCommand("gm_spawn", check) end
	return check, table.HasValue(BlockedModels, check)
end

hook.Add("PlayerBindPress", "SpawnModel", function(ply, bind, pressed, extraArg)
	local TheBind = string.Explode(' ', bind)
	if not TheBind[1] or string.lower(TheBind[1]) ~= "gm_spawn" or not pressed or extraArg then return end
	local DoSpawn = hook.Call("PlayerBindPress", nil, ply, bind, pressed, true)
	if not DoSpawn then FSpawnModel(TheBind[2]) end
	return true
end)

hook.Add("InitPostEntity", "HookIntoFPP", function()
	if not FPP then return end
	local notify = FPP.AddNotify
	function FPP.AddNotify(str, type)
		if LastSpawned ~= '' and (str == "The model of this entity is in the black list!" or str == "The model of this entity is not in the white list!" or
			str == "Your prop is ghosted because it is too big. Interract with it to unghost it.") then
			table.insert(BlockedModels, string.lower(LastSpawned))
			if Falco_Alternatives[string.lower(LastSpawned)] then
				FSpawnModel(Falco_Alternatives[string.lower(LastSpawned)])
			end
		end
		return notify(str, type)
	end
end)





-- xray
-- The sound used to indicate prop speed
util.PrecacheSound("Canals.d1_canals_01_combine_shield_touch_loop1")

-- Speed up the vars!
local ents = ents
local GetConVarNumber = GetConVarNumber
local GetGlobalInt = GetGlobalInt
local hook = hook
local LocalPlayer = LocalPlayer
local math = math
local pairs = pairs
local player = player
local render = render
local RunConsoleCommand = RunConsoleCommand
local string = string
local surface = surface
local table = table
local timer = timer
local type = type
local util = util
local IsValid = IsValid

local _R = debug.getregistry()
local SetColor = _R.Entity.SetColor
local GetColor = _R.Entity.GetColor
local SetMat = _R.Entity.SetMaterial
local GetMat = _R.Entity.GetMaterial
local GetClass = _R.Entity.GetClass
local GetRagdollEntity = _R.Player.GetRagdollEntity
local SetNoDraw = _R.Entity.SetNoDraw
local GetVelocity = _R.Entity.GetVelocity
local VelLength = _R.Vector.Length


-- XRay variables!
local RayOn = false -- Xray toggle variable
local entityMaterials = {}
local entityColors = {}
local VIEWMODEL = NULL
local NoDraws = {"cluaeffect",
	"fog",
	"waterlodcontrol",
	"clientragdoll",
	"envtonemapcontroller",
	"entityflame",
	"func_tracktrain",
	"env_sprite",
	"prop_effect",
	"class c_sun",
	"class C_ClientRagdoll",
	"class C_BaseAnimating",
	"clientside",
	"illusionary",
	"shadowcontrol",
	"keyframe",
	"wind",
	"gmod_wire_hologram",
	"effect",
	"stasisshield",
	"shadertest",
	"portalball",
	"portalskydome",
	"cattails"
}

-- cvars
local repmat = CreateClientConVar("falco_xraymaterial", "mat1", true, false)
local PROPColor = CreateClientConVar("falco_xrayPROPColor", "255,200,0,60", true, false)
local PROPBGColor = CreateClientConVar("falco_xrayPROPBGColor", "0,204,0,39", true, false)
local MINEColor = CreateClientConVar("falco_xrayMINEColor", "255,204,255,60", true, false)
local HOLDINGColor = CreateClientConVar("falco_xrayHOLDINGColor", "0,0,0,40", true, false)
local MINEBGColor = CreateClientConVar("falco_xrayPROPMINEBGColor", "1,204,1,39", true, false)
local PLYColor = CreateClientConVar("falco_xrayPLAYERcolor", "255,255,0,100", true, false)

local cPROPColor = Color(unpack(string.Explode(",", PROPColor:GetString())))
local cPROPBGColor = Color(unpack(string.Explode(",", PROPBGColor:GetString())))
local cPROPMINEBGColor = Color(unpack(string.Explode(",", MINEBGColor:GetString())))
local cPROPHOLDINGColor = Color(unpack(string.Explode(",", HOLDINGColor:GetString())))
local cMINEColor = Color(unpack(string.Explode(",", MINEColor:GetString())))
local cPLYColor = Color(unpack(string.Explode(",", PLYColor:GetString())))
local FRayMat = repmat:GetString()

local ExecuteFray

-- Overriding effects!
local OldEffectFunctions = {}
OldEffectFunctions.render_AddBeam = render.AddBeam
OldEffectFunctions.render_DrawSprite = render.DrawSprite
local OLDUtilEffect = util.Effect

local EMITTER = FindMetaTable("CLuaEmitter")
EMITTER.OldAdd = EMITTER.OldAdd or EMITTER.Add
function EMITTER:Add(...)
	if RayOn then
		local returnal = table.Copy(FindMetaTable("CLuaParticle"))
		for k,v in pairs(returnal or {}) do
			if type(v) == "function" then
				returnal[k] = function() end
			end
		end
		return returnal--override all the functions of this FAKE particle to do nothing
	end
	return self:OldAdd(...)
end

function render.AddBeam(...)
	if not RayOn then
		return OldEffectFunctions.render_AddBeam(...)
	end
end

function render.DrawSprite(a,b,c,d,e, ...)
	if not RayOn or e then
		OldEffectFunctions.render_DrawSprite(a,b,c,d, ...)
	end
end

-- Register babygodded players
local babygod, bgodtime
local function RegisterSpawn()
	local Pls = player.GetAll()
	for ply=1, #Pls do
		Health = Pls[ply]:Health()
		if Health < 1 and Pls[ply].Spawned then
			Pls[ply].Spawned = false
			Pls[ply].BabyGod = false
		elseif Health > 0 and not Pls[ply].Spawned then
			Pls[ply].Spawned = true
			Pls[ply].BabyGod = true
			timer.Simple(bgodtime, function()
				if not IsValid(Pls[ply]) then return end
				Pls[ply].BabyGod = false
				if entityColors[Pls[ply]] then entityColors[Pls[ply]] = Color(255,255,255,255) end
			end)
		end
	end
end
hook.Add("InitPostEntity", "a", function()
	babygod = tobool(GetConVarNumber("babygod"))
	bgodtime = tonumber(GetConVarNumber("babygodtime"))
	if babygod then
		hook.Add("Think", "FalcoDetectSpawn", RegisterSpawn)
	end
end)


local function ToggleFRay(ply, cmd, args)
	FRayMat = repmat:GetString()
	RunConsoleCommand("r_cleardecals")

	-- Turn some annoying things off
	Falco_ForceVar("r_drawparticles", RayOn and 1 or 0)
	//Falco_ForceVar("r_3dsky", RayOn and 1 or 0)
	Falco_ForceVar("r_drawsprites", RayOn and 1 or 0)

	-- Turning xray off
	if RayOn then
		surface.PlaySound("buttons/button19.wav")

		local ENTS = ents.GetAll()
		for v = 1, #ENTS do
			if not IsValid(ENTS[v]) then continue end

			SetMat(ENTS[v], entityMaterials[ENTS[v]])
			local z = entityColors[ENTS[v]]
			if z and type(z) == "table" then
				SetColor(ENTS[v], Color(z.r, z.g, z.b, z.a))
			else
				SetColor(ENTS[v], Color(255,255,255,255))
			end

			for a,b in pairs(NoDraws) do
				local model = ENTS[v]:GetModel() or ""
				if string.find(GetClass(ENTS[v]), b) or string.find(model, b) then -- Hide effects
					SetNoDraw(ENTS[v], false)
				end
			end
		end
		entityColors = {}

		hook.Remove("PostDrawOpaqueRenderables", "falco_xray")
		hook.Remove("OnEntityCreated", "FalcoRayEntityInPVS")
		hook.Remove("PreDrawSkyBox", "removeSkybox")

		util.Effect = OLDUtilEffect
	else
		-- Play a nice sound
		surface.PlaySound("buttons/button1.wav")

		-- Get rid of ropes
		for k,v in pairs(ents.FindByClass("class C_RopeKeyframe")) do
			SetColor(v, Color(0,0,0,0))
		end

		-- and effects
		util.Effect = function() end

		local ENTS = ents.GetAll()
		for v = 1, #ENTS do
			ExecFRayOnce(ENTS[v])
		end

		-- remove the skybox
		hook.Add("PreDrawSkyBox", "removeSkybox", function()
			render.Clear(50, 50, 50, 255)

			return true
		end)

		-- Add the rendering hook
		hook.Add("PostDrawOpaqueRenderables", "falco_xray", ExecuteFray)
		hook.Add("OnEntityCreated", "FalcoRayEntityInPVS", function(ent)
			ExecFRayOnce(ent)
		end)
	end
	RayOn = not RayOn
end
concommand.Add("ae_xray", ToggleFRay)

function ExecFRayOnce(v)
	if not IsValid(v) then return end
	local color = GetColor(v)
	local r,g,b,a = color.r, color.g, color.b, color.a
	local class = GetClass(v)
	local low = string.lower(class)
	local model = v:GetModel() or ""

	-- Set some entities to not draw
	for _, entname in pairs(NoDraws) do
		if string.find(low, entname) or string.find(model, entname) then
			SetNoDraw(v, true)
			return
		end
	end

	v:SetRenderMode(RENDERMODE_TRANSALPHA)
	if v:IsNPC() and (r ~= 0 or g ~= 0 or b ~= 255 or a ~= 255) then
		entityColors[v] = Color(r,g,b,a)
		SetColor(v, Color(0, 0, 255, 30))
	elseif class == "viewmodel" and (r ~= 0 or g ~= 0 or b ~= 0 or a ~= 30)  then
		VIEWMODEL = v
		entityColors[v] = Color(r,g,b,a)
		SetColor(v, Color(0, 0, 0, 30))
		SetMat(v, "mat1")
	elseif string.find(class, "ghost") and a ~= 100 then
		entityColors[v] = Color(r,g,b,a)
		SetColor(v, Color(255,255,255,100))
	elseif (class == "drug_lab" or class == "money_printer") and (r ~= 255 or g ~= 0 or b ~= 100 or a ~= 50) then
		entityColors[v] = Color(r,g,b,a)
		SetColor(v, Color(255, 0, 100, 50))
	elseif class == "prop_physics" or v:IsPlayer() then
		entityColors[v] = Color(r,g,b,a)
	elseif not v:IsPlayer() and not v:IsNPC() and class ~= "prop_physics" and class ~= "prop" and class ~= "drug_lab" and class ~= "money_printer" and class ~= "func_breakable" and class ~= "func_wall" and not v:IsWeapon() and class ~= "viewmodel" and not v.NoXRay and not string.find(class, "ghost") and ( r ~= 255 or g ~= 200 or b ~= 0 or a ~= 100) then
		entityColors[v] = Color(r,g,b,a)
		--SetColor(v, 255, 200, 0, 100)
		SetColor(v, Color(0, 255, 0, 100))
	end
	if class ~= "viewmodel" and GetMat(v) ~= FRayMat and class ~= "func_door" and class ~= "func_door_rotating" and class ~= "prop_door_rotating" and class ~= "func_breakable" and class ~= "func_wall" and not v.NoXRay and not string.find(class, "ghost") then
		entityMaterials[v] = GetMat(v)
		SetMat(v, FRayMat)
	end
end

local ScaleNormal = Vector()
local ScaleOutline1	= Vector()
local function DrawEntityOutline(ent, size, r, g, b, a)
	--size = size or 1.0
	render.SetBlend(a)
	render.SetColorModulation(r, g, b)

	-- First Outline
	--ent:SetModelScale(ScaleOutline1 * size) -- WARNING: RESIZE LAGS
	--SetMaterialOverride("mat4")
	ent:DrawModel()

	-- Revert everything back to how it should be
	render.MaterialOverride(nil)
	--ent:SetModelScale(ScaleNormal)


end

function ExecuteFray()
	if not RayOn then return end

	local PROPS = ents.FindByClass("prop_physics")
	local PLYS = player.GetAll()

	local ang = EyeAngles()
	local eyePos = EyePos()
	cam.Start3D(eyePos, ang)
		for v = 1, #PROPS do
			if IsValid(PROPS[v]) then
				local prop = PROPS[v]

				local IsHolding = LocalPlayer().IsHolding == PROPS[v]

				local r,g,b,a =
					cPROPColor.r,
					cPROPColor.g,
					cPROPColor.b,
					cPROPColor.a

				if PROPS[v].IsMine then
					r, g, b, a = cMINEColor.r, cMINEColor.g, cMINEColor.b, cMINEColor.a or a
				end
				if PROPS[v].IsBreakable and PROPS[v]:IsBreakable() then
					r, g, b = (PROPS[v].IsMine and cMINEColor.r) or 0, 0, 255
				end

				SetColor(PROPS[v], Color(r, g, b, a))
				SetMat(PROPS[v], "mat4")
				if PROPS[v].IsMine then
					local col = IsHolding and cPROPHOLDINGColor or cPROPMINEBGColor
					DrawEntityOutline(PROPS[v], 1.00, col.r/255, col.g/255, col.b/255, col.a/255)
				elseif ang:Forward():Dot(PROPS[v]:GetPos() - eyePos) > 0 then
					DrawEntityOutline(PROPS[v], 1.00, cPROPBGColor.r/255, cPROPBGColor.g/255, cPROPBGColor.b/255, cPROPBGColor.a/255)
				end
				SetMat(PROPS[v], FRayMat)
			end
		end

		for v = 1, #PLYS do
			if IsValid(PLYS[v]) then
				if PLYS[v].BabyGod then
					SetColor(PLYS[v], Color(150,0,255,255))
					if PLYS[v] == LocalPlayer() and IsValid(VIEWMODEL) then
						SetMat(VIEWMODEL, "mat2")
						SetColor(VIEWMODEL, 255,0,0,40)
					end
				else
					if PLYS[v] == LocalPlayer() and IsValid(VIEWMODEL) then
						SetMat(VIEWMODEL, "mat1")
						SetColor(VIEWMODEL, Color(0,0,0,30))
					end
					SetColor(PLYS[v], Color(cPLYColor.r, cPLYColor.g, cPLYColor.b, cPLYColor.a))
				end
				SetMat(PLYS[v], "mat4")
				DrawEntityOutline(PLYS[v], 1.00, 1, 0.2, 0.2, 0.17)
				SetMat(PLYS[v], FRayMat)
				if IsValid(PLYS[v]:GetActiveWeapon()) then
					SetMat(PLYS[v]:GetActiveWeapon(),  "mat4")
					DrawEntityOutline(PLYS[v]:GetActiveWeapon(), 1.00, 1, 0.2, 0.2, 0.17)
				end
			end
			if GetRagdollEntity(PLYS[v]) then
				SetNoDraw(GetRagdollEntity(PLYS[v]), true)
			end
		end
	cam.End3D()

end

/*---------------------------------------------------------------------------
Removes the spawn effect of props
---------------------------------------------------------------------------*/

if SERVER then
	AddCSLuaFile("cl_OverridePropEffect.lua")
	return
end

local Disable = CreateClientConVar( "cl_disable_spawn_effects", "1", true, false )
if not tobool(Disable:GetInt()) then return end
local function Override()
	effects.Register( { Init = function() end, Think = function() end, Render = function() end }, "propspawn" )

	DoPropSpawnedEffect = function( ent )
	end
end

timer.Create("OverrideProp", 30, 0, Override)

hook.Add( "InitPostEntity", "PostGamemodeLoaded.OverridePropEffect", Override )
timer.Simple(3, Override)


//require("cvar2")

function Falco_ForceVar(var, value)
	//cvar2.SetValue(var, value)
end
concommand.Add("falco_bypass", function(ply, cmd, args)
	//Falco_ForceVar(args[1], args[2])
end)
concommand.Add("falco_forcevar", function(ply, cmd, args)
	//Falco_ForceVar(args[1], args[2])
end)



if LocalPlayer():Health() < 60 and LocalPlayer():Alive() then
lhw = 1
else
lhw = 0
end


/************************************************************************************************************************************************************************************************************************
																								Future shit
************************************************************************************************************************************************************************************************************************/





    /************************************
    Name: Localizing
    Purpose: Make the cheat run faster
    ************************************/

	ae = {} -- nothing
    ae.settings                              = {} -- Not started yet.
    ae.hooks                                 = {} -- Store hooks in a table
    ae.concommands                   = {} -- Store concommands in a table
    ae.convars                               = {} -- Store the ConVars in a table
    ae.timers                                        = {} -- Store Timers in a table
    ae.cones                                 = { normal = {}, hl2 = {}, custom = {}} -- I probably won't even need this, I won't have NoSpread for a long time. Anyways, store cones here.
    ae.meta                                  = {} -- Store metatables here
    ae.files                                 = {"ae.lua","Log.txt"} -- Files to hide and protect
    ae.version                               = "4.5" -- Version of the cheat.
    ae.ents                                  = {"ent_pot","npc_vendor","weapon_perp_glock","ent_item","ent_prop_item","sent_spawnpoint","spawned_weapon","spawned_shipment","weed_plant","gift","spawned_money","base_item","weapon_ak47_dayz","weapon_mp5_dayz","weapon_deagle_dayz","sapphire_money_printer","amethyst_money_printer","topaz_money_printer","emerald_money_printer"} -- Ents to show on the ESP
    ae.invalidents                   = {"player","prop_physics","viewmodel",} -- Ents to not show on the ESP
    ae.weapons                               = {["weapon_crossbow"] = 3110,}
    ae.spectators                            = {} -- Store spectators here.
    ae.admins                                        = {} -- store admins here

    local colors                            = {}
    red                                                     = Color(255,0,0,255);
    black                                           = Color(0,0,0,255);
    green                                           = Color(0,255,0,255);
    white                                           = Color(255,255,255,255);
    blue                                            = Color(0,0,255,255);
    cyan                                            = Color(0,255,255,255);
    pink                                            = Color(255,0,255,255);
    blue                                            = Color(0,0,255,255);
    grey                                            = Color(100,100,100,255);
    gold                                            = Color(255,228,0,255);
    lblue                                           = Color(155,205,248);
    lgreen                                          = Color(174,255,0);
    iceblue                                         = Color(116,187,251,255);

    /*******************************************
    Start by unlocking metatabes and localizing
    *******************************************/
    local _G                                        = table.Copy(_G)

    local math                                      = _G.math
    local string                            = _G.string
    local hook                                      = _G.hook
    local table                             = _G.table
    local timer                             = _G.timer
    local surface                           = _G.surface
    local concommand                        = _G.concommand
    local cvars                             = _G.cvars
    local ents                                      = _G.ents
    local player                            = _G.player
    local team                                      = _G.team
    local util                                      = _G.util
    local draw                                      = _G.draw
    local usermessage                       = _G.usermessage
    local vgui                                      = _G.vgui
    local http                                      = _G.http
    local cam                                       = _G.cam
    local render                            = _G.render

    local MsgN                                      = _G.MsgN
    local Msg                                       = _G.Msg
    local Vector                            = _G.Vector
    local Angle                             = _G.Angle
    local pairs                             = _G.pairs
    local ipairs                            = _G.ipairs
    local CreateSound                       = _G.CreateSound
    local setmetatable                      = _G.setmetatable
    local Sound                             = _G.Sound
    local print                             = _G.print
    local pcall                             = _G.pcall
    local type                                      = _G.type
    local LocalPlayer                       = _G.LocalPlayer
    local KeyValuesToTable          = _G.KeyValuesToTable
    local TableToKeyValues          = _G.TableToKeyValues
    local Color                             = _G.Color
    local CreateClientConVar        = _G.CreateClientConVar
    local ErrorNoHalt                       = _G.ErrorNoHalt
    local IsValid                           = _G.IsValid
    local CreateMaterial            = _G.CreateMaterial
    local tonumber                          = _G.tonumber
    local tostring                          = _G.tostring
    local CurTime                           = _G.CurTime
    local FrameTime                         = _G.FrameTime
    local ScrW                                      = _G.ScrW
    local ScrH                                      = _G.ScrH
    local SetClipboardText          = _G.SetClipboardText
    local GetHostName                       = _G.GetHostName
    local unpack                            = _G.unpack
    local AddConsoleCommand         = _G.AddConsoleCommand
    local require                           = _G.require
    local include                           = _G.include

    local MOVETYPE_OBSERVER         = _G.MOVETYPE_OBSERVER
    local MOVETYPE_NONE             = _G.MOVETYPE_NONE
    local TEXT_ALIGN_LEFT           = _G.TEXT_ALIGN_LEFT
    local TEXT_ALIGN_TOP            = _G.TEXT_ALIGN_TOP
    local TEXT_ALIGN_RIGHT          = _G.TEXT_ALIGN_RIGHT
    local TEXT_ALIGN_BOTTOM         = _G.TEXT_ALIGN_BOTTOM
    local IN_DUCK                           = _G.IN_DUCK
    local TEAM_SPECTATOR            = 1002

    -- old [detour]
    local old_filecdir                      = file.CreateDir;
    local old_filedel                       = file.Delete;
    local old_fileexist             = file.Exists;
    local old_fileexistex           = file.ExistsEx;
    local old_filefind                      = file.Find;
    local old_filefinddir           = file.FindDir;
    local old_filefindil            = file.FindInLua;
    local old_fileisdir                     = file.IsDir;
    local old_fileread                      = file.Read;
    local old_filerename            = file.Rename;
    local old_filesize                      = file.Size;
    local old_filetfind                     = file.TFind;
    local old_filetime                      = file.Time;
    local old_filewrite             = file.Write;
    local old_dbginfo                       = debug.getinfo;
    local old_dbginfo                       = debug.getupvalue;
    local old_cve                           = ConVarExists;
    local old_gcv                           = GetConVar;
    local old_gcvn                          = GetConVarNumber;
    local old_gcvs                          = GetConVarString;
    local old_rcc                           = RunConsoleCommand;
    local old_hookadd                       = hook.Add;
    local old_hookrem                       = hook.Remove;
    local old_ccadd                         = concommand.Add;
    local old_ccrem                         = concommand.Remove;
    local old_cvaracc                       = cvars.AddChangeCallback;
    local old_cvargcvc                      = cvars.GetConVarCallbacks;
    local old_cvarchange            = cvars.OnConVarChanged;
    local old_require                       = require;
    local old_eccommand             = engineConsoleCommand;


    --Fonts--
    surface.CreateFont("ESPFont",{font = "ScoreboardText", size = 17, weight = 400, antialias = 0})
    surface.CreateFont("ESPFont_Small",{font = "Default", size = 12, weight = 200, antialias = 0})
    surface.CreateFont("Logo",{font = "akbar", size = 21, weight = 400, antialias = 0})
    surface.CreateFont("ae_ScoreboardText",{font = "ScoreboardText", size = 15, weight = 700, antialias = 0})
    surface.CreateFont("ae_coolvetica",{font = "coolvetica", size = 16, weight = 500, antialias = 0})
    surface.CreateFont("ae_hvh",{font = "ScoreboardTextt", size = 15, weight = 1000, antialias = 1})

    --Materials--
    function ae:CreateMaterial()
    local BaseInfo = {
    ["$basetexture"] = "models/debug/debugwhite",
    ["$model"]       = 1,
    ["$translucent"] = 1,
    ["$alpha"]       = 1,
    ["$nocull"]      = 1,
    ["$ignorez"]     = 1
    }
    local mat
    if GetConVarString("ae_ESP_Chams_Material") == "Solid" then
            mat = CreateMaterial( "ae_solid", "VertexLitGeneric", BaseInfo )
    elseif GetConVarString("ae_ESP_Chams_Material") == "Wireframe" then
            mat = CreateMaterial( "ae_wire", "Wireframe", BaseInfo )
    end
       return mat // return the var to the function
    end

    /**************************************
    Name: Logger
    Purpose: Logs functions and shit
    **************************************/
    concommand.Add("ae_StartLog",function() -- file.Exists is being bad, this is an alternative
    file.Write("ae/log.txt","Log created: ("..os.date()..") \n")
    end)

    function Log(msg)
    file.Append("ae/log.txt","["..os.date().."]: "..msg.."\n")
    end
    Log("Loading....")


    /*******************************************
    Name: Print/Chat functions
    Purpose: Notify the user of what's going on
    ********************************************/
    function ae.Print(msg)
            print("[ae] "..msg)
    end

    function ae.Notify(dosound,col,msg)
            if col then
                    col = col
            end
    chat.AddText(
    iceblue, "[ae] ",
    col, msg)
            if dosound == sound then
                    local beep = Sound( "/buttons/button17.wav" )
                    local beepsound = CreateSound( LocalPlayer(), beep )
                    beepsound:Play()
            end
    end

    /***********************************************
    Name: Hook functions
    Purpose: Add hooks and protect from anticheats
    ************************************************/

    -- Addhook
    local function AddHook(Type,Function)
            Name = Type.." | "..math.random(1,1000),math.random(1,2000),math.random(1,3000) -- Simple hook names
            ae.Print("[ADDED] Hook: ["..Type.."] | Name: "..Name.."")
            return old_hookadd(Type,Name,Function)
    end

    -- RemoveHook
    local function RemoveHook(Type,Function)
            ae.Print("[REMOVED] Hook: ["..Type.."]")
            return old_hookadd(Type,Function)
    end

    /**********************************
    Name: File Shit
    Purpose: Anything relating to file.
    ***********************************/
    -- Write file
    function AddFile(Name,Data)
            ae.Print("[WROTE] File: "..Name.."")
            return old_filewrite(Name,Data)
    end

    /**************
    Random String
    **************/
    function RandomString( len )
            local ret = ""
                    for i = 1 , len do
                            ret = ret .. string.char( math.random( 65 , 116 ) )
            end
            return ret
    end

    /**********************
    Name: Timer shit
    Purpose: Anything timer
    ***********************/
    function AddTimer( sec, rep, func )
            local index = RandomString( 10 )
            ae.timers[ index ] = sec
            timer.Create( index, sec, rep, func )
    end

    /******************************************
    Name: ConCommand Shit
    Purpose: Anything related to concommands
    ********************************************/

    function AddCMD(Name,Function)
            ae.Print("[ADDED] ConCommand: "..Name.."")
            return old_ccadd(Name,Function)
    end

    function RemoveCMD(Name)
            ae.Print("[REMOVED] ConCommand: "..Name.."")
            return old_ccrem(Name)
    end


    /**************************************
    Name: Entity Shit
    Purpose: Anything to do with entities
    ***************************************/
    -- entity finder [addent]
    function AddEnt(entclass)
            if(!table.HasValue(ae.ents,entclass)) then
                    table.insert(ae.ents,entclass)
                    ae.Print("[ADDED] Ent: "..entclass.." to ESP")
                    file.Write("ae/ents.txt", glon.encode( ae.ents ))
            end
    end

    -- entity finder [removeent]
    function RemoveEnt(entclass)
            for k, v in pairs(ae.ents) do
                    if(string.Trim(v) == entclass) then
                            ae.ents[k] = nil
                            ae.Print("[REMOVED] Ent: "..entclass.." from the ESP")
                    end
            end
            file.Write("ae/ents.txt", glon.encode( ae.ents ))
    end

    -- entity finder [clear ents]
    function ClearEnts()
            ae.ents = {}
            file.Write("ae/ents.txt", glon.encode( ae.ents ))
    end

    -- entity finder [IsCustomEnt()]
    function IsCustomEnt( entclass )
            return table.HasValue( ae.ents, entclass )
    end


    /*************************
    Name: CreatePos
    Purpose: Create a position
    Credits: BaconBot
    ***************************/
    function CreatePos(v)
    local ply = LocalPlayer()
    local center = v:LocalToWorld( v:OBBCenter() )
    local min, max = v:OBBMins(), v:OBBMaxs()
    local dim = max - min   local z = max + min
    local frt       = ( v:GetForward() ) * ( dim.y / 2 )
    local rgt       = ( v:GetRight() ) * ( dim.x / 2 )
    local top       = ( v:GetUp() ) * ( dim.z / 2 )
    local bak       = ( v:GetForward() * -1 ) * ( dim.y / 2 )
    local lft       = ( v:GetRight() * -1 ) * ( dim.x / 2 )
    local btm       = ( v:GetUp() * -1 ) * ( dim.z / 2 )
    local s = 1
    local FRT       = center + frt / s + rgt / s + top / s; FRT = FRT:ToScreen()
    local BLB       = center + bak / s + lft / s + btm / s; BLB = BLB:ToScreen()
    local FLT       = center + frt / s + lft / s + top / s; FLT = FLT:ToScreen()
    local BRT       = center + bak / s + rgt / s + top / s; BRT = BRT:ToScreen()
    local BLT       = center + bak / s + lft / s + top / s; BLT = BLT:ToScreen()
    local FRB       = center + frt / s + rgt / s + btm / s; FRB = FRB:ToScreen()
    local FLB       = center + frt / s + lft / s + btm / s; FLB = FLB:ToScreen()
    local BRB       = center + bak / s + rgt / s + btm / s; BRB = BRB:ToScreen()
    local z = 100
    if ( v:Health() <= 50 ) then z = 100 end
    local x, y = ( ( v:Health() / 100 ) ), 1
    if ( v:Health() <= 0 ) then x = 1 end
    local FRT3      = center + frt + rgt + top / x; FRT3 = FRT3; FRT3 = FRT3:ToScreen()
    local BLB3      = center + bak + lft + btm / x; BLB3 = BLB3; BLB3 = BLB3:ToScreen()
    local FLT3      = center + frt + lft + top / x; FLT3 = FLT3; FLT3 = FLT3:ToScreen()
    local BRT3      = center + bak + rgt + top / x; BRT3 = BRT3; BRT3 = BRT3:ToScreen()
    local BLT3      = center + bak + lft + top / x; BLT3 = BLT3; BLT3 = BLT3:ToScreen()
    local FRB3      = center + frt + rgt + btm / x; FRB3 = FRB3; FRB3 = FRB3:ToScreen()
    local FLB3      = center + frt + lft + btm / x; FLB3 = FLB3; FLB3 = FLB3:ToScreen()
    local BRB3      = center + bak + rgt + btm / x; BRB3 = BRB3; BRB3 = BRB3:ToScreen()
    local x, y, z = 1.1, 0.9, 1
    local FRT2      = center + frt / y + rgt / z + top / x; FRT2 = FRT2:ToScreen()
    local BLB2      = center + bak / y + lft / z + btm / x; BLB2 = BLB2:ToScreen()
    local FLT2      = center + frt / y + lft / z + top / x; FLT2 = FLT2:ToScreen()
    local BRT2      = center + bak / y + rgt / z + top / x; BRT2 = BRT2:ToScreen()
    local BLT2      = center + bak / y + lft / z + top / x; BLT2 = BLT2:ToScreen()
    local FRB2      = center + frt / y + rgt / z + btm / x; FRB2 = FRB2:ToScreen()
    local FLB2      = center + frt / y + lft / z + btm / x; FLB2 = FLB2:ToScreen()
    local BRB2      = center + bak / y + rgt / z + btm / x; BRB2 = BRB2:ToScreen()
    local maxX = math.max( FRT.x,BLB.x,FLT.x,BRT.x,BLT.x,FRB.x,FLB.x,BRB.x )
    local minX = math.min( FRT.x,BLB.x,FLT.x,BRT.x,BLT.x,FRB.x,FLB.x,BRB.x )
    local maxY = math.max( FRT.y,BLB.y,FLT.y,BRT.y,BLT.y,FRB.y,FLB.y,BRB.y )
    local minY = math.min( FRT.y,BLB.y,FLT.y,BRT.y,BLT.y,FRB.y,FLB.y,BRB.y )
    local minYhp2 = math.min( FRT.y,BLB.y,FLT.y,BRT.y,BLT.y,FRB.y,FLB.y,BRB.y )
    local maxXhp = math.max( FRT3.x,BLB3.x,FLT3.x,BRT3.x,BLT3.x,FRB3.x,FLB3.x,BRB3.x )
    local minXhp = math.min( FRT3.x,BLB3.x,FLT3.x,BRT3.x,BLT3.x,FRB3.x,FLB3.x,BRB3.x )
    local maxYhp = math.max( FRT3.y,BLB3.y,FLT3.y,BRT3.y,BLT3.y,FRB3.y,FLB3.y,BRB3.y )
    local minYhp = math.min( FRT3.y,BLB3.y,FLT3.y,BRT3.y,BLT3.y,FRB3.y,FLB3.y,BRB3.y )
    local maxX2 = math.max( FRT2.x,BLB2.x,FLT2.x,BRT2.x,BLT2.x,FRB2.x,FLB2.x,BRB2.x )
    local minX2 = math.min( FRT2.x,BLB2.x,FLT2.x,BRT2.x,BLT2.x,FRB2.x,FLB2.x,BRB2.x )
    local maxY2 = math.max( FRT2.y,BLB2.y,FLT2.y,BRT2.y,BLT2.y,FRB2.y,FLB2.y,BRB2.y )
    local minY2 = math.min( FRT2.y,BLB2.y,FLT2.y,BRT2.y,BLT2.y,FRB2.y,FLB2.y,BRB2.y )
    return maxX, minX, maxY, minY, maxX2, minX2, maxY2, minY2, minYhp, maxYhp
    end
    /*******************************************
    Name: Anti-Cheat bypasses
    Purpose: Bypass shitty LUA anti-cheats
    ********************************************/
    ae.Print("[AE]PT1")
    ae.Print("[AE]PT2")
    ae.Print("[AE]PT3")
    /***********************************
    concommands to find entities and shit
    **************************************/

    AddCMD("_ents",function()
    PrintTable(ents.GetAll())
    end)

    AddCMD("_players",function()
    PrintTable(player.GetAll())
    end)
    /*******************
    SOCK
    *******************/

    -- distance check
    function IsCloseEnough(ent)
            local dist = ent:GetPos():Distance( LocalPlayer():GetPos() )
            if( dist <= GetConVarNumber("ae_ESP_Distance") and ent:GetPos() != Vector( 0, 0, 0 ) ) then
                    return true
            end
            return false
    end

    function Chams()
    local mat = ae:CreateMaterial()
            if GetConVarNumber("ae_ESP_Chams") == 1 then
                    for k,v in pairs(player.GetAll()) do
                            local TCol = team.GetColor(v:Team())
                            if IsValid(v) and v:Health() > 0 and v:Team() != TEAM_SPECTATOR and IsCloseEnough(v) then
                            //Players
                            cam.Start3D(EyePos(),EyeAngles())
                            render.SuppressEngineLighting( true )
                            render.SetColorModulation( ( TCol.r * ( 1 / 255 ) ), ( TCol.g * ( 1 / 255 ) ), ( TCol.b * ( 1 / 255 ) ) )
                            render.MaterialOverride( mat )
                            v:DrawModel()
                            render.SuppressEngineLighting( false )
                            render.SetColorModulation(1,1,1)
                            render.MaterialOverride( )
                            v:DrawModel()
                            cam.End3D()
                            end
                    end
            end
    end


    local IsLock = false;
    --[[
            DDR
    ]]--
    function ESP()
            for k, e in pairs( player.GetAll() ) do
    local TeamColor = team.GetColor(e:Team())
    local HPColor = Color(255,255,255,255)
    local Dist = e:GetPos():Distance(LocalPlayer():GetPos());
    local wep = "Unknown"
    local SteamID = e:SteamID()
    local Name = e:Nick()
    local hvhpos = ( e:GetPos() + Vector( 0, 0, 130 ) ):ToScreen();
    if GetConVarNumber("ae_PERP_RPNames") == 1 then
            Name = e:GetRPName()
    else
            Name = e:Nick()
    end
    local maxX, minX, maxY, minY, maxX2, minX2, maxY2, minY2, minYhp, maxYhp = CreatePos( e )
    -- This is bad
    if e:Health() >= 90 then HPColor = Color(0,255,0,255)
            elseif e:Health() >= 70 then HPColor = Color(255,255,0,255)
            elseif e:Health() >= 50 then HPColor = Color(255,165,0,255)
            elseif e:Health() >= 30 then HPColor = Color(255,140,0,255)
            elseif e:Health() >= 20 then HPCOlor = Color(255,69,0,255)
            elseif e:Health() >= 10 then HPColor = Color(255,0,0,255)
            else HPColor = Color(255,0,0,255)
    end
    draw.SimpleTextOutlined("Snow Boi","Logo",1285,15,Color(2,0,0,255),4,1,1,red)
                    if ( e:IsPlayer() && e:Alive() && e != LocalPlayer() && IsCloseEnough(e) ) then
                            if e:GetActiveWeapon() != nil then
                                    if type(e:GetActiveWeapon()) == "Weapon" then
                                            if e:GetActiveWeapon() and e:GetActiveWeapon():IsValid() then
                                                    wep = e:GetActiveWeapon():GetPrintName()

                                                            -- ESP INFO
                                                            if (GetConVarNumber("ae_ESP_Info") == 1 && GetConVarString("ae_ESP_Info_Type") == "info") then
                                                                    draw.SimpleTextOutlined( Name..GetAdminType(e), "ae_coolvetica", maxX2, minY2, TeamColor,4,1,1,Color(0,0,0))
                                                                    draw.SimpleTextOutlined( "H: " .. e:Health(), "ESPFont_Small", maxX2, minY2 + 10, HPColor, 4,1, 1, black )
                                                                    draw.SimpleTextOutlined( "D: " .. math.floor(Dist), "ESPFont_Small", maxX2, minY2 + 20, iceblue, 4, 1, 1, black )
                                                                    draw.SimpleTextOutlined( "W: " .. wep, "ESPFont_Small", maxX2, minY2 + 30, iceblue, 4, 1, 1, black)
                                                                    if e:GetFriendStatus() == "friend" then
                                                                            draw.SimpleTextOutlined( "[Friend]", "ESPFont_Small", maxX2, minY2 - 10, iceblue, 4, 1,1,black)
                                                                    end
                                                                            if e:IsAdmin() then
                                                                                    draw.SimpleText("[Admin]","ESPFont_Small",maxX2,minY2 -20,cyan,4,1,1,black)
                                                                            end
                                                            elseif GetConVarString("ae_ESP_Info_Type") == "hvh" then
                                                                    draw.SimpleTextOutlined(e:Nick().." ["..e:Health().."]","Default",hvhpos.x,hvhpos.y,TeamColor,4,.5,.5,black,TEXT_ALIGN_CENTER)
                                                            end

                                                            -- ESP BOX --
                                                            if GetConVarNumber("ae_ESP_Box") == 1 then
                                                                    surface.SetDrawColor(0,0,255,255)
                                                                    surface.DrawLine( maxX, maxY, maxX, minY )
                                                                    surface.DrawLine( maxX, minY, minX, minY )
                                                                    surface.DrawLine( minX, minY, minX, maxY )
                                                                    surface.DrawLine( minX, maxY, maxX, maxY )
                                                            end
                                                            -- PRE SKEL --
                                                            local bones = {
                                                            { S = "ValveBiped.Bip01_Head1", E = "ValveBiped.Bip01_Neck1" },
                                                            { S = "ValveBiped.Bip01_Neck1", E = "ValveBiped.Bip01_Spine4" },
                                                            { S = "ValveBiped.Bip01_Spine4", E = "ValveBiped.Bip01_Spine2" },
                                                            { S = "ValveBiped.Bip01_Spine2", E = "ValveBiped.Bip01_Spine1" },
                                                            { S = "ValveBiped.Bip01_Spine1", E = "ValveBiped.Bip01_Spine" },
                                                            { S = "ValveBiped.Bip01_Spine", E = "ValveBiped.Bip01_Pelvis" },

                                                            { S = "ValveBiped.Bip01_Spine4", E = "ValveBiped.Bip01_L_UpperArm" },
                                                            { S = "ValveBiped.Bip01_L_UpperArm", E = "ValveBiped.Bip01_L_Forearm" },
                                                            { S = "ValveBiped.Bip01_L_Forearm", E = "ValveBiped.Bip01_L_Hand" },

                                                            { S = "ValveBiped.Bip01_Spine4", E = "ValveBiped.Bip01_R_UpperArm" },
                                                            { S = "ValveBiped.Bip01_R_UpperArm", E = "ValveBiped.Bip01_R_Forearm" },
                                                            { S = "ValveBiped.Bip01_R_Forearm", E = "ValveBiped.Bip01_R_Hand" },

                                                            { S = "ValveBiped.Bip01_Pelvis", E = "ValveBiped.Bip01_L_Thigh" },
                                                            { S = "ValveBiped.Bip01_L_Thigh", E = "ValveBiped.Bip01_L_Calf" },
                                                            { S = "ValveBiped.Bip01_L_Calf", E = "ValveBiped.Bip01_L_Foot" },
                                                            { S = "ValveBiped.Bip01_L_Foot", E = "ValveBiped.Bip01_L_Toe0" },

                                                            { S = "ValveBiped.Bip01_Pelvis", E = "ValveBiped.Bip01_R_Thigh" },
                                                            { S = "ValveBiped.Bip01_R_Thigh", E = "ValveBiped.Bip01_R_Calf" },
                                                            { S = "ValveBiped.Bip01_R_Calf", E = "ValveBiped.Bip01_R_Foot" },
                                                            { S = "ValveBiped.Bip01_R_Foot", E = "ValveBiped.Bip01_R_Toe0" },
                                                            }
                                                            if GetConVarNumber("ae_ESP_Skeleton") == 1 then
                                                                    for k, v in pairs( bones ) do
                                                                            local sPos, ePos = e:GetBonePosition( e:LookupBone( v.S ) ):ToScreen(), e:GetBonePosition( e:LookupBone( v.E ) ):ToScreen()
                                                                                    if e:IsPlayer() and !e:IsNPC() then
                                                                                            surface.SetDrawColor(team.GetColor(e:Team()))
                                                                                    end
                                                                                    surface.DrawLine(sPos.x,sPos.y,ePos.x,ePos.y)
                                                                    end
                                                            end
                                                            -- TRACE --
                                                            if GetConVarNumber("ae_ESP_Tracer") == 1 then
                                                                    cam.Start3D( EyePos() , EyeAngles())
                                                                    render.SetMaterial( Material( "trails/laser" ) )
                                                                    StartPos = LocalPlayer():GetActiveWeapon():GetPos()
                                                                    EndPos = e:GetBonePosition(e:LookupBone("ValveBiped.Bip01_Head1"))
                                                                    render.DrawBeam(StartPos, EndPos , 3, 0, 0, Color(0,255,0,255))
                                                                    cam.End3D()
                                                            end

                                                            -- ch --
                                                            if GetConVarNumber("ae_ESP_Crosshair") == 1 then
                                                                    local x, y = ScrW() / 2, ScrH() / 2
                                                                    local Speed = 1
                                                                    surface.SetDrawColor(GetColorCrosshair())
                                                                    CHPosx = math.Clamp(LocalPlayer():GetEyeTrace().HitPos:ToScreen().x,0,ScrW())
                                                                    CHPosy = math.Clamp(LocalPlayer():GetEyeTrace().HitPos:ToScreen().y,0,ScrH())
                                                                    mathsin = math.sin(CurTime()*Speed)*4
                                                                    mathcos = math.cos(CurTime()*Speed)*4
                                                                    mathsin2 = math.sin(CurTime()*Speed+0.1)*4
                                                                    mathcos2 = math.cos(CurTime()*Speed+0.1)*4
                                                                    mathsin3 = math.sin(CurTime()*Speed-0.1)*4
                                                                    mathcos3 = math.cos(CurTime()*Speed-0.1)*4
                                                                    surface.DrawLine( CHPosx+mathcos*2,CHPosy+mathsin*2,CHPosx+mathcos*5,CHPosy+mathsin*5 );
                                                                    surface.DrawLine( CHPosx-mathcos*2,CHPosy-mathsin*2,CHPosx-mathcos*5,CHPosy-mathsin*5 );
                                                                    surface.DrawLine( CHPosx+mathsin*2,CHPosy-mathcos*2,CHPosx+mathsin*5,CHPosy-mathcos*5 );
                                                                    surface.DrawLine( CHPosx-mathsin*2,CHPosy+mathcos*2,CHPosx-mathsin*5,CHPosy+mathcos*5 );
                                                            end
                                            end
                                    end
                            end
                    end
            end
            for _, v in ipairs( ents.GetAll() ) do
                    if( v:IsValid() and IsCustomEnt( v:GetClass() )) then
                            if GetConVarNumber("ae_ESP_Ents") == 1 then
                                    local wepn = v:GetClass()
                                    local wname = string.Replace(wepn,"weapon_","")
                                    wname = string.Replace(wname,"_"," ")
                                    wname = string.upper(wname)
                                    local entpos = v:GetPos():ToScreen()
                                    draw.SimpleTextOutlined(""..wname.."", "ESPFont_Small", entpos.x + 50, entpos.y - 15, color_red, TEXT_ALIGN_CENTER, TEXT_ALIGN_LEFT, .6, black )
                                    surface.SetDrawColor(255,0,255,255)
                                    surface.DrawLine(entpos.x,entpos.y,entpos.x,entpos.y-10)
                                    surface.DrawLine(entpos.x,entpos.y,entpos.x+10,entpos.y)
                            end
                    end
            end
    end


    /*****************************************
    Name: Aimbot/Aim functions
    Purpose: Aim for you, because you suck
    Credits: faggot
    *******************************************/

    local Tb  = table.Copy( file )
    local Tbs = table.Copy( string )
    local Uw = {}
    local Mw = {}
    local function PlyPos( ply )
    local min = ply:OBBMins()
    local max = ply:OBBMaxs()

    local Spots = {
            Vector( min.x, min.y, min.z ),
            Vector( min.x, min.y, max.z ),
            Vector( min.x, max.y, min.z ),
            Vector( min.x, max.y, max.z ),
            Vector( max.x, min.y, min.z ),
            Vector( max.x, min.y, max.z ),
            Vector( max.x, max.y, min.z ),
            Vector( max.x, max.y, max.z )
    }
    local minX = ScrW() * 2
    local minY = ScrH() * 2
    local maxX = 0
    local maxY = 0

            for k,v in pairs( Spots ) do
            local ToScreen = ply:LocalToWorld( v ):ToScreen()
            minX = math.min( minX, ToScreen.x )
            minY = math.min( minY, ToScreen.y )
            maxX = math.max( maxX, ToScreen.x )
            maxY = math.max( maxY, ToScreen.y )
            end
            return minX, minY, maxX, maxY
    end
    AddCMD("+ae_Aim",function()
    Aimon = 1
    end)

    AddCMD("-ae_Aim",function()
    Aimon = 0
    IsLock = false
    end)

    local function AimSpot(targ)
            if GetConVarString("ae_AIM_AimSpot") == "Eye" then
            local eye = targ:LookupAttachment("eyes")
                    if eye then
                    local pos = targ:GetAttachment(eye)
                            if pos then return pos.Pos end
                    end
            end
            if GetConVarString("ae_AIM_AimSpot") == "Bone" then
            local bone = targ:LookupBone("ValveBiped.Bip01_Head1")
                    if bone then
                    local pos = targ:GetBonePosition(bone)
                            if pos then return pos end
                    end
            end
            if GetConVarString("ae_AIM_AimSpot") == "Center" then
            local center = targ:OBBCenter()
                    if center then
                    local pos = targ:LocalToWorld(center)
                            if pos then return pos end
                    end
            end

    return targ:LocalToWorld(targ:OBBCenter())

    end

    local function Exception(ent)
            if (ent == LocalPlayer()) then return false end
            if (ent:Team() == TEAM_SPECTATOR) then return false end
            if (ent:GetMoveType() == MOVETYPE_OBSERVER) then return false end
            if (!ent:Alive() ) then return false end
            if (ent:InVehicle()) then return false end
            if (GetConVarNumber("ae_AIM_Friendly") == 0 && ent:Team() == LocalPlayer():Team()) then return false end
            if (GetConVarNumber("ae_AIM_Steam") == 0 && ent:GetFriendStatus() == "friend" ) then return false end
    return true
    end

    local function Visible(ply)
    local tracedata = {}
            tracedata.start = LocalPlayer():GetShootPos()
            tracedata.endpos = AimSpot(ply) - Vector(0,0,GetConVarNumber("ae_AIM_Offset"))
            tracedata.mask = MASK_SHOT
            tracedata.filter = {ply , LocalPlayer()}
            Trace = util.TraceLine(tracedata)
            if Trace.Hit then return false else return true end
    end


    local function Aimbot(ucmd)
            if Aimon == 1 then
                    local ArchAngel = Angle(0,0,0)
                    local target;
                    local distance = math.huge;
                    for _, ply in pairs(player.GetAll()) do
                            if (ply != LocalPlayer() and ply:Alive() and Visible(ply) and Exception(ply)) then
                                    local thedist = ply:GetPos():DistToSqr(LocalPlayer():GetPos());
                                    if (thedist < distance) then
                                            distance = thedist;
                                            target = ply;
                                    end
                            end
                    end
                    if target != nil then

                    local Aimspot = AimSpot(target) - Vector(0,0,GetConVarNumber("ae_AIM_Offset"))
                    Aimspot = Aimspot + target:GetVelocity() / 45 - LocalPlayer():GetVelocity() / 45
                    Angel = (Aimspot - LocalPlayer():GetShootPos()):GetNormal():Angle()
                    Angel.p = math.NormalizeAngle( Angel.p )
                    Angel.y = math.NormalizeAngle( Angel.y )
                            ArchAngel = Angle( Angel.p, Angel.y, 0 )
                                    debug.getregistry()["CUserCmd"].SetViewAngles(ucmd, ArchAngel)
                                    IsLock = 1
                            if GetConVarNumber("ae_AIM_Auto") == 1 then
                    ucmd:SetButtons(bit.bor(ucmd:GetButtons(),IN_ATTACK))
                            end
                            if GetConVarNumber("ae_AIM_SH") == 1 then
                                    ucmd:SetButtons(bit.bor(ucmd:GetButtons(),IN_ATTACK2))
                            end
                    end
            end
    end


    /******************************
    Name: SILENT AIM
    Purpose: FAKE AIM VIEW
    ******************************/

    -- make me

    /****************************
    Name: Misc
    Purpose: Misc features
    *****************************/

    function NameChanger()
            if GetConVarNumber("ae_MISC_Namechanger") == 1 then
                    AddTimer( 1, 1, function()
                            ae.chat(dosound,white,"nope");
                    end )
            end
    end

    function Misc()
            if GetConVarNumber("ae_MISC_BunnyHop") == 1 then
                    if input.IsKeyDown(KEY_SPACE) then
                            if LocalPlayer():IsOnGround() then
                                    old_rcc("+Jump")
                                    timer.Create("Bhop",0.01, 0 ,function() old_rcc("-Jump") end)
                            end
                    end
            end
            if GetConVarNumber("ae_AIM_NoRecoil") == 1 then
                    if LocalPlayer():GetActiveWeapon().Primary then
                            LocalPlayer():GetActiveWeapon().Primary.Recoil = 0
                    end
            end
            if GetConVarNumber("ae_MISC_ChatSpam") == 1 then
                    LocalPlayer():ConCommand("say "..GetConVarString("ae_MISC_ChatSpam_Msg").."["..math.random(1,999).."]")
            end
            if GetConVarNumber("ae_MISC_RPGod") == 1 then
                    if LocalPlayer():Health() < 100 then
                            LocalPlayer():ConCommand("say /buyhealth"); -- spam buyhealth
				end
            end
    end

    function ShowNotifi()
            -- now spectating
            for k, v in pairs(player.GetAll()) do
                    if (IsValid(v:GetObserverTarget()) and v:GetObserverTarget():IsPlayer() and v:GetObserverTarget() == LocalPlayer()) then
                            if(not table.HasValue(ae.spectators, v)) then
                                    table.insert(ae.spectators, v);
                                    if GetConVarNumber("ae_MISC_ShowSpec") == 1 then
                                            ae.Notify(true,red,""..v:Nick().." is now spectating you!")
                                            surface.PlaySound("buttons/blip1.wav")
                                    end
                            end
                    end
            end
            -- no longer spectating
            for k, v in pairs(ae.spectators) do
                    if (not IsValid(v) or not IsValid(v:GetObserverTarget()) or not v:GetObserverTarget():IsPlayer() or (v:GetObserverTarget() ~= LocalPlayer())) then
                            table.remove(ae.spectators, k);
                            if GetConVarNumber("ae_MISC_ShowSpec") == 1 then
                                    ae.Notify(true,green,""..v:Nick().." is no longer spectating you!")
                            end
                    end
            end
            -- admin join
            if GetConVarNumber("ae_MISC_ShowAdmins") == 1 then
                    for k, v in pairs(player.GetAll()) do
                            if (v:IsAdmin() and not table.HasValue(ae.admins, v)) then
                                    table.insert(ae.admins, v);
                                    ae.Notify(true,white,"Admin " .. v:Nick() .. " has joined!")
                                    surface.PlaySound("buttons/blip1.wav");
                            end
                    end
            end
    end


    local commands = { "forward" , "back" , "jump" , "moveleft" , "moveright", "duck" }
    function AntiAfk()
            if GetConVarNumber("ae_MISC_AntiAFK") == 1 then
                    local command1 = table.Random( commands )
                    local command2 = table.Random( commands )
                    AddTimer( 1, 1, function()
                            old_rcc( "+"..command1 )
                            old_rcc( "+"..command2 )
                    end )
                    AddTimer( 2, 1, function()
                            old_rcc("-"..command1 )
                            old_rcc("-"..command2 )
                    end )
            end
    end
    AddTimer( 5 , 0 , function() AntiAfk() end )

    // Traitor finder functions
    local Traitors = {};
    local PlayerIsTraitor = false
    timer.Simple( 3, function()
            if ( gmod.GetGamemode().Name ) == "Trouble in Terrorist Town" then
                    local TWeapons = { "weapon_ttt_knife", "weapon_ttt_radio", "(Disguise)", "spiderman's_swep", "weapon_ttt_trait_defilibrator", "weapon_ttt_xbow", "weapon_ttt_dhook", "weapon_awp", "weapon_ttt_ak47", "weapon_jihadbomb", "weapon_ttt_c4", "weapon_ttt_decoy", "weapon_ttt_flaregun", "weapon_ttt_phammer", "weapon_ttt_push", "weapon_ttt_sipistol", "weapon_ttt_awp", "weapon_ttt_silencedsniper", "weapon_ttt_turtlenade", "weapon_ttt_death_station", "weapon_ttt_sg552", "weapon_ttt_tripmine", "weapon_zm_m1911", "weapon_zm_tmp", "weapon_zm_rifle_silence", "weapon_ttt_silenced_m4a1", "weapon_ttt_gadaffiboom", "weapon_ttt_siriffle", "weapon_ttt_teleport", "weapon_ttt_silentsnip", "weapon_ttt_siltmp", "weapon_ttt_sisniper", "weapon_ttt_sitmp", "weapon_ttt_switchatron", "weapon_ttt_thook", "weapon_ttt_radiojammer" }
                    local UsedWeapons = {}
                    local MapWeapons = {}
    function IsATraitor( ply )
            for k, v in pairs( Traitors ) do
                    if v == ply then
                            return true
                    else
                            return false
                    end
            end
    end

    timer.Create("TTT", 0.8, 0, function()
            if GetConVarNumber("ae_MISC_TTT") == 1 then
                    if !IsATraitor( ply ) then
                            for k, v in pairs( ents.FindByClass( "player" ) ) do
                                    if IsValid( v ) then
                                            if (!v:IsDetective()) then
                                                    if v:Team() ~= TEAM_SPECTATOR then
                                                            for wepk, wepv in pairs( TWeapons ) do
                                                                    for entk, entv in pairs( ents.FindByClass( wepv ) ) do
                                                                            if IsValid( entv ) then
                                                                                    cookie.Set( entv, 100 - wepk )
                                                                                    if !table.HasValue( UsedWeapons, cookie.GetNumber( entv ) ) then
                                                                                            if !table.HasValue( MapWeapons, cookie.GetNumber( entv ) ) then
                                                                                                    local EntPos = ( entv:GetPos() - Vector(0,0,35) )
                                                                                                            if entv:GetClass() == wepv then
                                                                                                                    if v:GetPos():Distance( EntPos ) <= 1 then
                                                                                                                            table.insert( Traitors, v )
                                                                                                                            ae.Notify(sound,red,v:Nick() .. " has traitor weapon: " .. wepv )
                                                                                                                            if !table.HasValue( UsedWeapons, cookie.GetNumber( entv ) ) then
                                                                                                                                    table.insert( UsedWeapons, cookie.GetNumber( entv ) )
                                                                                                                            else
                                                                                                                            if !table.HasValue( MapWeapons, cookie.GetNumber( entv ) ) then
                                                                                                                                    table.insert( MapWeapons, cookie.GetNumber( entv ) )
                                                                                                                            end
                                                                                                                    end
                                                                                                            end
                                                                                                    end
                                                                                            end
                                                                                    end
                                                                            end
                                                                    end
                                                            end
                                                    end
                                            end
                                    end
                            end
                    end
            end
    end )

    AddHook("HUDPaint",function()
            if GetConVarNumber("ae_MISC_TTT") == 1 then
                    for k, e in pairs( Traitors ) do
                            local maxX, minX, maxY, minY, maxX2, minX2, maxY2, minY2, minYhp, maxYhp = CreatePos( e )
                            if IsValid( e ) then
                                    if e:Team() ~= TEAM_SPECTATOR then
                                            if ( !e:IsDetective() ) then
                                                    PlayerIsTraitor = true
                                                    draw.SimpleTextOutlined( "[TRAITOR]", "ESPFont", maxX2, minY2 -20, red, 4, 1, 1, black )
                                            end
                                    end
                            end
                    end
            end
    end )

    AddHook("TTTPrepareRound",function()
    timer.Simple( 2, function()
            for k, v in pairs( Traitors ) do
                    table.remove( Traitors, k )
                    Traitors = {}
            end
                    for k, v in pairs( UsedWeapons ) do
                            table.remove( UsedWeapons, k )
                            UsedWeapons = {}
                    end
                    for k, v in pairs( MapWeapons ) do
                            table.remove( MapWeapons, k )
                            MapWeapons = {}
                    end
            end )
    end )
            end
    end )


    /**********************
    Name: Hooks
    Purpose: Hook shit
    ***********************/

    function hooks_hudpaint()
    ESP()
    Notifications()
    end

    function hooks_postdraw()
    Chams()
    end

    function hooks_think()
    Misc();
    NameChanger();
    ShowNotifi();
    end

    function hooks_renderscreenspaceeffects()
    end

    function hooks_calcview()
    end

    function hooks_createmove(ucmd)
    Aimbot(ucmd)
    end

    function ae.hooks:load()
    Log("Loaded hooks")
    AddHook("HUDPaint",hooks_hudpaint)
    AddHook("PostDrawEffects",hooks_postdraw)
    AddHook("Think",hooks_think)
    AddHook("CalcView",hooks_calcview)
    AddHook("RenderScreenspaceEffects",hooks_renderscreenspaceeffects)
    AddHook("CreateMove",hooks_createmove)
    end
    ae.hooks:load(); -- load them

    function ae.hooks:unload()
    RemoveHook("HUDPaint",hooks_hudpaint)
    RemoveHook("CalcView",hooks_calcview)
    RemoveHook("PostDrawEffects",hooks_postdraw)
    RemoveHook("Think",hooks_think)
    RemoveHook("RenderScreenspaceEffects",hooks_renderscreenspaceeffects)
    RemoveHook("CreateMove",hooks_createmove)
    end

    function ae.hooks:reload()
    Log("Reloaded hooks")
    ae.hooks:unload()
    ae.hooks:load()
    end




-- Bar
function Notifications()
local NotifPos = 5

                draw.RoundedBox( 8, -9, 0, 118, 30, Color(0,0,0,110))
				  draw.RoundedBox( 8, 120, 0, 110, 30, Color(0,0,0,110))

				draw.SimpleText(" AE BETA V5", "Logo", 3, NotifPos, Color(0,55,200,255))

  if LocalPlayer():Health() < 60 then
  lhw = 1
  else
  lhw = 0
  end
                if lhw == 0 then
                        draw.SimpleText("Healthy", "Logo", 130,NotifPos, Color(0,255,0,255))
                else
                        draw.SimpleText("Low health!", "Logo", 130, NotifPos, Color(255,0,0,255))
                end
				end

