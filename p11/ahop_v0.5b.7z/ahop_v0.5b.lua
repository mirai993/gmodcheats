/*
 
        aHop.lua
       
        Advanced bunnyhop v0.5b
       
        "Simple, yet effective."
       
*/
 
/************************************/
 
surface.CreateFont( "aHop", { font = "Arial", size = 15, weight = 750, antialias = false, outline = true } )
 
local Version = "v0.5b"
local Enabled = true
local curSpeed = 0
local maxSpeed = 0
local aHop = {}
 
/*
 
        Helper functions
               
*/
 
function aHop.AddHook( Type, Function )
        Name = "[aHop] - " .. math.random( 1, 10000 )
        hook.Add( Type, Name, Function )
end
 
function aHop.AddCommand( Name, Function )
        concommand.Add( Name, Function )
end
 
/*
 
        Core functions
       
*/
 
function aHop.toggleBunnyhop()
        Enabled = !Enabled
        if Enabled == true then
                chat.AddText( Color( 255, 0, 0 ), "[aHop " .. Version .. "] ", Color( 255, 255, 255 ), "Script enabled." )
        else
                chat.AddText( Color( 255, 0, 0 ), "[aHop " .. Version .. "] ", Color( 255, 255, 255 ), "Script disabled." )
        end
end
 
function aHop.HUD()
        curSpeed = math.Round( LocalPlayer():GetVelocity():Length() )
        if ( curSpeed > maxSpeed && LocalPlayer():Alive() ) then
                maxSpeed = curSpeed
        end
        if Enabled then
                draw.RoundedBox( 4, 10, 10, 150, 70, Color( 0, 0, 0, 150 ) )
                draw.SimpleText( "aHop " .. Version, "aHop", 50, 15, Color( 50, 200, 50, 255 ) )
                draw.SimpleText( "Speed: " .. curSpeed, "aHop", 20, 30, Color( 255, 255, 255, 255 ) )
                draw.SimpleText( "Max Speed: " .. maxSpeed, "aHop", 20, 45, Color( 255, 255, 255, 255 ) )
                draw.SimpleText( "Coded by Tyler", "aHop", 30, 60, Color( 200, 40, 60 ) )
        end
end
 
function aHop.bunnyHop( cmd, u )
        if Enabled then
                if !LocalPlayer():IsOnGround() then
                        cmd:SetButtons( bit.band( cmd:GetButtons(), bit.bnot( IN_JUMP ) ) )                    
                end
        end
end
 
/*
 
        Hooks and command adding.
       
*/
 
aHop.AddCommand( "aHop", aHop.toggleBunnyhop )
aHop.AddHook( "CreateMove", aHop.bunnyHop )
aHop.AddHook( "HUDPaint", aHop.HUD )
chat.AddText( Color( 255, 255, 50 ), "[aHop " .. Version .. "] ", Color( 255, 255, 255 ), "Loaded script!" )
chat.AddText( Color( 255, 50, 255 ), "[aHop " .. Version .. "] ", Color( 255, 255, 255 ), "Type 'aHop' in console to toggle the script." )