/*
	
	snixzzCloud OFFICIAL ScriptCloud
	www.snixzz.net
	
	Author: 0xymoron
	Purpose: Load scripts from our cloud of official & unofficial scripts & cheats
	
*/

local SC = { Copy = table.Copy( _G ) }

local g = SC.Copy.table.Copy( _G )
local r = g.debug.getregistry()

-- You can modify this shit

SC.Data = "snixzzCloud" -- Folder in data/ where settings & downloaded scripts will be stored,

----------------------------

-- Don't modify this shit
SC.DB = "http://snixzz.net/"
SC.Dir = "Cloud/"

SC.Scripts = {}

/* Backend */

function SC.Init()
	
	if !g.file.IsDir( SC.Data, "DATA" ) then
	 
		g.file.CreateDir( SC.Data )
		g.MsgN( "[snixzzCloud] Created directory data/" .. SC.Data )
		
	end
	
end

function SC.GetScripts()
	
	g.http.Fetch( SC.DB .. SC.Dir .. "table.txt",
	
		function( body, len, headers, code )
			
			SC.Scripts = g.util.JSONToTable( body )
			
		end,
			
		function( error )
			
			SC.Scripts = {}
			g.MsgN( "[snixzzCloud] Error Fetching Scripts '" .. error .. "'" )
			
		end
		
	)

end

function SC.IsSaved( str )

	return g.file.Exists( SC.Data .. "/" .. g.string.Replace( str, ".lua", ".txt" ), "DATA" )
	
end

function SC.ReadFromDisk( str )

	return g.file.Read( SC.Data .. "/" .. g.string.Replace( str, ".lua", ".txt" ), "DATA" )
	
end

function SC.SaveToDisk( str )

	g.http.Fetch( SC.DB .. SC.Dir .. str,
			
		function( body, len, headers, code )
				
			g.file.Write( SC.Data .. "/" .. g.string.Replace( str, ".lua", ".txt" ), body )
			
			g.chat.AddText(
				g.Color( 201, 85, 85 ), "[snixzzCloud] ",
				g.Color( 255, 255, 255 ), "Saved '",
				g.Color( 0, 255, 0 ), SC.Data .. "/" .. g.string.Replace( str, ".lua", ".txt" ),
				g.Color( 255, 255, 255 ), "'"
			)
			
		end,
			
		function( error )
				
			g.MsgN( "[snixzzCloud] Failed to save file from webserver '" .. str .. "' (" .. error ..")" )
				
		end
		
	)
	
end

function SC.LoadScript( method, str )
	
	if method == "Cloud" then
	
		g.http.Fetch( SC.DB .. SC.Dir .. str,
				
			function( body, len, headers, code )
					
				g.RunStringEx( body, "[C]" )
				
				g.chat.AddText(
					g.Color( 201, 85, 85 ), "[snixzzCloud] ",
					g.Color( 255, 255, 255 ), "Loaded '",
					g.Color( 0, 255, 0 ), str,
					g.Color( 255, 255, 255 ), "' from ",
					g.Color( 0, 255, 255 ), "Cloud"
				)
					
			end,
				
			function( error )
					
				g.MsgN( "[snixzzCloud] Failed to load file from webserver '" .. str .. "' (" .. error ..")" )
					
			end
			
		)
		
	elseif method == "Disk" then
		
		if SC.IsSaved( str ) then
		
			g.chat.AddText(
				g.Color( 201, 85, 85 ), "[snixzzCloud] ",
				g.Color( 255, 255, 255 ), "Loaded '",
				g.Color( 0, 255, 0 ), str,
				g.Color( 255, 255, 255 ), "' from ",
				g.Color( 0, 255, 255 ), "Disk"
			)

			g.RunStringEx( SC.ReadFromDisk( str ), "[C]" )
			
		else
			
			g.chat.AddText( 
				g.Color( 0, 255, 255 ), "[snixzzCloud] ",
				g.Color( 255, 0, 0 ), "Failed to find '" .. str .. "' Make sure to 'Save' the script in the menu!" 
			)
			
		end
		
	end
	
end

local lScript
function SC.Menu()

	SC.GetScripts()
	
	SC.Frame = g.vgui.Create( "DFrame" )
	SC.Frame:SetSize( 440, 300 )
	SC.Frame:SetTitle( ":: snixzzCloud v1.2" )
	SC.Frame:ShowCloseButton( false )
	SC.Frame:MakePopup()
	SC.Frame:Center()
	SC.Frame.Paint = function()		
		g.draw.RoundedBox( 0, 0, 0, SC.Frame:GetWide(), SC.Frame:GetTall(), g.Color( 0, 0, 0, 150 ) )		
	end
	
	local Close = g.vgui.Create( "DButton", SC.Frame )
	Close:SetPos( SC.Frame:GetWide() - 60, 0 )
	Close:SetSize( 60, 20 )
	Close:SetText( "x" )
	Close:SetTextColor( g.color_white )
	Close:SetFont( "Trebuchet18" )
	Close.Paint = function()		
		g.draw.RoundedBox( 0, 0, 0, Close:GetWide(), Close:GetTall(), g.Color( 201, 85, 85 ) )		
	end
	Close.DoClick = function()		
		SC.Frame:SetVisible( false )	
		g.surface.PlaySound( "/buttons/button9.wav" )		
	end
	
	local Sources = g.vgui.Create( "DButton", SC.Frame )
	Sources:SetPos( SC.Frame:GetWide() - 190, 0 )
	Sources:SetSize( 60, 20 )
	Sources:SetText( "Sources" )
	Sources:SetTextColor( g.color_white )
	Sources:SetFont( "Trebuchet18" )
	Sources.Paint = function()		
		g.draw.RoundedBox( 0, 0, 0, Sources:GetWide(), Sources:GetTall(), g.Color( 0, 103, 203 ) )		
	end
	Sources.DoClick = function()			
		g.surface.PlaySound( "/buttons/button9.wav" )
		g.gui.OpenURL( "http://www.snixzz.net/Cloud/" )
	end
	
	local Website = g.vgui.Create( "DButton", SC.Frame )
	Website:SetPos( SC.Frame:GetWide() - 315, 0 )
	Website:SetSize( 120, 20 )
	Website:SetText( "More Free Cheats!" )
	Website:SetTextColor( g.color_white )
	Website:SetFont( "Trebuchet18" )
	Website.Paint = function()		
		g.draw.RoundedBox( 0, 0, 0, Website:GetWide(), Website:GetTall(), g.Color( 150, 0, 0 ) )		
	end
	Website.DoClick = function()		
		g.surface.PlaySound( "/buttons/button9.wav" )
		g.gui.OpenURL( "http://www.snixzz.net/" )
	end
	
	local Sheet = g.vgui.Create( "DPropertySheet", SC.Frame )
	Sheet:SetPos( 5, 25 )
	Sheet:SetSize( SC.Frame:GetWide() - 10, SC.Frame:GetTall() - 30 )
	Sheet.Paint = function()		
		g.draw.RoundedBox( 0, 0, 0, SC.Frame:GetWide() - 10, SC.Frame:GetTall() - 10, g.Color( 0, 0, 0, 100 ) )		
	end
	
	local Scripts = g.vgui.Create( "DListView", Sheet )
	Scripts:SetPos( 5, 5 )
	Scripts:SetSize( Sheet:GetWide() - 100, Sheet:GetTall() - 10 )
	Scripts:SetMultiSelect( false )
	Scripts:AddColumn( "Name" )
	Scripts:AddColumn( "Description" )
	for k, v in g.next, SC.Scripts do
		Scripts:AddLine( k, v )
	end
	
	local Refresh = g.vgui.Create( "DButton", SC.Frame )
	Refresh:SetPos( SC.Frame:GetWide() - 125, 0 )
	Refresh:SetSize( 60, 20 )
	Refresh:SetText( "Refresh" )
	Refresh:SetTextColor( g.color_white )
	Refresh:SetFont( "Trebuchet18" )
	Refresh.Paint = function()		
		g.draw.RoundedBox( 0, 0, 0, Refresh:GetWide(), Refresh:GetTall(), g.Color( 50, 150, 50 ) )		
	end
	Refresh.DoClick = function()		
		SC.GetScripts()
		Scripts:Clear()
		for k, v in g.next, SC.Scripts do
			Scripts:AddLine( k, v )
		end
		g.surface.PlaySound( "/buttons/button9.wav" )
	end
	
	local LoadCloud = g.vgui.Create( "DButton", Sheet )
	LoadCloud:SetPos( Sheet:GetWide() - 90, 5 )
	LoadCloud:SetSize( 85, 30 )
	LoadCloud:SetText( "Load [Web]" )
	LoadCloud:SetTextColor( g.color_white )
	LoadCloud:SetFont( "Trebuchet18" )
	LoadCloud.Paint = function()		
		g.draw.RoundedBox( 0, 0, 0, LoadCloud:GetWide(), LoadCloud:GetTall(), g.Color( 0, 164, 204 ) )		
	end
	LoadCloud.DoClick = function()	
	
		lScript = Scripts:GetSelectedLine()
		
		if lScript != nil then
	
			g.surface.PlaySound( "/buttons/button9.wav" )
			SC.LoadScript( "Cloud", Scripts:GetLine( lScript ):GetValue( 1 ) )
			
		end
		
	end

	local LoadDisk = g.vgui.Create( "DButton", Sheet )
	LoadDisk:SetPos( Sheet:GetWide() - 90, 40 )
	LoadDisk:SetSize( 85, 30 )
	LoadDisk:SetText( "Load [Disk]" )
	LoadDisk:SetTextColor( g.color_white )
	LoadDisk:SetFont( "Trebuchet18" )
	LoadDisk.Paint = function()		
		g.draw.RoundedBox( 0, 0, 0, LoadDisk:GetWide(), LoadDisk:GetTall(), g.Color( 0, 164, 204 ) )		
	end
	LoadDisk.DoClick = function()	
	
		lScript = Scripts:GetSelectedLine()
		
		if lScript != nil then
	
			g.surface.PlaySound( "/buttons/button9.wav" )
			SC.LoadScript( "Disk", Scripts:GetLine( lScript ):GetValue( 1 ) )
			
		end
		
	end
	
	local Save = g.vgui.Create( "DButton", Sheet )
	Save:SetPos( Sheet:GetWide() - 90, 75 )
	Save:SetSize( 85, 30 )
	Save:SetText( "Save" )
	Save:SetTextColor( g.color_white )
	Save:SetFont( "Trebuchet18" )
	Save.Paint = function()		
		g.draw.RoundedBox( 0, 0, 0, Save:GetWide(), Save:GetTall(), g.Color( 0, 164, 204 ) )		
	end
	Save.DoClick = function()	
	
		lScript = Scripts:GetSelectedLine()
		
		if lScript != nil then
	
			g.surface.PlaySound( "/buttons/button9.wav" )
			SC.SaveToDisk( Scripts:GetLine( lScript ):GetValue( 1 ) )
			
		end
		
	end
	
	local ViewSrc = g.vgui.Create( "DButton", Sheet )
	ViewSrc:SetPos( Sheet:GetWide() - 90, 110 )
	ViewSrc:SetSize( 85, 30 )
	ViewSrc:SetText( "View Source" )
	ViewSrc:SetTextColor( g.color_white )
	ViewSrc:SetFont( "Trebuchet18" )
	ViewSrc.Paint = function()		
		g.draw.RoundedBox( 0, 0, 0, ViewSrc:GetWide(), ViewSrc:GetTall(), g.Color( 0, 164, 204 ) )		
	end
	ViewSrc.DoClick = function()	
	
		lScript = Scripts:GetSelectedLine()
		
		if lScript != nil then
		
			g.gui.OpenURL( "http://snixzz.net/Cloud/" .. Scripts:GetLine( lScript ):GetValue( 1 ) )
			g.chat.AddText(
				g.Color( 201, 85, 85 ), "[snixzzCloud] ",
				g.Color( 255, 255, 255 ), "Opening source file '",
				g.Color( 0, 255, 0 ), "http://snixzz.net/Cloud/" .. Scripts:GetLine( lScript ):GetValue( 1 ),
				g.Color( 255, 255, 255 ), "'"
			)
			g.surface.PlaySound( "/buttons/button9.wav" )
			
		end
		
	end
	
end

SC.GetScripts()
SC.Init()
g.concommand.Add( "sc_menu", function() SC.Menu() end )
g.chat.AddText(
	g.Color( 201, 85, 85 ), "[snixzzCloud] ",
	g.Color( 255, 255, 255 ), "Loaded! Bind a key to 'sc_menu' to access the Cloud!"
)
g.chat.AddText(
	g.Color( 0, 255, 85 ), "[snixzzCloud] ",
	g.Color( 255, 255, 255 ), "Coded by 0xymoron @ snixzz.net & mpgh.net"
)
	