--[[
	MOD/lua/jing.lua
	Prototype_Silenced | STEAM_0:1:30877682 <78.150.205.25:27005> | [30-10-13 11:12:28AM]
	===BadFile===
]]

--[[
Features:
On/Off Switch - In the top right of the hack there is an on/off switch that will deactivate everything.

Aimbot -
Active - Determines, overall, if the aimbot should be working.
Random Bone - If enabled the aimbot will pick a random bone to attack instead of always going at the players head.
Preference - Used to determine who the aimbot should target next. Can be set to Distance or Angle.
Attack NPCs - Determines if the aimbot should target NPCs.
Attack Player - Determines if the aimbot should target Players.
Prediction - Velocity prediction, to increase the aimbots accuracy.
Aim On Key - If this is on the aimbot will only target when your selected key is pressed.
Key - Determines the key for the previous option.
Anti Snap - Stops the aimbot from snapping to the target. But will decrease accuracy.
A-Snap Speed - The speed of the anti-snap. Value between 1 and 5.
Max Angle - The maximum angle the target can be away from you. Value between 0-270.
Auto Shoot - If this is on and the aimbot is locked on it will automatically shoot.
Panic Mode - If this is on the aimbot wont function while you are being spectated.
Ignore Team - If this is on the aimbot will not target players on your team, works with TTT if the traitor detector is enabled.

ESP -
Active - Determines, overall, if the ESP is working.
Player Info - Determines if the ESP should show player information.
NPC Info - Determines if the ESP should show NPC information.
Names - Determines if the targets name should be shown. (on NPCs it will be the class name, ex: npc_monk)
Weapons - Determines if the targets weapon should be displayed
Distance - Determines if distance between you and the target should be displayed.
Health - Determines if the targets health should be displayed.
Bounding Box - Determines if a bounding box should be drawn around the target.
TTT Feature - Show Traitors - Determines if the ESP should display if the target is a traitor. (must have traitor finder active, see Misc)
TTT Feature - Bodies - Will display body information on TTT. (Credits on body, Name of player, Found or not found)
2D Radar - Enables a 2D radar on screen. Players and NPCs are shown as arrows, bodies (TTT) are shown as circles.
Radar Scale - The distance the radar reaches. Value between 1 and 100
Max Distance - Determines the maximum distance the ESP will work to. (set to 0 for unlimited distance)
Team Based - Make the color of the ESP based on the targets team. Works with TTT.

Chams -
Active - Determines, overall, if the Chams are working.
Draw Players - Determines if the Chams should draw players.
Draw NPCs - Determines if the Chams should draw NPCs.
Draw Weapons - Determines if the Chams should draw the targets weapon.
TTT Feature - Bodies - Adds TTT bodies to the Chams
Team Based - Makes the color of the chams based on the targets team. Works with TTT.
Max Distance - Determines the maximum distance the Chams will work to. (set to 0 for unlimited distance)

Misc -
Show Admins - Displays all current admins in the top right corner of your screen.
Crosshair - Will draw a crosshair on your screen.
Crosshair Size - The size of the crosshair. Value between 0 and 1000.
No Recoil - Will remove all weapon recoil. (doesn't work in singleplayer)
Spectators - Displays all your current spectators in the top right corner of your screen, under the admins.
Auto Reload - Will automatically reload your weapon when your magazine is empty.
Bunny Hop - If this is on you will bunny hop while pressing the bunny hop key.
Key - Determines the key for the previous option.
Auto Pistol - Fires semi-automatic weapons as fast as possible. (doesn't work on default HL2 weapons)
DarkRP Feature - Buy Health - Will automatically use /buyhealth when your health falls below the minimum value set.
DarkRP Feature - Minimum - Minimum health before buying health. Value between 0 and 100.
TTT Feature - Traitor Finder - Will display when a traitor buys a traitor weapon. (see also the ESP option for displaying traitors)
Show Deaths - Will notify you via chat when a player dies.
Sounds - Enables sound cues along with notifications.

Style -
Bounding Box - Determines the color the bounding box should draw in.
ESP Text - Determines the color the ESP text should draw in.
Crosshair - Determines the color the Crosshair should draw in.
TTT Feature - Body Text - Determines the color body information will be shown in.
Chams - The color of the chams. (will be overwritten if Cham option Team Based is on)
TTT Feature - Body Chams - The color TTT bodies should be on the chams.
--]]

--I hear this makes the hack load faster, i didn't actually check the O times but whatever.
local hook = hook
local derma = derma
local surface = surface
local vgui = vgui
local input = input
local util = util
local cam = cam
local render = render
local math = math
local draw = draw
local team = team

local Jing = {}
Jing.Active = CreateClientConVar("Jing_Active", 1, true, false)
Jing.Version = "1.0.0"
Jing.Ply = LocalPlayer()
Jing.TTT = (GAMEMODE and GAMEMODE.Name and string.find(GAMEMODE.Name, "Terror") and true) or false
if Jing.TTT then Jing.TTTCORPSE = CORPSE end
Jing.DarkRP = (GAMEMODE and GAMEMODE.Name and string.find(GAMEMODE.Name, "DarkRP") and true) or false

--Converts a string of a color (ex. "Color(255, 255, 255, 255)") into an actual color, and returns the color.
Jing.GetColorFromString = function(words)
	--I probably shouldve just used string.explode...well.......
	if type(words) != "string" then return Color(255, 255, 255, 255) end
	words = "return "..words
	local func = CompileString(words, "GettingColors", true)
	local good, color = pcall(func)
	if good and type(color) == "table" and color.r and color.g and color.b and color.a then
		return color
	else
		return Color(255, 255, 255, 255)
	end
end

Jing.Chars = {"A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M", "N", "O", "P", "Q", "R", "S", "T", "U", "V", "W", "X", "Y", "Z"}
Jing.RandomName = function(amount)
	local toReturn = ""
	local amount = amount or 10
	for i = 1, amount do
		if math.random(0, 1) == 0 then
			toReturn = toReturn..string.lower(table.Random(Jing.Chars))
		else
			toReturn = toReturn..table.Random(Jing.Chars)
		end
	end
	return toReturn
end

Jing.Message = function(...)
	chat.AddText(Color(50, 255, 100), "[Jing] ", ...)
end

Jing.Aimbot = {}
Jing.Aimbot.CurTarget = nil
Jing.Aimbot.Vars = {}
Jing.Aimbot.Vars["Active"] = CreateClientConVar("Jing_Aimbot_Active", 0, true, false)
Jing.Aimbot.Vars["RandomBones"] = CreateClientConVar("Jing_Aimbot_RandomBones", 0, true, false)
Jing.Aimbot.Vars["AttackNPCs"] = CreateClientConVar("Jing_Aimbot_AttackNPCs", 0, true, false)
Jing.Aimbot.Vars["AttackPlayers"] = CreateClientConVar("Jing_Aimbot_AttackPlayers", 0, true, false)
Jing.Aimbot.Vars["Prediction"] = CreateClientConVar("Jing_Aimbot_Prediction", 0, true, false)
Jing.Aimbot.Vars["AimOnKey"] = CreateClientConVar("Jing_Aimbot_AimOnKey", 0, true, false)
Jing.Aimbot.Vars["AimOnKey_Key"] = CreateClientConVar("Jing_Aimbot_AimOnKey_Key", "MOUSE_LEFT", true, false)
Jing.Aimbot.Vars["MaxAngle"] = CreateClientConVar("Jing_Aimbot_MaxAngle", 180, true, false)
Jing.Aimbot.Vars["Preference"] = CreateClientConVar("Jing_Aimbot_Preference", "Distance", true, false)
Jing.Aimbot.Vars["AntiSnap"] = CreateClientConVar("Jing_Aimbot_AntiSnap", 0, true, false)
Jing.Aimbot.Vars["AntiSnapSpeed"] = CreateClientConVar("Jing_Aimbot_AntiSnapSpeed", 4, true, false)
Jing.Aimbot.Vars["AutoShoot"] = CreateClientConVar("Jing_Aimbot_AutoShoot", 0, true, false)
Jing.Aimbot.Vars["PanicMode"] = CreateClientConVar("Jing_Aimbot_PanicMode", 0, true, false)
Jing.Aimbot.Vars["IgnoreTeam"] = CreateClientConVar("Jing_Aimbot_IgnoreTeam", 0, true, false)

Jing.Friends = {}
Jing.Friends.List = {} --The steamIDs of everyone on your friends list
Jing.Friends.Vars = {}
Jing.Friends.Vars["Active"] = CreateClientConVar("Jing_Friends_Active", 0, true, false)
Jing.Friends.Vars["Reverse"] = CreateClientConVar("Jing_Friends_Reverse", 0, true, false)

Jing.ESP = {}
Jing.ESP.Vars = {}
Jing.ESP.Vars["Active"] = CreateClientConVar("Jing_ESP_Active", 0, true, false)
Jing.ESP.Vars["Players"] = CreateClientConVar("Jing_ESP_Players", 0, true, false)
Jing.ESP.Vars["NPCs"] = CreateClientConVar("Jing_ESP_NPCs", 0, true, false)
Jing.ESP.Vars["Name"] = CreateClientConVar("Jing_ESP_Name", "Off", true, false)
Jing.ESP.Vars["Weapons"] = CreateClientConVar("Jing_ESP_Weapons", "Off", true, false)
Jing.ESP.Vars["Distance"] = CreateClientConVar("Jing_ESP_Distance", "Off", true, false)
Jing.ESP.Vars["Health"] = CreateClientConVar("Jing_ESP_Health", "Off", true, false)
Jing.ESP.Vars["MaxDistance"] = CreateClientConVar("Jing_ESP_MaxDistance", 0, true, false)
Jing.ESP.Vars["Box"] = CreateClientConVar("Jing_ESP_Box", 0, true, false)
Jing.ESP.Vars["ShowTraitors"] = CreateClientConVar("Jing_ESP_ShowTraitors", "Off", true, false)
Jing.ESP.Vars["Bodies"] = CreateClientConVar("Jing_ESP_Bodies", 0, true, false)
Jing.ESP.Vars["Radar"] = CreateClientConVar("Jing_ESP_Radar", 0, true, false)
Jing.ESP.Vars["RadarScale"] = CreateClientConVar("Jing_ESP_RadarScale", 20, true, false)
Jing.ESP.Vars["TeamBased"] = CreateClientConVar("Jing_ESP_TeamBased", 0, true, false)

Jing.Chams = {}
Jing.Chams.Mat = CreateMaterial(Jing.RandomName(math.random(10,15)), "VertexLitGeneric", { ["$basetexture"] = "models/debug/debugwhite", ["$model"] = 1, ["$ignorez"] = 1 })
Jing.Chams.Vars = {}
Jing.Chams.Vars["Active"] = CreateClientConVar("Jing_Chams_Active", 0, true, false)
Jing.Chams.Vars["Players"] = CreateClientConVar("Jing_Chams_Players", 0, true, false)
Jing.Chams.Vars["NPCs"] = CreateClientConVar("Jing_Chams_NPCs", 0, true, false)
Jing.Chams.Vars["Weapons"] = CreateClientConVar("Jing_Chams_Weapons", 0, true, false)
Jing.Chams.Vars["MaxDistance"] = CreateClientConVar("Jing_Chams_MaxDistance", 0, true, false)
Jing.Chams.Vars["Bodies"] = CreateClientConVar("Jing_Chams_Bodies", 0, true, false)
Jing.Chams.Vars["TeamBased"] = CreateClientConVar("Jing_Chams_TeamBased", 0, true, false)

Jing.Entities = {}
Jing.Entities.List = {} --The class namse of all the entities
Jing.Entities.Vars = {}
Jing.Entities.Vars["Active"] = CreateClientConVar("Jing_Entities_Active", 0, true, false)

Jing.Misc = {}
Jing.Misc.Vars = {}
Jing.Misc.Vars["ShowAdmins"] = CreateClientConVar("Jing_Misc_ShowAdmins", 0, true, false)
Jing.Misc.Vars["Crosshair"] = CreateClientConVar("Jing_Misc_Cross", 0, true, false)
Jing.Misc.Vars["CrosshairSize"] = CreateClientConVar("Jing_Misc_CrossSize", 50, true, false)
Jing.Misc.Vars["NoRecoil"] = CreateClientConVar("Jing_Misc_NoRecoil", 0, true, false)
Jing.Misc.Vars["ShowSpectators"] = CreateClientConVar("Jing_Misc_ShowSpectators", 0, true, false)
Jing.Misc.Vars["BunnyHop"] = CreateClientConVar("Jing_Misc_BunnyHop", 0, true, false)
Jing.Misc.Vars["BunnyHop_Key"] = CreateClientConVar("Jing_Misc_BunnyHop_Key", "KEY_SPACE", true, false)
Jing.Misc.Vars["AutoReload"] = CreateClientConVar("Jing_Misc_AutoReload", 0, true, false)
Jing.Misc.Vars["AutoPistol"] = CreateClientConVar("Jing_Misc_AutoPistol", 0, true, false)
Jing.Misc.Vars["BuyHealth"] = CreateClientConVar("Jing_Misc_BuyHealth", 0, true, false)
Jing.Misc.Vars["BuyHealth_Minimum"] = CreateClientConVar("Jing_Misc_BuyHealth_Minimum", 80, true, false)
Jing.Misc.Vars["TraitorFinder"] = CreateClientConVar("Jing_Misc_TraitorFinder", 0, true, false)
Jing.Misc.Vars["Deaths"] = CreateClientConVar("Jing_Misc_Deaths", 0, true, false)
Jing.Misc.Vars["Sounds"] = CreateClientConVar("Jing_Misc_Sounds", 0, true, false)

Jing.Style = {}
Jing.Style.Vars = {}
Jing.Style.Vars["BoundingBox"] = {}
Jing.Style.Vars["BoundingBox"].var = CreateClientConVar("Jing_Style_BoundingBox", "Color(255, 0, 0, 255)", true, false)
Jing.Style.Vars["BoundingBox"].color = Jing.GetColorFromString(Jing.Style.Vars["BoundingBox"].var:GetString())
Jing.Style.Vars["ESPText"] = {}
Jing.Style.Vars["ESPText"].var = CreateClientConVar("Jing_Style_ESPText", "Color(255, 255, 255, 255)", true, false)
Jing.Style.Vars["ESPText"].color = Jing.GetColorFromString(Jing.Style.Vars["ESPText"].var:GetString())
Jing.Style.Vars["Crosshair"] = {}
Jing.Style.Vars["Crosshair"].var = CreateClientConVar("Jing_Style_Cross", "Color(255, 255, 255, 255)", true, false)
Jing.Style.Vars["Crosshair"].color = Jing.GetColorFromString(Jing.Style.Vars["Crosshair"].var:GetString())
Jing.Style.Vars["BodyText"] = {}
Jing.Style.Vars["BodyText"].var = CreateClientConVar("Jing_Style_BodyText", "Color(255, 255, 255, 255)", true, false)
Jing.Style.Vars["BodyText"].color = Jing.GetColorFromString(Jing.Style.Vars["BodyText"].var:GetString())
Jing.Style.Vars["Chams"] = {}
Jing.Style.Vars["Chams"].var = CreateClientConVar("Jing_Style_Chams", "Color(0, 255, 0, 255)", true, false)
Jing.Style.Vars["Chams"].color = Jing.GetColorFromString(Jing.Style.Vars["Chams"].var:GetString())
Jing.Style.Vars["BodyChams"] = {}
Jing.Style.Vars["BodyChams"].var = CreateClientConVar("Jing_Style_BodyChams", "Color(0, 255, 0, 255)", true, false)
Jing.Style.Vars["BodyChams"].color = Jing.GetColorFromString(Jing.Style.Vars["BodyChams"].var:GetString())

--This loads our friends list and custom entities list.
/*Jing.SavedData = CreateClientConVar("Jing_SaveData", Jing.RandomName(math.random(10, 15)), true, false)
if file.Exists(Jing.SavedData:GetString()..".txt", "DATA") then
	local info = string.Explode("\n", file.Read(Jing.SavedData:GetString()..".txt", "DATA"))
	if type(info) == "table" and info[1] and info[2] then
		Jing.Friends.List = util.JSONToTable(info[1])
		Jing.Entities.List = util.JSONToTable(info[2])
	end
end

Jing.SaveData = function()
	file.Write(Jing.SavedData:GetString()..".txt", util.TableToJSON(Jing.Friends.List))
	file.Append(Jing.SavedData:GetString()..".txt", "\n")
	file.Append(Jing.SavedData:GetString()..".txt", util.TableToJSON(Jing.Entities.List))
end*/

--This is all the bones i look for in the order im looking for them. Feel free to change the order if you want to attack the foot before the head or something like that.
Jing.Bones = {
"ValveBiped.Bip01_Head1",
"ValveBiped.Bip01_Neck1",
"ValveBiped.Bip01_Spine4",
"ValveBiped.Bip01_Spine2",
"ValveBiped.Bip01_Spine1",
"ValveBiped.Bip01_Spine",
"ValveBiped.Bip01_R_UpperArm",
"ValveBiped.Bip01_R_Forearm",
"ValveBiped.Bip01_R_Hand",
"ValveBiped.Bip01_L_UpperArm",
"ValveBiped.Bip01_L_Forearm",
"ValveBiped.Bip01_L_Hand",
"ValveBiped.Bip01_R_Thigh",
"ValveBiped.Bip01_R_Calf",
"ValveBiped.Bip01_R_Foot",
"ValveBiped.Bip01_R_Toe0",
"ValveBiped.Bip01_L_Thigh",
"ValveBiped.Bip01_L_Calf",
"ValveBiped.Bip01_L_Foot",
"ValveBiped.Bip01_L_Toe0"
}

--If random bones is enabled this list is gone through, randomly, and if none of the bones on this list are found the entire list (above) is gone through.
--If you edit this be sure to edit the function below it.
Jing.RandomBones = {
"ValveBiped.Bip01_Head1",
"ValveBiped.Bip01_Neck1",
"ValveBiped.Bip01_Spine4",
"ValveBiped.Bip01_Spine2",
"ValveBiped.Bip01_R_UpperArm",
"ValveBiped.Bip01_L_UpperArm"
}
Jing.GetRandomBones = function()
	local temp = {}
	local function GetBones() --Ahh recursion, i love you.
		if #Jing.RandomBones > 0 then
			local random = math.random(1, #Jing.RandomBones)
			table.insert(temp, Jing.RandomBones[random])
			table.remove(Jing.RandomBones, random)
			GetBones()
		else
			table.insert(Jing.RandomBones, "ValveBiped.Bip01_Head1")
			table.insert(Jing.RandomBones, "ValveBiped.Bip01_Neck1")
			table.insert(Jing.RandomBones, "ValveBiped.Bip01_Spine4")
			table.insert(Jing.RandomBones, "ValveBiped.Bip01_Spine2")
			table.insert(Jing.RandomBones, "ValveBiped.Bip01_R_UpperArm")
			table.insert(Jing.RandomBones, "ValveBiped.Bip01_L_UpperArm")
		end
	end
	GetBones()
	return temp
end

--A list of all keyboard keys, for binding
Jing.Keys = {
[0] = "KEY_NONE",
[1] = "KEY_0",
[2] = "KEY_1",
[3] = "KEY_2",
[4] = "KEY_3",
[5] = "KEY_4",
[6] = "KEY_5",
[7] = "KEY_6",
[8] = "KEY_7",
[9] = "KEY_8",
[10] = "KEY_9",
[11] = "KEY_A",
[12] = "KEY_B",
[13] = "KEY_C",
[14] = "KEY_D",
[15] = "KEY_E",
[16] = "KEY_F",
[17] = "KEY_G",
[18] = "KEY_H",
[19] = "KEY_I",
[20] = "KEY_J",
[21] = "KEY_K",
[22] = "KEY_L",
[23] = "KEY_M",
[24] = "KEY_N",
[25] = "KEY_O",
[26] = "KEY_P",
[27] = "KEY_Q",
[28] = "KEY_R",
[29] = "KEY_S",
[30] = "KEY_T",
[31] = "KEY_U",
[32] = "KEY_V",
[33] = "KEY_W",
[34] = "KEY_X",
[35] = "KEY_Y",
[36] = "KEY_Z",
[37] = "KEY_PAD_0",
[38] = "KEY_PAD_1",
[39] = "KEY_PAD_2",
[40] = "KEY_PAD_3",
[41] = "KEY_PAD_4",
[42] = "KEY_PAD_5",
[43] = "KEY_PAD_6",
[44] = "KEY_PAD_7",
[45] = "KEY_PAD_8",
[46] = "KEY_PAD_9",
[47] = "KEY_PAD_DIVIDE",
[48] = "KEY_PAD_MULTIPLY",
[49] = "KEY_PAD_MINUS",
[50] = "KEY_PAD_PLUS",
[51] = "KEY_PAD_ENTER",
[52] = "KEY_PAD_DECIMAL",
[53] = "KEY_LBRACKET",
[54] = "KEY_RBRACKET",
[55] = "KEY_SEMICOLON",
[56] = "KEY_APOSTROPHE",
[57] = "KEY_BACKQUOTE",
[58] = "KEY_COMMA",
[59] = "KEY_PERIOD",
[60] = "KEY_SLASH",
[61] = "KEY_BACKSLASH",
[62] = "KEY_MINUS",
[63] = "KEY_EQUAL",
[64] = "KEY_ENTER",
[65] = "KEY_SPACE",
[66] = "KEY_BACKSPACE",
[67] = "KEY_TAB",
[68] = "KEY_CAPSLOCK",
[69] = "KEY_NUMLOCK",
[70] = "KEY_ESCAPE",
[71] = "KEY_SCROLLLOCK",
[72] = "KEY_INSERT",
[73] = "KEY_DELETE",
[74] = "KEY_HOME",
[75] = "KEY_END",
[76] = "KEY_PAGEUP",
[77] = "KEY_PAGEDOWN",
[78] = "KEY_BREAK",
[79] = "KEY_LSHIFT",
[80] = "KEY_RSHIFT",
[81] = "KEY_LALT",
[82] = "KEY_RALT",
[83] = "KEY_LCONTROL",
[84] = "KEY_RCONTROL",
[85] = "KEY_LWIN",
[86] = "KEY_RWIN",
[87] = "KEY_APP",
[88] = "KEY_UP",
[89] = "KEY_LEFT",
[90] = "KEY_DOWN",
[91] = "KEY_RIGHT",
[92] = "KEY_F1",
[93] = "KEY_F2",
[94] = "KEY_F3",
[95] = "KEY_F4",
[96] = "KEY_F5",
[97] = "KEY_F6",
[98] = "KEY_F7",
[99] = "KEY_F8",
[100] = "KEY_F9",
[101] = "KEY_F10",
[102] = "KEY_F11",
[103] = "KEY_F12",
--[104] = "KEY_CAPSLOCKTOGGLE", --THESE
--[105] = "KEY_NUMLOCKTOGGLE", --MOFOS
--[106] = "KEY_SCROLLLOCKTOGGLE", --SHOULD DIE
[107] = "KEY_XBUTTON_UP",
[108] = "KEY_XBUTTON_DOWN",
[109] = "KEY_XBUTTON_LEFT",
[110] = "KEY_XBUTTON_RIGHT",
[111] = "KEY_XBUTTON_START",
[112] = "KEY_XBUTTON_BACK",
[113] = "KEY_XBUTTON_STICK1",
[114] = "KEY_XBUTTON_STICK2",
[115] = "KEY_XBUTTON_A",
[116] = "KEY_XBUTTON_B",
[117] = "KEY_XBUTTON_X",
[118] = "KEY_XBUTTON_Y",
[119] = "KEY_XBUTTON_BLACK",
[120] = "KEY_XBUTTON_WHITE",
[121] = "KEY_XBUTTON_LTRIGGER",
[122] = "KEY_XBUTTON_RTRIGGER",
[123] = "KEY_XSTICK1_UP",
[124] = "KEY_XSTICK1_DOWN",
[125] = "KEY_XSTICK1_LEFT",
[126] = "KEY_XSTICK1_RIGHT",
[127] = "KEY_XSTICK2_UP",
[128] = "KEY_XSTICK2_DOWN",
[129] = "KEY_XSTICK2_LEFT",
[130] = "KEY_XSTICK2_RIGHT"
}
--A list of all mouse keys, for binding
Jing.MouseKeys = {
[107] = "MOUSE_LEFT",
[108] = "MOUSE_RIGHT",
[109] = "MOUSE_MIDDLE",
[110] = "MOUSE_4",
[111] = "MOUSE_5"
}
--Tells me if a specific key is pressed. Loops through both tables.
Jing.KeyPressed = function(key)
	if Jing.InChat then return false end
	
	for k = 107, 111 do
		if key == Jing.MouseKeys[k] then
			if input.IsMouseDown(k) then
				return true
			else
				return false
			end
		end
	end
	
	for k = 0, 130 do
		if key == Jing.Keys[k] then
			if input.IsKeyDown(k) then
				return true
			else
				return false
			end
		end
	end
	
	return false
end

--Very simple. If the boolean is true it returns 1. If the boolean is false then it returns 0. I dont think i ended up using this anywhere, but whatever, ill leave it here.
Jing.BoolToInt = function(bool)
	if bool then 
		return 1
	else
		return 0
	end
end

--Checking if a bone is visible, pos is the position of the bone and ent is the entity whos bone were looking for. 
Jing.SpotIsVisible = function(pos, ent)
	ent = ent or Jing.Aimbot.CurTarget
	local tracedata = {}
	tracedata.start = Jing.Ply:GetShootPos()
	tracedata.endpos = pos
	tracedata.filter = {Jing.Ply, ent}
	
	local trace = util.TraceLine(tracedata)
	if trace.HitPos:Distance(pos) < 0.005 then
		return true
	else
		return false
	end
end

--Checks all of the entities bones to find if we can see this entity or not.
Jing.CanSee = function(ent)
	for k = 1, #Jing.Bones do 
		local v = Jing.Bones[k]
		local bone = ent:LookupBone(v)
		if bone != nil then
			local pos, ang = ent:GetBonePosition(bone)
			if Jing.SpotIsVisible(pos, ent) then
				return true
			end
		end
	end
	return false
end

--This returns the next entity we should attack.
Jing.GetTarget = function()
	if Jing.Aimbot.Vars["AttackNPCs"]:GetBool() or Jing.Aimbot.Vars["AttackPlayers"]:GetBool() then
		local targets = {}
		local everything = ents.GetAll()
		for k = 1, #everything do 
			local v = everything[k]
			if Jing.Aimbot.Vars["AttackNPCs"]:GetBool() and v:IsNPC() then
				if Jing.CanSee(v) then
					table.insert(targets, {["Target"] = v, ["Pos"] = v:LocalToWorld(v:OBBCenter())})
				end
			elseif Jing.Aimbot.Vars["AttackPlayers"]:GetBool() and v:IsPlayer() and v != Jing.Ply then
				if Jing.CanSee(v) then
					table.insert(targets, {["Target"] = v, ["Pos"] = v:LocalToWorld(v:OBBCenter())})
				end
			end
		end
		
		for k,v in SortedPairs(targets, true) do --It will already be sorted so this shouldn't be too resource heavy, the main point of this is to loop through the table backwards
			local v = v["Target"]
			local shouldremove = false
			if Jing.Aimbot.Vars["IgnoreTeam"]:GetBool() and v:IsPlayer() then
				if Jing.TTT then
					if Jing.Ply:GetRole() == 1 and v:GetRole() == 1 then
						shouldremove = true
					end
						
					if Jing.Ply:GetRole() != 1 and not table.HasValue(Jing.Traitors, v) then
						shouldremove = true
					end
				else
					if v:Team() == Jing.Ply:Team() then
						shouldremove = true
					end
				end
			end
			
			if Jing.Friends.Vars["Active"]:GetBool() then
				if Jing.Friends.Vars["Reverse"]:GetBool() then
					if not table.HasValue(Jing.Friends.List, v:SteamID()) then
						shouldremove = true
					end
				else
					if table.HasValue(Jing.Friends.List, v:SteamID()) then
						shouldremove = true		
					end
				end
			end
			
			if shouldremove then
				table.remove(targets, k)
			end
		end
		
		if #targets == 0 then 
			return nil
		elseif #targets == 1 then
			targets[1]["Target"].BoneToAimAt = nil
			return targets[1]["Target"]
		end
		
		if Jing.Aimbot.Vars["Preference"]:GetString() == "Distance" then
			local min = {["Distance"] = Jing.Ply:GetPos():Distance(targets[1]["Pos"]), ["Target"] = targets[1]["Target"]}
			for k = 1, #targets do 
				local v = targets[k]
				
				local distance = Jing.Ply:GetPos():Distance(v["Pos"])
				if distance < min["Distance"] then
					min = {["Distance"] = distance, ["Target"] = v["Target"]}
				end
			end
			min["Target"].BoneToAimAt = nil
			return min["Target"]
		elseif Jing.Aimbot.Vars["Preference"]:GetString() == "Angle" then		
			local min = {["Angle"] = Jing.AngleTo(targets[1]["Pos"]), ["Target"] = targets[1]["Target"]}
			for k = 1, #targets do 
				local v = targets[k]
				
				local angle = Jing.AngleTo(v["Pos"])
				if angle < min["Angle"] then
					min = {["Angle"] = angle, ["Target"] = v["Target"]}
				end
			end
			min["Target"].BoneToAimAt = nil
			return min["Target"]
		end
	else
		return nil
	end
end

--This returns the total angle away from the target we are, and then the pitch and yaw seperately
Jing.AngleTo = function(pos)
	local myAngs = Jing.Ply:GetAngles()
	local needed = (pos - Jing.Ply:GetShootPos()):Angle()
	
	myAngs.p = math.NormalizeAngle(myAngs.p)
	needed.p = math.NormalizeAngle(needed.p)
	
	myAngs.y = math.NormalizeAngle(myAngs.y)
	needed.y = math.NormalizeAngle(needed.y)
	
	local p = math.NormalizeAngle(needed.p - myAngs.p)
	local y = math.NormalizeAngle(needed.y - myAngs.y)
	
	return math.abs(p) + math.abs(y), {p = p, y = y}
end

--Returns true if our target meets our Preferences.
Jing.ValidTarget = function()
	if Jing.Aimbot.CurTarget == nil then return false end
	if not IsValid(Jing.Aimbot.CurTarget) then return false end
	if Jing.Aimbot.CurTarget:IsPlayer() and (not Jing.Aimbot.CurTarget:Alive() or Jing.Aimbot.CurTarget:Team() == TEAM_SPECTATOR or Jing.Aimbot.CurTarget:Health() < 1) then return false end
	if not Jing.Aimbot.Vars["AttackNPCs"]:GetBool() and Jing.Aimbot.CurTarget:IsNPC() then return false end
	if not Jing.Aimbot.Vars["AttackPlayers"]:GetBool() and Jing.Aimbot.CurTarget:IsPlayer() then return false end
	if not Jing.CanSee(Jing.Aimbot.CurTarget) then return false end
	if Jing.Aimbot.Vars["IgnoreTeam"]:GetBool() and Jing.Aimbot.CurTarget:IsPlayer() then
		if Jing.TTT then
			if Jing.Ply:GetRole() == 1 and Jing.Aimbot.CurTarget:GetRole() == 1 then return false end				
			if Jing.Ply:GetRole() != 1 and not table.HasValue(Jing.Traitors, Jing.Aimbot.CurTarget) then return false end
		else
			if Jing.Aimbot.CurTarget:Team() == Jing.Ply:Team() then return false end
		end
	end
	
	return true
end

hook.Add("RenderScreenspaceEffects", Jing.RandomName(math.random(10, 15)), function()
	if Jing.Active:GetBool() then
		local everything = ents.GetAll()
		for k = 1, #everything do
			local v = everything[k]
			
			if Jing.Chams.Vars["Active"]:GetBool() and v != Jing.Ply and (Jing.Chams.Vars["MaxDistance"]:GetInt() == 0 or v:GetPos():Distance(Jing.Ply:GetPos()) < Jing.Chams.Vars["MaxDistance"]:GetInt()) then
				cam.Start3D(EyePos(), EyeAngles())
					if (v:IsPlayer() and v:Alive() and v:Team() != TEAM_SPECTATOR and Jing.Chams.Vars["Players"]:GetBool()) or (v:IsNPC() and v:Health() > 0 and Jing.Chams.Vars["NPCs"]:GetBool()) then
						local color = Jing.Style.Vars["Chams"].color
						if Jing.Chams.Vars["TeamBased"]:GetBool() and v:IsPlayer() then
							color = team.GetColor(v:Team())
							if Jing.TTT then
								if v:GetRole() == 2 then
									color = Color(0, 0, 255, 255)
								elseif table.HasValue(Jing.Traitors, v) then
									color = Color(255, 0, 0, 255)
								else
									color = Color(0, 255, 0, 255)
								end
							end
						end
						render.SuppressEngineLighting(true)
						render.SetColorModulation(color.r/255, color.g/255, color.b/255, 1)
						render.MaterialOverride(Jing.Chams.Mat)
						v:DrawModel()
						
						render.SetColorModulation((color.r + 150)/250, (color.g + 150)/250, (color.b + 150)/255, 1)						
						if IsValid(v:GetActiveWeapon()) and Jing.Chams.Vars["Weapons"]:GetBool() then
							v:GetActiveWeapon():DrawModel() 
						end
						
						render.SetColorModulation(1, 1, 1, 1)
						render.MaterialOverride()
						render.SetModelLighting(4, color.r/255, color.g/255, color.b/255)
						v:DrawModel()
						render.SuppressEngineLighting(false)
					elseif Jing.TTT and Jing.Chams.Vars["Bodies"]:GetBool() and v:GetClass() == "prop_ragdoll" then
						local color = Jing.Style.Vars["BodyChams"].color
						render.SuppressEngineLighting(true)	
						render.SetColorModulation(color.r/255, color.g/255, color.b/255, 1)
						render.MaterialOverride(Jing.Chams.Mat)
						v:DrawModel()	
						render.SetColorModulation(1, 1, 1, 1)
						render.MaterialOverride()
						render.SetModelLighting(4, color.r/255, color.g/255, color.b/255)
						v:DrawModel()
						render.SuppressEngineLighting(false)
					elseif Jing.Entities.Vars["Active"]:GetBool() and table.HasValue(Jing.Entities.List, v:GetClass()) then
						local color = Jing.Style.Vars["Chams"].color					
						render.SuppressEngineLighting(true)	
						render.SetColorModulation(color.r/255, color.g/255, color.b/255, 1)
						render.MaterialOverride(Jing.Chams.Mat)
						v:DrawModel()	
						render.SetColorModulation(1, 1, 1, 1)
						render.MaterialOverride()
						render.SetModelLighting(4, color.r/255, color.g/255, color.b/255)
						v:DrawModel()
						render.SuppressEngineLighting(false)
					end
				cam.End3D()
			end
		end
	end
end)

--Helper function on radar. I just copied this one from the wiki.
Jing.DrawFilledCircle = function(x, y, radius, quality)
	local circle = {}
    local tmp = 0
    for i = 1, quality do
        tmp = math.rad(i * 360) / quality 
        circle[i] = {x = x + math.cos(tmp) * radius, y = y + math.sin(tmp) * radius}
    end
	surface.DrawPoly(circle)
end

--Another helper fuction on the radar.
Jing.DrawArrow = function(x, y, myRotation)
	local arrow = {}	
	arrow[1] = {x = x, y = y}
	arrow[2] = {x = x + 4, y = y + 7.5}
	arrow[3] = {x = x, y = y + 5}
	arrow[4] = {x = x - 4, y = y + 7.5}
	
	--Now that i have the arrow determined, i have to rotate it to match the targets angle
	myRotation = myRotation * -1
	myRotation = math.rad(myRotation)
	for i = 1, 4 do
		local theirX = arrow[i].x
		local theirY = arrow[i].y
		
		theirX = theirX - x
		theirY = theirY - y
		
		arrow[i].x = theirX * math.cos(myRotation) - theirY * math.sin(myRotation)
		arrow[i].y = theirX * math.sin(myRotation) + theirY * math.cos(myRotation)
		
		arrow[i].x = arrow[i].x + x
		arrow[i].y = arrow[i].y + y
	end

	surface.DrawPoly(arrow)
end

Jing.Traitors = {}
Jing.SuperAdmins = {}
Jing.Admins = {}
Jing.Spectators = {}
local radarX, radarY, radarWidth, radarHeight = 100, 200, 150, 150
hook.Add("HUDPaint", Jing.RandomName(math.random(10, 15)), function()
	if Jing.Active:GetBool() then	
		local everything = ents.GetAll()
		
		if Jing.ESP.Vars["Active"]:GetBool() and Jing.ESP.Vars["Radar"]:GetBool() then --Setting up the background here. And since the ESP doesnt draw you 
			draw.RoundedBox(0, radarX, radarY, radarWidth, radarHeight, Color(100, 100, 100, 255 ))
			draw.NoTexture()
			if Jing.ESP.Vars["TeamBased"]:GetBool() then
				local color = team.GetColor(Jing.Ply:Team())
				if Jing.TTT then
					if Jing.Ply:GetRole() == 2 then
						color = Color(0, 0, 255, 255)
					elseif Jing.Ply:GetRole() == 1 then
						color = Color(255, 0, 0, 255)
					else
						color = Color(0, 255, 0, 255)
					end
				end
				surface.SetDrawColor(color)
			else
				surface.SetDrawColor(Jing.Style.Vars["ESPText"].color)
			end
			Jing.DrawArrow(radarX + (radarWidth / 2), radarY + (radarHeight / 2), 0)
		end
		
		for k = 1, #everything do
			local v = everything[k]
		
			if Jing.ESP.Vars["Active"]:GetBool() and v != Jing.Ply and (Jing.ESP.Vars["MaxDistance"]:GetInt() == 0 or v:GetPos():Distance(Jing.Ply:GetPos()) < Jing.ESP.Vars["MaxDistance"]:GetInt()) then										
				if (v:IsPlayer() and v:Alive() and v:Team() != TEAM_SPECTATOR and Jing.ESP.Vars["Players"]:GetBool()) or (v:IsNPC() and v:Health() > 0 and Jing.ESP.Vars["NPCs"]:GetBool()) then
					local color = Jing.Style.Vars["ESPText"].color
					if Jing.ESP.Vars["TeamBased"]:GetBool() and v:IsPlayer() then
						color = team.GetColor(v:Team())
						if Jing.TTT then
							if v:GetRole() == 2 then
								color = Color(0, 0, 255, 255)
							elseif table.HasValue(Jing.Traitors, v) then
								color = Color(255, 0, 0, 255)
							else
								color = Color(0, 255, 0, 255)
							end
						end
					end
					
					local Min, Max = v:GetCollisionBounds()
					if Jing.ESP.Vars["Box"]:GetBool() then
						local one = v:LocalToWorld(Min):ToScreen()
						local two = v:LocalToWorld(Vector(Min.x, Min.y, Max.z)):ToScreen()
						local three = v:LocalToWorld(Vector(Min.x, Min.y + (Max.y * 2), Min.z)):ToScreen()
						local four = v:LocalToWorld(Vector(Min.x + (Max.x * 2), Min.y, Min.z)):ToScreen()
						local five = v:LocalToWorld(Max):ToScreen()
						local six = v:LocalToWorld(Vector(Max.x, Max.y, Min.z)):ToScreen()
						local seven = v:LocalToWorld(Vector(Max.x, Max.y + (Min.y * 2), Max.z)):ToScreen()
						local eight = v:LocalToWorld(Vector(Max.x + (Min.x * 2), Max.y, Max.z)):ToScreen()				
						
						if Jing.ESP.Vars["TeamBased"]:GetBool() then
							surface.SetDrawColor(color)
						else
							surface.SetDrawColor(Jing.Style.Vars["BoundingBox"].color)
						end
						local function connect(tabone, tabtwo)
							surface.DrawLine(tabone.x, tabone.y, tabtwo.x, tabtwo.y)
						end
						
						connect(one, two)
						connect(three, eight)
						connect(four, seven)
						connect(six, five)
						connect(four, six)
						connect(four, one)
						connect(one, three)
						connect(three, six)
						connect(five, eight)
						connect(eight, two)
						connect(two, seven)
						connect(seven, five)
					end
					
					surface.SetFont("ESPFont")
					local top = v:GetPos() + Vector(0, 0, Max.z + 10) -- A little above their head so its not constantly covering their face.
					local topscreen = top:ToScreen()
					local topy = topscreen.y
					
					local bottom = v:GetPos()
					local bottomscreen = bottom:ToScreen()
					local bottomy = bottomscreen.y
					
					local function DrawAbove(text)
						local W, H = surface.GetTextSize(text)
						surface.SetTextPos(topscreen.x - W / 2, topy) 
						surface.DrawText(text)
						
						topy = topy + H
					end
					
					local function DrawBelow(text)
						local W, H = surface.GetTextSize(text)
						surface.SetTextPos(bottomscreen.x - W / 2, bottomy) 
						surface.DrawText(text)
						
						bottomy = bottomy + H
					end
					
					surface.SetTextColor(Color(255, 0, 0, 255))
					if Jing.ESP.Vars["ShowTraitors"]:GetString() != "Off" and table.HasValue(Jing.Traitors, v) then
						if Jing.ESP.Vars["ShowTraitors"]:GetString() == "Above" then
							DrawAbove("Traitor")
						else
							DrawBelow("Traitor")
						end
					end
					
					surface.SetTextColor(color)
					if v:IsPlayer() then
						if Jing.ESP.Vars["Name"]:GetString() == "Above" then
							DrawAbove("Name: "..v:Nick())
						elseif Jing.ESP.Vars["Name"]:GetString() == "Below" then
							DrawBelow("Name: "..v:Nick())
						end
					else
						if Jing.ESP.Vars["Name"]:GetString() == "Above" then
							DrawAbove("Name: "..v:GetClass())
						elseif Jing.ESP.Vars["Name"]:GetString() == "Below" then
							DrawBelow("Name: "..v:GetClass())
						end
					end
					
					if Jing.ESP.Vars["Weapons"]:GetString() == "Above" and IsValid(v:GetActiveWeapon()) then
						DrawAbove("Weapon: "..v:GetActiveWeapon():GetClass()) 
					elseif Jing.ESP.Vars["Weapons"]:GetString() == "Below" and IsValid(v:GetActiveWeapon()) then
						DrawBelow("Weapon: "..v:GetActiveWeapon():GetClass()) 
					end		
					
					if Jing.ESP.Vars["Distance"]:GetString() == "Above" then 
						DrawAbove("Distance: "..bottom:Distance(Jing.Ply:GetPos())) 
					elseif Jing.ESP.Vars["Distance"]:GetString() == "Below" then
						DrawBelow("Distance: "..bottom:Distance(Jing.Ply:GetPos())) 
					end	
					
					if Jing.ESP.Vars["Health"]:GetString() == "Above" then 
						DrawAbove("HP: "..v:Health()) 
					elseif Jing.ESP.Vars["Health"]:GetString() == "Below" then
						DrawBelow("HP: "..v:Health()) 
					end
					
					if Jing.ESP.Vars["Radar"]:GetBool() then
						surface.SetDrawColor(color)
						local myPos = Jing.Ply:GetPos()
						local theirPos = v:GetPos()
						local myAngles = Jing.Ply:GetAngles()
						
						local theirX = (radarX + (radarWidth / 2)) + ((theirPos.x - myPos.x) / Jing.ESP.Vars["RadarScale"]:GetInt())
						local theirY = (radarY + (radarHeight / 2)) + ((myPos.y - theirPos.y) / Jing.ESP.Vars["RadarScale"]:GetInt())
						
						--Now i have to rotate this
						local myRotation = myAngles.y - 90
						myRotation = math.rad(myRotation)
						
						theirX = theirX - (radarX + (radarWidth / 2))
						theirY = theirY - (radarY + (radarHeight / 2))
						local newX = theirX * math.cos(myRotation) - theirY * math.sin(myRotation)
						local newY = theirX * math.sin(myRotation) + theirY * math.cos(myRotation)
						newX = newX + (radarX + (radarWidth / 2))
						newY = newY + (radarY + (radarHeight / 2))
						
						--And now that its rotated i can check if its within our radars bounds and draw it
						if newX < (radarX + radarWidth) and newX > radarX and newY < (radarY + radarHeight) and newY > radarY then
							Jing.DrawArrow(newX, newY, v:EyeAngles().y - myAngles.y)
						end
					end
				elseif Jing.TTT and Jing.ESP.Vars["Bodies"]:GetBool() and v:GetClass() == "prop_ragdoll" then
					surface.SetFont("ESPFont")
					
					--Im just going to position this info at the center of the player, if i get any complaints ill change it
					local pos = v:LocalToWorld(v:OBBCenter())
					local poscreen = pos:ToScreen()
					local W, H = surface.GetTextSize("Sample") --It doesnt have to be perfect but this will help center the text more.
					local y = poscreen.y - (H * 1.5)
					
					local function DrawText(text)
						local W, H = surface.GetTextSize(text)
						surface.SetTextPos(poscreen.x - W / 2, y) 
						surface.DrawText(text)
						
						y = y + H
					end
					
					surface.SetTextColor(Jing.Style.Vars["BodyText"].color)
					DrawText("Credits: "..Jing.TTTCORPSE.GetCredits(v, 0))
					DrawText("Name: "..Jing.TTTCORPSE.GetPlayerNick(v, "Unknown"))
					DrawText("Found: "..tostring(Jing.TTTCORPSE.GetFound(v, false)))
					
					if Jing.ESP.Vars["Radar"] then
						surface.SetDrawColor(Jing.Style.Vars["BodyText"].color)
						local myPos = Jing.Ply:GetPos()
						local theirPos = v:GetPos()
						
						local theirX = (radarX + (radarWidth / 2)) + ((theirPos.x - myPos.x) / Jing.ESP.Vars["RadarScale"]:GetInt())
						local theirY = (radarY + (radarHeight / 2)) + ((myPos.y - theirPos.y) / Jing.ESP.Vars["RadarScale"]:GetInt())
						
						--Now i have to rotate this
						local myRotation = Jing.Ply:GetAngles().y - 90
						myRotation = math.rad(myRotation)
						
						theirX = theirX - (radarX + (radarWidth / 2))
						theirY = theirY - (radarY + (radarHeight / 2))
						local newX = theirX * math.cos(myRotation) - theirY * math.sin(myRotation)
						local newY = theirX * math.sin(myRotation) + theirY * math.cos(myRotation)
						newX = newX + (radarX + (radarWidth / 2))
						newY = newY + (radarY + (radarHeight / 2))
						
						--And now that its rotated i can check if its within our radars bounds and draw it
						if newX < (radarX + radarWidth) and newX > radarX and newY < (radarY + radarHeight) and newY > radarY then
							Jing.DrawFilledCircle(newX, newY, 2, 4)
						end
					end
				elseif Jing.Entities.Vars["Active"]:GetBool() and table.HasValue(Jing.Entities.List, v:GetClass()) then
					surface.SetFont("ESPFont")
					surface.SetTextColor(Jing.Style.Vars["ESPText"].color)
					
					local text = v:GetClass()
					local W, H = surface.GetTextSize(text)
					
					local PosScreen = v:GetPos():ToScreen()
					surface.SetTextPos(PosScreen.x - W / 2, PosScreen.y) 
					surface.DrawText(text)
				end
			end
			
			surface.SetFont("default")
			if v:IsPlayer() and v:IsSuperAdmin() then
				if not table.HasValue(Jing.SuperAdmins, v) then
					table.insert(Jing.SuperAdmins, v) 
					Jing.Message("Super Admin "..v:Nick().." joined the game.")
					if Jing.Misc.Vars["Sounds"]:GetBool() then
						surface.PlaySound("vo/npc/Alyx/watchout02.wav")
					end	
				end
			end			
			if v:IsPlayer() and v:IsAdmin() and not v:IsSuperAdmin() then
				if not table.HasValue(Jing.Admins, v) then
					table.insert(Jing.Admins, v)
					Jing.Message("Admin "..v:Nick().." joined the game.")
					if Jing.Misc.Vars["Sounds"]:GetBool() then
						surface.PlaySound("vo/npc/Alyx/watchout01.wav")
					end	
				end
			end		
			for k,v in SortedPairs(Jing.Admins, true) do
				if not IsValid(v) then
					table.remove(Jing.Admins, k)
				end
			end
			for k,v in SortedPairs(Jing.SuperAdmins, true) do
				if not IsValid(v) then
					table.remove(Jing.SuperAdmins, k)
				end
			end
				
			if v:IsPlayer() and v:GetObserverTarget() == Jing.Ply then
				if not table.HasValue(Jing.Spectators, v) then
					table.insert(Jing.Spectators, v)
					Jing.Message(v:Nick().." started spectating you.")
					if Jing.Misc.Vars["Sounds"]:GetBool() then
						surface.PlaySound("vo/npc/female01/ohno.wav")
					end				
				end
			end
			for k,v in SortedPairs(Jing.Spectators, true) do
				if IsValid(v) then
					if v:GetObserverTarget() != Jing.Ply then
						table.remove(Jing.Spectators, k)
					end
				else
					table.remove(Jing.Spectators, k)
				end
			end
			
			if Jing.TTT and Jing.Misc.Vars["TraitorFinder"]:GetBool() then
				if GetRoundState() == 3 and v:IsWeapon() and type(v:GetOwner()) == "Player" and v.Buyer == nil and v.CanBuy and table.HasValue(v.CanBuy, 1) then
					local owner = v:GetOwner()
					if owner:GetRole() == 2 then
						v.Buyer = owner
					else
						Jing.Message(owner:Nick().." bought a traitor weapon: "..v:GetClass())
						v.Buyer = owner
						table.insert(Jing.Traitors, owner)
						if Jing.Misc.Vars["Sounds"]:GetBool() then
							surface.PlaySound("weapons/shotgun/shotgun_cock.wav")
						end	
					end
				elseif GetRoundState() != 3 then
					table.Empty(Jing.Traitors)
				end
			end
			
			if Jing.Misc.Vars["Deaths"]:GetBool() and v:IsPlayer() then
				if v:Alive() then
					v.IsAlive = true
				elseif v.IsAlive then
					Jing.Message(3, v:Nick().." just died.")
					v.IsAlive = false
					if Jing.Misc.Vars["Sounds"]:GetBool() then
						surface.PlaySound("npc/combine_soldier/vo/onedown.wav")
					end	
				end				
			end
		end
		
		surface.SetFont("default")
		surface.SetTextColor(Color(255, 255, 255, 255))	
		local AdminWidest = 0
		local AdminTotalHeight = 0
		local AdminHeight = 20
		if Jing.Misc.Vars["ShowAdmins"]:GetBool() then 
			for k,v in pairs(Jing.SuperAdmins) do
				local W, H = surface.GetTextSize(v:Nick().." - Super Admin")
				if W > AdminWidest then
					AdminWidest = W
				end
				AdminTotalHeight = AdminTotalHeight + H
			end
			for k,v in pairs(Jing.Admins) do
				local W, H = surface.GetTextSize(v:Nick().." - Admin")
				if W > AdminWidest then
					AdminWidest = W
				end
				AdminTotalHeight = AdminTotalHeight + H
			end
			draw.RoundedBox(8, ScrW() - AdminWidest - 30, 10, AdminWidest + 20, AdminTotalHeight + 20, Color(0, 0, 0, 150 ))
			for k,v in pairs(Jing.SuperAdmins) do
				local text = v:Nick().." - Super Admin"
				local W, H = surface.GetTextSize(text)
				surface.SetTextPos(ScrW() - 20 - AdminWidest, AdminHeight)
				surface.DrawText(text)
				AdminHeight = AdminHeight + H
			end
			for k,v in pairs(Jing.Admins) do
				local text = v:Nick().." - Admin"
				local W, H = surface.GetTextSize(text)
				surface.SetTextPos(ScrW() - 20 - AdminWidest, AdminHeight)
				surface.DrawText(text)
				AdminHeight = AdminHeight + H
			end
		end
		
		local SpecWidest = 0
		local SpecTotalHeight = 0
		local SpecHeight = AdminTotalHeight + 50
		if Jing.Misc.Vars["ShowSpectators"]:GetBool() then
			for k,v in pairs(Jing.Spectators) do
				local W, H = surface.GetTextSize(v:Nick())
				if W > SpecWidest then
					SpecWidest = W
				end
				SpecTotalHeight = SpecTotalHeight + H
			end
			draw.RoundedBox(8, ScrW() - SpecWidest - 30, 40 + AdminTotalHeight, SpecWidest + 20, SpecTotalHeight + 20, Color(0, 0, 0, 150 ))
			for k,v in pairs(Jing.Spectators) do
				local text = v:Nick()
				local W, H = surface.GetTextSize(text)
				surface.SetTextPos(ScrW() - 20 - SpecWidest, SpecHeight)
				surface.DrawText(text)
				SpecHeight = SpecHeight + H
			end
		end
		
		if Jing.Misc.Vars["Crosshair"]:GetBool() then
			local size = Jing.Misc.Vars["CrosshairSize"]:GetInt()
			local MiddleScreen = {x = surface.ScreenWidth() / 2, y = surface.ScreenHeight() / 2}
			surface.SetDrawColor(Jing.Style.Vars["Crosshair"].color)
			surface.DrawLine(MiddleScreen.x, MiddleScreen.y, MiddleScreen.x - size, MiddleScreen.y)
			surface.DrawLine(MiddleScreen.x, MiddleScreen.y, MiddleScreen.x, MiddleScreen.y - size)
			surface.DrawLine(MiddleScreen.x, MiddleScreen.y, MiddleScreen.x + size, MiddleScreen.y)
			surface.DrawLine(MiddleScreen.x, MiddleScreen.y, MiddleScreen.x, MiddleScreen.y + size)
		end
	end
end)

hook.Add("Think", Jing.RandomName(math.random(10, 15)), function()
	if Jing.Active:GetBool() then	
		if Jing.Aimbot.Vars["Active"]:GetBool() and not (Jing.Aimbot.Vars["PanicMode"]:GetBool() and #Jing.Spectators > 0) then
			if not Jing.Aimbot.Vars["AimOnKey"]:GetBool() or (Jing.Aimbot.Vars["AimOnKey"]:GetBool() and Jing.KeyPressed(Jing.Aimbot.Vars["AimOnKey_Key"]:GetString())) then
				if Jing.ValidTarget() then
					local BoneOrder = {}
					if Jing.Aimbot.CurTarget.BoneToAimAt and Jing.Aimbot.Vars["RandomBones"]:GetBool() then
						table.insert(BoneOrder, Jing.Aimbot.CurTarget.BoneToAimAt)
						table.Add(BoneOrder, Jing.GetRandomBones())
						table.Add(BoneOrder, Jing.Bones)
					else
						if Jing.Aimbot.Vars["RandomBones"]:GetBool() then
							table.Add(BoneOrder, Jing.GetRandomBones())
							table.Add(BoneOrder, Jing.Bones)
						else
							table.Add(BoneOrder, Jing.Bones)
						end
					end
					for k = 1, #BoneOrder do 
						local v = BoneOrder[k]
						local bone = Jing.Aimbot.CurTarget:LookupBone(v)
						if bone != nil then
							local pos, ang = Jing.Aimbot.CurTarget:GetBonePosition(bone)
							if v == "ValveBiped.Bip01_Head1" then
								pos = pos + Vector(0, 0, 3) --Aiming a little higher for the head
							end
							local total, needed = 300, {300, 300}
							
							if Jing.Aimbot.Vars["Prediction"]:GetBool() then
								local tarSpeed = Jing.Aimbot.CurTarget:GetVelocity() * 0.013
								local plySpeed = Jing.Ply:GetVelocity() * 0.013
								total, needed = Jing.AngleTo(pos - plySpeed + tarSpeed)
							else
								total, needed = Jing.AngleTo(pos)
							end
								
							if Jing.SpotIsVisible(pos) and total < Jing.Aimbot.Vars["MaxAngle"]:GetInt() then
								local myAngles = Jing.Ply:GetAngles()								
								local NewAngles = Angle(myAngles.p + needed.p, myAngles.y + needed.y, 0)
								
								if Jing.Aimbot.Vars["AntiSnap"]:GetBool() then
									local speed = Jing.Aimbot.Vars["AntiSnapSpeed"]:GetInt()
									NewAngles = (Angle(math.Approach(myAngles.p, NewAngles.p, speed), math.Approach(myAngles.y, NewAngles.y, speed), 0))
								end
								
								Jing.Ply:SetEyeAngles(NewAngles)
								Jing.Aimbot.CurTarget.BoneToAimAt = BoneOrder[k]
								break
							end
						end
					end
				else
					Jing.Aimbot.CurTarget = Jing.GetTarget()
				end
			else
				Jing.Aimbot.CurTarget = nil
			end
		end
		
		if Jing.Misc.Vars["NoRecoil"]:GetBool() then
			if IsValid(Jing.Ply:GetActiveWeapon()) then
				local weapon = Jing.Ply:GetActiveWeapon()
				if weapon.Primary then
					weapon.OldRecoil = weapon.OldRecoil or weapon.Primary.Recoil or weapon.Recoil
					weapon.Primary.Recoil = 0
					weapon.Recoil = 0
				else
					weapon.OldRecoil = weapon.OldRecoil or weapon.Recoil
					weapon.Recoil = 0
				end
			end
		elseif IsValid(Jing.Ply:GetActiveWeapon()) then
			local weapon = Jing.Ply:GetActiveWeapon()
			if weapon.Primary then
				weapon.Primary.Recoil = weapon.OldRecoil or weapon.Primary.Recoil or weapon.Recoil
				weapon.Recoil = weapon.OldRecoil or weapon.Recoil or weapon.Primary.Recoil
			else
				weapon.Recoil = weapon.OldRecoil or weapon.Recoil
			end
		end
		
		if Jing.DarkRP and Jing.Misc.Vars["BuyHealth"]:GetBool() then
			if Jing.Ply:Alive() and Jing.Ply:Health() < Jing.Misc.Vars["BuyHealth_Minimum"]:GetInt() then
				Jing.Ply:ConCommand("say /buyhealth")
			end
		end
	end
end)

Jing.Misc.NextReload = CurTime()
Jing.Misc.ShootNext = true
hook.Add("CreateMove", Jing.RandomName(math.random(10, 15)), function(cmd)
	if Jing.Active:GetBool() then		
		local DontShoot = {"gmod_tool", "gmod_camera", "weapon_physgun", "weapon_physcannon"}
		if Jing.Aimbot.Vars["AutoShoot"]:GetBool() and Jing.Aimbot.Vars["Active"]:GetBool() and Jing.Ply:GetEyeTrace().Entity == Jing.Aimbot.CurTarget and IsValid(Jing.Ply:GetActiveWeapon()) and not table.HasValue(DontShoot, Jing.Ply:GetActiveWeapon():GetClass()) then
			cmd:SetButtons(cmd:GetButtons() + IN_ATTACK)
		end
		
		if Jing.Misc.Vars["BunnyHop"]:GetBool() and cmd:KeyDown(IN_JUMP) and Jing.KeyPressed(Jing.Misc.Vars["BunnyHop_Key"]:GetString()) then
			cmd:SetButtons(cmd:GetButtons() - IN_JUMP)
		end
		if Jing.Misc.Vars["BunnyHop"]:GetBool() and Jing.Ply:OnGround() and Jing.KeyPressed(Jing.Misc.Vars["BunnyHop_Key"]:GetString()) then
			cmd:SetButtons(cmd:GetButtons() + IN_JUMP)
		end
	
		local DontReload = {"gmod_tool", "gmod_camera", "weapon_physgun", "weapon_physcannon", "weapon_crowbar"}
		if Jing.Misc.Vars["AutoReload"]:GetBool() and IsValid(Jing.Ply:GetActiveWeapon()) and Jing.Ply:GetActiveWeapon():Clip1() < 1 and not table.HasValue(DontReload, Jing.Ply:GetActiveWeapon():GetClass()) and Jing.Misc.NextReload < CurTime() then
			cmd:SetButtons(cmd:GetButtons() + IN_RELOAD)
		end
		
		if Jing.Misc.Vars["AutoPistol"]:GetBool() and IsValid(Jing.Ply:GetActiveWeapon()) then
			local weapon = Jing.Ply:GetActiveWeapon()
			if weapon.Primary and type(weapon.Primary.Automatic) == "boolean" and not weapon.Primary.Automatic then
				if cmd:KeyDown(IN_ATTACK) then
					if Jing.Misc.ShootNext then
						Jing.Misc.ShootNext = false
					else
						cmd:SetButtons(cmd:GetButtons() - IN_ATTACK)
						Jing.Misc.ShootNext = true
					end
				end					
			elseif type(weapon.Automatic) == "boolean" and not weapon.Automatic then
				if cmd:KeyDown(IN_ATTACK) then
					if Jing.Misc.ShootNext then
						Jing.Misc.ShootNext = false
					else
						cmd:SetButtons(cmd:GetButtons() - IN_ATTACK)
						Jing.Misc.ShootNext = true
					end
				end
			end
		end
	end
end)

--Used to see if the player is typing in chat or not. Binds arent called when you're in chat.
Jing.InChat = false
hook.Add("StartChat", Jing.RandomName(math.random(10, 15)), function()
	Jing.InChat = true
end)
hook.Add("FinishChat", Jing.RandomName(math.random(10, 15)), function()
	Jing.InChat = false
end) 

concommand.Add("Jing_Menu", function()
	--Im only using DColumnSheet because everyone used DPropertySheet. I just want to be different
	local main = vgui.Create("DFrame")
	main:SetSize(500,496)
	main:Center()
	main:SetTitle("")
	main:MakePopup()
	main:ShowCloseButton(false)
	main.Paint = function()
		draw.RoundedBox( 0, 0, 0, main:GetWide(), main:GetTall(), Color( 0, 0, 0, 150 ) )
	end
	
	local PanicButton = vgui.Create("DButton", main)
	PanicButton:SetSize(50, 20)
	PanicButton:SetPos(415, 3)
	local function Enable()
		PanicButton:SetText("Disable")
		PanicButton.DoClick = function()
			PanicButton:SetText("Enable")
			PanicButton.DoClick = Enable
			Jing.Ply:ConCommand("Jing_Active 0")
		end
		Jing.Ply:ConCommand("Jing_Active 1")
	end
	local function Disable()
		PanicButton:SetText("Enable")
		PanicButton.DoClick = function()
			PanicButton:SetText("Disable")
			PanicButton.DoClick = Disable
			Jing.Ply:ConCommand("Jing_Active 1")
		end
		Jing.Ply:ConCommand("Jing_Active 0")
	end
	if Jing.Active:GetBool() then
		PanicButton:SetText("Disable")
		PanicButton.DoClick = Disable
	else
		PanicButton:SetText("Enable")
		PanicButton.DoClick = Enable
	end
	
	local CloseButton = vgui.Create("DButton", main)
	CloseButton:SetSize(30, 20)
	CloseButton:SetPos(465, 3)
	CloseButton:SetText("X")
	CloseButton.DoClick = function()
		main:Close()
	end
	
	local title = vgui.Create("DLabel", main)
	title:SetColor(Color(255, 255, 255, 255))
	title:SetFont("TitleFont")
	title:SetText("Jing - "..Jing.Version)
	title:SizeToContents()
	title:SetPos(main:GetWide() / 2 - title:GetWide() / 2,3)	
	
	ColumnSheet = vgui.Create("DColumnSheet",main)
	ColumnSheet:SetPos(5, 25)
	ColumnSheet:SetSize(500 ,465)
	
	local y = 40
	local function ToggleOption(name, parent, var)
		local Options = vgui.Create("DComboBox", parent)
		Options:SetSize(100, 20)
		Options:SetPos(parent:GetWide() * 0.75 - Options:GetWide() / 2, y)
		Options:AddChoice("Off", 0)
		Options:AddChoice("On", 1)
		Options.OnSelect = function(panel,index,value,data)
			Jing.Ply:ConCommand(var.." "..data)
		end
		Options:SetText(Options:GetOptionText(GetConVar(var):GetInt() + 1))
		
		local text = vgui.Create("DLabel", parent)
		text:SetColor(Color(0, 0, 0, 255))
		text:SetFont("CatagoryText")
		text:SetText(name)
		text:SizeToContents()
		text:SetPos(parent:GetWide() / 4 - text:GetWide() / 2, y + Options:GetTall() / 2 - text:GetTall() / 2)
		
		y = y + Options:GetTall() + 20
	end
	
	local function SetKeyOption(name, parent, var)		
		local Options = vgui.Create("DButton", parent)
		Options:SetSize(100, 20)
		Options:SetPos(parent:GetWide() * 0.75 - Options:GetWide() / 2, y)
		Options:SetText(GetConVar(var):GetString())
		Options.DoClick = function()
			Options:SetText("Press a key...")
			Options.Think = function()
				for k = 107, 111 do
					if input.IsMouseDown(k) then
						Jing.Ply:ConCommand(var.." "..Jing.MouseKeys[k])
						Options:SetText(Jing.MouseKeys[k])
						Options.Think = nil
					end
				end
				
				for k = 0, 130 do
					if input.IsKeyDown(k) then
						Jing.Ply:ConCommand(var.." "..Jing.Keys[k])
						Options:SetText(Jing.Keys[k])
						Options.Think = nil
					end
				end 
			end
		end
		
		local text = vgui.Create("DLabel", parent)
		text:SetColor(Color(0, 0, 0, 255))
		text:SetFont("CatagoryText")
		text:SetText(name)
		text:SizeToContents()
		text:SetPos(parent:GetWide() / 4 - text:GetWide() / 2, y + Options:GetTall() / 2 - text:GetTall() / 2)
		
		y = y + Options:GetTall() + 20
	end
	
	local function SetNumberOption(name, parent, var, min, max, decimals)		
		local Options = vgui.Create("DNumberWang", parent)
		Options:SetSize(100, 20)
		Options:SetPos(parent:GetWide() * 0.75 - Options:GetWide() / 2, y)
		Options:SetMin(min)
		Options:SetMax(max)
		Options:SetDecimals(decimals)
		Options:SetConVar(var)
		
		local text = vgui.Create("DLabel", parent)
		text:SetColor(Color(0, 0, 0, 255))
		text:SetFont("CatagoryText")
		text:SetText(name)
		text:SizeToContents()
		text:SetPos(parent:GetWide() / 4 - text:GetWide() / 2, y + Options:GetTall() / 2 - text:GetTall() / 2)
		
		y = y + Options:GetTall() + 20
	end
	
	local function MultiOption(name, parent, var, tab)		
		local Options = vgui.Create("DComboBox", parent)
		Options:SetSize(100, 20)
		Options:SetPos(parent:GetWide() * 0.75 - Options:GetWide() / 2, y)
		for i = 1, #tab do
			Options:AddChoice(tab[i])
		end
		Options.OnSelect = function(panel,index,value,data)
			Jing.Ply:ConCommand(var.." "..value)
		end
		Options:SetText(GetConVar(var):GetString())
		
		local text = vgui.Create("DLabel", parent)
		text:SetColor(Color(0, 0, 0, 255))
		text:SetFont("CatagoryText")
		text:SetText(name)
		text:SizeToContents()
		text:SetPos(parent:GetWide() / 4 - text:GetWide() / 2, y + Options:GetTall() / 2 - text:GetTall() / 2)
		
		y = y + Options:GetTall() + 20
	end
	
	--Starting the Aimbot panel
	local Aimbot = vgui.Create("DPanel")
	Aimbot:SetSize(379, 465)
	Aimbot.Paint = function()
		draw.RoundedBox( 0, 0, 0, Aimbot:GetWide(), Aimbot:GetTall(), Color( 240, 240, 240, 255 ) )
	end
	
	local title = vgui.Create("DLabel", Aimbot)
	title:SetColor(Color(0, 0, 0, 255))
	title:SetFont("CatagoryHeader")
	title:SetText("Aimbot")
	title:SizeToContents()
	title:SetPos(Aimbot:GetWide() / 2 - title:GetWide() / 2, 0)
	
	ToggleOption("Active", Aimbot, "Jing_Aimbot_Active")
	ToggleOption("Random Bones", Aimbot, "Jing_Aimbot_RandomBones")
	MultiOption("Preference", Aimbot, "Jing_Aimbot_Preference", {"Distance", "Angle"})	
	ToggleOption("Attack Players", Aimbot, "Jing_Aimbot_AttackPlayers")
	ToggleOption("Attack NPCs", Aimbot, "Jing_Aimbot_AttackNPCs")
	ToggleOption("Prediction", Aimbot, "Jing_Aimbot_Prediction")
	ToggleOption("Aim On Key", Aimbot, "Jing_Aimbot_AimOnKey")
	SetKeyOption("Key", Aimbot, "Jing_Aimbot_AimOnKey_Key")
	ToggleOption("Anti Snap", Aimbot, "Jing_Aimbot_AntiSnap")
	SetNumberOption("Anti Snap Speed", Aimbot, "Jing_Aimbot_AntiSnapSpeed", 1, 5, 2)
	SetNumberOption("Max Angle", Aimbot, "Jing_Aimbot_MaxAngle", 0, 270, 0)
	ToggleOption("Auto Shoot", Aimbot, "Jing_Aimbot_AutoShoot")
	ToggleOption("Panic Mode", Aimbot, "Jing_Aimbot_PanicMode")
	ToggleOption("Ignore Team", Aimbot, "Jing_Aimbot_IgnoreTeam")
	
	if y > 465 then
		Aimbot:SetTall(y)
	end
	
	--This is the best way i can find to add a scrollbar to the menu...
	AimbotList = vgui.Create( "DPanelList" )
	AimbotList:SetSize(379, 465)
	AimbotList:SetSpacing(0)
	AimbotList:EnableHorizontal(false)
	AimbotList:EnableVerticalScrollbar(true)
	AimbotList:AddItem(Aimbot)
	
	ColumnSheet:AddSheet("Aimbot", AimbotList, "icon16/application_xp_terminal.png")
	
	--Starting the Friends panel
	local FriendsPanel = vgui.Create("DPanel")
	FriendsPanel:SetSize(379, 465)
	FriendsPanel.Paint = function()
		draw.RoundedBox( 0, 0, 0, FriendsPanel:GetWide(), FriendsPanel:GetTall(), Color( 240, 240, 240, 255 ) )
	end
	
	local title = vgui.Create("DLabel", FriendsPanel)
	title:SetColor(Color(0, 0, 0, 255))
	title:SetFont("CatagoryHeader")
	title:SetText("Friends")
	title:SizeToContents()
	title:SetPos(FriendsPanel:GetWide() / 2 - title:GetWide() / 2, 3)
	
	local Friends = {}
	local Enemies = {}
	
	local players = player.GetAll()
	for k = 1, #players do
		local v = players[k]
		if v != Jing.Ply then
			if table.HasValue(Jing.Friends.List, v:SteamID()) then
				table.insert(Friends, v)
			else
				table.insert(Enemies, v)
			end
		end
	end
	
	y = 40
	local EnemiesList = vgui.Create("DListView", FriendsPanel) --Need this up here so FriendsList can reference it.	
	local FriendsList = vgui.Create("DListView", FriendsPanel)
	FriendsList:SetSize(150, 200)
	FriendsList:SetPos(FriendsPanel:GetWide() * 0.25 - FriendsList:GetWide() / 2, y)
	FriendsList:SetMultiSelect(false)
	FriendsList:AddColumn("Friends")
	for k = 1, #Friends do
		FriendsList:AddLine(Friends[k]:Nick())
	end
	FriendsList.DoDoubleClick = function(panel, index, line)
		table.insert(Enemies, Friends[index])
		table.remove(Friends, index)
		
		FriendsList:Clear()
		EnemiesList:Clear()
		for k = 1, #Friends do
			FriendsList:AddLine(Friends[k]:Nick())
		end
		for k = 1, #Enemies do
			EnemiesList:AddLine(Enemies[k]:Nick())
		end
		
		Jing.Friends.List = {}
		for k = 1, #Friends do
			table.insert(Jing.Friends.List, Friends[k]:SteamID())
		end
		--Jing.SaveData()
	end
	
	EnemiesList:SetSize(150, 200)
	EnemiesList:SetPos(FriendsPanel:GetWide() * 0.75 - EnemiesList:GetWide() / 2, y)
	EnemiesList:SetMultiSelect(false)
	EnemiesList:AddColumn("Enemies")
	for k = 1, #Enemies do
		EnemiesList:AddLine(Enemies[k]:Nick())
	end
	EnemiesList.DoDoubleClick = function(panel, index, line)
		table.insert(Friends, Enemies[index])
		table.remove(Enemies, index)
		
		FriendsList:Clear()
		EnemiesList:Clear()
		for k = 1, #Friends do
			FriendsList:AddLine(Friends[k]:Nick())
		end
		for k = 1, #Enemies do
			EnemiesList:AddLine(Enemies[k]:Nick())
		end
		
		Jing.Friends.List = {}
		for k = 1, #Friends do
			table.insert(Jing.Friends.List, Friends[k]:SteamID())
		end
		--Jing.SaveData()
	end
	
	y = y + EnemiesList:GetTall() + 20
	ToggleOption("Use", FriendsPanel, "Jing_Friends_Active")
	ToggleOption("Reverse", FriendsPanel, "Jing_Friends_Reverse")
	
	if y > 465 then
		FriendsPanel:SetTall(y)
	end
	
	local FriendsPanelList = vgui.Create( "DPanelList" )
	FriendsPanelList:SetSize(379, 465)
	FriendsPanelList:SetSpacing(0)
	FriendsPanelList:EnableHorizontal(false)
	FriendsPanelList:EnableVerticalScrollbar(true)
	FriendsPanelList:AddItem(FriendsPanel)
	
	ColumnSheet:AddSheet("Friends", FriendsPanelList, "icon16/group.png")

	--Starting the ESP panel
	local ESP = vgui.Create("DPanel")
	ESP:SetSize(379, 465)
	ESP.Paint = function()
		draw.RoundedBox( 0, 0, 0, ESP:GetWide(), ESP:GetTall(), Color( 240, 240, 240, 255 ) )
	end
	
	local title = vgui.Create("DLabel", ESP)
	title:SetColor(Color(0, 0, 0, 255))
	title:SetFont("CatagoryHeader")
	title:SetText("ESP")
	title:SizeToContents()
	title:SetPos(ESP:GetWide() / 2 - title:GetWide() / 2, 3)
	
	y = 40
	ToggleOption("Active", ESP, "Jing_ESP_Active")
	ToggleOption("Player Info", ESP, "Jing_ESP_Players")
	ToggleOption("NPC Info", ESP, "Jing_ESP_NPCs")
	MultiOption("Name", ESP, "Jing_ESP_Name", {"Off", "Above", "Below"})	
	MultiOption("Weapon", ESP, "Jing_ESP_Weapons", {"Off", "Above", "Below"})	
	MultiOption("Health", ESP, "Jing_ESP_Health", {"Off", "Above", "Below"})	
	MultiOption("Distance", ESP, "Jing_ESP_Distance", {"Off", "Above", "Below"})
	MultiOption("Show Traitors", ESP, "Jing_ESP_ShowTraitors", {"Off", "Above", "Below"})
	ToggleOption("Bounding Box", ESP, "Jing_ESP_Box")
	ToggleOption("Body Info", ESP, "Jing_ESP_Bodies")
	ToggleOption("2D Radar", ESP, "Jing_ESP_Radar")
	SetNumberOption("Radar Scale", ESP, "Jing_ESP_RadarScale", 1, 100, 0)
	SetNumberOption("Max Distance", ESP, "Jing_ESP_MaxDistance", 0, 8000, 0)
	ToggleOption("Team Based", ESP, "Jing_ESP_TeamBased")
	
	if y > 465 then
		ESP:SetTall(y)
	end
	
	ESPList = vgui.Create( "DPanelList" )
	ESPList:SetSize(379, 465)
	ESPList:SetSpacing(0)
	ESPList:EnableHorizontal(false)
	ESPList:EnableVerticalScrollbar(true)
	ESPList:AddItem(ESP)
	
	ColumnSheet:AddSheet("ESP", ESPList, "icon16/pencil.png")
	
	--Starting the Chams panel
	local Chams = vgui.Create("DPanel")
	Chams:SetSize(379, 465)
	Chams.Paint = function()
		draw.RoundedBox( 0, 0, 0, Chams:GetWide(), Chams:GetTall(), Color( 240, 240, 240, 255 ) )
	end
	
	local title = vgui.Create("DLabel", Chams)
	title:SetColor(Color(0, 0, 0, 255))
	title:SetFont("CatagoryHeader")
	title:SetText("Chams")
	title:SizeToContents()
	title:SetPos(Chams:GetWide() / 2 - title:GetWide() / 2, 3)
	
	y = 40
	ToggleOption("Active", Chams, "Jing_Chams_Active")
	ToggleOption("Draw Players", Chams, "Jing_Chams_Players")
	ToggleOption("Draw NPCs", Chams, "Jing_Chams_NPCs")
	ToggleOption("Draw Weapons", Chams, "Jing_Chams_Weapons")
	ToggleOption("Draw Bodies", Chams, "Jing_Chams_Bodies")
	ToggleOption("Team Based", Chams, "Jing_Chams_TeamBased")
	SetNumberOption("Max Distance", Chams, "Jing_Chams_MaxDistance", 0, 8000, 0)
	
	if y > 465 then
		Chams:SetTall(y)
	end
	
	ChamsList = vgui.Create( "DPanelList" )
	ChamsList:SetSize(379, 465)
	ChamsList:SetSpacing(0)
	ChamsList:EnableHorizontal(false)
	ChamsList:EnableVerticalScrollbar(true)
	ChamsList:AddItem(Chams)
	
	ColumnSheet:AddSheet("Chams", ChamsList, "icon16/eye.png")
	
	--Starting the Finder panel
	local Finder = vgui.Create("DPanel")
	Finder:SetSize(379, 465)
	Finder.Paint = function()
		draw.RoundedBox( 0, 0, 0, Finder:GetWide(), Finder:GetTall(), Color( 240, 240, 240, 255 ) )
	end
	
	local title = vgui.Create("DLabel", Finder)
	title:SetColor(Color(0, 0, 0, 255))
	title:SetFont("CatagoryHeader")
	title:SetText("Entity Finder")
	title:SizeToContents()
	title:SetPos(Finder:GetWide() / 2 - title:GetWide() / 2, 3)
	
	local ToShow = {}
	local Others = {}
	
	local All = ents.GetAll()
	for k = 1, #All do
		local v = All[k]
		if table.HasValue(Jing.Entities.List, v:GetClass()) then
			if not table.HasValue(ToShow, v:GetClass()) then
				table.insert(ToShow, v:GetClass())
			end
		elseif not table.HasValue(Others, v:GetClass()) then
			table.insert(Others, v:GetClass())
		end
	end
	
	y = 40
	local IgnoreList = vgui.Create("DListView", Finder) --Need this up here so ToShowList can reference it.	
	local ToShowList = vgui.Create("DListView", Finder)
	ToShowList:SetSize(150, 200)
	ToShowList:SetPos(Finder:GetWide() * 0.25 - ToShowList:GetWide() / 2, y)
	ToShowList:SetMultiSelect(false)
	ToShowList:AddColumn("To Show")
	for k = 1, #ToShow do
		ToShowList:AddLine(ToShow[k])
	end
	ToShowList.DoDoubleClick = function(panel, index, line)
		table.insert(Others, ToShow[index])
		table.remove(ToShow, index)
		
		ToShowList:Clear()
		IgnoreList:Clear()
		for k = 1, #ToShow do
			ToShowList:AddLine(ToShow[k])
		end
		for k = 1, #Others do
			IgnoreList:AddLine(Others[k])
		end
		
		Jing.Entities.List = {}
		for k = 1, #ToShow do
			table.insert(Jing.Entities.List, ToShow[k])
		end
		--Jing.SaveData()
	end
	
	IgnoreList:SetSize(150, 200)
	IgnoreList:SetPos(Finder:GetWide() * 0.75 - IgnoreList:GetWide() / 2, y)
	IgnoreList:SetMultiSelect(false)
	IgnoreList:AddColumn("Others")
	for k = 1, #Others do
		IgnoreList:AddLine(Others[k])
	end
	IgnoreList.DoDoubleClick = function(panel, index, line)
		table.insert(ToShow, Others[index])
		table.remove(Others, index)
		
		ToShowList:Clear()
		IgnoreList:Clear()
		for k = 1, #ToShow do
			ToShowList:AddLine(ToShow[k])
		end
		for k = 1, #Others do
			IgnoreList:AddLine(Others[k])
		end
		
		Jing.Entities.List = {}
		for k = 1, #ToShow do
			table.insert(Jing.Entities.List, ToShow[k])
		end
		--Jing.SaveData()
	end
	
	y = y + IgnoreList:GetTall() + 20
	ToggleOption("Active", Finder, "Jing_Entities_Active")
	
	if y > 465 then
		Finder:SetTall(y)
	end
	
	local FinderList = vgui.Create( "DPanelList" )
	FinderList:SetSize(379, 465)
	FinderList:SetSpacing(0)
	FinderList:EnableHorizontal(false)
	FinderList:EnableVerticalScrollbar(true)
	FinderList:AddItem(Finder)
	
	ColumnSheet:AddSheet("Finder", FinderList, "icon16/magnifier.png")
	
	--Starting the Misc panel
	local Misc = vgui.Create("DPanel")
	Misc:SetSize(379, 465)
	Misc.Paint = function()
		draw.RoundedBox( 0, 0, 0, Misc:GetWide(), Misc:GetTall(), Color( 240, 240, 240, 255 ) )
	end
	
	local title = vgui.Create("DLabel", Misc)
	title:SetColor(Color(0, 0, 0, 255))
	title:SetFont("CatagoryHeader")
	title:SetText("Misc")
	title:SizeToContents()
	title:SetPos(Misc:GetWide() / 2 - title:GetWide() / 2, 3)
	
	y = 40
	ToggleOption("Show Admins", Misc, "Jing_Misc_ShowAdmins")
	ToggleOption("Crosshair", Misc, "Jing_Misc_Cross")
	SetNumberOption("Crosshair Size", Misc, "Jing_Misc_CrossSize", 0, 1000, 0)
	ToggleOption("No Recoil", Misc, "Jing_Misc_NoRecoil")
	ToggleOption("Spectators", Misc, "Jing_Misc_ShowSpectators")
	ToggleOption("Auto Reload", Misc, "Jing_Misc_AutoReload")
	ToggleOption("Bunny Hop", Misc, "Jing_Misc_BunnyHop")
	SetKeyOption("Key", Misc, "Jing_Misc_BunnyHop_Key")
	ToggleOption("Auto Pistol", Misc, "Jing_Misc_AutoPistol")
	ToggleOption("Buy Health", Misc, "Jing_Misc_BuyHealth")
	SetNumberOption("Minimum", Misc, "Jing_Misc_BuyHealth_Minimum", 0, 100, 0)
	ToggleOption("Traitor Finder", Misc, "Jing_Misc_TraitorFinder")
	ToggleOption("Show Deaths", Misc, "Jing_Misc_Deaths")
	ToggleOption("Sounds", Misc, "Jing_Misc_Sounds")

	if y > 465 then
		Misc:SetTall(y)
	end
	
	MiscList = vgui.Create( "DPanelList" )
	MiscList:SetSize(379, 465)
	MiscList:SetSpacing(0)
	MiscList:EnableHorizontal(false)
	MiscList:EnableVerticalScrollbar(true)
	MiscList:AddItem(Misc)

	ColumnSheet:AddSheet("Misc", MiscList, "icon16/package.png")
	
	local function ColorOption(name, parent, tab)
		local Options = vgui.Create("DColorMixer", parent)
		Options:SetSize(150, 100)
		Options:SetPos(parent:GetWide() * 0.75 - Options:GetWide() / 2, y)
		Options:SetColor(tab.color)--Jing.GetColorFromString(GetConVar(var):GetString()))
		Options:SetWangs(false)
		Options:SetPalette(false)
		Options.ValueChanged = function(panel, color) 
			Jing.Ply:ConCommand(tab.var:GetName().." ".."Color("..color.r..","..color.g..","..color.b..","..color.a..")")
			tab.color = Jing.GetColorFromString(tab.var:GetString())
		end
		
		local text = vgui.Create("DLabel", parent)
		text:SetColor(Color(0, 0, 0, 255))
		text:SetFont("CatagoryText")
		text:SetText(name)
		text:SizeToContents()
		text:SetPos(parent:GetWide() / 4 - text:GetWide() / 2, y + Options:GetTall() / 2 - text:GetTall() / 2)
		
		y = y + Options:GetTall() + 10
	end
	--Starting the Style panel
	local Style = vgui.Create("DPanel")
	Style:SetSize(379, 465)
	Style.Paint = function()
		draw.RoundedBox( 0, 0, 0, Style:GetWide(), Style:GetTall(), Color( 240, 240, 240, 255 ) )
	end
	
	local title = vgui.Create("DLabel", Style)
	title:SetColor(Color(0, 0, 0, 255))
	title:SetFont("CatagoryHeader")
	title:SetText("Style")
	title:SizeToContents()
	title:SetPos(Style:GetWide() / 2 - title:GetWide() / 2, 3)
	
	y = 50
	ColorOption("Bounding Box", Style, Jing.Style.Vars["BoundingBox"])
	ColorOption("ESP Text", Style, Jing.Style.Vars["ESPText"])
	ColorOption("Crosshair", Style, Jing.Style.Vars["Crosshair"])
	ColorOption("TTT Body Text", Style, Jing.Style.Vars["BodyText"])
	ColorOption("Chams", Style, Jing.Style.Vars["Chams"])
	ColorOption("TTT Body Chams", Style, Jing.Style.Vars["BodyChams"])
	
	if y > 465 then
		Style:SetTall(y)
	end
	
	StyleList = vgui.Create( "DPanelList" )
	StyleList:SetSize(379, 465)
	StyleList:SetSpacing(0)
	StyleList:EnableHorizontal(false)
	StyleList:EnableVerticalScrollbar(true)
	StyleList:AddItem(Style)
	
	ColumnSheet:AddSheet("Style", StyleList, "icon16/color_wheel.png")
end)


--Just some fonts
surface.CreateFont("TitleFont", {font = "Arial", size = 20})
surface.CreateFont("CatagoryHeader", {font = "CloseCaption_Normal", size = 34})
surface.CreateFont("CatagoryText", {font = "CloseCaption_Normal", size = 28})
surface.CreateFont("ESPFont", {font = "CloseCaption_Normal", weight = 1000, size = 15})

--[[ 
	DPropertySheet - Slightly edited so it looks good.
--]]
local PANEL = {}
AccessorFunc( PANEL, "ActiveButton", "ActiveButton" )

--[[---------------------------------------------------------
Name: Init
-----------------------------------------------------------]]
function PANEL:Init()
	self.Navigation = vgui.Create( "DScrollPanel", self )
	self.Navigation:Dock( LEFT )
	self.Navigation:SetWidth( 100 )
	self.Navigation:DockMargin( 0, 0, 10, 0 )

	self.Content = vgui.Create( "Panel", self )
	self.Content:Dock( FILL )

	self.Items = {}
end

function PANEL:UseButtonOnlyStyle()
	self.ButtonOnly = true
end

--[[---------------------------------------------------------
Name: AddSheet
-----------------------------------------------------------]]
function PANEL:AddSheet( label, panel, material )
	if ( !IsValid( panel ) ) then return end

	local Sheet = {}

	if ( self.ButtonOnly ) then
		Sheet.Button = vgui.Create( "DImageButton", self.Navigation )
	else
		Sheet.Button = vgui.Create( "DButton", self.Navigation )
	end
	Sheet.Button:SetImage( material )
	Sheet.Button.Target = panel
	Sheet.Button:Dock( TOP )
	Sheet.Button:SetText( label )
	Sheet.Button:DockMargin( 0, 0, 0, 5 )

	Sheet.Button.DoClick = function ()
		self:SetActiveButton( Sheet.Button )
	end

	Sheet.Panel = panel
	Sheet.Panel:SetParent( self.Content )
	Sheet.Panel:SetVisible( false )

	if ( self.ButtonOnly ) then
		Sheet.Button:SizeToContents()
		Sheet.Button:SetColor( Color( 150, 150, 150, 255 ) )
	end

	table.insert( self.Items, Sheet )

	if ( !IsValid( self.ActiveButton ) ) then
		self:SetActiveButton( Sheet.Button )
	end
end

--[[---------------------------------------------------------
Name: SetActiveTab
-----------------------------------------------------------]]
function PANEL:SetActiveButton( active )
	if ( self.ActiveButton == active ) then return end

	if ( self.ActiveButton && self.ActiveButton.Target ) then	
		self.ActiveButton.Target:SetVisible( false )
		self.ActiveButton:SetSelected( false )
		self.ActiveButton:SetColor( Color( 0, 0, 0, 255 ) )
	end
	self.ActiveButton = active
	active.Target:SetVisible( true )
	active:SetSelected( true )
	active:SetColor( Color( 150, 150, 150, 255 ) )

	self.Content:InvalidateLayout()
end

derma.DefineControl( "DColumnSheet", "", PANEL, "Panel" )

Jing.Message("Hack Loaded")