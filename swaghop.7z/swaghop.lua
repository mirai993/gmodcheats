/*
	(RUSSIAN) AM DENNY =] [65.30.50.13:27005 | STEAM_0:0:40143824]
	SwagHop.txt
*/
chat.AddText(
Color(255,0,0),"[SwagHop] ",
Color(255,255,255),"Loaded!")

local old_rcc = RunConsoleCommand

function bhop()
	if input.IsKeyDown(KEY_SPACE) then
		if LocalPlayer():IsOnGround() then
			old_rcc("+Jump")
			timer.Create("Bhop",0.01, 0 ,function() old_rcc("-Jump") end)
		end
	end
end
hook.Add("CreateMove","sh_bhop_exec",bhop)	
