/*
	
	NoSpread.lua
	Shitty constant nospread
	REQUIRES:
		gmcl_spreadthebutter (rename it to gmcl_nospread)
		
	This was thrown together using the nospread functions from hake v2
	
	codet by tyler !11122
		
*/

require( "nospread" )

print( "Hey, are you black?" )
 
local NormalCones 			= {
	[ "weapon_cs_base" ]	= true,
	[ "weapon_zs_base" ] 	= true,
}

local HL2Cones 				= {
	[ "weapon_pistol" ] 	= Vector( 0.0100, 0.0100, 0.0100 ),
	[ "weapon_smg1" ] 		= Vector( 0.04362, 0.04362, 0.04362 ),
	[ "weapon_ar2" ]		= Vector( 0.02618, 0.02618, 0.02618 ),
	[ "weapon_shotgun" ]	= Vector( 0.08716, 0.08716, 0.08716 ),
}
 
function GetCone( wep )
	if !IsValid( wep ) then return 0 end
	
	if HL2Cones[ wep:GetClass() ] then return HL2Cones[ wep:GetClass() ] end
	if NormalCones[ wep.Base ] then return wep.Cone or wep.Primary.Cone or 0 end
	
	local Cone = wep.Cone
	
	if !Cone then
		Cone = wep.Primary and wep.Primary.Cone or 0
	end
	
	return Cone
end

function PredictSpread( cmd, ang )
local w = LocalPlayer():GetActiveWeapon()
local vecCone, valCone = Vector( 0, 0, 0 )
	if ( w && w:IsValid() && ( type( w.Initialize ) == "function" ) ) then
		valCone = GetCone( w )                    
		if ( type( valCone ) == "number" ) then
			vecCone = Vector( -valCone, -valCone, -valCone )                      
		elseif ( type( valCone ) == "Vector" ) then
			vecCone = valCone * -1     
		elseif bit.band( cmd:GetButtons(), IN_SPEED ) or bit.band( cmd:GetButtons(), IN_JUMP ) then
			vecCone = valCone + (cone * 2 )                        
		end
	else
		if ( w:IsValid() ) then
			local class = w:GetClass()
			if ( HL2Cones[ class ] ) then
				vecCone = HL2Cones[ class ]
			end
		end
	end
return DS_manipulateShot( DS_md5PseudoRandom( DS_getUCMDCommandNumber( cmd ) ), ang:Forward(), vecCone ):Angle()
end

local angles = Angle( 0, 0, 0 )

function GetAngles()
	if ( !ValidEntity( LocalPlayer() ) ) then return end
	angles = LocalPlayer():EyeAngles()
end

function Parkinsons( ucmd )
	angles.p = math.NormalizeAngle( angles.p )
	angles.y = math.NormalizeAngle( angles.y )
	
	local correct = 1
	angles.y = math.NormalizeAngle( angles.y + ( ucmd:GetMouseX() * -0.022 * correct ) )
	angles.p = math.Clamp( angles.p + ( ucmd:GetMouseY() * 0.022 * correct ), -89, 90 )
	ucmd:SetViewAngles( angles )
	
	if ( ucmd:GetButtons() && IN_ATTACK > 0 ) then
		local FakeAngle = PredictSpread( ucmd, angles )
		FakeAngle.p = math.NormalizeAngle( FakeAngle.p )
		FakeAngle.y = math.NormalizeAngle( FakeAngle.y )
		ucmd:SetViewAngles( FakeAngle )
	end
end

function CalcView( ply, origin, angles, FOV )
	local ply = LocalPlayer()
	local w = ply:GetActiveWeapon()
	
	local wep = ply:GetActiveWeapon()
	if wep.Primary then wep.Primary.Recoil = 0 end
	if wep.Secondary then wep.Secondary.Recoil = 0 end
	local view = GAMEMODE:CalcView( ply, origin, angles, zoomFOV ) || {}
	view.angles = angles
	view.angles.r = 0
	view.fov = zoomFOV
	return view
end

// i suggest ripping a hook system, this is shit
hook.Add( "CalcView", "I hate making hook names", CalcView )
hook.Add( "CreateMove", "YouHaveParkinsons", Parkinsons )