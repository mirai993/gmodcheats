//THESE ARE SHIT HACKS, WHY DO YOU WANT THEM?
//Well not really but fuck it. New name LunaBot so yeah
//I personally thought it would just be me fucking around until I got bored but private hacks so!

--[[
	HvH STATS:
	
	Wins:
		Lunabot vs. Aimware
		Lunabot vs. StylesHack
		Lunabot vs. Every public cheat ever
	
	Losses:
	
		Lunabot vs. Lyoko's hack
	
	Ties:
	
		None so far
	

]]



local LB = {}
LB.prefix = "[Lunabot]"
LB.prefixcolor = Color( 0, 0, 255 )
local BoolSettings = {}
local Hooks = {}
local NumberSettings = {}
local Members = { "STEAM_0:1:73012010" }
local nospreadmodule = false
local cvarknee = false
local IsTTT = false	-- Still Haven't done anything with this :D
local IsMurder = false
local traitors = {}
local spammessage = "Fuck You."
local friends = {}
local enemys = {}
local accplayers = {}	--Used for finding players that we can attack
local menuaddons = { "Moonbutt is best Princess!", "FOR EQUESTRIA -Twilight Sparkle", "Because I Can.", "Now 20% cooler", "Now not with a HAC bypass!", "I've betten c++ cheats!" }

local spreads = {	--Used for when we detour FireBullets later in the code
["weapon_pistol"] = Vector(0.01,0.01,0),
["weapon_smg1"] = Vector(0.04362,0.04362,0),
["weapon_ar2"] = Vector(0.02618,0.02618,0)
}
-- Indexing globals for optimization :)
local LocalPlayer = LocalPlayer
local table = table.Copy( table ) -- Copy some static (Who needs terminology) functions on the global table
local player = table.Copy( player )
local math = table.Copy( math )
local me = LocalPlayer()
local _G = _G
local _R = debug.getregistry()
local aimboting = false
local targetx = nil

//I really don't want to remake this again so fuck it we are using the one off of the wiki
local print = function( message )
	MsgC( LB.prefixcolor, LB.prefix .. " ", Color( 255, 255, 255 ), message .. "\n")
end

surface.CreateFont( "ESPFont", {
	font = "Arial",
	size = 12,
	weight = 500,
	blursize = 0,
	scanlines = 0,
	antialias = true,
	underline = false,
	italic = false,
	strikeout = false,
	symbol = false,
	rotary = false,
	shadow = false,
	additive = false,
	outline = true,
} )

surface.CreateFont( "NOTESPFont", {
	font = "Arial",
	size = 25,
	weight = 500,
	blursize = 0,
	scanlines = 0,
	antialias = true,
	underline = false,
	italic = false,
	strikeout = false,
	symbol = false,
	rotary = false,
	shadow = false,
	additive = false,
	outline = true,
} )
local MaterialInfo = {
["$basetexture"] = "models/debug/debugwhite",
["$ignorez"] = 0
}
CreateMaterial( "wh_material", "vertexlitgeneric", MaterialInfo )
local wh_material = Material( "wh_material", "vertexlitgeneric" )
function Int()

	
	LB.SetBoolSetting = SetBoolSetting()
	if TTTCheck() then
		LB.IsTTT = false
	end
	if MurderCheck() then
		LB.IsMurder = true
	end

	SetBoolSetting( "Aimbot", false )
	SetBoolSetting( "AntiSnap", false )
	SetBoolSetting( "Aim_at_steam_friends", false )
	SetBoolSetting( "Aim_at_Teammates", false )
	SetBoolSetting( "ESP", true )
	SetBoolSetting( "3Dbox", true )
	SetBoolSetting( "TraceLine", true )
	SetBoolSetting( "CrossHair", true )
	SetBoolSetting( "TriggerBot", true )
	SetBoolSetting( "AutoPistol", true )
	SetBoolSetting( "WallHack", true )
	SetBoolSetting( "NoRecoil", true )
	SetBoolSetting( "NoSpread", true )
	SetBoolSetting( "Bhop", true )
	SetBoolSetting( "NoHands", false )
	SetBoolSetting( "AutoStrafe", false )
	SetBoolSetting( "TraceLineThing", false )
	SetBoolSetting( "AntiAntiAim", false )
	SetBoolSetting( "antiaim", false )
	SetBoolSetting( "fuckingpsilent", false )
	SetBoolSetting( "psayspam", false )
	SetBoolSetting( "chatspam", false )
	SetBoolSetting( "antikick", false )
	SetBoolSetting( "Fullbright", false)
	CreateConVar( "LB_AntiSnapSpeed", 0, true, true )
	CreateConVar( "LB_MaxAngle", 180, true, true )
	
	if file.Exists( "lua/bin/gmcl_spreadthebutter_win32.dll", "MOD" ) then
		nospreadmodule = true
		require( "spreadthebutter" )
		print( "NoSpread Module Loaded!" )
	end
	
	
	--[[if file.Exists( "lua/bin/gmcl_cvarknee_win32.dll", "GAME" ) then
		cvarknee = true
		require( "cvarknee" )
		print( "Cvar Knee Loaded!" )
	end
	--]]
	
	if cvarknee then
		GetConVar( "sv_cheats" ):SetFlags( 0 )
		GetConVar( "sv_cheats" ):SetValue( 1 )
	end
end
function getshootpos()
	if me:GetVelocity():Length() > 0 then
	return me:GetAttachment( me:LookupAttachment( "eyes" ) ).Pos
	else
	return me:GetShootPos()
	end
end

function TTTCheck()
	if GAMEMODE.Name == "Trouble in Terrorist Town" then
		print( "Gamemode is TTT!" )
		return true
	else 
		print( "Gamemode is not TTT!" )
		return false
	end
end


function MurderCheck()
	if GAMEMODE.Name == "Murder" then
		print( "Gamemode is Murder!" )
		return true
	else 
		print( "Gamemode is not Murder!" )
		return false
	end
end

function Check( plyer )
	for _, y in pairs( Members ) do
		if plyer:SteamID() == y then
			return true
		end
	end
	return false
end





function SetBoolSetting( Myname, setting )
	if !ConVarExists( "LB_" .. tostring(Myname) ) then
		if setting == true then
			CreateClientConVar( "LB_" .. tostring(Myname), 1, true, true )
			BoolSettings[tostring(Myname)] = setting
		else
			CreateClientConVar( "LB_" .. tostring(Myname), 0, true, true )
			BoolSettings[tostring(Myname)] = setting
		end
	else
		if setting == true then
			RunConsoleCommand( "LB_" .. tostring(Myname), 1 )
			BoolSettings[tostring(Myname)] = setting
		else
			RunConsoleCommand( "LB_" .. tostring(Myname), 0 )
			BoolSettings[tostring(Myname)] = setting
		end
	end
end

function GetBoolSetting( name )
	return tobool( GetConVarNumber( "LB_" .. name ) )
end

local function IsTraitor( target )
	if table.HasValue( target, traitors ) then
		return true
	else
		return false
	end
end
local function maxradius( angle1, angle2 )
	local p = angle1.p - angle2.p
	local y = angle1.y - angle2.y
	if math.NormalizeAngle( p ) <= GetConVarNumber( "LB_MaxAngle" ) && math.NormalizeAngle( y ) <= GetConVarNumber( "LB_MaxAngle" ) then
		return true
	else
		return false
	end
	
end

local function enemygetteam( ply )

	if IsMurder then
		if ply:GetWeapon( "weapon_mu_knife" ) then
			return true
		else
		return false
		end
	else
	if ply:Team() != me:Team() then
		return false
	else
		return true
	end
	end
end

local ply = me
//AIMBOT
hook.Add( "Think", "acceptplayers", function()
	table.Empty( accplayers )
	for _, y in pairs( player.GetAll() ) do
		//if table.HasValue( maxradius( 90, 65565, y ), y ) then
		if GetBoolSetting( "Aim_at_steam_friends" ) && y:GetFriendStatus() == "friend" --[[|| GetBoolSetting( "Aim_at_Teammates" ) && y:Team() == me:Team()]] then
			table.insert( accplayers, y )
		elseif GetBoolSetting( "Aim_at_Teammates" ) &&  enemygetteam( y ) then
			table.insert( accplayers, y )
			continue
		elseif y:GetFriendStatus() != "friend" && !enemygetteam( y ) then
			table.insert( accplayers, y )
		//end
		end
		
	end
end)

local function CanSee(target, bone, attach)
	if IsValid( target ) && IsValid( me ) && target:Health() > 0 && me:Health() > 0 then
	local tr = {};	
	tr.start = me:GetShootPos();
	if attach && IsValid( target:GetAttachment(target:LookupAttachment("eyes")) ) then
		tr.endpos =  target:GetAttachment(target:LookupAttachment("eyes")).Pos or 0 
	else
		tr.endpos =	 target:GetBonePosition( target:LookupBone( bone ) or 0 ) 
	end
	tr.filter = {me, target};
	tr.mask = MASK_SHOT;	
    local trace = util.TraceLine(tr) ;
    if (trace.Fraction == 1) then 
        return true;
    else 
        return false; 
    end 
	end
end
local globalangle = nil
local calcViewAngle = nil
local afterview = nil
//local viewthings = { 541, 540, 542, 543, 539, 538 }
local viewthings = {-3061, -541, -181}

hook.Add( "CreateMove", "the123123", function(cmd)
	if !GetBoolSetting( "antiaim" ) || aimboting == true then return end
	local eyeangles = cmd:GetViewAngles()
	eyeangles.pitch = table.Random( viewthings )
	eyeangles.roll = -180
	
	
	globalangle = eyeangles
	cmd:SetViewAngles( eyeangles )
	if input.IsKeyDown( KEY_W ) then
		cmd:SetForwardMove( 250 )
	elseif input.IsKeyDown( KEY_S ) then
		cmd:SetForwardMove( -250 )
	elseif input.IsKeyDown( KEY_D ) then
		cmd:SetSideMove( 250 )
	elseif input.IsKeyDown( KEY_A ) then
		cmd:SetSideMove( -250 )
	end
end)

--[[hook.Add( "CalcView", "the234234", function( ply, origin, angles, fov )
	local calcview = {}
	calcview.origin = origin
	if GetBoolSetting( "antiaim" ) then
	calcview.angles = globalangle
	//calcview.angles.roll = 180
	calcview.angles.pitch = 541
	afterview = calcview.angles
	else
	calcview.angles = angles
	end
	calcview.fov = 90 
	
	return calcview
end)]]
local Detours = {}
local dr 					= _R
local function Detour( Old, New )
	Detours[New] = Old
	return New
end

dr['Player']['GetHands'] = Detour( dr['Player']['GetHands'], function( ent )
	if ( ent == LocalPlayer() && GetBoolSetting( "NoHands" ) ) then
		return nil;
	end
	return Detours[dr['Player']['GetHands']]( ent );
end )

dr['Player']['SetHands'] = Detour( dr['Player']['SetHands'], function( ent, model )
	if ( ent == LocalPlayer() && GetBoolSetting( "NoHands" ) ) then
		return nil;
	end
	return Detours[dr['Player']['SetHands']]( ent, model );
end )

dr['Player']['GetHandsModel'] = Detour( dr['Player']['GetHandsModel'], function( ent )
	if ( ent == LocalPlayer() && GetBoolSetting( "NoHands" ) ) then
		return nil;
	end
	return Detours[ddr['Player']['GetHandsModel']]( ent );
end )

hook.Add( "Think", "traitors", function()
	if IsTTT == false then return end
	table.Empty( traitors )

	for _, y in pairs( player.GetAll() )do
		for _, x in pairs( y:GetWeapons() ) do
			if table.HasValue( x, GetWeaponsForRole( ROLE_TRAITOR ) ) then
				table.insert( y, traitors )
			end
		end
	end
end)
concommand.Add( "print_t", function()
	PrintTable( traitors )
end)

local function VelocityPrediction(ply1, ply2)
return (ply1:GetAbsVelocity() * 0.012) - (ply2:GetAbsVelocity() * 0.012)
--[[local thing1 = ply1:GetAbsVelocity()
local thing2 = ply2:GetAbsVelocity()
return ( thing1 / thing2 ) * 0.0067]]
end

local function GetPos(target)
if IsValid(target) then
if CanSee(target, "ValveBiped.Bip01_Head1", true) then
	return target:GetAttachment(target:LookupAttachment("eyes")).Pos
elseif GetBoolSetting( "AntiAntiAim" ) && CanSee(target, "ValveBiped.Bip01_Spine", false) then
	return target:GetBonePosition( target:LookupBone( "ValveBiped.Bip01_Spine" ) or 0  ) + VelocityPrediction( target, me )
else
return nil
end
end
end
local timernumber = 0
local function autopistol()
	if timernumber <= CurTime() then
		RunConsoleCommand( "+attack" )
		timernumber = me:GetActiveWeapon():GetNextPrimaryFire()
		timer.Simple( 0.01, function()
			RunConsoleCommand( "-attack" )
		end)
	else
		timernumber = me:GetActiveWeapon():GetNextPrimaryFire()
	end
end

hook.Add( "Think", "THEINGJE", function()
	if not me:GetActiveWeapon().Primary then return end
		if input.IsMouseDown( MOUSE_LEFT ) && GetBoolSetting( "AutoPistol" ) && me:GetActiveWeapon().Primary.Automatic == false then
			autopistol()
		end
end)

local entsss = table.Copy( _R.Entity )

_R.Entity.FireBullets = function( ent, bullet )
	if not spreads[me:GetActiveWeapon():GetClass()] || spreads[me:GetActiveWeapon():GetClass()] != bullet.Spread then
		spreads[me:GetActiveWeapon():GetClass()] = bullet.Spread
	end
	return entsss.FireBullets( ent, bullet )
end

local function triggetbot( target )
	local weapon = me:GetActiveWeapon()
	if weapon.Primary then
	if weapon.Primary.Automatic == true || !GetBoolSetting( "AutoPistol" ) then
			RunConsoleCommand( "+attack" )
		timer.Simple( 0.01, function()
			RunConsoleCommand( "-attack" )
		end)
	elseif GetBoolSetting( "AutoPistol" ) then
		autopistol()
	end
	end
end


local function bestangle( angle1, angle2, myangle, target )
	if angle1 > angle2 && maxradius( angle1, myangle )  then
		return true
	else
		return false
	end
end


local function AngleTo(target)
	if IsValid(target) then
		--[[local eyes = target:LookupAttachment("eyes")
		eyes = target:GetAttachment(eyes)
		if(eyes and eyes.Pos) then
			return (eyes.Pos - ply:GetShootPos()):Angle()
		end]]--
		if GetPos(target) && !GetBoolSetting( "AntiSnap" ) then
			
			return (GetPos(target) - me:GetShootPos()):Angle()				
		else
			local p = math.ApproachAngle( ply:EyeAngles().p, (GetPos(target) - me:GetShootPos()):Angle().p, GetConVarNumber( "LB_AntiSnapSpeed" ) )
			local y = math.ApproachAngle( ply:EyeAngles().y, (GetPos(target) - me:GetShootPos()):Angle().y, GetConVarNumber( "LB_AntiSnapSpeed" ) )
			return Angle( p, y, (GetPos(target) - me:GetShootPos()):Angle().r )
		end
	end
	
end
--[[hook.Add( "CreateMove", "Thingy", function(cmd)
	if input.IsMouseDown( MOUSE_LEFT ) then
		SetBoolSetting( "Aimbot", true )
	elseif !input.IsMouseDown( MOUSE_LEFT ) then
		SetBoolSetting( "Aimbot", false )
	end
end)]]


local function basecheck( weapon )
	if weapon.Base == "bobs_gun_base" || weapon.Base == "bobs_shotty_base" || weapon.Base == "bobs_scoped_base" then
		return "M9K"
	else
		return "Other"
	end
end
bSendPacket = true
bBulletTime = true;
bGOOO = true;
oldView = Angle( 0, 0, 0 )

local function Aimbot( cmd, target, angle, oldangles )
	
	
	if nospreadmodule == true && GetBoolSetting( "NoSpread" ) then
		local weapon = me:GetActiveWeapon();
		
		if IsValid(weapon)--[[ and weapon.Primary and weapon.Primary.Cone --[[and basecheck( weapon ) == "Other"]] then
			angle = DS_manipulateShot(DS_md5PseudoRandom(DS_getUCMDCommandNumber(cmd)), angle:Forward(), Vector(-spreads[me:GetActiveWeapon():GetClass()].x, -spreads[me
			:GetActiveWeapon():GetClass()].y, 0)):Angle();
			aimboting = true
			
		
			
		--[[elseif IsValid(weapon) and basecheck( weapon ) == "M9K" then
			if weapon:GetIronsights() == false then
				angle = DS_manipulateShot(DS_md5PseudoRandom(DS_getUCMDCommandNumber(cmd)), angle:Forward(), Vector(-weapon.Primary.Spread, -weapon.Primary.Spread, 0)):Angle()
			else
				angle = DS_manipulateShot(DS_md5PseudoRandom(DS_getUCMDCommandNumber(cmd)), angle:Forward(), Vector(-weapon.Primary.IronAccuracy, -weapon.Primary.IronAccuracy, 0)):Angle()
			end]]
	if GetBoolSetting( "fuckingpsilent" ) then
	if bSendPacket then
		oldView = cmd:GetViewAngles()
	end
		oldSidemove = cmd:GetSideMove()
	oldForwardmove = cmd:GetForwardMove()

	flServerTime = UnPredictedCurTime( )
	flNextPrimaryAttack = LocalPlayer():GetActiveWeapon():GetNextPrimaryFire() - 0.00001


if( flNextPrimaryAttack >= flServerTime ) then
	bBulletTime = false
else
	if bSendPacket then
		bBulletTime = true;
	end
end
if cmd:CommandNumber() == 0 then
	bGOOO = true;
else
	bGOOO = false;
end

if( bBulletTime && !bGOOO ) then
	bSendPacket = false;
	cmd:SetViewAngles( angle )
	triggetbot( v );
else 
	bSendPacket = true;
	cmd:SetViewAngles(oldView);
	cmd:SetSideMove(oldSidemove);
	cmd:SetForwardMove( oldForwardmove );
	//aimboting = false
end

else
		cmd:SetViewAngles(angle);
		//aimboting = false
end

		return true
	else
		cmd:SetViewAngles(angle);
		return true
	end
	end
	aimboting = false
end



function calculateview( cmd )
	if aimboting == false then
		oldView = cmd:GetViewAngles()
	end
	
	//calcviewthing = thing - oldView
end



hook.Add( "CreateMove", "fjkdkfjslkdjf", calculateview )

local function reset( cmd )
	cmd:SetViewAngles( oldView )
end

local function GetTarget(cmd)
	if GetBoolSetting( "Aimbot" ) == false then aimboting = false return end
	for k = 1, #accplayers do
	local v = accplayers[k];
		if v != me and v:Health() > 0 and IsValid( v ) --[[&& maxradius( 20, 1000, v )]] then
			if GetPos( v ) then
			local bestangle1 = 0;
			if bestangle1 == 0 then
			bestangle1 = AngleTo( v );
			elseif bestangle( bestangle1, AngleTo( v ), cmd:GetViewAngles(), v ) then
				bestangle1 = AngleTo( v );
			end
			
			if not spreads[me:GetActiveWeapon():GetClass()] then
				triggetbot( v );
			else
				Aimbot( cmd, v, bestangle1, cmd:GetViewAngles() );
				
			end
			if GetBoolSetting( "TriggerBot" ) && !GetBoolSetting( "fuckingpsilent" ) then
				triggetbot( v );
			end
	
			end
		end
	end
	end
	



hook.Add( "Think", "fkdjflkdfjdl;kfjsa;lf", function()
	if GetBoolSetting( "psayspam" ) then
		for _, y in pairs( player.GetAll() ) do
			if y != me && y:GetFriendStatus() != "friend" then
				RunConsoleCommand( "ulx", "psay", y:Name(), spammessage )
			end
		end
	end
	if GetBoolSetting( "chatspam" ) then
		RunConsoleCommand( "say", spammessage )
	end
	if GetBoolSetting( "antikick" ) then
		for _, y in pairs( player.GetAll() ) do
			if y != me && y:GetFriendStatus() != "friend" then
				RunConsoleCommand( "ulx", "votekick", y:Name() )
			end
		end
	end
end)




hook.Add( "HUDPaint", "aimwearcorsair", function()
	if GetBoolSetting( "Crosshair" ) then
	local x, y, s = ScrW() / 2, ScrH() / 2, 8
	surface.SetDrawColor(Color(255,255,255,255))
	surface.DrawLine( x, y - s, x, y + s )
	surface.DrawLine( x - s, y, x + s, y )
	end
	local pos
	if IsValid(LocalPlayer():GetActiveWeapon()) then
		local vm = LocalPlayer():GetActiveWeapon()
		
		if IsValid(LocalPlayer():GetViewModel()) then
			vm = LocalPlayer():GetViewModel()
			
			local attachmentIndex = vm:LookupAttachment("2")
			
			if attachmentIndex == 0 then attachmentIndex = vm:LookupAttachment("muzzle") end
			
			pos = LocalPlayer():GetViewModel():GetAttachment(attachmentIndex)
			pos = pos and pos.Pos or LocalPlayer():EyePos() + Vector(5,0,0)
		else
		
			local attachmentIndex = vm:LookupAttachment("1")
			if attachmentIndex == 0 then attachmentIndex = vm:LookupAttachment("muzzle") end
			
			
			pos = LocalPlayer():GetActiveWeapon():GetAttachment(attachmentIndex)
			pos = pos and pos.Pos or LocalPlayer():EyePos() + Vector(5,0,0)
		end
	elseif IsValid(LocalPlayer():GetActiveWeapon()) then
		pos = LocalPlayer():GetActiveWeapon():GetPos()
	else
		pos = LocalPlayer():EyePos() + Vector(5,0,0)
	end

	targetx = me:GetEyeTrace().HitPos
	if GetBoolSetting( "TraceLineThing" ) then
	cam.Start3D(EyePos(), EyeAngles())
		cam.IgnoreZ(true)
			render.SetMaterial(Material( "trails/laser" ))
			render.DrawBeam(pos, targetx, 4, 2, 0, Color(0,255,0,255))
		cam.IgnoreZ(false)
	cam.End3D()
	end
end)
hook.Add( "HUDPaint", "the", function()
	surface.SetDrawColor( 255, 0, 0 )
	local x = ScrW() * 0.5
	local y = ScrH() * 0.5
	surface.DrawLine( x + 25, y, x - 25, y )
	surface.DrawLine( x, y + 25, x, y - 25 )
	surface.DrawLine( x + 25, y, x + 25, y + 25 )
	surface.DrawLine( x - 25, y, x - 25, y - 25 )
	surface.DrawLine( x, y + 25, x - 25, y + 25 )
	surface.DrawLine( x, y - 25, x + 25, y - 25 )
end)

hook.Add("RenderScreenspaceEffects", "thing", function()
   if GetBoolSetting( "Fullbright" ) then
		render.SetLightingMode( 2 )
	else
		render.SetLightingMode( 0 )
   end
   if !GetBoolSetting( "WallHack" ) then return end
    for k,v in pairs(player.GetAll()) do
       if v:Health() > 0 then
        cam.Start3D(me:EyePos(), me:EyeAngles())
            render.SuppressEngineLighting( true );
            cam.IgnoreZ( true )
           
			local TeamColor = Color( 255, 221, 0 )
            local drawcolor = Color( 0, 255, 0 )
			
			if CanSee( v, "ValveBiped.Bip01_Head1" ) then
				drawcolor = Color( 255, 0, 0 )
			else
				drawcolor = Color( 0, 255, 0 )
			end
            render.SetColorModulation( TeamColor.r/255, TeamColor.g/255, TeamColor.b/255 )
			 if v:Alive() then
			if v != me then
            local start = me:GetPos()
			local ending = v:GetPos()
			//local aimstart = me:GetActiveWeapon():GetAttachment(me:GetActiveWeapon():LookupAttachment( "muzzle" ))
			local min, max = v:GetRenderBounds()
			//render.DrawLine( aimstart.Pos, me:GetAimVector(), Color( 255, 0, 0 ) )
			end
			//if !CanSee( v, "ValveBiped.Bip01_Head1" ) then
				v:DrawModel();
			//end
            end
			render.MaterialOverride( Material( "models/debug/debugwhite", "vertexlitgeneric" ));
			//render.SetModelLighting( 4, TeamColor.r/255, TeamColor.g/255, TeamColor.b/255 );
			--[[cam.IgnoreZ( false )
			v:DrawModel( false )
           ]]
            render.SuppressEngineLighting( false );
        cam.End3D()
	end
    end
   
end)
--[[hook.Add( "CreateMove", "the5", function(cmd)
	if GetBoolSetting( "AutoPistol" ) && input.IsMouseDown( MOUSE_LEFT ) && LocalPlayer():GetActiveWeapon().Primary.Auotmatic == true then
		autopistol()
	end
end)]]

hook.Add( "HUDPaint", "LKDFJDL:KFJDLFKJSDLFK:", function()
	if !GetBoolSetting( "ESP" ) then return end
	for _, ply in pairs( player.GetAll() ) do
	
	
	if ply == me then continue end
	local y = ( (ply:OBBCenter() + ply:GetPos() ) + ply:OBBMaxs() * 0.15 ):ToScreen()
	draw.SimpleText( ply:Name(), "DermaDefault", y.x, y.y, n )
	end
end)


hook.Add( "PostPlayerDraw", "line", function( ply )
	if !GetBoolSetting( "ESP" ) then return end
	if ply == me then return end
	

end)
hook.Add( 'PostPlayerDraw', 'espbox', function( ply )
        if !GetBoolSetting( "ESP" ) || ply == me  then return end
		 -- color when visible
         -- invisible
		 local n = table.Copy( team.GetColor( ply:Team() ) )
	local z = Color( n.b, n.g, n.r )
       
        local v = ply:GetPos()
        local rv = v + ply:OBBCenter()
        local rd = ( v:ToScreen().y - ( v + ( ply:OBBMins() + ply:OBBMaxs() ) * 0.5 ):ToScreen().y ) * 1.5 -- box height
		  local x = -rd * 0.5
		  
       
        cam.Start3D2D( rv, EyeAngles() + Angle( 90, 0, 0 ), rv:Distance( EyePos() ) * 0.003     ) -- same pixel scale at any render distance
       
      
	
       
        cam.IgnoreZ( true )
		
        surface.SetDrawColor( z )
		
		surface.DrawOutlinedRect( x, x, rd, rd )  -- draw box with ignorez first, this box will be seen anytime
		
        cam.IgnoreZ( false )
       
       
       
        surface.SetDrawColor( n )
        surface.DrawOutlinedRect( x, x, rd, rd ) -- try overlapping it over ignore-z box, if there's no obstacles, it will be overlapped
       
       
        cam.End3D2D()
end )

--[[local laser = Material( "cable/redlaser" )
hook.Add("RenderScreenspaceEffects", "lelelel", function()
	if !GetBoolSetting( "TraceLineThing" ) then return end
	local startpos = LocalPlayer():GetPos()
	local EndPos = LocalPlayer():GetEyeTrace().HitPos;
	local model = LocalPlayer():GetViewModel()
	
	if not IsValid(model) then
		return
	end
	
	local attach = model:GetAttachment("1")
	if not attach then return end
	
	startpos = attach.Pos
	
	cam.Start3D()
		render.SetMaterial( laser )
		render.DrawBeam( startpos, EndPos, 5, 1, 1, Color( 255, 255, 255, 255 ) ) 
	cam.End3D()


end)]]


       

hook.Add( "CreateMove", "bhop", function(cmd)
	
	local ply = me
	if ply:OnGround() && input.IsKeyDown( KEY_SPACE ) && GetBoolSetting( "Bhop" ) then
		jump()
	end
	if ply:OnGround() == false && GetBoolSetting( "AutoStrafe" ) then
		strafe( cmd )
	end
end)
	
	local oldangle = me:EyeAngles()

function strafe( cmd )
	local angles = me:EyeAngles()

	if angles.y > oldangle.y then
		oldangle = angles
		cmd:SetSideMove( -1000000000 )
		timer.Simple( 0.0001, function()
			cmd:SetSideMove( 1000000000 )
		end)
	elseif angles.y < oldangle.y then
		oldangle = angles
		cmd:SetSideMove( 100000000 )
		timer.Simple( 0.0001, function()
			cmd:SetSideMove( -1000000000 )
		end)
	end

end

--[[orgply = table.Copy( FindMetaTable( "Player" ) )
players = FindMetaTable( "Player" )

players.MetaBaseClass.FireBullets = function( ent, bullettable )

	bullettable.Tracer = 1
	bullettable.Spread = Vector( 0, 0, 0 )
	
	orgply.MetaBaseClass.FireBullets( ent, bullettable )

end
]]


function jump()
	RunConsoleCommand( "+jump" )
	timer.Simple( 0.001, function()
		RunConsoleCommand( "-jump" )
	end)
end





-- Lua generated by DermaDesigner


concommand.Add( "LB_menu", function()
local shitmenu = vgui.Create( "DFrame" )
shitmenu:SetPos( ScrW() / 2 - ( 750 / 2 ), ScrH() / 2 - ( 500 / 2 ))
shitmenu:SetSize( 750, 500 )
shitmenu:SetTitle( LB.prefix .. "    " .. table.Random( menuaddons ) )
shitmenu:SetVisible( true )
shitmenu:SetDraggable( true )
shitmenu:ShowCloseButton( true )
shitmenu:MakePopup( )
shitmenu.Paint = function()
	surface.SetDrawColor( 0, 0, 0, 165 )
	surface.DrawRect( 0, 0, shitmenu:GetWide(), shitmenu:GetTall() )
	surface.SetDrawColor( 255, 0, 0, 165 )
	surface.DrawRect( 0, 0, shitmenu:GetWide(), 25 )
	surface.SetDrawColor( 255, 0, 0 )
	surface.DrawOutlinedRect( 0, 0, shitmenu:GetWide(), shitmenu:GetTall() )
	//surface.DrawOutlinedRect( 0, 0, shitmenu:GetWide(), 25 )
	
end
local tabs = vgui.Create( "DPropertySheet", shitmenu )
tabs:SetPos( 5, 30 )
tabs:SetSize( 740, 465 )
tabs.Paint = function()
	
end

local shitlist = vgui.Create( "DPanelList" )
shitlist:SetSize( 735, 465 )
shitlist:SetPos( 10, 30 )
shitlist:SetSpacing( 50 )
shitlist:EnableHorizontal( false )
shitlist:EnableVerticalScrollbar( false )
local ESP = vgui.Create( "DPanelList" )
ESP:SetSize( 735, 465 )
ESP:SetPos( 10, 30 )
ESP:SetSpacing( 50 )
ESP:EnableHorizontal( false )
ESP:EnableVerticalScrollbar( false )
local Misc = vgui.Create( "DPanelList" )
Misc:SetSize( 735, 465 )
Misc:SetPos( 10, 30 )
Misc:SetSpacing( 50 )
Misc:EnableHorizontal( false )
Misc:EnableVerticalScrollbar( false )
local Spam = vgui.Create( "DPanelList" )
Spam:SetSize( 735, 465 )
Spam:SetPos( 10, 30 )
Spam:SetSpacing( 50 )
Spam:EnableHorizontal( false )
Spam:EnableVerticalScrollbar( false )
local hvh = vgui.Create( "DPanelList" )
hvh:SetSize( 735, 465 )
hvh:SetPos( 10, 30 )
hvh:SetSpacing( 50 )
hvh:EnableHorizontal( false )
hvh:EnableVerticalScrollbar( false )
local mov = vgui.Create( "DPanelList" )
mov:SetSize( 735, 465 )
mov:SetPos( 10, 30 )
mov:SetSpacing( 50 )
mov:EnableHorizontal( false )
mov:EnableVerticalScrollbar( false )


--[[shitmenu.Paint = function()

end]]
local textcolor = Color( 255, 0, 0 )
local shitaimbotbutton = vgui.Create( "DCheckBoxLabel" )
shitaimbotbutton:SetText( "Aimbot" )
shitaimbotbutton:SetTextColor( textcolor )
shitaimbotbutton:SetConVar( "LB_Aimbot" )
shitaimbotbutton:SetValue( GetConVarNumber( "LB_Aimbot" ) )
shitaimbotbutton:SizeToContents()
local shitespbutton = vgui.Create( "DCheckBoxLabel" )
shitespbutton:SetText( "ESP" )
shitespbutton:SetConVar( "LB_ESP" )
shitespbutton:SetTextColor( textcolor )
shitespbutton:SetValue( GetConVarNumber( "LB_ESP" ) )
shitespbutton:SizeToContents()
local shitwallhackbutton = vgui.Create( "DCheckBoxLabel" )
shitwallhackbutton:SetText( "WallHack" )
shitwallhackbutton:SetConVar( "LB_WallHack" )
shitwallhackbutton:SetTextColor( textcolor )
shitwallhackbutton:SetValue( GetConVarNumber( "LB_WallHack" ) )
shitwallhackbutton:SizeToContents()
local shitnorecoilbutton = vgui.Create( "DCheckBoxLabel" )
shitnorecoilbutton:SetText( "No Recoil" )
shitnorecoilbutton:SetTextColor( textcolor )
shitnorecoilbutton:SetConVar( "LB_NoRecoil" )
shitnorecoilbutton:SetValue( GetConVarNumber( "LB_NoRecoil" ) )
shitnorecoilbutton:SizeToContents()
local shitnospreadbutton = vgui.Create( "DCheckBoxLabel" )
shitnospreadbutton:SetText( "No Spread" )
shitnospreadbutton:SetTextColor( textcolor )
shitnospreadbutton:SetConVar( "LB_NoSpread" )
shitnospreadbutton:SetValue( GetConVarNumber( "LB_NoSpread" ) )
shitnospreadbutton:SizeToContents()
local shitbhopbutton = vgui.Create( "DCheckBoxLabel" )
shitbhopbutton:SetText( "Bhop" )
shitbhopbutton:SetTextColor( textcolor )
shitbhopbutton:SetConVar( "LB_Bhop" )
shitbhopbutton:SetValue( GetConVarNumber( "LB_Bhop" ) )
shitbhopbutton:SizeToContents()
local strafe = vgui.Create( "DCheckBoxLabel" )
strafe:SetText( "Auto Strafe" )
strafe:SetTextColor( textcolor )
strafe:SetConVar( "LB_AutoStrafe" )
strafe:SetValue( GetConVarNumber( "LB_AutoStrafe" ) )
strafe:SizeToContents()
local teams = vgui.Create( "DCheckBoxLabel" )
teams:SetText( "Team" )
teams:SetTextColor( textcolor )
teams:SetConVar( "LB_Aim_at_Teammates" )
teams:SetValue( GetConVarNumber( "LB_Aim_at_Teammates" ) )
teams:SizeToContents()
local friends = vgui.Create( "DCheckBoxLabel" )
friends:SetText( "Aim At Steam Friends" )
friends:SetTextColor( textcolor )
friends:SetConVar( "LB_Aim_at_steam_friends" )
friends:SetValue( GetConVarNumber( "LB_Aim_at_steam_friends" ) )
friends:SizeToContents()
local triggerbot = vgui.Create( "DCheckBoxLabel" )
triggerbot:SetText( "TriggerBot" )
triggerbot:SetTextColor( textcolor )
triggerbot:SetConVar( "LB_TriggerBot" )
triggerbot:SetValue( GetConVarNumber( "LB_TriggerBot" ) )
triggerbot:SizeToContents()
local psilent = vgui.Create( "DCheckBoxLabel" )
psilent:SetText( "psilent" )
psilent:SetTextColor( textcolor )
psilent:SetConVar( "LB_fuckingpsilent" )
psilent:SetValue( GetConVarNumber( "LB_fuckingpsilent" ) )
local autopistol = vgui.Create( "DCheckBoxLabel" )
autopistol:SetText( "AutoPistol" )
autopistol:SetTextColor( textcolor )
autopistol:SetConVar( "LB_AutoPistol" )
autopistol:SetValue( GetConVarNumber( "LB_AutoPistol" ) )
autopistol:SizeToContents()
local crosshair = vgui.Create( "DCheckBoxLabel" )
crosshair:SetText( "Crosshair" )
crosshair:SetTextColor( textcolor )
crosshair:SetConVar( "LB_CrossHair" )
crosshair:SetValue( GetConVarNumber( "LB_CrossHair" ) )
crosshair:SizeToContents()
--[[local threedbox = vgui.Create( "DCheckBoxLabel" )
threedbox:SetText( "3D Box" )
threedbox:SetTextColor( textcolor )
threedbox:SetConVar( "LB_3Dbox" )
threedbox:SetValue( GetConVarNumber( "LB_3Dbox" ) )
threedbox:SizeToContents()
local tracelines = vgui.Create( "DCheckBoxLabel" )
tracelines:SetText( "TraceLine" )
tracelines:SetTextColor( textcolor )
tracelines:SetConVar( "LB_TraceLine" )
tracelines:SetValue( GetConVarNumber( "LB_TraceLine" ) )
tracelines:SizeToContents()]]
local Lazer = vgui.Create( "DCheckBoxLabel" )
Lazer:SetText( "Lazer" )
Lazer:SetTextColor( textcolor )
Lazer:SetConVar( "LB_TraceLineThing" )
Lazer:SetValue( GetConVarNumber( "LB_TraceLineThing" ) )
Lazer:SizeToContents()
local hands = vgui.Create( "DCheckBoxLabel" )
hands:SetText( "No Hands" )
hands:SetTextColor( textcolor )
hands:SetConVar( "LB_NoHands" )
hands:SetValue( GetConVarNumber( "LB_NoHands" ) )
hands:SizeToContents()
local AA = vgui.Create( "DCheckBoxLabel" )
AA:SetText( "Anti-Aim" )
AA:SetTextColor( textcolor )
AA:SetConVar( "LB_antiaim" )
AA:SetValue( GetConVarNumber( "LB_antiaim" ) )
AA:SizeToContents()
local psay = vgui.Create( "DCheckBoxLabel" )
psay:SetText( "Psay Spam" )
psay:SetTextColor( textcolor )
psay:SetConVar( "LB_psayspam" )
psay:SetValue( GetConVarNumber( "LB_psayspam" ) )
psay:SizeToContents()
local chats = vgui.Create( "DCheckBoxLabel" )
chats:SetText( "Chat Spam" )
chats:SetTextColor( textcolor )
chats:SetConVar( "LB_chatspam" )
chats:SetValue( GetConVarNumber( "LB_chatspam" ) )
chats:SizeToContents()
local kick = vgui.Create( "DCheckBoxLabel" )
kick:SetText( "ULX Anti-Kick" )
kick:SetTextColor( textcolor )
kick:SetConVar( "LB_antikick" )
kick:SetValue( GetConVarNumber( "LB_antikick" ) )
kick:SizeToContents()
local AS = vgui.Create( "DCheckBoxLabel" )
AS:SetText( "Anti-Snap" )
AS:SetTextColor( textcolor )
AS:SetConVar( "LB_AntiSnap" )
AS:SetValue( GetConVarNumber( "LB_AntiSnap" ) )
AS:SizeToContents()
local AS2 = vgui.Create( "DCheckBoxLabel" )
AS2:SetText( "FullBright" )
AS2:SetTextColor( textcolor )
AS2:SetConVar( "LB_Fullbright" )
AS2:SetValue( GetConVarNumber( "LB_Fullbright" ) )
AS2:SizeToContents()
local ASS = vgui.Create( "DNumSlider" )
ASS:SetText( "Anti-Snap Speed" )
ASS:SetConVar( "LB_AntiSnapSpeed" )
ASS:SetMin( 1 ) 
ASS:SetMax( 20 )                
ASS:SetDecimals( 0 )
ASS:SetValue( GetConVarNumber( "LB_AntiSnapSpeed" ) )
ASS:SizeToContents()
local TextEntry = vgui.Create( "DTextEntry", frame )	-- create the form as a child of frame
TextEntry:SetText( spammessage )
TextEntry.OnEnter = function( self )
	spammessage = self:GetValue()
end
--[[local Mixer1 = vgui.Create( "DColorMixer" ) 				
Mixer1:SetColor( Color( 30,100,160 ) )
Mixer1:SetAlphaBar( false )
Mixer1:SetPalette( false )
Mixer1:SetWangs( false )
local Mixer2 = vgui.Create( "DColorMixer" ) 				
Mixer2:SetColor( Color( 30,100,160 ) )
Mixer2:SetAlphaBar( false )
Mixer2:SetPalette( false )
Mixer2:SetWangs( false )]]

shitlist:AddItem( shitaimbotbutton )
shitlist:AddItem( psilent )
shitlist:AddItem( AS )
ESP:AddItem( shitespbutton )
//ESP:AddItem( threedbox )
//ESP:AddItem( tracelines )
ESP:AddItem( shitwallhackbutton )
ESP:AddItem( crosshair )
ESP:AddItem( Lazer )
//ESP:AddItem( Mixer1 )
//ESP:AddItem( Mixer2 )
Misc:AddItem( shitnorecoilbutton )
Misc:AddItem( shitnospreadbutton )
Misc:AddItem( hands )
mov:AddItem( shitbhopbutton )
mov:AddItem( strafe )
shitlist:AddItem( friends )
Misc:AddItem( triggerbot )
Misc:AddItem( autopistol )
hvh:AddItem( AA )
Spam:AddItem( TextEntry )
Spam:AddItem( psay )
Spam:AddItem( chats )
Spam:AddItem( kick )
shitlist:AddItem( teams )
shitlist:AddItem( ASS )
Misc:AddItem( AS2 )
tabs:AddSheet( "Aimbot", shitlist, "gui/silkicons/user", false, false, "Aimbot" )
tabs:AddSheet( "ESP", ESP, "gui/silkicons/user", false, false, "ESP" )
tabs:AddSheet( "Misc", Misc, "gui/silkicons/user", false, false, "Misc" )
tabs:AddSheet( "Spam", Spam, "gui/silkicons/user", false, false, "Spam" )
tabs:AddSheet( "HackvHack", hvh, "gui/silkicons/user", false, false, "H4X0rS" )
tabs:AddSheet( "Movement", mov, "gui/silkicons/user", false, false, "FUCK" )


--[[local mainbox = vgui.Create( "DFrame" )
mainbox:SetPos( 0, ScrH() - 400 )
mainbox:SetSize( 200, 400 )
mainbox:SetTitle( "[Lunabot]" )
mainbox:SetVisible( true )
mainbox:SetDraggable( true )
mainbox:ShowCloseButton( true )
mainbot:MakePopup( )

mainbox.Paint = function()
	surface.SetDrawColor( 0, 0, 0 )
	surface.DrawRect( 0, 0, mainbox:GetWide(), mainbox:GetTall() )
end]]

end)


hook.Add( "CreateMove", "NoRecoil", function(cmd)
	if !GetBoolSetting( "NoRecoil" ) then return end
	local weapon = me:GetActiveWeapon()
	if IsValid(weapon) && weapon.Primary then
		weapon.Primary.Recoil = 0
	end
end)


hook.Add( "CalcView", "thingy", norecoil )
hook.Add( "CreateMove", "the", GetTarget)

concommand.Add( "+aimbot", function()
	SetBoolSetting( "Aimbot", true )
end)
concommand.Add( "-aimbot", function()
	SetBoolSetting( "Aimbot", false )
end)

concommand.Add( "+speedhack", function()
	if cvarknee then
		GetConVar( "host_timescale" ):SetFlags( 0 )
		GetConVar( "host_timescale" ):SetValue( 4 )
	end
end)
concommand.Add( "-speedhack", function()
	if cvarknee then
		GetConVar( "host_timescale" ):SetFlags( 0 )
		GetConVar( "host_timescale" ):SetValue( 1 )
	end
end)

Int()