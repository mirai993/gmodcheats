local kat = {}
local G = table.Copy(_G)
local x,y = G.ScrW(), G.ScrH()
local lp = G.LocalPlayer()

require("dickwrap")
require("bsendpacket")
// require("big")

bSendPacket = true 

local chamsmat = CreateMaterial("a", "VertexLitGeneric", { ["$ignorez"] = 1, ["$model"] = 0, ["$basetexture"] = "models/debug/debugwhite", }); local chamsmat2 = CreateMaterial("@", "VertexLitGeneric", { ["$ignorez"] = 0, ["$model"] = 1, ["$basetexture"] = "models/debug/debugwhite", })

G.MsgC(G.Color(75,0,130), [[

  _         _   _           _    
 | |       | | | |         | |   
 | | ____ _| |_| |__   __ _| | __
 | |/ / _` | __| '_ \ / _` | |/ /
 |   < (_| | |_| | | | (_| |   < 
 |_|\_\__,_|\__|_| |_|\__,_|_|\_\
                                           
]])

--// FONT --\\

G.surface.CreateFont( "ESPFont", {
	font = "Bahnschrift Light", --  Use the font-name which is shown to you by your operating system Font Viewer, not the file name
    size = 13,
    weight = 400,
    antialias = false,
    outline = true,
    shadow = true,
} )

G.surface.CreateFont( "SmallESPFont", {
	font = "BudgetLabel",
    size = 12,
	weight = 500,
    antialias = false, -- because outline fucks up if you don't
    outline = true 
} )


--// DETOURS --\\

-- we doin this later --

--// CONVARS & MENU --\\

local convars = {
    {"kat_aimbot"},
    {"kat_headshot_only"},
    {"kat_ignore_bot"},
    {"kat_ignore_team"},
    {"kat_ignore_staff"},
    {"kat_ignore_noclip"},
    {"kat_ignore_cloak"},
    {"kat_autoshoot"},
    {"kat_silent"},
    {"kat_recoil"},
    {"kat_spread"},

    {"kat_esp"},
    {"kat_box"},
    {"kat_name"},
    {"kat_weapon"},
    {"kat_healthbar"},
    {"kat_glow"},
    {"kat_chams"},
    {"kat_chams_flat"},
    {"kat_chams_los"},

    {"kat_bhop"},
    {"kat_autostrafe"},
    {"kat_antiaim"},
    {"kat_method", "micromovements"}, -- overflow, micromovements, fake angles
    {"kat_lby"},
    {"kat_lby_angle",179}, 
    {"kat_pitch",-89},
    {"kat_yaw",90},
    {"kat_fake_yaw",-90},

    -- hidden cvars --
    {"kat_micromovements_threshold",1.1}

}

for k,v in G.ipairs(convars) do 
    convars[v[1]] = G.CreateClientConVar(v[1],v[2] or 0)
    convars[k] = nil
end

local menu_loop = {
    {
        {0,"enabled","kat_aimbot"},
        {0,"headshot only","kat_headshot_only"},
        {0,"ignore bot","kat_ignore_bot"},
        {0,"ignore team","kat_ignore_team"},
        {0,"ignore staff","kat_ignore_staff"},
        {0,"ignore noclipping","kat_ignore_noclip"},
        {0,"ignore cloak","kat_ignore_cloak"},
        {0,"autofire","kat_autoshoot"},
        {0,"silent","kat_silent"},
        {0,"remove recoil","kat_recoil"},
        {0,"remove spread","kat_spread"},

    },

    {
        {0,"visuals","kat_esp"},
        {0,"box","kat_box"},
        {0,"name","kat_name"},
        {0,"weapon","kat_weapon"},
        {0,"healthbar","kat_healthbar"},
        {0,"glow","kat_glow"},
        {0,"chams","kat_chams"},
        {0,"chams flat","kat_chams_flat"},
        {0,"chams ignore los","kat_chams_los"},

    },

    {
        {0,"bunnyhop","kat_bhop"},
        {0,"autostrafe","kat_autostrafe"},


    },
}

--// FUNCTIONS & VARS --\\

local nicebones = {
	"ValveBiped.Bip01_Head1",
	"ValveBiped.Bip01_Neck1",
	"ValveBiped.Bip01_Spine",
	"ValveBiped.Bip01_Spine1",
	"ValveBiped.Bip01_Spine2",
	"ValveBiped.Bip01_Spine4",
	"ValveBiped.Bip01_R_UpperArm",
	"ValveBiped.Bip01_R_Forearm",
	"ValveBiped.Bip01_R_Hand",
	"ValveBiped.Bip01_L_UpperArm",
	"ValveBiped.Bip01_L_Forearm",
	"ValveBiped.Bip01_L_Hand",
	"ValveBiped.Bip01_R_Thigh",
	"ValveBiped.Bip01_R_Calf",
	"ValveBiped.Bip01_R_Foot",
	"ValveBiped.Bip01_R_Toe0",
	"ValveBiped.Bip01_L_Thigh",
	"ValveBiped.Bip01_L_Calf",
	"ValveBiped.Bip01_L_Foot",
	"ValveBiped.Bip01_L_Toe0",
}

local antiswitch = false 

function kat.checkhitbox(ply)
    if kat.getc("headshot_only"):GetBool() then return util.TraceLine({start = LocalPlayer():EyePos(), endpos = ply:GetBonePosition(ply:LookupBone("ValveBiped.Bip01_Head1")), mask = MASK_SHOT, filter = {G.LocalPlayer(), ply},}).Fraction == 1 && "ValveBiped.Bip01_Head1" end 

    for k,v in G.pairs(nicebones) do 
        if util.TraceLine({start = LocalPlayer():EyePos(), endpos = ply:GetBonePosition(ply:LookupBone(v)), mask = MASK_SHOT, filter = {G.LocalPlayer(), ply},}).Fraction == 1 then 
            return v
        end
    end
end

function kat.checkignores(ply)
    if kat.getc("ignore_bot"):GetBool() && ply:IsBot() then return true end 
    if kat.getc("ignore_team"):GetBool() && ply:Team() == lp:Team() && G.engine.ActiveGamemode() != "sandbox" then return true end 
    if kat.getc("ignore_staff"):GetBool() && !ply:IsUserGroup("user") && ply:IsAdmin() then return true end
    if kat.getc("ignore_noclip") && ply:GetMoveType() == MOVETYPE_NOCLIP then return true end  
    if kat.getc("ignore_cloak") && ply:GetColor().a != 255 then return true end 
end

function kat.getc(name)
    return convars["kat_" .. name]
end

--// AIMBOT --\\

function kat.aimbot(cmd)
    if !kat.getc("aimbot"):GetBool() then return end 
    if cmd:CommandNumber() == 0 && kat.getc("silent"):GetBool() then return end

    local ply_table = {0,0}

    -- GETTING THE PLAYER WERE GONNA SHOOT AT
    for k,v in G.pairs(G.player.GetAll()) do 

        if !v:Alive() || v:Health() <= 0 || v:IsDormant() || v == lp then continue end  
        if kat.checkignores(v) then continue end 

        -- sort by if they player is closer to the center then others
        local eyes = v:EyePos():ToScreen()
        local fov = G.math.Dist(x / 2, y / 2, eyes.x, eyes.y)

        if ply_table[1] > fov || ply_table[2] == 0 then 
            local hit = kat.checkhitbox(v) -- also getting the hitbox we shoot at 
            if !hit then continue end 

            ply_table = {fov,v,hit}
        end
    end

    local target,hitbox = ply_table[2],ply_table[3]
    
    if !target || target == 0 then return end -- no target 

    -- find hitbox location 
    hitbox = target:GetBonePosition( target:LookupBone( hitbox ) )

    -- calculate angle
    local fin_pos = hitbox-G.EyePos()
 
    -- make it into an angle since rn its a vector
    fin_pos = fin_pos:Angle()

    -- compensate for recoil
    if kat.getc("recoil"):GetBool() then 
        fin_pos = fin_pos - lp:GetViewPunchAngles()
    end

    -- set angle
    cmd:SetViewAngles(fin_pos)

    if lp:KeyDown(IN_ATTACK) then 
        local angs = cmd:GetViewAngles()
        local spread = kat.predictspread(cmd,angs)
        cmd:SetViewAngles(angs+G.Angle(spread.x,spread.y,spread.z))
    end


    -- autofire 
    if kat.getc("autoshoot"):GetBool() then 
        if lp:KeyDown(IN_ATTACK) then
            cmd:RemoveKey(IN_ATTACK) -- remove shooting, if we don't do this we're basically just holding mouse1 and it wouldn't work with pistols
        else
            cmd:AddKey(IN_ATTACK) -- shoot
        end
    end

    -- fix movement (if silent)
    if kat.getc("silent"):GetBool() then 
        kat.silentmove(cmd) 
    end
end

--// SILENT & NO SPREAD --\\

local silent_angle;
local sens,cones,nullvec = G.GetConVar("sensitivity"):GetFloat(),{},G.Vector(-1,-1,-1)

function kat.predictspread(cmd,ang)
    if kat.getc("spread"):GetBool() then 
        local swep = lp:GetActiveWeapon()

        if !swep then return ang:Forward() end

        if cones[swep:GetClass()] then 
            return dickwrap.Predict(cmd, ang:Forward(), cones[swep:GetClass()])
        else 
            return ang:Forward()
        end
    end
    return ang:Forward()
end

function kat.silentmove(cmd)
    if !silent_angle then silent_angle = cmd:GetViewAngles() end 

    local vec = G.Vector(cmd:GetForwardMove(), cmd:GetSideMove(), 0)
	local vel = G.math.sqrt(vec.x * vec.x + vec.y * vec.y)
	local mang = vec:Angle()
	local yaw = cmd:GetViewAngles().y - silent_angle.y + mang.y
 
	if ( ( cmd:GetViewAngles().p + 90 ) % 360 ) > 180 then
		yaw = 180 - yaw
	end
 
	yaw = ( ( yaw + 180 ) % 360 ) - 180
 
	cmd:SetForwardMove( G.math.cos( G.math.rad( yaw ) ) * vel )
	cmd:SetSideMove( G.math.sin( G.math.rad( yaw ) ) * vel )

end

function kat.silentangle(cmd)
    if !silent_angle then silent_angle = cmd:GetViewAngles() end 

    if cmd:CommandNumber() == 0 then
        if kat.getc("silent"):GetBool() || kat.getc("antiaim"):GetBool() then 
            silent_angle = silent_angle + G.Angle( cmd:GetMouseY() * sens/100, cmd:GetMouseX() * -(sens/100), 0 )

            silent_angle.x = G.math.NormalizeAngle(silent_angle.x)

            silent_angle.p = G.math.Clamp(silent_angle.p, -89, 89)

            cmd:SetViewAngles(silent_angle)
        end
    end
end

--// VISUALS --\\

function kat.startVisuals()
    if !kat.getc("esp"):GetBool() then return end 

    local box,name,wep,health,glow = kat.getc("box"):GetBool(),kat.getc("name"):GetBool(),kat.getc("weapon"):GetBool(),kat.getc("healthbar"):GetBool(),kat.getc("glow"):GetBool()

    for k,v in G.ipairs(G.player.GetAll()) do 
        if !v || v:IsDormant() || !v:Alive() || v:Health() <= 0 || v == lp then continue end 

        local pos = v:GetPos()
        local min, max = v:GetCollisionBounds()
        local pos2 = (pos + G.Vector(0, 0, max.z)):ToScreen()

        pos = pos:ToScreen()
        
        local h = pos.y - pos2.y
        local w = h / 2

        -- BOX ESP -- 
        if box then 
            G.surface.SetDrawColor(255,255,255) -- the white
            G.surface.DrawOutlinedRect(pos.x - w / 2, pos.y - h + 2, w, h)
            G.surface.SetDrawColor(0,0,0,75) -- the outline
            G.surface.DrawOutlinedRect(pos.x - w / 2 - 1, pos.y - h - 1 + 4, w + 2, h - 2)
        end 

        -- NAME ESP --
        if name then 
            G.draw.SimpleText(v:Name(), "ESPFont", pos.x, pos.y - h - 5, G.Color(255,255,255), 1, 1)
        end

        -- WEAPON ESP --
        if wep then 
            local wep = v:GetActiveWeapon()       
            if G.IsValid(wep) then 
                G.draw.SimpleText(G.string.lower(G.language.GetPhrase(wep:GetClass())), "SmallESPFont", pos.x, pos.y + 8, G.Color(255,255,255), 1, 1)
            else -- if they are stripped or gamemode restricts their guns
                G.draw.SimpleText("unarmed", "SmallESPFont", pos.x, pos.y + 8, G.Color(255,255,255), 1, 1)
            end
        end

        -- GLOW ESP --
        if glow then 
            G.halo.Add({v, v:GetActiveWeapon()}, G.Color(75,0,130), 1, 1, 5, true, true)
        end

        -- HEALTHBAR ESP -- 
        if health then 
            -- lerping healthbar --
            v.health = v:Health()
            v.healthnum = v:Health()
            v.oldHP = v.oldHP or 100

            if(v.oldHP ~= v.health and v.health == 100) then v.oldHP = 100 end 

            if(oldHP ~= v:Health()) then 
                v.health = G.Lerp(0.025,v.oldHP,v:Health())
                v.oldHP = G.Lerp(0.025,v.oldHP,v:Health())
                v.healthnum = G.Lerp(0.030,v.oldHP,v:Health())
            else
                v.oldHP = v.health
            end
            --------------------------------------------

            local hp = h * v.health / 100
            if(hp > h) then hp = h end
            local diff = h - hp

            G.surface.SetDrawColor(0, 0, 0, 150)
            G.surface.DrawRect(pos.x - w / 2 - 6, pos.y - h + 2, 3, h)
            G.surface.DrawRect(pos.x - w / 2 - 7, pos.y - h + 2, 3, h)

            local col = Color((150 - v.health) * 2.55, v.health * 2.55, 0, 255)
            if(v:Health() > 75) then 
                col = G.Color(v.health * 1.50, v.health * 2.55, 0, 255)
            end 
            G.surface.SetDrawColor(col)

            if v:Health() <= 92 then 
                -- because skeet.
                local rounded = G.math.Round(v.health)
                G.draw.SimpleText(rounded .. "%", "SmallESPFont", pos.x - w / 2 - (15+(rounded >= 10 and 4 or .5 )), pos.y - h + diff + 4, col, 1, 1)
            end

            G.surface.DrawRect(pos.x - w / 2 - 6, pos.y - h + 2 + diff, 2, hp)
        end

    end
end

--// MISC --\\

function kat.bunnyhop(cmd)
    if(!lp:IsOnGround() && cmd:KeyDown(IN_JUMP) && kat.getc("bhop"):GetBool()) then
        cmd:RemoveKey(IN_JUMP) -- allows you to spam it without letting go
    end

    if kat.getc("autostrafe"):GetBool() then
        if(!lp:IsOnGround()) then
            if lp:GetMoveType() == MOVETYPE_NOCLIP || lp:IsFlagSet(1024) || lp:Team() == TEAM_SPECTATOR || !lp:Alive() then return end 

            if(cmd:GetMouseX() > 1 || cmd:GetMouseX() < - 1) then
                cmd:SetSideMove( cmd:GetMouseX() > 1 && 10000 || -10000 ) -- for changing directions
            else
                cmd:SetSideMove( (cmd:CommandNumber() % 2 == 0) && 10000 || -10000 ) -- for changing directions when you hit something like a prop
            end
            cmd:SetForwardMove(5 * lp:GetVelocity():Length2D()) -- makes you go forward
        end
    end
end

function kat.antiaim(cmd)
    if cmd:KeyDown(IN_ATTACK) || lp:Team() == TEAM_SPECTATOR || lp:GetMoveType() == MOVETYPE_NOCLIP then return end 
    if cmd:CommandNumber() == 0 then return end 
    if !kat.getc("antiaim"):GetBool() then return end 

    local method = kat.getc("method"):GetString()

    local angle = cmd:GetViewAngles()

    local fake,real = kat.getc("fake_yaw"):GetFloat(),kat.getc("yaw"):GetFloat()

    real = real + angle.y

    angle.x = kat.getc("pitch"):GetFloat()

    if method == "overflow" then 
        angle.y = math.sin(math.pi*fake) + real 
    elseif method == "fake angles" then 
        if bSendPacket then 
            angle.y = fake 
            if cmd:CommandNumber() % 2 == 0 then 
                bSendPacket = false 
            end
        else
            angle.y = real
            bSendPacket = true 
        end
    elseif method == "micromovements" then 
        local threshold = kat.getc("micromovements_threshold"):GetFloat()

        if bSendPacket then 
            angle.y = fake 
            bSendPacket = false 
            cmd:SetSideMove(cmd:GetSideMove() + (G.engine.TickCount() % 2 == 0 && -threshold or threshold))
        else
            angle.y = real 
            bSendPacket = true 
        end
    end

    if kat.getc("lby"):GetBool() && G.engine.TickCount() % 10 == 0 then 
        angle.y = kat.getc("lby_angle"):GetFloat()
    end

    cmd:SetViewAngles(angle)

    kat.silentmove(cmd) 
end

--// MENU --\\

local menu = {}

menu.frame = G.vgui.Create("DFrame")
menu.frame:SetSize(400, 250)
menu.frame:Center()
menu.frame:SetTitle("kathak beta")
menu.frame:SetVisible(false)
menu.frame:SetDraggable(true)
menu.frame:SetSizable(false)
menu.frame:ShowCloseButton(true)
menu.frame:SetDeleteOnClose(false)
menu.frame:MakePopup()
menu.frame.Paint = function(self,w,h)
    surface.SetDrawColor(26, 27, 29)
    surface.DrawRect(0, 0, w, h)
    
    surface.SetDrawColor( 55,55,55 )    
    surface.DrawOutlinedRect(0, 0, w, h)
    
    surface.SetDrawColor(55,55,55)
    surface.DrawRect(10, 50, 40, 30)

    surface.SetDrawColor(26, 27, 29)
    surface.DrawRect(2, 35, w - 4, h - 37)		

    surface.SetMaterial(Material("gui/gradient_up"))
    surface.SetDrawColor(26, 27, 29)
    surface.DrawOutlinedRect(1, 1, w - 2, h -421)
end

menu.sheet = G.vgui.Create( "DColumnSheet", menu.frame )
menu.sheet:Dock( FILL )
menu.sheet.Paint = function(self,w,h)
    surface.SetDrawColor( Color(25, 25, 25, 255) )
    surface.DrawRect(0, 0, w, h)
end

local tab_aimbot = vgui.Create( "DPanel", menu.sheet )
local tab_wallhack = vgui.Create( "DPanel", menu.sheet )
local tab_other = vgui.Create( "DPanel", menu.sheet )

tab_aimbot:Dock( FILL )
tab_wallhack:Dock( FILL )
tab_other:Dock( FILL )

menu.sheet:AddSheet( "aimbot", tab_aimbot)
menu.sheet:AddSheet( "wallhack", tab_wallhack)
menu.sheet:AddSheet( "other", tab_other)

menu.gen = {tab_aimbot,tab_wallhack,tab_other}

function menu.checkbox(panel,txt,convar)
    local DCheckBoxLabel = vgui.Create( "DCheckBoxLabel", panel )
    DCheckBoxLabel:Dock( TOP )
    DCheckBoxLabel:DockMargin( 4, 4, 0, 0 )
    DCheckBoxLabel:SetText( txt )
    DCheckBoxLabel:SetConVar( convar )
    DCheckBoxLabel:SetValue( G.GetConVar(convar):GetBool() )
    DCheckBoxLabel:SetTextColor( G.Color(0,0,0) )
    DCheckBoxLabel:SizeToContents()
    DCheckBoxLabel.Button.Paint = function( s, w, h )
        G.draw.RoundedBox( 0, 2, 2, w - 5, h -5, G.Color( 255, 255, 224 ) )
        if s:GetChecked() then
            G.draw.RoundedBox( 0, 2, 2, w - 5, h -5, G.Color( 75,0,130 ) )

            if s:IsHovered() then
                G.draw.RoundedBox( 0, 2, 2, w - 5, h -5, G.Color( 100,25,160 ) )
            end

        end
        G.surface.SetDrawColor( 0, 0, 0 )
        G.surface.DrawOutlinedRect( 2, 2, w - 5, h -5 )
    end
end

for i,p in G.pairs(menu_loop) do
    for k,v in G.pairs(p) do 
        if v[1] == 0 then 
            menu.checkbox(menu.gen[i],v[2],v[3])
        end
    end
end


G.concommand.Add("kat_menu", function() menu.frame:SetVisible(true) end)

--// HOOKS --\\

G.hook.Add("RenderScreenspaceEffects", "loki_rse", function()
    if kat.getc("chams"):GetBool() then 
        local flat,walls = kat.getc("chams_flat"):GetBool(),kat.getc("chams_los"):GetBool()

        for k,v in G.ipairs(G.player.GetAll()) do 
            if v:Health() <= 0 || v == lp then continue end 

            cam.Start3D() -- start the drawing so we can actually draw over a player in 3d (otherwise its 2d and doesn't help us)

            if flat then render.SuppressEngineLighting( true ) else render.SuppressEngineLighting( false ) end -- removes shadows

            local wep = v:GetActiveWeapon()

            if walls then -- render it with ignorez flag
                render.MaterialOverride(chamsmat)
                render.SetColorModulation(169/255,169/255,169/255)
                v:DrawModel()
            end

            render.MaterialOverride(chamsmat2) -- render it without ignorez flag
            render.SetColorModulation(75/255,0/255,130/255)
            v:DrawModel()

            render.SetColorModulation(1, 1, 1) -- this is just to make sure the color doesn't get
            -- overriden by gmod

            cam.End3D()

        end

    end
end)

G.hook.Add("CreateMove", "loki_cm", function(cmd)
    kat.bunnyhop(cmd)

    kat.silentangle(cmd)
    kat.aimbot(cmd)
    kat.antiaim(cmd)
end)

G.hook.Add("DrawOverlay", "loki_do", function()
    kat.startVisuals()
end)

GAMEMODE["EntityFireBullets"] = function(self, p, data) local swep = lp:GetActiveWeapon() local spread = data.Spread if (not swep or not G.IsValid(swep) or cones[swep:GetClass()] == spread or spread == nullvec) then return end cones[swep:GetClass()] = spread end
