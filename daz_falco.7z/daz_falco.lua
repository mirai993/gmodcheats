print("OPENING FALCO'S SCRIPTS!")
print("MERGED INTO ONE SCRIPT BY XYLUS AND DAZ")
local cansay = true
FALCO_CHATTIME = 1.6
local OOC = CreateClientConVar("falco_ooc", 1, true, false)

function Falco_DelayedSay(text)
	if cansay then
		local add = ""
		if OOC:GetInt() == 1 and GetGlobalInt("alltalk") == 0 then add = "/ooc " end
		local endresult = add.. tostring(text)
		if string.len(endresult) >= 126 then
			timer.Simple(1.62, Falco_DelayedSay, string.sub(endresult, 127))
		end
		LocalPlayer():ConCommand("say " ..string.sub(endresult, 1, 126))
		cansay = false
		timer.Simple(FALCO_CHATTIME, function() cansay = true end)
	else
		timer.Simple(FALCO_CHATTIME, Falco_DelayedSay, text)
	end
end
--Example:
concommand.Add("falco_hiall", function()
	local hiall = ""
	for k,v in pairs(player.GetAll()) do 
		if v ~= LocalPlayer() then
			hiall = hiall ..", hi " .. v:Nick()
		end
	end
	hiall = string.sub(hiall, 3)
	Falco_DelayedSay(hiall)
end)

FALCO_CHATCOMMANDS = {}

function falco_addchatcmd(text, func)
	FALCO_CHATCOMMANDS[text] = func
end

function FALCO_CHAT(ply, text, teamonly, dead)
	if ply == LocalPlayer() then
		cansay = false
		timer.Simple(2.1, function() cansay = true end)
		for k,v in pairs(FALCO_CHATCOMMANDS) do
			if string.lower(string.sub(text,1, string.len(k))) == string.lower(k) then 
				v(string.sub(text, string.len(k) + 2)) 
				break
			elseif string.lower(string.sub(text, 7, string.len(k) + 6)) == string.lower(k) then
				v(string.sub(text, string.len(k) + 8)) 
			end
		end
	end	
end
hook.Add( "OnPlayerChat", "Falco_chat", FALCO_CHAT)
falco_addchatcmd("Falco_ReloadScripts", function() include("autorun/client/falcoutilities.lua") end)
falco_addchatcmd("FReloadScripts", function() include("autorun/client/falcoutilities.lua") end)
concommand.Add("Falco_ReloadScripts", function() include("autorun/client/falcoutilities.lua") end)
concommand.Add("FReloadScripts", function() include("autorun/client/falcoutilities.lua") end)

function fnotify(text, a, b)
	local Type, Length = a, b
	if not a and not b then
		Type, Length = 1, 5
	end
	if GAMEMODE.IsSandboxDerived then // in some gamemodes GAMEMODE:AddNotify() doesn't exist
		GAMEMODE:AddNotify(tostring(text), Type, Length)
		surface.PlaySound( "ambient/water/drip2.wav") // I don't care about the other drips so no difficult concatenations or something
	end
end

for k,v in pairs(file.FindInLua("falco/*.lua")) do include("falco/"..v) end

function FalcoPlayerDeath( Victim, Inflictor, Attacker )
	local NewAttacker = Attacker
	local NewInflictor = Inflictor
	
	if Attacker:GetNWEntity("OwnerObj"):IsValid() then
		NewAttacker = Attacker:GetNWEntity("OwnerObj")
		NewInflictor = Attacker
	end
	
 	if ( NewInflictor and NewInflictor == NewAttacker and (NewInflictor:IsPlayer() or NewInflictor:IsNPC()) ) then
 		NewInflictor = NewInflictor:GetActiveWeapon()
 		if ( !NewInflictor or NewInflictor == NULL ) then NewInflictor = NewAttacker end
 	end

 	if NewAttacker:IsPlayer() and not NewInflictor:IsPlayer() then
		for k,v in pairs(player.GetAll()) do
			if v:IsAdmin() then
				if Attacker:GetClass() == "prop_physics" then
					v:PrintMessage(HUD_PRINTCONSOLE, "\nKILL:\n"..NewAttacker:Nick().. " killed "..Victim:Nick() .." with a " ..NewInflictor:GetClass().. "\nThis doesn't mean "..NewAttacker:Nick().. " is the killer but the chance is big!\n\n")
				else
					v:PrintMessage(HUD_PRINTCONSOLE, "\nKILL:\n"..NewAttacker:Nick().. " killed "..Victim:Nick() .." with a " ..NewInflictor:GetClass().."\n\n")
				end
			end
		end
		return
	end
	
	for k,v in pairs(player.GetAll()) do
		if v:IsAdmin() then
			if NewInflictor == Victim then 
				v:PrintMessage(HUD_PRINTCONSOLE, "\nSUICIDE:\n"..Victim:Nick().. " suicided!!!\n")
			else
				v:PrintMessage(HUD_PRINTCONSOLE, "\nKILL:\n"..Victim:Nick().. " Got killed by " ..NewAttacker:GetClass().. " with a " .. NewInflictor:GetClass().."\n\n")
			end
		end
	end

end
hook.Add("PlayerDeath", "FalcoPlayerDeath", FalcoPlayerDeath)

local function supervise(ply)
	if ply.IsSuperVising then ply.NextSpawnTime = CurTime() ply:UnSpectate() ply:Spawn() return end
	if not ply:IsAdmin() then return end
	ply:KillSilent()
	ply:Spectate(OBS_MODE_ROAMING)
	ply.IsSuperVising = true
	ply.NextSpawnTime = CurTime() + 99999999
end
concommand.Add("supervise", supervise)
concommand.Add("poki_supervise", supervise)

hook.Add( "PlayerSpawnProp", "supervise", function(ply, model)
	if ply.IsSuperVising then return false end
end)

hook.Add("PlayerSpawn", "supervise", function(ply) 
	ply.IsSuperVising = nil
end)


local function GetPropWeight(ply)
	local ent = ply:GetEyeTrace().Entity
	if ValidEntity(ent) and ent:GetPhysicsObject():IsValid() then
		ply:ChatPrint("Weight: " .. tostring(ent:GetPhysicsObject():GetMass()))
	end
end
concommand.Add("PoKi_Getweight", GetPropWeight)

local IsSpectating = false
local holding = {}
local SpectatePosition = Vector(0,0,0)
local CanMove = true // for if you're in an object you mustn't be able to move
local SaveAngles = Angle(0,0,0) // Only used when spectating an object
local SpecEnt = LocalPlayer()
local speed = 15
local SpecEntSaveAngle = Angle(0,0,0)
local camsdata = {}
local camsize = CreateClientConVar("Falco_SpecScreenSize", 5, true, false)
local LockMouse = CreateClientConVar("Falco_SpecLockMouse", 0, true, false)
local SpecSpeed = CreateClientConVar("Falco_SpecSpeed", 50, true, false)
local ThPDist = 100
local SpecAng = Angle(0,0,0)
local IsPlayer = true


local RayOn = false
local AllMats = {}
local allcolors = {}
local FSetColor = _R.Entity.SetColor
local FSetMat = _R.Entity.SetMaterial
local FGetMat = _R.Entity.GetMaterial
local repmat = CreateClientConVar("falco_xraymaterial", "mat2", true, false)

local function TogglePoKiRay()
	if RayOn then
		surface.PlaySound("buttons/button19.wav") 
		for k,v in pairs(ents.GetAll()) do
			FSetMat(v, AllMats[v])
			local z = allcolors[v]
			if z and type(z) == "table" then
				FSetColor(v, z.r, z.g, z.b, z.a)
			else 
				FSetColor(v, 255,255,255,255)
			end
		end
		allcolors = {}
	else
		for k,v in pairs(ents.GetAll()) do
			ExecFRayOnce(v)
		end
		surface.PlaySound("buttons/button1.wav") 
	end
	RayOn = not RayOn
end
concommand.Add("falco_xray", TogglePoKiRay)

function ExecFRayOnce(v)
	local r,g,b,a = v:GetColor()
	local class = v:GetClass()
	local low = string.lower(class)
	if v:IsNPC() and (r ~= 0 or g ~= 0 or b ~= 255 or a ~= 255) then
		allcolors[v] = Color(r,g,b,a)
		FSetColor(v, 0, 0, 255, 255)
	elseif v:IsWeapon() and (r ~= 140 or g ~= 0 or b ~= 255 or a ~= 255) then
		allcolors[v] = Color(r,g,b,a)
		FSetColor(v, 140, 0, 255, 255)
	elseif string.find(class, "ghost") and a ~= 100 then
		allcolors[v] = Color(r,g,b,a)
		FSetColor(v, 255,255,255,100)
	elseif (class == "drug_lab" or class == "money_printer") and (r ~= 255 or g ~= 0 or b ~= 100 or a ~= 50) then
		allcolors[v] = Color(r,g,b,a)
		FSetColor(v, 255, 0, 100, 50)
	elseif not v:IsPlayer() and not v:IsNPC() and class ~= "prop_physics" and class ~= "prop" and class ~= "drug_lab" and class ~= "money_printer" and not v:IsWeapon() and class ~= "viewmodel" and not string.find(class, "ghost") and ( r ~= 255 or g ~= 200 or b ~= 0 or a ~= 100) then
		allcolors[v] = Color(r,g,b,a)
		FSetColor(v, 255, 200, 0, 100)
	end
	if class ~= "viewmodel" and FGetMat(v) ~= repmat:GetString() and class ~= "func_door" and class ~= "func_door_rotating" and class ~= "prop_door_rotating" and not string.find(class, "ghost") then
		AllMats[v] = FGetMat(v)
		FSetMat(v, repmat:GetString())
	end
end

function DoPoKiRay()
	if not RayOn then return end
	for k,v in pairs(ents.FindByClass("prop_physics")) do
		if ValidEntity(v) then
			FSetColor(v,50, 255, 50, 40)
			FSetMat(v, repmat:GetString())
		end
	end
	
	for k,v in pairs(ents.FindByClass("prop")) do
		if ValidEntity(v) then
			FSetColor(v,50, 255, 50, 40)
			FSetMat(v, repmat:GetString())
		end
	end
	
	for k,v in pairs(player.GetAll()) do
		if ValidEntity(v) then
			FSetColor(v,255,0,0,255)
			FSetMat(v, repmat:GetString())
		end
	end
end 
hook.Add( "RenderScene", "PoKiRay", DoPoKiRay)

local function FDynamicLight()
	local dlight = DynamicLight( LocalPlayer():UserID() ) 
	if dlight then 
		dlight.Pos = LocalPlayer():GetEyeTrace().HitPos
		dlight.r = 255
		dlight.g = 255 
		dlight.b = 255
		dlight.Brightness = 10 
		dlight.Size = 700
		dlight.Decay = 0 
		dlight.DieTime = CurTime() + 0.2
	end 
end  
 
local togglelight = true
concommand.Add("falco_light", function()
	togglelight = not togglelight
	LocalPlayer():EmitSound("items/flashlight1.wav",100,100)
	if togglelight then
		hook.Remove("Think", "Falco_Light")
	else
		hook.Add("Think", "Falco_Light", FDynamicLight)
	end
end)

local toggle = false
local net_graph = GetConVarNumber("net_graph")
local showfps = GetConVarNumber("cl_showfps")


local function CameraMode(ply, cmd, args)
	toggle = not toggle
	if toggle then 
		RunConsoleCommand("physgun_drawbeams", 0)
		RunConsoleCommand("cl_drawthrusterseffects", 0)
		RunConsoleCommand("cl_drawhoverballs", 0)
		RunConsoleCommand("cl_drawcameras", 0)
		RunConsoleCommand("net_graph", 0)
		RunConsoleCommand("cl_showfps", 0)
		hook.Add("HUDShouldDraw", "HideThings", function()
			return false 
		end)
	else
		RunConsoleCommand("physgun_drawbeams", 1)
		RunConsoleCommand("cl_drawthrusterseffects", 1)
		RunConsoleCommand("cl_drawhoverballs", 1)
		RunConsoleCommand("cl_drawcameras", 1)
		RunConsoleCommand("net_graph", net_graph)
		RunConsoleCommand("cl_showfps", showfps)
		hook.Remove("HUDShouldDraw", "HideThings")
	end
end
concommand.Add("falco_cameramode", CameraMode)



function EntityInformation()
	local trace = LocalPlayer():GetEyeTrace()
	print(trace.Entity:GetClass())
	print(trace.Entity:GetModel())
	if trace.Hit and trace.Entity:IsValid() and string.find(string.lower(trace.Entity:GetClass()), "prop") then 
		print(trace.Entity:GetModel())
		print(trace.Entity:GetOwner())
		print(trace.Entity:Health())
		PrintTable(trace.Entity:GetTable())
	elseif trace.Hit and trace.Entity:IsValid() and trace.Entity:GetClass() == "player" then
		print(trace.Entity:Nick())
		print(trace.Entity:Health())
		print(trace.Entity:GetActiveWeapon():GetPrintName())
		print("the guy you're looking at is admin:", trace.Entity:IsAdmin())
	end
end
concommand.Add("falco_GetModel", EntityInformation)

local PlayersHaveVoted = {}
local IsVoting = false
local VoteResults = {}

VoteResults.yes = 0
VoteResults.no = 0

local function FStartVote(text)
	print(1)
	IsVoting = true
	timer.Simple(3, RunConsoleCommand, "say", "/advert Falcovote: \"" .. text .. "\" Vote by saying !yes or !no")
	timer.Create("FVote", 120, 1, StopFalcoVote)
end
falco_addchatcmd("fvote", FStartVote)
falco_addchatcmd("(OOC) fvote", FStartVote)

local function GetVotes(ply, text, teamonly, dead)
	if not IsVoting then return end
	if ply ~= LocalPlayer() and ply:EntIndex() ~= 0 and not table.HasValue(PlayersHaveVoted, ply) then
		if string.find(string.lower(text), "!yes") or string.find(string.lower(text), "/yes") then
			table.insert(PlayersHaveVoted, ply)
			VoteResults.yes = VoteResults.yes + 1
			Falco_DelayedSay("'" ..tostring(ply:Nick()) .. "' voted yes")
		elseif string.find(string.lower(text), "!no") or string.find(string.lower(text), "!no") then
			table.insert(PlayersHaveVoted, ply)
			VoteResults.no = VoteResults.no + 1
			Falco_DelayedSay("'" .. tostring(ply:Nick()) .. "' voted no") 
		end
		if VoteResults.no + VoteResults.yes == #player.GetAll() - 1 then
			timer.Remove("FVote")
			StopFalcoVote()
		end
	elseif ply ~= LocalPlayer() and table.HasValue(PlayersHaveVoted, ply) and ( string.find(string.lower(text), "!yes") or string.find(string.lower(text), "/yes") or string.find(string.lower(text), "!no") or string.find(string.lower(text), "!no")) then
		Falco_DelayedSay("'" ..tostring( ply:Nick()) .. "' already voted. Can't vote twice")
	end	
end
hook.Add( "OnPlayerChat", "FGetVotes", GetVotes)

function StopFalcoVote()
	IsVoting = false
	Falco_DelayedSay("The vote has ended, These are the results:")
	if VoteResults.yes > VoteResults.no then 
		addition = "option yes won"
	elseif VoteResults.yes == VoteResults.no then
		addition = "no option won"
	elseif VoteResults.yes < VoteResults.no then
		addition = "option no won"
	end
	
	if VoteResults.yes == VoteResults.no and VoteResults.yes == 0 then
		addition = "Nobody voted :("
	end
	Falco_DelayedSay("Yes: " .. tostring(VoteResults.yes) .. ", no: " .. tostring(VoteResults.no) .. "    " ..  addition)
	VoteResults.yes = 0
	VoteResults.no = 0
	PlayersHaveVoted = {}
end

local wait = false
local enabled = CreateClientConVar("falco_PropKillDetector", 0, true, false)
function GetPropKiller()
	if enabled:GetInt() == 1 then
		if not LocalPlayer():Alive() and not wait then
			wait = true
			for k,v in pairs(ents.FindInSphere(LocalPlayer():GetShootPos(), 100)) do
				if v:GetClass() == "prop_physics" and v:GetNWString("Owner") ~= "" and v:GetNWString("Owner") ~= LocalPlayer():Nick() and v:GetNWString("Owner") ~= "Shared" and v:GetNWString("Owner") ~= "World" then
					RunConsoleCommand("say", v:GetNWString("Owner") .. ", did you propkill me?")
				end
			end
		elseif LocalPlayer():Alive() and wait then
			wait = false
		end
	end
end
hook.Add("Think", "GetPropKiller", GetPropKiller)

local IsSpectating = false
local holding = {}
local SpectatePosition = Vector(0,0,0)
local CanMove = true // for if you're in an object you mustn't be able to move
local SaveAngles = Angle(0,0,0) // Only used when spectating an object
local SpecEnt = LocalPlayer()
local speed = 15
local SpecEntSaveAngle = Angle(0,0,0)
local camsdata = {}
local camsize = CreateClientConVar("Falco_SpecScreenSize", 5, true, false)
local LockMouse = CreateClientConVar("Falco_SpecLockMouse", 0, true, false)
local SpecSpeed = CreateClientConVar("Falco_SpecSpeed", 50, true, false)
local ThPDist = 100
local SpecAng = Angle(0,0,0)
local IsPlayer = false


local function SelectSomeone()//DONT SAY IT'S STOLEN FROM THE GODDAMN PLAYER POSSESSOR SWEP! I GODDAMN MAAAAADE THE PLAYER POSSESSOR SWEP!
	holding = {}
	if table.Count(player.GetAll()) <= 1  then
		fnotify("You're the only one in the server")
		return
	end
	local frame = vgui.Create("DFrame")
	local button = {}
	local PosSize = {}
	
	frame:SetSize( 200, 500 )
	frame:Center()
	frame:SetVisible(true)
	frame:MakePopup()
	frame:SetTitle("Choose a player")
	
	PosSize[0] = 5
	local sorted = player.GetAll()
	table.sort(sorted, function(a, b) return a:Nick() < b:Nick() end )
	for k,v in pairs(sorted) do
		if v == LocalPlayer() then
			PosSize[k] = PosSize[k-1]
		elseif v!= LocalPlayer() then
			PosSize[k] = PosSize[k-1] + 30
			frame:SetSize(200, PosSize[k] + 40)
			button[k] = vgui.Create("DButton", frame)
			button[k]:SetPos( 20, PosSize[k])
			button[k]:SetSize( 160, 20 )
			button[k]:SetText( v:Nick())
			frame:Center()
			button[k]["DoClick"] = function()
				if not ValidEntity(v) then fnotify("Can't spectate him at the moment") return end
				if ValidEntity(SpecEnt) then
					SpecEnt:SetNoDraw(false)
				end
				CanMove = false
				SpecEnt = v
				IsPlayer = true
			end
		end
	end
end

local function OptionsDerma()
	local frame = vgui.Create( "DFrame" )
	frame:SetTitle( "Spectate config" )
	frame:SetSize( 300, 300 ) 
	frame:Center()
	frame:SetVisible( true )
	frame:MakePopup( )
	
	local Panel = vgui.Create( "DPanelList", frame )
	Panel:SetPos(20,30)
	Panel:SetSize(260, 260)
	Panel:SetSpacing(5)
	Panel:EnableHorizontal( false )
	Panel:EnableVerticalScrollbar( true )
	
	local SelectPerson = vgui.Create( "DButton", frame)
	SelectPerson:SetText( "Select someone to spectate" )
	SelectPerson:SetSize(220, 20)
	function SelectPerson:DoClick()
		frame:Close()
		SelectSomeone()
	end	
	Panel:AddItem(SelectPerson)
	
	local makescreen = vgui.Create( "DButton", frame)
	makescreen:SetText( "Make a screen" )
	makescreen:SetSize(220, 20)
	function makescreen:DoClick()
		if CanMove then
			table.insert(camsdata, {pos = SpectatePosition, ang = LocalPlayer():EyeAngles(), obj = false})
		elseif not CanMove then
			table.insert(camsdata, {obj = SpecEnt, dist = ThPDist, ang = SaveAngles, entang = SpecEntSaveAngle})
		end
		fnotify("Screen made")
		frame:Close()
	end	
	Panel:AddItem(makescreen)
	
	local RemoveScreen = vgui.Create( "DButton", frame)
	RemoveScreen:SetText( "Remove last screen" )
	RemoveScreen:SetSize(220, 20)
	function RemoveScreen:DoClick()
		if #camsdata > 0 then
			table.remove(camsdata, #camsdata) // remove the last one in the table
			fnotify("Last screen removed")
		end
	end	
	Panel:AddItem(RemoveScreen)
	
	if not CanMove and SpecEnt:IsValid() then
		local AddFESP = vgui.Create( "DButton", frame)
		AddFESP:SetText( "Add to FESP" )
		AddFESP:SetSize(220, 20)
		function AddFESP:DoClick()
			FESPAddEnt(SpecEnt, SpecEnt:EntIndex())
		end	
		Panel:AddItem(AddFESP)
		
		local RemoveFESP = vgui.Create( "DButton", frame)
		RemoveFESP:SetText( "Remove from FESP" )
		RemoveFESP:SetSize(220, 20)
		function RemoveFESP:DoClick()
			FESPRemoveEnt(SpecEnt:EntIndex())
		end	
		Panel:AddItem(RemoveFESP)
	end
	
	local ScreenSize = vgui.Create( "DNumSlider", frame )
	ScreenSize:SetValue(camsize:GetInt())
	ScreenSize:SetConVar("Falco_SpecScreenSize")
	ScreenSize:SetMin(1)
	ScreenSize:SetMax(20)
	ScreenSize:SetText("Set the screensize")
	ScreenSize:SetDecimals(2)
	Panel:AddItem(ScreenSize)
	
	local specspeedsldr = vgui.Create( "DNumSlider", frame )
	specspeedsldr:SetValue(SpecSpeed:GetInt())
	specspeedsldr:SetConVar("Falco_SpecSpeed")
	specspeedsldr:SetMin(1)
	specspeedsldr:SetMax(200)
	specspeedsldr:SetText("Set the spectate speed")
	specspeedsldr:SetDecimals(0)
	Panel:AddItem(specspeedsldr)
	
	local LockMousechkbx = vgui.Create( "DCheckBoxLabel", frame )
	LockMousechkbx:SetText("Lock mouse when spectating non-player")
	LockMousechkbx:SetConVar("Falco_SpecLockMouse")
	Panel:AddItem(LockMousechkbx)
end

local function BindPresses(ply, bind, pressed)
	local use = LocalPlayer():KeyDown(IN_USE)
	if (string.find(bind, "forward") or string.find(bind, "moveleft") or string.find(bind, "moveright") or string.find(bind, "back") or string.find(bind, "jump") or string.find(bind, "duck")) and not use then
		holding[string.sub(bind, 2)] = pressed
		return true 
	elseif string.find(bind, "speed") and pressed and not use then
		if speed <= 15 then speed = 50
		elseif speed == 50 then speed = 15
		end
		return true
	elseif string.find(bind, "walk") and pressed and not use then
		if speed ~= 2 then speed = 2
		elseif speed == 2 then speed = 15
		end
		return true
	elseif string.find(bind, "invprev") and pressed and not use then
		ThPDist = ThPDist - 10
		return true
	elseif string.find(bind, "invnext") and pressed and not use then
		ThPDist = ThPDist + 10
		return true
	elseif string.find(bind, "menu") and not string.find(bind, "context") and pressed then
		if not use then
			OptionsDerma()
			fnotify("Hold use + Q to open the spawnmenu while spectating")
			return true
		end
	elseif string.find(bind, "attack2") and pressed and not use then
		if SpecEnt and SpecEnt:IsPlayer() then
			IsPlayer = not IsPlayer
			return true
		end
	elseif string.find(bind, "reload") and pressed and not use then
		if CanMove then
			local Tracey = {}
			Tracey.start = SpectatePosition
			Tracey.endpos = SpectatePosition + SpecAng:Forward() * 100000000
			Tracey.filter = LocalPlayer() // in case you're aiming at yourself... IF that's even possible but I can't be arsed to test that
			local trace = util.TraceLine(Tracey)
			
			if trace.Hit and trace.Entity and ValidEntity(trace.Entity) and not trace.Entity:IsPlayer() then
				CanMove = false
				SpectatePosition = trace.Entity:LocalToWorld(trace.Entity:OBBCenter())
				SaveAngles = SpecAng//LocalPlayer():GetAimVector():Angle()
				SpecEntSaveAngle = trace.Entity:EyeAngles()
				SpecEnt = trace.Entity
				fnotify("Now spectating an entity")
				print("-----------------------------SPECTATING ENT INFO: -----------------------------------------------")
				print("Classname: ", trace.Entity:GetClass())
				print("Model: ", trace.Entity:GetModel())
				print("Owner: ", trace.Entity:GetNWString("Owner"))
				print("Distance to self: ", math.floor(trace.Entity:GetPos():Distance(LocalPlayer():GetPos())))
				print("Colour: ", trace.Entity:GetColor())
				print("ENT Index: ", trace.Entity:EntIndex())
				print("-----------------------------END OF ENT INFO: -----------------------------------------------")
			elseif trace.Hit and trace.Entity and ValidEntity(trace.Entity) and trace.Entity:IsPlayer() then
				print("-----------------------------SPECTATING ENT INFO: -----------------------------------------------")
				print("name: ", trace.Entity:Nick())
				print("Model: ", trace.Entity:GetModel())
				print("Money: ", "$"..trace.Entity:GetNWInt("Money"))
				print("UserID: ", trace.Entity:UserID())
				print("Distance to self: ", math.floor(trace.Entity:GetPos():Distance(LocalPlayer():GetPos())))
				print("Colour: ", trace.Entity:GetColor())
				print("ENT Index: ", trace.Entity:EntIndex())
				print("-----------------------------END OF ENT INFO: -----------------------------------------------")
				CanMove = false
				SpectatePosition = trace.Entity:GetShootPos()
				SpecEnt = trace.Entity
				IsPlayer = true
				fnotify("Now spectating " .. trace.Entity:Name())
			end
		elseif not CanMove then
			CanMove = true
			SpecEnt:SetNoDraw(false)
			if IsPlayer then
				if SpecEnt:IsPlayer() then
					SpectatePosition = SpecEnt:GetShootPos()
					SpecAng = SpecEnt:EyeAngles()
				else
					SpectatePosition = SpecEnt:GetPos()
					SpecAng = SpecEnt:EyeAngles()
				end
			end
			fnotify("Stopped spectating object")
		end
		return true
	end
end

local function DoMove(what)
	if CanMove then
		if string.find(what, "forward") then 
			SpectatePosition = SpectatePosition + SpecAng:Forward() * speed * RealFrameTime() * SpecSpeed:GetInt()
		elseif string.find(what, "back") then
			SpectatePosition = SpectatePosition - SpecAng:Forward() * speed * RealFrameTime() * SpecSpeed:GetInt()
		elseif string.find(what, "moveleft") then
			SpectatePosition = SpectatePosition - SpecAng:Right() * speed * RealFrameTime() * SpecSpeed:GetInt()
		elseif string.find(what, "moveright") then
			SpectatePosition = SpectatePosition + SpecAng:Right() * speed * RealFrameTime() * SpecSpeed:GetInt()
		elseif string.find(what, "jump") then
			SpectatePosition = SpectatePosition + Vector(0,0,speed * RealFrameTime() * SpecSpeed:GetInt())
		elseif string.find(what, "duck") then
			SpectatePosition = SpectatePosition - Vector(0,0,speed * RealFrameTime() * SpecSpeed:GetInt())
		end
	elseif not CanMove then
		if string.find(what, "forward") then // todo
			SaveAngles = SaveAngles + Angle(0.1 * speed * RealFrameTime() * SpecSpeed:GetInt(), 0, 0)
		elseif string.find(what, "back") then
			SaveAngles = SaveAngles - Angle(0.1 * speed * RealFrameTime() * SpecSpeed:GetInt(), 0, 0)
		elseif string.find(what, "moveleft") then
			SaveAngles = SaveAngles - Angle(0, 0.1 * speed * RealFrameTime() * SpecSpeed:GetInt(), 0)
		elseif string.find(what, "moveright") then
			SaveAngles = SaveAngles + Angle(0, 0.1 * speed * RealFrameTime() * SpecSpeed:GetInt(), 0)
		elseif string.find(what, "jump") then
			ThPDist = ThPDist + 0.5 * speed * RealFrameTime() * SpecSpeed:GetInt()
			if ThPDist > 10 then
				SpecEnt:SetNoDraw(false)
			end
		elseif string.find(what, "duck") and ThPDist > 3 then
			ThPDist = ThPDist - 0.5 * speed * RealFrameTime() * SpecSpeed:GetInt()
			if ThPDist <= 10 then
				SpecEnt:SetNoDraw(true)
			end
		end
	end
end

local function Thinks()
	for k,v in pairs(holding) do
		if v then
			DoMove(k)
		end
	end
end

local PLAYER = FindMetaTable("Player")
PLAYER.FalcooldEyeAngles = PLAYER.FalcooldEyeAngles or PLAYER.GetEyeTrace
function PLAYER:GetEyeTrace()
	if IsSpectating and CanMove and self == LocalPlayer() then
		local trace = {}
		trace.start = SpectatePosition
		trace.endpos = SpectatePosition + SpecAng:Forward() * 1000000
		trace.filter = LocalPlayer()
		traceline = util.TraceLine(trace)
		return traceline
	end
	return self:FalcooldEyeAngles()
end

local OldUtilPlayerTrace = util.GetPlayerTrace
function util.GetPlayerTrace(ply)
	if IsSpectating and ply == LocalPlayer() then
		local trace = {}
		trace.start = SpectatePosition
		trace.endpos = SpectatePosition + SpecAng:Forward() * 1000000
		trace.filter = LocalPlayer()
		return trace
	end
	return OldUtilPlayerTrace(ply)
end

local function CalcViews(ply, origin, angles, fov)
	local view = {}
	if not CanMove and not ValidEntity(SpecEnt) then
		CanMove = true
	end
	view.vm_origin = Vector(0,0,-13000)
	if not CanMove and not IsPlayer then
		local ang1 = SpecEnt:EyeAngles()
		local ang
		if SpecEnt:IsPlayer() then
			ang = Angle(ang1.p - ang1.p - ang1.p, ang1.y, ang1.r) - SpecEntSaveAngle
		else
			ang = SpecEntSaveAngle
		end
		SpectatePosition = SpecEnt:GetPos() - (SaveAngles + ang ):Forward() * ThPDist
		SpecAng = (SpecEnt:GetPos() - SpectatePosition):Angle()
		view.angles = SpecAng
		view.origin = SpectatePosition
		view.vm_origin = SpectatePosition
	elseif not CanMove and IsPlayer then
		view.angles = SpecEnt:EyeAngles()
		if SpecEnt:IsPlayer() then
			view.origin = SpecEnt:GetShootPos()
		else
			view.origin = SpecEnt:GetPos()
		end
		view.vm_origin = LocalPlayer():GetShootPos()
		SpecEnt:SetNoDraw(true)
	elseif CanMove then
		view.angles = SpecAng
		view.origin = SpectatePosition
		view.vm_origin = SpectatePosition
	end
	return view
end

local function Screens()
	local dat = {}
	for k,v in pairs(camsdata) do
		local ang = LocalPlayer():EyeAngles()
		if not ValidEntity(v.obj) and v.obj == false then
			dat.origin = v.pos
			dat.angles = v.ang
			dat.y = 0
			dat.w = ScrW() / camsize:GetInt()
			dat.h = ScrH() / (0.75 * camsize:GetInt())
			if k <= camsize:GetInt() then
				dat.x = (k-1) * ScrW() / camsize:GetInt()
			elseif k > camsize:GetInt() and k <=2 * camsize:GetInt() then
				dat.y = ScrH() / (0.75 * camsize:GetInt())
				dat.x = (k - (camsize:GetInt() + 1)) * ScrW() / camsize:GetInt()
			elseif k > 2 * camsize:GetInt() then
				dat.y = 2 * (ScrH() / (0.75 * camsize:GetInt()))
				dat.x = (k - (2*camsize:GetInt()+1)) * ScrW() / camsize:GetInt()
			end
			render.RenderView( dat )
		elseif ValidEntity(v.obj) then
			dat.w = ScrW() / camsize:GetInt()
			dat.h = ScrH() / (0.75 * camsize:GetInt())
			dat.y = 0
			if k <= camsize:GetInt() then
				dat.x = (k-1) * ScrW() / camsize:GetInt()
			elseif k > camsize:GetInt() and k <=2 * camsize:GetInt() then
				dat.y = ScrH() / (0.75 * camsize:GetInt())
				dat.x = (k - (camsize:GetInt() + 1)) * ScrW() / camsize:GetInt()
			elseif k > 2 * camsize:GetInt() then
				dat.y = 2 * (ScrH() / (0.75 * camsize:GetInt()))
				dat.x = (k - (2*camsize:GetInt()+1)) * ScrW() / camsize:GetInt()
			end
			
			if v.obj:IsPlayer() then
				dat.origin = v.obj:GetShootPos()
				dat.angles = v.obj:EyeAngles()
				v.obj:SetNoDraw(true)
				render.RenderView( dat )
				v.obj:SetNoDraw(false)
			else
				local ang1 = v.obj:EyeAngles()
				local ang = Angle(ang1.p - ang1.p - ang1.p, ang1.y, ang1.r) - v.entang
				local pos = v.obj:GetPos() - (Angle(ang.p, ang.y, ang.r) + v.ang ):Forward() * v.dist
				dat.origin = pos
				dat.angles = (v.obj:GetPos() - pos):Angle()
				render.RenderView( dat )
			end
			
		elseif not ValidEntity(v.obj) and v.obj ~= false then
			local temp = {}
			camsdata[k] = nil
			for k,v in pairs(camsdata) do
				table.insert(temp, v)
			end
			camsdata = {}
			for k,v in pairs(temp) do
				table.insert(camsdata, v)
			end 
			dat[k] = nil
		end
	end
	if #camsdata > 0 then
		draw.RoundedBox(1, (ScrW() / 2) - 1.5, (ScrH() / 2) - 1.5, 3, 3, Color(255,255,255,255))
	end
	
	if IsSpectating then
		surface.SetFont("HUDNumber")
		surface.SetTextColor(255,255,255,255)
		if CanMove then
			surface.SetTextPos( (ScrW() / 2) - 0.5*surface.GetTextSize("Free spectating"), ScrH() - 80)
			surface.DrawText("Free spectating")
		elseif not CanMove and SpecEnt:IsPlayer() then
			surface.SetTextPos( (ScrW() / 2) - 0.5*surface.GetTextSize("Spectating " .. SpecEnt:Name()), ScrH() - 80)
			surface.DrawText("Spectating " .. SpecEnt:Name())
		elseif not CanMove and not SpecEnt:IsPlayer() then
			surface.SetTextPos( (ScrW() / 2) - 0.5*surface.GetTextSize("Spectating an entity"), ScrH() - 80)
			surface.DrawText("Spectating an entity")
		end
	end
end
hook.Add("HUDPaint", "FSpectatePermanentScreens", Screens)

local safeview = _R.CUserCmd.SetViewAngles
local function MouseStuff(u)
	if not CanMove and SpecEnt:IsValid() and SpecEnt:IsPlayer() and SpecEnt ~= LocalPlayer() then
		local trace = SpecEnt:GetEyeTrace().HitPos
		safeview(u, (trace - LocalPlayer():GetShootPos()):Angle())
	elseif not CanMove and SpecEnt:IsValid() and not SpecEnt:IsPlayer() and LockMouse:GetInt() ~= 1 then
		SaveAngles.p = SaveAngles.p + u:GetMouseY() * 0.025
		SaveAngles.y = SaveAngles.y - u:GetMouseX() * 0.025
		local trace = {}
		trace.start = SpectatePosition
		trace.endpos = SpectatePosition + SpecAng:Forward() * 100000 
		trace.filter = LocalPlayer()
		local traceline = util.TraceLine(trace)
		local pos = traceline.HitPos
		safeview(u, (pos - LocalPlayer():GetShootPos()):Angle())
	elseif CanMove then
		local trace = {}
		trace.start = SpectatePosition
		trace.endpos = SpectatePosition + SpecAng:Forward() * 100000 
		trace.filter = LocalPlayer()
		local traceline = util.TraceLine(trace)
		local pos = traceline.HitPos
		SpecAng.p = math.Clamp(SpecAng.p + u:GetMouseY() * 0.025, -90, 90)
		SpecAng.y = SpecAng.y + u:GetMouseX() * -0.025
		safeview(u, (pos - LocalPlayer():GetShootPos()):Angle())
	end
end

local function Toggle()
	if IsSpectating then
		IsSpectating = false
		CanMove = true
		if ValidEntity(SpecEnt) then
			SpecEnt:SetNoDraw(false)
			SpecEnt = LocalPlayer()
		end
		speed = 15
		holding = {}
		hook.Remove("CreateMove", "FSpectate")
		hook.Remove("CalcView", "FSpectate")
		hook.Remove("Think", "FSpectate")
		hook.Remove("PlayerBindPress", "FSpectate")
		hook.Remove("ShouldDrawLocalPlayer", "FSpectate")
		FESPRemoveEnt(1337)
	else
		IsSpectating = true
		SpectatePosition = LocalPlayer():GetShootPos()
		SpecAng = LocalPlayer():EyeAngles()
		-- HOOKS:
		hook.Add("CreateMove", "FSpectate", MouseStuff)
		hook.Add("CalcView", "FSpectate", CalcViews)
		hook.Add("Think", "FSpectate", Thinks)
		hook.Add("PlayerBindPress", "FSpectate", BindPresses)
		hook.Add("ShouldDrawLocalPlayer", "FSpectate", function() return true end)
		FESPAddEnt(LocalPlayer(), 1337)
	end
end
concommand.Add("falco_spectate", Toggle)