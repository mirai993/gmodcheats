local setmetatable = setmetatable
local pairs = pairs
local ipairs = ipairs
local istable = istable
local type = type

local debug_getmetatable = debug.getmetatable
local function table_Copy(t, lookup_table)
	if ( t == nil ) then return nil end
	local copy = {}
	setmetatable(copy, debug_getmetatable(t))
	for i, v in pairs(t) do
		if ( !istable( v ) ) then
			copy[ i ] = v
		else
			lookup_table = lookup_table or {}
			lookup_table[ t ] = copy
			if ( lookup_table[ v ] ) then
				copy[i] = lookup_table[v]
			else
				copy[i] = table_Copy(v, lookup_table)
			end
		end
	end
	return copy
end

local G = table_Copy(_G)
local detours, luadetours, msgs, menupanels, clickguipanels, hudpanels, windowpanels = {}, {}, {}, {}, {}, {}, {}
local menuBtnDown, menuOpen = false
local me

local OPTIONTYPE_BOOL = 1
local OPTIONTYPE_MODE = 2
local OPTIONTYPE_NUM  = 3
local OPTIONTYPE_STR  = 4

local modules = {
	["Chat"] = {
		IsShown = true,
		Modules = {
			["Announce"] = {
				tooltip = "Announce your actions to the server!",
				toggled = false,
				expanded = false,
				options = {
					["PhysgunPickup"] = {
						type = OPTIONTYPE_BOOL,
						tooltip = "Announce when you pick up a prop with your physgun.",
						value = true
					},
					["KillPlayer"] = {
						type = OPTIONTYPE_BOOL,
						tooltip = "Announce when you kill a player.",
						value = true
					}
				}
			},
			["Spam"] = {
				tooltip = "Spam the chat or ULX private chat.",
				toggled = false,
				expanded = false,
				options = {
					["ULXChat"] = {
						type = OPTIONTYPE_BOOL,
						tooltip = "If spammer should use ULX psay or not. Recommended on Libby's",
						value = true
					},
					["Mode"] = {
						type = OPTIONTYPE_MODE,
						tooltip = "The message type to spam.",
						value = 1,
						values = {"bbotgen", "advertise"}
					},
					["IgnoreFriends"] = {
						type = OPTIONTYPE_BOOL,
						tooltip = "Whether the ULX spammer should ignore friends or not.",
						value = true
					}
				}
			}
		}
	},
	["Combat"] = {
		IsShown = true,
		Modules = {}
	},
	["Miscellaneous"] = {
		IsShown = true,
		Modules = {
			["SUIRatingSpam"] = {
				tooltip = "Spam everyone's ratings on the SUI scoreboard.",
				toggled = false,
				expanded = false,
				options = {
					["Rating"] = {
						type = OPTIONTYPE_MODE,
						tooltip = "The rating of your choice.",
						value = 1,
						values = {"NIGGER", "gay", "naughty", "friendly", "smile", "love", "artistic", "gold_star", "builder", "informative", "lol", "curvey", "best_landvehicle", "best_airvehicle", "stunter", "god"}
					}
				}
			}
		}
	},
	["Movement"] = {
		IsShown = true,
		Modules = {
			["BunnyHop"] = {
				tooltip = "Automatically bunnyhop",
				toggled = false,
				expanded = false,
				options = {}
			},
			["AutoStrafe"] = {
				tooltip = "Automatically strafe",
				toggled = false,
				expanded = false,
				options = {
					["Mode"] = {
						type = OPTIONTYPE_MODE,
						tooltip = "The Autostrafe type.",
						value = 1,
						values = {"Directional", "Simple"}
					}
				}
			}
		}
	},
	["Player"] = {
		IsShown = true,
		Modules = {
			["AutoSC"] = {
				tooltip = "Farms social credits in Libby's.",
				toggled = false,
				expanded = false,
				options = {
					["HUDTimer"] = {
						type = OPTIONTYPE_BOOL,
						tooltip = "Show in HUD when the next SC vote is taking place.",
						value = false
					}
				}
			},
			["RapidFire"] = {
				tooltip = "Rapid fire for your tools! Supports camera",
				toggled = false,
				expanded = false,
				options = {}
			}
		}
	},
	["Render"] = {
		IsShown = true,
		Modules = {
			["ESP"] = {
				tooltip = "Draw players through walls!",
				toggled = false,
				expanded = false,
				options = {
					["2D Boxes"] = {
						type = OPTIONTYPE_BOOL,
						tooltip = "Whether to draw 2D boxes or not.",
						value = true
					},
					["Names"] = {
						type = OPTIONTYPE_BOOL,
						tooltip = "Whether to draw player names or not.",
						value = true
					},
					["Weapon"] = {
						type = OPTIONTYPE_BOOL,
						tooltip = "Whether to draw the current weapon or not.",
						value = false
					},
					["Rank"] = {
						type = OPTIONTYPE_BOOL,
						tooltip = "Whether to draw the player's rank or not.",
						value = false
					},
					["Health"] = {
						type = OPTIONTYPE_MODE,
						tooltip = "Whether to draw player health or not.",
						value = 1,
						values = {"None", "Number", "Bar", "Both"}
					}
				}
			},
			["LandingTrajectory"] = {
				tooltip = "Draws where you're going to land.",
				toggled = false,
				expanded = false,
				options = {}
			}
		}
	},
	["World"] = {
		IsShown = true,
		Modules = {}
	},
	["Client"] = {
		IsShown = true,
		Modules = {}
	}
}
local guicategories = {
	{"ClickGUI", ""},
	{"Hud Editor", ""},
	{"Windows", ""}
}
local currentguicategory = 1

local function getRainbowCol(index, saturation, speed)
	index = index or 0
	saturation = saturation or 0.5
	speed = speed or 50
	return G.HSVToColor((G.SysTime() * speed + index) % 360, saturation, 1)
end

local mocha_rosewater = {r = 245, g = 224, b = 220, a = 255}
local mocha_flamingo = {r = 242, g = 205, b = 205, a = 255}
local mocha_pink = {r = 245, g = 194, b = 231, a = 255}
local mocha_mauve = {r = 203, g = 166, b = 247, a = 255}
local mocha_red = {r = 243, g = 139, b = 168, a = 255}
local mocha_maroon = {r = 235, g = 160, b = 172, a = 255}
local mocha_peach = {r = 250, g = 179, b = 135, a = 255}
local mocha_yellow = {r = 249, g = 226, b = 175, a = 255}
local mocha_green = {r = 166, g = 227, b = 161, a = 255}
local mocha_teal = {r = 148, g = 226, b = 213, a = 255}
local mocha_sky = {r = 137, g = 220, b = 235, a = 255}
local mocha_sapphire = {r = 116, g = 199, b = 236, a = 255}
local mocha_blue = {r = 137, g = 180, b = 250, a = 255}
local mocha_lavender = {r = 180, g = 190, b = 254, a = 255}
local mocha_text = {r = 205, g = 214, b = 244, a = 255}
local mocha_subtext1 = {r = 186, g = 194, b = 222, a = 255}
local mocha_subtext0 = {r = 166, g = 173, b = 200, a = 255}
local mocha_overlay2 = {r = 147, g = 153, b = 178, a = 255}
local mocha_overlay1 = {r = 127, g = 132, b = 156, a = 255}
local mocha_overlay0 = {r = 108, g = 112, b = 134, a = 255}
local mocha_surface2 = {r = 88, g = 91, b = 112, a = 255}
local mocha_surface1 = {r = 69, g = 71, b = 90, a = 255}
local mocha_surface0 = {r = 49, g = 50, b = 68, a = 255}
local mocha_base = {r = 30, g = 30, b = 46, a = 255}
local mocha_mantle = {r = 24, g = 24, b = 37, a = 255}
local mocha_crust = {r = 17, g = 17, b = 27, a = 255}

local color_white = {r = 255, g = 255, b = 255, a = 255}
local color_black = {r = 0, g = 0, b = 0, a = 255}

G.surface.CreateFont("fontawesomeregular36sillyhack", {
	font = "Font Awesome 6 Free Regular",
	extended = true,
	size = 36
})

G.surface.CreateFont("fontawesomesolid36sillyhack", {
	font = "Font Awesome 6 Free Solid",
	extended = true,
	size = 36
})

G.surface.CreateFont("jetbrainsmono10sillyhack", {
	font = "JetBrains Mono",
	size = 10
})

G.surface.CreateFont("jetbrainsmono14sillyhack", {
	font = "JetBrains Mono",
	size = 14
})

G.surface.CreateFont("fontawesomesolid16sillyhack", {
	font = "Font Awesome 6 Free Solid",
	extended = true,
	size = 16
})

local function doMsg(data)
    for i, v in ipairs(data) do
        table.insert(msgs, v)
    end
end

local function Msg(...)
    local data = {...}
    if type(data[1]) == "table" then
        G.table.insert(data, 1, data[1])
    else
        G.table.insert(data, 1, mocha_text)
    end
    G.table.insert(data, 2, G.os.date("%X") .. " - ")
	G.table.insert(data, "\n")
    doMsg(data)
    G.MsgC(unpack(data))
end

local function round(num, idp)
	local mult = 10 ^ (idp or 0)
	return G.math.floor(num * mult + 0.5) / mult
end

local function getFileFromFilename(path)
	for i = #path, 1, -1 do
		local c = string.sub(path, i, i)
		if ( c == "/" or c == "\\" ) then return string.sub( path, i + 1 ) end
	end

	return path
end

local function drawRoundedBox(cornerRadius, x, y, w, h, color, roundTopLeft, roundTopRight, roundBottomLeft, roundBottomRight)
	G.surface.SetDrawColor(color.r, color.g, color.b, color.a)

	if cornerRadius <= 0 then
		surface.DrawRect(x, y, width, height)
		return
	end

	x = round(x)
	y = round(y)
	w = round(w)
	h = round(h)
	cornerRadius = G.math.min(round(cornerRadius), G.math.floor(w / 2), G.math.floor(h / 2))

	G.surface.DrawRect(x + cornerRadius, y, w - cornerRadius * 2, h)
	G.surface.DrawRect(x, y + cornerRadius, cornerRadius, h - cornerRadius * 2)
	G.surface.DrawRect(x + w - cornerRadius, y + cornerRadius, cornerRadius, h - cornerRadius * 2)

	local texture = surface.GetTextureID("gui/corner8")
	if cornerRadius > 64 then texture = surface.GetTextureID("gui/corner512") end
	if cornerRadius > 32 then texture = surface.GetTextureID("gui/corner64") end
	if cornerRadius > 16 then texture = surface.GetTextureID("gui/corner32") end
	if cornerRadius > 8 then texture = surface.GetTextureID("gui/corner16") end

	G.surface.SetTexture(texture)

	if roundTopLeft then
		G.surface.DrawTexturedRectUV(x, y, cornerRadius, cornerRadius, 0, 0, 1, 1)
	else
		G.surface.DrawRect(x, y, cornerRadius, cornerRadius)
	end

	if roundTopRight then
		G.surface.DrawTexturedRectUV(x + w - cornerRadius, y, cornerRadius, cornerRadius, 1, 0, 0, 1)
	else
		G.surface.DrawRect(x + w - cornerRadius, y, cornerRadius, cornerRadius)
	end

	if roundBottomLeft then
		G.surface.DrawTexturedRectUV(x, y + h - cornerRadius, cornerRadius, cornerRadius, 0, 1, 1, 0)
	else
		G.surface.DrawRect(x, y + h - cornerRadius, cornerRadius, cornerRadius)
	end

	if roundBottomRight then
		G.surface.DrawTexturedRectUV(x + w - cornerRadius, y + h - cornerRadius, cornerRadius, cornerRadius, 1, 1, 0, 0)
	else
		G.surface.DrawRect(x + w - cornerRadius, y + h - cornerRadius, cornerRadius, cornerRadius)
	end
end

local TEXT_ALIGN_LEFT = 0
local TEXT_ALIGN_CENTER = 1
local TEXT_ALIGN_RIGHT = 2
local TEXT_ALIGN_TOP = 3
local TEXT_ALIGN_BOTTOM	= 4

local function drawSimpleText(text, font, x, y, color, xAlign, yAlign)
	text = G.tostring(text)
	font = font or "DermaDefault"
	x = x or 0
	y = y or 0
	xAlign = xAlign or TEXT_ALIGN_LEFT
	yAlign = yAlign or TEXT_ALIGN_TOP

	G.surface.SetFont(font)
	local w, h = G.surface.GetTextSize(text)

	if xAlign == TEXT_ALIGN_CENTER then
		x = x - w / 2
	elseif xAlign == TEXT_ALIGN_RIGHT then
		x = x - w
	end

	if yAlign == TEXT_ALIGN_CENTER then
		y = y - h / 2
	elseif yAlign == TEXT_ALIGN_BOTTOM then
		y = y - h
	end

	G.surface.SetTextPos(G.math.ceil(x), G.math.ceil(y))

	if color ~= nil then
		G.surface.SetTextColor(color.r, color.g, color.b, color.a)
	else
		G.surface.SetTextColor(255, 255, 255, 255)
	end

	G.surface.DrawText(text)

	return w, h
end

local function drawSimpleTextOutlined(text, font, x, y, color, xAlign, yAlign, outlineWidth, outlineColor)
	local steps = outlineWidth * 2 / 3
	if steps < 1 then steps = 1 end

	for _x = -outlineWidth, outlineWidth, steps do
		for _y = -outlineWidth, outlineWidth, steps do
			drawSimpleText(text, font, x + _x, y + _y, outlineColor, xAlign, yAlign)
		end
	end

	drawSimpleText(text, font, x, y, color, xAlign, yAlign)
end

local function drawFilledCircle(x, y, radius)
	local vertices = {}

	G.table.insert(vertices, {x = x, y = y, u = 0.5, v = 0.5})
	for i = 0, 360 do
		local a = G.math.rad((i / 360) * -360)
		G.table.insert(vertices, {
			x = x + G.math.sin(a) * radius,
			y = y + G.math.cos(a) * radius,
			u = G.math.sin(a) / 2 + 0.5,
			v = G.math.cos(a) / 2 + 0.5
		})
	end

	local a = G.math.rad(0)
	G.table.insert(vertices, {
		x = x + G.math.sin(a) * radius,
		y = y + G.math.cos(a) * radius,
		u = G.math.sin(a) / 2 + 0.5,
		v = G.math.cos(a) / 2 + 0.5
	})

	G.surface.DrawPoly(vertices)
end

local convarCache = {}
local function getConVar(name)
	local c = convarCache[name]
	if not c then
		c = G.GetConVar_Internal(name)
		if not c then return end
		convarCache[name] = c
	end
	return c
end

local gravity
local function getLandingPos()
	local localplayer = me
	if not localplayer then return end
	if localplayer:IsOnGround() then return end

	local gravity = getConVar("sv_gravity"):GetFloat()
	local pos = localplayer:GetPos()
	local speed = localplayer:GetVelocity()
	local horizontalSpeed = G.Vector(speed.x, speed.y, 0)

	local time = speed.z / gravity
	local vertDist = 0.5 * gravity * time * time
	local startPos = pos + G.Vector(0, 0, vertDist) + horizontalSpeed * time

	speed.z = G.math.min(-300, -G.math.abs(speed.z))

	local trace = {
		start = pos,
		endpos = pos + speed * 1e8,
		filter = localplayer
	}

	local tr = util.TraceLine(trace)

	local landingPos = startPos
	local t = -time
	while landingPos.z > tr.HitPos.z and t < 10 do
		local vert = 0.5 * gravity * t * t
		landingPos = startPos + horizontalSpeed * t - G.Vector(0, 0, vert)
		t = t + 0.01
	end

	local endTrace = util.QuickTrace(pos, (landingPos - pos) * 2, localplayer)

	return endTrace.HitPos, endTrace, startPos
end

local function createDetour(original, name, detour)
    Msg(mocha_mauve, "[DETOURS] ", mocha_green, "Creating detour ", name)
    detours[detour] = original
    return detour
end

local zxc
local frozen2
local function getzxc()
	if zxc then return zxc end
	Msg(mocha_red, "[MODULE] ", mocha_maroon, "Loading zxcmodule...")
	G.require("zxcmodule")
	if _G.ded ~= nil then
		zxc = table_Copy(_G.ded)
		_G.ded = nil
		Msg(mocha_red, "[MODULE] ", mocha_maroon, "Successfully loaded and localized zxcmodule.")
		return zxc
	end
end

local function stringSplit(separator, str)
	local returnval = {}
	local currentPos = 1

	for i = 1, G.string.len(str) do
		local startPos, endPos = G.string.find(str, separator, currentPos, true)
		if not startPos then break end
		returnval[i] = G.string.sub(str, currentPos, startPos - 1)
		currentPos = endPos + 1
	end

	returnval[#returnval - 1] = G.string.sub(str, currentPos)
	return returnval
end

local function startsWith(str, start)
	return G.string.sub(str, 1, G.string.len(start)) == start
end

local function IsValid(object)
	if not object then return false end

	local isvalid = object.IsValid
	if not isvalid then return false end

	return isvalid(object)
end

local md5 = {}

md5.Const = {
	0xd76aa478, 0xe8c7b756, 0x242070db, 0xc1bdceee,
	0xf57c0faf, 0x4787c62a, 0xa8304613, 0xfd469501,
	0x698098d8, 0x8b44f7af, 0xffff5bb1, 0x895cd7be,
	0x6b901122, 0xfd987193, 0xa679438e, 0x49b40821,
	0xf61e2562, 0xc040b340, 0x265e5a51, 0xe9b6c7aa,
	0xd62f105d, 0x02441453, 0xd8a1e681, 0xe7d3fbc8,
	0x21e1cde6, 0xc33707d6, 0xf4d50d87, 0x455a14ed,
	0xa9e3e905, 0xfcefa3f8, 0x676f02d9, 0x8d2a4c8a,
	0xfffa3942, 0x8771f681, 0x6d9d6122, 0xfde5380c,
	0xa4beea44, 0x4bdecfa9, 0xf6bb4b60, 0xbebfbc70,
	0x289b7ec6, 0xeaa127fa, 0xd4ef3085, 0x04881d05,
	0xd9d4d039, 0xe6db99e5, 0x1fa27cf8, 0xc4ac5665,
	0xf4292244, 0x432aff97, 0xab9423a7, 0xfc93a039,
	0x655b59c3, 0x8f0ccc92, 0xffeff47d, 0x85845dd1,
	0x6fa87e4f, 0xfe2ce6e0, 0xa3014314, 0x4e0811a1,
	0xf7537e82, 0xbd3af235, 0x2ad7d2bb, 0xeb86d391,
	0x67452301, 0xefcdab89, 0x98badcfe, 0x10325476
}

local f = function(x, y, z)
	return G.bit.bor(G.bit.band(x, y), G.bit.band(-x - 1, z))
end

local g = function(x, y, z)
	return G.bit.bor(G.bit.band(x, z), G.bit.band(y, -z - 1))
end

local h = function(x, y, z)
	return G.bit.bxor(x, G.bit.bxor(y, z))
end

local i = function(x, y, z)
	return G.bit.bxor(y, G.bit.bor(x, -z - 1))
end

local z = function(f, a, b, c, d, x, s, ac)
	a = G.bit.band(a + f(b, c, d) + x + ac, 0xffffffff)
	return G.bit.bor(G.bit.lshift(G.bit.band(a, G.bit.rshift(0xffffffff, s)), s), G.bit.rshift(a, 32 - s)) + b
end

local MAX = 2 ^ 31
local SUB = 2 ^ 32

function Fix(a)
	if a > MAX then
		return a - SUB
	end

	return a
end

function Transform(A, B, C, D, X)
	local a, b, c, d = A, B, C, D

	a=z(f,a,b,c,d,X[ 0], 7,md5.Const[ 1]) -- I'm not even gonna try with this cluster fuck
	a=Fix(a) b=Fix(b) c=Fix(c) d=Fix(d)
	d=z(f,d,a,b,c,X[ 1],12,md5.Const[ 2])
	a=Fix(a) b=Fix(b) c=Fix(c) d=Fix(d)
	c=z(f,c,d,a,b,X[ 2],17,md5.Const[ 3])
	a=Fix(a) b=Fix(b) c=Fix(c) d=Fix(d)
	b=z(f,b,c,d,a,X[ 3],22,md5.Const[ 4])
	a=Fix(a) b=Fix(b) c=Fix(c) d=Fix(d)
	a=z(f,a,b,c,d,X[ 4], 7,md5.Const[ 5])
	a=Fix(a) b=Fix(b) c=Fix(c) d=Fix(d)
	d=z(f,d,a,b,c,X[ 5],12,md5.Const[ 6])
	a=Fix(a) b=Fix(b) c=Fix(c) d=Fix(d)
	c=z(f,c,d,a,b,X[ 6],17,md5.Const[ 7])
	a=Fix(a) b=Fix(b) c=Fix(c) d=Fix(d)
	b=z(f,b,c,d,a,X[ 7],22,md5.Const[ 8])
	a=Fix(a) b=Fix(b) c=Fix(c) d=Fix(d)
	a=z(f,a,b,c,d,X[ 8], 7,md5.Const[ 9])
	a=Fix(a) b=Fix(b) c=Fix(c) d=Fix(d)
	d=z(f,d,a,b,c,X[ 9],12,md5.Const[10])
	a=Fix(a) b=Fix(b) c=Fix(c) d=Fix(d)
	c=z(f,c,d,a,b,X[10],17,md5.Const[11])
	a=Fix(a) b=Fix(b) c=Fix(c) d=Fix(d)
	b=z(f,b,c,d,a,X[11],22,md5.Const[12])
	a=Fix(a) b=Fix(b) c=Fix(c) d=Fix(d)
	a=z(f,a,b,c,d,X[12], 7,md5.Const[13])
	a=Fix(a) b=Fix(b) c=Fix(c) d=Fix(d)
	d=z(f,d,a,b,c,X[13],12,md5.Const[14])
	a=Fix(a) b=Fix(b) c=Fix(c) d=Fix(d)
	c=z(f,c,d,a,b,X[14],17,md5.Const[15])
	a=Fix(a) b=Fix(b) c=Fix(c) d=Fix(d)
	b=z(f,b,c,d,a,X[15],22,md5.Const[16])
	a=Fix(a) b=Fix(b) c=Fix(c) d=Fix(d)

	a=z(g,a,b,c,d,X[ 1], 5,md5.Const[17])
	a=Fix(a) b=Fix(b) c=Fix(c) d=Fix(d)
	d=z(g,d,a,b,c,X[ 6], 9,md5.Const[18])
	a=Fix(a) b=Fix(b) c=Fix(c) d=Fix(d)
	c=z(g,c,d,a,b,X[11],14,md5.Const[19])
	a=Fix(a) b=Fix(b) c=Fix(c) d=Fix(d)
	b=z(g,b,c,d,a,X[ 0],20,md5.Const[20])
	a=Fix(a) b=Fix(b) c=Fix(c) d=Fix(d)
	a=z(g,a,b,c,d,X[ 5], 5,md5.Const[21])
	a=Fix(a) b=Fix(b) c=Fix(c) d=Fix(d)
	d=z(g,d,a,b,c,X[10], 9,md5.Const[22])
	a=Fix(a) b=Fix(b) c=Fix(c) d=Fix(d)
	c=z(g,c,d,a,b,X[15],14,md5.Const[23])
	a=Fix(a) b=Fix(b) c=Fix(c) d=Fix(d)
	b=z(g,b,c,d,a,X[ 4],20,md5.Const[24])
	a=Fix(a) b=Fix(b) c=Fix(c) d=Fix(d)
	a=z(g,a,b,c,d,X[ 9], 5,md5.Const[25])
	a=Fix(a) b=Fix(b) c=Fix(c) d=Fix(d)
	d=z(g,d,a,b,c,X[14], 9,md5.Const[26])
	a=Fix(a) b=Fix(b) c=Fix(c) d=Fix(d)
	c=z(g,c,d,a,b,X[ 3],14,md5.Const[27])
	a=Fix(a) b=Fix(b) c=Fix(c) d=Fix(d)
	b=z(g,b,c,d,a,X[ 8],20,md5.Const[28])
	a=Fix(a) b=Fix(b) c=Fix(c) d=Fix(d)
	a=z(g,a,b,c,d,X[13], 5,md5.Const[29])
	a=Fix(a) b=Fix(b) c=Fix(c) d=Fix(d)
	d=z(g,d,a,b,c,X[ 2], 9,md5.Const[30])
	a=Fix(a) b=Fix(b) c=Fix(c) d=Fix(d)
	c=z(g,c,d,a,b,X[ 7],14,md5.Const[31])
	a=Fix(a) b=Fix(b) c=Fix(c) d=Fix(d)
	b=z(g,b,c,d,a,X[12],20,md5.Const[32])
	a=Fix(a) b=Fix(b) c=Fix(c) d=Fix(d)

	a=z(h,a,b,c,d,X[ 5], 4,md5.Const[33])
	a=Fix(a) b=Fix(b) c=Fix(c) d=Fix(d)
	d=z(h,d,a,b,c,X[ 8],11,md5.Const[34])
	a=Fix(a) b=Fix(b) c=Fix(c) d=Fix(d)
	c=z(h,c,d,a,b,X[11],16,md5.Const[35])
	a=Fix(a) b=Fix(b) c=Fix(c) d=Fix(d)
	b=z(h,b,c,d,a,X[14],23,md5.Const[36])
	a=Fix(a) b=Fix(b) c=Fix(c) d=Fix(d)
	a=z(h,a,b,c,d,X[ 1], 4,md5.Const[37])
	a=Fix(a) b=Fix(b) c=Fix(c) d=Fix(d)
	d=z(h,d,a,b,c,X[ 4],11,md5.Const[38])
	a=Fix(a) b=Fix(b) c=Fix(c) d=Fix(d)
	c=z(h,c,d,a,b,X[ 7],16,md5.Const[39])
	a=Fix(a) b=Fix(b) c=Fix(c) d=Fix(d)
	b=z(h,b,c,d,a,X[10],23,md5.Const[40])
	a=Fix(a) b=Fix(b) c=Fix(c) d=Fix(d)
	a=z(h,a,b,c,d,X[13], 4,md5.Const[41])
	a=Fix(a) b=Fix(b) c=Fix(c) d=Fix(d)
	d=z(h,d,a,b,c,X[ 0],11,md5.Const[42])
	a=Fix(a) b=Fix(b) c=Fix(c) d=Fix(d)
	c=z(h,c,d,a,b,X[ 3],16,md5.Const[43])
	a=Fix(a) b=Fix(b) c=Fix(c) d=Fix(d)
	b=z(h,b,c,d,a,X[ 6],23,md5.Const[44])
	a=Fix(a) b=Fix(b) c=Fix(c) d=Fix(d)
	a=z(h,a,b,c,d,X[ 9], 4,md5.Const[45])
	a=Fix(a) b=Fix(b) c=Fix(c) d=Fix(d)
	d=z(h,d,a,b,c,X[12],11,md5.Const[46])
	a=Fix(a) b=Fix(b) c=Fix(c) d=Fix(d)
	c=z(h,c,d,a,b,X[15],16,md5.Const[47])
	a=Fix(a) b=Fix(b) c=Fix(c) d=Fix(d)
	b=z(h,b,c,d,a,X[ 2],23,md5.Const[48])
	a=Fix(a) b=Fix(b) c=Fix(c) d=Fix(d)

	a=z(i,a,b,c,d,X[ 0], 6,md5.Const[49])
	a=Fix(a) b=Fix(b) c=Fix(c) d=Fix(d)
	d=z(i,d,a,b,c,X[ 7],10,md5.Const[50])
	a=Fix(a) b=Fix(b) c=Fix(c) d=Fix(d)
	c=z(i,c,d,a,b,X[14],15,md5.Const[51])
	a=Fix(a) b=Fix(b) c=Fix(c) d=Fix(d)
	b=z(i,b,c,d,a,X[ 5],21,md5.Const[52])
	a=Fix(a) b=Fix(b) c=Fix(c) d=Fix(d)
	a=z(i,a,b,c,d,X[12], 6,md5.Const[53])
	a=Fix(a) b=Fix(b) c=Fix(c) d=Fix(d)
	d=z(i,d,a,b,c,X[ 3],10,md5.Const[54])
	a=Fix(a) b=Fix(b) c=Fix(c) d=Fix(d)
	c=z(i,c,d,a,b,X[10],15,md5.Const[55])
	a=Fix(a) b=Fix(b) c=Fix(c) d=Fix(d)
	b=z(i,b,c,d,a,X[ 1],21,md5.Const[56])
	a=Fix(a) b=Fix(b) c=Fix(c) d=Fix(d)
	a=z(i,a,b,c,d,X[ 8], 6,md5.Const[57])
	a=Fix(a) b=Fix(b) c=Fix(c) d=Fix(d)
	d=z(i,d,a,b,c,X[15],10,md5.Const[58])
	a=Fix(a) b=Fix(b) c=Fix(c) d=Fix(d)
	c=z(i,c,d,a,b,X[ 6],15,md5.Const[59])
	a=Fix(a) b=Fix(b) c=Fix(c) d=Fix(d)
	b=z(i,b,c,d,a,X[13],21,md5.Const[60])
	a=Fix(a) b=Fix(b) c=Fix(c) d=Fix(d)
	a=z(i,a,b,c,d,X[ 4], 6,md5.Const[61])
	a=Fix(a) b=Fix(b) c=Fix(c) d=Fix(d)
	d=z(i,d,a,b,c,X[11],10,md5.Const[62])
	a=Fix(a) b=Fix(b) c=Fix(c) d=Fix(d)
	c=z(i,c,d,a,b,X[ 2],15,md5.Const[63])
	a=Fix(a) b=Fix(b) c=Fix(c) d=Fix(d)
	b=z(i,b,c,d,a,X[ 9],21,md5.Const[64])
	a=Fix(a) b=Fix(b) c=Fix(c) d=Fix(d)

	return A + a, B + b, C + c, D + d
end

function md5.PseudoRandom(number)
    local a, b, c, d = Fix(md5.Const[65]), Fix(md5.Const[66]), Fix(md5.Const[67]), Fix(md5.Const[68])

    local m = {}

    for i= 0, 15 do
		m[i] = 0
	end

    m[0] = number
    m[1] = 128
    m[14] = 32

    local a,b,c,d = Transform(a,b,c,d,m)

    return G.bit.rshift( Fix(b) , 16) % 256
end

md5.EngineSpread = {
    [0] = {-0.492036, 0.286111},
    [1] = {-0.492036, 0.286111},
    [2] = {-0.255320, 0.128480},
    [3] = {0.456165, 0.356030},
    [4] = {-0.361731, 0.406344},
    [5] = {-0.146730, 0.834589},
    [6] = {-0.253288, -0.421936},
    [7] = {-0.448694, 0.111650},
    [8] = {-0.880700, 0.904610},
    [9] = {-0.379932, 0.138833},
    [10] = {0.502579, -0.494285},
    [11] = {-0.263847, -0.594805},
    [12] = {0.818612, 0.090368},
    [13] = {-0.063552, 0.044356},
    [14] = {0.490455, 0.304820},
    [15] = {-0.192024, 0.195162},
    [16] = {-0.139421, 0.857106},
    [17] = {0.715745, 0.336956},
    [18] = {-0.150103, -0.044842},
    [19] = {-0.176531, 0.275787},
    [20] = {0.155707, -0.152178},
    [21] = {-0.136486, -0.591896},
    [22] = {-0.021022, -0.761979},
    [23] = {-0.166004, -0.733964},
    [24] = {-0.102439, -0.132059},
    [25] = {-0.607531, -0.249979},
    [26] = {-0.500855, -0.185902},
    [27] = {-0.080884, 0.516556},
    [28] = {-0.003334, 0.138612},
    [29] = {-0.546388, -0.000115},
    [30] = {-0.228092, -0.018492},
    [31] = {0.542539, 0.543196},
    [32] = {-0.355162, 0.197473},
    [33] = {-0.041726, -0.015735},
    [34] = {-0.713230, -0.551701},
    [35] = {-0.045056, 0.090208},
    [36] = {0.061028, 0.417744},
    [37] = {-0.171149, -0.048811},
    [38] = {0.241499, 0.164562},
    [39] = {-0.129817, -0.111200},
    [40] = {0.007366, 0.091429},
    [41] = {-0.079268, -0.008285},
    [42] = {0.010982, -0.074707},
    [43] = {-0.517782, -0.682470},
    [44] = {-0.663822, -0.024972},
    [45] = {0.058213, -0.078307},
    [46] = {-0.302041, -0.132280},
    [47] = {0.217689, -0.209309},
    [48] = {-0.143615, 0.830349},
    [49] = {0.270912, 0.071245},
    [50] = {-0.258170, -0.598358},
    [51] = {0.099164, -0.257525},
    [52] = {-0.214676, -0.595918},
    [53] = {-0.427053, -0.523764},
    [54] = {-0.585472, 0.088522},
    [55] = {0.564305, -0.533822},
    [56] = {-0.387545, -0.422206},
    [57] = {0.690505, -0.299197},
    [58] = {0.475553, 0.169785},
    [59] = {0.347436, 0.575364},
    [60] = {-0.069555, -0.103340},
    [61] = {0.286197, -0.618916},
    [62] = {-0.505259, 0.106581},
    [63] = {-0.420214, -0.714843},
    [64] = {0.032596, -0.401891},
    [65] = {-0.238702, -0.087387},
    [66] = {0.714358, 0.197811},
    [67] = {0.208960, 0.319015},
    [68] = {-0.361140, 0.222130},
    [69] = {-0.133284, -0.492274},
    [70] = {0.022824, -0.133955},
    [71] = {-0.100850, 0.271962},
    [72] = {-0.050582, -0.319538},
    [73] = {0.577980, 0.095507},
    [74] = {0.224871, 0.242213},
    [75] = {-0.628274, 0.097248},
    [76] = {0.184266, 0.091959},
    [77] = {-0.036716, 0.474259},
    [78] = {-0.502566, -0.279520},
    [79] = {-0.073201, -0.036658},
    [80] = {0.339952, -0.293667},
    [81] = {0.042811, 0.130387},
    [82] = {0.125881, 0.007040},
    [83] = {0.138374, -0.418355},
    [84] = {0.261396, -0.392697},
    [85] = {-0.453318, -0.039618},
    [86] = {0.890159, -0.335165},
    [87] = {0.466437, -0.207762},
    [88] = {0.593253, 0.418018},
    [89] = {0.566934, -0.643837},
    [90] = {0.150918, 0.639588},
    [91] = {0.150112, 0.215963},
    [92] = {-0.130520, 0.324801},
    [93] = {-0.369819, -0.019127},
    [94] = {-0.038889, -0.650789},
    [95] = {0.490519, -0.065375},
    [96] = {-0.305940, 0.454759},
    [97] = {-0.521967, -0.550004},
    [98] = {-0.040366, 0.683259},
    [99] = {0.137676, -0.376445},
    [100] = {0.839301, 0.085979},
    [101] = {-0.319140, 0.481838},
    [102] = {0.201437, -0.033135},
    [103] = {0.384637, -0.036685},
    [104] = {0.598419, 0.144371},
    [105] = {-0.061424, -0.608645},
    [106] = {-0.065337, 0.308992},
    [107] = {-0.029356, -0.634337},
    [108] = {0.326532, 0.047639},
    [109] = {0.505681, -0.067187},
    [110] = {0.691612, 0.629364},
    [111] = {-0.038588, -0.635947},
    [112] = {0.637837, -0.011815},
    [113] = {0.765338, 0.563945},
    [114] = {0.213416, 0.068664},
    [115] = {-0.576581, 0.554824},
    [116] = {0.246580, 0.132726},
    [117] = {0.385548, -0.070054},
    [118] = {0.538735, -0.291010},
    [119] = {0.609944, 0.590973},
    [120] = {-0.463240, 0.010302},
    [121] = {-0.047718, 0.741086},
    [122] = {0.308590, -0.322179},
    [123] = {-0.291173, 0.256367},
    [124] = {0.287413, -0.510402},
    [125] = {0.864716, 0.158126},
    [126] = {0.572344, 0.561319},
    [127] = {-0.090544, 0.332633},
    [128] = {0.644714, 0.196736},
    [129] = {-0.204198, 0.603049},
    [130] = {-0.504277, -0.641931},
    [131] = {0.218554, 0.343778},
    [132] = {0.466971, 0.217517},
    [133] = {-0.400880, -0.299746},
    [134] = {-0.582451, 0.591832},
    [135] = {0.421843, 0.118453},
    [136] = {-0.215617, -0.037630},
    [137] = {0.341048, -0.283902},
    [138] = {-0.246495, -0.138214},
    [139] = {0.214287, -0.196102},
    [140] = {0.809797, -0.498168},
    [141] = {-0.115958, -0.260677},
    [142] = {-0.025448, 0.043173},
    [143] = {-0.416803, -0.180813},
    [144] = {-0.782066, 0.335273},
    [145] = {0.192178, -0.151171},
    [146] = {0.109733, 0.165085},
    [147] = {-0.617935, -0.274392},
    [148] = {0.283301, 0.171837},
    [149] = {-0.150202, 0.048709},
    [150] = {-0.179954, -0.288559},
    [151] = {-0.288267, -0.134894},
    [152] = {-0.049203, 0.231717},
    [153] = {-0.065761, 0.495457},
    [154] = {0.082018, -0.457869},
    [155] = {-0.159553, 0.032173},
    [156] = {0.508305, -0.090690},
    [157] = {0.232269, -0.338245},
    [158] = {-0.374490, -0.480945},
    [159] = {-0.541244, 0.194144},
    [160] = {-0.040063, -0.073532},
    [161] = {0.136516, -0.167617},
    [162] = {-0.237350, 0.456912},
    [163] = {-0.446604, -0.494381},
    [164] = {0.078626, -0.020068},
    [165] = {0.163208, 0.600330},
    [166] = {-0.886186, -0.345326},
    [167] = {-0.732948, -0.689349},
    [168] = {0.460564, -0.719006},
    [169] = {-0.033688, -0.333340},
    [170] = {-0.325414, -0.111704},
    [171] = {0.010928, 0.723791},
    [172] = {0.713581, -0.077733},
    [173] = {-0.050912, -0.444684},
    [174] = {-0.268509, 0.381144},
    [175] = {-0.175387, 0.147070},
    [176] = {-0.429779, 0.144737},
    [177] = {-0.054564, 0.821354},
    [178] = {0.003205, 0.178130},
    [179] = {-0.552814, 0.199046},
    [180] = {0.225919, -0.195013},
    [181] = {0.056040, -0.393974},
    [182] = {-0.505988, 0.075184},
    [183] = {-0.510223, 0.156271},
    [184] = {-0.209616, 0.111174},
    [185] = {-0.605132, -0.117104},
    [186] = {0.412433, -0.035510},
    [187] = {-0.573947, -0.691295},
    [188] = {-0.712686, 0.021719},
    [189] = {-0.643297, 0.145307},
    [190] = {0.245038, 0.343062},
    [191] = {-0.235623, -0.159307},
    [192] = {-0.834004, 0.088725},
    [193] = {0.121377, 0.671713},
    [194] = {0.528614, 0.607035},
    [195] = {-0.285699, -0.111312},
    [196] = {0.603385, 0.401094},
    [197] = {0.632098, -0.439659},
    [198] = {0.681016, -0.242436},
    [199] = {-0.261709, 0.304265},
    [200] = {-0.653737, -0.199245},
    [201] = {-0.435512, -0.762978},
    [202] = {0.701105, 0.389527},
    [203] = {0.093495, -0.148484},
    [204] = {0.715218, 0.638291},
    [205] = {-0.055431, -0.085173},
    [206] = {-0.727438, 0.889783},
    [207] = {-0.007230, -0.519183},
    [208] = {-0.359615, 0.058657},
    [209] = {0.294681, 0.601155},
    [210] = {0.226879, -0.255430},
    [211] = {-0.307847, -0.617373},
    [212] = {0.340916, -0.780086},
    [213] = {-0.028277, 0.610455},
    [214] = {-0.365067, 0.323311},
    [215] = {0.001059, -0.270451},
    [216] = {0.304025, 0.047478},
    [217] = {0.297389, 0.383859},
    [218] = {0.288059, 0.262816},
    [219] = {-0.889315, 0.533731},
    [220] = {0.215887, 0.678889},
    [221] = {0.287135, 0.343899},
    [222] = {0.423951, 0.672285},
    [223] = {0.411912, -0.812886},
    [224] = {0.081615, -0.497358},
    [225] = {-0.051963, -0.117891},
    [226] = {-0.062387, 0.331698},
    [227] = {0.020458, -0.734125},
    [228] = {-0.160176, 0.196321},
    [229] = {0.044898, -0.024032},
    [230] = {-0.153162, 0.930951},
    [231] = {-0.015084, 0.233476},
    [232] = {0.395043, 0.645227},
    [233] = {-0.232095, 0.283834},
    [234] = {-0.507699, 0.317122},
    [235] = {-0.606604, -0.227259},
    [236] = {0.526430, -0.408765},
    [237] = {0.304079, 0.135680},
    [238] = {-0.134042, 0.508741},
    [239] = {-0.276770, 0.383958},
    [240] = {-0.298963, -0.233668},
    [241] = {0.171889, 0.697367},
    [242] = {-0.292571, -0.317604},
    [243] = {0.587806, 0.115584},
    [244] = {-0.346690, -0.098320},
    [245] = {0.956701, -0.040982},
    [246] = {0.040838, 0.595304},
    [247] = {0.365201, -0.519547},
    [248] = {-0.397271, -0.090567},
    [249] = {-0.124873, -0.356800},
    [250] = {-0.122144, 0.617725},
    [251] = {0.191266, -0.197764},
    [252] = {-0.178092, 0.503667},
    [253] = {0.103221, 0.547538},
    [254] = {0.019524, 0.621226},
    [255] = {0.663918, -0.573476}
}


local cheatHooks = {}
local function addHook(eventName, identifier, func)
	if not cheatHooks[eventName] then cheatHooks[eventName] = {} end
	cheatHooks[eventName][identifier] = func
	Msg(mocha_sapphire, "[HOOKS] ", mocha_sky, "Created cheat hook for ", eventName, ": ", identifier)
end
local function delHook(eventName, identifier)
	if not cheatHooks[eventName] or not cheatHooks[eventName][identifier] then return end
	cheatHooks[eventName][identifier] = nil
	Msg(mocha_sapphire, "[HOOKS] ", mocha_sky, "Removed cheat hook for ", eventName, ": ", identifier)
end

G.AddConsoleCommand("sillyhack")
local commands = {}
local function handleCommand(args)
	if args[1] then
		if commands[args[1]] then
			commands[args[1]][4](args)
		else
			Msg(mocha_sapphire, "[COMMANDS] ", mocha_red, "Unknown command: ", args[1])
		end
	else
		Msg(mocha_sapphire, "[COMMANDS] ", mocha_red, "Please specify a command!")
	end
end
local function addCommand(name, syntax, desc, func, aliases)
	commands[name] = {
		name, syntax, desc, func, aliases
	}
	Msg(mocha_sapphire, "[COMMANDS] ", mocha_sky, "Added command ", name)
end


luadetours["require"] = {}
luadetours["include"] = {}

local hookRun
luadetours["require"]["hook"] = function()
	local original_Call = hook.Call
	local hookRun = hook.Run
	hook.Call = createDetour(original_Call, "hook.Call", function(eventName, gamemodeTable, ...)
		local eventTable = cheatHooks[eventName]
		if eventTable ~= nil then
			local a, b, c, d, e, f
			for i, v in pairs(eventTable) do
				a, b, c, d, e, f = v(...)
			end
			if a ~= nil then
				return a, b, c, d, e, f
			end
		end

		return original_Call(eventName, gamemodeTable, ...)
	end)
end

luadetours["require"]["concommand"] = function()
	local original_Run = concommand.Run
	local original_AutoComplete = concommand.AutoComplete
	concommand.Run = createDetour(original_Run, "concommand.Run", function(ply, cmd, args, argStr)
		if G.string.lower(cmd) == "sillyhack" then
			handleCommand(args)
			return true
		end
		return original_Run(ply, cmd, args, argStr)
	end)
	concommand.AutoComplete = createDetour(original_AutoComplete, "concommand.AutoComplete", function(cmd, argStr, args)
		if G.string.lower(cmd) == "sillyhack" then
			local autoCompletes = {}
			local firstarg = args[1] or ""

			if commands[firstarg] ~= nil then
				G.table.insert(autoCompletes, cmd .. " " .. G.string.lower(firstarg) .. " " .. commands[firstarg][2])
			else
				for commandName, commandData in next, commands do
					if startsWith(commandName, firstarg) then
						G.table.insert(autoCompletes, cmd .. " " .. commandName)
					end
				end
			end

			return autoCompletes
		end
		return original_AutoComplete(cmd, argStr, args)
	end)
end


luadetours["include"]["ulib/shared/hook.lua"] = function()
	Msg(mocha_mauve, "[LUADETOURS] ", mocha_sky, "ULib override broke cheat hook system, redetouring!")
	luadetours["require"]["hook"]()
end


debug.sethook = createDetour(G.debug.sethook, "debug.sethook", function(thread, hook, mask, count)
    return G.debug.sethook(thread, function(event, ...)
		if G.debug.getinfo(2).short_src == "sillyhack.lua" then return end
		return hook(event, ...)
	end, mask, count)
end)

local function getSafeStackLevel(stackLevel)
	if G.debug.getinfo(stackLevel).short_src == "sillyhack.lua" then
		return getSafeStackLevel(stackLevel + 1)
	end
	return stackLevel
end

debug.getinfo = createDetour(G.debug.getinfo, "debug.getinfo", function(funcOrStackLevel, fields, func)
	if type(funcOrStackLevel) == "function" and detours[funcOrStackLevel] then
		return G.debug.getinfo(detours[funcOrStackLevel], fields)
	end
	--[[if type(funcOrStackLevel) == "number" then
		return G.debug.getinfo(getSafeStackLevel(funcOrStackLevel), fields)
	end]]
	return G.debug.getinfo(funcOrStackLevel, fields, func)
end)

_G.tostring = createDetour(G.tostring, "tostring", function(value)
	if detours[value] then
		return G.tostring(detours[value])
	end
	return G.tostring(value)
end)

string.format = createDetour(G.string.format, "string.format", function(str, ...)
	local data = {...}
	for i, v in next, data do
		if detours[v] then
			data[i] = detours[v]
		end
	end
	return G.string.format(str, unpack(data))
end)

_G.require = createDetour(G.require, "require", function(...)
	local returnval = G.require(...)
	local data = {...}
	if luadetours["require"][data[1]] ~= nil then
		Msg(mocha_mauve, "[LUADETOURS] ", mocha_sky, "Detouring \"", data[1], "\" require")
		luadetours["require"][data[1]]()
		Msg(mocha_mauve, "[LUADETOURS] ", mocha_sky, "Finished detouring \"", data[1], "\" require")
	end
	return returnval
end)

local lastEvent = 0
chat.AddText = createDetour(G.chat.AddText, "chat.AddText", function(...)
	local data = {...}
	if G.type(data[1]) == "table" and data[1].r == 162 and data[1].g == 255 and data[1].b == 162 and data[1].a == 255 and G.type(data[2]) == "string" and data[2]:sub(1, 25) == "[SC] first person to say " then
		lastEvent = G.os.time()
		if modules["Player"].Modules["AutoSC"].toggled then
			G.RunConsoleCommand("say", string.match(data[2], "(%d+)"))
		end
	end
	return G.chat.AddText(...)
end)

_G.include = createDetour(G.include, "include", function(...)
	local returnval = G.include(...)
	local data = {...}
	if luadetours["include"][data[1]] ~= nil then
		Msg(mocha_mauve, "[LUADETOURS] ", mocha_sky, "Detouring \"", data[1], "\" include")
		luadetours["include"][data[1]]()
		Msg(mocha_mauve, "[LUADETOURS] ", mocha_sky, "Finished detouring \"", data[1], "\" include")
	end
	return returnval
end)

menupanels.watermark = G.vgui.Create("Awesomium")
menupanels.watermark.direction = {
	x = 1,
	y = 1
}
menupanels.watermark.speed = 6
menupanels.watermark:OpenURL("https://files.catbox.moe/hnnf52.gif") -- gentleman: https://files.catbox.moe/bfm3tt.gif
menupanels.watermark:SetSize(150, 150) -- gentleman: 374, 281
menupanels.watermark:SetZPos(-math.huge)
menupanels.watermark:SetVisible(false)
addHook("Tick", "doWatermarkBounce", function()
	local x = menupanels.watermark:GetX() + menupanels.watermark.direction.x * menupanels.watermark.speed
	local y = menupanels.watermark:GetY() + menupanels.watermark.direction.y * menupanels.watermark.speed
	local scrW = G.ScrW()
	local scrH = G.ScrH()
	
	if (x + menupanels.watermark:GetWide() + menupanels.watermark.direction.x * menupanels.watermark.speed >= scrW) or (x + menupanels.watermark.direction.x * menupanels.watermark.speed < 0) then
		menupanels.watermark.direction.x = menupanels.watermark.direction.x * -1
	end
	
	if (y + menupanels.watermark:GetTall() + menupanels.watermark.direction.y * menupanels.watermark.speed >= scrH) or (y + menupanels.watermark.direction.y * menupanels.watermark.speed < 0) then
		menupanels.watermark.direction.y = menupanels.watermark.direction.y * -1
	end
	
	menupanels.watermark:SetPos(x, y)
end)

local function reloadCategoryWindows()
	for i, v in next, clickguipanels do
		v:SetVisible(false)
	end
	for i, v in next, hudpanels do
		v:SetVisible(false)
	end
	for i, v in next, windowpanels do
		v:SetVisible(false)
	end
	if not menuOpen then return end
	if currentguicategory == 1 then
		for i, v in next, clickguipanels do
			v:SetVisible(true)
		end
	elseif currentguicategory == 2 then
		for i, v in next, hudpanels do
			v:SetVisible(true)
		end
	elseif currentguicategory == 3 then
		for i, v in next, windowpanels do
			v:SetVisible(true)
		end
	end
end

menupanels.sidebar = G.vgui.Create("Panel")
menupanels.sidebar:SetVisible(false)
menupanels.sidebar:SetSize(64, 4 + #guicategories * 56 + #guicategories * 4)
--menupanels.sidebar:MakePopup()
menupanels.sidebar.Think = function(self)
	self:SetPos(G.ScrW() - self:GetWide(), G.ScrH() / 2 - self:GetTall() / 2)
end
menupanels.sidebar.Paint = function(self, w, h)
	drawRoundedBox(8, 0, 0, w, h, {r = 60, g = 60, b = 60, a = 100}, true, false, true, false)
	drawRoundedBox(8, 4, currentguicategory * 4 + (currentguicategory - 1) * 56, 56, 56, getRainbowCol(), true, true, true, true)

	local mouseX, mouseY = self:ScreenToLocal(G.gui.MouseX(), G.gui.MouseY())
	for i = 1, #guicategories do
		if mouseX >= 4 and mouseX < 4 + 56 then
			if mouseY >= i * 4 + (i - 1) * 56 and mouseY < i * 4 + (i - 1) * 56 + 56 then
				drawRoundedBox(8, 4, i * 4 + (i - 1) * 56, 56, 56, {r = 80, g = 80, b = 80, a = 100}, true, true, true, true)
			end
		end

		drawSimpleTextOutlined(guicategories[i][2], "fontawesomesolid36sillyhack", 4 + 56 / 2, 4 + i * 4 + (i - 1) * 56, color_white, TEXT_ALIGN_CENTER, TEXT_ALIGN_TOP, 2, color_black)
		drawSimpleTextOutlined(guicategories[i][1], "jetbrainsmono10sillyhack", 4 + 56 / 2, 2 + (i - 1) * 4 + i * 56, color_white, TEXT_ALIGN_CENTER, TEXT_ALIGN_BOTTOM, 1, color_black)
	end
end
menupanels.sidebar.OnMousePressed = function(self, keyCode)
	if keyCode ~= 107 then return end
	local mouseX, mouseY = self:ScreenToLocal(G.gui.MouseX(), G.gui.MouseY())
	for i = 1, #guicategories do
		if mouseX >= 4 and mouseX < 4 + 56 then
			if mouseY >= i * 4 + (i - 1) * 56 and mouseY < i * 4 + (i - 1) * 56 + 56 then
				currentguicategory = i
				reloadCategoryWindows()
			end
		end
	end
end

clickguipanels.guitoggle = G.vgui.Create("Panel")
clickguipanels.guitoggle:SetVisible(false)
G.surface.SetFont("fontawesomesolid16sillyhack")
local textW, textH = G.surface.GetTextSize("")
local width = 3 + textW + 3
for i, v in next, modules do
	G.surface.SetFont("jetbrainsmono14sillyhack")
	textW, textH = G.surface.GetTextSize(i)
	width = width + textW + 3 + 3 + 3
end
clickguipanels.guitoggle:SetSize(width, 24)
clickguipanels.guitoggle.Think = function(self)
	self:SetPos(G.ScrW() / 2 - self:GetWide() / 2, 0)
end
clickguipanels.guitoggle.Paint = function(self, w, h)
	drawRoundedBox(8, 0, 0, w, h, {r = 60, g = 60, b = 60, a = 100}, false, false, true, true)
	local mouseX, mouseY = self:ScreenToLocal(G.gui.MouseX(), G.gui.MouseY())
	local currentx = 0
	for i, v in next, modules do
		G.surface.SetFont("jetbrainsmono14sillyhack")
		local tW, tH = G.surface.GetTextSize(i)
		if v.IsShown then
			drawRoundedBox(8, currentx + 3, 3, 3 + tW + 3, 18, getRainbowCol(), true, true, true, true)
		end
		if mouseX >= currentx + 3 and mouseX < currentx + 3 + 3 + tW + 3 then
			if mouseY >= 3 and mouseY < 21 then
				drawRoundedBox(8, currentx + 3, 3, 3 + tW + 3, 18, {r = 80, g = 80, b = 80, a = 100}, true, true, true, true)
			end
		end
		drawSimpleTextOutlined(i, "jetbrainsmono14sillyhack", currentx + 3 + 3, 24 / 2, color_white, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER, 1, color_black)
		currentx = currentx + tW + 3 + 3 + 3
	end

	drawSimpleTextOutlined("", "fontawesomesolid16sillyhack", self:GetWide() - 3, self:GetTall() / 2, color_white, TEXT_ALIGN_RIGHT, TEXT_ALIGN_CENTER, 1, color_black)
end
clickguipanels.guitoggle.OnMousePressed = function(self, keyCode)
	local mouseX, mouseY = self:ScreenToLocal(G.gui.MouseX(), G.gui.MouseY())
	local currentx = 0
	for i, v in next, modules do
		G.surface.SetFont("jetbrainsmono14sillyhack")
		local tW, tH = G.surface.GetTextSize(i)
		if mouseX >= currentx + 3 and mouseX < currentx + 3 + 3 + tW + 3 then
			if mouseY >= 3 and mouseY < 21 then
				v.IsShown = not v.IsShown
			end
		end
		currentx = currentx + tW + 3 + 3 + 3
	end
end

local currentTooltip = ""
local count = 0
for categoryName, categoryData in next, modules do
	clickguipanels[categoryName] = G.vgui.Create("Panel")
	clickguipanels[categoryName]:SetVisible(false)
	local height = 20 + 2
	local noExpandHeight = 20 + 2
	for i, v in next, categoryData.Modules do
		height = height + 20 + 2
		noExpandHeight = noExpandHeight + 20 + 2
		for i, v in next, v.options do
			height = height + 20 + 2
		end
	end
	clickguipanels[categoryName]:SetSize(150, height)
	clickguipanels[categoryName]:SetPos(4 + count * 150 + count * 4, 30)
	clickguipanels[categoryName].OnMousePressed = function(self, keyCode)
		if not categoryData.IsShown then return end
		local screenX, screenY = self:LocalToScreen(0, 0)
		
		if G.gui.MouseY() < (screenY + 20) then
			self.Dragging = {G.gui.MouseX() - self.x, G.gui.MouseY() - self.y}
			self:MouseCapture(true)
		end

		local mouseX, mouseY = self:ScreenToLocal(G.gui.MouseX(), G.gui.MouseY())
		if keyCode == 107 then
			local count = 0
			for moduleName, moduleData in next, categoryData.Modules do
				if mouseX >= 2 and mouseX < 148 then
					if mouseY >= 20 + 2 + count * 20 + count * 2 and mouseY < 20 + 2 + count * 20 + count * 2 + 20 then
						moduleData.toggled = not moduleData.toggled
					end
				end
				count = count + 1
				if moduleData.expanded then
					for settingName, settingData in next, moduleData.options do
						if settingData.type == OPTIONTYPE_BOOL then
							if mouseX >= 4 and mouseX < 148 then
								if mouseY >= 20 + 2 + count * 20 + count * 2 and mouseY < 20 + 2 + count * 20 + count * 2 + 20 then
									settingData.value = not settingData.value
								end
							end
						end
						if settingData.type == OPTIONTYPE_MODE then
							if mouseX >= 4 and mouseX < 148 then
								if mouseY >= 20 + 2 + count * 20 + count * 2 and mouseY < 20 + 2 + count * 20 + count * 2 + 20 then
									if settingData.value >= #settingData.values then
										settingData.value = 1
									else
										settingData.value = settingData.value + 1
									end
								end
							end
						end
						count = count + 1
					end
				end
			end
		end
		if keyCode == 108 then
			local count = 0
			for moduleName, moduleData in next, categoryData.Modules do
				if mouseX >= 2 and mouseX < 148 then
					if mouseY >= 20 + 2 + count * 20 + count * 2 and mouseY < 20 + 2 + count * 20 + count * 2 + 20 then
						moduleData.expanded = not moduleData.expanded
					end
				end
				count = count + 1
			end
		end
	end
	clickguipanels[categoryName].OnMouseReleased = function(self, keyCode)
		if not categoryData.IsShown then return end
		self.Dragging = nil
		self:MouseCapture(false)
	end
	clickguipanels[categoryName].Think = function(self)
		if not categoryData.IsShown then return end
		local mouseX = G.math.min(G.math.max(G.gui.MouseX(), 1), G.ScrW() - 1)
		local mouseY = G.math.min(G.math.max(G.gui.MouseY(), 1), G.ScrH() - 1)

		if self.Dragging then
			self:SetPos(mouseX - self.Dragging[1], mouseY - self.Dragging[2])
		end
	end
	clickguipanels[categoryName].Paint = function(self, w, h)
		if not categoryData.IsShown then return end
		local mouseX, mouseY = self:ScreenToLocal(G.gui.MouseX(), G.gui.MouseY())
		G.surface.SetDrawColor(getRainbowCol())
		G.surface.DrawRect(0, 0, w, 20)
		G.surface.SetDrawColor(60, 60, 60, 100)
		G.surface.DrawRect(0, 20, w, 2)
		drawSimpleTextOutlined(categoryName, "jetbrainsmono14sillyhack", w / 2, 20 / 2, color_white, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER, 1, color_black)
		local count = 0
		for moduleName, moduleData in next, categoryData.Modules do
			G.surface.SetDrawColor(60, 60, 60, 100)
			G.surface.DrawRect(0, 20 + 2 + (count * 20) + (count * 2), w, 20 + 2)
			G.surface.SetDrawColor(100, 100, 100, 100)
			if moduleData.toggled then 
				G.surface.SetDrawColor(getRainbowCol(count * 4))
			end
			G.surface.DrawRect(2, 20 + 2 + count * 20 + count * 2, 146, 20)
			if mouseX >= 2 and mouseX < 148 then
				if mouseY >= 20 + 2 + count * 20 + count * 2 and mouseY < 20 + 2 + count * 20 + count * 2 + 20 then
					currentTooltip = moduleData.tooltip or ""
					G.surface.SetDrawColor(120, 120, 120, 100)
					G.surface.DrawRect(2, 20 + 2 + count * 20 + count * 2, 146, 20)
				end
			end
			drawSimpleTextOutlined(moduleName, "jetbrainsmono14sillyhack", 4, 20 + 2 + count * 20 + count * 2 + 10, color_white, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER, 1, color_black)
			count = count + 1
			if moduleData.expanded then
				for settingName, settingData in next, moduleData.options do
					if settingData.type == OPTIONTYPE_BOOL then
						G.surface.SetDrawColor(60, 60, 60, 100)
						G.surface.DrawRect(0, 20 + 2 + (count * 20) + (count * 2), w, 20 + 2)
						G.surface.SetDrawColor(100, 100, 100, 100)
						if settingData.value == true then 
							G.surface.SetDrawColor(getRainbowCol(count * 4))
						end
						G.surface.DrawRect(4, 20 + 2 + count * 20 + count * 2, 144, 20)
						if mouseX >= 4 and mouseX < 148 then
							if mouseY >= 20 + 2 + count * 20 + count * 2 and mouseY < 20 + 2 + count * 20 + count * 2 + 20 then
								currentTooltip = settingData.tooltip or ""
								G.surface.SetDrawColor(120, 120, 120, 100)
								G.surface.DrawRect(4, 20 + 2 + count * 20 + count * 2, 144, 20)
							end
						end
						drawSimpleTextOutlined(settingName, "jetbrainsmono14sillyhack", 6, 20 + 2 + count * 20 + count * 2 + 10, color_white, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER, 1, color_black)
					end
					if settingData.type == OPTIONTYPE_MODE then
						G.surface.SetDrawColor(60, 60, 60, 100)
						G.surface.DrawRect(0, 20 + 2 + (count * 20) + (count * 2), w, 20 + 2)
						G.surface.SetDrawColor(100, 100, 100, 100)
						G.surface.DrawRect(4, 20 + 2 + count * 20 + count * 2, 144, 20)
						if mouseX >= 4 and mouseX < 148 then
							if mouseY >= 20 + 2 + count * 20 + count * 2 and mouseY < 20 + 2 + count * 20 + count * 2 + 20 then
								currentTooltip = settingData.tooltip or ""
								G.surface.SetDrawColor(120, 120, 120, 100)
								G.surface.DrawRect(4, 20 + 2 + count * 20 + count * 2, 144, 20)
							end
						end
						drawSimpleTextOutlined(settingName, "jetbrainsmono14sillyhack", 6, 20 + 2 + count * 20 + count * 2 + 10, color_white, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER, 1, color_black)
						drawSimpleTextOutlined(settingData.values[settingData.value], "jetbrainsmono14sillyhack", 148 - 2, 20 + 2 + count * 20 + count * 2 + 10, color_white, TEXT_ALIGN_RIGHT, TEXT_ALIGN_CENTER, 1, color_black)
					end
					count = count + 1
				end
			end
		end
	end
	
	count = count + 1
end

clickguipanels.Tooltip = G.vgui.Create("Panel")
clickguipanels.Tooltip:SetVisible(false)
clickguipanels.Tooltip.Think = function(self)
	self:SetSize(G.ScrW() * 2, G.ScrH())
	self:SetPos(G.gui.MouseX() + 10 - G.ScrW(), G.gui.MouseY() + 10)
end
clickguipanels.Tooltip.Paint = function(self, w, h)
	if currentTooltip == "" then return end
	G.surface.SetFont("jetbrainsmono14sillyhack")
	local tW, tH = G.surface.GetTextSize(currentTooltip)
	G.surface.SetDrawColor(60, 60, 60, 100)
	if self:LocalToScreen(G.ScrW() + 4 + tW + 4, 0) > G.ScrW() then
		G.surface.DrawRect(G.ScrW() - 4 - tW - 4, 0, 4 + tW + 4, 4 + tH + 4)
		drawSimpleTextOutlined(currentTooltip, "jetbrainsmono14sillyhack", G.ScrW() - 4, 4, color_white, TEXT_ALIGN_RIGHT, TEXT_ALIGN_TOP, 1, color_black)
	else
		G.surface.DrawRect(G.ScrW(), 0, 4 + tW + 4, 4 + tH + 4)
		drawSimpleTextOutlined(currentTooltip, "jetbrainsmono14sillyhack", G.ScrW() + 4, 4, color_white, TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP, 1, color_black)
	end
	currentTooltip = ""
end


hudpanels["ClientName"] = G.vgui.Create("Label")
hudpanels["ClientName"]:SetPos(4, 4)
hudpanels["ClientName"]:SetText("sillyhack")
hudpanels["ClientName"]:SizeToContents()
hudpanels["ClientName"].Paint = function(self, w, h)

end


windowpanels["Console"] = G.vgui.Create("EditablePanel")
windowpanels["Console"]:SetVisible(false)
windowpanels["Console"]:SetPos(4, 4)
windowpanels["Console"]:SetSize(575, 390)
windowpanels["Console"].Paint = function(self, w, h)
	G.surface.SetDrawColor(getRainbowCol())
	G.surface.DrawRect(0, 0, w, 24)
	G.surface.SetDrawColor(60, 60, 60, 80)
	G.surface.DrawRect(0, 24, w, h - 24)
	drawSimpleTextOutlined("Console", "jetbrainsmono14sillyhack", 4, 12, color_white, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER, 1, color_black)
end
windowpanels["Console"].Think = function(self)
	local mouseX, mouseY = G.gui.MouseX(), G.gui.MouseY()
	if self.Dragging then
		self:SetPos(mouseX - self.Dragging[1], mouseY - self.Dragging[2])
	end
	if self.y < 0 then self:SetPos(self.x, 0) end
end
windowpanels["Console"].OnMousePressed = function(self)
	local mouseX, mouseY = self:ScreenToLocal(G.gui.MouseX(), G.gui.MouseY())

	if mouseY >= 0 and mouseY < 24 then
		self.Dragging = {G.gui.MouseX() - self.x, G.gui.MouseY() - self.y}
		self:MouseCapture(true)
		return
	end
end
windowpanels["Console"].OnMouseReleased = function(self)
	self.Dragging = nil
	self:MouseCapture(false)
end
windowpanels["Console"].console = G.vgui.Create("RichText", windowpanels["Console"])
windowpanels["Console"].console:SetPos(2, 26)
windowpanels["Console"].console:SetSize(571, 362)
windowpanels["Console"].console.PerformLayout = function(self)
	self:SetBGColor(80, 80, 80, 100)
end
doMsg = function(data)
	for i, v in ipairs(data) do
		if G.type(v) == "table" then
			windowpanels["Console"].console:InsertColorChange(v.r, v.g, v.b, v.a)
		else
			windowpanels["Console"].console:AppendText(G.tostring(v))
		end
	end
end
doMsg(msgs)
msgs = nil

addHook("Think", "openMenu", function()
	if G.input.IsKeyDown(72) then
		if not menuBtnDown then
			menuOpen = not menuOpen
			G.gui.EnableScreenClicker(menuOpen)
			for i, v in next, menupanels do
				v:SetVisible(menuOpen)
			end
			reloadCategoryWindows()
		end
		menuBtnDown = true
	else
		menuBtnDown = false
	end
end)

G.timer.Create("esfjvtkhgnisverivteirm", 64, 0, function()
	if not modules["Miscellaneous"].Modules["SUIRatingSpam"].toggled then return end
	for i, v in next, G.player.GetAll() do
		if v == LocalPlayer() then continue end
		me:ConCommand("sui_rateuser " .. v:EntIndex() .. " " .. modules["Miscellaneous"].Modules["SUIRatingSpam"].options["Rating"].values[modules["Miscellaneous"].Modules["SUIRatingSpam"].options["Rating"].value])
	end
end)

local AnnounceCooldown = 0
local AnnounceMsgs = {}

addHook("Think", "sendAnnounce", function()
	if not modules["Chat"].Modules["Announce"].toggled then return end
	if G.SysTime() - AnnounceCooldown < 3 then return end
	if AnnounceMsgs[1] ~= nil then
		G.RunConsoleCommand("say", AnnounceMsgs[1])
		G.table.remove(AnnounceMsgs, 1)
		AnnounceCooldown = G.SysTime()
	end
end)

addHook("InitPostEntity", "setLocalPlayer", function()
	me = G.LocalPlayer()
	Msg(mocha_blue, "[HOOKS] ", mocha_sky, "Successfully got LocalPlayer!")
end)

local lastPickedUpProp = ""
addHook("DrawPhysgunBeam", "addPickUpAnnounce", function(ply, physgun, enabled, target, physBone, hitPos)
	if not modules["Chat"].Modules["Announce"].toggled then return end
	if not modules["Chat"].Modules["Announce"].options["PhysgunPickup"].value == true then return end
	if ply == LocalPlayer() and enabled and IsValid(target) and target:GetClass() == "prop_physics" and lastPickedUpProp ~= target:GetModel() then
		G.table.insert(AnnounceMsgs, "I just picked up a " .. getFileFromFilename(target:GetModel()) .. "!")
		lastPickedUpProp = target:GetModel()
	end
end)

G.gameevent.Listen("entity_killed")
addHook("entity_killed", "addKillAnnounce", function(data)
	if not modules["Chat"].Modules["Announce"].toggled then return end
	if not modules["Chat"].Modules["Announce"].options["KillPlayer"].value == true then return end
	local attacker = G.ents.GetByIndex(data.entindex_attacker)
	local killed = G.ents.GetByIndex(data.entindex_killed)
	local inflictor = G.ents.GetByIndex(data.entindex_inflictor)

	if attacker == LocalPlayer() and killed:IsPlayer() and killed ~= LocalPlayer() and IsValid(inflictor) then
		local kill = "killed"
		local inflictorName = inflictor:GetClass()

		if inflictorName == "prop_physics" then
			inflictorName = getFileFromFilename(inflictor:GetModel())
			kill = "prop" .. kill
		end

		G.table.insert(AnnounceMsgs, "I just " .. kill .. " " .. killed:Nick() .. " with a " .. inflictorName .. "!")
	end
end)

addHook("HUDPaint", "drawAutoSCTimer", function()
	if not modules["Player"].Modules["AutoSC"].toggled then return end
	if not modules["Player"].Modules["AutoSC"].options["HUDTimer"].value == true then return end
	local str = "waiting for next SC event"
	if lastEvent ~= 0 then
		local currentTime = G.os.time()
		local timeRemaining = (30 * 60) - (currentTime - lastEvent)
		if timeRemaining < 0 then timeRemaining = 0 end
		local formattedTime = G.os.date("!%X", timeRemaining)
		str = "next SC event: " .. formattedTime
	end
	drawSimpleTextOutlined(str, "jetbrainsmono14sillyhack", ScrW() - 4, ScrH() - 4, color_white, TEXT_ALIGN_RIGHT, TEXT_ALIGN_BOTTOM, 1, color_black)
end)

local messageMap = {
	["bbotgen"] = {"bbot key gen: scottpott8.co.uk"},
	["advertise"] = {"get silly get hax get sillyhax", "sillyhack is the best gmod cheat for silly individuals", "you aren't silly without sillyhack", "sillyhack download link: https://hotballs.cc/zOCE1/jOBiDoyu80.jpg", "the voices are telling me to advertise sillyhack please download", "sillyhack is the best gmod hack so you should download it", "are you silly? do you need a hack? get sillyhack!!"}
}

G.timer.Create("nhdkfsrgvjkervntgsjtersuyg", .35, 0, function()
	if not modules["Chat"].Modules["Spam"].toggled then return end
	local msglist = messageMap[modules["Chat"].Modules["Spam"].options["Mode"].values[modules["Chat"].Modules["Spam"].options["Mode"].value]]
	if msglist then
		local msg = msglist[G.math.random(1, #msglist)]
		if modules["Chat"].Modules["Spam"].options["ULXChat"].value == true then
			for i, v in ipairs(G.player.GetHumans()) do
				if v == me then continue end
				if modules["Chat"].Modules["Spam"].options["IgnoreFriends"].value == true and me:GetFriendStatus() == "friend" then continue end
				G.RunConsoleCommand("ulx", "psay", v:Nick(), msg)
			end
		else
			G.RunConsoleCommand("say", msg)
		end
	end
end)

addHook("HUDPaint", "draw2DESP", function()
	if not modules["Render"].Modules["ESP"].toggled then return end
	for i, v in next, G.player.GetAll() do
        if !v:IsValid() or !v:IsPlayer() or !v:Alive() or 0 >= v:Health() or v == me then continue end
        local min, max = v:GetCollisionBounds()
        local pos = v:GetPos()
        local top, bottom = (pos + G.Vector(0, 0, max.z)):ToScreen(), (pos - G.Vector(0, 0, 8)):ToScreen()
        local middle = bottom.y - top.y
        local width = middle / 2.425
 
        if modules["Render"].Modules["ESP"].options["Names"].value == true then
            drawSimpleTextOutlined(v:Nick(), "jetbrainsmono14sillyhack", bottom.x, top.y, getRainbowCol(), TEXT_ALIGN_CENTER, TEXT_ALIGN_BOTTOM, 1, color_black)
        end
 
        if modules["Render"].Modules["ESP"].options["2D Boxes"].value == true then
            G.surface.SetDrawColor(me:Team() == v:Team() and {r = 0, g = 255, b = 100, a = 255} or {r = 200, g = 100, b = 0, a = 255})
            G.surface.DrawOutlinedRect(bottom.x - width, top.y, width * 2, middle)
            G.surface.SetDrawColor(0, 0, 0)
            G.surface.DrawOutlinedRect(bottom.x - width - 1, top.y - 1, width * 2 + 2, middle + 2)
            G.surface.DrawOutlinedRect(bottom.x - width + 1, top.y + 1, width * 2 - 2, middle - 2)
        end

		local y = 0

		if modules["Render"].Modules["ESP"].options["Weapon"].value == true then
			local wep = v:GetActiveWeapon()
			if IsValid(wep) then
				drawSimpleTextOutlined(wep.GetPrintName and wep:GetPrintName() or wep:GetClass(), "jetbrainsmono14sillyhack", bottom.x, bottom.y, color_white, TEXT_ALIGN_CENTER, TEXT_ALIGN_TOP, 1, color_black)
				y = y + 14
			end
		end

		if modules["Render"].Modules["ESP"].options["Rank"].value == true then
			drawSimpleTextOutlined(v.GetUserGroup and v:GetUserGroup() or "No Rank", "jetbrainsmono14sillyhack", bottom.x, bottom.y + y, color_white, TEXT_ALIGN_CENTER, TEXT_ALIGN_TOP, 1, color_black)
			y = y + 14
		end

		local val = modules["Render"].Modules["ESP"].options["Health"].value
		if val == 2 or val == 4 then
			drawSimpleTextOutlined(v.Health and "H: " .. v:Health() or "H: 0", "jetbrainsmono14sillyhack", bottom.x, bottom.y + y, color_white, TEXT_ALIGN_CENTER, TEXT_ALIGN_TOP, 1, color_black)
			y = y + 14
		end
		if val == 3 or val == 4 then
			local clampedHealth = G.math.min(G.math.max(v:Health(), 0), 100)
			local g = clampedHealth * 2.55
			local r = 255 - g
			G.surface.SetDrawColor(0, 0, 0)
			G.surface.DrawRect(bottom.x + width + 2, top.y - 1, 4, middle + 2)
			G.surface.SetDrawColor(r, g, 0)
			local height = clampedHealth * middle / 100
			G.surface.DrawRect(bottom.x + width + 3, top.y + middle - height, 2, height)
		end
	end
end)

addHook("PostDrawOpaqueRenderables", "drawLandingPos", function()
	if not modules["Render"].Modules["LandingTrajectory"].toggled then return end
	local landPos, tr, parabolaTop = getLandingPos()
	if not landPos then return end

	endSpeed = parabolaTop.z - tr.HitPos.z
	local color = endSpeed >= 240 and {r = 255, g = 0, b = 0, a = 255} or {r = 255, g = 255, b = 255, a = 255}
	G.cam.IgnoreZ(true)
	G.cam.Start3D2D(landPos, tr.HitNormal:Angle():Up():Angle(), 1)
	drawRoundedBox(8, -32, -32, 64, 64, color, true, true, true, true)
	G.cam.End3D2D()
	G.cam.IgnoreZ(false)
	render.DrawLine(tr.StartPos, landPos, color)
end)

local function normalizeAngle(a)
	return (a + 180) % 360 - 180
end

local function distance(x1, y1, x2, y2)
	local xd = x2 - x1
	local yd = y2 - y1
	return G.math.sqrt(xd * xd + yd * yd)
end

local function RapidFire(cmd)
	if modules["Player"].Modules["RapidFire"].toggled and cmd:KeyDown(1) then
		if (me:Alive() or me:Health() > 0) and IsValid(me:GetActiveWeapon()) and me:GetActiveWeapon():GetClass() ~= "weapon_physgun" then
			if rapidfiretoggle == false then
				cmd:SetButtons(G.bit.bor(cmd:GetButtons()), 1)
				rapidfiretoggle = true
			else
				cmd:SetButtons(G.bit.band(cmd:GetButtons()), G.bit.bnot(1))
				rapidfiretoggle = false
			end
		end
	end
end

local toggler = 0
local function RapidFire(cmd)
	if modules["Player"].Modules["RapidFire"].toggled == true then
		if me:KeyDown(1) then
			if (me:Alive() or me:Health() > 0) and IsValid(me:GetActiveWeapon()) and me:GetActiveWeapon():GetClass() ~= "weapon_physgun" then
				if toggler == 0 then
					cmd:SetButtons(G.bit.bor(cmd:GetButtons(), 1))
					toggler = 1
				else
					cmd:SetButtons(G.bit.band(cmd:GetButtons(), G.bit.bnot(1)))
					toggler = 0
				end
			end
		end
	end
end

local f0 = 0.0
local function BunnyHop(cmd)
	if me:GetMoveType() == 8 or me:GetMoveType() == 9 or me:WaterLevel() > 1 then return end
	if modules["Movement"].Modules["BunnyHop"].toggled == true then
		if me:OnGround() and cmd:KeyDown(2) then
			cmd:AddKey(2)
		else
			cmd:RemoveKey(2)
		end
	end

	if modules["Movement"].Modules["AutoStrafe"].toggled then
		if modules["Movement"].Modules["AutoStrafe"].options["Mode"].value == 2 then
			if not me:OnGround() then
				if cmd:GetMouseX() > 1 or cmd:GetMouseX() < -1 then
					cmd:SetSideMove(cmd:GetMouseX() > 1 and 400 or -400)
				else
					cmd:SetForwardMove(5850 / me:GetVelocity():Length2D())
					cmd:SetSideMove((cmd:CommandNumber() % 2 == 0) and -400 or 400)
				end
			elseif cmd:KeyDown(2) then
				cmd:SetForwardMove(450)
			end
		elseif modules["Movement"].Modules["AutoStrafe"].options["Mode"].value == 1 then
			if not me:IsFlagSet(1) then
				local w = me:EyeAngles()
			    local f2 = function(f3)
			        local f4 = G.math.deg(G.math.atan(30.0 / f3))
			        if f4 > 90.0 then
			            return 90.0
			        elseif f4 < 0.0 then
			            return 0.0
			        else
			            return f4
			        end
			    end
			    local f5 = 57.295779513082
			    local f6 = 10000
			    local f3 = me:GetVelocity()
			    f3.z = 0.0
			    local f7 = cmd:GetForwardMove()
			    local f8 = cmd:GetSideMove()
			    if not f7 or not f8 then
			        return
			    end
			    local f9 = cmd:TickCount() % 2 == 0
			    local fa = f9 and 1.0 or -1.0
			    local fb = G.Angle(w.x, w.y, w.z)
			    if f7 or f8 then
			        cmd:SetForwardMove(0)
			        cmd:SetSideMove(0)
			        local fc = G.math.atan2(-f8, f7)
			        fb.y = fb.y + fc * f5
			    elseif f7 then
			        cmd:SetForwardMove(0)
			    end
			    local fd = G.math.deg(G.math.atan(15 / f3:Length2D()))
			    if fd > 90 then
			        fd = 90
			    elseif fd < 0 then
			        fd = 0
			    end
			    local fe = G.Vector(0, fb.y - f0, 0)
			    fe.y = normalizeAngle(fe.y)
			    local ff = fe.y
			    f0 = fb.y
			    local fg = G.math.abs(ff)
			    if fg <= fd or fg >= 30 then
			        local fh = f3:Angle()
			        fe = G.Vector(0, fb.y - fh.y, 0)
			        fe.y = normalizeAngle(fe.y)
			        local fi = fe.y
			        local fj = f2(f3:Length2D() * 128)
			        if fi <= fj or f3:Length2D() <= 15 then
			            if -fj <= fi or f3:Length2D() <= 15 then
			                fb.y = fb.y + fd * fa
			                cmd:SetSideMove(f6 * fa)
			            else
			                fb.y = fh.y - fj
			                cmd:SetSideMove(f6)
			            end
			        else
			            fb.y = fh.y + fj
			            cmd:SetSideMove(-f6)
			        end
			    elseif ff > 0 then
			        cmd:SetSideMove(-f6)
			    elseif ff < 0 then
			        cmd:SetSideMove(f6)
			    end
			    local fk = G.Vector(cmd:GetForwardMove(), cmd:GetSideMove(), 0)
			    local fl = fk:Length()
			    local fm = fk:Angle()
			    local fn = G.math.modf(w.x + 180, 360) - 180
			    local fo = G.math.modf(w.y + 180, 360) - 180
			    local df = G.math.rad(fo - fb.y + fm.y)
			    if fn >= 90 or fn <= -90 or w.x >= 90 and w.x <= 200 or w.x <= -90 and w.x <= 200 then
			        cmd:SetForwardMove(-G.math.cos(df) * fl)
			    else
			        cmd:SetForwardMove(G.math.cos(df) * fl)
			    end
			    cmd:SetSideMove(G.math.sin(df) * fl)
		    end
		end
	end
end

local angle_zero = G.Angle(0, 0, 0)
local vector_origin = G.Vector(0, 0, 0)

addHook("CreateMove", "doMovementStuff", function(cmd)
	RapidFire(cmd)
	if cmd:CommandNumber() == 0 then return end
	BunnyHop(cmd)
end)

addHook("HUDPaint", "drawHudEditor", function()
	if menuOpen and currentguicategory == 2 then
		G.surface.SetDrawColor(80, 80, 80, 135)
		drawFilledCircle(0, 0, 100)
		drawFilledCircle(G.ScrW(), 0, 100)
		drawFilledCircle(0, G.ScrH(), 100)
		drawFilledCircle(G.ScrW() / 2, G.ScrH(), 100)
		drawFilledCircle(G.ScrW(), G.ScrH(), 100)
	end
end)

addCommand("help", "[command]", "Show command help", function(args)
	if args[2] == nil then
		local cmdlist = {}
		for i, v in next, commands do
			G.table.insert(cmdlist, i)
		end
		Msg(mocha_sapphire, "[COMMANDS] ", mocha_sky, "Commands (", #cmdlist, "): ", G.table.concat(cmdlist, ", "))
	else
		for i, v in next, commands do
			if startsWith(i, G.string.lower(args[2])) then
				Msg(mocha_sapphire, "[COMMANDS] ", mocha_sky, i, " - ", v[3])
				Msg(mocha_sapphire, "[COMMANDS] ", mocha_sky, "Syntax: ", v[2])
				return
			end
		end
	end
end, {"commands", "cmds"})

addCommand("changename", "<newname>", "Set a new name", function(args)
	if args[2] ~= nil then
		Msg(mocha_sapphire, "[COMMANDS] ", mocha_sky, "Setting your name...")
		G.table.remove(args, 1)
		getzxc().NetSetConVar("name", G.table.concat(args, " "))
	else
		Msg(mocha_sapphire, "[COMMANDS] ", mocha_red, "Please specify a name")
	end
end)