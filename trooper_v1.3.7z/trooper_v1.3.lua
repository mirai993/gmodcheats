--[[
	56.lua
	Erfie - New Phone :D | (STEAM_0:0:11602053)
	===DStream===
]]

// TrooperHack v1.3, created by Assault_Trooper.

local VersionNumber = "1.3"
local Version 		= "v" .. VersionNumber .. " Public"

print( "TrooperHack " .. Version .. " loaded!" )

local AimbotSwitch 		= GetConVar( "trooper_aimbot" ) or CreateClientConVar( "trooper_aimbot", 0, true, false )
local BoneSwitch 		= GetConVar( "trooper_aimbot_bone" ) or CreateClientConVar( "trooper_aimbot_bone", 1, true, false )
local AutoshootSwitch 	= GetConVar( "trooper_autoshoot" ) or CreateClientConVar( "trooper_autoshoot", 0, true, false )
local NorecoilSwitch 	= GetConVar( "trooper_norecoil" ) or CreateClientConVar( "trooper_norecoil", 0, true, false )
local FriendSwitch 		= GetConVar( "trooper_friends" ) or CreateClientConVar( "trooper_friends", 0, true, false )
local TeamSwitch 		= GetConVar( "trooper_team" ) or CreateClientConVar( "trooper_team", 0, true, false )
local TargetSwitch 		= GetConVar( "trooper_target" ) or CreateClientConVar( "trooper_target", 0, true, false )
local TargetSteam		= GetConVar( "trooper_target_steamid" ) or CreateClientConVar( "trooper_target_steamid", "", true, false )
local ESPSwitch 		= GetConVar( "trooper_esp" ) or CreateClientConVar( "trooper_esp", 0, true, false )
local DarkrpSwitch 		= GetConVar( "trooper_esp_darkrp" ) or CreateClientConVar( "trooper_esp_darkrp", 0, true, false )
local HealthSwitch 		= GetConVar( "trooper_esp_health" ) or CreateClientConVar( "trooper_esp_health", 0, true, false )
local WeaponSwitch 		= GetConVar( "trooper_esp_weapon" ) or CreateClientConVar( "trooper_esp_weapon", 0, true, false )
local UsergroupSwitch	= GetConVar( "trooper_esp_usergroup" ) or CreateClientConVar( "trooper_esp_usergroup", 0, true, false )
local TargetTypeSwitch 	= GetConVar( "trooper_target_type" ) or CreateClientConVar( "trooper_target_type", 1, true, false )
local CrosshairSwitch	= GetConVar( "trooper_crosshair" ) or CreateClientConVar( "trooper_crosshair", 0, true, false )
local WallhackSwitch	= GetConVar( "trooper_wallhack" ) or CreateClientConVar( "trooper_wallhack", 1, true, false )
local UpdateSwitch		= GetConVar( "trooper_notify_update" ) or CreateClientConVar( "trooper_notify_update", 1, true, false )
local LoadedSwitch		= GetConVar( "trooper_notify_loaded" ) or CreateClientConVar( "trooper_notify_loaded", 1, true, false )
local DeadSwitch		= GetConVar( "trooper_esp_dead" ) or CreateClientConVar( "trooper_esp_dead", 1, true, false )

local THColor = Color( 20, 20, 200 )

if LoadedSwitch:GetBool() then

	timer.Simple( 1, function()
		chat.AddText( THColor, "[TrooperHack] ", Color( 255, 255, 255 ), "loaded" )
	end )

end

local function CheckUpdates()

	http.Get( "http://trooperhack.troopersbuild.info/version.php", "", function( contents )
	
		if !string.match( contents, VersionNumber ) and ( contents != "" ) then
		
			chat.AddText( THColor, "[TrooperHack] ", Color( 255, 255, 255 ), string.format( "A newer version is available. ( %s )", contents ) )
		
		end
	
	end )

end

if UpdateSwitch:GetBool() then

	CheckUpdates()

end

local TARGET_TYPE 	= {}
TARGET_TYPE.ALL		= 1
TARGET_TYPE.PLY 	= 2
TARGET_TYPE.NPC		= 3

local Menu 			= {}

local BannedWeapons = { "weapon_physcannon", "weapon_physgun", "weapon_frag", "weapon_real_cs_smoke", "arrest_stick", "unarrest_stick", "stunstick",
"weapon_real_cs_flash", "weapon_real_cs_grenade", "spidermans_swep", "manhack_welder", "laserpointer", "remotecontroller", "med_kit",
"door_ram", "pocket", "weaponchecker", "lockpick", "keypad_cracker", "keys", "weapon_real_cs_knife", "gmod_tool", "gmod_camera", "weapon_crowbar",
"weapon_stunstick", "weapon_knife", "weapon_fishing_rod", "weapon_slam", "none" }

local DarkrpEnts = { "money_printer", "golden_printer", "platinum_printer", "zz_money_printer", "money_printer_commercial", "money_printer_industrial", "drug_lab",
"gunlab", "microwave", "spawned_shipment", "food", "melon", "drug", "spawned_weapon" }

local function GetPlayerIndex( ply )

	for k,v in pairs ( player.GetAll() ) do

		if v == ply then return k end

	end

end

local function GetPlayerByIndex( index )

	for k,v in pairs ( player.GetAll() ) do
	
		if k == index then return v end
	
	end

end

local function WeaponCheck()

	if LocalPlayer() and LocalPlayer():GetActiveWeapon() and LocalPlayer():GetActiveWeapon():IsValid() then
		
		if table.HasValue( BannedWeapons, LocalPlayer():GetActiveWeapon():GetClass() ) then return false end
		if LocalPlayer():GetActiveWeapon():Clip1() == 0 then return false end

		return true 

	end

end

local Bones = {

	{ "ValveBiped.Bip01_Head1", "Head" },
	{ "ValveBiped.Bip01_Spine", "Spine" }

}

local function GetSpecialBone( target )

	local Targets 	= {}
	local Bones 	= {}
	
	for k,v in pairs( Targets ) do
	
		if string.match( target, Targets[k] ) then
		
			return { use = true, bone = Bones[k] }
		
		end
	
	end
	
	return { use = false, bone = "" }
	
end

local function GetTarget( ent )

	if ent:IsValid() and ( ent:IsPlayer() or ent:IsNPC() ) then

		local Special = GetSpecialBone( ent )
	
		if Special.use == true then
		
			return ent:GetBonePosition( ent:LookupBone( Special.bone ) )
		
		else
	
			for k,v in pairs ( Bones ) do

				if BoneSwitch:GetInt() == k then

					return ent:GetBonePosition( ent:LookupBone( Bones[k][1] ) )
				
				end
			
			end
			
		end

	end

end

local function StatusCheck( ply )

	if !ply:IsValid() then return false end
	if ply:IsWorld() then return false end
	if !( ply:IsPlayer() or ply:IsNPC() ) then return false end
	if FriendSwitch:GetBool() and ply:IsPlayer() and ply:GetFriendStatus() == "friend" then return false end
	if TeamSwitch:GetBool() and ply:IsPlayer() and ply:Team() == LocalPlayer():Team() then return false end
	if TargetSwitch:GetBool() and ply:SteamID() != GetConVarString( TargetSteam:GetName() ) then return false end
	if TargetTypeSwitch:GetInt() == TARGET_TYPE.PLY and !ply:IsPlayer() then return false end
	if TargetTypeSwitch:GetInt() == TARGET_TYPE.NPC and !ply:IsNPC() then return false end

	return true

end

local function GenerateName()

	local Name = ""
	
	for i=1, math.random( math.random( 4, 6 ), math.random( 8, 11 ) ) do
	
		Name = Name .. tostring( math.random( 1, 9 ) )
	
	end
	
	return Name

end

hook.Add( "CreateMove", GenerateName(), function( UCMD )

	local trace = LocalPlayer():GetEyeTrace()

	if trace.Entity:IsValid() and AimbotSwitch:GetBool() and WeaponCheck() and StatusCheck( trace.Entity ) then

		UCMD:SetViewAngles( ( GetTarget( trace.Entity ) - LocalPlayer():GetShootPos() ):Angle() )

	end
	
	if LocalPlayer():Alive() and LocalPlayer():GetActiveWeapon():IsValid() then

		if AutoshootSwitch:GetBool() and WeaponCheck() and StatusCheck( trace.Entity ) then
		
				RunConsoleCommand( "+attack" )
				timer.Simple( 0.5, function()
					RunConsoleCommand( "-attack" )
				end )
		
		else
	
			if LocalPlayer():GetActiveWeapon():Clip1() == 0 then
		
				RunConsoleCommand( "+reload" )
				timer.Simple( 1, function()
					RunConsoleCommand( "-reload" )
				end )
			
			end

		end
	
	end

	if NorecoilSwitch:GetBool() and WeaponCheck() and LocalPlayer():Alive() and LocalPlayer():GetActiveWeapon():IsValid() and LocalPlayer():GetActiveWeapon().Primary then

		LocalPlayer():GetActiveWeapon().Primary.Recoil = 0

	end

end )

local function WeaponGet( ply )

	if ply:IsValid() and ply:GetActiveWeapon() and ply:GetActiveWeapon():IsValid() then

		return ply:GetActiveWeapon():GetClass()

	else

		return "N/A"

	end

end

local function UsergroupGet( ply )

	if ply:IsValid() then

			if ply:IsSuperAdmin() then
			
				return "Superadmin"
				
			elseif ply:IsAdmin() then
			
				return "Admin"
				
			else
				
				if pcall( function() ply:GetUserGroup() end ) then
					
					return ply:GetUserGroup()
					
				elseif pcall( function() ply:EV_GetRank() end ) then
				
					return ply:EV_GetRank()
					
				else
				
					return "Player"
					
				end
				
			end
			
	else

		return "N/A"

	end

end

hook.Add( "HUDPaint", GenerateName(), function()

	if ESPSwitch:GetBool() then
	
		for k,v in pairs ( player.GetAll() ) do

			local Position = ( v:GetPos() + Vector( 0,0,80 ) ):ToScreen()
			local Name = ""
			local nColor = Color( 255, 255, 255, 255 )
			
			if v != LocalPlayer() then Name = v:Name() end
			
			if !v:Alive() and DeadSwitch:GetBool() then
				Name = "*Dead* " .. Name 
				nColor = Color( 0,0,0,255 )			
			elseif !v:Alive() and !DeadSwitch:GetBool() then
				Name = ""
				nColor = Color( 0,0,0,0 )
			else
				nColor = team.GetColor( v:Team() ) 
			end

			draw.DrawText( Name, "MenuLarge", Position.x, Position.y, nColor, 1 )

			if HealthSwitch:GetBool() and v != LocalPlayer() then
				draw.DrawText( "HP: " .. v:Health(), "UiBold", Position.x , Position.y + 12, nColor, 1 )
			end

			if WeaponSwitch:GetBool() and v != LocalPlayer() then

				local Math
				if HealthSwitch:GetBool() then Math = 22 else Math = 12 end

				draw.DrawText( "Weapon: " .. WeaponGet( v ), "UiBold", Position.x , Position.y + Math, nColor, 1 )

			end

			if UsergroupSwitch:GetBool() and v != LocalPlayer() then

				local Math
				if WeaponSwitch:GetBool() and HealthSwitch:GetBool() then
					Math = 32
				elseif !HealthSwitch:GetBool() and WeaponSwitch:GetBool() or !WeaponSwitch:GetBool() and HealthSwitch:GetBool() then
					Math = 22
				else
					Math = 12
				end

				draw.DrawText( "Usergroup: " .. UsergroupGet( v ), "UiBold", Position.x , Position.y + Math, nColor, 1 )

			end

		end

	end

	if DarkrpSwitch:GetBool() then

		for _,ent in pairs ( ents.GetAll() ) do

			if ent:IsValid() and table.HasValue( DarkrpEnts, ent:GetClass() ) then

				local Position = ent:GetPos():ToScreen()
				draw.DrawText( ent:GetClass(), "MenuLarge", Position.x, Position.y, nColor, 1 )
				
				cam.Start3D( LocalPlayer():GetPos() + Vector( 0, 0, 64 ), LocalPlayer():EyeAngles() )
					ent:DrawModel()
				cam.End3D()

			end

		end

	end
	
	if CrosshairSwitch:GetBool() then
	
		draw.RoundedBox( 4, ( ScrW() / 2 ) - 3, ( ScrH() / 2 ) - 3, 7, 7, Color( 255, 255, 255, 255 ) )
	
	end
	
	if WallhackSwitch:GetBool() then
	
		for k,v in pairs ( player.GetAll() ) do
		
			local Pos
			local Ang = LocalPlayer():GetAngles()
			
			if LocalPlayer():Crouching() then
				Pos = LocalPlayer():GetPos() + Vector( 0, 0, 28 )
			else
				Pos = LocalPlayer():GetPos() + Vector( 0, 0, 64 )
			end
		
			cam.Start3D( Pos, LocalPlayer():EyeAngles() )
		
			v:DrawModel()
			
			if v:GetActiveWeapon() and v:GetActiveWeapon():IsValid() then
				v:GetActiveWeapon():DrawModel()
			end
			
			cam.End3D()
		
		end
	
	end

end )

local function GetPlayerBySteamID( SteamID )

	for k,v in pairs ( player.GetAll() ) do
	
		if v:SteamID() == SteamID then return v end
	
	end

end

concommand.Add( "+trooperhack_menu", function()

	Menu.Main = vgui.Create( "DFrame")
	Menu.Main:SetSize( 380, 300 )
	Menu.Main:SetTitle( "TrooperHack " .. Version .. " - By Assault_Trooper" )
	Menu.Main:Center()
	Menu.Main:MakePopup()

	local AdvTab = vgui.Create( "DPropertySheet", Menu.Main )
	AdvTab:SetPos( 5, 25 )
	AdvTab:SetSize( 370, 270 )
	
	Menu.Image = "trooperhack/assault_trooper"

	local Page1 = vgui.Create( "DImage" )
	Page1:SetImage( Menu.Image )
	AdvTab:AddSheet( "Aimbot", Page1, "gui/silkicons/bomb", false, false, "Aimbot configuration" )
	
	local AimbotToggle = vgui.Create( "DCheckBoxLabel", Page1 )
	AimbotToggle:SetPos( 10, 10 )
	AimbotToggle:SetText( "Aimbot" )
	AimbotToggle:SetValue( GetConVar( AimbotSwitch:GetName() ):GetInt() )
	AimbotToggle:SetConVar( AimbotSwitch:GetName() )
	AimbotToggle:SizeToContents()

	local AimbotTarget = vgui.Create( "DMultiChoice", Page1 )
	AimbotTarget:SetPos( 250, 5 )
	AimbotTarget:SetSize( 100, 20 )
	AimbotTarget:SetEditable( false )
	for k,v in pairs ( Bones ) do
		AimbotTarget:AddChoice( Bones[k][2] )
	end
	AimbotTarget:ChooseOptionID( BoneSwitch:GetInt() )
	AimbotTarget.OnSelect = function( index, value, data )
		RunConsoleCommand( BoneSwitch:GetName(), math.Round( value ) )
	end
	
	AimbotToggle.OnChange = function()
		AimbotTarget:SetVisible( AimbotSwitch:GetBool() )
	end

	local AutoshootToggle = vgui.Create( "DCheckBoxLabel", Page1 )
	AutoshootToggle:SetPos( 10, 40 )
	AutoshootToggle:SetText( "Autoshoot" )
	AutoshootToggle:SetValue( AutoshootSwitch:GetInt() )
	AutoshootToggle:SetConVar( AutoshootSwitch:GetName() )
	AutoshootToggle:SizeToContents()

	local NorecoilToggle = vgui.Create( "DCheckBoxLabel", Page1 )
	NorecoilToggle:SetPos( 10, 70 )
	NorecoilToggle:SetText( "No-recoil" )
	NorecoilToggle:SetValue( NorecoilSwitch:GetInt() )
	NorecoilToggle:SetConVar( NorecoilSwitch:GetName() )
	NorecoilToggle:SizeToContents()

	local TeamToggle = vgui.Create( "DCheckBoxLabel", Page1 )
	TeamToggle:SetPos( 10, 100 )
	TeamToggle:SetText( "Ignore team-mates" )
	TeamToggle:SetValue( TeamSwitch:GetInt() )
	TeamToggle:SetConVar( TeamSwitch:GetName() )
	TeamToggle:SizeToContents()

	local FriendToggle = vgui.Create( "DCheckBoxLabel", Page1 )
	FriendToggle:SetPos( 10, 130 )
	FriendToggle:SetText( "Ignore steam friends" )
	FriendToggle:SetValue( FriendSwitch:GetInt() )
	FriendToggle:SetConVar( FriendSwitch:GetName() )
	FriendToggle:SizeToContents()

	local TargetToggle = vgui.Create( "DCheckBoxLabel", Page1 )
	TargetToggle:SetPos( 10, 160 )
	TargetToggle:SetText( "Specific target" )
	TargetToggle:SetValue( TargetSwitch:GetInt() )
	TargetToggle:SetConVar( TargetSwitch:GetName() )
	TargetToggle:SizeToContents()
	
	local TargetList = vgui.Create( "DMultiChoice", Page1 )
	TargetList:SetPos( 220, 155 )
	TargetList:SetSize( 130, 20 )
	TargetList:SetEditable( false )
	for k,v in pairs ( player.GetAll() ) do
		TargetList:AddChoice( v:Name() )
	end
	TargetList:ChooseOptionID( GetPlayerIndex( GetPlayerBySteamID( GetConVarString( TargetSteam:GetName() ) ) ) or 1 )
	TargetList.OnSelect = function( index, value, data )
		RunConsoleCommand( TargetSteam:GetName(), GetPlayerByIndex( value ):SteamID() )
	end
	
	TargetToggle.OnChange = function( index, value, data )
		TeamToggle:SetDisabled( TargetSwitch:GetBool() )
		FriendToggle:SetDisabled( TargetSwitch:GetBool() )
		TargetList:SetVisible( TargetSwitch:GetBool() )
	end

	local InfoSelect = vgui.Create( "DLabel", Page1 )
	InfoSelect:SetPos( 20, 190 )
	InfoSelect:SetText( "Target:" )
	InfoSelect:SizeToContents()

	local TargetType = vgui.Create( "DMultiChoice", Page1 )
	TargetType:SetPos( 60, 185 )
	TargetType:SetSize( 70, 20 )
	TargetType:SetEditable( false )
	TargetType:AddChoice( "All" )
	TargetType:AddChoice( "Player" )
	TargetType:AddChoice( "NPC" )
	TargetType:ChooseOptionID( TargetTypeSwitch:GetInt() )
	TargetType.OnSelect = function( index, value, data )
		RunConsoleCommand( TargetTypeSwitch:GetName(), math.Round( value ) )
	end

	local Page2 = vgui.Create( "DImage" )
	Page2:SetImage( Menu.Image )
	AdvTab:AddSheet( "Wallhack", Page2, "gui/silkicons/group", false, false, "Wallhack configuration" )

	local WallhackToggle = vgui.Create( "DCheckBoxLabel", Page2 )
	WallhackToggle:SetPos( 10, 10 )
	WallhackToggle:SetText( "Wallhack" )
	WallhackToggle:SetValue( WallhackSwitch:GetInt() )
	WallhackToggle:SetConVar( WallhackSwitch:GetName() )
	WallhackToggle:SizeToContents()
	
	local ESPToggle = vgui.Create( "DCheckBoxLabel", Page2 )
	ESPToggle:SetPos( 10, 40 )
	ESPToggle:SetText( "ESP" )
	ESPToggle:SetValue( ESPSwitch:GetInt() )
	ESPToggle:SetConVar( ESPSwitch:GetName() )
	ESPToggle:SizeToContents()

	local HealthToggle = vgui.Create( "DCheckBoxLabel", Page2 )
	HealthToggle:SetPos( 30, 70 )
	HealthToggle:SetText( "Show health")
	HealthToggle:SetValue( HealthSwitch:GetInt() )
	HealthToggle:SetConVar( HealthSwitch:GetName() )
	HealthToggle:SizeToContents()

	local WeaponToggle = vgui.Create( "DCheckBoxLabel", Page2 )
	WeaponToggle:SetPos( 30, 100 )
	WeaponToggle:SetText( "Show weapon" )
	WeaponToggle:SetValue( WeaponSwitch:GetInt() )
	WeaponToggle:SetConVar( WeaponSwitch:GetName() )
	WeaponToggle:SizeToContents()

	local UsergroupToggle = vgui.Create( "DCheckBoxLabel", Page2 )
	UsergroupToggle:SetPos( 30, 130 )
	UsergroupToggle:SetText( "Show usergroup" )
	UsergroupToggle:SetValue( UsergroupSwitch:GetInt() )
	UsergroupToggle:SetConVar( UsergroupSwitch:GetName() )
	UsergroupToggle:SizeToContents()
	
	local DeadToggle = vgui.Create( "DCheckBoxLabel", Page2 )
	DeadToggle:SetPos( 30, 160 )
	DeadToggle:SetText( "Show dead players" )
	DeadToggle:SetValue( DeadSwitch:GetInt() )
	DeadToggle:SetConVar( DeadSwitch:GetName() )
	DeadToggle:SizeToContents()

	ESPToggle.OnChange = function()
		HealthToggle:SetDisabled( !ESPSwitch:GetBool() )
		WeaponToggle:SetDisabled( !ESPSwitch:GetBool() )
		UsergroupToggle:SetDisabled( !ESPSwitch:GetBool() )
		DeadToggle:SetDisabled( !ESPSwitch:GetBool() )
	end

	local CrosshairToggle = vgui.Create( "DCheckBoxLabel", Page2 )
	CrosshairToggle:SetPos( 10, 190 )
	CrosshairToggle:SetText( "Draw crosshair" )
	CrosshairToggle:SetValue( CrosshairSwitch:GetInt() )
	CrosshairToggle:SetConVar( CrosshairSwitch:GetName() )
	CrosshairToggle:SizeToContents()
	
	local DarkrpToggle = vgui.Create( "DCheckBoxLabel", Page2 )
	DarkrpToggle:SetPos( 10, 220 )
	DarkrpToggle:SetText( "DarkRP Entities" )
	DarkrpToggle:SetValue( DarkrpSwitch:GetInt() )
	DarkrpToggle:SetConVar( DarkrpSwitch:GetName() )
	DarkrpToggle:SizeToContents()
	
	local Page3 = vgui.Create( "DImage" )
	Page3:SetImage( Menu.Image )
	AdvTab:AddSheet( "Notify", Page3, "gui/silkicons/world", false, false, "Notify settings" )
	
	local LoadedToggle = vgui.Create( "DCheckBoxLabel", Page3 )
	LoadedToggle:SetPos( 10, 10 )
	LoadedToggle:SetText( "Notify when loaded" )
	LoadedToggle:SetValue( LoadedSwitch:GetInt() )
	LoadedToggle:SetConVar( LoadedSwitch:GetName() )
	LoadedToggle:SizeToContents()
	
	local UpdateToggle = vgui.Create( "DCheckBoxLabel", Page3 )
	UpdateToggle:SetPos( 10, 40 )
	UpdateToggle:SetText( "Notify new updates" )
	UpdateToggle:SetValue( UpdateSwitch:GetInt() )
	UpdateToggle:SetConVar( UpdateSwitch:GetName() )
	UpdateToggle:SizeToContents()
	
	local UpdateButton = vgui.Create( "DButton", Page3 )
	UpdateButton:SetPos( 140, 80 )
	UpdateButton:SetSize( 100, 40 )
	UpdateButton:SetText( "Check for updates" )

	UpdateButton.DoClick = function()
		CheckUpdates()
	end
	
end )

concommand.Add( "-trooperhack_menu", function()

	Menu.Main:Remove()

end )
