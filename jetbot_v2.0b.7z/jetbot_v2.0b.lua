-- JetBot [v2]
--     by JetBoom

local MySelf = NULL
hook.Add("Think", "GGetLocal", function()
	MySelf = LocalPlayer()
	if MySelf:IsValid() then
		hook.Remove("Think", "GGetLocal")
	end
end)

-- true = all concommands are randomized. The console command prefix will be printed to the top left of your screen.
-- Once you have the prefix, put that before all jetbot related console commands (except for +aimbot_scan, wich will be +prefix_aimbot_scan)
local ANTIANTICHEAT = true

local safeeyeangles = _R["Player"].SetEyeAngles

-- Clientside aimbot and esp for GMod10.

-- These are the default settings. Most are saved when you leave a server.

-- Aimbot on/off.
local AIMBOT_ON = false
-- Only target players.
local AIMBOT_PLAYERSONLY = true
-- Only target people who aren't on your team.
local AIMBOT_ENEMYSONLY = false
-- ESP on/off.
local ESP_ON = false
-- Default offset to use. This shoots people in the chest area.
local AIMBOT_OFFSET = Vector(0,0,45)
-- Aim for the head when target is a player. (ignore offsets)
local AIMBOT_HEADSHOTS = true
-- Suicide health threshold. This is the health needed before you suicide.
local SUICIDE_HEALTH = 0
-- ESP will display everything.
local ESP_EVERYTHING = false
-- ESP will color by team instead of friendly / enemy.
local ESP_COLORBYTEAM = false

-- I've tested it and this seems to be the best I can get. Your ping also plays
-- a factor in lag compensation calculations so you shouldn't have to change this.
local AIMBOT_LAGCOMPENSATION = 0.0007

local OFFSETPRESETS = {}
--OFFSETPRESETS["headshot"] = 55 -- I need to add in some side offsets because the head is hunched.
OFFSETPRESETS["chest"] = 45
OFFSETPRESETS["none"] = 0


--  |             |
-- \|/ Core code \|/

local AIMBOT_SCANNING = false
local AIMBOT_HEADOFFSET = Vector(0,0,58.5)
local AIMBOT_HEADOFFSET_CROUCHING = Vector(0,0,34)
surface.CreateFont( "arial", 14, 400, true, false, "AimBotSmall" )
surface.CreateFont( "coolvetica", 24, 500, true, false, "AimBotBig" )

local AIMBOT_TARGET

local COLOR_FRIENDLY = Color(0, 255, 0, 255)
local COLOR_ENEMY = Color(255, 0, 0, 255)
local COLOR_DEAD = Color(40, 40, 40, 255)
local COLOR_TRACKING = Color(255, 0, 255, 255)
local COLOR_OBJECT = Color(255, 255, 255, 255)

if not ConVarExists("_esp_colorbyname") then
	CreateClientConVar("_esp", 1, true, false)
	CreateClientConVar("_aimbot", 1, true, false)
	CreateClientConVar("_aimbot_headshots", 1, true, false)
	CreateClientConVar("_aimbot_enemysonly", 0, true, false)
	CreateClientConVar("_aimbot_playersonly", 1, true, false)
	CreateClientConVar("_aimbot_lagcompensation", AIMBOT_LAGCOMPENSATION, true, false)
	CreateClientConVar("_aimbot_suicidehealth", SUICIDE_HEALTH, true, false)
	CreateClientConVar("_aimbot_offset", AIMBOT_OFFSET.z, true, false)
	CreateClientConVar("_esp_everything", 0, true, false)
	CreateClientConVar("_esp_colorbyteam", 0, true, false)
end

ESP_ON = util.tobool(GetConVarNumber("_esp"))
AIMBOT_ON = util.tobool(GetConVarNumber("_aimbot"))
AIMBOT_HEADSHOTS = util.tobool(GetConVarNumber("_aimbot_headshots"))
AIMBOT_ENEMYSONLY = util.tobool(GetConVarNumber("_aimbot_enemysonly"))
AIMBOT_PLAYERSONLY = util.tobool(GetConVarNumber("_aimbot_playersonly"))
AIMBOT_LAGCOMPENSATION = GetConVarNumber("_aimbot_lagcompensation")
SUICIDE_HEALTH = GetConVarNumber("_aimbot_suicidehealth")
ESP_EVERYTHING = util.tobool(GetConVarNumber("_esp_everything"))
ESP_COLORBYTEAM = util.tobool(GetConVarNumber("_esp_colorbyteam"))

local function AddBotNotify(msg, typ, length)
	MySelf:ChatPrint(msg)
end

local function ESP_On(sender, command, arguments)
	AddBotNotify( "ESP on!!", NOTIFY_HINT, 6 )
	ESP_ON = true
	RunConsoleCommand("_esp", "1")
end

local function ESP_Off(sender, command, arguments)
	AddBotNotify( "ESP off!!", NOTIFY_HINT, 6 )
	ESP_ON = false
	RunConsoleCommand("_esp", "0")
end

local function AimBot_Off(sender, command, arguments)
	AddBotNotify( "Aimbot off!!", NOTIFY_HINT, 6 )
	AIMBOT_ON = false
	AIMBOT_SCANNING = false
	RunConsoleCommand("_aimbot", "0")
end

local function AimBot_On(sender, command, arguments)
	AddBotNotify( "Aimbot on!!", NOTIFY_HINT, 6 )
	AIMBOT_ON = true
	RunConsoleCommand("_aimbot", "1")
end

local function AimBot_HeadShotsOff(sender, command, arguments)
	AddBotNotify("Headshots off!!", NOTIFY_HINT, 6)
	AIMBOT_HEADSHOTS = false
	RunConsoleCommand("_aimbot_headshots", "0")
end

local function AimBot_HeadShotsOn(sender, command, arguments)
	AddBotNotify("Headshots on!!", NOTIFY_HINT, 6)
	AIMBOT_HEADSHOTS = true
	RunConsoleCommand("_aimbot_headshots", "1")
end

local function AimBot_EnemysOnly_On(sender, command, arguments)
	AddBotNotify( "Targeting enemys only!!", NOTIFY_HINT, 6 )
	AIMBOT_ENEMYSONLY = true
	RunConsoleCommand("_aimbot_enemysonly", "1")
end

local function AimBot_EnemysOnly_Off(sender, command, arguments)
	AddBotNotify( "Targeting friendlies and enemies!!", NOTIFY_HINT, 6 )
	AIMBOT_ENEMYSONLY = false
	RunConsoleCommand("_aimbot_enemysonly", "0")
end

local function ESP_Everything_On(sender, command, arguments)
	AddBotNotify("I see everything...", NOTIFY_HINT, 6)
	ESP_EVERYTHING = true
	RunConsoleCommand("_esp_everything", "1")
end

local function ESP_Everything_Off(sender, command, arguments)
	AddBotNotify("Seeing less than before.", NOTIFY_HINT, 6)
	ESP_EVERYTHING = false
	RunConsoleCommand("_esp_everything", "0")
end

local function ESP_ColorByTeam_On(sender, command, arguments)
	AddBotNotify("Color by team: ON.", NOTIFY_HINT, 6)
	ESP_COLORBYTEAM = true
	RunConsoleCommand("_esp_colorbyteam", "1")
end

local function ESP_ColorByTeam_Off(sender, command, arguments)
	AddBotNotify("Color by team OFF.", NOTIFY_HINT, 6)
	ESP_COLORBYTEAM = false
	RunConsoleCommand("_esp_colorbyteam", "0")
end

local function AimBot_PlayersOnly_On(sender, command, arguments)
	AddBotNotify( "Targeting players!!", NOTIFY_HINT, 6 )
	AIMBOT_PLAYERSONLY = true
	RunConsoleCommand("_aimbot_playersonly", "1")
end

local function AimBot_PlayersOnly_Off(sender, command, arguments)
	AddBotNotify( "Targeting everything!!", NOTIFY_HINT, 6 )
	AIMBOT_PLAYERSONLY = false
	RunConsoleCommand("_aimbot_playersonly", "0")
end

local function AimBot_SetLagCompensation(sender, command, arguments)
	if arguments[1] == nil then AddBotNotify( "Lag Compensation is currently "..AIMBOT_LAGCOMPENSATION.."!!", NOTIFY_HINT, 6 ) return end
	if tonumber(arguments[1]) == nil then
		AddBotNotify( "Not a number!", NOTIFY_ERROR, 6 )
		return
	end
	AIMBOT_LAGCOMPENSATION = math.Clamp(tonumber(arguments[1]), 0, 2)
	AddBotNotify("Lag Compensation changed to "..AIMBOT_LAGCOMPENSATION.."!!", NOTIFY_HINT, 6)
	RunConsoleCommand("_aimbot_lagcompensation", AIMBOT_LAGCOMPENSATION)
end

local function AimBot_SetSuicideHealth(sender, command, arguments)
	if arguments[1] == nil then AddBotNotify( "Suicide health is currently "..SUICIDE_HEALTH.."!!", NOTIFY_HINT, 6 ) return end
	if tonumber(arguments[1]) == nil then
		AddBotNotify( "Not a number!", NOTIFY_ERROR, 6 )
		return
	end
	SUICIDE_HEALTH = tonumber(arguments[1])
	AddBotNotify("Suicide health changed to "..SUICIDE_HEALTH.."!!", NOTIFY_HINT, 6)
	RunConsoleCommand("_aimbot_suicidehealth", SUICIDE_HEALTH)
end

local function AimBot_SetOffset(sender, command, arguments)
	if arguments[1] == nil then AddBotNotify( "Offset is currently "..AIMBOT_OFFSET.z.."!!", NOTIFY_HINT, 6 ) return end
	if tonumber(arguments[1]) == nil then
	    if OFFSETPRESETS[arguments[1] ] then
	        AIMBOT_OFFSET = Vector(0,0, OFFSETPRESETS[arguments[1] ])
			AddBotNotify( "Offset changed to "..AIMBOT_OFFSET.z.."!!", NOTIFY_HINT, 6 )
			return
	    else
			AddBotNotify( "Offset is not a number!", NOTIFY_ERROR, 6 )
			return
		end
	end
	AIMBOT_OFFSET = Vector(0,0, math.Clamp(tonumber(arguments[1]), -512, 512))
	AddBotNotify("Offset changed to "..AIMBOT_OFFSET.z.."!!", NOTIFY_HINT, 6)
	RunConsoleCommand("_aimbot_offset", AIMBOT_OFFSET.z)
end

local function AimBot_ScanOn(sender, command, arguments)
	AIMBOT_SCANNING = true
end

local function AimBot_ScanOff(sender, command, arguments)
	AIMBOT_SCANNING = false
	AIMBOT_TARGET = nil
end

local NextSpam = 0
local SpamPlus = false

local function DoorSpam()
	if RealTime() < NextSpam then return end
	if not MySelf:IsValid() or not MySelf:Alive() then return end

	if SpamPlus then
		RunConsoleCommand("+use")
	else
		RunConsoleCommand("-use")
	end

	SpamPlus = not SpamPlus
	NextSpam = RealTime() + 0.05
end

local function DoorSpam_On(sender, command, arguments)
	SpamPlus = true
	NextSpam = 0
	hook.Add("Think", "DoorSpam", DoorSpam)
end

local function DoorSpam_Off(sender, command, arguments)
	hook.Remove("Think", "DoorSpam")
	RunConsoleCommand("-use")
end

local function GetTargetPos(ent)
	if ent:IsPlayer() then
		local attach = ent:GetAttachment(1)
		if AIMBOT_HEADSHOTS and attach then
			return attach.Pos + ent:GetAngles():Forward() * -4
		else
			if ent:Crouching() then
				return ent:GetPos() + (AIMBOT_OFFSET * 0.586)
			else
				return ent:GetPos() + AIMBOT_OFFSET
			end
		end
	else
		return ent:GetPos() + AIMBOT_OFFSET
	end
end

local LAST_SUICIDE = CurTime()

local function DoESPEnt(ent)
	local pos = ent:GetPos()
	pos = pos:ToScreen()
	if pos.visible then
		local mypos = MySelf:GetPos()
		local size = ScrW() * 0.02
		if AIMBOT_TARGET and ent == AIMBOT_TARGET then
			// Nothing
		else
			surface.SetDrawColor(0, 255, 0, 255)
			surface.DrawLine( pos.x - size, pos.y, pos.x + size, pos.y )
			surface.DrawLine( pos.x, pos.y - size, pos.x, pos.y + size)
			draw.SimpleText("< "..ent:GetClass().." >", "AimBotBig", pos.x, pos.y + size + 10, COLOR_ENEMY, TEXT_ALIGN_CENTER)
			draw.SimpleText("Health: "..ent:Health(), "AimBotSmall", pos.x, pos.y + size + 30, COLOR_OBJECT, TEXT_ALIGN_LEFT)
			draw.SimpleText("Dist: "..math.floor(ent:GetPos():Distance(mypos)), "AimBotSmall", pos.x, pos.y + size + 42, COLOR_OBJECT, TEXT_ALIGN_LEFT)
		end
	end
end

local function DoESPPlayer(pl)
	if pl == MySelf then
		-- DO NOTHING
	elseif pl:Alive() then
		local pos = GetTargetPos(pl)
		pos = pos:ToScreen()
		if pos.visible then
			local mypos = MySelf:GetPos()
			local size = ScrW() * 0.02
			if not (AIMBOT_TARGET and pl == AIMBOT_TARGET) then
				local colortouse = COLOR_FRIENDLY

				if ESP_COLORBYTEAM then
					colortouse = team.GetColor(pl:Team())
				elseif pl:Team() ~= MySelf:Team() then
					colortouse = COLOR_ENEMY
				end

				surface.SetDrawColor(colortouse.r, colortouse.g, colortouse.b, 255)
				surface.DrawLine(pos.x - size, pos.y, pos.x + size, pos.y)
				surface.DrawLine(pos.x, pos.y - size, pos.x, pos.y + size)
				draw.DrawText(pl:Name(), "AimBotBig", pos.x, pos.y + size + 10, colortouse, TEXT_ALIGN_CENTER)
				draw.DrawText("HP: "..pl:Health(), "AimBotSmall", pos.x, pos.y + size + 30, colortouse, TEXT_ALIGN_LEFT)
				draw.DrawText("Dist: "..math.floor(pl:GetPos():Distance(mypos)), "AimBotSmall", pos.x, pos.y + size + 42, colortouse, TEXT_ALIGN_LEFT)
				draw.DrawText("Group: "..pl:GetNetworkedString("usergroup", "none"), "AimBotSmall", pos.x, pos.y + size + 54, colortouse, TEXT_ALIGN_LEFT)
				local wep = pl:GetActiveWeapon()
				if wep:IsValid() then
					draw.DrawText("Weapon: "..wep:GetClass().." ("..wep:EntIndex()..")", "AimBotSmall", pos.x, pos.y + size + 66, colortouse, TEXT_ALIGN_LEFT)
				else
					draw.DrawText("Unarmed", "AimBotSmall", pos.x, pos.y + size + 66, colortouse, TEXT_ALIGN_LEFT)
				end
			end
		end
	else
	    local pos = GetTargetPos(pl):ToScreen()
		if pos.visible then
			local mypos = MySelf:GetPos()
			local size = ScrW() * 0.02
			surface.SetDrawColor(0, 0, 0, 255)
			surface.DrawLine(pos.x - size, pos.y, pos.x + size, pos.y)
			surface.DrawLine(pos.x, pos.y - size, pos.x, pos.y + size)
			draw.SimpleText(pl:Name(), "AimBotBig", pos.x, pos.y + size + 10, COLOR_DEAD, TEXT_ALIGN_CENTER)
			draw.SimpleText("** DEAD **", "AimBotSmall", pos.x, pos.y + size + 30, COLOR_DEAD, TEXT_ALIGN_CENTER)
			draw.SimpleText("Dist: "..math.floor(pl:GetPos():Distance(mypos)), "AimBotSmall", pos.x, pos.y + size + 42, COLOR_DEAD, TEXT_ALIGN_LEFT)
		end
	end
end

local function DoAimBot()
	if not MySelf:IsValid() then return end

	if PREFIX then
		draw.SimpleText("Your JetBot concommand prefix: "..PREFIX, "DefaultSmall", ScrW() - 8, ScrH() * 0.5, COLOR_ENEMY, TEXT_ALIGN_RIGHT)
	end

	if ESP_ON then
	    draw.SimpleText("ESP", "AimBotBig", ScrW() * 0.5, ScrH() * 0.01, COLOR_ENEMY, TEXT_ALIGN_CENTER)
		if ESP_EVERYTHING then
			for _, ent in pairs(ents.GetAll()) do
				if ent:IsValid() then
					if ent:IsPlayer() then
						DoESPPlayer(ent)
					else
						DoESPEnt(ent)
					end
				end
			end
		else
			for _, pl in pairs(player.GetAll()) do
				DoESPPlayer(pl)
			end
		end
	end

	if not MySelf:Alive() then return end

	if MySelf:Health() <= SUICIDE_HEALTH then
		if CurTime() > LAST_SUICIDE + 0.5 and MySelf:Health() > 0 then
			RunConsoleCommand("kill")
			AddBotNotify("Committing Suicide", NOTIFY_ERROR, 6)
			LAST_SUICIDE = CurTime()
		end
	end

	if AIMBOT_ON then
		if AIMBOT_TARGET and AIMBOT_TARGET ~= nil and AIMBOT_TARGET:IsValid() then
			local wpos = GetTargetPos(AIMBOT_TARGET)
			local pos = wpos:ToScreen()
			local size = ScrW() * 0.018
			if AIMBOT_LAGCOMPENSATION > 0 then
				local velocity = AIMBOT_TARGET:GetVelocity() or Vector(0,0,0)
				safeeyeangles(MySelf, ((wpos + velocity * (AIMBOT_LAGCOMPENSATION * MySelf:Ping() * FrameTime())) - MySelf:GetShootPos()):Angle())
				local ppos = ((wpos + velocity * (AIMBOT_LAGCOMPENSATION * MySelf:Ping() * FrameTime()))):ToScreen()
				surface.SetDrawColor(255, 255, 0, 255)
				surface.DrawLine( ppos.x - size, ppos.y, ppos.x + size, ppos.y )
				surface.DrawLine( ppos.x, ppos.y - size, ppos.x, ppos.y + size)
			else
				safeeyeangles(MySelf, (wpos - MySelf:GetShootPos()):Angle())
			end
			surface.SetDrawColor(255, 0, 255, 255)
		    surface.DrawLine( pos.x - size, pos.y, pos.x + size, pos.y )
			surface.DrawLine( pos.x, pos.y - size, pos.x, pos.y + size)
			if AIMBOT_TARGET:IsPlayer() then
				if AIMBOT_TARGET:Alive() then
					draw.SimpleText(AIMBOT_TARGET:Name(), "AimBotBig", pos.x, pos.y + size + 10, COLOR_TRACKING, TEXT_ALIGN_CENTER)
					draw.SimpleText("HP: "..AIMBOT_TARGET:Health(), "AimBotSmall", pos.x, pos.y + size + 30, COLOR_TRACKING, TEXT_ALIGN_LEFT)
					draw.SimpleText("Dist: "..math.floor(AIMBOT_TARGET:GetPos():Distance(MySelf:GetPos())), "AimBotSmall", pos.x, pos.y + size + 42, COLOR_TRACKING, TEXT_ALIGN_LEFT)
				else
					AddBotNotify("pwned "..AIMBOT_TARGET:Name(), NOTIFY_CLEANUP, 3)
					surface.PlaySound("buttons/blip1.wav")
					AIMBOT_TARGET = nil
				end
			else
				draw.SimpleText(tostring(AIMBOT_TARGET), "AimBotBig", pos.x, pos.y + size + 10, COLOR_TRACKING, TEXT_ALIGN_CENTER)
				draw.SimpleText("Dist: "..math.floor(AIMBOT_TARGET:GetPos():Distance(MySelf:GetPos())), "AimBotSmall", pos.x, pos.y + size + 30, COLOR_TRACKING, TEXT_ALIGN_LEFT)
			end
		else
			if AIMBOT_SCANNING then
				draw.SimpleText("Scanning...", "AimBotBig", ScrW() * 0.5, ScrH() * 0.6, COLOR_ENEMY, TEXT_ALIGN_CENTER)
				local tr = utilx.GetPlayerTrace(MySelf, MySelf:GetCursorAimVector())
				local trace = util.TraceLine(tr)
				if trace.Hit and trace.HitNonWorld then
					local entity = trace.Entity
					if AIMBOT_PLAYERSONLY then
						if entity:IsValid() and entity:GetPos() then
							if entity:IsPlayer() then
								if entity:Team() ~= MySelf:Team() or not AIMBOT_ENEMYSONLY then
									AIMBOT_TARGET = entity
									AIMBOT_SCANNING = false
								end
							end
						end
					else
						if entity:IsValid() and entity:GetPos() then
							if entity:IsPlayer() then
								if entity:Team() ~= MySelf:Team() or not AIMBOT_ENEMYSONLY then
									AIMBOT_TARGET = entity
									AIMBOT_SCANNING = false
								end
							else
								AIMBOT_TARGET = entity
								AIMBOT_SCANNING = false
							end
						end
					end
				end
			else
				AIMBOT_TARGET = nil
			end
		end
	end
end
if PREFIX then
	hook.Add("HUDPaint", PREFIX..string.char(math.random(97, 122)), DoAimBot)
else
	hook.Add("HUDPaint", "AIMBOT", DoAimBot)
end

local SpazHookName
if PREFIX then
	SpazHookName = PREFIX.."s"
else
	SpazHookName = "Spaz"
end

local function SpazOn()
	hook.Add("CreateMove", SpazHookName, function(cmd)
		cmd:SetViewAngles(cmd:GetViewAngles() * -1)
		return cmd
	end)
end

local function SpazOff()
	hook.Remove("CreateMove", SpazHookName)
end

local function PrintAllEnts()
	PrintTable(ents.GetAll())
end

local function PrintEntTable(sender, command, arguments)
	PrintTable(Entity(tonumber(arguments[1])):GetTable())
end

local function EntSetValue(sender, command, arguments)
	Entity(tonumber(arguments[1])):GetTable()[ arguments[2] ] = arguments[3]
end

local function EntRunNone(sender, command, arguments)
	local ent = Entity(tonumber(arguments[1]))
	ent[ arguments[2] ](ent)
end

local function EntRun(sender, command, arguments)
	local ent = Entity(tonumber(arguments[1]))
	ent[ arguments[2] ](ent, arguments[3])
end

local function EntRunTwo(sender, command, arguments)
	local ent = Entity(tonumber(arguments[1]))
	ent[ arguments[2] ](ent, arguments[3], arguments[4])
end

local function EntRunThree(sender, command, arguments)
	local ent = Entity(tonumber(arguments[1]))
	ent[ arguments[2] ](ent, arguments[3], arguments[4], arguments[5])
end

local function EntRunFour(sender, command, arguments)
	local ent = Entity(tonumber(arguments[1]))
	ent[ arguments[2] ](ent, arguments[3], arguments[4], arguments[5], arguments[6])
end

local function GetEnt(sender, command, arguments)
	local tr = util.TraceLine(utilx.GetPlayerTrace(MySelf, MySelf:GetAimVector()))
	if tr.Entity then
		print(tostring(tr.Entity))
	end
end

local function CamEnable()
	MY_VIEW = MySelf:GetAimVector()
	CAM_POS = MySelf:EyePos()
	CAM_ANG = MySelf:GetAimVector()

	local HookNamea
	if PREFIX then
		HookNamea = PREFIX.."a"
	else
		HookNamea = "CamStopMove"
	end

	hook.Add("CreateMove", HookNamea, function(cmd)
		cmd:SetForwardMove(0)
		cmd:SetUpMove(0)
		cmd:SetSideMove(0)
		return cmd
	end)

	local HookNamet
	if PREFIX then
		HookNamet = PREFIX.."t"
	else
		HookNamet = "CamCalcView"
	end

	hook.Add("CalcView", HookNamet, function(ply, origin, angles, fov)
		angles = angles:Forward()
		local masktouse = COLLISION_GROUP_WORLD
		if MySelf:KeyDown(IN_FORWARD) then
			local tr = util.TraceLine({start = CAM_POS, endpos = CAM_POS + angles * FrameTime() * 200, mask=masktouse})
			CAM_POS = tr.HitPos
		end
		if MySelf:KeyDown(IN_BACK) then
			local tr = util.TraceLine({start = CAM_POS, endpos = CAM_POS + angles * FrameTime() * -200, mask=masktouse})
			CAM_POS = tr.HitPos
		end
		if MySelf:KeyDown(IN_MOVELEFT) then
			local tr = util.TraceLine({start = CAM_POS, endpos = CAM_POS + angles:Angle():Right() * FrameTime() * -200, mask=masktouse})
			CAM_POS = tr.HitPos
		end
		if MySelf:KeyDown(IN_MOVERIGHT) then
			local tr = util.TraceLine({start = CAM_POS, endpos = CAM_POS + angles:Angle():Right() * FrameTime() * 200, mask=masktouse})
			CAM_POS = tr.HitPos
		end

		local view = {}
		view.origin = CAM_POS
		view.angles = angles:Angle()
		view.fov = fov

		return view
	end)
end

local function CamDisable()
	if PREFIX then
		hook.Remove("CreateMove", PREFIX.."a")
		hook.Remove("CalcView", PREFIX.."t")
	else
		hook.Remove("CreateMove", "CamStopMove")
		hook.Remove("CalcView", "CamCalcView")
	end
end

local dotele = false
hook.Add("Move", "Teleportin", function(pl, move)
	if dotele then
		move:SetOrigin(pl:GetEyeTrace().HitPos)
		dotele = false
		return true
	end
end)

local function Teleportin()
	dotele = true
end

local function JetBotpcall(sender, command, arguments)
	_G[ arguments[1] ](unpack(arguments, 2))
end

if PREFIX then
	concommand.Add(PREFIX.."_aimbot_headshots_on", AimBot_HeadShotsOn)
	concommand.Add(PREFIX.."_aimbot_headshots_off", AimBot_HeadShotsOff)
	concommand.Add(PREFIX.."_aimbot_on", AimBot_On)
	concommand.Add(PREFIX.."_aimbot_off", AimBot_Off)
	concommand.Add(PREFIX.."_esp_on", ESP_On)
	concommand.Add(PREFIX.."_esp_off", ESP_Off)
	concommand.Add(PREFIX.."_aimbot_enemysonly_on", AimBot_EnemysOnly_On)
	concommand.Add(PREFIX.."_aimbot_enemysonly_off", AimBot_EnemysOnly_Off)
	concommand.Add(PREFIX.."_esp_everything_on", ESP_Everything_On)
	concommand.Add(PREFIX.."_esp_everything_off", ESP_Everything_Off)
	concommand.Add(PREFIX.."_esp_colorbyteam_on", ESP_ColorByTeam_On)
	concommand.Add(PREFIX.."_esp_colorbyteam_off", ESP_ColorByTeam_Off)
	concommand.Add(PREFIX.."_aimbot_playersonly_on", AimBot_PlayersOnly_On)
	concommand.Add(PREFIX.."_aimbot_playersonly_off", AimBot_PlayersOnly_Off)
	concommand.Add(PREFIX.."_entx_pcall", JetBotpcall)
	concommand.Add(PREFIX.."_entx_camdisable", CamDisable)
	concommand.Add(PREFIX.."_entx_camenable", CamEnable)
	concommand.Add(PREFIX.."_entx_traceget", GetEnt)
	concommand.Add(PREFIX.."_entx_run4", EntRunFour)
	concommand.Add(PREFIX.."_entx_run3", EntRunThree)
	concommand.Add(PREFIX.."_entx_run2", EntRunTwo)
	concommand.Add(PREFIX.."_entx_run1", EntRun)
	concommand.Add(PREFIX.."_entx_run", EntRunNone)
	concommand.Add(PREFIX.."_entx_setvalue", EntSetValue)
	concommand.Add(PREFIX.."_entx_printallents", PrintAllEnts)
	concommand.Add(PREFIX.."_entx_printenttable", PrintEntTable)
	concommand.Add(PREFIX.."_entx_spazoff", SpazOff)
	concommand.Add(PREFIX.."_entx_spazon", SpazOn)
	concommand.Add(PREFIX.."_teleport", Teleportin)
	concommand.Add("+"..PREFIX.."_aimbot_scan", AimBot_ScanOn)
	concommand.Add("-"..PREFIX.."_aimbot_scan", AimBot_ScanOff)
	concommand.Add("+"..PREFIX.."_doorspam", DoorSpam_On)
	concommand.Add("-"..PREFIX.."_doorspam", DoorSpam_Off)
	concommand.Add(PREFIX.."_aimbot_suicidehealth", AimBot_SetSuicideHealth)
	concommand.Add(PREFIX.."_aimbot_lagcompensation", AimBot_SetLagCompensation)
	concommand.Add(PREFIX.."_aimbot_offset", AimBot_SetOffset)
else
	concommand.Add("aimbot_headshots_on", AimBot_HeadShotsOn)
	concommand.Add("aimbot_headshots_off", AimBot_HeadShotsOff)
	concommand.Add("aimbot_on", AimBot_On)
	concommand.Add("aimbot_off", AimBot_Off)
	concommand.Add("esp_on", ESP_On)
	concommand.Add("esp_off", ESP_Off)
	concommand.Add("aimbot_enemysonly_on", AimBot_EnemysOnly_On)
	concommand.Add("aimbot_enemysonly_off", AimBot_EnemysOnly_Off)
	concommand.Add("esp_everything_on", ESP_Everything_On)
	concommand.Add("esp_everything_off", ESP_Everything_Off)
	concommand.Add("esp_colorbyteam_on", ESP_ColorByTeam_On)
	concommand.Add("esp_colorbyteam_off", ESP_ColorByTeam_Off)
	concommand.Add("aimbot_playersonly_on", AimBot_PlayersOnly_On)
	concommand.Add("aimbot_playersonly_off", AimBot_PlayersOnly_Off)
	concommand.Add("entx_pcall", JetBotpcall)
	concommand.Add("entx_camdisable", CamDisable)
	concommand.Add("entx_camenable", CamEnable)
	concommand.Add("entx_traceget", GetEnt)
	concommand.Add("entx_run4", EntRunFour)
	concommand.Add("entx_run3", EntRunThree)
	concommand.Add("entx_run2", EntRunTwo)
	concommand.Add("entx_run1", EntRun)
	concommand.Add("entx_run", EntRunNone)
	concommand.Add("entx_setvalue", EntSetValue)
	concommand.Add("entx_printallents", PrintAllEnts)
	concommand.Add("teleport", Teleportin)
	concommand.Add("entx_printenttable", PrintEntTable)
	concommand.Add("entx_spazoff", SpazOff)
	concommand.Add("entx_spazon", SpazOn)
	concommand.Add("+aimbot_scan", AimBot_ScanOn)
	concommand.Add("-aimbot_scan", AimBot_ScanOff)
	concommand.Add("+doorspam", DoorSpam_On)
	concommand.Add("-doorspam", DoorSpam_Off)
	concommand.Add("aimbot_suicidehealth", AimBot_SetSuicideHealth)
	concommand.Add("aimbot_lagcompensation", AimBot_SetLagCompensation)
	concommand.Add("aimbot_offset", AimBot_SetOffset)
end

local oldcreateclientconvar = CreateClientConVar
function CreateClientConVar(a,b,c,d,e)
	if a ~= "ai_test_los" then
		oldcreateclientconvar(a,b,c,d,e)
	end
end
