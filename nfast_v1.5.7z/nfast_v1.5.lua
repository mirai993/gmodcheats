local hook = hook
local derma = derma
local surface = surface
local vgui = vgui
local input = input
local util = util
local cam = cam
local render = render
local math = math
local draw = draw
local team = team
local timer = timer
local _G                                        = table.Copy( _G )
local _R                                        = _G.debug.getregistry()
local math                                      = _G.math
local string                            = _G.string
local hook                                      = _G.hook
local table                             = _G.table
local timer                             = _G.timer
local surface                           = _G.surface
local concommand                        = _G.concommand
local cvars                             = _G.cvars
local ents                                      = _G.ents
local player                            = _G.player
local team                                      = _G.team
local util                                      = _G.util
local draw                                      = _G.draw
local usermessage                       = _G.usermessage
local vgui                                      = _G.vgui
local http                                      = _G.http
local cam                                       = _G.cam
local render                            = _G.render
local MsgN                                      = _G.MsgN
local Msg                                       = _G.Msg
local Vector                            = _G.Vector
local Angle                             = _G.Angle
local pairs                             = _G.pairs
local ipairs                            = _G.ipairs
local CreateSound                       = _G.CreateSound
local setmetatable                      = _G.setmetatable
local Sound                             = _G.Sound
local print                             = _G.print
local pcall                             = _G.pcall
local type                                      = _G.type
local LocalPlayer                       = _G.LocalPlayer
local KeyValuesToTable          = _G.KeyValuesToTable
local TableToKeyValues          = _G.TableToKeyValues
local Color                             = _G.Color
 
local NFast = {}
NFast.Active = CreateClientConVar("NFast_Active", 1, true, false)
NFast.Version = "1.5.0"
NFast.Ply = LocalPlayer()
NFast.TTT = (GAMEMODE and GAMEMODE.Name and string.find(GAMEMODE.Name, "Terror") and true) or false
if NFast.TTT then NFast.TTTCORPSE = CORPSE end
NFast.DarkRP = (GAMEMODE and GAMEMODE.Name and string.find(GAMEMODE.Name, "DarkRP") and true) or false
 
//Converts a string of a color (ex. "Color(255, 255, 255, 255)") into an actual color, and returns the color.
NFast.GetColorFromString = function(words)
        //I probably shouldve just used string.explode...well.......
        if type(words) != "string" then return Color(255, 255, 255, 255) end
        words = "return "..words
        local func = CompileString(words, "GettingColors", true)
        local good, color = pcall(func)
        if good and type(color) == "table" and color.r and color.g and color.b and color.a then
                return color
        else
                return Color(255, 255, 255, 255)
        end
end
 
NFast.Chars = {"A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M", "N", "O", "P", "Q", "R", "S", "T", "U", "V", "W", "X", "Y", "Z"}
NFast.RandomName = function(amount)
        local toReturn = ""
        local amount = amount or 10
        for i = 1, amount do
                if math.random(0, 1) == 0 then
                        toReturn = toReturn..string.lower(table.Random(NFast.Chars))
                else
                        toReturn = toReturn..table.Random(NFast.Chars)
                end
        end
        return toReturn
end
 
NFast.Message = function(...)
        chat.AddText(Color(50, 255, 100), "[NFast] ", ...)
end
 
NFast.Aimbot = {}
NFast.Aimbot.CurTarget = nil
NFast.Aimbot.Vars = {}
NFast.Aimbot.Vars["Active"] = CreateClientConVar("NFast_Aimbot_Active", 0, true, false)
NFast.Aimbot.Vars["RandomBones"] = CreateClientConVar("NFast_Aimbot_RandomBones", 0, true, false)
NFast.Aimbot.Vars["AttackNPCs"] = CreateClientConVar("NFast_Aimbot_AttackNPCs", 0, true, false)
NFast.Aimbot.Vars["AttackPlayers"] = CreateClientConVar("NFast_Aimbot_AttackPlayers", 0, true, false)
NFast.Aimbot.Vars["Prediction"] = CreateClientConVar("NFast_Aimbot_Prediction", 0, true, false)
NFast.Aimbot.Vars["AimOnKey"] = CreateClientConVar("NFast_Aimbot_AimOnKey", 0, true, false)
NFast.Aimbot.Vars["AimOnKey_Key"] = CreateClientConVar("NFast_Aimbot_AimOnKey_Key", "MOUSE_LEFT", true, false)
NFast.Aimbot.Vars["MaxAngle"] = CreateClientConVar("NFast_Aimbot_MaxAngle", 180, true, false)
NFast.Aimbot.Vars["Preferance"] = CreateClientConVar("NFast_Aimbot_Preferance", "Distance", true, false)
NFast.Aimbot.Vars["AntiSnap"] = CreateClientConVar("NFast_Aimbot_AntiSnap", 0, true, false)
NFast.Aimbot.Vars["AntiSnapSpeed"] = CreateClientConVar("NFast_Aimbot_AntiSnapSpeed", 4, true, false)
NFast.Aimbot.Vars["AutoShoot"] = CreateClientConVar("NFast_Aimbot_AutoShoot", 0, true, false)
NFast.Aimbot.Vars["PanicMode"] = CreateClientConVar("NFast_Aimbot_PanicMode", 0, true, false)
NFast.Aimbot.Vars["IgnoreTeam"] = CreateClientConVar("NFast_Aimbot_IgnoreTeam", 0, true, false)
 
NFast.Friends = {}
NFast.Friends.List = {} //The steamIDs of everyone on your friends list
NFast.Friends.Vars = {}
NFast.Friends.Vars["Active"] = CreateClientConVar("NFast_Friends_Active", 0, true, false)
NFast.Friends.Vars["Reverse"] = CreateClientConVar("NFast_Friends_Reverse", 0, true, false)
 
NFast.ESP = {}
NFast.ESP.Vars = {}
NFast.ESP.Vars["Active"] = CreateClientConVar("NFast_ESP_Active", 0, true, false)
NFast.ESP.Vars["Players"] = CreateClientConVar("NFast_ESP_Players", 0, true, false)
NFast.ESP.Vars["NPCs"] = CreateClientConVar("NFast_ESP_NPCs", 0, true, false)
NFast.ESP.Vars["Name"] = CreateClientConVar("NFast_ESP_Name", "Off", true, false)
NFast.ESP.Vars["Weapons"] = CreateClientConVar("NFast_ESP_Weapons", "Off", true, false)
NFast.ESP.Vars["Distance"] = CreateClientConVar("NFast_ESP_Distance", "Off", true, false)
NFast.ESP.Vars["Health"] = CreateClientConVar("NFast_ESP_Health", "Off", true, false)
NFast.ESP.Vars["MaxDistance"] = CreateClientConVar("NFast_ESP_MaxDistance", 0, true, false)
NFast.ESP.Vars["Box"] = CreateClientConVar("NFast_ESP_Box", 0, true, false)
NFast.ESP.Vars["ShowTraitors"] = CreateClientConVar("NFast_ESP_ShowTraitors", "Off", true, false)
NFast.ESP.Vars["Bodies"] = CreateClientConVar("NFast_ESP_Bodies", 0, true, false)
NFast.ESP.Vars["Radar"] = CreateClientConVar("NFast_ESP_Radar", 0, true, false)
NFast.ESP.Vars["RadarScale"] = CreateClientConVar("NFast_ESP_RadarScale", 20, true, false)
NFast.ESP.Vars["TeamBased"] = CreateClientConVar("NFast_ESP_TeamBased", 0, true, false)
 
NFast.Chams = {}
NFast.Chams.Mat = CreateMaterial(NFast.RandomName(math.random(10,15)), "VertexLitGeneric", { ["$basetexture"] = "models/debug/debugwhite", ["$model"] = 1, ["$ignorez"] = 1 })
NFast.Chams.Vars = {}
NFast.Chams.Vars["Active"] = CreateClientConVar("NFast_Chams_Active", 0, true, false)
NFast.Chams.Vars["Players"] = CreateClientConVar("NFast_Chams_Players", 0, true, false)
NFast.Chams.Vars["NPCs"] = CreateClientConVar("NFast_Chams_NPCs", 0, true, false)
NFast.Chams.Vars["Weapons"] = CreateClientConVar("NFast_Chams_Weapons", 0, true, false)
NFast.Chams.Vars["MaxDistance"] = CreateClientConVar("NFast_Chams_MaxDistance", 0, true, false)
NFast.Chams.Vars["Bodies"] = CreateClientConVar("NFast_Chams_Bodies", 0, true, false)
NFast.Chams.Vars["TeamBased"] = CreateClientConVar("NFast_Chams_TeamBased", 0, true, false)
 
NFast.Entities = {}
NFast.Entities.List = {} //The class namse of all the entities
NFast.Entities.Vars = {}
NFast.Entities.Vars["Active"] = CreateClientConVar("NFast_Entities_Active", 0, true, false)
 
NFast.Misc = {}
NFast.Misc.Vars = {}
NFast.Misc.Vars["ShowAdmins"] = CreateClientConVar("NFast_Misc_ShowAdmins", 0, true, false)
NFast.Misc.Vars["Crosshair"] = CreateClientConVar("NFast_Misc_Cross", 0, true, false)
NFast.Misc.Vars["CrosshairSize"] = CreateClientConVar("NFast_Misc_CrossSize", 50, true, false)
NFast.Misc.Vars["NoRecoil"] = CreateClientConVar("NFast_Misc_NoRecoil", 0, true, false)
NFast.Misc.Vars["ShowSpectators"] = CreateClientConVar("NFast_Misc_ShowSpectators", 0, true, false)
NFast.Misc.Vars["BunnyHop"] = CreateClientConVar("NFast_Misc_BunnyHop", 0, true, false)
NFast.Misc.Vars["BunnyHop_Key"] = CreateClientConVar("NFast_Misc_BunnyHop_Key", "KEY_SPACE", true, false)
NFast.Misc.Vars["AutoReload"] = CreateClientConVar("NFast_Misc_AutoReload", 0, true, false)
NFast.Misc.Vars["AutoPistol"] = CreateClientConVar("NFast_Misc_AutoPistol", 0, true, false)
NFast.Misc.Vars["BuyHealth"] = CreateClientConVar("NFast_Misc_BuyHealth", 0, true, false)
NFast.Misc.Vars["BuyHealth_Minimum"] = CreateClientConVar("NFast_Misc_BuyHealth_Minimum", 80, true, false)
NFast.Misc.Vars["TraitorFinder"] = CreateClientConVar("NFast_Misc_TraitorFinder", 0, true, false)
NFast.Misc.Vars["Deaths"] = CreateClientConVar("NFast_Misc_Deaths", 0, true, false)
NFast.Misc.Vars["Sounds"] = CreateClientConVar("NFast_Misc_Sounds", 0, true, false)
 
NFast.Style = {}
NFast.Style.Vars = {}
NFast.Style.Vars["BoundingBox"] = {}
NFast.Style.Vars["BoundingBox"].var = CreateClientConVar("NFast_Style_BoundingBox", "Color(255, 0, 0, 255)", true, false)
NFast.Style.Vars["BoundingBox"].color = NFast.GetColorFromString(NFast.Style.Vars["BoundingBox"].var:GetString())
NFast.Style.Vars["ESPText"] = {}
NFast.Style.Vars["ESPText"].var = CreateClientConVar("NFast_Style_ESPText", "Color(255, 255, 255, 255)", true, false)
NFast.Style.Vars["ESPText"].color = NFast.GetColorFromString(NFast.Style.Vars["ESPText"].var:GetString())
NFast.Style.Vars["Crosshair"] = {}
NFast.Style.Vars["Crosshair"].var = CreateClientConVar("NFast_Style_Cross", "Color(255, 255, 255, 255)", true, false)
NFast.Style.Vars["Crosshair"].color = NFast.GetColorFromString(NFast.Style.Vars["Crosshair"].var:GetString())
NFast.Style.Vars["BodyText"] = {}
NFast.Style.Vars["BodyText"].var = CreateClientConVar("NFast_Style_BodyText", "Color(255, 255, 255, 255)", true, false)
NFast.Style.Vars["BodyText"].color = NFast.GetColorFromString(NFast.Style.Vars["BodyText"].var:GetString())
NFast.Style.Vars["Chams"] = {}
NFast.Style.Vars["Chams"].var = CreateClientConVar("NFast_Style_Chams", "Color(0, 255, 0, 255)", true, false)
NFast.Style.Vars["Chams"].color = NFast.GetColorFromString(NFast.Style.Vars["Chams"].var:GetString())
NFast.Style.Vars["BodyChams"] = {}
NFast.Style.Vars["BodyChams"].var = CreateClientConVar("NFast_Style_BodyChams", "Color(0, 255, 0, 255)", true, false)
NFast.Style.Vars["BodyChams"].color = NFast.GetColorFromString(NFast.Style.Vars["BodyChams"].var:GetString())
 
//This loads our friends list and custom entities list.
/*NFast.SavedData = CreateClientConVar("NFast_SaveData", NFast.RandomName(math.random(10, 15)), true, false)
if file.Exists(NFast.SavedData:GetString()..".txt", "DATA") then
        local info = string.Explode("\n", file.Read(NFast.SavedData:GetString()..".txt", "DATA"))
        if type(info) == "table" and info[1] and info[2] then
                NFast.Friends.List = util.JSONToTable(info[1])
                NFast.Entities.List = util.JSONToTable(info[2])
        end
end
 
NFast.SaveData = function()
        file.Write(NFast.SavedData:GetString()..".txt", util.TableToJSON(NFast.Friends.List))
        file.Append(NFast.SavedData:GetString()..".txt", "\n")
        file.Append(NFast.SavedData:GetString()..".txt", util.TableToJSON(NFast.Entities.List))
end*/
 
//This is all the bones i look for in the order im looking for them. Feel free to change the order if you want to attack the foot before the head or something like that.
NFast.Bones = {
"ValveBiped.Bip01_Head1",
"ValveBiped.Bip01_Neck1",
"ValveBiped.Bip01_Spine4",
"ValveBiped.Bip01_Spine2",
"ValveBiped.Bip01_Spine1",
"ValveBiped.Bip01_Spine",
"ValveBiped.Bip01_R_UpperArm",
"ValveBiped.Bip01_R_Forearm",
"ValveBiped.Bip01_R_Hand",
"ValveBiped.Bip01_L_UpperArm",
"ValveBiped.Bip01_L_Forearm",
"ValveBiped.Bip01_L_Hand",
"ValveBiped.Bip01_R_Thigh",
"ValveBiped.Bip01_R_Calf",
"ValveBiped.Bip01_R_Foot",
"ValveBiped.Bip01_R_Toe0",
"ValveBiped.Bip01_L_Thigh",
"ValveBiped.Bip01_L_Calf",
"ValveBiped.Bip01_L_Foot",
"ValveBiped.Bip01_L_Toe0"
}
 
//If random bones is enabled this list is gone through, randomly, and if none of the bones on this list are found the entire list (above) is gone through.
//If you edit this be sure to edit the function below it.
NFast.RandomBones = {
"ValveBiped.Bip01_Head1",
"ValveBiped.Bip01_Neck1",
"ValveBiped.Bip01_Spine4",
"ValveBiped.Bip01_Spine2",
"ValveBiped.Bip01_R_UpperArm",
"ValveBiped.Bip01_L_UpperArm"
}
NFast.GetRandomBones = function()
        local temp = {}
        local function GetBones() //Ahh recursion, i love you.
                if #NFast.RandomBones > 0 then
                        local random = math.random(1, #NFast.RandomBones)
                        table.insert(temp, NFast.RandomBones[random])
                        table.remove(NFast.RandomBones, random)
                        GetBones()
                else
                        table.insert(NFast.RandomBones, "ValveBiped.Bip01_Head1")
                        table.insert(NFast.RandomBones, "ValveBiped.Bip01_Neck1")
                        table.insert(NFast.RandomBones, "ValveBiped.Bip01_Spine4")
                        table.insert(NFast.RandomBones, "ValveBiped.Bip01_Spine2")
                        table.insert(NFast.RandomBones, "ValveBiped.Bip01_R_UpperArm")
                        table.insert(NFast.RandomBones, "ValveBiped.Bip01_L_UpperArm")
                end
        end
        GetBones()
        return temp
end
 
//A list of all keyboard keys, for binding
NFast.Keys = {
[0] = "KEY_NONE",
[1] = "KEY_0",
[2] = "KEY_1",
[3] = "KEY_2",
[4] = "KEY_3",
[5] = "KEY_4",
[6] = "KEY_5",
[7] = "KEY_6",
[8] = "KEY_7",
[9] = "KEY_8",
[10] = "KEY_9",
[11] = "KEY_A",
[12] = "KEY_B",
[13] = "KEY_C",
[14] = "KEY_D",
[15] = "KEY_E",
[16] = "KEY_F",
[17] = "KEY_G",
[18] = "KEY_H",
[19] = "KEY_I",
[20] = "KEY_J",
[21] = "KEY_K",
[22] = "KEY_L",
[23] = "KEY_M",
[24] = "KEY_N",
[25] = "KEY_O",
[26] = "KEY_P",
[27] = "KEY_Q",
[28] = "KEY_R",
[29] = "KEY_S",
[30] = "KEY_T",
[31] = "KEY_U",
[32] = "KEY_V",
[33] = "KEY_W",
[34] = "KEY_X",
[35] = "KEY_Y",
[36] = "KEY_Z",
[37] = "KEY_PAD_0",
[38] = "KEY_PAD_1",
[39] = "KEY_PAD_2",
[40] = "KEY_PAD_3",
[41] = "KEY_PAD_4",
[42] = "KEY_PAD_5",
[43] = "KEY_PAD_6",
[44] = "KEY_PAD_7",
[45] = "KEY_PAD_8",
[46] = "KEY_PAD_9",
[47] = "KEY_PAD_DIVIDE",
[48] = "KEY_PAD_MULTIPLY",
[49] = "KEY_PAD_MINUS",
[50] = "KEY_PAD_PLUS",
[51] = "KEY_PAD_ENTER",
[52] = "KEY_PAD_DECIMAL",
[53] = "KEY_LBRACKET",
[54] = "KEY_RBRACKET",
[55] = "KEY_SEMICOLON",
[56] = "KEY_APOSTROPHE",
[57] = "KEY_BACKQUOTE",
[58] = "KEY_COMMA",
[59] = "KEY_PERIOD",
[60] = "KEY_SLASH",
[61] = "KEY_BACKSLASH",
[62] = "KEY_MINUS",
[63] = "KEY_EQUAL",
[64] = "KEY_ENTER",
[65] = "KEY_SPACE",
[66] = "KEY_BACKSPACE",
[67] = "KEY_TAB",
[68] = "KEY_CAPSLOCK",
[69] = "KEY_NUMLOCK",
[70] = "KEY_ESCAPE",
[71] = "KEY_SCROLLLOCK",
[72] = "KEY_INSERT",
[73] = "KEY_DELETE",
[74] = "KEY_HOME",
[75] = "KEY_END",
[76] = "KEY_PAGEUP",
[77] = "KEY_PAGEDOWN",
[78] = "KEY_BREAK",
[79] = "KEY_LSHIFT",
[80] = "KEY_RSHIFT",
[81] = "KEY_LALT",
[82] = "KEY_RALT",
[83] = "KEY_LCONTROL",
[84] = "KEY_RCONTROL",
[85] = "KEY_LWIN",
[86] = "KEY_RWIN",
[87] = "KEY_APP",
[88] = "KEY_UP",
[89] = "KEY_LEFT",
[90] = "KEY_DOWN",
[91] = "KEY_RIGHT",
[92] = "KEY_F1",
[93] = "KEY_F2",
[94] = "KEY_F3",
[95] = "KEY_F4",
[96] = "KEY_F5",
[97] = "KEY_F6",
[98] = "KEY_F7",
[99] = "KEY_F8",
[100] = "KEY_F9",
[101] = "KEY_F10",
[102] = "KEY_F11",
[103] = "KEY_F12",
//[104] = "KEY_CAPSLOCKTOGGLE", //THESE
//[105] = "KEY_NUMLOCKTOGGLE", //MOFOS
//[106] = "KEY_SCROLLLOCKTOGGLE", //SHOULD DIE
[107] = "KEY_XBUTTON_UP",
[108] = "KEY_XBUTTON_DOWN",
[109] = "KEY_XBUTTON_LEFT",
[110] = "KEY_XBUTTON_RIGHT",
[111] = "KEY_XBUTTON_START",
[112] = "KEY_XBUTTON_BACK",
[113] = "KEY_XBUTTON_STICK1",
[114] = "KEY_XBUTTON_STICK2",
[115] = "KEY_XBUTTON_A",
[116] = "KEY_XBUTTON_B",
[117] = "KEY_XBUTTON_X",
[118] = "KEY_XBUTTON_Y",
[119] = "KEY_XBUTTON_BLACK",
[120] = "KEY_XBUTTON_WHITE",
[121] = "KEY_XBUTTON_LTRIGGER",
[122] = "KEY_XBUTTON_RTRIGGER",
[123] = "KEY_XSTICK1_UP",
[124] = "KEY_XSTICK1_DOWN",
[125] = "KEY_XSTICK1_LEFT",
[126] = "KEY_XSTICK1_RIGHT",
[127] = "KEY_XSTICK2_UP",
[128] = "KEY_XSTICK2_DOWN",
[129] = "KEY_XSTICK2_LEFT",
[130] = "KEY_XSTICK2_RIGHT"
}
//A list of all mouse keys, for binding
NFast.MouseKeys = {
[107] = "MOUSE_LEFT",
[108] = "MOUSE_RIGHT",
[109] = "MOUSE_MIDDLE",
[110] = "MOUSE_4",
[111] = "MOUSE_5"
}
//Tells me if a specific key is pressed. Loops through both tables.
NFast.KeyPressed = function(key)
        if NFast.InChat then return false end
       
        for k = 107, 111 do
                if key == NFast.MouseKeys[k] then
                        if input.IsMouseDown(k) then
                                return true
                        else
                                return false
                        end
                end
        end
       
        for k = 0, 130 do
                if key == NFast.Keys[k] then
                        if input.IsKeyDown(k) then
                                return true
                        else
                                return false
                        end
                end
        end
       
        return false
end
 
//Very simple. If the boolean is true it returns 1. If the boolean is false then it returns 0. I dont think i ended up using this anywhere, but whatever, ill leave it here.
NFast.BoolToInt = function(bool)
        if bool then
                return 1
        else
                return 0
        end
end
 
//Checking if a bone is visible, pos is the position of the bone and ent is the entity whos bone were looking for.
NFast.SpotIsVisible = function(pos, ent)
        ent = ent or NFast.Aimbot.CurTarget
        local tracedata = {}
        tracedata.start = NFast.Ply:GetShootPos()
        tracedata.endpos = pos
        tracedata.filter = {NFast.Ply, ent}
       
        local trace = util.TraceLine(tracedata)
        if trace.HitPos:Distance(pos) < 0.005 then
                return true
        else
                return false
        end
end
 
//Checks all of the entities bones to find if we can see this entity or not.
NFast.CanSee = function(ent)
        for k = 1, #NFast.Bones do
                local v = NFast.Bones[k]
                local bone = ent:LookupBone(v)
                if bone != nil then
                        local pos, ang = ent:GetBonePosition(bone)
                        if NFast.SpotIsVisible(pos, ent) then
                                return true
                        end
                end
        end
        return false
end
 
//This returns the next entity we should attack.
NFast.GetTarget = function()
        if NFast.Aimbot.Vars["AttackNPCs"]:GetBool() or NFast.Aimbot.Vars["AttackPlayers"]:GetBool() then
                local targets = {}
                local everything = ents.GetAll()
                for k = 1, #everything do
                        local v = everything[k]
                        if NFast.Aimbot.Vars["AttackNPCs"]:GetBool() and v:IsNPC() then
                                if NFast.CanSee(v) then
                                        table.insert(targets, {["Target"] = v, ["Pos"] = v:LocalToWorld(v:OBBCenter())})
                                end
                        elseif NFast.Aimbot.Vars["AttackPlayers"]:GetBool() and v:IsPlayer() and v != NFast.Ply then
                                if NFast.CanSee(v) then
                                        table.insert(targets, {["Target"] = v, ["Pos"] = v:LocalToWorld(v:OBBCenter())})
                                end
                        end
                end
               
                for k,v in SortedPairs(targets, true) do //It will already be sorted so this shouldn't be too resource heavy, the main point of this is to loop through the table backwards
                        local v = v["Target"]
                        local shouldremove = false
                        if NFast.Aimbot.Vars["IgnoreTeam"]:GetBool() and v:IsPlayer() then
                                if NFast.TTT then
                                        if NFast.Ply:GetRole() == 1 and v:GetRole() == 1 then
                                                shouldremove = true
                                        end
                                               
                                        if NFast.Ply:GetRole() != 1 and not table.HasValue(NFast.Traitors, v) then
                                                shouldremove = true
                                        end
                                else
                                        if v:Team() == NFast.Ply:Team() then
                                                shouldremove = true
                                        end
                                end
                        end
                       
                        if NFast.Friends.Vars["Active"]:GetBool() then
                                if NFast.Friends.Vars["Reverse"]:GetBool() then
                                        if not table.HasValue(NFast.Friends.List, v:SteamID()) then
                                                shouldremove = true
                                        end
                                else
                                        if table.HasValue(NFast.Friends.List, v:SteamID()) then
                                                shouldremove = true            
                                        end
                                end
                        end
                       
                        if shouldremove then
                                table.remove(targets, k)
                        end
                end
               
                if #targets == 0 then
                        return nil
                elseif #targets == 1 then
                        targets[1]["Target"].BoneToAimAt = nil
                        return targets[1]["Target"]
                end
               
                if NFast.Aimbot.Vars["Preferance"]:GetString() == "Distance" then
                        local min = {["Distance"] = NFast.Ply:GetPos():Distance(targets[1]["Pos"]), ["Target"] = targets[1]["Target"]}
                        for k = 1, #targets do
                                local v = targets[k]
                               
                                local distance = NFast.Ply:GetPos():Distance(v["Pos"])
                                if distance < min["Distance"] then
                                        min = {["Distance"] = distance, ["Target"] = v["Target"]}
                                end
                        end
                        min["Target"].BoneToAimAt = nil
                        return min["Target"]
                elseif NFast.Aimbot.Vars["Preferance"]:GetString() == "Angle" then             
                        local min = {["Angle"] = NFast.AngleTo(targets[1]["Pos"]), ["Target"] = targets[1]["Target"]}
                        for k = 1, #targets do
                                local v = targets[k]
                               
                                local angle = NFast.AngleTo(v["Pos"])
                                if angle < min["Angle"] then
                                        min = {["Angle"] = angle, ["Target"] = v["Target"]}
                                end
                        end
                        min["Target"].BoneToAimAt = nil
                        return min["Target"]
                end
        else
                return nil
        end
end
 
//This returns the total angle away from the target we are, and then the pitch and yaw seperately
NFast.AngleTo = function(pos)
        local myAngs = NFast.Ply:GetAngles()
        local needed = (pos - NFast.Ply:GetShootPos()):Angle()
       
        myAngs.p = math.NormalizeAngle(myAngs.p)
        needed.p = math.NormalizeAngle(needed.p)
       
        myAngs.y = math.NormalizeAngle(myAngs.y)
        needed.y = math.NormalizeAngle(needed.y)
       
        local p = math.NormalizeAngle(needed.p - myAngs.p)
        local y = math.NormalizeAngle(needed.y - myAngs.y)
       
        return math.abs(p) + math.abs(y), {p = p, y = y}
end
 
//Returns true if our target meets our preferances.
NFast.ValidTarget = function()
        if NFast.Aimbot.CurTarget == nil then return false end
        if not IsValid(NFast.Aimbot.CurTarget) then return false end
        if NFast.Aimbot.CurTarget:IsPlayer() and (not NFast.Aimbot.CurTarget:Alive() or NFast.Aimbot.CurTarget:Team() == TEAM_SPECTATOR or NFast.Aimbot.CurTarget:Health() < 1) then return false end
        if not NFast.Aimbot.Vars["AttackNPCs"]:GetBool() and NFast.Aimbot.CurTarget:IsNPC() then return false end
        if not NFast.Aimbot.Vars["AttackPlayers"]:GetBool() and NFast.Aimbot.CurTarget:IsPlayer() then return false end
        if not NFast.CanSee(NFast.Aimbot.CurTarget) then return false end
        if NFast.Aimbot.Vars["IgnoreTeam"]:GetBool() and NFast.Aimbot.CurTarget:IsPlayer() then
                if NFast.TTT then
                        if NFast.Ply:GetRole() == 1 and NFast.Aimbot.CurTarget:GetRole() == 1 then return false end                            
                        if NFast.Ply:GetRole() != 1 and not table.HasValue(NFast.Traitors, NFast.Aimbot.CurTarget) then return false end
                else
                        if NFast.Aimbot.CurTarget:Team() == NFast.Ply:Team() then return false end
                end
        end
       
        return true
end
 
hook.Add("RenderScreenspaceEffects", NFast.RandomName(math.random(10, 15)), function()
        if NFast.Active:GetBool() then
                local everything = ents.GetAll()
                for k = 1, #everything do
                        local v = everything[k]
                       
                        if NFast.Chams.Vars["Active"]:GetBool() and v != NFast.Ply and (NFast.Chams.Vars["MaxDistance"]:GetInt() == 0 or v:GetPos():Distance(NFast.Ply:GetPos()) < NFast.Chams.Vars["MaxDistance"]:GetInt()) then
                                cam.Start3D(EyePos(), EyeAngles())
                                        if (v:IsPlayer() and v:Alive() and v:Team() != TEAM_SPECTATOR and NFast.Chams.Vars["Players"]:GetBool()) or (v:IsNPC() and v:Health() > 0 and NFast.Chams.Vars["NPCs"]:GetBool()) then
                                                local color = NFast.Style.Vars["Chams"].color
                                                if NFast.Chams.Vars["TeamBased"]:GetBool() and v:IsPlayer() then
                                                        color = team.GetColor(v:Team())
                                                        if NFast.TTT then
                                                                if v:GetRole() == 2 then
                                                                        color = Color(0, 0, 255, 255)
                                                                elseif table.HasValue(NFast.Traitors, v) then
                                                                        color = Color(255, 0, 0, 255)
                                                                else
                                                                        color = Color(0, 255, 0, 255)
                                                                end
                                                        end
                                                end
                                                render.SuppressEngineLighting(true)
                                                render.SetColorModulation(color.r/255, color.g/255, color.b/255, 1)
                                                render.MaterialOverride(NFast.Chams.Mat)
                                                v:DrawModel()
                                               
                                                render.SetColorModulation((color.r + 150)/250, (color.g + 150)/250, (color.b + 150)/255, 1)                                            
                                                if IsValid(v:GetActiveWeapon()) and NFast.Chams.Vars["Weapons"]:GetBool() then
                                                        v:GetActiveWeapon():DrawModel()
                                                end
                                               
                                                render.SetColorModulation(1, 1, 1, 1)
                                                render.MaterialOverride()
                                                render.SetModelLighting(4, color.r/255, color.g/255, color.b/255)
                                                v:DrawModel()
                                                render.SuppressEngineLighting(false)
                                        elseif NFast.TTT and NFast.Chams.Vars["Bodies"]:GetBool() and v:GetClass() == "prop_ragdoll" then
                                                local color = NFast.Style.Vars["BodyChams"].color
                                                render.SuppressEngineLighting(true)    
                                                render.SetColorModulation(color.r/255, color.g/255, color.b/255, 1)
                                                render.MaterialOverride(NFast.Chams.Mat)
                                                v:DrawModel()  
                                                render.SetColorModulation(1, 1, 1, 1)
                                                render.MaterialOverride()
                                                render.SetModelLighting(4, color.r/255, color.g/255, color.b/255)
                                                v:DrawModel()
                                                render.SuppressEngineLighting(false)
                                        elseif NFast.Entities.Vars["Active"]:GetBool() and table.HasValue(NFast.Entities.List, v:GetClass()) then
                                                local color = NFast.Style.Vars["Chams"].color                                  
                                                render.SuppressEngineLighting(true)    
                                                render.SetColorModulation(color.r/255, color.g/255, color.b/255, 1)
                                                render.MaterialOverride(NFast.Chams.Mat)
                                                v:DrawModel()  
                                                render.SetColorModulation(1, 1, 1, 1)
                                                render.MaterialOverride()
                                                render.SetModelLighting(4, color.r/255, color.g/255, color.b/255)
                                                v:DrawModel()
                                                render.SuppressEngineLighting(false)
                                        end
                                cam.End3D()
                        end
                end
        end
end)
 
//Helper function on radar. I just copied this one from the wiki.
NFast.DrawFilledCircle = function(x, y, radius, quality)
        local circle = {}
    local tmp = 0
    for i = 1, quality do
        tmp = math.rad(i * 360) / quality
        circle[i] = {x = x + math.cos(tmp) * radius, y = y + math.sin(tmp) * radius}
    end
        surface.DrawPoly(circle)
end
 
//Another helper fuction on the radar.
NFast.DrawArrow = function(x, y, myRotation)
        local arrow = {}       
        arrow[1] = {x = x, y = y}
        arrow[2] = {x = x + 4, y = y + 7.5}
        arrow[3] = {x = x, y = y + 5}
        arrow[4] = {x = x - 4, y = y + 7.5}
       
        //Now that i have the arrow determined, i have to rotate it to match the targets angle
        myRotation = myRotation * -1
        myRotation = math.rad(myRotation)
        for i = 1, 4 do
                local theirX = arrow[i].x
                local theirY = arrow[i].y
               
                theirX = theirX - x
                theirY = theirY - y
               
                arrow[i].x = theirX * math.cos(myRotation) - theirY * math.sin(myRotation)
                arrow[i].y = theirX * math.sin(myRotation) + theirY * math.cos(myRotation)
               
                arrow[i].x = arrow[i].x + x
                arrow[i].y = arrow[i].y + y
        end
 
        surface.DrawPoly(arrow)
end
 
NFast.Traitors = {}
NFast.SuperAdmins = {}
NFast.Admins = {}
NFast.Spectators = {}
local radarX, radarY, radarWidth, radarHeight = 100, 200, 150, 150
hook.Add("HUDPaint", NFast.RandomName(math.random(10, 15)), function()
        if NFast.Active:GetBool() then 
                local everything = ents.GetAll()
               
                if NFast.ESP.Vars["Active"]:GetBool() and NFast.ESP.Vars["Radar"]:GetBool() then //Setting up the background here. And since the ESP doesnt draw you
                        draw.RoundedBox(0, radarX, radarY, radarWidth, radarHeight, Color(100, 100, 100, 255 ))
                        draw.NoTexture()
                        if NFast.ESP.Vars["TeamBased"]:GetBool() then
                                local color = team.GetColor(NFast.Ply:Team())
                                if NFast.TTT then
                                        if NFast.Ply:GetRole() == 2 then
                                                color = Color(0, 0, 255, 255)
                                        elseif NFast.Ply:GetRole() == 1 then
                                                color = Color(255, 0, 0, 255)
                                        else
                                                color = Color(0, 255, 0, 255)
                                        end
                                end
                                surface.SetDrawColor(color)
                        else
                                surface.SetDrawColor(NFast.Style.Vars["ESPText"].color)
                        end
                        NFast.DrawArrow(radarX + (radarWidth / 2), radarY + (radarHeight / 2), 0)
                end
               
                for k = 1, #everything do
                        local v = everything[k]
               
                        if NFast.ESP.Vars["Active"]:GetBool() and v != NFast.Ply and (NFast.ESP.Vars["MaxDistance"]:GetInt() == 0 or v:GetPos():Distance(NFast.Ply:GetPos()) < NFast.ESP.Vars["MaxDistance"]:GetInt()) then                                                                            
                                if (v:IsPlayer() and v:Alive() and v:Team() != TEAM_SPECTATOR and NFast.ESP.Vars["Players"]:GetBool()) or (v:IsNPC() and v:Health() > 0 and NFast.ESP.Vars["NPCs"]:GetBool()) then
                                        local color = NFast.Style.Vars["ESPText"].color
                                        if NFast.ESP.Vars["TeamBased"]:GetBool() and v:IsPlayer() then
                                                color = team.GetColor(v:Team())
                                                if NFast.TTT then
                                                        if v:GetRole() == 2 then
                                                                color = Color(0, 0, 255, 255)
                                                        elseif table.HasValue(NFast.Traitors, v) then
                                                                color = Color(255, 0, 0, 255)
                                                        else
                                                                color = Color(0, 255, 0, 255)
                                                        end
                                                end
                                        end
                                       
                                        local Min, Max = v:GetCollisionBounds()
                                        if NFast.ESP.Vars["Box"]:GetBool() then
                                                local one = v:LocalToWorld(Min):ToScreen()
                                                local two = v:LocalToWorld(Vector(Min.x, Min.y, Max.z)):ToScreen()
                                                local three = v:LocalToWorld(Vector(Min.x, Min.y + (Max.y * 2), Min.z)):ToScreen()
                                                local four = v:LocalToWorld(Vector(Min.x + (Max.x * 2), Min.y, Min.z)):ToScreen()
                                                local five = v:LocalToWorld(Max):ToScreen()
                                                local six = v:LocalToWorld(Vector(Max.x, Max.y, Min.z)):ToScreen()
                                                local seven = v:LocalToWorld(Vector(Max.x, Max.y + (Min.y * 2), Max.z)):ToScreen()
                                                local eight = v:LocalToWorld(Vector(Max.x + (Min.x * 2), Max.y, Max.z)):ToScreen()                             
                                               
                                                if NFast.ESP.Vars["TeamBased"]:GetBool() then
                                                        surface.SetDrawColor(color)
                                                else
                                                        surface.SetDrawColor(NFast.Style.Vars["BoundingBox"].color)
                                                end
                                                local function connect(tabone, tabtwo)
                                                        surface.DrawLine(tabone.x, tabone.y, tabtwo.x, tabtwo.y)
                                                end
                                               
                                                connect(one, two)
                                                connect(three, eight)
                                                connect(four, seven)
                                                connect(six, five)
                                                connect(four, six)
                                                connect(four, one)
                                                connect(one, three)
                                                connect(three, six)
                                                connect(five, eight)
                                                connect(eight, two)
                                                connect(two, seven)
                                                connect(seven, five)
                                        end
                                       
                                        surface.SetFont("ESPFont")
                                        local top = v:GetPos() + Vector(0, 0, Max.z + 10) // A little above their head so its not constantly covering their face.
                                        local topscreen = top:ToScreen()
                                        local topy = topscreen.y
                                       
                                        local bottom = v:GetPos()
                                        local bottomscreen = bottom:ToScreen()
                                        local bottomy = bottomscreen.y
                                       
                                        local function DrawAbove(text)
                                                local W, H = surface.GetTextSize(text)
                                                surface.SetTextPos(topscreen.x - W / 2, topy)
                                                surface.DrawText(text)
                                               
                                                topy = topy + H
                                        end
                                       
                                        local function DrawBelow(text)
                                                local W, H = surface.GetTextSize(text)
                                                surface.SetTextPos(bottomscreen.x - W / 2, bottomy)
                                                surface.DrawText(text)
                                               
                                                bottomy = bottomy + H
                                        end
                                       
                                        surface.SetTextColor(Color(255, 0, 0, 255))
                                        if NFast.ESP.Vars["ShowTraitors"]:GetString() != "Off" and table.HasValue(NFast.Traitors, v) then
                                                if NFast.ESP.Vars["ShowTraitors"]:GetString() == "Above" then
                                                        DrawAbove("Traitor")
                                                else
                                                        DrawBelow("Traitor")
                                                end
                                        end
                                       
                                        surface.SetTextColor(color)
                                        if v:IsPlayer() then
                                                if NFast.ESP.Vars["Name"]:GetString() == "Above" then
                                                        DrawAbove("Name: "..v:Nick())
                                                elseif NFast.ESP.Vars["Name"]:GetString() == "Below" then
                                                        DrawBelow("Name: "..v:Nick())
                                                end
                                        else
                                                if NFast.ESP.Vars["Name"]:GetString() == "Above" then
                                                        DrawAbove("Name: "..v:GetClass())
                                                elseif NFast.ESP.Vars["Name"]:GetString() == "Below" then
                                                        DrawBelow("Name: "..v:GetClass())
                                                end
                                        end
                                       
                                        if NFast.ESP.Vars["Weapons"]:GetString() == "Above" and IsValid(v:GetActiveWeapon()) then
                                                DrawAbove("Weapon: "..v:GetActiveWeapon():GetClass())
                                        elseif NFast.ESP.Vars["Weapons"]:GetString() == "Below" and IsValid(v:GetActiveWeapon()) then
                                                DrawBelow("Weapon: "..v:GetActiveWeapon():GetClass())
                                        end            
                                       
                                        if NFast.ESP.Vars["Distance"]:GetString() == "Above" then
                                                DrawAbove("Distance: "..bottom:Distance(NFast.Ply:GetPos()))
                                        elseif NFast.ESP.Vars["Distance"]:GetString() == "Below" then
                                                DrawBelow("Distance: "..bottom:Distance(NFast.Ply:GetPos()))
                                        end    
                                       
                                        if NFast.ESP.Vars["Health"]:GetString() == "Above" then
                                                DrawAbove("HP: "..v:Health())
                                        elseif NFast.ESP.Vars["Health"]:GetString() == "Below" then
                                                DrawBelow("HP: "..v:Health())
                                        end
                                       
                                        if NFast.ESP.Vars["Radar"]:GetBool() then
                                                surface.SetDrawColor(color)
                                                local myPos = NFast.Ply:GetPos()
                                                local theirPos = v:GetPos()
                                                local myAngles = NFast.Ply:GetAngles()
                                               
                                                local theirX = (radarX + (radarWidth / 2)) + ((theirPos.x - myPos.x) / NFast.ESP.Vars["RadarScale"]:GetInt())
                                                local theirY = (radarY + (radarHeight / 2)) + ((myPos.y - theirPos.y) / NFast.ESP.Vars["RadarScale"]:GetInt())
                                               
                                                //Now i have to rotate this
                                                local myRotation = myAngles.y - 90
                                                myRotation = math.rad(myRotation)
                                               
                                                theirX = theirX - (radarX + (radarWidth / 2))
                                                theirY = theirY - (radarY + (radarHeight / 2))
                                                local newX = theirX * math.cos(myRotation) - theirY * math.sin(myRotation)
                                                local newY = theirX * math.sin(myRotation) + theirY * math.cos(myRotation)
                                                newX = newX + (radarX + (radarWidth / 2))
                                                newY = newY + (radarY + (radarHeight / 2))
                                               
                                                //And now that its rotated i can check if its within our radars bounds and draw it
                                                if newX < (radarX + radarWidth) and newX > radarX and newY < (radarY + radarHeight) and newY > radarY then
                                                        NFast.DrawArrow(newX, newY, v:EyeAngles().y - myAngles.y)
                                                end
                                        end
                                elseif NFast.TTT and NFast.ESP.Vars["Bodies"]:GetBool() and v:GetClass() == "prop_ragdoll" then
                                        surface.SetFont("ESPFont")
                                       
                                        //Im just going to position this info at the center of the player, if i get any complaints ill change it
                                        local pos = v:LocalToWorld(v:OBBCenter())
                                        local poscreen = pos:ToScreen()
                                        local W, H = surface.GetTextSize("Sample") //It doesnt have to be perfect but this will help center the text more.
                                        local y = poscreen.y - (H * 1.5)
                                       
                                        local function DrawText(text)
                                                local W, H = surface.GetTextSize(text)
                                                surface.SetTextPos(poscreen.x - W / 2, y)
                                                surface.DrawText(text)
                                               
                                                y = y + H
                                        end
                                       
                                        surface.SetTextColor(NFast.Style.Vars["BodyText"].color)
                                        DrawText("Credits: "..NFast.TTTCORPSE.GetCredits(v, 0))
                                        DrawText("Name: "..NFast.TTTCORPSE.GetPlayerNick(v, "Unknown"))
                                        DrawText("Found: "..tostring(NFast.TTTCORPSE.GetFound(v, false)))
                                       
                                        if NFast.ESP.Vars["Radar"] then
                                                surface.SetDrawColor(NFast.Style.Vars["BodyText"].color)
                                                local myPos = NFast.Ply:GetPos()
                                                local theirPos = v:GetPos()
                                               
                                                local theirX = (radarX + (radarWidth / 2)) + ((theirPos.x - myPos.x) / NFast.ESP.Vars["RadarScale"]:GetInt())
                                                local theirY = (radarY + (radarHeight / 2)) + ((myPos.y - theirPos.y) / NFast.ESP.Vars["RadarScale"]:GetInt())
                                               
                                                //Now i have to rotate this
                                                local myRotation = NFast.Ply:GetAngles().y - 90
                                                myRotation = math.rad(myRotation)
                                               
                                                theirX = theirX - (radarX + (radarWidth / 2))
                                                theirY = theirY - (radarY + (radarHeight / 2))
                                                local newX = theirX * math.cos(myRotation) - theirY * math.sin(myRotation)
                                                local newY = theirX * math.sin(myRotation) + theirY * math.cos(myRotation)
                                                newX = newX + (radarX + (radarWidth / 2))
                                                newY = newY + (radarY + (radarHeight / 2))
                                               
                                                //And now that its rotated i can check if its within our radars bounds and draw it
                                                if newX < (radarX + radarWidth) and newX > radarX and newY < (radarY + radarHeight) and newY > radarY then
                                                        NFast.DrawFilledCircle(newX, newY, 2, 4)
                                                end
                                        end
                                elseif NFast.Entities.Vars["Active"]:GetBool() and table.HasValue(NFast.Entities.List, v:GetClass()) then
                                        surface.SetFont("ESPFont")
                                        surface.SetTextColor(NFast.Style.Vars["ESPText"].color)
                                       
                                        local text = v:GetClass()
                                        local W, H = surface.GetTextSize(text)
                                       
                                        local PosScreen = v:GetPos():ToScreen()
                                        surface.SetTextPos(PosScreen.x - W / 2, PosScreen.y)
                                        surface.DrawText(text)
                                end
                        end
                       
                        surface.SetFont("default")
                        if v:IsPlayer() and v:IsSuperAdmin() then
                                if not table.HasValue(NFast.SuperAdmins, v) then
                                        table.insert(NFast.SuperAdmins, v)
                                        NFast.Message("Super Admin "..v:Nick().." joined the game.")
                                        if NFast.Misc.Vars["Sounds"]:GetBool() then
                                                surface.PlaySound("vo/npc/Alyx/watchout02.wav")
                                        end    
                                end
                        end                    
                        if v:IsPlayer() and v:IsAdmin() and not v:IsSuperAdmin() then
                                if not table.HasValue(NFast.Admins, v) then
                                        table.insert(NFast.Admins, v)
                                        NFast.Message("Admin "..v:Nick().." joined the game.")
                                        if NFast.Misc.Vars["Sounds"]:GetBool() then
                                                surface.PlaySound("vo/npc/Alyx/watchout01.wav")
                                        end    
                                end
                        end            
                        for k,v in SortedPairs(NFast.Admins, true) do
                                if not IsValid(v) then
                                        table.remove(NFast.Admins, k)
                                end
                        end
                        for k,v in SortedPairs(NFast.SuperAdmins, true) do
                                if not IsValid(v) then
                                        table.remove(NFast.SuperAdmins, k)
                                end
                        end
                               
                        if v:IsPlayer() and v:GetObserverTarget() == NFast.Ply then
                                if not table.HasValue(NFast.Spectators, v) then
                                        table.insert(NFast.Spectators, v)
                                        NFast.Message(v:Nick().." started spectating you.")
                                        if NFast.Misc.Vars["Sounds"]:GetBool() then
                                                surface.PlaySound("vo/npc/female01/ohno.wav")
                                        end                            
                                end
                        end
                        for k,v in SortedPairs(NFast.Spectators, true) do
                                if IsValid(v) then
                                        if v:GetObserverTarget() != NFast.Ply then
                                                table.remove(NFast.Spectators, k)
                                        end
                                else
                                        table.remove(NFast.Spectators, k)
                                end
                        end
                       
                        if NFast.TTT and NFast.Misc.Vars["TraitorFinder"]:GetBool() then
                                if GetRoundState() == 3 and v:IsWeapon() and type(v:GetOwner()) == "Player" and v.Buyer == nil and v.CanBuy and table.HasValue(v.CanBuy, 1) then
                                        local owner = v:GetOwner()
                                        if owner:GetRole() == 2 then
                                                v.Buyer = owner
                                        else
                                                NFast.Message(owner:Nick().." bought a traitor weapon: "..v:GetClass())
                                                v.Buyer = owner
                                                table.insert(NFast.Traitors, owner)
                                                if NFast.Misc.Vars["Sounds"]:GetBool() then
                                                        surface.PlaySound("weapons/shotgun/shotgun_cock.wav")
                                                end    
                                        end
                                elseif GetRoundState() != 3 then
                                        table.Empty(NFast.Traitors)
                                end
                        end
                       
                        if NFast.Misc.Vars["Deaths"]:GetBool() and v:IsPlayer() then
                                if v:Alive() then
                                        v.IsAlive = true
                                elseif v.IsAlive then
                                        NFast.Message(3, v:Nick().." just died.")
                                        v.IsAlive = false
                                        if NFast.Misc.Vars["Sounds"]:GetBool() then
                                                surface.PlaySound("npc/combine_soldier/vo/onedown.wav")
                                        end    
                                end                            
                        end
                end
               
                surface.SetFont("default")
                surface.SetTextColor(Color(255, 255, 255, 255))
                local AdminWidest = 0
                local AdminTotalHeight = 0
                local AdminHeight = 20
                if NFast.Misc.Vars["ShowAdmins"]:GetBool() then
                        for k,v in pairs(NFast.SuperAdmins) do
                                local W, H = surface.GetTextSize(v:Nick().." - Super Admin")
                                if W > AdminWidest then
                                        AdminWidest = W
                                end
                                AdminTotalHeight = AdminTotalHeight + H
                        end
                        for k,v in pairs(NFast.Admins) do
                                local W, H = surface.GetTextSize(v:Nick().." - Admin")
                                if W > AdminWidest then
                                        AdminWidest = W
                                end
                                AdminTotalHeight = AdminTotalHeight + H
                        end
                        draw.RoundedBox(8, ScrW() - AdminWidest - 30, 10, AdminWidest + 20, AdminTotalHeight + 20, Color(0, 0, 0, 150 ))
                        for k,v in pairs(NFast.SuperAdmins) do
                                local text = v:Nick().." - Super Admin"
                                local W, H = surface.GetTextSize(text)
                                surface.SetTextPos(ScrW() - 20 - AdminWidest, AdminHeight)
                                surface.DrawText(text)
                                AdminHeight = AdminHeight + H
                        end
                        for k,v in pairs(NFast.Admins) do
                                local text = v:Nick().." - Admin"
                                local W, H = surface.GetTextSize(text)
                                surface.SetTextPos(ScrW() - 20 - AdminWidest, AdminHeight)
                                surface.DrawText(text)
                                AdminHeight = AdminHeight + H
                        end
                end
               
                local SpecWidest = 0
                local SpecTotalHeight = 0
                local SpecHeight = AdminTotalHeight + 50
                if NFast.Misc.Vars["ShowSpectators"]:GetBool() then
                        for k,v in pairs(NFast.Spectators) do
                                local W, H = surface.GetTextSize(v:Nick())
                                if W > SpecWidest then
                                        SpecWidest = W
                                end
                                SpecTotalHeight = SpecTotalHeight + H
                        end
                        draw.RoundedBox(8, ScrW() - SpecWidest - 30, 40 + AdminTotalHeight, SpecWidest + 20, SpecTotalHeight + 20, Color(0, 0, 0, 150 ))
                        for k,v in pairs(NFast.Spectators) do
                                local text = v:Nick()
                                local W, H = surface.GetTextSize(text)
                                surface.SetTextPos(ScrW() - 20 - SpecWidest, SpecHeight)
                                surface.DrawText(text)
                                SpecHeight = SpecHeight + H
                        end
                end
               
                if NFast.Misc.Vars["Crosshair"]:GetBool() then
                        local size = NFast.Misc.Vars["CrosshairSize"]:GetInt()
                        local MiddleScreen = {x = surface.ScreenWidth() / 2, y = surface.ScreenHeight() / 2}
                        surface.SetDrawColor(NFast.Style.Vars["Crosshair"].color)
                        surface.DrawLine(MiddleScreen.x, MiddleScreen.y, MiddleScreen.x - size, MiddleScreen.y)
                        surface.DrawLine(MiddleScreen.x, MiddleScreen.y, MiddleScreen.x, MiddleScreen.y - size)
                        surface.DrawLine(MiddleScreen.x, MiddleScreen.y, MiddleScreen.x + size, MiddleScreen.y)
                        surface.DrawLine(MiddleScreen.x, MiddleScreen.y, MiddleScreen.x, MiddleScreen.y + size)
                end
        end
end)
 
hook.Add("Think", NFast.RandomName(math.random(10, 15)), function()
        if NFast.Active:GetBool() then 
                if NFast.Aimbot.Vars["Active"]:GetBool() and not (NFast.Aimbot.Vars["PanicMode"]:GetBool() and #NFast.Spectators > 0) then
                        if not NFast.Aimbot.Vars["AimOnKey"]:GetBool() or (NFast.Aimbot.Vars["AimOnKey"]:GetBool() and NFast.KeyPressed(NFast.Aimbot.Vars["AimOnKey_Key"]:GetString())) then
                                if NFast.ValidTarget() then
                                        local BoneOrder = {}
                                        if NFast.Aimbot.CurTarget.BoneToAimAt and NFast.Aimbot.Vars["RandomBones"]:GetBool() then
                                                table.insert(BoneOrder, NFast.Aimbot.CurTarget.BoneToAimAt)
                                                table.Add(BoneOrder, NFast.GetRandomBones())
                                                table.Add(BoneOrder, NFast.Bones)
                                        else
                                                if NFast.Aimbot.Vars["RandomBones"]:GetBool() then
                                                        table.Add(BoneOrder, NFast.GetRandomBones())
                                                        table.Add(BoneOrder, NFast.Bones)
                                                else
                                                        table.Add(BoneOrder, NFast.Bones)
                                                end
                                        end
                                        for k = 1, #BoneOrder do
                                                local v = BoneOrder[k]
                                                local bone = NFast.Aimbot.CurTarget:LookupBone(v)
                                                if bone != nil then
                                                        local pos, ang = NFast.Aimbot.CurTarget:GetBonePosition(bone)
                                                        if v == "ValveBiped.Bip01_Head1" then
                                                                pos = pos + Vector(0, 0, 3) //Aiming a little higher for the head
                                                        end
                                                        local total, needed = 300, {300, 300}
                                                       
                                                        if NFast.Aimbot.Vars["Prediction"]:GetBool() then
                                                                local tarSpeed = NFast.Aimbot.CurTarget:GetVelocity() * 0.013
                                                                local plySpeed = NFast.Ply:GetVelocity() * 0.013
                                                                total, needed = NFast.AngleTo(pos - plySpeed + tarSpeed)
                                                        else
                                                                total, needed = NFast.AngleTo(pos)
                                                        end
                                                               
                                                        if NFast.SpotIsVisible(pos) and total < NFast.Aimbot.Vars["MaxAngle"]:GetInt() then
                                                                local myAngles = NFast.Ply:GetAngles()                                                         
                                                                local NewAngles = Angle(myAngles.p + needed.p, myAngles.y + needed.y, 0)
                                                               
                                                                if NFast.Aimbot.Vars["AntiSnap"]:GetBool() then
                                                                        local speed = NFast.Aimbot.Vars["AntiSnapSpeed"]:GetInt()
                                                                        NewAngles = (Angle(math.Approach(myAngles.p, NewAngles.p, speed), math.Approach(myAngles.y, NewAngles.y, speed), 0))
                                   l