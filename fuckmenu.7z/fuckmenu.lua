--[[
	autorun/client/lua/autorun/client/fuckmenu.lua
	ALL YOU CAN EAT | (STEAM_0:1:14585758)
	===DStream===
]]

surface.CreateFont( "arial", 12, 350, true, false, "AimBotSmall" )
surface.CreateFont ("Comic Sans MS", 15, 350, true, false, "KDR")
surface.CreateFont ("Impact", 15, 350, true, false, "Quakefont")
//COnVars
//Esp
CreateConVar("fuck_esp", 1, false)
--CreateConVar("fuck_esp_x", 0, false)
--CreateConVar("fuck_esp_y", 0, false)
CreateConVar("fuck_esp_box", 1, false)
CreateConVar("fuck_esp_name", 1, false)
CreateConVar("fuck_esp_Health", 1, false)
CreateConVar("fuck_esp_armor", 1, false)
CreateConVar("fuck_esp_weapon", 0, false)
CreateConVar("fuck_esp_enemys_only", 1, false)
CreateConVar("fuck_esp_stats", 0, false)
CreateConVar("fuck_esp_id", 0, false)
CreateConVar("fuck_esp_entity", 0, false)
CreateConVar("fuck_esp_distance", 0, false)
CreateConVar("fuck_esp_info", 0, false)
CreateConVar("fuck_esp_aimatme", 0, false)
CreateConVar("fuck_esp_barrel", 0, false)
--CreateConVar("fuck_esp_dlight", 1, false)
CreateConVar("fuck_esp_crosshair", 1, false)
CreateConVar("fuck_gm_ttt_trai",0,false)
CreateConVar("fuck_move_bunnyhop",0,false)
CreateConVar("fuck_show_xy",0,false)
//Spam
--CreateConVar("fuck_spam", 0, false)
//Dlight
--CreateConVar("fuck_dlight_Enemys", 1, false)
--CreateConVar("fuck_dlight_Friends", 0, false)
Show = util.tobool(GetConVarNumber("fuck_show_xy"))

ESP = util.tobool(GetConVarNumber("fuck_esp"))
ESP_box = util.tobool(GetConVarNumber("fuck_esp_box"))
ESP_name = util.tobool(GetConVarNumber("fuck_esp_name"))
ESP_health = util.tobool(GetConVarNumber("fuck_esp_Health"))
ESP_armor = util.tobool(GetConVarNumber("fuck_esp_armor"))
ESP_weapon = util.tobool(GetConVarNumber("fuck_esp_weapon"))
ESP_enemy = util.tobool(GetConVarNumber("fuck_esp_enemys_only"))
--ESP_stats = util.tobool(GetConVarNumber("fuck_esp_stats"))
ESP_id = util.tobool(GetConVarNumber("fuck_esp_id"))
ESP_ent = util.tobool(GetConVarNumber("fuck_esp_entity"))
ESP_distance = util.tobool(GetConVarNumber("fuck_esp_distance"))
ESP_info = util.tobool(GetConVarNumber("fuck_esp_info"))
ESP_aimatme = util.tobool(GetConVarNumber("fuck_esp_aimatme"))
ESP_barrel = util.tobool(GetConVarNumber("fuck_esp_barrel"))
--ESP_dlight = util.tobool(GetConVarNumber("fuck_esp_dlight"))
ESP_crosshair = GetConVarNumber("fuck_esp_crosshair")
ESP_gm = util.tobool(GetConVarNumber("fuck_gm_ttt_trai"))
bunny = util.tobool(GetConVarNumber("fuck_move_bunnyhop"))

function MainMenuSelect()
local HackMenu = vgui.Create( "HFrame" )
HackMenu:SetPos(904,0 )
HackMenu:SetSize( 120, 767 )
HackMenu:SetTitle( "F.U.C.K Hack 0.2" )
HackMenu:ShowCloseButton( true )
HackMenu:SetVisible( true )
HackMenu:SetDraggable( false)
HackMenu:MakePopup()

local B1 = vgui.Create( "HButton" )
B1:SetParent( HackMenu ) -- Set parent to our "DermaPanel"
B1:SetText( "~Aimbot~" )
B1:SetPos( 10, 75)
B1:SetSize( 100, 25 )
B1.DoClick = function ()
		RunConsoleCommand("aa_menu")
end

local B2 = vgui.Create( "HButton" )
B2:SetParent( HackMenu ) -- Set parent to our "DermaPanel"
B2:SetText( "~Esp~" )
B2:SetPos( 10, 105)
B2:SetSize( 100, 25 )
B2.DoClick = function ()
		RunConsoleCommand("va_menu")
end

local B3 = vgui.Create( "HButton" )
B3:SetParent( HackMenu ) -- Set parent to our "DermaPanel"
B3:SetText( "~Playerinfo~" )
B3:SetPos( 10, 135)
B3:SetSize( 100, 25 )
B3.DoClick = function ()
		RunConsoleCommand("fuck_plyinfo")
end

local B4 = vgui.Create( "HButton" )
B4:SetParent( HackMenu ) -- Set parent to our "DermaPanel"
B4:SetText( "~Stats~" )
B4:SetPos( 10, 165)
B4:SetSize( 100, 25 )
B4.DoClick = function ()
		RunConsoleCommand("fuck_stats")
end
local B5 = vgui.Create( "HButton" )
B5:SetParent( HackMenu ) -- Set parent to our "DermaPanel"
B5:SetText( "~Spam~" )
B5:SetPos( 10, 195)
B5:SetSize( 100, 25 )
B5.DoClick = function ()
		RunConsoleCommand("fuck_spam")
end
local B6 = vgui.Create( "HButton" )
B6:SetParent( HackMenu ) -- Set parent to our "DermaPanel"
B6:SetText( "~Crapy Test Panel~" )
B6:SetPos( 10, 225)
B6:SetSize( 100, 25 )
B6.DoClick = function ()
		RunConsoleCommand("fuck_test")
end
local B7 = vgui.Create( "HButton" )
B7:SetParent( HackMenu ) -- Set parent to our "DermaPanel"
B7:SetText( "~ESP SETTINGS~" )
B7:SetPos( 10, 255)
B7:SetSize( 100, 25 )
B7.DoClick = function ()
		RunConsoleCommand("fuck_esp_vgui")
end
end
concommand.Add("fuck_main",MainMenuSelect)  

function testp()
local TP = vgui.Create( "HRadar" )
TP:SetPos( 250,250 )
TP:SetSize( 500, 250 )
TP:SetTitle( "TEST" )
TP:ShowCloseButton( true )
TP:SetVisible( true )
TP:MakePopup()
end
concommand.Add("fuck_test",testp) 

function Spamtest()
local DermaPanel = vgui.Create( "HFrame" )
DermaPanel:SetPos( 250,250 )
DermaPanel:SetSize( 500, 250 )
DermaPanel:SetTitle( "Spam Menu" )
DermaPanel:ShowCloseButton( true )
DermaPanel:SetVisible( true )
DermaPanel:MakePopup()
 
local DermaText = vgui.Create( "DTextEntry", DermaPanel )
DermaText:SetPos( 20,25 )
DermaText:SetTall( 20 )
DermaText:SetWide( 450 )
DermaText:SetEnterAllowed( true )
DermaText.OnEnter = function()
     file.Write("my_mod/data.txt", ""..DermaText:GetValue().."") 
end

local DermaButton = vgui.Create( "HButton" )
DermaButton:SetParent( DermaPanel ) -- Set parent to our "DermaPanel"
DermaButton:SetText( "say it    " )
DermaButton:SetPos( 25, 50 )
DermaButton:SetSize( 100, 25 )
DermaButton.DoClick = function ()
if file.Exists("my_mod/data.txt") then
    local text = file.Read("my_mod/data.txt")
		timer.Create("timer1", 2, 0,RunConsoleCommand,"say",""..text.."") 
	end
end

local DermaButton2 = vgui.Create( "HButton" )
DermaButton2:SetParent( DermaPanel ) -- Set parent to our "DermaPanel"
DermaButton2:SetText( "STOP IT    " )
DermaButton2:SetPos( 25, 75)
DermaButton2:SetSize( 100, 25 )
DermaButton2.DoClick = function ()
		timer.Destroy("timer1")
	end

local Killmenu = vgui.Create( "HButton" )
Killmenu:SetParent( DermaPanel ) -- Set parent to our "DermaPanel"
Killmenu:SetText( "STATS" )
Killmenu:SetPos( 25, 125)
Killmenu:SetSize( 100, 25 )
Killmenu.DoClick = function ()
		RunConsoleCommand("fuck_killtext")
	end
end
concommand.Add("fuck_spam",Spamtest)    


function PlayerInfoBox()

local PlayerBox = vgui.Create( "HFrame" )
PlayerBox:SetPos( 500,500 )
PlayerBox:SetSize( 300, 250 )
PlayerBox:SetTitle( "PlayerInfo" )
PlayerBox:ShowCloseButton( true )
PlayerBox:SetVisible( true )
PlayerBox:MakePopup()


local Plylist = vgui.Create( "DListView", PlayerBox )
Plylist:SetPos( 10,25 )
Plylist:SetSize(270, 220)
Plylist:AddColumn("Name")
Plylist:AddColumn("Kills")
Plylist:AddColumn("Deaths")
Plylist:AddColumn("Health")

for k, ply in pairs(player.GetAll()) do
Plylist:AddLine(ply:Nick(),ply:Frags(),ply:Deaths(),ply:Health()) 
	end
end

concommand.Add("fuck_plyinfo",PlayerInfoBox)  

function Radar()

end

concommand.Add("fuck_radar",Radar)  

function Crosshair()
X = ScrW() / 2
Y = ScrH() / 2
Choose = 0

local CrosshairC = vgui.Create( "HFrame" )
CrosshairC:SetPos( 500,500 )
CrosshairC:SetSize( 350, 250 )
CrosshairC:SetTitle( "Crosshair" )
CrosshairC:ShowCloseButton( true )
CrosshairC:SetVisible( true )
CrosshairC:MakePopup()

color = vgui.Create( "DColorMixer",CrosshairC)
color:SetSize( 80, 100)
color:SetPos( 150,150  )
color:SetColor(Color(255,0,255))
 --color2=color:GetColor()
--print(color2.r,color2.g,color2.r)


local Cross1 = vgui.Create( "DButton" )
Cross1:SetParent( CrosshairC ) 
Cross1:SetText( "Crosshair1" )
Cross1:SetPos( 25, 25)
Cross1:SetSize( 100, 100 )
Cross1.DoClick = function()

	end
	
	local Cross2 = vgui.Create( "DButton" )
Cross2:SetParent( CrosshairC ) 
Cross2:SetText( "Crosshair2" )
Cross2:SetPos( 130, 25)
Cross2:SetSize( 100, 100 )
Cross2.DoClick = function()



	end
	
	local Cross3 = vgui.Create( "DButton" )
Cross3:SetParent( CrosshairC ) 
Cross3:SetText( "Crosshair3" )
Cross3:SetPos( 235, 25)
Cross3:SetSize( 100, 100 )
Cross3.DoClick = function()


	end
	save = vgui.Create( "DButton" )
save:SetParent( CrosshairC ) 
save:SetText( "Save" )
save:SetPos( 450, 250)
save:SetSize( 100, 100 )
save.DoClick = function()
color2=color:GetColor()
end
end
concommand.Add("fuck_crosshair",Crosshair)  

function Drawcross()
if (GetConVarNumber("fuck_esp_crosshair") == 0) then return end
if (GetConVarNumber("fuck_esp_crosshair") == 1) then
		surface.SetDrawColor( 43, 43, 255, 255)
		surface.DrawRect((ScrW() / 2) - 25,(ScrH() /2 ),50,1)
		surface.DrawRect((ScrW() / 2),(ScrH() /2 )- 25,1,50)
		surface.DrawRect((ScrW() / 2) - 10,(ScrH() /2 ),20,1)
		surface.DrawRect((ScrW() / 2),(ScrH() /2 )-10,1,20)
		surface.SetDrawColor( 0, 255, 0, 255)
		surface.DrawRect((ScrW() / 2),(ScrH() /2 )-5,1,11)
		surface.DrawRect((ScrW() / 2) - 5,(ScrH() /2 ),11,1)
elseif (GetConVarNumber("fuck_esp_crosshair") == 2) then
		surface.SetDrawColor( 255, 0, 0, 255)
		surface.DrawRect((ScrW() / 2) - 9,(ScrH() /2 ),9,2)
		surface.DrawRect((ScrW() / 2) +2,(ScrH() /2 ),9,2)
		surface.DrawRect((ScrW() / 2),(ScrH() /2 )-9,2,9)
		surface.DrawRect((ScrW() / 2),(ScrH() /2 )+2,2,9)
		surface.DrawRect((ScrW() / 2),(ScrH() /2 ),2,2)
elseif (GetConVarNumber("fuck_esp_crosshair") == 3) then
		surface.SetDrawColor( 0, 0, 0, 255)
		surface.DrawRect((ScrW() / 2) - 14,(ScrH() /2 ),11,2)
		surface.DrawRect((ScrW() / 2) + 5,(ScrH() /2 ),11,2)
		surface.DrawRect((ScrW() / 2),(ScrH() /2 )-14,2,11)
		surface.DrawRect((ScrW() / 2),(ScrH() /2 )+5,2,11)
		surface.DrawRect((ScrW() / 2),(ScrH() /2 ),2,2)
elseif (GetConVarNumber("fuck_esp_crosshair") == 4) then
		surface.SetDrawColor( 0, 255, 0, 255)
		surface.DrawRect((ScrW() / 2) - 25,(ScrH() /2 ),50,1)
		surface.DrawRect((ScrW() / 2),(ScrH() /2 )-25,1,50)
		surface.DrawRect((ScrW() / 2) - 10,(ScrH() /2 ),20,1)
		surface.DrawRect((ScrW() / 2),(ScrH() /2 )-10,1,20)
end
end

function Chatbox()

local ChatFrame = vgui.Create( "HFrame" )
ChatFrame:SetPos( 500,500 )
ChatFrame:SetSize( 300, 500 )
ChatFrame:SetTitle( "ChatBox" )
ChatFrame:ShowCloseButton( true )
ChatFrame:SetVisible( true )
ChatFrame:MakePopup()

local ChatM = vgui.Create( "DListView", ChatFrame ) 
ChatM:Center() 
ChatM:SizeToContents() 
ChatM:AddColumn( "Chat" ) 

end



concommand.Add("fuck_chatbox",Chatbox) 

function Esptestpanel()
local CHFrame = vgui.Create( "HFrame" )
CHFrame:SetPos( 500,500 )
CHFrame:SetSize( 300, 500 )
CHFrame:SetTitle( "Esp_settings" )
CHFrame:ShowCloseButton( true )
CHFrame:SetVisible( true )
CHFrame:MakePopup()

local check = vgui.Create( "DCheckBoxLabel", CHFrame )
check:SetPos( 10,50 )
check:SetText( "BOX ESP" )
check:SetConVar( "fuck_esp_box" ) -- ConCommand must be a 1 or 0 value
check:SetValue( tostring(GetConVarNumber("fuck_esp_box")) )
check:SetSize( 100, 50 )

local check1 = vgui.Create( "DCheckBoxLabel", CHFrame )
check1:SetPos( 10,65 )
check1:SetText( "NAME ESP" )
check1:SetConVar( "fuck_esp_name" ) -- ConCommand must be a 1 or 0 value
check1:SetValue( tostring(GetConVarNumber("fuck_esp_name")) )
check1:SetSize( 100, 50 )

local check2 = vgui.Create( "DCheckBoxLabel", CHFrame )
check2:SetPos( 10, 80 )
check2:SetText( "HEALTH ESP" )
check2:SetConVar( "fuck_esp_Health" ) -- ConCommand must be a 1 or 0 value
check2:SetValue( tostring(GetConVarNumber("fuck_esp_Health")) )
check2:SetSize( 100, 50 )

local check3 = vgui.Create( "DCheckBoxLabel", CHFrame )
check3:SetPos( 10, 95 )
check3:SetText( "ARMOR ESP" )
check3:SetConVar( "fuck_esp_armor" ) -- ConCommand must be a 1 or 0 value
check3:SetValue( tostring(GetConVarNumber("fuck_esp_armor")) )
check3:SetSize( 100, 50 )

local check4 = vgui.Create( "DCheckBoxLabel", CHFrame )
check4:SetPos( 10, 110 )
check4:SetText( "DISTANCE ESP" )
check4:SetConVar( "fuck_esp_distance" ) -- ConCommand must be a 1 or 0 value
check4:SetValue( tostring(GetConVarNumber("fuck_esp_distance")) )
check4:SetSize( 100, 50 )

local check5 = vgui.Create( "DCheckBoxLabel", CHFrame )
check5:SetPos( 10, 125 )
check5:SetText( "BARREL ESP" )
check5:SetConVar( "fuck_esp_barrel" ) -- ConCommand must be a 1 or 0 value
check5:SetValue( tostring(GetConVarNumber("fuck_esp_barrel")) )
check5:SetSize( 100, 50 )
end 
concommand.Add("fuck_esp_vgui",Esptestpanel) 
/*

Taken from melonracer to to own stuff

*/
function SplashSlow( name )

	local sprite = CreateSprite( Material(name) )
	
	sprite:SetTerm( 1 )
	sprite:SetPos( ScrW()*0.5, ScrH() * 0.3 )
	sprite:SetSize( 10, 10 )
	sprite:SetColor( Color(0,0,0,255) )
	
	sprite:SizeTo( ScrH() * 0.4, ScrH() * 0.4, 0.3, 0 )
	sprite:ColorTo( Color(255, 255, 255, 255), 0.3, 0 )
	
	sprite:ColorTo( Color(255, 255, 255, 0), 0.5, 0.5 )
	sprite:MoveTo( ScrW()*0.5, ScrH() * 0.1, 0.5, 0.5 )
	sprite:SizeTo( ScrH() * 0.3, ScrH() * 0.7, 0.5, 0.5 )
	
	SplashFade( name )
	surface.SetTextColor( 200, 200, 200, 255 )
surface.SetTextPos( 100, 200 ) 
surface.DrawText( "This is a text example" )
end

function SplashFade( name )

	local sprite = CreateSprite( Material(name) )
	sprite:SetTerm( 0.5 )
	sprite:SetPos( ScrW()*0.5, ScrH() * 0.3 )
	sprite:SetSize( 10, 10 )
	sprite:SetColor( Color(255,255,255,255) )
	
	sprite:SizeTo( ScrH() * 0.6, ScrH() * 0.6, 0.5, 0 )
	sprite:ColorTo( Color(255, 255, 255, 0), 0.5, 0 )
	
end

//

function killtext(vitim,weapon,killer)
if Killer:IsPlayer() then
	local text = "my_mod/killtext.txt"
		if !file.Exists(text) then
			Msg("say HAHA KILLED by me")
		else
			RunConsoleCommand("say",""..text.."")
		end
	end
end

function QuakesoundsDisplay(frag)

frag = LocalPlayer():Frags()
if (frag == 5) then
draw.DrawText("BOOMHEADSHOT", "Quakefont",ScrW() / 2 ,160, Color(255,255,255,255),1) end
if (frag == 10) then 
draw.DrawText("DOMINATING", "Quakefont",ScrW() / 2 ,160, Color(255,255,255,255),1) end
if (frag == 15) then 
draw.DrawText("HEADHUNTER", "Quakefont",ScrW() / 2 ,160, Color(255,255,255,255),1) end
if (frag == 25) then 
draw.DrawText("MULTIKILL", "Quakefont",ScrW() / 2 ,160, Color(255,255,255,255),1) end
if (frag == 35) then 
draw.DrawText("MONSTERKILL", "Quakefont",ScrW() / 2 ,160, Color(255,255,255,255),1) end
if (frag == 45) then 
draw.DrawText("RAMPAGE", "Quakefont",ScrW() / 2 ,160, Color(255,255,255,255),1) end
if (frag == 55) then 
draw.DrawText("HUMILIATION", "Quakefont",ScrW() / 2 ,160, Color(255,255,255,255),1) end
if (frag == 65) then 
draw.DrawText("KILLINGSPREE", "Quakefont",ScrW() / 2 ,160, Color(255,255,255,255),1) end
if (frag == 100) then 
draw.DrawText("LUDICROUSKILL", "Quakefont",ScrW() / 2 ,160, Color(255,255,255,255),1) end
if (frag == 125) then 
draw.DrawText("UNSTOPPABLE", "Quakefont",ScrW() / 2 ,160, Color(255,255,255,255),1) end
if (frag == 150) then 
draw.DrawText("ULTRAKILL", "Quakefont",ScrW() / 2 ,160, Color(255,255,255,255),1) end
if (frag == 200) then 
draw.DrawText("HOLYSHIT", "Quakefont",ScrW() / 2 ,160, Color(255,255,255,255),1) end
if (frag == 250) then
draw.DrawText("WICKEDSICK", "Quakefont",ScrW() / 2 ,160, Color(255,255,255,255),1) end
if (frag == 300) then 
draw.DrawText("GODLIKE", "Quakefont",ScrW() / 2 ,160, Color(255,255,255,255),1) end


end


function quakesounds(frag)

frag = LocalPlayer():Frags()
if (frag == 5) then
timer.Create("Head", 0.1, 1,surface.PlaySound,"nquake/boomheadshot.mp3") 
 return "Boomheadshot" end
if (frag == 10) then 
timer.Create("DOM", 0.1, 1,surface.PlaySound,"nquake/dominating.mp3") 
return "Dominating" end
if (frag == 15) then 
timer.Create("HH", 0.1, 1,surface.PlaySound,"nquake/headhunter.wav") 
return "Headhunter" end
if (frag == 25) then 
timer.Create("Mul", 0.1, 1,surface.PlaySound,"nquake/multikill.mp3") 
return "Multikill" end
if (frag == 35) then
timer.Create("MON", 0.1, 1,surface.PlaySound,"nquake/monsterkill.mp3") 
 return "Monsterkill" end
if (frag == 45) then 
timer.Create("RA", 0.1, 1,surface.PlaySound,"nquake/rampage.mp3") 
return "Rampage" end
if (frag == 55) then
timer.Create("HU", 0.1, 1,surface.PlaySound,"nquake/humiliation.mp3") 
 return "Humiliation" end
if (frag == 65) then 
timer.Create("Kil", 0.1, 1,surface.PlaySound,"nquake/killingspree.mp3") 
return "Killingspree" end
if (frag == 100) then 
timer.Create("LUD", 0.1, 1,surface.PlaySound,"nquake/ludicrouskill.mp3") 
return "Ludicrouskill" end
if (frag == 125) then 
timer.Create("UNS", 0.1, 1,surface.PlaySound,"nquake/unstoppable.mp3") 
return "Unstoppable" end
if (frag == 150) then 
timer.Create("ULT", 0.1, 1,surface.PlaySound,"nquake/ultrakill.mp3") 
return "Ultrakill" end
if (frag == 200) then
timer.Create("HOL", 0.1, 1,surface.PlaySound,"nquake/holyshit.mp3") 
 return "Holyshit" end
if (frag == 250) then 
timer.Create("WIC", 0.1, 1,surface.PlaySound,"nquake/wickedsick.mp3") 
return "Wickedsick" end
if (frag == 300) then 
timer.Create("GOD", 0.1, 1,surface.PlaySound,"nquake/godlike.mp3") 
return "Godlike" end

return ""

end

function KDRmath(kdrm)
	kdrm = LocalPlayer():Frags() / LocalPlayer():Deaths()
		return kdrm
end

function hp(hit)
hit = LocalPlayer():Health()
	return hit
end

function Killpanel()

local killp = vgui.Create("HFrame")
	  killp:SetPos(0,ScrH()/2)
	  killp:SetSize(320,175)
	  killp:SetTitle("Killtext")
	  killp:ShowCloseButton( true )
	  killp:SetVisible( true )
	  killp:MakePopup()

local Messageboard = vgui.Create( "DTextEntry", killp )
	  Messageboard:SetPos( 20,25 )
	  Messageboard:SetTall( 20 )
	  Messageboard:SetWide( 160 )
	  Messageboard:SetEnterAllowed( true )
	  Messageboard.OnEnter = function()
			file.Write("my_mod/killtext.txt", ""..Messageboard:GetValue().."") 
	end
end

concommand.Add("fuck_killtext",Killpanel)

function stats()

local Stats = vgui.Create( "HFrame" )
Stats:SetPos(0,ScrH()/2 )
Stats:SetSize( 320, 175 )
Stats:SetTitle( "Stats von "..LocalPlayer():Nick().."" )
Stats:ShowCloseButton( true )
Stats:SetVisible( true )
Stats:MakePopup()

HP = vgui.Create("DLabel", Stats)
HP:SetText("Health: "..hp().."")
HP:SetPos(25,50)

Level = vgui.Create("DLabel", Stats)
Level:SetText("Level: "..quakesounds().."")
Level:SetPos(25,75)
Level:SetSize(60,15)
Level:SizeToContents()

Kills = vgui.Create("DLabel", Stats)
Kills:SetText("Kills: "..LocalPlayer():Frags().."")
Kills:SetPos(25,100)

Deaths = vgui.Create("DLabel", Stats)
Deaths:SetText("Deaths: "..LocalPlayer():Deaths().."")
Deaths:SetPos(25,125)

Deaths = vgui.Create("DLabel", Stats)
Deaths:SetText("KDR: "..KDRmath().."")
Deaths:SetPos(25,150)

end

concommand.Add("fuck_stats",stats) 

// Drawing stuff

function HPbox()
for _, ply in pairs(player.GetAll()) do
local wide = ply:Health()
if ply:Health() > 100 then
local wide = 100
return wide
		end
	end
end

function AddText( playerindex, playername, text, messagetype)
ChatM:AddLine(playername .. " said: '" .. text .. "'.")
end

function Leveld()
		draw.RoundedBox(6,ScrW() / 2 - 102,35,204,24, Color(0,0,0,255)) //Schwarze Umrandung
        draw.RoundedBox(6,ScrW() / 2 - 100,37,200,20,Color(153,204,204,255))
	--	draw.RoundedBox(6,ScrW() / 2 - 100,37,LocalPlayer():Frags()/200 +1,20,Color(0,0,255,255))
		
end

function ToScreen(vWorld)
	local vsScreen = vWorld:ToScreen()
	return Vector(vsScreen.x, vsScreen.y, 0)
end

function LineToScreen(vStart, vEnd)
	local dotStart = cache.vLookVector:DotProduct(vStart - cache.vLookClipPos)
	local dotEnd = cache.vLookVector:DotProduct(vEnd - cache.vLookClipPos)
	
	if dotStart > 0 and dotEnd > 0 then
		return ToScreen(vStart), ToScreen(vEnd)
	elseif dotStart > 0 or dotEnd > 0 then
		local vLength = vEnd - vStart
		local vIntersect = vStart + vLength * ((cache.vLookClipPos:DotProduct(cache.vLookVector) - vStart:DotProduct(cache.vLookVector)) / vLength:DotProduct(cache.vLookVector))
		
		if dotStart <= 0 then
			return ToScreen(vIntersect), ToScreen(vEnd)
		else
			return ToScreen(vStart), ToScreen(vIntersect)
		end
	end
end
/*
		surface.DrawLine(pos.x - 10,pos.y +10,pos.x + 10,pos.y + 10)
		surface.DrawLine(pos.x - 10,pos.y +10,pos.x - 10,pos.y - 10)
		surface.DrawLine(pos.x + 10,pos.y +10,pos.x + 10,pos.y - 10)
		surface.DrawLine(pos.x - 10,pos.y -10,pos.x + 10,pos.y - 10)
*/

--		local vsX, vsY = LineToScreen(vX, vY)
	--	if (vsX) then DrawScreenLine(vsX + vsOffset, vsY + vsOffset) end
function boxesp()

for _, ply in pairs(player.GetAll()) do
local pos =( ply:GetPos() + Vector( 0, 0, 40 ))
pos = pos:ToScreen()
obbmin = ( ply:GetPos() + ( ply:GetRight() * -25 ) ):ToScreen()
obbmax = ( ply:GetPos() + ( ply:GetRight() * 21 ) + ( ply:GetUp() * 72) ):ToScreen()
if (GetConVarNumber("fuck_esp_box") == 0) then return end
if(GetConVarNumber("fuck_esp_box") == 1) then
	if ply == LocalPlayer() then
	Msg("")
elseif ply:Team() == LocalPlayer():Team() and LocalPlayer():Alive() then
		surface.SetDrawColor(255,0,255,255)
			surface.DrawLine( obbmin.x, obbmax.y, obbmax.x, obbmax.y )--oben
			surface.DrawLine( obbmin.x, obbmin.y, obbmin.x, obbmax.y )
			surface.SetDrawColor(255,0,0,255)
			surface.DrawLine( obbmax.x, obbmax.y, obbmax.x, obbmin.y )
			surface.DrawLine( obbmin.x, obbmin.y, obbmax.x, obbmin.y )
elseif ply:Team() ~= LocalPlayer():Team() and GetConVarNumber("fuck_esp_box") == 1 and LocalPlayer():Alive() then
	surface.SetDrawColor(255,0,0,255)
			surface.DrawLine( obbmin.x, obbmax.y, obbmax.x, obbmax.y )
			surface.SetDrawColor(0,0,0,255)
			surface.DrawLine( obbmin.x, obbmin.y, obbmin.x, obbmax.y )
			surface.DrawLine( obbmax.x, obbmax.y, obbmax.x, obbmin.y )
			surface.DrawLine( obbmin.x, obbmin.y, obbmax.x, obbmin.y )
	--do nothing				
					end
				end
			end
if(	GetConVarNumber("fuck_show_xy") == 1) then
	if ply == LocalPlayer() then
	Msg("")
	else
	draw.DrawText("X: "..obbmin.x.." Y:"..obbmin.y.."", "AimBotSmall", 150,200, Color(255,0,255,255),1)
end
end
end
function nameesp()
for _, ply in pairs(player.GetAll()) do
local pos =( ply:GetPos() + Vector( 0, 0, 40 ) )
pos = pos:ToScreen()
spos = ply:GetShootPos():ToScreen()
obbmin = ( ply:GetPos() + ( ply:GetRight() * -25 ) ):ToScreen()
obbmax = ( ply:GetPos() + ( ply:GetRight() * 21 ) + ( ply:GetUp() * 72) ):ToScreen()
if(GetConVarNumber("fuck_esp_name") == 0) then return end
if(GetConVarNumber("fuck_esp_name") == 1) then
	if ply == LocalPlayer() then
	Msg("")
elseif ply:Team() ~= LocalPlayer():Team() then
	surface.SetDrawColor(255,255,255,255)
	draw.DrawText(""..ply:Nick().."", "AimBotSmall", spos.x,spos.y + 50 , Color(255,255,255,255),1)
elseif ply:Team() == LocalPlayer():Team() and GetConVarNumber("fuck_esp_enemys_only") == 1 then
	surface.SetDrawColor(255,255,255,255)
	draw.DrawText(""..ply:Nick().."", "AimBotSmall", spos.x,spos.y + 50, Color(255,255,255,255),1)
	--Do Nothing
					end
				end
			end
		end
 --health,armor,weapon,stats,id,entity,distance,info,aimatme,barrel
 --		surface.DrawRect(pos.x + 20 , pos.y - 5, ply:Health(), 5 )
 function healthesp()
 for _, ply in pairs(player.GetAll()) do
local pos =( ply:GetPos() + Vector( 0, 0, 40 ) )
pos = pos:ToScreen()
if(GetConVarNumber("fuck_esp_Health") == 0) then return end
if(GetConVarNumber("fuck_esp_Health") == 1) then
	if ply == LocalPlayer() then
	Msg("")
	elseif ply:Team() ~= LocalPlayer():Team() then
		surface.SetDrawColor(255,0,255,255)
		draw.DrawText("HP: "..ply:Health().."", "AimBotSmall", pos.x + 30,pos.y -5, Color(255,0,255,255),1)
		elseif ply:Team() == LocalPlayer():Team() then
		surface.SetDrawColor(255,0,255,255)
	    draw.DrawText("HP: "..ply:Health().."", "AimBotSmall", pos.x + 30,pos.y -5, Color(255,0,255,255),1)

			end
		end
	end
end

 function armoresp()
  for _, ply in pairs(player.GetAll()) do
local pos =( ply:GetPos() + Vector( 0, 0, 40 ) )
pos = pos:ToScreen()
if(GetConVarNumber("fuck_esp_armor") == 0) then return end
if(GetConVarNumber("fuck_esp_armor") == 1) then
if ply == LocalPlayer() then
Msg("")
	elseif ply:Team() ~= LocalPlayer():Team() then
		draw.DrawText("Armor: "..ply:Armor().."", "AimBotSmall", pos.x + 30,pos.y , Color(255,0,255,255),1)
		elseif ply:Team() == LocalPlayer():Team() then
		surface.SetDrawColor(255,0,255,255)
		draw.DrawText("Armor: "..ply:Armor().."", "AimBotSmall", pos.x + 30,pos.y + 4, Color(255,0,255,255),1)
		
			end
		end
	end
end
	
 function weaponesp()
 
 end
 
 function statsesp()
 
 end
 
 function idesp()
    for _, ply in pairs(player.GetAll()) do
local pos =( ply:GetPos() + Vector( 0, 0, 40 ) )
pos = pos:ToScreen()
end
 end
 
 function entityesp()//buggy zeigt waffen des spielers
     for _, ply in pairs(player.GetAll()) do
 for _, ent in pairs( ents.GetAll() ) do
 prange = ply:GetPos()
 model = ent:GetModel()
 epos = (ent:GetPos() + Vector( 0, 0, 10 ))
 entpos = epos:ToScreen()
 weapon = ply:GetWeapons()
--if ent:IsPlayerHolding() == true then return end
if GetConVarNumber("fuck_esp_entity") == 0 then return end
if GetConVarNumber("fuck_esp_entity") == 1 then
if weapon == "weapon_ak47" then
Msg("find")
elseif (model == "models/weapons/w_pist_usp.mdl") then// CSS WEAPONS
		surface.SetDrawColor(255,0,255,255)
		draw.DrawText("F.U.C.K USP", "Quakefont", entpos.x+15,entpos.y + 10, Color(255,0,0,255),1)
elseif (model == "models/weapons/w_pist_usp_silencer.mdl") then
		surface.SetDrawColor(255,0,255,255)
		draw.DrawText("F.U.C.K USP sil.", "Quakefont", entpos.x+15,entpos.y + 10, Color(255,0,0,255),1)
elseif (model == "models/weapons/w_rif_ak47.mdl") then
		surface.SetDrawColor(255,0,255,255)
		draw.DrawText("F.U.C.K Ak47", "Quakefont", entpos.x+15,entpos.y + 10, Color(255,0,0,255),1)
elseif (model == "models/weapons/w_pist_glock18.mdl" and ent:IsOnGround()) then
		surface.SetDrawColor(255,0,255,255)
		draw.DrawText("F.U.C.K GLOCK", "Quakefont", entpos.x+15,entpos.y + 10, Color(255,0,0,255),1)
elseif (model == "models/weapons/w_smg_tmp.mdl" and ent:IsOnGround()) then
		surface.SetDrawColor(255,0,255,255)
		draw.DrawText("F.U.C.K TMP", "Quakefont", entpos.x+15,entpos.y + 10, Color(255,0,0,255),1)
elseif (model == "models/weapons/w_rif_aug.mdl" and ent:IsOnGround()) then
		surface.SetDrawColor(255,0,255,255)
		draw.DrawText("F.U.C.K AUG", "Quakefont", entpos.x+15,entpos.y + 10, Color(255,0,0,255),1)
elseif (model == "models/weapons/w_pist_deagle.mdl" and ent:IsOnGround()) then
		surface.SetDrawColor(255,0,255,255)
		draw.DrawText("F.U.C.K DEAGLE", "Quakefont", entpos.x+15,entpos.y + 10, Color(255,0,0,255),1)
elseif (model == "models/weapons/w_eq_fraggrenade.mdl" and ent:IsOnGround()) then
		surface.SetDrawColor(255,0,255,255)
		draw.DrawText("F.U.C.K HE-GRENADE", "Quakefont", entpos.x+15,entpos.y + 10, Color(255,0,0,255),1)
elseif (model == "models/weapons/w_eq_fraggrenade_thrown.mdl" and ent:IsOnGround()) then
		surface.SetDrawColor(255,0,255,255)
		draw.DrawText("F.U.C.K HE-GRENADE", "Quakefont", entpos.x+15,entpos.y + 10, Color(255,0,0,255),1)
elseif (model == "models/weapons/w_eq_flashbang_thrown.mdl" and ent:IsOnGround()) then
		surface.SetDrawColor(255,0,255,255)
		draw.DrawText("F.U.C.K FLASHBANG", "Quakefont", entpos.x+15,entpos.y + 10, Color(255,0,0,255),1)
elseif (model == "models/weapons/w_eq_flashbang.mdl" and ent:IsOnGround()) then
		surface.SetDrawColor(255,0,255,255)
		draw.DrawText("F.U.C.K FLASHBANG", "Quakefont", entpos.x+15,entpos.y + 10, Color(255,0,0,255),1)
elseif (model == "models/weapons/w_snip_g3sg1.mdl" and ent:IsOnGround()) then
		surface.SetDrawColor(255,0,255,255)
		draw.DrawText("F.U.C.K G3SG1", "Quakefont", entpos.x+15,entpos.y + 10, Color(255,0,0,255),1)
elseif (model == "models/weapons/w_knife_ct.mdl" and ent:IsOnGround()) then
		surface.SetDrawColor(255,0,255,255)
		draw.DrawText("F.U.C.K KNIFE", "Quakefont", entpos.x+15,entpos.y + 10, Color(255,0,0,255),1)
elseif (model == "models/weapons/w_knife_t.mdl" and ent:IsOnGround()) then
		surface.SetDrawColor(255,0,255,255)
		draw.DrawText("F.U.C.K KNIFE", "Quakefont", entpos.x+15,entpos.y + 10, Color(255,0,0,255),1)
elseif (model == "models/weapons/w_shot_m3super90.mdl" and ent:IsOnGround()) then
		surface.SetDrawColor(255,0,255,255)
		draw.DrawText("F.U.C.K M3", "Quakefont", entpos.x+15,entpos.y + 10, Color(255,0,0,255),1)
elseif (model == "models/weapons/w_smg_mac10.mdl" and ent:IsOnGround()) then
		surface.SetDrawColor(255,0,255,255)
		draw.DrawText("F.U.C.K MAC10", "Quakefont", entpos.x+15,entpos.y + 10, Color(255,0,0,255),1)
elseif (model == "models/weapons/w_smg_p90.mdl" and ent:IsOnGround()) then
		surface.SetDrawColor(255,0,255,255)
		draw.DrawText("F.U.C.K P90", "Quakefont", entpos.x+15,entpos.y + 10, Color(255,0,0,255),1)
elseif (model == "models/weapons/w_snip_scout.mdl" and ent:IsOnGround()) then
		surface.SetDrawColor(255,0,255,255)
		draw.DrawText("F.U.C.K SCOUT", "Quakefont", entpos.x+15,entpos.y + 10, Color(255,0,0,255),1)
elseif (model == "models/weapons/w_snip_sg550.mdl" and ent:IsOnGround()) then
		surface.SetDrawColor(255,0,255,255)
		draw.DrawText("F.U.C.K SG550", "Quakefont", entpos.x+15,entpos.y + 10, Color(255,0,0,255),1)
elseif (model == "models/weapons/w_eq_smokegrenade.mdl" and ent:IsOnGround()) then
		surface.SetDrawColor(255,0,255,255)
		draw.DrawText("F.U.C.K SMOKEGRENADE", "Quakefont", entpos.x+15,entpos.y + 10, Color(255,0,0,255),1)
elseif (model == "models/weapons/w_eq_smokegrenade_thrown.mdl" and ent:IsOnGround()) then
		surface.SetDrawColor(255,0,255,255)
		draw.DrawText("F.U.C.K SMOKEGRENADE", "Quakefont", entpos.x+15,entpos.y + 10, Color(255,0,0,255),1)
elseif (model == "models/weapons/w_smg_ump45.mdl" and ent:IsOnGround()) then
		surface.SetDrawColor(255,0,255,255)
		draw.DrawText("F.U.C.K UMP45", "Quakefont", entpos.x+15,entpos.y + 10, Color(255,0,0,255),1)
elseif (model == "models/weapons/w_snip_awp..mdl" and ent:IsOnGround()) then
		surface.SetDrawColor(255,0,255,255)
		draw.DrawText("F.U.C.K AWP", "Quakefont", entpos.x+15,entpos.y + 10, Color(255,0,0,255),1)
elseif (model == "models/weapons/w_pist_elite.mdl" and ent:IsOnGround()) then
		surface.SetDrawColor(255,0,255,255)
		draw.DrawText("F.U.C.K DUALIES", "Quakefont", entpos.x+15,entpos.y + 10, Color(255,0,0,255),1)
elseif (model == "models/weapons/w_pist_elite_dropped.mdl" and ent:IsOnGround()) then
		surface.SetDrawColor(255,0,255,255)
		draw.DrawText("F.U.C.K DUALIES", "Quakefont", entpos.x+15,entpos.y + 10, Color(255,0,0,255),1)
elseif (model == "models/weapons/w_rif_famas.mdl" and ent:IsOnGround()) then
		surface.SetDrawColor(255,0,255,255)
		draw.DrawText("F.U.C.K FAMAS", "Quakefont", entpos.x+15,entpos.y + 10, Color(255,0,0,255),1)
elseif (model == "models/weapons/w_pist_fiveseven.mdl" and ent:IsOnGround()) then
		surface.SetDrawColor(255,0,255,255)
		draw.DrawText("F.U.C.K FIVESEVEN", "Quakefont", entpos.x+15,entpos.y + 10, Color(255,0,0,255),1)
elseif (model == "models/weapons/w_rif_galil.mdl" and ent:IsOnGround()) then
		surface.SetDrawColor(255,0,255,255)
		draw.DrawText("F.U.C.K GALIL", "Quakefont", entpos.x+15,entpos.y + 10, Color(255,0,0,255),1)
elseif (model == "models/weapons/w_rif_m4a1_silencer.mdl" and ent:IsOnGround()) then
		surface.SetDrawColor(255,0,255,255)
		draw.DrawText("F.U.C.K M4A1 sil.", "Quakefont", entpos.x+15,entpos.y + 10, Color(255,0,0,255),1)
elseif (model == "models/weapons/w_rif_m4a1.mdl" and ent:IsOnGround()) then
		surface.SetDrawColor(255,0,255,255)
		draw.DrawText("F.U.C.K M4A1", "Quakefont", entpos.x+15,entpos.y + 10, Color(255,0,0,255),1)
elseif (model == "models/weapons/w_smg_mp5..mdl" and ent:IsOnGround()) then
		surface.SetDrawColor(255,0,255,255)
		draw.DrawText("F.U.C.K MP5", "Quakefont", entpos.x+15,entpos.y + 10, Color(255,0,0,255),1)
elseif (model == "models/weapons/w_pist_p228.mdl" and ent:IsOnGround()) then
		surface.SetDrawColor(255,0,255,255)
		draw.DrawText("F.U.C.K P228", "Quakefont", entpos.x+15,entpos.y + 10, Color(255,0,0,255),1)
elseif (model == "models/weapons/w_mach_m249para.mdl" and ent:IsOnGround()) then
		surface.SetDrawColor(255,0,255,255)
		draw.DrawText("F.U.C.K M249", "Quakefont", entpos.x+15,entpos.y + 10, Color(255,0,0,255),1)
elseif (model == "models/weapons/w_rif_sg552.mdl" and ent:IsOnGround()) then
		surface.SetDrawColor(255,0,255,255)
		draw.DrawText("F.U.C.K SG552", "Quakefont", entpos.x+15,entpos.y + 10, Color(255,0,0,255),1)
elseif (model == "models/weapons/w_c4.mdl" and ent:IsOnGround()) then
		surface.SetDrawColor(255,0,255,255)
		draw.DrawText("F.U.C.K C4", "Quakefont", entpos.x+15,entpos.y + 10, Color(255,0,0,255),1)
elseif (model == "models/weapons/w_c4_planted.mdl" and ent:IsOnGround()) then
		surface.SetDrawColor(255,0,255,255)
		draw.DrawText("F.U.C.K C4 pla.", "Quakefont", entpos.x+15,entpos.y + 10, Color(255,0,0,255),1)
elseif (model == "models/weapons/w_shot_xm1014.mdl" and ent:IsOnGround()) then
		surface.SetDrawColor(255,0,255,255)
		draw.DrawText("F.U.C.K XM1014", "Quakefont", entpos.x+15,entpos.y + 10, Color(255,0,0,255),1)
elseif (model == "models/weapons/w_defuser.mdl" and ent:IsOnGround()) then
		surface.SetDrawColor(255,0,255,255)
		draw.DrawText("F.U.C.K DEFUSEKIT", "Quakefont", entpos.x+15,entpos.y + 10, Color(255,0,0,255),1)
		//HL� weapons
	end
	end
end
end
 end
 
 
 function distanceesp()
   for _, ply in pairs(player.GetAll()) do
local pos =( ply:GetPos() + Vector( 0, 0, 40 ) )
pos = pos:ToScreen()
dis = math.floor(ply:GetPos():Distance(LocalPlayer():GetPos()))
if ply == LocalPlayer() then
Msg("")
	elseif ply:Team() ~= LocalPlayer():Team() and GetConVarNumber("fuck_esp_distance") == 1 then
		draw.DrawText("Dist: "..dis.."", "AimBotSmall", pos.x + 30,pos.y + 15 , Color(255,0,255,255),1)
		elseif ply:Team() == LocalPlayer():Team() and GetConVarNumber("fuck_esp_distance") == 1 then
		surface.SetDrawColor(255,0,255,255)
		draw.DrawText("Dist: "..dis.."", "AimBotSmall", pos.x + 30,pos.y + 15, Color(255,0,255,255),1)
 end
 end
 end

--w_rif_ak47.mdl      fuck_esp_entity
 function testpos()
   for _, ply in pairs(player.GetAll()) do
 local hudpos = ply:OBBMaxs()
 hudpos = hudpos:ToScreen()
 if ply == LocalPlayer() then
 Msg("")
 else
 		surface.SetDrawColor(255,0,0,255)
	surface.DrawRect(hudpos , 10, 10, 10 )
		end
	end
 end
 --fuck_esp_aimatme
 function aimatmeesp()
 for _, ply in pairs(player.GetAll()) do
shotpos = ply:GetAimVector()
pos = LocalPlayer():GetPos()
	if(GetConVarNumber("fuck_esp_aimatme") == 0) then return end
	if(GetConVarNumber("fuck_esp_aimatme") == 1) then
	if shotpos == pos and ply:Team() ~= LocalPlayer():Team() then
		draw.DrawText("EIN GEGNER ZIELT AUF DICH", "KDR",ScrW() / 2 ,40, Color(255,0,0,255),1)
		Msg("JKLN")
	else
	---
			end
		end
	end
 end
 
 function barrelesp()
  for _, ply in pairs(player.GetAll()) do
local shotpos = ply:GetAimVector()
local pos = ply:GetPos()+ Vector( 0, 0, 60 ) --+ shotpos
local endpos = pos+(shotpos*160)
endpos = endpos:ToScreen()
shotpos = shotpos:ToScreen()
pos = pos:ToScreen()
if (GetConVarNumber("fuck_esp_barrel") == 0) then return end
if (GetConVarNumber("fuck_esp_barrel") == 1) then
	 if ply != LocalPlayer() then
surface.SetDrawColor(255,0,0,255)
 	 surface.DrawLine( pos.x, pos.y, endpos.x, endpos.y )
else
Msg("")
end
end end
 end
 /// ttt
/* function plymeta:IsActiveTraitor() 
   return self.is_traitor and self:IsTerror() and GAMEMODE.round_state == ROUND_ACTIVE
end
 
local pos = self.Owner:GetShootPos()
local ang = self.Owner:GetAimVector()
local tracedata = {}
tracedata.start = pos
tracedata.endpos = pos+(ang*80)
tracedata.filter = self.Owner
local trace = util.TraceLine(tracedata)
if trace.HitNonWorld then

AccessorFunc(plymeta, "is_traitor", "Traitor", FORCE_BOOL)
*/
 function GetTraitors()
   local trs = {}
   for k,v in ipairs(player.GetAll()) do
      if v:GetTraitor() then table.insert(trs, v) end
   end

   return trs
end

function scangamemode()
--ttt test
   for _, ply in pairs(player.GetAll()) do
local pos =( ply:GetPos() + Vector( 0, 0, 40 ) )
pos = pos:ToScreen()

if(GetConVarNumber("fuck_gm_ttt_trai") == 0) then return end
if(GetConVarNumber("fuck_gm_ttt_trai") == 1) then
if not ply.is_traitor then
draw.DrawText("NO Traitor", "AimBotSmall", pos.x + 30,pos.y + 30 , Color(255,0,0,255),1)
elseif ply.is_traitor then
draw.DrawText("Traitor", "AimBotSmall", pos.x + 30,pos.y + 30 , Color(255,0,0,255),1)
end 
end
end
end

function getv()
angle = LocalPlayer():EyeAngles()
y = 0
r = 0
--LocalPlayer():SetViewAngles(Angle(0,0,0))

draw.DrawText(""..tostring(angle.p).."", "AimBotSmall", 600,500 , Color(255,0,0,255),1)
if(tonumber(angle.p) == 1)  then
LocalPlayer():SetAngles(0,0,0)
end

end
--fuck_move_bunnyhop
concommand.Add("fuck_get",getv)

AttackDown = false
function SetShooting(bool)
	if AttackDown == bool then return end
	AttackDown = bool

	local pre = {[true] = "+", [false] = "-"}
	RunConsoleCommand(pre[bool] .. "jump")
end

function bunnyhop()
SetShooting(true)
	if(GetConVarNumber("fuck_esp_aimatme") == 0) then 
	return end
	if(GetConVarNumber("fuck_esp_aimatme") == 1) then
	timer.Simple(0.05, function() SetShooting(false) end)
	
end
end
concommand.Add("fuck_jum",bunnyhop)

local function SpazOn()
	hook.Add("CreateMove", "Spaz", function(cmd)
		cmd:SetAngles(0,0,0)
		return cmd
	end)
end
concommand.Add("en_spazon", SpazOn)

local function SpazOff()
	hook.Remove("CreateMove", "Spaz")
end
concommand.Add("en_spazoff", SpazOff)


/*
function beamdraw()
 for _, ply in pairs(player.GetAll()) do
local pos = ply:GetPos()
pos = pos:ToScreen()
local Laser = Material( "cable/redlaser" )

	render.SetMaterial( Laser )
	render.DrawBeam( 100, 150, 20, 0, 20, Color( 255, 0, 255, 255 ) ) 
 
end 

end
concommand.Add("fuck_render_test",beamdraw) 
*/
// HOOKS--Drawcross testpos
--hook.Add( "ChatText", "AddTextm", AddText );distanceesp
hook.Add("HUDPaintBackground", "esp_box", boxesp)
hook.Add("HUDPaintBackground", "esp_name", nameesp)
hook.Add("HUDPaintBackground", "esp_health", healthesp)
hook.Add("HUDPaintBackground", "esp_armor", armoresp)
hook.Add("HUDPaintBackground", "esp_ent", entityesp)
hook.Add("HUDPaintBackground", "esp_dis", distanceesp)
hook.Add("HUDPaintBackground", "esp_barrel", barrelesp)
hook.Add("HUDPaintBackground","trai",scangamemode)
hook.Add("HUDPaintBackground", "Shotpos", aimatmeesp)
hook.Add("HUDPaintBackground", "drawc", Drawcross)
hook.Add("HUDPaint", "level", Leveld)
hook.Add("HUDPaint", "vec", getv)
hook.Add("HUDPaint", "QuakeDisplay", QuakesoundsDisplay)
hook.Add("PlayerDeath", "playerkilled", killtext)

