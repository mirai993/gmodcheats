--[[
	lua/jewbot.lua
	heart | (STEAM_0:1:6930453)
	===DStream===
]]

--FUCK THE BOOK
--FUCK THE BOOK
--FUCK THE BOOK
--FUCK THE BOOK
--FUCK THE BOOK
--FUCK THE BOOK
--FUCK THE BOOK
--FUCK THE BOOK
--FUCK THE BOOK
--FUCK THE BOOK
--FUCK THE BOOK
--FUCK THE BOOK
--FUCK THE BOOK
--FUCK THE BOOK
--FUCK THE BOOK
--FUCK THE BOOK
--FUCK THE BOOK
--FUCK THE BOOK
--FUCK THE BOOK
--FUCK THE BOOK
--FUCK THE BOOK
--FUCK THE BOOK
--FUCK THE BOOK
--FUCK THE BOOK
--FUCK THE BOOK
--FUCK THE BOOK

--POTMAT = surface.GetTextureID("POTEMAYO")
--POTMATT = Material("POTEMAYO")







local MySelf = NULL
hook.Add("Think", "GGetLocal", function()
	MySelf = LocalPlayer()
	if MySelf:IsValid() then
		hook.Remove("Think", "GGetLocal")
	end
end)

local ANTIANTICHEAT = false

local lookthisway = FindMetaTable("Player").SetEyeAngles

local killall_ON = false
local jewbot_ON = true
local jewbot_PLAYERSONLY = true
local jewbot_ENEMYSONLY = true
local Perception_ON = false
local jewbot_OFFSET = Vector(0,0,45)
local jewbot_HEADSHOTS = true
local SUICIDE_HEALTH = 0
local Perception_EVERYTHING = false
local Perception_COLORBYTEAM = false

local jewbot_LAGCOMPENSATION = 0.00

local OFFSETPRESETS = {}
OFFSETPRESETS["chest"] = 45
OFFSETPRESETS["none"] = 0

local PREFIX = ""
if ANTIANTICHEAT then
	for i=1, math.random(4, 10) do
		PREFIX = PREFIX..string.char(math.random(97, 122))
	end

	_G[PREFIX] = PREFIX

	hook.Add("Think", PREFIX, function()
		PREFIX = _G[PREFIX] // This is in case a script tries to override PREFIX. PREFIX is local so you can't actually access it by an outside script, but you can override it.
	end)
else
	PREFIX = "h"
end

local jewbot_SCANNING = false
local jewbot_HEADOFFSET = Vector(0,0,58.5)
local jewbot_HEADOFFSET_CROUCHING = Vector(0,0,34)
surface.CreateFont("jewbotSmall", {font="coolvetica", size=14, weight=400})
surface.CreateFont("jewbotBig", {font="coolvetica", size=24, weight=400})

local jewbot_TARGET

local COLOR_FRIENDLY = Color(0, 255, 0, 255)
local COLOR_ENEMY = Color(255, 0, 0, 255)
local COLOR_DEAD = Color(40, 40, 40, 255)
local COLOR_TRACKING = Color(0, 255, 255, 255)
local COLOR_OBJECT = Color(255, 255, 255, 255)

if not ConVarExists("_Perception_colorbyteam") then
	CreateClientConVar("_Perception", 1, true, false)
	CreateClientConVar("_jewbot", 1, true, false)
	CreateClientConVar("_jewbot_killall", 0, true, false)
	CreateClientConVar("_jewbot_headshots", 1, true, false)
	CreateClientConVar("_jewbot_enemysonly", 0, true, false)
	CreateClientConVar("_jewbot_playersonly", 1, true, false)
	CreateClientConVar("_jewbot_lagcompensation", jewbot_LAGCOMPENSATION, true, false)
	CreateClientConVar("_jewbot_suicidehealth", SUICIDE_HEALTH, true, false)
	CreateClientConVar("_jewbot_offset", jewbot_OFFSET.z, true, false)
	CreateClientConVar("_Perception_everything", 0, true, false)
	CreateClientConVar("_Perception_colorbyteam", 0, true, false)
end

Perception_ON = util.tobool(GetConVarNumber("_Perception"))
jewbot_ON = util.tobool(GetConVarNumber("_jewbot"))
jewbot_HEADSHOTS = util.tobool(GetConVarNumber("_jewbot_headshots"))
jewbot_ENEMYSONLY = util.tobool(GetConVarNumber("_jewbot_enemysonly"))
jewbot_PLAYERSONLY = util.tobool(GetConVarNumber("_jewbot_playersonly"))
jewbot_LAGCOMPENSATION = GetConVarNumber("_jewbot_lagcompensation")
killall_ON = util.tobool(GetConVarNumber("_jewbot_killall"))
SUICIDE_HEALTH = GetConVarNumber("_jewbot_suicidehealth")
Perception_EVERYTHING = util.tobool(GetConVarNumber("_Perception_everything"))
Perception_COLORBYTEAM = util.tobool(GetConVarNumber("_Perception_colorbyteam"))

local function AddBotNotify(msg, typ, length)
	MySelf:ChatPrint(msg)
end

local function Perception_On(sender, command, arguments)
	AddBotNotify( "Perception is now on.", NOTIFY_HINT, 6 )
	Perception_ON = true
	RunConsoleCommand("_Perception", "1")
end

local function Perception_Off(sender, command, arguments)
	AddBotNotify( "Perception is now off.", NOTIFY_HINT, 6 )
	Perception_ON = false
	RunConsoleCommand("_Perception", "0")
end

local function jewbot_Off(sender, command, arguments)
	AddBotNotify( "Jewbot is now disabled.", NOTIFY_HINT, 6 )
	jewbot_ON = false
	jewbot_SCANNING = false
	RunConsoleCommand("_jewbot", "0")
end

local function jewbot_On(sender, command, arguments)
	AddBotNotify( "Jewbot is now enabled.", NOTIFY_HINT, 6 )
	jewbot_ON = true
	RunConsoleCommand("_jewbot", "1")
end

local function killall_Off(sender, command, arguments)
	AddBotNotify( "Killall is now disabled.", NOTIFY_HINT, 6 )
	killall_ON = false
	RunConsoleCommand("_jewbot_killall", "0")
end

local function killall_On(sender, command, arguments)
	AddBotNotify( "Killall is now enabled.", NOTIFY_HINT, 6 )
	killall_ON = true
	RunConsoleCommand("_jewbot_killall", "1")
end

local function jewbot_HeadShotsOff(sender, command, arguments)
	AddBotNotify("Now targeting players' chests.", NOTIFY_HINT, 6)
	jewbot_HEADSHOTS = false
	RunConsoleCommand("_jewbot_headshots", "0")
end

local function jewbot_HeadShotsOn(sender, command, arguments)
	AddBotNotify("Now targeting players' heads.", NOTIFY_HINT, 6)
	jewbot_HEADSHOTS = true
	RunConsoleCommand("_jewbot_headshots", "1")
end

local function jewbot_EnemysOnly_On(sender, command, arguments)
	AddBotNotify( "Now targeting enemies only.", NOTIFY_HINT, 6 )
	jewbot_ENEMYSONLY = true
	RunConsoleCommand("_jewbot_enemysonly", "1")
end

local function jewbot_EnemysOnly_Off(sender, command, arguments)
	AddBotNotify( "Now targeting both enemies and allies.", NOTIFY_HINT, 6 )
	jewbot_ENEMYSONLY = false
	RunConsoleCommand("_jewbot_enemysonly", "0")
end

local function Perception_Everything_On(sender, command, arguments)
	AddBotNotify("Perception displaying all entities is now enabled.", NOTIFY_HINT, 6)
	Perception_EVERYTHING = true
	RunConsoleCommand("_Perception_everything", "1")
end

local function Perception_Everything_Off(sender, command, arguments)
	AddBotNotify("Perception displaying all entities is now disabled.", NOTIFY_HINT, 6)
	Perception_EVERYTHING = false
	RunConsoleCommand("_Perception_everything", "0")
end

local function Perception_ColorByTeam_On(sender, command, arguments)
	AddBotNotify("Perception coloring by team is now enabled.", NOTIFY_HINT, 6)
	Perception_COLORBYTEAM = true
	RunConsoleCommand("_Perception_colorbyteam", "1")
end

local function Perception_ColorByTeam_Off(sender, command, arguments)
	AddBotNotify("Perception coloring by team is now disabled.", NOTIFY_HINT, 6)
	Perception_COLORBYTEAM = false
	RunConsoleCommand("_Perception_colorbyteam", "0")
end

local function jewbot_PlayersOnly_On(sender, command, arguments)
	AddBotNotify( "Now targeting only players.", NOTIFY_HINT, 6 )
	jewbot_PLAYERSONLY = true
	RunConsoleCommand("_jewbot_playersonly", "1")
end

local function jewbot_PlayersOnly_Off(sender, command, arguments)
	AddBotNotify( "Now targeting all entities.", NOTIFY_HINT, 6 )
	jewbot_PLAYERSONLY = false
	RunConsoleCommand("_jewbot_playersonly", "0")
end

local function jewbot_SetLagCompensation(sender, command, arguments)
	if arguments[1] == nil then AddBotNotify( "Lag Compensation is currently at "..jewbot_LAGCOMPENSATION..".", NOTIFY_HINT, 6 ) return end
	if tonumber(arguments[1]) == nil then
		AddBotNotify( "That value is not a number.", NOTIFY_ERROR, 6 )
		return
	end
	jewbot_LAGCOMPENSATION = math.Clamp(tonumber(arguments[1]), 0, 2)
	AddBotNotify("Lag Compensation has been changed to "..jewbot_LAGCOMPENSATION..".", NOTIFY_HINT, 6)
	RunConsoleCommand("_jewbot_lagcompensation", jewbot_LAGCOMPENSATION)
end

local function jewbot_SetSuicideHealth(sender, command, arguments)
	if arguments[1] == nil then AddBotNotify( "Suicide health is currently at "..SUICIDE_HEALTH..".", NOTIFY_HINT, 6 ) return end
	if tonumber(arguments[1]) == nil then
		AddBotNotify( "Not a number!", NOTIFY_ERROR, 6 )
		return
	end
	SUICIDE_HEALTH = tonumber(arguments[1])
	AddBotNotify("Suicide health changed to "..SUICIDE_HEALTH..".", NOTIFY_HINT, 6)
	RunConsoleCommand("_jewbot_suicidehealth", SUICIDE_HEALTH)
end

local function jewbot_SetOffset(sender, command, arguments)
	if arguments[1] == nil then AddBotNotify( "Offset is currently at "..jewbot_OFFSET.z..".", NOTIFY_HINT, 6 ) return end
	if tonumber(arguments[1]) == nil then
	    if OFFSETPRESETS[arguments[1] ] then
	        jewbot_OFFSET = Vector(0,0, OFFSETPRESETS[arguments[1] ])
			AddBotNotify( "Offset has been changed to "..jewbot_OFFSET.z..".", NOTIFY_HINT, 6 )
			return
	    else
			AddBotNotify( "That value is not a number.", NOTIFY_ERROR, 6 )
			return
		end
	end
	jewbot_OFFSET = Vector(0,0, math.Clamp(tonumber(arguments[1]), -512, 512))
	AddBotNotify("Offset changed to "..jewbot_OFFSET.z.."!!", NOTIFY_HINT, 6)
	RunConsoleCommand("_jewbot_offset", jewbot_OFFSET.z)
end

local function GetBone( e )
	/* Returns the position of a bone */
	if ( !ValidEntity(e) ) then return end
	if ( !_bone:GetBool() ) then return e:LocalToWorld(e:OBBCenter()) end
	return e:GetBonePosition(e:LookupBone(bones[math.Clamp(_bone:GetInt(), 1, 4)]))
end
			
local function jewbot_ScanOn(sender, command, arguments)
	jewbot_SCANNING = true
end

local function jewbot_ScanOff(sender, command, arguments)
	jewbot_SCANNING = false
	jewbot_TARGET = nil
end

local function GetTargetPos(ent)
	if ent:IsPlayer() then
--		local attach = ent:GetAttachment(1)
--		print(string.lower(tostring(ent:GetModel())))
		if (string.lower(tostring(ent:GetModel())) == "models/player/combine_soldier_prisonguard.mdl" || string.lower(tostring(ent:GetModel())) == 
"models/player/arctic.mdl") then
			attach = ent:GetAttachment(3)
			attach.Pos = attach.Pos-- + Vector(0,0,6)
--			print("DRRRR")
		else
			if (string.lower(tostring(ent:GetModel())) == "models/error.mdl") then
				attach = ent
				attach.Pos = ent:GetPos() + Vector(0,0,40)
				return
			end
			attach = ent:GetAttachment(1)
			if not attach then return end
			attach.Pos = attach.Pos-- + Vector(0,0,2)
--			print("NO")
		end
		
		if jewbot_HEADSHOTS and attach then
			return attach.Pos + ent:GetAngles():Forward() * -4
		else
			if ent:Crouching() then
				return ent:GetPos() + (jewbot_OFFSET * 0.586)
			else
				return ent:GetPos() + jewbot_OFFSET
			end
		end
	else
		return ent:GetPos() + jewbot_OFFSET
	end
end

local LAST_SUICIDE = CurTime()

local function DoPerceptionEnt(ent)
	local pos = ent:GetPos()
	pos = pos:ToScreen()
	if pos.visible then
		local mypos = MySelf:GetPos()
		local size = ScrW() * 0.007
		if jewbot_TARGET and ent == jewbot_TARGET then
			// Nothing
		else
			surface.SetDrawColor(0, 255, 0, 255)
			surface.DrawLine( pos.x - size, pos.y, pos.x + size, pos.y )
			surface.DrawLine( pos.x, pos.y - size, pos.x, pos.y + size)
			draw.SimpleText("< "..ent:GetClass().." >", "jewbotBig", pos.x, pos.y + size + 10, COLOR_ENEMY, TEXT_ALIGN_CENTER)
			draw.SimpleText("Health: "..ent:Health(), "jewbotSmall", pos.x, pos.y + size + 30, COLOR_OBJECT, TEXT_ALIGN_LEFT)
			draw.SimpleText("Dist: "..math.floor(ent:GetPos():Distance(mypos)), "jewbotSmall", pos.x, pos.y + size + 42, COLOR_OBJECT, TEXT_ALIGN_LEFT)

			end
	end
end
local function GetBoneScreenPos( yer, bone )
    return yer:GetBonePosition( yer:LookupBone( bone ) ):ToScreen()
end

local function DoPerceptionPlayer(pl)
	if pl == MySelf then
		-- DO NOTHING
	elseif pl:Alive() then
		local pos = GetTargetPos(pl) or pl:GetPos()
		local BONES = {
		    { "ValveBiped.Bip01_Head1", "ValveBiped.Bip01_Neck1" },
		    { "ValveBiped.Bip01_Neck1", "ValveBiped.Bip01_Pelvis" },
		    { "ValveBiped.Bip01_Neck1", "ValveBiped.Bip01_L_UpperArm" },
		    { "ValveBiped.Bip01_Neck1", "ValveBiped.Bip01_R_UpperArm" },
		    { "ValveBiped.Bip01_L_UpperArm", "ValveBiped.Bip01_L_Forearm" },
		    { "ValveBiped.Bip01_R_UpperArm", "ValveBiped.Bip01_R_Forearm" },
		    { "ValveBiped.Bip01_R_Forearm", "ValveBiped.Bip01_R_Hand" },
		    { "ValveBiped.Bip01_L_Forearm", "ValveBiped.Bip01_L_Hand" },
		    { "ValveBiped.Bip01_Pelvis", "ValveBiped.Bip01_L_Thigh" },
		    { "ValveBiped.Bip01_Pelvis", "ValveBiped.Bip01_R_Thigh" },
		    { "ValveBiped.Bip01_L_Thigh", "ValveBiped.Bip01_L_Calf" },
		    { "ValveBiped.Bip01_R_Thigh", "ValveBiped.Bip01_R_Calf" },
		    { "ValveBiped.Bip01_R_Calf", "ValveBiped.Bip01_R_Foot" },
		    { "ValveBiped.Bip01_L_Calf", "ValveBiped.Bip01_L_Foot" },
		}
		local colortouse = COLOR_FRIENDLY
		if Perception_COLORBYTEAM then
			colortouse = team.GetColor(pl:Team())
		elseif pl:Team() ~= MySelf:Team() then
			colortouse = COLOR_ENEMY
		end
	    for k,v in ipairs( BONES ) do
	        pos1 = GetBoneScreenPos( pl, v[1] )
	        pos2 = GetBoneScreenPos( pl, v[2] )
	        surface.SetDrawColor(colortouse)
	        surface.DrawLine( pos1.x, pos1.y, pos2.x, pos2.y )
	    end
	    local mypos = MySelf:GetPos()
	    local distance = pos:Distance(mypos)
		local size = ScrW() * 0.007

		local lplyPos = pos:ToScreen()
		
		draw.SimpleText(pl:GetName(), "ChatFont" , lplyPos.x  , lplyPos.y + size + 10, colortouse , TEXT_ALIGN_CENTER , TEXT_ALIGN_CENTER)
		draw.DrawText("Health "..pl:Health(), "DefaultFixedDropShadow", lplyPos.x, lplyPos.y + size + 30, colortouse, TEXT_ALIGN_LEFT)
		draw.DrawText(""..math.floor(pl:GetPos():Distance(mypos)), "DefaultFixedDropShadow", lplyPos.x, lplyPos.y + size + 54, colortouse, TEXT_ALIGN_LEFT)
		draw.DrawText("Set: "..pl:GetNetworkedString("usergroup", "none"), "DefaultFixedDropShadow", lplyPos.x, lplyPos.y + size + 66, team.GetColor(pl:Team()), TEXT_ALIGN_LEFT)
		local wep = pl:GetActiveWeapon()
		if wep:IsValid() then
			draw.DrawText("Weapon: "..wep:GetClass().." ("..wep:EntIndex()..")", "DefaultFixedDropShadow", lplyPos.x, lplyPos.y + size + 42, colortouse, TEXT_ALIGN_LEFT)
		else
			draw.DrawText("Unarmed", "DefaultFixedDropShadow", lplyPos.x, lplyPos.y + size + 42, colortouse, TEXT_ALIGN_LEFT)
		end

	else
		if not pl then return end
	    local pos = GetTargetPos(pl):ToScreen()
		if pos.visible then
			local mypos = MySelf:GetPos()
			local size = ScrW() * 0.007
			surface.SetDrawColor(0, 0, 0, 255)
			surface.DrawLine(pos.x - size, pos.y, pos.x + size, pos.y)
			surface.DrawLine(pos.x, pos.y - size, pos.x, pos.y + size)
			draw.SimpleText(pl:Name(), "ChatFont", pos.x, pos.y + size + 10, COLOR_DEAD, TEXT_ALIGN_CENTER)
			draw.SimpleText("** DEAD **", "DefaultFixedDropShadow", pos.x, pos.y + size + 30, COLOR_DEAD, TEXT_ALIGN_CENTER)
			draw.SimpleText("Dist: "..math.floor(pl:GetPos():Distance(mypos)), "DefaultFixedDropShadow", pos.x, pos.y + size + 42, COLOR_DEAD, TEXT_ALIGN_LEFT)
		end
	end
end

local function Dojewbot()
	if not MySelf:IsValid() then return end

	if PREFIX then
		draw.SimpleText("Your Jewbot concommand prefix: "..PREFIX, "DefaultSmall", ScrW() - 8, ScrH() * 0.5, COLOR_ENEMY, TEXT_ALIGN_RIGHT)
	end

	if Perception_ON then
--	    draw.SimpleText("PERCEPTION", "jewbotBig", ScrW() * 0.5, ScrH() * 0.01, COLOR_ENEMY, TEXT_ALIGN_CENTER)
		if Perception_EVERYTHING then
			for _, ent in pairs(ents.GetAll()) do
				if ent:IsValid() then
					if ent:IsPlayer() then
						DoPerceptionPlayer(ent)
					else
						DoPerceptionEnt(ent)
					end
				end
			end
		else
			for _, ent in pairs(ents.GetAll()) do
				if ent:IsValid() then
					if ent:IsPlayer() then
						DoPerceptionPlayer(ent)
					end
					if (string.find(ent:GetClass(),"spawned_shipment")) then
						DoPerceptionEnt(ent)
					end
				end
			end
		end
	end

	if not MySelf:Alive() then return end

	if MySelf:Health() <= SUICIDE_HEALTH then
		if CurTime() > LAST_SUICIDE + 0.5 and MySelf:Health() > 0 then
			RunConsoleCommand("kill")
			AddBotNotify("Committing Suicide", NOTIFY_ERROR, 6)
			LAST_SUICIDE = CurTime()
		end
	end

	if jewbot_ON then
		if jewbot_TARGET and jewbot_TARGET ~= nil and jewbot_TARGET:IsValid() then
			local wpos = GetTargetPos(jewbot_TARGET)
			local pos = wpos:ToScreen()
			local size = ScrW() * 0.007
			if jewbot_LAGCOMPENSATION > 0 then
				local velocity = jewbot_TARGET:GetVelocity() or Vector(0,0,0)
				lookthisway(MySelf, ((wpos + velocity * (jewbot_LAGCOMPENSATION * MySelf:Ping() * FrameTime())) - MySelf:GetShootPos()):Angle())
				local ppos = ((wpos + velocity * (jewbot_LAGCOMPENSATION * MySelf:Ping() * FrameTime()))):ToScreen()
				surface.SetDrawColor(255, 255, 0, 255)
				surface.DrawLine( ppos.x - size, ppos.y, ppos.x + size, ppos.y )
				surface.DrawLine( ppos.x, ppos.y - size, ppos.x, ppos.y + size)
			else
				lookthisway(MySelf, (wpos - MySelf:GetShootPos()):Angle())
			end
			surface.SetDrawColor(0, 255, 255, 255)
		    surface.DrawLine( pos.x - size, pos.y, pos.x + size, pos.y )
			surface.DrawLine( pos.x, pos.y - size, pos.x, pos.y + size)
			if jewbot_TARGET:IsPlayer() then
				if jewbot_TARGET:Alive() then
					draw.SimpleText(jewbot_TARGET:Name(), "jewbotBig", pos.x, pos.y + size + 10, COLOR_TRACKING, TEXT_ALIGN_CENTER)
					draw.SimpleText("HP: "..jewbot_TARGET:Health(), "jewbotSmall", pos.x, pos.y + size + 30, COLOR_TRACKING, TEXT_ALIGN_LEFT)
					draw.SimpleText("Dist: "..math.floor(jewbot_TARGET:GetPos():Distance(MySelf:GetPos())), "jewbotSmall", pos.x, pos.y + size + 42, COLOR_TRACKING, TEXT_ALIGN_LEFT)
				else
					AddBotNotify("Dominated "..jewbot_TARGET:Name(), NOTIFY_CLEANUP, 3)
					surface.PlaySound("buttons/blip1.wav")
					if killall_ON then
						print("If killall_ON then")
						jewbot_TARGETOLD = jewbot_TARGET
						print("jewbot_TARGETOLD = jewbot_TARGET")
						jewbot_TARGET = player.GetByID(math.random(1,table.Count(player.GetAll())))
						print("jewbot_TARGET = player.GetByID(math.random(1,table.Count(player.GetAll())))")
						local tr = util.GetPlayerTrace(MySelf, player.GetByID(math.random(1,#player.GetAll())))
						print("local tr = util.GetPlayerTrace(MySelf, player.GetByID(math.random(1,#player.GetAll())))")
						local trace = util.TraceLine(tr)
						print("local trace = util.TraceLine(tr)")
						if trace.Hit and trace.HitNonWorld then
							print("if trace.Hit and trace.HitNonWorld then")
							if jewbot_TARGET == jewbot_TARGETOLD then
								print("if jewbot_TARGET == jewbot_TARGETOLD then")
								jewbot_TARGET = player.GetByID(math.random(1,#player.GetAll()))
								print("jewbot_TARGET = player.GetByID(math.random(1,#player.GetAll()))")
							end
						else
							print("else")
							jewbot_TARGET = player.GetByID(math.random(1,#player.GetAll()))
							print("jewbot_TARGET = player.GetByID(math.random(1,#player.GetAll())")
						end
					else
						jewbot_TARGET = nil
					end
				end
			else
				draw.SimpleText(tostring(jewbot_TARGET), "jewbotBig", pos.x, pos.y + size + 10, COLOR_TRACKING, TEXT_ALIGN_CENTER)
				draw.SimpleText("Dist: "..math.floor(jewbot_TARGET:GetPos():Distance(MySelf:GetPos())), "jewbotSmall", pos.x, pos.y + size + 30, COLOR_TRACKING, TEXT_ALIGN_LEFT)
			end
		else
			if jewbot_SCANNING then

				draw.SimpleText("Scanning...", "jewbotBig", ScrW() * 0.5, ScrH() * 0.6, COLOR_ENEMY, TEXT_ALIGN_CENTER)
				local tr = util.GetPlayerTrace(MySelf, MySelf:GetAimVector())
				local trace = util.TraceLine(tr)
				if trace.Hit and trace.HitNonWorld then
					local entity = trace.Entity
					if jewbot_PLAYERSONLY then
						if entity:IsValid() and entity:GetPos() then
							if entity:IsPlayer() then
								if entity:Team() ~= MySelf:Team() or not jewbot_ENEMYSONLY then
									jewbot_TARGET = entity
									jewbot_SCANNING = false
								end
							end
						end
					else
						if entity:IsValid() and entity:GetPos() then
							if entity:IsPlayer() then
								if entity:Team() ~= MySelf:Team() or not jewbot_ENEMYSONLY then
									jewbot_TARGET = entity
									jewbot_SCANNING = false
								end
							else
								jewbot_TARGET = entity
								jewbot_SCANNING = false
							end
						end
					end
				end
			else
				jewbot_TARGET = nil
			end
		end
	end
end

if PREFIX then
	hook.Add("HUDPaint", PREFIX..string.char(math.random(97, 122)), Dojewbot)
else
	hook.Add("HUDPaint", "jewbot", Dojewbot)
end

if PREFIX then
	concommand.Add(PREFIX.."_jewbot_headshots_on", jewbot_HeadShotsOn)
	concommand.Add(PREFIX.."_jewbot_headshots_off", jewbot_HeadShotsOff)
	concommand.Add(PREFIX.."_killall_on", killall_On)
	concommand.Add(PREFIX.."_killall_off", killall_Off)
	concommand.Add(PREFIX.."_jewbot_on", jewbot_On)
	concommand.Add(PREFIX.."_jewbot_off", jewbot_Off)
	concommand.Add(PREFIX.."_Perception_on", Perception_On)
	concommand.Add(PREFIX.."_Perception_off", Perception_Off)
	concommand.Add(PREFIX.."_jewbot_enemysonly_on", jewbot_EnemysOnly_On)
	concommand.Add(PREFIX.."_jewbot_enemysonly_off", jewbot_EnemysOnly_Off)
	concommand.Add(PREFIX.."_Perception_everything_on", Perception_Everything_On)
	concommand.Add(PREFIX.."_Perception_everything_off", Perception_Everything_Off)
	concommand.Add(PREFIX.."_Perception_colorbyteam_on", Perception_ColorByTeam_On)
	concommand.Add(PREFIX.."_Perception_colorbyteam_off", Perception_ColorByTeam_Off)
	concommand.Add(PREFIX.."_jewbot_playersonly_on", jewbot_PlayersOnly_On)
	concommand.Add(PREFIX.."_jewbot_playersonly_off", jewbot_PlayersOnly_Off)
	concommand.Add("+"..PREFIX.."_jewbot_scan", jewbot_ScanOn)
	concommand.Add("-"..PREFIX.."_jewbot_scan", jewbot_ScanOff)
	concommand.Add(PREFIX.."_jewbot_suicidehealth", jewbot_SetSuicideHealth)
	concommand.Add(PREFIX.."_jewbot_lagcompensation", jewbot_SetLagCompensation)
	concommand.Add(PREFIX.."_jewbot_offset", jewbot_SetOffset)
else
	concommand.Add("jewbot_headshots_on", jewbot_HeadShotsOn)
	concommand.Add("jewbot_headshots_off", jewbot_HeadShotsOff)
	concommand.Add("_killall_on", killall_On)
	concommand.Add("_killall_off", killall_Off)
	concommand.Add("jewbot_on", jewbot_On)
	concommand.Add("jewbot_off", jewbot_Off)
	concommand.Add("Perception_on", Perception_On)
	concommand.Add("Perception_off", Perception_Off)
	concommand.Add("jewbot_enemysonly_on", jewbot_EnemysOnly_On)
	concommand.Add("jewbot_enemysonly_off", jewbot_EnemysOnly_Off)
	concommand.Add("Perception_everything_on", Perception_Everything_On)
	concommand.Add("Perception_everything_off", Perception_Everything_Off)
	concommand.Add("Perception_colorbyteam_on", Perception_ColorByTeam_On)
	concommand.Add("Perception_colorbyteam_off", Perception_ColorByTeam_Off)
	concommand.Add("jewbot_playersonly_on", jewbot_PlayersOnly_On)
	concommand.Add("jewbot_playersonly_off", jewbot_PlayersOnly_Off)
	concommand.Add("+jewbot_scan", jewbot_ScanOn)
	concommand.Add("-jewbot_scan", jewbot_ScanOff)
	concommand.Add("jewbot_suicidehealth", jewbot_SetSuicideHealth)
	concommand.Add("jewbot_lagcompensation", jewbot_SetLagCompensation)
	concommand.Add("jewbot_offset", jewbot_SetOffset)
end
local dickconvar = CreateClientConVar("entfindclass", "classname here", true, false)
local function entfind()
	xxx = dickconvar:GetString()
	for _, ent in pairs(ents.GetAll()) do
		if ent:IsValid() then
			if ent:GetClass() == xxx then
				DoPerceptionEnt(ent)
			end
		end
	end
end

concommand.Add("entfind", function() hook.Add("HUDPaint", "entfind", entfind) end )
concommand.Add("entfindoff", function() hook.Remove("HUDPaint", "entfind") end )