--[[
	cl_insaesp.lua
	Lawl |sethhack v4 is released:(
	===DStream===
]]

local curmaterial = "solid"
local silencer = false
local function validtargetesp(entz)
if !(entz:IsPlayer() or entz:IsNPC()) then return false end
if entz == LocalPlayer() then return false end
if entz:IsNPC() then 
if entz.IsDead == true then
return false
end
if entz:GetMoveType() == MOVETYPE_NONE then return false end
if entz:IsPlayer() then if entz:Health() < 1 then return false end end
if entz:IsNPC() then if entz.IsDead == true then return false end end
if entz:GetMoveType() == MOVETYPE_NONE then return false end
return true
end
end
local cne = 0
function returntrace(ply)
local trace = {start = LocalPlayer():GetShootPos(),endpos = ply:GetBonePosition( ply:LookupBone( "ValveBiped.Bip01_Head1" ) ),filter = {LocalPlayer(), ply}}
local tr = util.TraceLine(trace)
return tr
end
local Materials = {}
local Hooks = {}
local function GetMeta(name)
	return table.Copy(_R[name] or {})
end
local EntM = GetMeta("Entity")
local function bMaterial()
local Texture = {
  ["$basetexture"] = "models/debug/debugwhite",
  ["$model"]       = 1,
  ["$translucent"] = 1,
  ["$alpha"]       = 1,
  ["$nocull"]      = 1,
  ["$ignorez"]  = 1
}
local Texture2 = {
  ["$basetexture"] = "models/debug/debugwhite",
  ["$model"]       = 1,
  ["$translucent"] = 1,
  ["$alpha"]       = 1,
  ["$nocull"]      = 1
}
   
local material = CreateMaterial( "b_solid", "VertexLitGeneric", Texture )
local material2 = CreateMaterial( "b_solid2", "VertexLitGeneric", Texture2 )

return material,material2

end

local function bChams()
for k, v in pairs( player.GetAll() ) do
if validtargetesp(v) then
if ValidEntity( v ) then
cam.Start3D( EyePos(), EyeAngles() )
local m,m2 = bMaterial()
render.SuppressEngineLighting( true )
render.SetColorModulation( team.TeamColor(v:GetTeam()))
SetMaterialOverride( m )
v:DrawModel()
render.SuppressEngineLighting( false )
render.SetColorModulation( Color(255,255,255)-team.TeamColor(v:GetTeam()))
SetMaterialOverride(m2)
v:DrawModel()
SetMaterialOverride(0)
cam.End3D()
			end
			end
			end
for k, v in pairs( ents.FindByClass("npc_*") ) do
if validtargetesp(v) then
if ValidEntity( v ) then
cam.Start3D( EyePos(), EyeAngles() )
local m,m2 = bMaterial()
render.SuppressEngineLighting( true )
render.SetColorModulation( 0, 0, 255 )
SetMaterialOverride( m )
v:DrawModel()
render.SuppressEngineLighting( false )
render.SetColorModulation( 255, 0, 0 )
SetMaterialOverride(m2)
v:DrawModel()
SetMaterialOverride(0)
cam.End3D()
			end
			end
		end
for k, v in pairs( ents.FindByClass("combine_mine") ) do
if validtargetesp(v) then
if ValidEntity( v ) then
cam.Start3D( EyePos(), EyeAngles() )
local m,m2 = bMaterial()
render.SuppressEngineLighting( true )
render.SetColorModulation( 0, 255, 0 )
SetMaterialOverride( m )
v:DrawModel()
render.SuppressEngineLighting( false )
render.SetColorModulation( 255, 0, 0 )
SetMaterialOverride(m2)
v:DrawModel()
SetMaterialOverride(0)
cam.End3D()
			end
		end
		end
end
	local function GenerateRandom()
		/*
			Generates a Random String; Thanks to RabidToaster
		*/
		local j, r = 0, ""
		
		for i = 1, math.random(3, 19) do
			j = math.random(65, 116)
			if ( j > 90 && j < 97 ) then j = j + 6 end
			r = r .. string.char(j)
		end
		return r
	end

	local function AddHook( h, f )
		local n = GenerateRandom()
		Hooks[h] = f
		hook.Add(h, n, f)
	end

	local function NoRecoil( u, o )
			local w = LocalPlayer():GetActiveWeapon()
			
			if ( w.Primary ) then w.Primary.Recoil = 0.0 end
			if ( w.Secondary ) then w.Secondary.Recoil = 0.0 end
		return { origin = o, angles = ViewAngle }
	end
hook.Add( "RenderScreenspaceEffects", "bChams", bChams )
--AddHook("CalcView", NoRecoil)
aimmodels = {
        ["models/combine_scanner.mdl"] = "Scanner.Body",
        ["models/hunter.mdl"] = "MiniStrider.body_joint",
        ["models/combine_turrets/floor_turret.mdl"] = "Barrel",
        ["models/dog.mdl"] = "Dog_Model.Eye",
        ["models/antlion.mdl"] = "Antlion.Body_Bone",
        ["models/antlion_guard.mdl"] = "Antlion_Guard.Body",
        ["models/antlion_worker.mdl"] = "Antlion.Head_Bone",
        ["models/zombie/fast_torso.mdl"] = "ValveBiped.HC_BodyCube",
        ["models/zombie/fast.mdl"] = "ValveBiped.HC_BodyCube",
        ["models/headcrabclassic.mdl"] = "HeadcrabClassic.SpineControl",
        ["models/headcrabblack.mdl"] = "HCBlack.body",
        ["models/headcrab.mdl"] = "HCFast.body",
        ["models/zombie/poison.mdl"] = "ValveBiped.Headcrab_Cube1",
        ["models/zombie/classic.mdl"] = "ValveBiped.HC_Body_Bone",
        ["models/zombie/classic_torso.mdl"] = "ValveBiped.HC_Body_Bone",
        ["models/zombie/zombie_soldier.mdl"] = "ValveBiped.HC_Body_Bone",
        ["models/combine_strider.mdl"] = "Combine_Strider.Body_Bone",
        ["models/lamarr.mdl"] = "HeadcrabClassic.SpineControl"
}
local function HeadPos(ply) 
    if ValidEntity(ply) then 
	local bone = (aimmodels[ ply:GetModel() ] or "ValveBiped.Bip01_Head1")
	local hbone = ply:LookupBone(bone) 
        return ply:GetBonePosition(hbone) 
    else return end 
end 
local h4x = {
	cross_swastika = 0,
	radar = 1,
	gap = 20,
	esp_enabled = 1,
	esp_showNames = 0,
	esp_boxWidth = 32,
	esp_boxHeight = 32,
	esp_NPCsColor_r = 255,
	esp_NPCsColor_g = 255,
	esp_NPCsColor_b = 255,
	esp_NPCsColor_a = 255,
	esp_localPlyColor_r = 255,
	esp_localPlyColor_g = 255,
	esp_localPlyColor_b = 255,
	esp_localPlyColor_a = 255,
	esp_localPlyCrossSize = 20,
	aim_on_NPC = 1,
	aim_on = 1,
	aim_on_key = 1,
	chamz_on = 0,
	esp_usebb9esp = 1,
}
local ply = LocalPlayer()
------ cusercmd ------
local function GetMeta(name)
	return table.Copy(_R[name] or {})
end
local AngM = GetMeta("Angle")
local CmdM = GetMeta("CUserCmd")
local EntM = GetMeta("Entity")
local PlyM = GetMeta("Player")
local VecM = GetMeta("Vector")
------------------------
------------------------
local cam,render = cam,render
--local filternpc = {"npc_hunter","npc_dog","npc_monk","npc_alyx","npc_mossman","npc_barney","npc_eli","npc_gman","npc_citizen","npc_turret_floor","npc_grenade_frag","rebelturret","npc_vortigaunt","npc_barnacle","npc_barnacle_tongue_tip","npc_kleiner","npc_satchel","npc_rollermine"}
local filternpc = {""}

function Visible(ply)
local trace = {start = LocalPlayer():GetShootPos(),endpos = ply:GetBonePosition( ply:LookupBone( "ValveBiped.Bip01_Head1" ) ),filter = {LocalPlayer(), ply}}
local tr = util.TraceLine(trace)
for k,v in pairs(filternpc) do
if ply:GetClass() == v then return false end
end
if ply:IsNPC() then if ply.IsDead == true then return false end end
if ply:GetMoveType() == MOVETYPE_NONE then return false end
if tr.Fraction == 1 then
return true
else
return false
end
end
concommand.Add( "addnpcfilter", function(player,command,arguments)
for k, fltr in pairs(filternpc) do
if arguments[1] == fltr then 
print("Already exists.")
return false
end
end
table.insert(filternpc,arguments[1])
print("Added aimbot filter for npc \""..arguments[1].."\"")
end)
concommand.Add( "removenpcfilter", function(player,command,arguments)
for k, fltr in pairs(filternpc) do
if arguments[1] == fltr then 
table.remove(filternpc,k)
end
end
print("Removed aimbot filter for npc \""..arguments[1].."\"")
end)
concommand.Add( "printnpcfilter", function()
print("List:\n__________________________________")
for k,v in pairs(filternpc) do
print(v)
end
print("__________________________________")
end)
concommand.Add( "addespent", function(player,command,arguments)
for k, fltr in pairs(espents) do
if arguments[1] == fltr then 
print("Already exists.")
return false
end
end
table.insert(espents,arguments[1])
print("Added ESP filter for ent \""..arguments[1].."\"")
end)
concommand.Add( "removeespent", function(player,command,arguments)
for k, fltr in pairs(espents) do
if arguments[1] == fltr then 
table.remove(espents,k)
end
end
print("Removed ESP filter for ent \""..arguments[1].."\"")
end)
concommand.Add( "printesplist", function()
print("List:\n__________________________________")
for k,v in pairs(espents) do
print(v)
end
print("__________________________________")
end)
concommand.Add( "printhooks", function()
print("List:\n__________________________________")
for k,v in pairs(Hooks) do
print(v)
end
print("__________________________________")
end)
local cppweaps = {}
cppweaps["weapon_357"] = true
cppweaps["weapon_smg1"] = true
cppweaps["weapon_ar2"] = true
cppweaps["weapon_shotgun"] = true
cppweaps["weapon_pistol"] = true
cppweaps["weapon_crossbow"] = true
cppweaps["weapon_rpg"] = true
local cppweapsrec = {}
cppweapsrec["weapon_357"] = 0.8
cppweapsrec["weapon_smg1"] = 1
cppweapsrec["weapon_ar2"] = 1.03
cppweapsrec["weapon_shotgun"] = 1
cppweapsrec["weapon_pistol"] = 1
cppweapsrec["weapon_crossbow"] = 1
local function anglepunch()
if !(LocalPlayer():GetActiveWeapon() == nil) then
if cppweaps[LocalPlayer():GetActiveWeapon():GetClass()] then
return (((LocalPlayer():GetPunchAngle( )) or Angle(0,0,0))*(0.8))
else
return Angle(0,0,0)
end
else
return Angle(0,0,0)
end
end
local correctView = Angle( 0, 0, 0 )
local silent = Angle( 0, 0, 0 )
local view = Angle( 0, 0, 0 )
local spinangle = Angle( 0, 0, 0 )
local stop = 0xFFFF - IN_JUMP
local ViewAngle = Angle( 0, 0, 0 )
local SetViewAngles = _R["CUserCmd"].SetViewAngles
local dontaimweaps = {}
dontaimweaps["weapon_crowbar"] = true
dontaimweaps["weapon_physcannon"] = true
dontaimweaps["weapon_physgun"] = true
dontaimweaps["weapon_rpg"] = true
dontaimweaps["weapon_grenade_frag"] = true
dontaimweaps["weapon_stunstick"] = true
dontaimweaps["weapon_slam"] = true
dontaimweaps["gmod_tool"] = true
local function validtarget(entz)
if !(LocalPlayer():GetActiveWeapon() == nil) then
if dontaimweaps[LocalPlayer():GetActiveWeapon():GetClass()] then return false end
else
return false
end
if !ValidEntity(entz) then return false end
if !(entz:IsPlayer() or entz:IsNPC()) then return false end
if entz == LocalPlayer() then return false end
if !Visible(entz) then return false end
if entz:IsNPC() then 
if entz.IsDead == true then
return false
end
if entz:GetMoveType() == MOVETYPE_NONE then return false end
if entz:IsPlayer() then if entz:Health() < 1 then return false end end
if entz:IsNPC() then if entz.IsDead == true then return false end end
if entz:GetMoveType() == MOVETYPE_NONE then return false end
return true
end
end
local Aiming
concommand.Add( "+b_aim", function() 
Aiming = true
 end )
concommand.Add( "-b_aim", function() 
Aiming = false 
end )
hook.Add("CreateMove", "lulz", function(cmd)
--local cmd = LocalPlayer():GetCurrentCommand( )
if h4x.aim_on==1 then
local e = EntM
local lol = LocalPlayer():GetAngles()
--cmd:SetViewAngles(PredictSpread(cmd,((ply:GetAimVector() - ply:GetShootPos()):Angle())))
--cmd:SetViewAngles(lol)
end
--if (IN_ATTACK & cmd:GetButtons()) > 0 then
if LocalPlayer():Health() > 0 then
		local ply = LocalPlayer()
		local myview = ply:EyeAngles()
		local mouse = Angle(cmd:GetMouseY() * GetConVarNumber("m_pitch"), cmd:GetMouseX() * -GetConVarNumber("m_yaw"),0)
if h4x.aim_on_NPC==1 then
local trget
if Aiming then
			for k, NPCs in pairs(ents.FindByClass("npc_*")) do
			if validtarget(NPCs) then
			trget = NPCs
			end
			end
			local ply = LocalPlayer()
			if trget then
			else
			return 
			end
			local targetheadpos = HeadPos(trget)
			local restangs = cmd:GetViewAngles()
			local targetPos = GetWeaponPredictionPos(targetPos , trget)
			local velocity = trget:GetVelocity() or Vector(0,0,0)
			local velocityplayer = ply:GetVelocity() or Vector(0,0,0)
			local targetPos = ((((targetheadpos+(velocity * 0.0024* (LocalPlayer():Ping() or 0) )) + velocity*1*FrameTime())- (ply:GetShootPos()+velocityplayer*1*FrameTime())):Angle())
			--local targetPos = (((targetheadpos + velocity*1*FrameTime())- (ply:GetShootPos()+velocityplayer*1*FrameTime())):Angle())
			targetPos.z = 0
			--if input.IsMouseDown(MOUSE_LEFT) then
			RunConsoleCommand( "+attack" )
			timer.Simple( 0.1, function() RunConsoleCommand( "-attack" ) end )
			--if (cmd:GetButtons() & IN_ATTACK > 0) then
			SetViewAngles(cmd,PredictSpread(cmd,targetPos)-anglepunch())
			--timer.Simple( 0.01, function() cmd:SetViewAngles(restangs) end )
			--end
			--end
end
else
			for k, plys in pairs(player.GetAll()) do
				if plys != LocalPlayer() then
				if validtarget(plys) then
				if plys:Health() > 0 then
				local targetPos = ((targetheadpos - ply:GetShootPos()):Angle())
			local ply = LocalPlayer()
			local restangs = cmd:GetViewAngles()
			local targetheadpos = HeadPos(plys)
			local targetPos = GetWeaponPredictionPos(targetPos , plys)
			local velocity = plys:GetVelocity() or Vector(0,0,0)
			local velocityplayer = ply:GetVelocity() or Vector(0,0,0)
			local targetPos = ((((targetheadpos + velocity*1*FrameTime()+(velocity * 0.0024* (LocalPlayer():Ping() or 0))) ))- (ply:GetShootPos()+velocityplayer*1*FrameTime())):Angle()
			targetPos.z = 0
			LocalPlayer():GetActiveWeapon().SetNextPrimaryFire( LocalPlayer():GetActiveWeapon() )
			--if input.IsMouseDown(MOUSE_LEFT) then
			RunConsoleCommand( "+attack" )
			timer.Simple( 0.1, function() RunConsoleCommand( "-attack" ) end )
			--if (cmd:GetButtons() & IN_ATTACK > 0) then
			SetViewAngles(cmd,PredictSpread(cmd,targetPos)-anglepunch())
			--timer.Simple( 0.01, function() cmd:SetViewAngles(restangs) end )
			--end
			--end
end
end
end
end
end
end
--end
end)
--[[hook.Add("CalcView", "FakeView", function( Player, Orig, ViewAngles, FOV)
if h4x.aim_on==1 then
if LocalPlayer():Health() > 0 then
if h4x.aim_on_NPC==1 then
			for k, NPCs in pairs(ents.FindByClass("npc_*")) do
			local ply = LocalPlayer()
			if Visible(NPCs) then
			local targethead = NPCs:LookupBone("ValveBiped.Bip01_Head1")
			local targetheadpos,targetheadang = NPCs:GetBonePosition(targethead)
			LocalPlayer():GetActiveWeapon().SetNextPrimaryFire( LocalPlayer():GetActiveWeapon() )
			return { origin = Orig, angles = (((targetheadpos - ply:GetShootPos()):Angle())) }
			end
			end
else
			for k, plys in pairs(player.GetAll()) do
				if plys != LocalPlayer() then
				if Visible(plys) then
				if plys:Health() > 0 then
			local ply = LocalPlayer()
			local restangs = cmd:GetViewAngles()
			local targethead = plys:LookupBone("ValveBiped.Bip01_Head1")
			local targetheadpos,targetheadang = plys:GetBonePosition(targethead)
			return { origin = Orig, angles = (((targetheadpos - ply:GetShootPos()):Angle())) }
end
end
end
end
end
end
end
	end)]]--
local convars = {}
local ScrW, ScrH = ScrW, ScrH
------------------------------
hook.Add( "HUDPaint", "DrawESP", function()
local g, b = Color( 255, 242, 0, 255 ), Color( 0, 0, 0, 255 )
draw.SimpleTextOutlined( "B-Hax by BB9", "Default", 10, 10, g, 0, 0, 1, b )
draw.SimpleTextOutlined( "Cone value: "..cne, "Default", 20, 20, g, 0, 0, 1, b )
if silencer == true then
local g, b = Color( 255, 242, 0, 255 ), Color( 0, 0, 0, 255 )
draw.SimpleTextOutlined( "* Silencer mode *", "Default", 20, 30, g, 0, 0, 1, b )
end
--[[local x = ScrW() / 2
local y = ScrH() / 2
	local pos = LocalPlayer():GetPos();
	local ang = LocalPlayer():GetAngles();
cam.Start3D( pos + ang:Forward() * 32 + ang:Up() * 8, ang )
surface.SetDrawColor( 0,150,255,255 )
surface.DrawRect(x-50,y-50,100,100)
surface.SetDrawColor( 255,0,0,255 )
surface.DrawOutlinedRect(x-50,y-50,100,100)
surface.DrawLine( x-40, y, x+40, y )
surface.DrawLine( x, y-40, x, y+40 )

surface.DrawLine( x+40, y+40, x+40, y )
surface.DrawLine( x-40, y-40, x-40, y )

surface.DrawLine( x+40, y-40, x, y-40 )
surface.DrawLine( x-40, y+40, x, y+40 )
cam.End3D()
]]--
if h4x.esp_enabled == 1 then
--[[for k, entz in pairs(espents) do
for k, v in pairs(ents.FindByClass(entz)) do
local maxx, minx, maxy, miny = box(entz)
local drawColor = Color(255,0,0,255)
draw.RoundedBox( 1, minx, miny, 4, 4, drawColor )
draw.RoundedBox( 1, maxx, miny, 4, 4, drawColor )
draw.RoundedBox( 1, maxx, maxy, 4, 4, drawColor )
draw.RoundedBox( 1, minx, maxy, 4, 4, drawColor )
	end
	end]]--
for k, weaps in pairs(ents.FindByClass("weapon_*")) do
local pos = weaps:GetPos()
local pos = pos:ToScreen()
surface.SetTextColor(255,255,255,255)
surface.SetFont("TabLarge")
surface.SetTextPos(pos.x,pos.y )
local wname = string.upper(weaps:GetClass())
surface.DrawText(wname)
end
for k, mine in pairs(ents.FindByClass("combine_mine")) do
local victimpos = ply:GetPos()
local targetpos = mine:GetPos()
allmineposition = mine:GetPos() + mine:OBBCenter()
mineposition = allmineposition:ToScreen()
local crsize = 10
if h4x.chamz_on == 1 then
cam.Start3D( EyePos(), EyeAngles() )
render.SetColorModulation(0, 255, 0)
end
if !Visible(mine) then
surface.SetDrawColor( 0,255,0,255 )
if h4x.chamz_on == 1 then
render.SetColorModulation(0, 255, 0)
end
end
if Visible(mine) then
surface.SetDrawColor( 255,255,0,255 )
if h4x.chamz_on == 1 then
render.SetColorModulation(255, 255, 0)
end
end
debugoverlay.Box(allmineposition, Vector(-25, -25, -25), Vector(25, 25, 25), 0.5, Color(0,0,255,0))
if h4x.chamz_on == 1 then
mine:DrawModel()
cam.End3D()
end
x = mineposition.x
y = mineposition.y
length = 20+10
gap = 20
local maxX, minX, maxY, minY = box(mine)			
surface.DrawLine( maxX, maxY, maxX, minY )
surface.DrawLine( maxX, minY, minX, minY )
surface.DrawLine( minX, minY, minX, maxY )
surface.DrawLine( minX, maxY, maxX, maxY )
--[[surface.SetDrawColor( 0,0,255,255 )
surface.DrawOutlinedRect(x-50,y-50,101,101)
surface.DrawOutlinedRect(x-51,y-51,101,101)
surface.DrawOutlinedRect(x-52,y-52,101,101)
surface.DrawOutlinedRect(x-53,y-53,101,101)

surface.DrawLine( x-50, y-50, x-10, y-10 )
surface.DrawLine( x+50, y+50, x+10, y+10 )
surface.DrawLine( x-50, y+50, x-10, y+10 )
surface.DrawLine( x+50, y-50, x+10, y-10 )

surface.DrawLine( x-50, y-30, x-50, y-50 )
surface.DrawLine( x-50, y-50, x-20, y-50 )

surface.DrawLine( x+50, y-30, x+50, y-50 )
surface.DrawLine( x+50, y-50, x+20, y-50 )

surface.DrawLine( x-50, y+30, x-50, y+50 )
surface.DrawLine( x-50, y+50, x-20, y+50 )

surface.DrawLine( x+50, y+30, x+50, y+50 )
surface.DrawLine( x+50, y+50, x+20, y+50 )
]]--
if victimpos:Distance( targetpos ) < 250 then
draw.DrawText("Warning: Combine mine in less then 250 distance", "TabLarge", ScrW() / 2, 25,Color(255, 255, 0, 255),TEXT_ALIGN_CENTER)
end
end
local rdrsize = 201

local ply = LocalPlayer()
local w, h = ScrW() / 2, ScrH() / 2
			local isadminz0r = ""
			for k, plys in pairs(player.GetAll()) do
			--if !validtargetesp(plys) then return end
				if plys != LocalPlayer() then
					allplayersposition = plys:GetPos() + plys:OBBCenter()
					playerposition = allplayersposition:ToScreen()
local x = 200
local y = 200
local xPos = 10
local yPos = 10
local radar = true

			surface.SetDrawColor(0,0,255,255)
					plysColor = Color(200,200,255,255)
						if plys:IsAdmin() then
							isadminz0r = "Yes"
						end
						if !plys:IsAdmin() then
							isadminz0r = "No"
						end
					local crsize = 10
					if Visible(plys) then
					surface.SetDrawColor( Color(200,200,255,255) )
					drawchamz(plys,Color(255,0,0,255))
					elseif !Visible(plys) then
					surface.SetDrawColor( Color(200,200,255,50) )
					drawchamz(plys,Color(0,0,255,255))
					end
local x = playerposition.x
local y = playerposition.y
length = 20+10
gap = 20
surface.SetDrawColor( 0,0,255,255 )
--[[surface.DrawOutlinedRect(x-50,y-50,101,101)
surface.DrawOutlinedRect(x-51,y-51,101,101)
surface.DrawOutlinedRect(x-52,y-52,101,101)
surface.DrawOutlinedRect(x-53,y-53,101,101)

surface.DrawLine( x-50, y-50, x-10, y-10 )
surface.DrawLine( x+50, y+50, x+10, y+10 )
surface.DrawLine( x-50, y+50, x-10, y+10 )
surface.DrawLine( x+50, y-50, x+10, y-10 )

surface.DrawLine( x-50, y-30, x-50, y-50 )
surface.DrawLine( x-50, y-50, x-20, y-50 )

surface.DrawLine( x+50, y-30, x+50, y-50 )
surface.DrawLine( x+50, y-50, x+20, y-50 )

surface.DrawLine( x-50, y+30, x-50, y+50 )
surface.DrawLine( x-50, y+50, x-20, y+50 )

surface.DrawLine( x+50, y+30, x+50, y+50 )
surface.DrawLine( x+50, y+50, x+20, y+50 )
]]--
			local maxX, minX, maxY, minY = box(plys)	
			surface.SetDrawColor( 0,255,0,255 )
			--surface.DrawLine( minX, minY, minY, minX+25 )
			--surface.DrawLine( minX, minY, minX+25, minY )

			--surface.DrawLine( maxX, maxY, maxX, minY )
			--surface.DrawLine( maxX, minY, minX, minY )
					
			--surface.DrawLine( minX, minY, minX, maxY )
			--surface.DrawLine( minX, maxY, maxX, maxY )

					surface.SetDrawColor(plysColor)
					boxHeightDividedBy2 = 16 / 2
					if plys:Health() < 101 then
					gethp = plys:Health()
					else
					gethp = 100
					end
					surface.SetDrawColor(0,0,0,255)
                    surface.DrawRect( maxX + 1, minY, 52, 10 ); 
					surface.SetDrawColor(255,255,255,255)
                    surface.DrawRect( maxX+2, minY+1, gethp/2, 8 ); 
					surface.SetTextColor(255,255,255,255)
					if h4x.esp_showNames==1 then
						local victimpos = ply:GetPos()
						local targetpos = plys:GetPos()
						surface.SetTextColor(plysColor)
						surface.SetFont("TabLarge")
						surface.SetTextPos(maxX,playerposition.y - boxHeightDividedBy2 - 16 )
						surface.DrawText("Name: "..plys:GetName())
						surface.SetTextPos(maxX,playerposition.y - boxHeightDividedBy2 - 16 +20 )
						surface.DrawText("Is admin? "..isadminz0r)
						surface.SetTextPos(maxX,playerposition.y - boxHeightDividedBy2 - 16 +40 )
						surface.DrawText("SteamID: "..plys:SteamID())
						surface.SetTextPos(maxX,playerposition.y - boxHeightDividedBy2 - 16 +60 )
						surface.DrawText("team name: "..team.GetName(plys:Team()))
						surface.SetTextPos(maxX,playerposition.y - boxHeightDividedBy2 - 16 -20 )
						surface.DrawText("Distance: "..victimpos:Distance( targetpos ))
					end
				end

		end
			for k, NPCs in pairs(ents.FindByClass("npc_*")) do
			if validtargetesp(NPCs) then
				local NPCposition = ""
				allNPCsposition = NPCs:GetPos() + NPCs:OBBCenter()
				NPCposition = allNPCsposition:ToScreen()
				local crsize = 10
				if !Visible(NPCs) then
				surface.SetDrawColor( 255, 255, 0, 255 )
				drawchamz(NPCs)
				end
				if Visible(NPCs) then
				surface.SetDrawColor( 255,0,0,255 )
				drawchamz(NPCs)
				end
length = 20+10
gap = 20
local x = NPCposition.x
local y = NPCposition.y
--[[surface.SetDrawColor( 0,0,255,255 )
surface.DrawOutlinedRect(x-50,y-50,101,101)
surface.DrawOutlinedRect(x-51,y-51,101,101)
surface.DrawOutlinedRect(x-52,y-52,101,101)
surface.DrawOutlinedRect(x-53,y-53,101,101)

surface.DrawLine( x-50, y-50, x-10, y-10 )
surface.DrawLine( x+50, y+50, x+10, y+10 )
surface.DrawLine( x-50, y+50, x-10, y+10 )
surface.DrawLine( x+50, y-50, x+10, y-10 )

surface.DrawLine( x-50, y-30, x-50, y-50 )
surface.DrawLine( x-50, y-50, x-20, y-50 )

surface.DrawLine( x+50, y-30, x+50, y-50 )
surface.DrawLine( x+50, y-50, x+20, y-50 )

surface.DrawLine( x-50, y+30, x-50, y+50 )
surface.DrawLine( x-50, y+50, x-20, y+50 )

surface.DrawLine( x+50, y+30, x+50, y+50 )
surface.DrawLine( x+50, y+50, x+20, y+50 )
]]--
			local targethead = NPCs:LookupBone("ValveBiped.Bip01_Head1")
			local targetheadpos,targetheadang = NPCs:GetBonePosition(targethead)
			        local drawColor = Color(255, 255, 255, 255); 
					local pos = Vector(NPCs:GetPos().x,NPCs:GetPos().y,NPCs:GetPos().z+ NPCs:OBBMaxs().z)
					local drawPosit = pos:ToScreen(); 
                    if( Visible(NPCs) ) then 
                        drawColor = Color( 255, 0, 0, 255 ); 
                    else 
                        drawColor = Color( 255, 255, 0, 255 ); 
                    end
					surface.SetDrawColor(drawColor)
                    
                    local textData = {} 
                    textData.pos = {} 
                    textData.pos[1] = drawPosit.x; 
                    textData.pos[2] = drawPosit.y-10; 
                    textData.color = drawColor;
					local nametag = ""
					nametag = NPCs:GetClass()
					if string.find(nametag,"npc_") then nametag = string.sub(nametag,5) end
					nametag = string.upper(nametag)
                    textData.text = nametag; 
                    textData.font = "DefaultFixed"; 
                    textData.xalign = TEXT_ALIGN_RIGHT; 
                    textData.yalign = TEXT_ALIGN_RIGHT; 
                    draw.Text( textData ); 
				local maxX, minX, maxY, minY = box(NPCs)			
				--surface.DrawLine( maxX, maxY, maxX, minY )
				--surface.DrawLine( maxX, minY, minX, minY )
					
				--surface.DrawLine( minX, minY, minX, maxY )
				--surface.DrawLine( minX, maxY, maxX, maxY )
				drbx(maxX,minX,maxY,minY)
				surface.SetDrawColor(drawColor)
				local newpos = NPCs:GetPos() + NPCs:OBBCenter()
				local newpos = newpos:ToScreen()
				surface.SetDrawColor(255,255,255,255)
				--[[if h4x.esp_showNames == 1 then
					NPCclass = NPCs:GetClass()
					local victimpos = ply:GetPos()
					local targetpos = NPCs:GetPos()
					boxHeightDividedBy2 = 16 / 2
					surface.SetTextColor( 0,0,255,255 )
					surface.SetTextPos(maxX,NPCposition.y - boxHeightDividedBy2 - 16)
					surface.SetFont("TabLarge")
					surface.DrawText("classname: "..NPCclass)
					surface.SetTextPos(maxX,NPCposition.y - boxHeightDividedBy2 - 16 -20 )
					surface.DrawText("Distance: "..victimpos:Distance( targetpos ))
				end]]--
			end
		end
		end
local x = ScrW() / 2
local y = ScrH() / 2
local gap = 20
local length = gap + 10
if h4x.cross_swastika == 0 then
surface.SetDrawColor( 0,0,255,255 )
surface.DrawOutlinedRect(x-50,y-50,101,101)
surface.SetDrawColor( 0,200,255,255 )

surface.DrawLine( x-50, y-50, x-10, y-10 )
surface.DrawLine( x+50, y+50, x+10, y+10 )
surface.DrawLine( x-50, y+50, x-10, y+10 )
surface.DrawLine( x+50, y-50, x+10, y-10 )

surface.SetDrawColor( 255,255,255,255 )
surface.DrawLine( x - length, y, x - gap, y )
surface.DrawLine( x + length, y, x + gap, y )
surface.DrawLine( x, y - length, x, y - gap )
surface.DrawLine( x, y + length, x, y + gap )
surface.SetDrawColor( 255,0,0,255 )
surface.DrawLine( x, y + length - 20, x, y )
surface.DrawLine( x, y - length + 20, x, y )
surface.DrawLine( x + length - 20, y , x, y )
surface.DrawLine( x - length + 20, y, x, y )
surface.SetDrawColor( 0,255,0,255 )
surface.DrawLine( x-50, y-30, x-50, y-50 )
surface.DrawLine( x-50, y-50, x-20, y-50 )

surface.DrawLine( x+50, y-30, x+50, y-50 )
surface.DrawLine( x+50, y-50, x+20, y-50 )

surface.DrawLine( x-50, y+30, x-50, y+50 )
surface.DrawLine( x-50, y+50, x-20, y+50 )

surface.DrawLine( x+50, y+30, x+50, y+50 )
surface.DrawLine( x+50, y+50, x+20, y+50 )
elseif h4x.cross_swastika == 1 then
surface.SetDrawColor( 0,0,255,255 )
surface.DrawOutlinedRect(x-50,y-50,101,101)
surface.SetDrawColor( 0,255,0,255 )
surface.DrawLine( x-50, y-30, x-50, y-50 )
surface.DrawLine( x-50, y-50, x-20, y-50 )

surface.DrawLine( x+50, y-30, x+50, y-50 )
surface.DrawLine( x+50, y-50, x+20, y-50 )

surface.DrawLine( x-50, y+30, x-50, y+50 )
surface.DrawLine( x-50, y+50, x-20, y+50 )

surface.DrawLine( x+50, y+30, x+50, y+50 )
surface.DrawLine( x+50, y+50, x+20, y+50 )

surface.SetDrawColor( 255,0,0,255 )
surface.DrawLine( x-40, y, x+40, y )
surface.DrawLine( x, y-40, x, y+40 )

surface.DrawLine( x+40, y+40, x+40, y )
surface.DrawLine( x-40, y-40, x-40, y )

surface.DrawLine( x+40, y-40, x, y-40 )
surface.DrawLine( x-40, y+40, x, y+40 )
elseif h4x.cross_swastika == 2 then
for i = 1,63 do
surface.SetDrawColor( 0,255,0,255 )

surface.SetFont("TabLarge")
surface.SetTextPos(x+65,y-63 )
if LocalPlayer():Health() > 75 then
surface.SetTextColor(0,255,0,255)
elseif LocalPlayer():Health() < 75 then
surface.SetTextColor(255,255,0,255)
end
if LocalPlayer():Health() < 50 then
surface.SetTextColor(255,0,0,255)
end
local we, he = surface.GetTextSize("Armor: "..LocalPlayer():Armor())
surface.SetTextPos(x-65-we,y-63 )
surface.SetTextColor(0,255,0,255)
surface.DrawText("Armor: "..LocalPlayer():Armor())

surface.DrawLine( x-63, y-30, x-63, y-63 )
surface.DrawLine( x-63, y-63, x-30, y-63 )

surface.DrawLine( x+63, y-30, x+63, y-63 )
surface.DrawLine( x+63, y-63, x+30, y-63 )

surface.DrawLine( x-63, y+30, x-63, y+63 )
surface.DrawLine( x-63, y+63, x-30, y+63 )

surface.DrawLine( x+63, y+30, x+63, y+63 )
surface.DrawLine( x+63, y+63, x+30, y+63 )

surface.SetDrawColor( i*4,0,0,255 )
surface.DrawLine( x-63+i, y, x+63-i, y )
surface.DrawLine( x, y-63+i, x, y+63-i )
surface.DrawLine( x-63+i, y-1, x+63-i, y-1 )
surface.DrawLine( x-1, y-63+i, x-1, y+63-i )
surface.DrawLine( x-63+i, y+1, x+63-i, y+1 )
surface.DrawLine( x+1, y-63+i, x+1, y+63-i )
surface.DrawLine( x-63+i, y-2, x+63-i, y-2 )
surface.DrawLine( x-2, y-63+i, x-2, y+63-i )
surface.DrawLine( x-63+i, y+2, x+63-i, y+2 )
surface.DrawLine( x+2, y-63+i, x+2, y+63-i )
end
end
--[[
	local center = Vector( ScrW() / 2, ScrH() / 2, 0 )
	local scale = Vector( length, length, 0 )
	local segmentdist = 360 / ( 2 * math.pi * math.max( scale.x, scale.y ) / 2 )
	surface.SetDrawColor( 255, 255, 255, 255 )
	for a = 0, 360 - segmentdist, segmentdist do
	surface.DrawLine( center.x + math.cos( math.rad( a ) ) * scale.x, center.y - math.sin( math.rad( a ) ) * scale.y, center.x + math.cos( math.rad( a + segmentdist ) ) * scale.x, center.y - math.sin( math.rad( a + segmentdist ) ) * scale.y )
end
]]--

end)
hook.Add("Initialize", "ESPInitialize", OnInitialize)
hook.Add("HUDPaint", "ESPDraw", DrawESP)
print([[
	BENBOOST9 IS PROUD TO PRESENT...
   _______________________________
 /    Benboost9 GMOD hack V0.3     \
|    _        _         _____       |
|   | |      | |       |  _  |      |
|   | |      | |       | | | |      |
|   | |      | |       | |_| |      |
|   | |___   | |___    |  ___|      |
|   |  _  |  |  _  |   | |          |
|   | |_| |  | |_| |   | |___       |
|   |_____|  |_____|   |_____|      |
|       ________       _______      |
|      |  ____  |     |____   |     |
|      | |    | |      ____|  |     |
|      | |    | |     |____   |     |
|      | |____| |  _   ____|  |     |
|      |________| |_| |_______|     |
 \________________________________ /

]])
concommand.Add("Menu_H4x",function()
local DermaPanel = vgui.Create( "DFrame" )
DermaPanel:SetPos( 0, 0 )
DermaPanel:SetSize( 255, 255+25 )
DermaPanel:SetTitle( "h4x:" )
DermaPanel:SetVisible( true )
DermaPanel:SetDraggable( true )
DermaPanel:ShowCloseButton( true )
DermaPanel.Paint = function()
for i=0,25 do
surface.SetDrawColor( i*10, 0, 250-i*10, 100)
surface.DrawLine( 0, i, 255, i )
end
for i=0,255 do
surface.SetDrawColor( i, 0, 255-i, 100)
surface.DrawLine( 0, i+25, 255, i+25 )
end
surface.SetDrawColor( 0, 255, 0, 255)
surface.DrawOutlinedRect(0,0,255,26)
local length = 30
local gap = 20
surface.SetDrawColor( 255,0,0,255 )
surface.SetDrawColor( 0,255,0,255 )
surface.DrawLine( 0, 25, 0, 75 )
surface.DrawLine( 0, 25, 50, 25 )

surface.DrawLine( 255, 25, 205, 25 )
surface.DrawLine( 254, 25, 254, 75 )

surface.DrawLine( 254, 204+21, 254, 254+25  )
surface.DrawLine( 254, 255+24, 204, 254+25  )

surface.DrawLine( 0, 254+25,50, 254+25 )
surface.DrawLine( 0, 204+25,0, 254+25 )
surface.SetDrawColor( 0, 255, 0, 255)
surface.DrawOutlinedRect(0,0,255,26)
end
local button1 = vgui.Create( "DButton", DermaPanel )
button1:SetSize( 100, 30 )
button1:SetPos( 10, 35 )
button1.Paint = function()
if h4x.aim_on==1 then
draw.RoundedBox(0, 0, 0, button1:GetWide(),button1:GetTall(), Color( 0,255,0,150 ) )
surface.SetDrawColor( 255, 255, 255, 255)
surface.DrawOutlinedRect(0,0,button1:GetWide(),button1:GetTall())
button1:SetText( "Disable aim" )
else
draw.RoundedBox(0, 0, 0, button1:GetWide(),button1:GetTall(), Color( 255,0,0,150 ) )
surface.SetDrawColor( 255, 255, 255, 255)
surface.DrawOutlinedRect(0,0,button1:GetWide(),button1:GetTall())
button1:SetText( "Enable aim" )
end
end
button1.DoClick = function()
if h4x.aim_on==1 then
h4x.aim_on = 0
else
h4x.aim_on = 1
end
end
local button2 = vgui.Create( "DButton", DermaPanel )
button2:SetSize( 100, 30 )
button2:SetPos( 10, 65+1 )
button2.Paint = function()
draw.RoundedBox(0, 0, 0, button2:GetWide(),button2:GetTall(), Color( 50,50,50,150 ) )
surface.SetDrawColor( 255, 255, 255, 255)
surface.DrawOutlinedRect(0,0,button1:GetWide(),button1:GetTall())
if h4x.aim_on_NPC==1 then
button2:SetText( "Switch to Player aim" )
else
button2:SetText( "Switch to NPC aim" )
end
end
button2.DoClick = function()
if h4x.aim_on_NPC==1 then
h4x.aim_on_NPC = 0
else
h4x.aim_on_NPC = 1
end
end
local button3 = vgui.Create( "DButton", DermaPanel )
button3:SetSize( 100, 30 )
button3:SetPos( 10, 65+32 )
button3.Paint = function()
if h4x.esp_showNames==1 then
draw.RoundedBox(0, 0, 0, button1:GetWide(),button1:GetTall(), Color( 0,255,0,150 ) )
surface.SetDrawColor( 255, 255, 255, 255)
surface.DrawOutlinedRect(0,0,button1:GetWide(),button1:GetTall())
button3:SetText( "Hide Name ESP" )
else
draw.RoundedBox(0 ,0, 0, button1:GetWide(),button1:GetTall(), Color( 255,0,0,150 ) )
surface.SetDrawColor( 255, 255, 255, 255)
surface.DrawOutlinedRect(0,0,button1:GetWide(),button1:GetTall())
button3:SetText( "Show Name ESP" )
end
end
button3.DoClick = function()
if h4x.esp_showNames==1 then
h4x.esp_showNames = 0
else
h4x.esp_showNames = 1
end
end
local button4 = vgui.Create( "DButton", DermaPanel )
button4:SetSize( 100, 30 )
button4:SetPos( 10, 65+30+33 )
button4.Paint = function()
if h4x.radar==1 then
draw.RoundedBox(0, 0, 0, button1:GetWide(),button1:GetTall(), Color( 0,255,0,150 ) )
surface.SetDrawColor( 255, 255, 255, 255)
surface.DrawOutlinedRect(0,0,button1:GetWide(),button1:GetTall())
button4:SetText( "Radar off" )
else
draw.RoundedBox(0, 0, 0, button1:GetWide(),button1:GetTall(), Color( 255,0,0,150 ) )
surface.SetDrawColor( 255, 255, 255, 255)
surface.DrawOutlinedRect(0,0,button1:GetWide(),button1:GetTall())
button4:SetText( "Radar on" )
end
end
button4.DoClick = function()
if h4x.radar==1 then
h4x.radar = 0
else
h4x.radar = 1
end
end
local button5 = vgui.Create( "DButton", DermaPanel )
button5:SetSize( 100, 30 )
button5:SetPos( 10, 65+30+35+30 )
button5.Paint = function()
draw.RoundedBox(0, 0, 0, button5:GetWide(),button5:GetTall(), Color( 50,50,50,150 ) )
surface.SetDrawColor( 255, 255, 255, 255)
surface.DrawOutlinedRect(0,0,button5:GetWide(),button5:GetTall())
button5:SetText( "switch crosshair" )
end
button5.DoClick = function()
if h4x.cross_swastika==0 then
h4x.cross_swastika = 1
elseif h4x.cross_swastika==1 then
h4x.cross_swastika = 2
elseif h4x.cross_swastika == 2 then
h4x.cross_swastika = 0
end
end
end)
------------TEST-----------
concommand.Add("colorselector",function()
local DermaPanel = vgui.Create( "DFrame" )
DermaPanel:SetPos( 0, 0 )
DermaPanel:SetSize( 255, 255+25 )
DermaPanel:SetTitle( "Color menu:" )
DermaPanel:SetVisible( true )
DermaPanel:SetDraggable( true )
DermaPanel:ShowCloseButton( true )
DermaPanel.Paint = function()
for i=0,25 do
surface.SetDrawColor( i*10, 0, 250-i*10, 100)
surface.DrawLine( 0, i, 255, i )
end
for i=0,255 do
surface.SetDrawColor( i, 0, 255-i, 100)
surface.DrawLine( 0, i+25, 255, i+25 )
end
surface.SetDrawColor( 0, 255, 0, 255)
surface.DrawOutlinedRect(0,0,255,26)
local length = 30
local gap = 20
local x = 127
local y = 127+25
surface.SetDrawColor( 255,0,0,255 )
surface.DrawLine( x, y + length - 20, x, y )
surface.DrawLine( x, y - length + 20, x, y )
surface.DrawLine( x + length - 20, y , x, y )
surface.DrawLine( x - length + 20, y, x, y )
surface.SetDrawColor( 0,255,0,255 )
surface.DrawLine( 0, 25, 0, 75 )
surface.DrawLine( 0, 25, 50, 25 )

surface.DrawLine( 255, 25, 205, 25 )
surface.DrawLine( 254, 25, 254, 75 )

surface.DrawLine( 254, 204+21, 254, 254+25  )
surface.DrawLine( 254, 255+24, 204, 254+25  )

surface.DrawLine( 0, 254+25,50, 254+25 )
surface.DrawLine( 0, 204+25,0, 254+25 )
surface.SetDrawColor( 0, 255, 0, 255)
surface.DrawOutlinedRect(0,0,255,26)
end
end)
function DrawRotatingCrosshair(x,y,time,length,gap)
    surface.DrawLine(
        x + (math.sin(math.rad(time)) * length),
        y + (math.cos(math.rad(time)) * length),
        x + (math.sin(math.rad(time)) * gap),
        y + (math.cos(math.rad(time)) * gap)
    )
end
--------------------
--[[function lol()
	cam.Start3D( EyePos(), EyeAngles() )
	pcall(function()
		for k, v in pairs( ents.GetAll() ) do
			if ValidEntity( v ) && util.IsValidModel( v:GetModel() or "" ) then
			if v:IsNPC() or v:IsPlayer() then
				render.SuppressEngineLighting( true )
					if( Visible(v) ) then 
					clor = Color(255,0,0,0)
					else
					clor = Color(255,255,0,0)
					end
				render.SetColorModulation( clor.r, clor.g, clor.b )
				render.SetBlend( 255 )
				SetMaterialOverride( "debug/white" )
				v:SetRenderMode(RENDERMODE_NONE)
				cam.IgnoreZ(true)
				v:DrawModel()
				cam.IgnoreZ(false)
				render.SetColorModulation( 255, 255, 0 )
				v:DrawModel()
			end
			end
		end
		end)
	cam.End3D()
end
hook.Add( "RenderScreenspaceEffects", "visuals", lol )
]]--
--------------------
concommand.Add("radar",function()
rdrclr = {}
rdrclr.r = 0
rdrclr.g = 0
rdrclr.b = 0
rdrclr.a = 255

local DermaPanel2 = vgui.Create( "DFrame" )
DermaPanel2:SetPos( 0, 0 )
DermaPanel2:SetSize( 255, 255+25 )
DermaPanel2:SetDraggable( true )
DermaPanel2:SetVisible( true )
DermaPanel2:SetTitle( "BB9Hack v0.3 Radar" )
DermaPanel2:ShowCloseButton( true )
DermaPanel2.Paint = function()
if h4x.radar == 1 then
local radar = {}
for i=0,25 do
surface.SetDrawColor( i*10, 0, 250-i*10, 100)
surface.DrawLine( 0, i, 255, i )
end
for i=0,255 do
surface.SetDrawColor( i, 0, 255-i, 100)
surface.DrawLine( 0, i+25, 255, i+25 )
end
surface.SetDrawColor( 0, 255, 0, 255)
surface.DrawOutlinedRect(0,0,255,26)
local time = (CurTime()*2) * -180        
surface.SetDrawColor(255,255,255,255)
DrawRotatingCrosshair(255/2,25+(255/2),time,255/2,0)
--Default values
radar.w = 255
radar.h = 255
radar.x = 0
radar.y = 25
radar.alphascale = 0.6
radar.bgcolor = Color(255,0,0,255)
radar.fgcolor = Color(0,0,255,255)
radar.dangercolour = Color(220,0,0,255)
radar.dangerblipcolour = Color(255,255,0,255)
radar.screendetail = 64 -- Ooh, purty.
radar.screenrotation = 0
radar.hazardmode = true 	-- If the radar finds any hazardous ents in its radius, should it bitch about it?

radar.radius = 5000

radar.player_show = true
radar.player_color = Color(0,150,255,255)
surface.CreateFont("Arial",64,400,false,false,"RadarPlayerLabel")
radar.player_fontcolor = Color(255,255,255,255)
radar.player_showname = true
radar.player_showhealth = true
radar.player_showarmor = false --TO DO
radar.player_showammo = true


radar.scanfor = {"player", "blastfungus", "rpg_missile", "crossbow_bolt", "npc_", "sent_", "prop_vehicle_"}		-- What should the radar look for?  Accepts partial names.
radar.dangerous = {"sent_nuke_missile", "sent_nuke_detpack"}		-- What should the radar consider extremely hazardous? ("Hazard Mode")  Only accepts full names.

-- The danger table relies on the scan table, make sure your dangerous ent is in both tables.


------------------------------------------------------------------
-- Don't edit under here unless you're the trigonometry GOD. D: --
------------------------------------------------------------------


radar.bgcolorbak = radar.bgcolor
radar.fgcolorbak = radar.fgcolor
radar.player_colorbak = radar.player_color


local color_ascale = function(col,scale) return Color(col.r,col.g,col.b,col.a*scale) end

-- Without further ado, let's rock.

	local ETable = {}
	local PulseRadar = false

	local lpl = LocalPlayer()
	
	
	if ( radar.player_show ) then
	
	--draw.RoundedBox( radar.w/2, radar.x, radar.y, radar.w, radar.h, radar.bgcolor ) --Looks like shit
	local vertices = {}
	for i=1,radar.screendetail do
		local shift = math.fmod(CurTime()*radar.screenrotation,360)
		local sizescale = 1 --+ math.sin(CurTime())/10
		local tab = {}
		tab.x = radar.x+radar.w/2 + math.cos(math.Deg2Rad((360/radar.screendetail)*i+shift)) * radar.w/2 * sizescale
		tab.y = radar.y+radar.h/2 + math.sin(math.Deg2Rad((360/radar.screendetail)*i+shift)) * radar.h/2 * sizescale
		tab.u = 0
		tab.v = 0
		table.insert(vertices,tab)
	end
	surface.SetTexture(surface.GetTextureID("vgui/white"))
	surface.SetDrawColor(radar.bgcolor.r,radar.bgcolor.g,radar.bgcolor.b,radar.bgcolor.a*radar.alphascale)
    draw.RoundedBox( 0, radar.x+radar.w/2, radar.y, 1, radar.h, color_ascale(radar.fgcolor,radar.alphascale) )
	draw.RoundedBox( 0, radar.x, radar.y+radar.h/2, radar.w, 1, color_ascale(radar.fgcolor,radar.alphascale) )
local length = 30
local gap = 20
local x = 127
local y = 127+25
surface.SetDrawColor( 255,0,0,255 )
surface.DrawLine( x, y + length - 20, x, y )
surface.DrawLine( x, y - length + 20, x, y )
surface.DrawLine( x + length - 20, y , x, y )
surface.DrawLine( x - length + 20, y, x, y )
surface.SetDrawColor( 0,255,0,255 )
surface.DrawLine( 0, 25, 0, 75 )
surface.DrawLine( 0, 25, 50, 25 )

surface.DrawLine( 255, 25, 205, 25 )
surface.DrawLine( 254, 25, 254, 75 )

surface.DrawLine( 254, 204+21, 254, 254+25  )
surface.DrawLine( 254, 255+24, 204, 254+25  )

surface.DrawLine( 0, 254+25,50, 254+25 )
surface.DrawLine( 0, 204+25,0, 254+25 )
surface.SetDrawColor( 0, 255, 0, 255)
surface.DrawOutlinedRect(0,0,255,26)
	local players = {}

	for i = 1, 1000 do -- Because running a loop 1000 times per frame ensures major luls.  Also ents.GetInSphere is serverside. (which sucks major donkey balls.)

			local ent = ents.GetByIndex(i)

			if ent:IsValid() then
				local type = ent:GetClass()

				for k, v in ipairs(radar.scanfor) do
					if string.find(type,v) then
						table.insert(players,ent)
					end
				end
			end
		end

		for i, pl in ipairs(players) do
			local cx = radar.x+radar.w/2
			local cy = radar.y+radar.h/2
			local vdiff = pl:GetPos()-lpl:GetPos()
			local dummy = nil   -- Because I'm lazy.


	-- Player Check.
			if (vdiff:Length() > radar.radius) then dummy = nil else -- In soviet russia, code badly you!
				if pl:IsPlayer() then
					if ( pl:Alive() and lpl~=pl ) then
						local px = (vdiff.x/radar.radius)
						local py = (vdiff.y/radar.radius)
						local z = math.sqrt( px*px + py*py )
						local phi = math.Deg2Rad( math.Rad2Deg( math.atan2( px, py ) ) - math.Rad2Deg( math.atan2( lpl:GetAimVector().x, lpl:GetAimVector().y ) ) - 90 )
						px = math.cos(phi)*z
						py = math.sin(phi)*z
						draw.RoundedBox( 0, cx+px*radar.w/2-4, cy+py*radar.h/2-4, 8, 8, color_ascale(radar.player_color,255) )
						surface.SetDrawColor( 0,0,0,255 )
						surface.DrawOutlinedRect( cx+px*radar.w/2-4, cy+py*radar.h/2-4, 8, 8)
						if radar.player_showname then
							draw.DrawText(pl:Name(), "Default", cx+px*radar.w/2, cy+py*radar.h/2+8, color_ascale(radar.player_fontcolor,radar.alphascale), TEXT_ALIGN_CENTER)
						end
						if radar.player_showhealth then
							draw.RoundedBox( 0, cx+px*radar.w/2-12, cy+py*radar.h/2+20, (math.min(100,pl:Health())/100)*24, 4, Color(255,0,0,255) )
						end
						if radar.player_showammo then
							if (lpl:GetActiveWeapon().Clip1~=nil and lpl:GetActiveWeapon():Clip1() > 0) then
								draw.RoundedBox( 0, cx+px*radar.w/2-12, cy+py*radar.h/2+26, math.min(1,(lpl:GetAmmoCount(lpl:GetActiveWeapon():GetPrimaryAmmoType())/lpl:GetActiveWeapon():Clip1()))*24, 4, Color(255,200,0,255) ) --BUGGED?
							else
								draw.RoundedBox( 0, cx+px*radar.w/2-12, cy+py*radar.h/2+26, 24, 4, Color(255,200,0,255) )
							end
						end
					end
				end


	-- Ent Check.
				if ((not pl:IsPlayer()) and pl:IsValid() ) then

				    local isDangerous = false


				--Fill up the hazard mode table.
					if ( radar.hazardmode ) then
						for k,v in ipairs(radar.dangerous) do
						    if (pl:GetClass() == v) then
						        table.insert(ETable,pl)
						        isDangerous = true
							end
						end
					end
					
					local px = (vdiff.x/radar.radius)
					local py = (vdiff.y/radar.radius)
					local z = math.sqrt( px*px + py*py )
					local phi = math.Deg2Rad( math.Rad2Deg( math.atan2( px, py ) ) - math.Rad2Deg( math.atan2( lpl:GetAimVector().x, lpl:GetAimVector().y ) ) - 90 )
					px = math.cos(phi)*z
					py = math.sin(phi)*z

					if (isDangerous == false) then -- Leave this one for the hazard mode so we can give it a lovely coloured dot. Oh the frivolity.
						draw.RoundedBox( 0, cx+px*radar.w/2-4, cy+py*radar.h/2-4, 8, 8, color_ascale(radar.player_color,255) )
						surface.SetDrawColor( 0,0,0,255 )
						surface.DrawOutlinedRect( cx+px*radar.w/2-4, cy+py*radar.h/2-4, 8, 8)
					end


					if radar.player_showname then

					--Let's do some name parsing! Whoooo... god dammit.
				
					--To add an extra name parsing thingamajobby, copy/paste one of the elseifs,
					--change the string, count the number of letters, add one, and use that as the last number.

						local nametag = ""
						if string.find(pl:GetClass(),"blastfungus") then nametag = "" -- There will usually be so many of these that adding names will look messy.
						elseif string.find(pl:GetClass(),"npc_") then nametag = string.sub(pl:GetClass(),5)
						elseif string.find(pl:GetClass(),"sent_") then nametag = string.sub(pl:GetClass(),6)
						elseif string.find(pl:GetClass(),"prop_vehicle_") then nametag = string.sub(pl:GetClass(),14)
						else nametag = pl:GetClass()
						end

						local nametable = string.Explode("_",nametag)
						nametag = table.concat(nametable," ")
						local nametag1 = string.sub(nametag,0,1)
						local nametag2 = string.sub(nametag,2)
						nametag1 = string.upper(nametag1)
						nametag = nametag1..nametag2


					end
				end
   			end
	 	end
	 	

   -- Hazard Mode.
   -- This is where things get hacky.  Well, more hacky.
   
   		local count = table.Count(ETable)
   		
   		if ( count > 0 ) then 	-- Oooooh shit.
   		for k,pl in ipairs(ETable) do
   			local cx = radar.x+radar.w/2
			local cy = radar.y+radar.h/2
			local vdiff = pl:GetPos()-lpl:GetPos()
			
   			local px = (vdiff.x/radar.radius)
			local py = (vdiff.y/radar.radius)
			local z = math.sqrt( px*px + py*py )
			local phi = math.Deg2Rad( math.Rad2Deg( math.atan2( px, py ) ) - math.Rad2Deg( math.atan2( lpl:GetAimVector().x, lpl:GetAimVector().y ) ) - 90 )
			px = math.cos(phi)*z
			py = math.sin(phi)*z
			draw.RoundedBox( 0, (cx+px*radar.w/2-8), (cy+py*radar.h/2-8), 16, 16, color_ascale(radar.dangerblipcolour,255) )
			surface.SetDrawColor( 0,0,0,255 )
			surface.DrawOutlinedRect( cx+px*radar.w/2-4, cy+py*radar.h/2-4, 8, 8)
		end
			
			radar.bgcolor = Color(255,255,255,0)
			radar.fgcolor = Color(60,60,60,100)
			
			PulseRadar = true
			
			
 			
		end
	end
	end

	end
end)
local function GetMeta(name)
	return table.Copy(_R[name] or {})
end

local VecM = GetMeta("Vector")
local CmdM = GetMeta("CUserCmd")

function drawchamz(ent)
--[[
				for k, e in pairs( ents.FindByClass("npc_*") ) do
				
			local light, col = DynamicLight( e:EntIndex() )

				light.Pos = e:GetPos() + Vector( 0, 0, 10 )
				if Visible(ent) then
				light.r = 0
				light.g = 255
				light.b = 0
				else
				light.r = 255
				light.g = 0
				light.b = 0
				end
				light.Brightness = 10
				light.Decay = 100 * 5
				light.Size = 200
				light.DieTime = CurTime() + 1
			end

				render.SuppressEngineLighting( true )
				SetMaterialOverride( "debug/white" )
				render.SetColorModulation( 0, 255, 0 )
				ent:DrawModel()
				render.SetColorModulation( 255, 0, 0 )
							]]--
							--cam.Start3D( EyePos(), EyeAngles() )
							--pcall(function()
							---cam.IgnoreZ(1)
							--SetMaterialOverride("debug_white")
							--render.SetColorModulation(255, 0, 0)
							---ent:DrawModel()
							--end)
							--cam.End3D()
end

local entityxmeta = _R.Entity
local entityxsetmaterial = entityxmeta.SetMaterial
--[[hook.Add("RenderScreenspaceEffects","",function()
			cam.Start3D( EyePos(), EyeAngles() )
for k, NPCs in pairs(ents.FindByClass("npc_*")) do
			local mat = NPCs:GetMaterial()
			render.SuppressEngineLighting( true )
			render.SetColorModulation( 1, 0, 0)
			NPCs:SetModelScale(Vector(1.1,1.1,1))
			entityxsetmaterial(NPCs, "debug_white")
			cam.IgnoreZ(true)
			NPCs:DrawModel()
			cam.IgnoreZ(false)
			render.SuppressEngineLighting( false )
			render.SetColorModulation( 1, 1, 1 )
			NPCs:SetModelScale(Vector(1,1,1))
			entityxsetmaterial(NPCs, mat)
			NPCs:DrawModel()
	end
	end)]]--
--[[
function OnPaint()
	local pos = LocalPlayer():GetPos();
	local ang = LocalPlayer():GetAngles();
 
	cam.Start3D( pos + ang:Forward() * 32 + ang:Up() * 8, LocalPlayer():EyeAngles() );
for i=0,255 do
surface.SetDrawColor( 0, i, 0, 200 )
surface.DrawLine( 0, i, 265, i )
end
--Default values
local radar = {}
radar.w = 255
radar.h = 255
radar.x = 0
radar.y = 0
radar.alphascale = 0.6
radar.bgcolor = Color(255,0,0,255)
radar.fgcolor = Color(0,0,255,255)
radar.dangercolour = Color(220,0,0,255)
radar.dangerblipcolour = Color(255,255,0,255)
radar.screendetail = 64 -- Ooh, purty.
radar.screenrotation = 0
radar.hazardmode = true 	-- If the radar finds any hazardous ents in its radius, should it bitch about it?

radar.radius = 5000

radar.player_show = true
radar.player_color = Color(30,255,30,255)
surface.CreateFont("Arial",64,400,false,false,"RadarPlayerLabel")
radar.player_fontcolor = Color(255,255,255,255)
radar.player_showname = true
radar.player_showhealth = true
radar.player_showarmor = false --TO DO
radar.player_showammo = true


radar.scanfor = {"player", "blastfungus", "rpg_missile", "crossbow_bolt", "npc_", "sent_", "prop_vehicle_"}		-- What should the radar look for?  Accepts partial names.
radar.dangerous = {"sent_nuke_missile", "sent_nuke_detpack"}		-- What should the radar consider extremely hazardous? ("Hazard Mode")  Only accepts full names.

-- The danger table relies on the scan table, make sure your dangerous ent is in both tables.


------------------------------------------------------------------
-- Don't edit under here unless you're the trigonometry GOD. D: --
------------------------------------------------------------------


radar.bgcolorbak = radar.bgcolor
radar.fgcolorbak = radar.fgcolor
radar.player_colorbak = radar.player_color


local color_ascale = function(col,scale) return Color(col.r,col.g,col.b,col.a*scale) end

-- Without further ado, let's rock.

	local ETable = {}
	local PulseRadar = false

	local lpl = LocalPlayer()
	
	
	if ( radar.player_show ) then
	
	--draw.RoundedBox( radar.w/2, radar.x, radar.y, radar.w, radar.h, radar.bgcolor ) --Looks like shit
	local vertices = {}
	for i=1,radar.screendetail do
		local shift = math.fmod(CurTime()*radar.screenrotation,360)
		local sizescale = 1 --+ math.sin(CurTime())/10
		local tab = {}
		tab.x = radar.x+radar.w/2 + math.cos(math.Deg2Rad((360/radar.screendetail)*i+shift)) * radar.w/2 * sizescale
		tab.y = radar.y+radar.h/2 + math.sin(math.Deg2Rad((360/radar.screendetail)*i+shift)) * radar.h/2 * sizescale
		tab.u = 0
		tab.v = 0
		table.insert(vertices,tab)
	end
	surface.SetTexture(surface.GetTextureID("vgui/white"))
	surface.SetDrawColor(radar.bgcolor.r,radar.bgcolor.g,radar.bgcolor.b,radar.bgcolor.a*radar.alphascale)
	
    draw.RoundedBox( 0, radar.x+radar.w/2, radar.y, 1, radar.h, color_ascale(radar.fgcolor,radar.alphascale) )
	draw.RoundedBox( 0, radar.x, radar.y+radar.h/2, radar.w, 1, color_ascale(radar.fgcolor,radar.alphascale) )
	
	local players = {}

	for i = 1, 1000 do -- Because running a loop 1000 times per frame ensures major luls.  Also ents.GetInSphere is serverside. (which sucks major donkey balls.)

			local ent = ents.GetByIndex(i)

			if ent:IsValid() then
				local type = ent:GetClass()

				for k, v in ipairs(radar.scanfor) do
					if string.find(type,v) then
						table.insert(players,ent)
					end
				end
			end
		end

		for i, pl in ipairs(players) do
			local cx = radar.x+radar.w/2
			local cy = radar.y+radar.h/2
			local vdiff = pl:GetPos()-lpl:GetPos()
			local dummy = nil   -- Because I'm lazy.


	-- Player Check.
			if (vdiff:Length() > radar.radius) then dummy = nil else -- In soviet russia, code badly you!
				if pl:IsPlayer() then
					if ( pl:Alive() and lpl~=pl ) then
						local px = (vdiff.x/radar.radius)
						local py = (vdiff.y/radar.radius)
						local z = math.sqrt( px*px + py*py )
						local phi = math.Deg2Rad( math.Rad2Deg( math.atan2( px, py ) ) - math.Rad2Deg( math.atan2( lpl:GetAimVector().x, lpl:GetAimVector().y ) ) - 90 )
						px = math.cos(phi)*z
						py = math.sin(phi)*z
						draw.RoundedBox( 4, cx+px*radar.w/2-4, cy+py*radar.h/2-4, 8, 8, color_ascale(radar.player_color,radar.alphascale) )
						if radar.player_showname then
							draw.DrawText(pl:Name(), "Default", cx+px*radar.w/2, cy+py*radar.h/2+8, color_ascale(radar.player_fontcolor,radar.alphascale), TEXT_ALIGN_CENTER)
						end
						if radar.player_showhealth then
							draw.RoundedBox( 0, cx+px*radar.w/2-12, cy+py*radar.h/2+20, (math.min(100,pl:Health())/100)*24, 4, Color(255,0,0,255) )
						end
						if radar.player_showammo then
							if (lpl:GetActiveWeapon().Clip1~=nil and lpl:GetActiveWeapon():Clip1() > 0) then
								draw.RoundedBox( 0, cx+px*radar.w/2-12, cy+py*radar.h/2+26, math.min(1,(lpl:GetAmmoCount(lpl:GetActiveWeapon():GetPrimaryAmmoType())/lpl:GetActiveWeapon():Clip1()))*24, 4, Color(255,200,0,255) ) --BUGGED?
							else
								draw.RoundedBox( 0, cx+px*radar.w/2-12, cy+py*radar.h/2+26, 24, 4, Color(255,200,0,255) )
							end
						end
					end
				end


	-- Ent Check.
				if ((not pl:IsPlayer()) and pl:IsValid() ) then

				    local isDangerous = false


				--Fill up the hazard mode table.
					if ( radar.hazardmode ) then
						for k,v in ipairs(radar.dangerous) do
						    if (pl:GetClass() == v) then
						        table.insert(ETable,pl)
						        isDangerous = true
							end
						end
					end
					
					local px = (vdiff.x/radar.radius)
					local py = (vdiff.y/radar.radius)
					local z = math.sqrt( px*px + py*py )
					local phi = math.Deg2Rad( math.Rad2Deg( math.atan2( px, py ) ) - math.Rad2Deg( math.atan2( lpl:GetAimVector().x, lpl:GetAimVector().y ) ) - 90 )
					px = math.cos(phi)*z
					py = math.sin(phi)*z

					if (isDangerous == false) then -- Leave this one for the hazard mode so we can give it a lovely coloured dot. Oh the frivolity.
						draw.RoundedBox( 4, cx+px*radar.w/2-4, cy+py*radar.h/2-4, 8, 8, color_ascale(radar.player_color,radar.alphascale) )
					end


					if radar.player_showname then

					--Let's do some name parsing! Whoooo... god dammit.
				
					--To add an extra name parsing thingamajobby, copy/paste one of the elseifs,
					--change the string, count the number of letters, add one, and use that as the last number.

						local nametag = ""
						if string.find(pl:GetClass(),"blastfungus") then nametag = "" -- There will usually be so many of these that adding names will look messy.
						elseif string.find(pl:GetClass(),"npc_") then nametag = string.sub(pl:GetClass(),5)
						elseif string.find(pl:GetClass(),"sent_") then nametag = string.sub(pl:GetClass(),6)
						elseif string.find(pl:GetClass(),"prop_vehicle_") then nametag = string.sub(pl:GetClass(),14)
						else nametag = pl:GetClass()
						end

						local nametable = string.Explode("_",nametag)
						nametag = table.concat(nametable," ")
						local nametag1 = string.sub(nametag,0,1)
						local nametag2 = string.sub(nametag,2)
						nametag1 = string.upper(nametag1)
						nametag = nametag1..nametag2

							draw.DrawText(nametag, "Default", cx+px*radar.w/2, cy+py*radar.h/2+8, color_ascale(radar.player_fontcolor,radar.alphascale), TEXT_ALIGN_CENTER)

					end
				end
   			end
	 	end
	 	

   -- Hazard Mode.
   -- This is where things get hacky.  Well, more hacky.
   
   		local count = table.Count(ETable)
   		
   		if ( count > 0 ) then 	-- Oooooh shit.
   		for k,pl in ipairs(ETable) do
   			local cx = radar.x+radar.w/2
			local cy = radar.y+radar.h/2
			local vdiff = pl:GetPos()-lpl:GetPos()
			
   			local px = (vdiff.x/radar.radius)
			local py = (vdiff.y/radar.radius)
			local z = math.sqrt( px*px + py*py )
			local phi = math.Deg2Rad( math.Rad2Deg( math.atan2( px, py ) ) - math.Rad2Deg( math.atan2( lpl:GetAimVector().x, lpl:GetAimVector().y ) ) - 90 )
			px = math.cos(phi)*z
			py = math.sin(phi)*z
			
			draw.RoundedBox( 8, (cx+px*radar.w/2-8), (cy+py*radar.h/2-8), 16, 16, color_ascale(radar.dangerblipcolour,radar.alphascale) ) -- M-M-MONSTER DOT.
		end
			
			radar.bgcolor = Color(255,255,255,0)
			radar.fgcolor = Color(60,60,60,100)
			
			PulseRadar = true
			
			
 			
		end
	end
	cam.End3D();
end
 
hook.Add( "HUDPaint", "OnPaint", OnPaint )
]]--
function box( e )
	local ply, pos = LocalPlayer(), nil
	local center = e:LocalToWorld( e:OBBCenter() )
	local min, max = e:OBBMins(), e:OBBMaxs()
	local dim = max - min
	local z = max + min
	
	local frt	= ( e:GetForward() ) * ( dim.y / 2 )
	local rgt	= ( e:GetRight() ) * ( dim.x / 2 )
	local top	= ( e:GetUp() ) * ( dim.z / 2 )
	local bak	= ( e:GetForward() * -1 ) * ( dim.y / 2 )
	local lft	= ( e:GetRight() * -1 ) * ( dim.x / 2 )
	local btm	= ( e:GetUp() * -1 ) * ( dim.z / 2 )
	
	local d, v = math.Round( e:GetPos():Distance( ply:GetShootPos() ) )
	v = d / 30
	
	pos = e:LocalToWorld( top + top ) + Vector( 0, 0, v + 10 )
	if ( e:IsWeapon() ) then pos = e:LocalToWorld( e:OBBCenter() ) end
	
	local FRT 	= center + frt + rgt + top; FRT = FRT:ToScreen()
	local BLB 	= center + bak + lft + btm; BLB = BLB:ToScreen()
	local FLT	= center + frt + lft + top; FLT = FLT:ToScreen()
	local BRT 	= center + bak + rgt + top; BRT = BRT:ToScreen()
	local BLT 	= center + bak + lft + top; BLT = BLT:ToScreen()
	local FRB 	= center + frt + rgt + btm; FRB = FRB:ToScreen()
	local FLB 	= center + frt + lft + btm; FLB = FLB:ToScreen()
	local BRB 	= center + bak + rgt + btm; BRB = BRB:ToScreen()
	
	pos = pos:ToScreen()
	
	local maxX = math.max( FRT.x,BLB.x,FLT.x,BRT.x,BLT.x,FRB.x,FLB.x,BRB.x )
	local minX = math.min( FRT.x,BLB.x,FLT.x,BRT.x,BLT.x,FRB.x,FLB.x,BRB.x )
	local maxY = math.max( FRT.y,BLB.y,FLT.y,BRT.y,BLT.y,FRB.y,FLB.y,BRB.y)
	local minY = math.min( FRT.y,BLB.y,FLT.y,BRT.y,BLT.y,FRB.y,FLB.y,BRB.y )
	
	return maxX, minX, maxY, minY
end
local CL = LocalPlayer()
local wep = LocalPlayer():GetActiveWeapon()
local NoSpreadHere=false
if #file.Find("../lua/includes/modules/gmcl_dec0.dll")>=1 then
NoSpreadHere=true

local MoveSpeed = 1

mysetupmove = function(objPl, move)
    if move then
        MoveSpeed = (move:GetVelocity():Length())/move:GetMaxSpeed()
    end
end

local ID_GAMETYPE = ID_GAMETYPE or -1
local GameTypes = {
    {check=function ()
        return string.find(GAMEMODE.Name,"Garry Theft Auto") ~= nil
    end,getcone=function (wep,cone)
        if type(wep.Base) == "string" then
            if wep.Base == "civilian_base" then
                local scale = cone
                if CL:KeyDown(IN_DUCK) then
        scale = math.Clamp(cone/1.5,0,10)
                elseif CL:KeyDown(IN_WALK) then
        scale = cone
                elseif (CL:KeyDown(IN_SPEED) or CL:KeyDown(IN_JUMP)) then
        scale = cone + (cone*2)
                elseif (CL:KeyDown(IN_FORWARD) or CL:KeyDown(IN_BACK) or CL:KeyDown(IN_MOVELEFT) or CL:KeyDown(IN_MOVERIGHT)) then
        scale = cone + (cone*1.5)
                end
                scale = scale + (wep:GetNWFloat("Recoil",0)/3)
                return Vector(scale,0,0)
            end
        end
        return Vector(cone,cone,cone)
    end},
    {check=function ()
        return type(TEAM_ZOMBIE) == "number" and type(TEAM_SURVIVORS) == "number" and string.find(GAMEMODE.Name,"Zombie Survival") ~= nil and type(NUM_WAVES) == "number"
    end,getcone=function (wep,cone)
        if wep:GetNetworkedBool("Ironsights",false) then
            if CL:Crouching() then
                return wep.ConeIronCrouching or cone
            end
            return wep.ConeIron or cone
        elseif 25 < LocalPlayer():GetVelocity():Length() then
            return wep.ConeMoving or cone
        elseif CL:Crouching() then
            return wep.ConeCrouching or cone
        end
        return cone
    end},
    {check=function ()
        return type(TEAM_ZOMBIE) == "number" and type(TEAM_SURVIVORS) == "number" and string.find(GAMEMODE.Name,"Zombie Survival") ~= nil
    end,getcone=function (wep,cone)
        if CL:GetVelocity():Length() > 25 then
            return wep.ConeMoving or cone
        elseif CL:Crouching() then
            return wep.ConeCrouching or cone
        end
        return cone
    end},
    {check=function ()
        return type(gamemode.Get("ZombRP")) == "table" or type(gamemode.Get("DarkRP")) == "table"
    end,getcone=function (wep, cone)
        if type(wep.Base) == "string" and (wep.Base == "ls_snip_base" or wep.Base == "ls_snip_silencebase") then
            if CL:GetNWInt( "ScopeLevel", 0 ) > 0 then 
                print("using scopecone")
                return wep.Primary.Cone
            end
            print("using unscoped cone")
            return wep.Primary.UnscopedCone
        end
        if type(wep.GetIronsights) == "function" and wep:GetIronsights() then
            return cone
        end
        return cone + .05
    end},
    {check=function ()
        return (GAMEMODE.Data == "falloutmod" and type(Music) == "table")
    end,getcone=function(wep,cone)
        if wep.Primary then
            local LastShootTime = wep.Weapon:GetNetworkedFloat( "LastShootTime", 0 ) 
            local lastshootmod = math.Clamp(wep.LastFireMax + 1 - math.Clamp( (CurTime() - LastShootTime) * wep.LastFireModifier, 0.0, wep.LastFireMax ), 1.0,wep.LastFireMaxMod) 
            local accuracy = wep.Primary.Accuracy
            if CL:IsMoving() then accuracy = accuracy * wep.MoveModifier end
            if wep.Weapon:GetNetworkedBool( "Ironsights", false ) then accuracy = accuracy * 0.75 end
            accuracy = accuracy * ((16-(Skills.Marksman or 1))/11)
            if CL:KeyDown(IN_DUCK) then
                return accuracy*wep.CrouchModifier*lastshootmod
            else
                return accuracy*lastshootmod
            end
        end
    end}
}
Check = function()
    for k, v in pairs(GameTypes) do
        if v.check() then
            ID_GAMETYPE = k
            break
        end
    end
end

concommand.Add("raidbot_predictcheck", function () Check() print("GameType = ["..ID_GAMETYPE.."]") end)

local tblNormalConeWepBases = {
    ["weapon_cs_base"] = true
}
local function GetCone(wep)
    local cone = wep.Cone
    if not cone and type(wep.Primary) == "table" and type(wep.Primary.Cone) == "number" then
        cone = wep.Primary.Cone
    end
    if wep:GetClass() == "ose_turretcontroller" then return 0 end
    return cone or 0
end

require("dec0")
local currentseed, cmd2, seed = currentseed or 0, 0, 0
local wep, vecCone, valCone
PredictSpread = function(cmd,aimAngle)
    cmd2, seed = hl2_ucmd_getpr3diction(cmd)
    if cmd2 ~= 0 then
        currentseed = seed
    end
    wep = LocalPlayer():GetActiveWeapon()
    vecCone = Vector(0,0,0)
    if wep and wep:IsValid() and type(wep.Initialize) == "function" then
        valCone = GetCone(wep)
        if( tonumber( valCone ) ) then
        vecCone = Vector( -valCone, -valCone, -valCone )
        elseif( type( valCone ) == "Vector" ) then
        vecCone = -1 * valCone
        end
    end
	if wep:GetClass() == "weapon_smg1" then
	vecCone = Vector(-0.04362,-0.04362,-0.04362)
	elseif wep:GetClass() == "weapon_pistol" then
	vecCone = Vector( -0.0100, -0.0100, -0.0100 )
	elseif wep:GetClass() == "weapon_ar2" then
	vecCone = Vector( -0.02618, -0.02618, -0.02618 )
	elseif wep:GetClass() == "weapon_shotgun" then
	vecCone = Vector( -0.08716, -0.08716, -0.08716 )
	elseif wep:GetClass() == "weapon_iceaxe" then
	vecCone = Vector(-0.15,-0.15,-0.15)
	elseif wep:GetClass() == "weapon_sniper" then
	vecCone = Vector(-0.1,-0.1,0)
	elseif wep:GetClass() == "weapon_hmg1" then
	vecCone = Vector(-0.07,-0.07,-0.07)
	elseif wep:GetClass() == "weapon_smg2" then
	vecCone = Vector(-0.07,-0.07,-0.07)
	elseif wep:GetClass() == "weapon_ar1" then
	vecCone = Vector(-0.07,-0.07,0)
	elseif wep:GetClass() == "weapon_oicw" then
	vecCone = Vector(-0.01,-0.01,-0.01)
	elseif wep:GetClass() == "weapon_bsmg1" then
	vecCone = Vector(-0.04362,-0.04362,-0.04362)
	elseif wep:GetClass() == "mill_deagle" then
	vecCone = Vector(-0.5,-0.5,-0.5)
	elseif wep:GetClass() == "weapon_para" then
	vecCone = Vector(-0.05,-0.05,0)
	
	elseif wep:GetClass() == "awp" then
	vecCone = Vector(-0.05,-0.05,0) * LocalPlayer():GetActiveWeapon().xhair.loss
	if LocalPlayer():Crouching() then
	vecCone = vecCone * .95
	end
	if !LocalPlayer():IsOnGround() then
	vecCone = vecCone * 20
	end
	elseif wep:GetClass() == "g3sg1" then
	vecCone = Vector(-0.015,-0.015,0) * LocalPlayer():GetActiveWeapon().xhair.loss
	if LocalPlayer():Crouching() then
	vecCone = vecCone * .95
	end
	if !LocalPlayer():IsOnGround() then
	vecCone = vecCone * 20
	end
	elseif wep:GetClass() == "scout" then
	vecCone = Vector(-0.05,-0.05,0) * LocalPlayer():GetActiveWeapon().xhair.loss
	if LocalPlayer():Crouching() then
	vecCone = vecCone * .95
	end
	if !LocalPlayer():IsOnGround() then
	vecCone = vecCone * 20
	end
	elseif wep:GetClass() == "sg550" then
	vecCone = Vector(-0.004,-0.004,0) * LocalPlayer():GetActiveWeapon().xhair.loss
	if LocalPlayer():Crouching() then
	vecCone = vecCone * .95
	end
	if !LocalPlayer():IsOnGround() then
	vecCone = vecCone * 20
	end
	end
	if silencer then
	vecCone = vecCone * 1.5
	end
    return hl2_manipshot(currentseed or 0, aimAngle:Forward(), vecCone):Angle()
end
end

local weapons = {
["weapon_crossbow"] = 3110,
}

function GetWeaponPredictionPos(pos , pl)
	if ValidEntity(pl) and type(pl:GetVelocity()) == "Vector" and pl.GetPos and type(pl:GetPos()) == "Vector" then
		local distance = LocalPlayer():GetPos():Distance(pl:GetPos())
		local weapon = (LocalPlayer().GetActiveWeapon and (ValidEntity(LocalPlayer():GetActiveWeapon()) and LocalPlayer():GetActiveWeapon():GetClass()))
		
		if weapon and weapons[weapon] then
			--local time = distance / weapons[weapon]
			--return pos + pl:GetVelocity() * 0.0087 - LocalPlayer():GetVelocity() * 0.0087 + pl:GetVelocity() * time-- ( pl:GetVelocity() / 47 - LocalPlayer():GetVelocity() / 47 )--+ ( pl.GetVelocity and pl:GetVelocity() * 0.0025 * LocalPlayer():Ping() )
		end
		
		return pos
	end
	return pos
end
function drbx(maxx,minx,maxy,miny)
surface.SetDrawColor( 0,255,0,255 )
end
function TraceTrigger( origin, dir, filter, ucmd )
 
	local trace = {}
 
	trace.start = origin
	trace.endpos = PredictSpread(ucmd,(origin + dir))
	trace.filter = filter
 
	return util.TraceLine( trace )
 
end
local function change()
timer.Simple(0.1,function() change() end)
	if( input.IsKeyDown( KEY_F12 ) ) then
	if silencer then
	silencer = false
	else
	silencer = true
	end
	end
end