--[[Created by ONIONZZZ, credits to Lenny (keep reading) and a huge thanks to Malboro for tidying up the script <3
]]
if SERVER then return end
 
--- Naughties
 
CreateClientConVar("onionbot_esp", 0)
 
local function coordinates( ent )
 
    local min, max = ent:OBBMins(), ent:OBBMaxs()
 
    local corners = {
            Vector( min.x, min.y, min.z ),
            Vector( min.x, min.y, max.z ),
            Vector( min.x, max.y, min.z ),
            Vector( min.x, max.y, max.z ),
            Vector( max.x, min.y, min.z ),
            Vector( max.x, min.y, max.z ),
            Vector( max.x, max.y, min.z ),
            Vector( max.x, max.y, max.z )
    }
     
    local minX, minY, maxX, maxY = ScrW() * 2, ScrH() * 2, 0, 0
 
    for _, corner in pairs( corners ) do
            local onScreen = ent:LocalToWorld( corner ):ToScreen()
            minX, minY = math.min( minX, onScreen.x ), math.min( minY, onScreen.y )
            maxX, maxY = math.max( maxX, onScreen.x ), math.max( maxY, onScreen.y )
    end
     
    return minX, minY, maxX, maxY
 
end
 
local function toto()
 
    if GetConVarNumber("onionbot_esp") != 1 then return end
 
    -- Draw Players Infos
 
    for k, v in pairs ( player.GetAll() ) do
 
        if v == LocalPlayer() or not v:Alive() then continue end
 
 
 local pos = v:GetShootPos():ToScreen()
 
 
 
 
        local Name = v:Name()
        local Rank = ""
       
 
        if v:IsAdmin() then
 
            Rank = "Admin"
 
        elseif v:IsSuperAdmin() then
 
            Rank = "Super Admin"
 
        elseif v:IsUserGroup("VIP") then
 
            Rank = "VIP"
                       
                else
                       
                        Rank = "User"
 
        end
 
        draw.DrawText( Name, "TargetID", pos.x, pos.y + 40, Color( 0, 255, 0, 255 ), 1 )
                draw.RoundedBox( 0, pos.x - 8, pos.y - 8, 8, 8, team.GetColor( v:Team() ) )
 
        if LocalPlayer():GetPos():Distance(v:GetPos()) < 600 then
 
            draw.DrawText( Rank, "TargetID", pos.x, pos.y + 20, Color( 255, 204, 0, 255 ), 1 )
 
 
        end
 
    end
       
 
 
    for k,v in pairs(player.GetAll()) do
 
        local x1,y1,x2,y2 = coordinates(v)
 
        surface.SetDrawColor(255, 233, 0, 255)
 
 
        surface.DrawLine( x1, y1, math.min( x1 + 5, x2 ), y1 )
        surface.DrawLine( x1, y1, x1, math.min( y1 + 5, y2 ) )
 
 
        surface.DrawLine( x2, y1, math.max( x2 - 5, x1 ), y1 )
        surface.DrawLine( x2, y1, x2, math.min( y1 + 5, y2 ) )
 
 
        surface.DrawLine( x1, y2, math.min( x1 + 5, x2 ), y2 )
        surface.DrawLine( x1, y2, x1, math.max( y2 - 5, y1 ) )
 
 
        surface.DrawLine( x2, y2, math.max( x2 - 5, x1 ), y2 )
        surface.DrawLine( x2, y2, x2, math.max( y2 - 5, y1 ) )
 
    end
       
       
 end
 
 
hook.Add("HUDPaint", "TOTO", toto)
 
cvars.AddChangeCallback("onionbot_esp", function()
 
    if GetConVarNumber("onionbot_esp") == 1 then
 
        hook.Add("HUDPaint", "onionbot_esp", onionbot_esp)
        chat.AddText( Color(255, 0, 0 ), "[OnionBot v5.0]", Color( 255, 255, 255 ), " OnionESP", Color( 0, 255, 63 ), " Enabled" )
 
    else
 
        hook.Remove("HUDPaint", "onionbot_esp")
        chat.AddText( Color(255, 0, 0 ), "[OnionBot v5.0]", Color( 255, 255, 255 ), " OnionESP", Color( 0, 255, 63 ), " Disabled" )
 
    end
 
end)
 
 
CreateClientConVar("onionbot_healthandwep", 0)
function healthandwep()
   for k, v in pairs ( player.GetAll() ) do
   
 
 local pos = v:GetShootPos():ToScreen()
 -- idk test
 
   local Health = v:Health()
        if v:GetActiveWeapon():IsValid() then Weapon = v:GetActiveWeapon():GetPrintName() else Weapon = "" end
                draw.DrawText( "Health: ".. Health, "TargetID", pos.x, pos.y + 60, Color( 255, 140, 0, 255 ), 1 )
        draw.DrawText( "Weapon: ".. Weapon, "TargetID", pos.x, pos.y + 80, Color( 255, 63, 0, 255 ), 1 )
   end
   end
 
   
   hook.Remove("HUDPaint", "healthandwep", healthandwep)
 
if GetConVarNumber("onionbot_healthandwep") == 1 then
        hook.Add("HUDPaint", "healthandwep", healthandwep)
end
 
cvars.AddChangeCallback("onionbot_healthandwep", function()
        if GetConVarNumber("onionbot_healthandwep") == 1 then
                hook.Add("HUDPaint", "healthandwep", healthandwep)
        else
               hook.Remove("HUDPaint", "healthandwep", healthandwep)
        end
end)
 
 
------ TB
 
CreateClientConVar("onionbot_triggerbot", 0)
 
local toggler = 0
 
local function triggerbot(cmd, ply)
 
    if LocalPlayer():Alive() then
 
        local target = LocalPlayer():GetEyeTrace().Entity
 
        if target:IsValid() then
 
            if IsValid(LocalPlayer():GetActiveWeapon()) then
 
                if LocalPlayer():GetActiveWeapon():Clip1() > 0 then
 
                    if target:IsPlayer() or target:IsNPC() then
 
                        if toggler == 0 then
 
                            cmd:SetButtons(bit.bor(cmd:GetButtons(), IN_ATTACK))
                            toggler = 1
 
                        else
 
                            cmd:SetButtons(bit.band(cmd:GetButtons(), bit.bnot(IN_ATTACK)))
                            toggler = 0
 
                        end
 
                    end
 
                end
 
            end
 
        end
 
    end
 
end
 
hook.Remove("CreateMove", "triggerbot")
 
if GetConVarNumber("onionbot_triggerbot") == 1 then
        hook.Add("CreateMove", "triggerbot", triggerbot)
end
 
 
cvars.AddChangeCallback("onionbot_triggerbot", function()
        if GetConVarNumber("onionbot_triggerbot") == 1 then
                hook.Add("CreateMove", "triggerbot", triggerbot)
chat.AddText( Color(255, 0, 0 ), "[OnionBot v5.0]", Color( 255, 255, 255 ), " OnionTrigger", Color( 0, 255, 63 ), " Enabled" )
 
        else
                hook.Remove("CreateMove", "triggerbot")
chat.AddText( Color(255, 0, 0 ), "[OnionBot v5.0]", Color( 255, 255, 255 ), " OnionTrigger", Color( 0, 255, 63 ), " Disabled" )
        end
end)
 
 
local onionhop = false
hook.Add("Think", "onionhop", function()
if onionhop then
     if (input.IsKeyDown( KEY_SPACE ) ) then
        if LocalPlayer():IsOnGround() then
            RunConsoleCommand("+jump")
            HasJumped = 1
        else
            RunConsoleCommand("-jump")
            HasJumped = 0
        end
    elseif onionhop and LocalPlayer():IsOnGround() then
        if HasJumped == 1 then
            RunConsoleCommand("-jump")
            HasJumped = 0
        end
    end
end
end)
 
concommand.Add("onion_bhop", function()
if onionhop then
    onionhop = !onionhop
chat.AddText( Color(255, 0, 0 ), "[OnionBot v5.0]", Color( 255, 255, 255 ), " OnionBhop", Color( 0, 255, 63 ), " Disabled" )
else
    onionhop = !onionhop
    chat.AddText( Color(255, 0, 0 ), "[OnionBot v5.0]", Color( 255, 255, 255 ), " OnionBhop", Color( 0, 255, 63 ), " Enabled" )
end
end)
 
 
CreateClientConVar("onionbot_hp", 0)
 
local function onionbot_hp()
        if LocalPlayer():Health() < 75 and LocalPlayer():Alive() then
                LocalPlayer():ConCommand("say /buyhealth")
        end
end
 
 
hook.Remove("Think", "onionbot_hp")
timer.Simple(1, function()
if GetConVarNumber("onionbot_hp") == 1 then
        hook.Add("Think", "onionbot_hp", onionbot_hp)
end
end)
 
 
 
cvars.AddChangeCallback("onionbot_hp", function()
        if GetConVarNumber("onionbot_hp") == 1 then
                hook.Add("Think", "onionbot_hp", onionbot_hp)
                                chat.AddText( Color(255, 0, 0 ), "[OnionBot v5.0]", Color( 255, 255, 255 ), " OnionHP", Color( 0, 255, 63 ), " Enabled" )
        else
                hook.Remove("Think", "onionbot_hp")
                                chat.AddText( Color(255, 0, 0 ), "[OnionBot v5.0]", Color( 255, 255, 255 ), " OnionHP", Color( 0, 255, 63 ), " Disabled" )
        end
end)
-- This may work on some servers considering spamming buyhealth is blocked.
 
 
 
local spam = CreateClientConVar("onionbot_spam1", "1", true, false)
 
local function onionbotspam1()
    if spam:GetBool() then
        RunConsoleCommand("say", "/ooc Clen at me brah")
    end
end
hook.Add( "Think", "spamatmebrah", onionbotspam1 )
 
local spam2 = CreateClientConVar("onionbot_spam2", "1", true, false)
 
local function onionbotspam2()
    if spam2:GetBool() then
        RunConsoleCommand("say", "/ooc l2configure")
    end
end
hook.Add( "Think", "spamatmebrah2", onionbotspam2 )
 
local spam3 = CreateClientConVar("onionbot_spam3", "1", true, false)
 
local function onionbotspam3()
    if spam3:GetBool() then
        RunConsoleCommand("say", "/ooc Not even h3x")
    end
end
hook.Add( "Think", "spamatmebrah3", onionbotspam3 )
 
local spam4 = CreateClientConVar("onionbot_spam4", "1", true, false)
 
local function onionbotspam4()
    if spam4:GetBool() then
        RunConsoleCommand("say", "/ooc My cheats mean I have a big dick")
    end
end
hook.Add( "Think", "spamatmebrah4", onionbotspam4 )
 
 
local normalspam = CreateClientConVar("onionbot_normalspam1", "1", true, false)
 
local function onionbotnormalspam1()
    if normalspam:GetBool() then
        RunConsoleCommand("say", "Clen at me brah")
    end
end
hook.Add( "Think", "spamatmebrahlol", onionbotnormalspam1 )
 
local normalspam2 = CreateClientConVar("onionbot_normalspam2", "1", true, false)
 
local function onionbotnormalspam2()
    if normalspam2:GetBool() then
        RunConsoleCommand("say", "l2configure")
    end
end
hook.Add( "Think", "spamatmebrah2lol", onionbotnormalspam2 )
 
local normalspam3 = CreateClientConVar("onionbot_normalspam3", "1", true, false)
 
local function onionbotnormalspam3()
    if normalspam3:GetBool() then
        RunConsoleCommand("say", "Not even h3x")
    end
end
hook.Add( "Think", "spamatmebrah3lol", onionbotnormalspam3 )
 
local normalspam4 = CreateClientConVar("onionbot_normalspam4", "1", true, false)
 
local function onionbotnormalspam4()
    if normalspam4:GetBool() then
        RunConsoleCommand("say", "My cheats mean I have a big dick")
    end
end
hook.Add( "Think", "spamatmebrah4lol", onionbotnormalspam4 )
 
 
local showing = true
 
concommand.Add("onionbot_entfinder", function()
        if showing then
        chat.AddText( Color(255, 0, 0 ), "[OnionBot v5.0]", Color( 255, 255, 255 ), " OnionEntFinder", Color( 0, 255, 63 ), " Disabled" )
                showing = false
        else
        chat.AddText( Color(255, 0, 0 ), "[OnionBot v5.0]", Color( 255, 255, 255 ), " OnionEntFinder", Color( 0, 255, 63 ), " Enabled" )
                showing = true
        end
end)
 
local EntsToShow = {}
local OtherEnts = {}
 
concommand.Add("onionbot_entmenu", function(ply, cmd, args)
        function Reload(startX, startY)
                table.Empty(OtherEnts)
                for k,v in pairs(ents.GetAll()) do
                        local addToAllEnts = true
                       
                        for i,p in pairs(EntsToShow) do
                                if p == v:GetClass() then
                                        addToAllEnts = false
                                end
                        end
                       
                        for i,p in pairs(OtherEnts) do
                                if p == v:GetClass() then
                                        addToAllEnts = false
                                end
                        end
                       
                        if addToAllEnts then
                                table.insert(OtherEnts, v:GetClass())
                        end
                end
 
                local main = vgui.Create( "DFrame" )
                main:SetSize( 400, 250 )
                if startX and startY then
                        main:SetPos(startX, startY)
                else
                        main:Center()
                end
                main:SetTitle( "OnionBot Ent Finder" )
                main:SetVisible( true )
                main:SetDraggable( true )
                main:ShowCloseButton( true )
                main.Paint = function()
                        draw.RoundedBox( 8, 0, 0, main:GetWide(), main:GetTall(), Color(0,0,255,200) )
                end
               
                DermaList = vgui.Create( "DPanelList", main )
                DermaList:SetPos( 25,25 )
                DermaList:SetSize( 700, 500 )
                DermaList:SetSpacing( 75 )
                DermaList:EnableHorizontal( false )
                DermaList:EnableVerticalScrollbar( true )
               
                local SelectedEnts = vgui.Create("DListView")
                SelectedEnts:SetSize(150, 200)
                SelectedEnts:SetPos(0, 0)
                SelectedEnts:SetMultiSelect(false)
                SelectedEnts:AddColumn("Viewing:")
                for k,v in pairs(EntsToShow) do
                        SelectedEnts:AddLine(v)
                end
                SelectedEnts.DoDoubleClick = function(parent, index, list)
                        table.remove(EntsToShow, index)
                        main:Close()
                        local x, y = main:GetPos()
                        Reload(x, y)
                end
                DermaList:Add(SelectedEnts)
               
                local AllEnts = vgui.Create("DListView")
                AllEnts:SetSize(150, 200)
                AllEnts:SetPos(200, 0)
                AllEnts:SetMultiSelect(false)
                AllEnts:AddColumn("Ents List:")
                for k,v in pairs(OtherEnts) do
                        AllEnts:AddLine(v)
                end
                AllEnts.DoDoubleClick = function(parent, index, list)
                        table.insert(EntsToShow, OtherEnts[index])
                        main:Close()
                        local x, y = main:GetPos()
                        Reload(x, y)
                end
                DermaList:Add(AllEnts)
        end
        Reload()
end)
 
 
hook.Add("HUDPaint", "ShowEnts", function()
        if showing then
                for k,v in pairs(ents.GetAll()) do
                        local drawing = false
                       
                        for i,p in pairs(EntsToShow) do
                                if v:GetClass() == p then
                                        drawing = true
                                end
                        end
                       
                        if drawing then
                                local stuff = v:GetPos():ToScreen()
                               
                                surface.SetTextPos( stuff.x - 15, stuff.y )
                                surface.SetTextColor( 0, 0, 255, 255 )                        
                                surface.SetFont("BudgetLabel")
                                local text = v:GetClass()
                                surface.DrawText( text )
                               
                                local Width, Height = surface.GetTextSize(text)
                               
                                surface.SetDrawColor( 255, 140, 0, 255)
                                surface.DrawOutlinedRect( stuff.x - 20, stuff.y, Width + 10, Height + 5)
                        end
                end
        end
end)
 
--[[
This namechanger was made by Lenny (STEAM_0:0:30422103) and was modified by ONIONZZZ (STEAM_0:0:1736) to work with OnionBot
 
All I did was add a hook and fix it up a little so it spams, more of a namechangespammer.
 
Credits to Lenny, oubielette and ab0mbs.
]]
 
CreateClientConVar("onionbot_namechanger", 0)
local blacklist = {
        "owner",
        "moderator",
        "mod",
        "admin",
        "superadmin"
}
 
local function GenerateName(parts)
        local name = ""
                while #name <= 25 and #parts > 0 do
                        local part = parts[math.random(1, #parts)]
 
                        local len = #name + #part
                       
                        if len <= 25 then
                                name = name.." "..part
                        end
                        table.remove(parts, 1)
                end
        return name
end
 
local function sorter(v1, v2)
        if #v1 > #v2 then
                return true
        end
end
 
local function TrimNameTable(parts)
        local lplyn = string.lower(LocalPlayer():Name())
        for k, v in pairs(parts) do
                if string.find(lplyn, string.lower(v), 0, 0) then
                        table.remove(parts, k)
                end
        end
 
        table.sort(parts, sorter)
 
        return parts
end
 
local function CheckBlackList(ply)
        local failed = false
        if !ply:IsAdmin() and !ply:IsSuperAdmin() then
                for k, v in pairs(blacklist) do
                        if string.find(string.lower(ply:Name()), v, 0, 0) then
                                failed = true
                                break
                        end
                end
        else
                failed = true
        end
 
        return failed
end
 
local function GetNameParts()
        local parts = {}
        local name = ""
        for k, v in pairs(player.GetAll()) do
                if !CheckBlackList(v) then
                        for k, v in pairs(string.Explode(" ", v:Name())) do
                                table.insert(parts, v)
                        end
                end
        end
        parts = TrimNameTable(parts)
 
        name = GenerateName(parts)
       
        LocalPlayer():ConCommand("say /rpname"..name)
        print(name)
               
               
end
 hook.Remove("Think", "getnameparts", GetNameParts)
 
if GetConVarNumber("onionbot_namechanger") == 1 then
        hook.Add("Think", "getnameparts", GetNameParts)
end
 
cvars.AddChangeCallback("onionbot_namechanger", function()
        if GetConVarNumber("onionbot_namechanger") == 1 then
                hook.Add("Think", "getnameparts", GetNameParts)
        else
                hook.Remove("Think", "getnameparts")
        end
end)
 -- end of namechanger
function onion_menu()
 
 
local DermaPanel1 = vgui.Create( "DFrame" )
DermaPanel1:SetPos( 500, 4)
DermaPanel1:SetSize( 500, 125 )
DermaPanel1:SetTitle( "OnionBot Menu #2" )
DermaPanel1:SetVisible( true )
DermaPanel1:SetDraggable( true )
DermaPanel1:ShowCloseButton( true )
DermaPanel1:IsActive( true)
function DermaPanel1:Paint(w, h)
    draw.RoundedBox(4, 0, 0, DermaPanel1:GetWide(), DermaPanel1:GetTall(), Color(0,0,255,200))
end
 
Label = vgui.Create( "DLabel", DermaPanel1 )
Label:SetText( "DarkRP Spam:" )
Label:SizeToContents()
Label:SetPos( 15, 20 )
 
Label = vgui.Create( "DLabel", DermaPanel1 )
Label:SetText( "Normal Spam:" )
Label:SizeToContents()
Label:SetPos( 150, 20 )
 
Label = vgui.Create( "DLabel", DermaPanel1 )
Label:SetText( "Extras:" )
Label:SizeToContents()
Label:SetPos( 300, 20 )
 
local DermaCheckboxs213 = vgui.Create( "DCheckBoxLabel" )
DermaCheckboxs213:SetParent( DermaPanel1 )
DermaCheckboxs213:SetPos( 150, 35 )
DermaCheckboxs213:SetText( "Clen at me brah" )
DermaCheckboxs213:SetConVar( "onionbot_normalspam1" )
DermaCheckboxs213:SetValue( 0 )
DermaCheckboxs213:SizeToContents()
 
local DermaCheckboxs222 = vgui.Create( "DCheckBoxLabel" )
DermaCheckboxs222:SetParent( DermaPanel1 )
DermaCheckboxs222:SetPos( 150, 55 )
DermaCheckboxs222:SetText( "Learn to configure" )
DermaCheckboxs222:SetConVar( "onionbot_normalspam2" )
DermaCheckboxs222:SetValue( 0 )
DermaCheckboxs222:SizeToContents()
 
local DermaCheckboxs242 = vgui.Create( "DCheckBoxLabel" )
DermaCheckboxs242:SetParent( DermaPanel1 )
DermaCheckboxs242:SetPos( 150, 75 )
DermaCheckboxs242:SetText( "Not even h3x" )
DermaCheckboxs242:SetConVar( "onionbot_normalspam3" )
DermaCheckboxs242:SetValue( 0 )
DermaCheckboxs242:SizeToContents()
 
local DermaCheckboxss242 = vgui.Create( "DCheckBoxLabel" )
DermaCheckboxss242:SetParent( DermaPanel1 )
DermaCheckboxss242:SetPos( 150, 95 )
DermaCheckboxss242:SetText( "Biggest Dick" )
DermaCheckboxss242:SetConVar( "onionbot_normalspam4" )
DermaCheckboxss242:SetValue( 0 )
DermaCheckboxss242:SizeToContents()
 
local DermaCheckbox213 = vgui.Create( "DCheckBoxLabel" )
DermaCheckbox213:SetParent( DermaPanel1 )
DermaCheckbox213:SetPos( 15, 35 )
DermaCheckbox213:SetText( "Clen at me brah" )
DermaCheckbox213:SetConVar( "onionbot_spam1" )
DermaCheckbox213:SetValue( 0 )
DermaCheckbox213:SizeToContents()
 
local DermaCheckbox222 = vgui.Create( "DCheckBoxLabel" )
DermaCheckbox222:SetParent( DermaPanel1 )
DermaCheckbox222:SetPos( 15, 55 )
DermaCheckbox222:SetText( "Learn to configure" )
DermaCheckbox222:SetConVar( "onionbot_spam2" )
DermaCheckbox222:SetValue( 0 )
DermaCheckbox222:SizeToContents()
 
local DermaCheckbox242 = vgui.Create( "DCheckBoxLabel" )
DermaCheckbox242:SetParent( DermaPanel1 )
DermaCheckbox242:SetPos( 15, 75 )
DermaCheckbox242:SetText( "Not even h3x" )
DermaCheckbox242:SetConVar( "onionbot_spam3" )
DermaCheckbox242:SetValue( 0 )
DermaCheckbox242:SizeToContents()
 
local DermaCheckbox242 = vgui.Create( "DCheckBoxLabel" )
DermaCheckbox242:SetParent( DermaPanel1 )
DermaCheckbox242:SetPos( 15, 95 )
DermaCheckbox242:SetText( "Biggest Dick" )
DermaCheckbox242:SetConVar( "onionbot_spam4" )
DermaCheckbox242:SetValue( 0 )
DermaCheckbox242:SizeToContents()
 
local DermaCheckbox = vgui.Create( "DCheckBoxLabel" )
DermaCheckbox:SetParent( DermaPanel1 )
DermaCheckbox:SetPos( 300, 35 )
DermaCheckbox:SetText( "TriggerBot" )
DermaCheckbox:SetConVar( "onionbot_triggerbot" )
DermaCheckbox:SetValue( 0 )
DermaCheckbox:SizeToContents()
 
local DermaCheckbox = vgui.Create( "DCheckBoxLabel" )
DermaCheckbox:SetParent( DermaPanel1 )
DermaCheckbox:SetPos( 300, 55 )
DermaCheckbox:SetText( "BuyhealthSpam" )
DermaCheckbox:SetConVar( "onionbot_hp" )
DermaCheckbox:SetValue( 0 )
DermaCheckbox:SizeToContents()
 
 
local DermaCheckbox = vgui.Create( "DCheckBoxLabel" )
DermaCheckbox:SetParent( DermaPanel1 )
DermaCheckbox:SetPos( 300, 75 )
DermaCheckbox:SetText( "DarkRP NameChangeSpam" )
DermaCheckbox:SetConVar( "onionbot_namechanger" )
DermaCheckbox:SetValue( 0 )
DermaCheckbox:SizeToContents()
 
 
local DermaPanel = vgui.Create( "DFrame" )
DermaPanel:SetPos( 4, 4 )
DermaPanel:SetSize( 250, 500 )
DermaPanel:SetTitle( "OnionBot v5.0" )
DermaPanel:SetDraggable( true )
DermaPanel:SetVisible( true )
DermaPanel:ShowCloseButton( true )
DermaPanel:IsActive( true)
 
function DermaPanel:Paint(w, h)
    draw.RoundedBox(4, 0, 0, DermaPanel:GetWide(), DermaPanel:GetTall(), Color(0,0,255,200))
end
 
 
local Form = vgui.Create( "DButton" )
Form:SetParent( DermaPanel )
Form:SetText( "Entity Finder" )
Form:SetPos( 125, 35)
Form:SetSize( 100, 30 )
Form.DoClick = function()
    RunConsoleCommand( "onionbot_entmenu" )
end
 
local DermaCheckbox = vgui.Create( "DCheckBoxLabel" )
DermaCheckbox:SetParent( DermaPanel )
DermaCheckbox:SetPos( 15, 35 )
DermaCheckbox:SetText( "ESP On/Off" )
DermaCheckbox:SetConVar( "onionbot_esp" )
DermaCheckbox:SetValue( 0 )
DermaCheckbox:SizeToContents()
 
local DermaCheckbox3 = vgui.Create( "DCheckBoxLabel" )
DermaCheckbox3:SetParent( DermaPanel )
DermaCheckbox3:SetPos( 15, 55 )
DermaCheckbox3:SetText( "Health/Wep ESP" )
DermaCheckbox3:SetConVar( "onionbot_healthandwep" )
DermaCheckbox3:SetValue( 0 )
DermaCheckbox3:SizeToContents()
 
local Form = vgui.Create( "DButton" )
Form:SetParent( DermaPanel )
Form:SetText( "Ent Finder On/Off" )
Form:SetPos( 125, 75)
Form:SetSize( 100, 30 )
Form.DoClick = function()
    RunConsoleCommand( "onionbot_entfinder" )
end
 
local Form = vgui.Create( "DButton" )
Form:SetParent( DermaPanel )
Form:SetText( "AutoBhop" )
Form:SetPos( 15, 75)
Form:SetSize( 100, 30 )
Form.DoClick = function()
    RunConsoleCommand( "onion_bhop" )
end
 
 
local DermaListView = vgui.Create("DListView")
DermaListView:SetParent(DermaPanel)
DermaListView:SetPos(15, 110)
DermaListView:SetSize(200, 200)
DermaListView:SetMultiSelect(false)
DermaListView:AddColumn("Admins")
 
for k,v in pairs(player.GetAll()) do
if v:IsAdmin() then
DermaListView:AddLine(v:Nick())
end
end
 
local DermaListView1 = vgui.Create("DListView")
DermaListView1:SetParent(DermaPanel)
DermaListView1:SetPos(15, 325)
DermaListView1:SetSize(200, 100)
DermaListView1:SetMultiSelect(false)
DermaListView1:AddColumn("SuperAdmins")
 
for k,v in pairs(player.GetAll()) do
if v:IsSuperAdmin() then
DermaListView1:AddLine(v:Nick())
end
end
 
 
Label = vgui.Create( "DLabel", DermaPanel )
Label:SetText( "OnionBot v5.0 by ONIONZZZ" )
Label:SizeToContents()
Label:SetPos( 4, 485 )
end
concommand.Add("onion_menu",onion_menu)