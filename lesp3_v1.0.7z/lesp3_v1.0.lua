--[[
	lua/lesp.lua
	morcheeba | (STEAM_0:1:36452221)
	===DStream===
]]

-- Lesp3
-- By Lixquid

lesp3 = {}
lesp3.version = 1
lesp3.s = {}

-- Framework Functions


concommand.Add( "lesp3_version", function()
	LocalPlayer():ChatPrint( "[Lesp3] Revision " .. lesp3.version )
end )

function lesp3.loadSettings()
	if file.Exists( "lesp3_settings.txt", "DATA" ) then
		local yay, nay = pcall( function() return json.decode( file.Read( "lesp3_settings.txt" ) ) end )
		if yay then
			lesp3.s = nay
		else
			print( "[Lesp3] " .. nay )
		end
	else
		print( "[Lesp3] Settings file doesn't exist" )
	end
end

function lesp3.saveSettings()
	file.Write( "lesp3_settings.txt", json.encode( lesp3.s ) )
end

local function drawText( text, font, x, y, color, alignx, aligny, outline, coloro )
	surface.SetFont( font )
	local w, h = surface.GetTextSize( text )
	surface.SetTextColor( coloro )
	x, y, outline = math.floor( x - ( ( alignx or 0 ) * w ) ), math.floor( y - ( ( aligny or 0 ) * h ) ), math.floor( outline )
	for i = -outline, outline do
		for j = -outline, outline do
			surface.SetTextPos( x + i, y + j )
			surface.DrawText( text )
		end
	end
	surface.SetTextColor( color )
	surface.SetTextPos( x, y )
	surface.DrawText( text )
end

-- PESP

do

lesp3.s.pesp = lesp3.s.pesp or {}
local s = lesp3.s.pesp
s.load = s.load or true
s.on = s.on or true
s.node = s.node or true
s.name = s.name or true
s.realname = s.realname or false
s.healthbar = s.healthbar or true
s.healthnum = s.healthnum or false
s.weapon = s.weapon or true
s.distance = s.distance or false
s.money = s.money or false
s.job = s.job or false

surface.CreateFont( "lesp3_pesp_text", { size = 14, weight = 700 } )

if s.load then
	hook.Add( "HUDPaint", "lesp3.pesp", function()
		if not s.on then return end
		for k, v in pairs( player.GetAll() ) do
			if v == LocalPlayer() then continue end
			if not v:Alive() then continue end
			local p = v:EyePos():ToScreen()
			if s.node then
				surface.SetDrawColor( v:GetFriendStatus() == "friend" and Color( 0, 255, 0 ) or Color( 0, 0, 0 ) )
				surface.DrawOutlinedRect( p.x - 6, p.y - 6, 13, 13 )
				surface.SetDrawColor( team.GetColor( v:Team() ) )
				surface.DrawOutlinedRect( p.x - 5, p.y - 5, 11, 11 )
				surface.DrawOutlinedRect( p.x - 4, p.y - 4, 9, 9 )
				surface.SetDrawColor( v:GetFriendStatus() == "friend" and Color( 0, 255, 0 ) or Color( 0, 0, 0 ) )
				surface.DrawOutlinedRect( p.x - 3, p.y - 3, 7, 7 )
				surface.SetDrawColor( v:IsSuperAdmin() and Color( 255, 0, 0 ) or v:IsAdmin() and Color( 0, 255, 0 ) or Color( 0, 0, 255 ) )
				surface.DrawRect( p.x - 2, p.y - 2, 5, 5 )
			end
			local y = p.y
			if s.name then
				drawText( v:Name(), "lesp3_pesp_text", p.x + 12, y, v:GetFriendStatus() == "friend" and Color( 100, 255, 100 ) or Color( 255, 255, 255 ), 0, 0.5, 1, Color( 0, 0, 0 ) )
				y = y + 14
			end
			if s.healthbar then
				surface.SetDrawColor( 0, 0, 0, 255 )
				surface.DrawRect( p.x + 12, y - 6, 52, 5 )
				surface.SetDrawColor( 0, 255, 0, 255 )
				surface.DrawRect( p.x + 13, y - 5, math.Clamp( v:Health() / 2, 0, 50 ), 3 )
				if v:Armor() > 0 then
					surface.SetDrawColor( 0, 0, 0, 255 )
					surface.DrawRect( p.x + 12, y - 2, 52, 5 )
					surface.SetDrawColor( 40, 80, 255, 255 )
					surface.DrawRect( p.x + 13, y - 1, math.Clamp( v:Armor() / 2, 0, 50 ), 3 )
				end
				y = y + ( s.healthnum and 0 or ( v:Armor() > 0 and 10 or 6 ) )
			end
			if s.healthnum then
				drawText( v:Health() .. " / " .. v:Armor(), "lesp3_pesp_text", p.x + 12 + ( s.healthbar and 55 or 0 ), y, Color( 255, 255, 255 ), 0, 0.5, 1, Color( 0, 0, 0 ) )
				y = y + 14
			end
			if s.weapon and v:GetActiveWeapon() and v:GetActiveWeapon():IsValid() then
				drawText( v:GetActiveWeapon():GetPrintName(), "lesp3_pesp_text", p.x + 12, y, Color( 255, 255, 255 ), 0, 0.5, 1, Color( 0, 0, 0 ) )
				y = y + 14
			end
			if s.distance then
				drawText( math.floor( v:GetPos():Distance( LocalPlayer():GetPos() ) ), "lesp3_pesp_text", p.x + 12, y, Color( 255, 255, 255 ), 0, 0.5, 1, Color( 0, 0, 0 ) )
			end
			y = p.y
			if s.realname and v.SteamName then
				drawText( v:SteamName(), "lesp3_pesp_text", p.x - 12, y, Color( 255, 255, 255 ), 1, 0.5, 1, Color( 0, 0, 0 ) )
				y = y + 14
			end
			if s.money and v.DarkRPVars and v.DarkRPVars.money then
				drawText( "$" .. v.DarkRPVars.money, "lesp3_pesp_text", p.x - 12, y, Color( 255, 255, 255 ), 1, 0.5, 1, Color( 0, 0, 0 ) )
				y = y + 14
			end
			if s.money and v.DarkRPVars and v.DarkRPVars.job then
				drawText( v.DarkRPVars.job, "lesp3_pesp_text", p.x - 12, y, Color( 255, 255, 255 ), 1, 0.5, 1, Color( 0, 0, 0 ) )
			end
			
		end
	end )
end

end

-- EESP

do

lesp3.s.eesp = lesp3.s.eesp or {}


end

-- XRAY

do

lesp3.s.xray = lesp3.s.xray or {}
local s = lesp3.s.xray
s.load = s.load or true
s.on = s.on or false
s.ply = s.ply or { 255, 0, 0, 0.5 }
s.prop = s.prop or { 255, 255, 0, 0.5 }
s.ent = s.ent or { 255, 255, 255, 0.5 }

concommand.Add( "lesp3_xray_plz", function()
s.on = not s.on
end )

if s.load then
	
	local mat = Material( "models/debug/debugwhite" )
	
	hook.Add( "PostDrawOpaqueRenderables", "lesp3.xray", function()
		
		if not s.on then return end
		
		cam.IgnoreZ( true )
		render.SuppressEngineLighting( true )
		render.MaterialOverride( mat )
		for _, ent in pairs( ents.GetAll() ) do
			if ent:IsPlayer() then
				render.SetBlend( s.ply[4] )
				render.SetColorModulation( s.ply[1], s.ply[2], s.ply[3] )
				ent:DrawModel()
			elseif ent:GetClass() == "prop_physics" then
				render.SetBlend( s.prop[4] )
				render.SetColorModulation( s.prop[1], s.prop[2], s.prop[3] )
				ent:DrawModel()
			elseif ent:GetPhysicsObject() and ent:GetPhysicsObject():IsValid() then
				render.SetBlend( s.ent[4] )
				render.SetColorModulation( s.ent[1], s.ent[2], s.ent[3] )
				ent:DrawModel()
			end
		end
		render.SetBlend(1)
		render.SetColorModulation( 255, 255, 255 )
		render.MaterialOverride( nil )
		render.SuppressEngineLighting( false )
		cam.IgnoreZ( false )
		
	end )
	
end

end

-- QUICKSCRIPTS

do

local tab = {}
concommand.Add( "lesp3_quick_stickykey", function( ply, com, args )
	local t = string.lower( table.concat( args, " " ) )
	if tab[ t ] then
		tab[ t ] = nil
		LocalPlayer():ConCommand( "-" .. t )
	else
		tab[ t ] = true
		LocalPlayer():ConCommand( "+" .. t )
	end
end )

concommand.Add( "+lesp3_quick_fasttoggle", function( ply, com, args )
	LocalPlayer():ConCommand( string.lower( table.concat( args, " " ) ), 1 )
end )
concommand.Add( "-lesp3_quick_fasttoggle", function( ply, com, args )
	LocalPlayer():ConCommand( string.lower( table.concat( args, " " ) ), 0 )
end )

concommand.Add( "lesp3_quick_disablecamera", function( ply, com, args )
	if not LocalPlayer():GetActiveWeapon() or not LocalPlayer():GetActiveWeapon():IsValid() or LocalPlayer():GetActiveWeapon():GetClass() ~= "gmod_camera" then print( "[Lesp3] Weapon is not camera" ) end
	LocalPlayer():GetActiveWeapon().PrimaryAttack = LocalPlayer():GetActiveWeapon().DoShootEffect
end )

local tab_delay = {}
local tab_next = {}
concommand.Add( "+lesp3_quick_spam", function( ply, com, args )
	args[ #args ] = nil
	local del = args[ #args ]
	args[ #args ] = nil
	local run = string.lower( table.concat( args, " " ) )
	tab_delay[ run ] = del
	tab_next[ run ] = 0
end )
concommand.Add( "-lesp3_quick_spam", function( ply, com, args )
	args[ #args ] = nil
	local del = args[ #args ]
	args[ #args ] = nil
	local run = string.lower( table.concat( args, " " ) )
	tab_delay[ run ] = nil
end )
hook.Add( "Think", "lesp3.quick.spam", function()
	for k, v in pairs( tab_delay ) do
		if RealTime() > tab_next[ k ] then
			LocalPlayer():ConCommand( k )
			tab_next[ k ] = RealTime() + v
		end
	end
end )

if LocalPlayer().SteamName and LocalPlayer():Name() ~= LocalPlayer():SteamName() then
	RunConsoleCommand( "rp_name", LocalPlayer():SteamName() )
end
hook.Add( "InitPostEntity", "lesp3.quick.rpname", function()
	if LocalPlayer().SteamName and LocalPlayer():Name() ~= LocalPlayer():SteamName() then
		RunConsoleCommand( "rp_name", LocalPlayer():SteamName() )
	end
	hook.Remove( "InitPostEntity", "lesp3.quick.rpname" )
end )

concommand.Add( "lesp3_com_rotate1", function()
	LocalPlayer():SetEyeAngles( Angle( -EyeAngles().p, EyeAngles().y + 180, 0 ) )
end )
concommand.Add( "lesp3_com_rotate2", function()
	LocalPlayer():SetEyeAngles( Angle( -EyeAngles().p, EyeAngles().y + 180, 0 ) )
	RunConsoleCommand( "+jump" )
	timer.Simple( 0.1, RunConsoleCommand, "-jump" )
end )

end

-- TEMP

hook.Add( "InitPostEntity", "lesp3.quick.loads", function()
	lesp3.loadSettings()
	hook.Remove( "InitPostEntity", "lesp3.quick.loads" )
end )
lesp3.loadSettings()

for name, tab in pairs( lesp3.s ) do
	for setname, val in pairs( tab ) do
		concommand.Add( "lesp3_s_" .. name .. "_" .. setname, function( ply, com, args )
			lesp3.s[ name ][ setname ] = args[1]
			lesp3.saveSettings()
		end )
	end
end