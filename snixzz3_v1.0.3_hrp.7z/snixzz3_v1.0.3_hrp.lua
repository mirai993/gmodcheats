/*
	
	RELEASE NOTES:
	The administration of the server I made this client for is terrible, the gamemode is extremely outdated, and there's absolutely no hope left for the server.
	Feel free to do whatever with this script, I made it purely out of boredom to see what I could do with the gamemode and what exploits I could find.
	Most major exploits were reported to the server's administration which they usually neglected to fix or just removed the features entirely.
	Enjoy this shit.
	Open the menu with the command "gui"

	HarborRP client written by 0xymoron
	Made for the Harbor-Roleplay.net server running the old CatalystRP HarborRP gamemode.
	Project started 11/12/17 @ approximately 1:00 AM
	
	Update 11/12/17, 4:39AM:
	I have taken this way too far, go back.
	
	Update: 11/16/17: 3:59AM:
	This is ridiculous. I have no idea why I added half of these features, I will never use them. R.I.P 
	
	Information/Reference:
	
		Items.GetAll() - get all items on map
	
	NetVars: 
	
		OxygenLevel - Scooba oxygen level
		HasScubaGear - uhhhh
		Noclip - Player in noclip		
		
*/

local meta = table.Copy( FindMetaTable( "Player" ) )
local _R = table.Copy( debug.getregistry() )

local client = {}

client.DevMode = true

client.AntiGrab = false

client.Version = "1.03"
client.DataFile = "hrp_settings.txt"

client.Vars = { // all commented out are patched/removed

	["anti afk"] = false,
	["scooba"] = false,
	["gps"] = false,
	["hud"] = false,
	["fish info"] = false,
	["bunnyhop"] = true,
	["scavenger"] = false,
	["green harbor"] = false,
	["flashlight"] = false,
	["nodraw"] = false,
	["boat finder"] = false,
	["farmer"] = false,
	//["halloween"] = false,
	//["physgun"] = false,
	
	//["spawn yacht"] = "spawnyacht",
	//["secret yacht"] = "spawnit",
	["force afk"] = "forceafk",
	//["wipe nlr"] = "wipenlr",
	//["end lockdown"] = "endlockdown",
	//["zombie event"] = "startzombie",
	//["end zombies"] = "stopzombie",
	["sell artifacts"] = "sellartifacts",
	["buy scuba gear"] = "buyscuba",
	
}

client.Functions = {

	["spawnyacht"] = function()
	
		RunConsoleCommand( "wake" )
		
	end,

	["spawnit"] = function()
	
		RunConsoleCommand( "spawnit" )
		
	end,	
	
	["forceafk"] = function()
	
		RunConsoleCommand( "4f3dg1df351acdvfvgs7c5x" )
		
	end,
	
	["wipenlr"] = function()
	
		RunConsoleCommand( "nlr_wipe")
		
	end,
	
	["endlockdown"] = function()
	
		RunConsoleCommand( "rp_unhurrdurr9001337" )
	
	end,
	
	["startzombie"] = function()
	
		RunConsoleCommand( "say", "/startzombie" )
	
	end,
	
	["stopzombie"] = function()
	
		RunConsoleCommand( "say", "/stopzombie" )
	
	end,	
	
	["sellartifacts"] = function()
	
		local ent = LocalPlayer():GetEyeTrace().Entity
		
		if ent:GetClass() == "artifact_box" then
		
			net.Start( "HRP:SellArtifacts" )
			
				net.WriteEntity( ent )
				
			net.SendToServer()
			
		else
			
			client.Msg( "Not looking at artifact box." )
		
		end
	
	end,
	
	["buyscuba"] = function()
	
		net.Start( "HRP:BuyScubaGear" )
		
		net.SendToServer()
	
	end,
	
}

client.Block = {

	["Capture.SendToServer"] = true,
	["Capture.SendToAdmin"] = true,
	["Capture.ReceiveData"] = true,
	["Cap_SendToClient"] = true,
	["Cap_Request"] = true,
	["Cap_SendFromClient"] = true,
	
	["ReSendVariables"] = true,

}

client.Locations = {

	["Red Harbor"] = { 
		Pos = Vector( -10005, 14694, 50 ),
		Col = Color( 255, 0, 0, 200 ),
		
	},
	
	["Blue Harbor"] = {
	
		Pos = Vector( 15239, -12300, 62 ),
		Col = Color( 0, 100, 255, 200 ),
	
	},
	
	["Islands"] = {
	
		Pos = Vector( -8225, -8211, 304 ),
		Col = Color( 255, 255, 0 ),
		
	},
	
	["Oil Rig"] = {
	
		Pos = Vector( 9359, 9303, 152 ),
		Col = Color( 255, 100, 0 ),
	
	},
	
	["Green Harbor"] = {
	
		Pos = Vector( 3300, -2167, -2518 ),
		Col = Color( 0, 200, 0 ),
		Close = true,
	
	}

}

local artifacts = {

	["Materials"] = {

		["models/props_foliage/tree_deciduous_01a_trunk"] = 1,
		["models/props_pipes/pipesystem01a_skin3"] = 2,
		["phoenix_storms/plastic"] = 3,
		["models/effects/splodearc_sheet"] = 4

	},

	["Colors"] = {

		[1] = Color( 255, 0, 0 ),
		[2] = Color( 255, 0, 255 ),
		[3] = Color( 0, 255, 0 ),
		[4] = Color( 0, 255, 255 ),

	},
	
	["Names"] = {

		[1] = "Common",
		[2] = "Uncommon",
		[3] = "Rare",
		[4] = "Legendary"
	}

}

local fish = {

	["Models"] = {
	
		["models/props/prop_damselfish.mdl"] = "Damselfish",
		["models/props/de_inferno/goldfish.mdl"] = "Goldfish",
		["models/foodnhouseholditems/fishrainbow.mdl"] = "Rainbow",
		["models/props/cs_militia/fishriver01.mdl"] = "Snapper",
		["models/foodnhouseholditems/fishgolden.mdl"] = "Golden Fish",
		["models/foodnhouseholditems/fishcatfish.mdl"] = "Catfish",
		["models/foodnhouseholditems/fishbass.mdl"] = "Bass",

	},

}

client.NoDraw = {
	
	-- Palm trees in Green Harbor, cause some FPS issues & have missing textures from distance.
	["models/props/nature/rd_tallpalm01.mdl"] = true,
	["models/props/nature/rd_tallpalm02.mdl"] = true,
	["models/props/nature/rd_newpalm01.mdl"] = true,
	["models/props/nature/rd_newpalm02.mdl"] = true,
	["models/props/nature/rd_newpalm03.mdl"] = true,
	
	-- Street Lights
	["models/props_c17/lamppost03a_on.mdl"] = true,
	["models/props/cs_assault/streetlight.mdl"] = true,
	
	-- Foliage
	["models/props/de_inferno/tree_small.mdl"] = true,
	
	["models/props_wasteland/buoy01.mdl"] = true,
	
		
}

client.GreenKeys = {
	["Brightest"] = {	
		Pos = Vector( 2928, 14915, -1932 ),
		Col = Color( 255, 255, 255 )		
	},
	["Darkest"] = {
		Pos = Vector( 3010, 14811, -1932 ),
		Col = Color( 100, 100, 100 )
	},
	["In Between"] = {
		Pos = Vector( 2926, 14809, -1935 ),
		Col = Color( 175, 175, 175 )
	}
}

client.RenderColor = Color( 0, 255, 0 )

function client.LoadData()
	
	if client.DevMode then return end
	
	if !file.Exists( client.DataFile, "DATA" ) then
	
		client.SaveData()
		
		return
		
	end
	
	client.Vars = util.JSONToTable( file.Read( client.DataFile, "DATA" ) )

end

function client.SaveData()
	
	if client.DevMode then return end
	
	file.Write( client.DataFile, util.TableToJSON( client.Vars ) )

end

function client.Msg( str )

	chat.AddText( Color( 0, 255, 255 ), "[HRPC] ",
	color_white, str )

end

local sound
function client.Sound( Val )

	if Val == 1 then
	
		sound = Sound( "/HL1/fvox/buzz.wav" )
		
	elseif Val == 2 then
	
		sound = Sound( "/buttons/blip1.wav" )
		
	elseif Val == 3 then
		
		sound = Sound( "/ambient/levels/canals/drip4.wav" )
		
	else
	
		sound = Sound( "/buttons/button17.wav" )
		
	end
	
	local createSound = CreateSound( LocalPlayer(), sound )
	createSound:Play()
	
end

function client.FuckAds() -- attempt
	
	if timer.Exists( "motdgdtimer" ) then
		
		timer.Adjust( "motdgdtimer", 0.1, 1, function() client.Msg( "Destroyed motdgd timer" ) end )
		
	end
	
	if _G.enableMotdGDClose then
		
		enableMotdGDClose()
		
		client.Msg( "Forced enableMotdGDClose()" )
		
	end
	
	if motdgdwindow && motdgdwindow:IsVisible() then
		
		motdgdwindow:Close()
		
		motdgdwindow = nil
		
		client.Msg( "Forcefully closed MOTDgd ad" )
		
	end

end

client.Detours = {}
function client.Detour( o, n )

	client.Detours[o] = n
	
	return n
	
end

function client.GetArtifactInfo( ent )

	local info = {}
	
	info["Type"] = artifacts["Materials"][ent:GetMaterial()]
	info["Color"] = artifacts["Colors"][info["Type"]]
	info["Name"] = artifacts["Names"][info["Type"]]

	return info

end

local tracePos
local depth
function client.GetDepth( ent )
	
	tracePos = ent:GetPos()
	
	local tracedata = {}
	tracedata.start = tracePos
	tracedata.endpos = tracePos - Vector( 0, 0, 1000 )
	tracedata.mask = MASK_OPAQUE
	
	local trace = util.TraceLine( tracedata )
	
	if !trace.Hit then	
	
		depth = 1337

	else
		
		depth = math.floor( math.Clamp( math.abs( trace.HitPos.z - tracePos.z ), 15, 1000 ) )
	
	end
	
	return depth
	
end

function client.GetFishType( dep )

	if dep < 224 then
		
		return "Goldfish"
		
	elseif dep > 224 && dep < 525 then
		
		return "Random [1]" 
		
	elseif dep > 525 && dep < 650 then
		
		return "Snapper"
		
	elseif dep > 650 && dep < 750 then
	
		return "Random [2]"
		
	elseif dep > 750 && dep < 795 then
		
		return "Golden Fish"
		
	elseif dep > 795 && dep < 830 then
		
		return "Random [3]"
		
	elseif dep > 830 && dep < 900 then
		
		return "Catfish"
		
	elseif dep > 900 && dep < 955 then
		
		return "Random [4]"
		
	elseif dep > 955 then
		
		return "Bass"
		
	end
	
	return "Unknown"

end

local info
local pos
local dist
local artifactTrace
function client.ESP_Artifact()
	
	if !client.Vars["scooba"] then return end
	
	//if !LocalPlayer():GetNetVar( "HasScubaGear", false ) then return end
	
	for k, v in next, ents.FindByClass( "artifact" ) do
	
		info = client.GetArtifactInfo( v )

		pos = v:GetPos():ToScreen()
		
		local artifactTrace = {
			x = ScrW() / 2,
			y = ScrH() / 2,
		}
		
		dist = math.Round( LocalPlayer():GetPos():Distance( v:GetPos() ) )
		
		if dist > 10000 then 

			continue
			
		end		
		
		surface.SetDrawColor( info["Color"] )
	
		surface.DrawRect( pos.x - 2, pos.y - 2, 2, 2 )
		
				
		if dist < 2000 then
			
			surface.DrawLine( artifactTrace.x, artifactTrace.y, pos.x, pos.y )
			
		end
		
	
		draw.SimpleTextOutlined( info["Name"], "Default", pos.x, pos.y + 5, info["Color"], 1, 1, 1, Color( 0, 0, 0 ) )
		
		draw.SimpleText( dist, "Default", pos.x, pos.y + 16, color_white, 1, 1 )
		
		
	
	end

end

local gpsPos
local gpsStart
function client.ESP_GPS()

	if !client.Vars["gps"] then return end

	for k, v in pairs( client.Locations ) do
		
		local gpsPos = v.Pos:ToScreen()
		
		local gpsStart = {
			x = ScrW() / 2,
			y = ScrH() / 2,
		}
		
		if !v.Close && LocalPlayer():GetPos():Distance( v.Pos ) < 7500 then 
			
			continue
			
		end
		
		if v.isNPC then
		
			draw.SimpleTextOutlined( k, "Trebuchet24", gpsPos.x, gpsPos.y + 5, v.Col, 1, 1, 1, Color( 0, 0, 0 )  )
		
		else	
			
			draw.SimpleTextOutlined( k, "CloseCaption_Bold", gpsPos.x, gpsPos.y + 5, v.Col, 1, 1, 1, Color( 0, 0, 0 )  )
			
		end
		
		
	end

end

local hud = {

	w = 175,
	h = 65,

}

local myDepth
function client.ESP_HUD()

	if !client.Vars["hud"] then return end

	if !LocalPlayer():Alive() then return end

	myDepth = client.GetDepth( LocalPlayer() )
	
	draw.RoundedBox( 0, ScrW() - hud["w"] - 10, 10, hud["w"], hud["h"], Color( 0, 0, 0, 150 ) )

	surface.SetDrawColor( Color( 0, 0, 0, 255 ) )
	
	surface.DrawOutlinedRect( ScrW() - hud["w"] - 10, 10, hud["w"], hud["h"] )
	
	draw.SimpleText( myDepth != 1337 && "Depth: " .. myDepth or "Depth: >1000", "Trebuchet24", ScrW() - hud["w"], 10, color_white, TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP )
	
	draw.SimpleText( "Fish: " .. client.GetFishType( myDepth ), "Trebuchet24", ScrW() - hud["w"], 30, color_white, TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP )
	
	if LocalPlayer():InVehicle() then
		
		draw.SimpleText( "MPH: " .. math.Round( LocalPlayer():GetVehicle():GetVelocity():Length() / 17.6 ), "Trebuchet24", ScrW() - hud["w"], 50, color_white, TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP )
		
	else
	
		draw.SimpleText( "MPH: " .. math.Round( LocalPlayer():GetVelocity():Length() / 17.6 ), "Trebuchet24", ScrW() - hud["w"], 50, color_white, TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP )	
	
	end
	
end

local boxPos
local boxStr
function client.ESP_Scavenge()

	if !client.Vars["scavenger"] then return end

	for k, v in next, ents.FindByClass( "scavengebox" ) do
	
		if v:GetPos():Distance( LocalPlayer():GetPos() ) > 7500 then continue end
	
		boxPos = v:GetPos():ToScreen()
		
		boxStr = v:GetModel() == "models/props_junk/wood_crate001a.mdl" && "Small Scavenge Box" or v:GetModel() == "models/props_junk/wood_crate002a.mdl" && "Large Scavenge Box"
		
		draw.SimpleText( boxStr .. " [" .. math.Round( LocalPlayer():GetPos():Distance( v:GetPos() ) ) .. "]", "Trebuchet18", boxPos.x, boxPos.y, Color( 145, 0, 0 ), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER )
		
	end
	
end

local netPos, fishPos, bouyPos
function client.FishInfo()

	if !client.Vars["fish info"] then return end

	for k, v in next, ents.FindByClass( "fishing_pot_medium" ) do
		
		if v:GetPos():Distance( LocalPlayer():GetPos() ) > 1500 then continue end
		
		netPos = v:GetPos():ToScreen()
		fishPos = v:GetPos():ToScreen().y + 16

		if v.Bait then
			
			draw.WordBox( 2, netPos.x, netPos.y, table.Count( v.FishToDisplay ) .. " Fish Caught", "Default", Color( 0, 0, 0, 150 ), table.Count( v.FishToDisplay ) > 0 && Color( 0, 186, 0 ) or Color( 186, 0, 0 ) )		
			
			for x, y in pairs( v.FishToDisplay ) do
			
				draw.WordBox( 2, netPos.x, fishPos, fish["Models"][y:GetModel()], "Default", Color( 0, 0, 0, 150 ), color_white )
				
				fishPos = fishPos + 16
			
			end
			
		else
		
			draw.WordBox( 2, netPos.x, netPos.y, "Needs Bait!", "Default", Color( 0, 0, 0, 150 ), Color( 220, 0, 0 ) )		
		
		end

	end
	
	for k, v in next, ents.FindByClass( "ent_buoy" ) do
	
		if v:GetPos():Distance( LocalPlayer():GetPos() ) > 1500 then continue end
		
		buoyPos = v:GetPos():ToScreen()
		
		draw.WordBox( 2, buoyPos.x, buoyPos.y, "Fish: " .. client.GetFishType( client.GetDepth( v ) ), "Default", Color( 0, 0, 0, 150 ), Color( 0, 186, 0 ) )		
	
	end

end

local triPos
local triCol
local keyPos
local activatePos = Vector( 9739, 9658, 1644 )

function client.GreenHarbor()

	if !client.Vars["green harbor"] then return end
	
	-- Locations of keys
	for k, v in next, ents.FindByClass( "func_physbox" ) do
		
		triPos = v:GetPos():ToScreen()
			
		triCol = v:GetColor()	
			
		draw.SimpleText( "Green Harbor Key", "Trebuchet18", triPos.x, triPos.y, Color( 0, 200, 0 ) )
	
	end
	
	-- Key destinations
	for k, v in next, client.GreenKeys do
	
		draw.SimpleText( k, "Trebuchet18", v.Pos:ToScreen().x, v.Pos:ToScreen().y, v.Col )
	
		surface.SetDrawColor( v.Col )
		
		surface.DrawRect( v.Pos:ToScreen().x - 2, v.Pos:ToScreen().y - 2, 3, 3 )
	
	end
	
	draw.SimpleText( "Final Activation", "Trebuchet24", activatePos:ToScreen().x, activatePos:ToScreen().y, Color( 255, 0, 0 ) )
	
	surface.SetDrawColor( Color( 255, 0, 0 ) )
		
	surface.DrawRect( activatePos:ToScreen().x - 2, activatePos:ToScreen().y - 2, 5, 5 )

end

function client.Boats()

	if !client.Vars["boat finder"] then return end

	for k, v in next, ents.FindByClass( "prop_vehicle_prisoner_pod" ) do
		
		if !IsValid( v ) then continue end
		if !DPP.IsOwned( v ) then continue end
		if DPP.IsOwned( v ) && DPP.GetOwnerDetails( v ) == LocalPlayer():Nick() then continue end
		
		cam.Start3D( EyePos(), EyeAngles() )

			render.SuppressEngineLighting( true )		
			render.SetColorModulation( client.RenderColor.r / 255, client.RenderColor.g / 255, client.RenderColor.b / 255 )			
			render.SetBlend( client.RenderColor.a / 255 )
						
			v:SetMaterial( "models/debug/debugwhite" )
			v:DrawModel() 
			v:SetColor( client.RenderColor )		
						
			render.SuppressEngineLighting( false )
				
			v:SetMaterial()
			v:SetColor( color_white )

		cam.End3D()		
		
		if v.DPP_ConstrainedWith != nil then
		
			for ent, _ in next, v.DPP_ConstrainedWith do
				
				if DPP.IsOwned( ent ) && DPP.GetOwnerDetails( ent ) == LocalPlayer():Nick() then continue end
				
				cam.Start3D( EyePos(), EyeAngles() )

					render.SuppressEngineLighting( true )		
					render.SetColorModulation( client.RenderColor.r / 255, client.RenderColor.g / 255, client.RenderColor.b / 255 )			
					render.SetBlend( client.RenderColor.a / 255 )
								
					ent:SetMaterial( "models/debug/debugwhite" )
					ent:DrawModel() 
					ent:SetColor( client.RenderColor )		
								
					render.SuppressEngineLighting( false )
						
					ent:SetMaterial()
					ent:SetColor( color_white )

				cam.End3D()					
			
			end
			
		end
	
	end	
	
end

local pumpkinPos
function client.Halloween()

	if !client.Vars["halloween"] then return end
	
	for k, v in next, ents.FindByClass( "prop_physics" ) do
	
		if v:GetModel() != "models/props_halloween/jackolantern_01.mdl" then continue end

		pumpkinPos = v:GetPos()
	
		draw.SimpleText( "JACK O' LANTERN", "Trebuchet24", pumpkinPos:ToScreen().x, pumpkinPos:ToScreen().y + 18, Color( 255, 93, 0 ), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER )
		draw.SimpleText( math.Round( v:GetPos():Distance( LocalPlayer():GetPos() ) ) .. "m", "Trebuchet24", pumpkinPos:ToScreen().x, pumpkinPos:ToScreen().y + 38, Color( 255, 93, 0 ), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER )
		
	
		surface.SetDrawColor( Color( 255, 93, 0 ) )
		
		surface.DrawRect( pumpkinPos:ToScreen().x - 2, pumpkinPos:ToScreen().y - 2, 5, 5 )
		
	end

end

function client.GayPhysgun()

	if !client.Vars["physgun"] then return end
	
	if LocalPlayer():Alive() && LocalPlayer():GetActiveWeapon():GetClass() == "weapon_physgun" then
	
		LocalPlayer():SetWeaponColor( Vector( 0.7 * math.abs( math.cos( CurTime() * 5 ) ), 0, 0.4 * math.abs( math.tan( CurTime() * 5 ) ) ) )

	end
		
end

local lite
function client.DynamicLight()

	if !client.Vars["flashlight"] then return end

	lite = DynamicLight( LocalPlayer():EntIndex() )
	
	if lite then
	
		lite.pos = LocalPlayer():GetPos()
		
		lite.r = 255
		lite.g = 255
		lite.b = 255
		
		lite.brightness = 2
		lite.Decay = 0
		lite.Size = 568
		lite.DieTime = CurTime() + 1
	
	end

end

local plantPos
local plantTypes = {

	[1] = "Orange",
	[2] = "Banana",
	[3] = "Watermelon",
	[4] = "Lemon"
	
}
function client.Farmer()

	if !client.Vars["farmer"] then return end
	
	for k, v in next, ents.FindByClass( "plant_pot" ) do
		
		if !IsValid( v ) then continue end
		
		if v:GetPos():Distance( LocalPlayer():GetPos() ) > 10000 then continue end
		
		plantPos = v:GetPos():ToScreen()
		
		draw.WordBox( 2, plantPos.x, plantPos.y, plantTypes[v:GetPlant()] .. " " ..  v:GetSize() * 100 .. "% (" .. v:GetWater() .. "% water)", "Default", Color( 0, 0, 0, 150 ), Color( 0, 186, 0 ) )					
	
	end

end

client.NoDrawBackup = {}

function client.SetNoDraw()

	if !client.Vars["nodraw"] then 
	
		if table.Count( client.NoDrawBackup ) >= 1 then
			
			for k, v in next, client.NoDrawBackup do
			
				k:SetNoDraw( false )
				
				client.NoDrawBackup[k] = nil
				
			end
			
		end
	
		return
		
	end
	
	for k, v in next, ents.FindByClass( "prop_dynamic" ) do
	
		if client.NoDraw[v:GetModel()] then
			
			client.NoDrawBackup[v] = true
			
			v:SetNoDraw( true )
			
		end
	
	end

end

client.AFKTicks = 0
function client.AntiAFK()

	if !client.Vars["anti afk"] then return end

	client.AFKTicks = client.AFKTicks + 1
	
	if client.AFKTicks == 4000 then
		
		RunConsoleCommand( "+forward" )
		
		timer.Simple( 0.05, function()
		
			RunConsoleCommand( "-forward" )
			
			RunConsoleCommand( "+back" )
			
			timer.Simple( 0.05, function()
			
				RunConsoleCommand( "-back" )
			
			end )
			
		end )
		
	elseif client.AFKTicks == 6000 then
	
		RunConsoleCommand( "+strafe" )
		RunConsoleCommand( "+left" )
		
		timer.Simple( 0.05, function()
		
			RunConsoleCommand( "-left" )

			RunConsoleCommand( "+right" )
			
			timer.Simple( 0.05, function()
			
				RunConsoleCommand( "-right" )
				RunConsoleCommand( "-strafe" )
			
			end )
			
		end )
		
	elseif client.AFKTicks == 8000 then
		
		RunConsoleCommand( "+back" )
		
		timer.Simple( 0.05, function()
		
			RunConsoleCommand( "-back" )
			
			RunConsoleCommand( "+forward" )
			
			timer.Simple( 0.05, function()
			
				RunConsoleCommand( "-forward" )
			
			end )
		
		end )
		
	elseif client.AFKTicks >= 10000 then
	
		RunConsoleCommand( "+strafe" )
		RunConsoleCommand( "+right" )
		
		timer.Simple( 0.05, function()
		
			RunConsoleCommand( "-right" )
			
			RunConsoleCommand( "+left" )
			
			timer.Simple( 0.05, function()
			
				RunConsoleCommand( "-left" )
				
				RunConsoleCommand( "-strafe" )
				
			end )
		
		end )
		
		client.AFKTicks = 0
	
	end

end

function client.CreateMove( cmd )

	if !client.Vars["bunnyhop"] then return end

	if LocalPlayer():GetMoveType() == MOVETYPE_NOCLIP or LocalPlayer():GetMoveType() == MOVETYPE_LADDER or LocalPlayer():WaterLevel() >= 1 then return end	
			
	if !LocalPlayer():OnGround() && cmd:KeyDown( IN_JUMP )then				
				
		cmd:SetButtons( bit.band( cmd:GetButtons(), bit.bnot( IN_JUMP ) ) )
		
	end
				
end

/* 

	Load
	
*/

client.LoadData()
client.FuckAds()

hook.Add( "HUDPaint", "HarborRP_HUD", function()
	
	if client.AntiGrab then return end
	
	client.ESP_Artifact()
	client.ESP_GPS()
	client.ESP_HUD()
	client.FishInfo()
	client.ESP_Scavenge()
	client.GreenHarbor()
	client.Boats()
	client.Halloween()
	client.GayPhysgun()
	client.Farmer()

end )

hook.Add( "Think", "HarborRP_THINK", function()

	if client.AntiGrab then return end

	client.DynamicLight()
	client.SetNoDraw()
	client.AntiAFK()

end )

hook.Add( "CreateMove", "HarborRP_MOVE", function( cmd )

	if client.AntiGrab then return end

	client.CreateMove( cmd )
	
end )

client.Detour( net.Start, function( name )

	if client.Block[name] then
		
		client.Msg( "Malicious net.Start blocked [" .. name .. "]" )
		
		return
		
	end
	
	return client.Detours[net.Start]( name )
	
end )

client.Detour( render.Capture, function( data )

	client.Sound( 1 )

	client.AntiGrab = true
	
	timer.Simple( 15, function()
	
		client.AntiGrab = false
	
		client.Sound( 3 )
	
	end )
	
	return client.Detours[render.Capture]( data )

end )

concommand.Add( "debug", function()
	
	local ent = LocalPlayer():GetEyeTrace().Entity
	
	MsgN( ent:GetClass() )
	
	MsgN()
	
	PrintTable( ent:GetTable() )

	MsgN( ent:GetModel() )
	
	MsgN( ent:GetMaterial() )
	
	MsgN( DPP.GetOwnerDetails( ent ) )
	
end )

/* 

	GUI
	
*/

local menuPos = { x = ScrW() - hud["w"] - 10, y = 80 }

concommand.Add( "gui", function()
		
	local buttonPos = 25

	client.Sound( 2 )
	
	client.Frame = vgui.Create( "DFrame" )
	client.Frame:SetTitle( "HarborRPClient v" .. client.Version )
	client.Frame:SetSize( 175, 37 * table.Count( client.Vars ) )
	client.Frame:SetPos( menuPos.x, menuPos.y )
	client.Frame:MakePopup()
	client.Frame:ShowCloseButton( false )
	client.Frame:SetDraggable( true )
	
	input.SetCursorPos( menuPos.x + client.Frame:GetWide() / 4, menuPos.y + client.Frame:GetTall() / 4 )
	
	client.Frame.Paint = function( self )
	
		draw.RoundedBox( 0, 0, 0, self:GetWide(), self:GetTall(), Color( 0, 0, 0, 175 ) )
	
		surface.SetDrawColor( Color( 0, 0, 0, 255 ) )
		
		surface.DrawOutlinedRect( 0, 0, self:GetWide(), self:GetTall() )
	
	end
	
	client.Frame.OnKeyCodePressed = function( self, key )
	
		if key == KEY_HOME then
		
			self:Remove()
		
		end
	
	end

	local close = vgui.Create( "DButton", client.Frame )
	close:SetSize( 50, 20 )
	close:SetPos( client.Frame:GetWide() - 51, 1 )
	close:SetText( "x" )
	close:SetTextColor( color_white )
	close:SetFont( "Trebuchet18" )
	
	close.Paint = function()
	
		draw.RoundedBox( 0, 0, 0, close:GetWide(), close:GetTall(), Color( 168, 62, 62, 255 ) )
	
	end
	
	close.DoClick = function()
		
		menuPos.x, menuPos.y = client.Frame:GetPos()
		
		client.Frame:Close()
		client.Sound()
		
	end
	
	for k, v in pairs( client.Vars ) do
	
		local button = vgui.Create( "DButton", client.Frame )
		button:SetSize( client.Frame:GetWide() - 10, 30 )
		button:SetPos( 5, buttonPos )
		button:SetText( string.upper( k ) )
		button:SetFont( "Trebuchet24" )
		
		if type( v ) == "string" then
		
			button:SetTextColor( Color( 115, 115, 115, 200 ) )
		
		else
			
			button:SetTextColor( v && Color( 200, 200, 200, 255 ) or Color( 115, 115, 115, 200 ) )
		
		end
		
		button.Paint = function( self )
			
			draw.RoundedBox( 0, 0, 0, self:GetWide(), self:GetTall(), Color( 0, 0, 0, 185 ) )

			surface.SetDrawColor( Color( 0, 0, 0, 255 ) )
		
			surface.DrawOutlinedRect( 0, 0, self:GetWide(), self:GetTall() )
	
			
		end
		
		button.DoClick = function()
			
			if type( v ) == "string" then
				
				client.Functions[v]()
			
				button:SetTextColor( Color( 200, 200, 200, 255 ) )
				
				client.Sound( 3 )
				
				timer.Simple( 0.05, function() if button != nil then button:SetTextColor( Color( 115, 115, 115, 255 ) ) end end )
			
			else
			
				client.Vars[k] = !client.Vars[k]

				button:SetTextColor( client.Vars[k] && Color( 200, 200, 200, 255 ) or Color( 115, 115, 115, 150 ) )
			
				client.Sound( 3 )
				
			end
			
			client.SaveData()
		
		end
		
		buttonPos = buttonPos + 35
	
	end

end )
