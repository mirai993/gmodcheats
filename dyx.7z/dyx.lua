-- Note by paradox: This file was initially labeled "dyx_d0d00d0d0d00d0cvf0c".

require"dyx"

if not dyx then
	dyx = _nyx
end

_nyx = nil

local SetViewAngles = dyx.SetViewAngles
local IsDormant = dyx.IsDormant

local hack = {}

local _R = {"Player","Entity","Vector","Angle","CUserCmd","Weapon"}

local FindMetaTable = FindMetaTable

for i=1,6 do
	for name,func in next, FindMetaTable(_R[i]) do
		_R[name] = func
	end
	_R[i] = nil
end

local me = LocalPlayer()
local interval = engine.TickInterval()

_R.ConCommand(me,"cl_updaterate "..(1/interval))
local interp = GetConVarNumber("cl_interp_ratio") / (1/interval)

_R.ConCommand(me,"cl_interp "..interp)
_R.ConCommand(me,"cl_cmdrate "..GetConVarNumber("sv_maxcmdrate"))

if not firebullets then
	firebullets = _R.FireBullets
end

FindMetaTable("CUserCmd").ClearMovement = function() end

FindMetaTable("CUserCmd").ClearButtons = function() end

FindMetaTable("CUserCmd").SetViewAngles = function() end

if not spreads then
	spreads = {}
end

local spreads = spreads

local call
local nxt = 1
local shot = CurTime()

FindMetaTable("Entity").FireBullets = function(ent,bullet)
	if not IsFirstTimePredicted() then return end
	if shot > CurTime() then return end
	if ent == me and call then
		nxt = nxt + 1
		call = false
	end
	firebullets(ent,bullet)
	shot = CurTime()
	local wepon = _R.GetActiveWeapon(me)
	if wepon == NULL then return end
	local class = _R.GetClass(wepon)
	if not spreads[class] then
		spreads[class] = -bullet.Spread
	end
end

local settings = {false,true,true,true,true,false,false}

local elements = {
"Aimbot",
"Silent aim",
"Autoshoot",
"Nospread",
"Ignore friends",
"Ignore team",
"Antiaim/Jitter",}

local GetAll = player.GetAll
local TraceLine = util.TraceLine

local view,set = _R.Angle(_R.GetAimVector(me))

local spot = 1
local menustate

local eyepos

local oldspz = 0

local function shootpos()
	local spos = _R.GetShootPos(me)
	local velocity = _R.GetVelocity(me) * 0.02355
	local accel = velocity.z - oldspz
	oldspz = velocity.z
	velocity.z = velocity.z + accel
	return spos + velocity
end

local function insight(ply,pos)
	local td = {}
	td.start = shootpos()
	td.endpos = pos
	td.filter = {ply,me}
	td.mask = 1174421507
	local tr = TraceLine(td)
	return tr.Fraction == 1
end

local oldz = {}

local function predict(ply,pos)
	local velocity = (_R.GetVelocity(ply) * interval) * 2
	return pos + (velocity * interp)
end

local function transform(a,x)
	local b = Vector(0,0,0)
	local m1,m2,m3 = x[1],x[2],x[3]
	local vec1 = Vector(m1[1],m1[2],m1[3])
	local vec2 = Vector(m2[1],m2[2],m2[3])
	local vec3 = Vector(m3[1],m3[2],m3[3])
	b.x = _R.Dot(a,vec1) + m1[4]
	b.y = _R.Dot(a,vec2) + m2[4]
	b.z = _R.Dot(a,vec3) + m3[4]
	return b
end

local function position(ply)
	local index = string.find(_R.GetModel(ply),"combine") and 1 or 0
	local pos = predict(ply,_R.LocalToWorld(ply,_R.OBBCenter(ply)))
	local bone = _R.GetHitBoxBone(ply,index,0)
	if not bone then return insight(ply,pos) and pos end
	if not _R.GetBonePosition(ply,bone) then return end
	local matrix = _R.GetBoneMatrix(ply,bone)
	if not matrix then return end
	local min,max = _R.GetHitBoxBounds(ply,index,0)
	matrix = matrix:ToTable()
	min = transform(min,matrix)
	max = transform(max,matrix)
	pos = predict(ply,(min + max) * 0.5)
	if not insight(ply,pos) then return end
	return pos
end

local function valid(ply)
	if not ply then return end
	if ply == me then return false end
	if _R.Health(ply) < 1 then return false end
	if IsDormant(_R.EntIndex(ply)) then return false end
	if settings[5] and _R.GetFriendStatus(ply) == "friend" then return false end
	if settings[6] and _R.Team(me) == _R.Team(ply) then return false end
	if _R.GetColor(ply).a < 255 then return false end
	if _R.InVehicle(ply) then return false end
	if not _R.GetMoveType(ply) == bit.bor(2,8) then return false end
	return true
end

local function targets()
	eyepos = nil
	local players = {}
	local aplayers = GetAll()
	local apos = {}
	for i=1,#aplayers do
		local ply = aplayers[i]
		if not valid(ply) then continue end
		local pos = position(ply)
		if not pos then continue end
		players[#players+1] = ply
		apos[ply] = pos
	end
	if nxt > #players then
		nxt = 1
	end
	local ply = players[nxt]
	eyepos = apos[ply]
end

local jit

function hack:CreateMove(c)
	//if true then return end
	if _R.CommandNumber(c) == 0 then
		if settings[2] then
			SetViewAngles(c,view)
		end
		set = true
		return
	end
	if set then
		view = _R.GetViewAngles(c)
		set = false
	end
	local ang = view
	if settings[1] then
		targets()
		if eyepos then
			ang = _R.Angle(eyepos - shootpos())
			ang.r = 0
			if settings[3] then
				_R.SetButtons(c,_R.GetButtons(c) + 1)
			end
		end
	end
	local wepon = _R.GetActiveWeapon(me)
	if wepon != NULL then 
		if settings[4] and (settings[2] or eyepos) then
			ang = _R.Angle(dyx.RemoveSpread(c,ang,spreads[_R.GetClass(me:GetActiveWeapon())] or Vector()))
		end
		if settings[7] then
			if jit then
				ang = Angle(-ang.p + 180,ang.y + 180,180)
				jit = false
			else
				jit = true
			end
		else
			ang.p = ang.p > 180 and ang.p - 360 or ang.p
			ang.y = ang.y < 0 and ang.y + 360 or ang.y
		end
		SetViewAngles(c,ang)
	end
	if settings[2] then
		local side = Vector(_R.GetForwardMove(c), _R.GetSideMove(c), 0)
		side = _R.Forward(_R.Angle(_R.GetNormal(side)) + (_R.GetViewAngles(c) - view)) * _R.Length(side)
		_R.SetForwardMove(c,side.x)
		_R.SetSideMove(c,side.y)
		dyx.Bunnyhop(c,_R.OnGround(me))
	end
	if menustate then
		spot = spot - _R.GetMouseWheel(c)
	end
	call = true
end

local w,h = ScrW()*0.5,ScrH()*0.5

local SimpleText = draw.SimpleText

function hack:HUDPaint()
	if not menustate then return end
	if spot > #elements then
		spot = 1
	elseif spot < 1 then
		spot = #elements
	end
	local len = #elements*15
	local pos = 0
	for i=1,#elements do
		SimpleText(spot == i and "- "..elements[i] or elements[i],"HudSelectionText",w,(h-len)-pos,Color(235,235,235))
		SimpleText(settings[i],"HudSelectionText",w*1.15,(h-len)-pos,settings[i] and Color(0,255,0) or Color(255,0,0))
		pos = pos - 15
	end
	SimpleText("-Menu-","HudSelectionText",w*1.05,(h-len)*0.95,Color(80,180,115))
end

local key
local left,right
local aim

function hack:Think()
	if input.IsKeyDown(52) then
		settings[1] = true
		aim = true
	elseif aim then
		settings[1] = false
		aim = false
	end
	if input.IsKeyDown(36) and not key then
		menustate = not menustate
		key = true
	end
	if not input.IsKeyDown(36) and key then key = false end
	if not menustate then return end
	if input.IsMouseDown(MOUSE_LEFT) and not left then
		settings[spot] = not settings[spot]
		left = true
	end
	if not input.IsMouseDown(MOUSE_LEFT) and left then left = false end
	if input.IsMouseDown(MOUSE_RIGHT) and not right then
		settings[spot] = not settings[spot]
		right = true
	end
	if not input.IsMouseDown(MOUSE_RIGHT) and right then right = false end
end

function hack:AdjustMouseSensitivity()
	return settings[2] and 2 or -1
end

function hack:PlayerBindPress(_,key)
	if menustate then
		if key == "+attack" then return true end
		if key == "+attack2" then return true end
	end
end

if not hooks then
	hooks = {}
end

for name,func in next, hack do
	if not hooks[name] then
		hooks[name] = GAMEMODE[name]
	end
	GAMEMODE[name] = function(gm,...)
		local var = func(nil,...)
		hooks[name](gm,...)
		if var then return var end
	end
end

MsgC(Color(80,180,115),"Hack loaded...\n")