--[[

 _   _         _                                          
| | | |       | |                                         
| | | |  __ _ | |  ___   _ __ __      __ __ _ __   __ ___ 
| | | | / _` || | / _ \ | '__|\ \ /\ / // _` |\ \ / // _ \
\ \_/ /| (_| || || (_) || |    \ V  V /| (_| | \ V /|  __/
 \___/  \__,_||_| \___/ |_|     \_/\_/  \__,_|  \_/  \___|
                                                          
                                                          
        Made by Astroux.

Testers:

Stormy Styx
Naxut
Astroux.
Zrehondier
Mannerduck
Egg
Data

Build Date: 12/15/2021
                                                                                                                                                                                                              
--]]















                                                                                                                      

local e, err = pcall(function() require("dickwrap") end);  	   
  	   
if (err) then
        print("[WAVE] dickwrap module failed to load")  	   
	dickwrap = {};  	   
	dickwrap.Predict = function(ucmd, ang)  	   
		return ang;  	   
	end  	   
end


timer.Create("wtf", 0.1, 0, function()
chatcounts = 0
tries = 999
end)

-- Antiscreengrab Hud Only
    local fakeRT = GetRenderTarget( "fakeRT" .. os.time(), ScrW(), ScrH() )
     
    hook.Add( "RenderScene", "AntiScreenGrab", function( vOrigin, vAngle, vFOV )
        local view = {
            x = 0,
            y = 0,
            w = ScrW(),
            h = ScrH(),
            dopostprocess = true,
            origin = vOrigin,
            angles = vAngle,
            fov = vFOV,
            drawhud = true,
            drawmonitors = true,
            drawviewmodel = true
        }
     
        render.RenderView( view )
        render.CopyTexture( nil, fakeRT )
     
        cam.Start2D()
            hook.Run( "CheatHUDPaint" )
        cam.End2D()
     
        render.SetRenderTarget( fakeRT )
     
        return true
    end )
     
    hook.Add( "ShutDown", "RemoveAntiScreenGrab", function()
        render.SetRenderTarget()
    end )

local vgui, surface, Color, input, hook, KEY_INSERT, pairs, string, timer, file, util = vgui, surface, Color, input, hook, KEY_INSERT, pairs, string, timer, file, util;  	   
local KEY_UP, KEY_DOWN, KEY_RIGHT, KEY_LEFT, KEY_HOME = KEY_UP, KEY_DOWN, KEY_RIGHT, KEY_LEFT, KEY_HOME;  	   
local player = player;  	   
local Vector = Vector;  	   
local Angle = Angle;  	   
local bit = bit;  	   
local FindMetaTable = FindMetaTable;  	   
local team = team;  	   
local me = LocalPlayer();  	   
local draw = draw;  	   
local SortedPairs = SortedPairs;  	   
local aimtarget;  	   
local pcall = pcall;  	   
local require = require;  	   
local debug = debug;  	   
local table = table;  	   
local gameevent = gameevent;  	   
local Entity = Entity;  	   
local ScrW, ScrH = ScrW, ScrH;  	   
local RunConsoleCommand = RunConsoleCommand;  	   
local GAMEMODE = GAMEMODE;  	   
local CurTime = CurTime;  	   
local cam = cam;  	   
local CreateMaterial = CreateMaterial;  	   
  	   
local em = FindMetaTable"Entity";  	   
local pm = FindMetaTable"Player";  	   
local cm = FindMetaTable"CUserCmd";  	   
local wm = FindMetaTable"Weapon";  	   
local am = FindMetaTable"Angle";  	   
local vm = FindMetaTable"Vector";  	   
  	   
local aiming;  	   
  	   
local chatspam = {  	   
	"So you got killed by me huh u mad ?? welp get my hack jk this is just a bind XXDDD",  	   
	"So you got killed by me huh u mad ?? welp get my hack jk this is just a bind XXDDD",  	   
	"So you got killed by me huh u mad ?? welp get my hack jk this is just a bind XXDDD",  	   
	"So you got killed by me huh u mad ?? welp get my hack jk this is just a bind XXDDD",  	   
	"So you got killed by me huh u mad ?? welp get my hack jk this is just a bind XXDDD",  	   
	"So you got killed by me huh u mad ?? welp get my hack jk this is just a bind XXDDD",  	   
	"valor wave sorta p90 not 100",  	   
	"love you :)))))))",  	   
}  	   
  	   
local zrespam = {  	   
	"sk ddos is back bitches",
	"zrehax.dl",  	   
	"stop hacking",  	   
	"ZRE STOP HITTING KIDS!!!!",  	   
	"I picked on little kids dammit -Zrehondier",  	   
	"بعغباثهخنبانبغاضغخع عؤن ىثباقتباتباخنتبمضهاتبانبانثضت",  	   
	"bioshock approved hack",  	   
	"where did the velocity chams go?",  	   
	"im your average medic/engineer main",  	     	      
}  	   
  	   
local naxutspam = {
        "swag",
        "vodka",
        "FREE 5CM COCK TORTURE",
        "I LOVE FREE SAUSAGE NIGGER PENIS!!!",
        "PENIS!!!!!!!!!!!!!!!!",
        "i woant doubleP??????????!!!!!!!!!!!!!",
        "HOLHS OHIT DOUBL CUR????",
        "NIGAS ATE MY FUCKING COCK",
        "WENT 2 7UP GOT A COKE",
        "9:11 AM LETS GOOOOOOOOOOOOOOOOOOOOOO",
        "WFT THE NIGERS JOINED.....?????!???/",
        "SEVEN SEVEN SEVEN FOUR",
        "BREED UR MOM",
        "SUCKA SUCK DICK DICK FREE HARAM DOWNLOAD",
        "ATE MY DOG",
        "CHINESE MAN NUMBER ONE FREE FOREVER",
        "TAIWAN OUNTRY ISNT NOT",
        "0 SLEEP GAMIE WI 59PING",
        "START VOICE CHAT",
        "GOD BOY BUSSY BOX 5994$",
        "1968 I BLEW UP THE MOON",
        "fuck FUCK fuCK I ATE B",
        "CALL 1234 4 FREE MONEY",
        "MY MOM BEAT ME 4 EATING HER LEG",
        "BOOOOOOOOOSE SOS EIIIIIIIII",
        "HOOOH LOOLL SLLLLEEP",
        "njoyed a cold crisp cock",
        "FREE fridge MOMENT",
        "america is HOMOSEXUALITY!!1",
        "bibski",
        "i got scammed BY NIGER",
}   
  	   
local omsg;  	   
  	   
local menvars = {  	   
	["Cheat Name"] = "valorwave by astroux",  	   
}  	   
  	   
if (file.Exists("rmenu/"..menvars["Cheat Name"].."/mvars.txt", "DATA")) then  	   
	menvars = util.JSONToTable(file.Read("rmenu/"..menvars["Cheat Name"].."/mvars.txt"), "DATA");  	   
else  	   
	file.CreateDir("rmenu");  	   
	file.CreateDir("rmenu/"..menvars["Cheat Name"]);  	   
	file.Write("rmenu/"..menvars["Cheat Name"].."/mvars.txt", util.TableToJSON(menvars, true));  	   
end  	   
  	
local matweapon = Material("models/wireframe")
 
local vars = {  	   
	["ESP"] = {  	   
		{"2D Box", 1, 1, "Draws A Box Over The Player"},  	   
		{"Healthbar", 1, 1, "Displays Player Health Via A Bar"},  	      
		{"Skeleton", 0, 1, "Draws Players Skeleton"},  	   
		{"Name", 1, 1, "Displays Players Name"},  	   
		{"Health", 1, 1, "Displays Players Health/HP"},  	   
		{"Distance", 1, 1, "Displays Players Distance From You"},
                {"Weapon", 0, 1, "Displays Players Weapon"},		  	   
		{"Rank", 0, 1, "Displays Player Rank"},	   
	},  	   
	["Misc."] = {  	   
		{"Thirdperson", 0, 1, "Thirdperson"},  	   
		{"Thirdperson D.", 13, "Thirdperson Distance"},
                {"", ""},  	   
		{"Chatspam", 0, 1, "Spam The Chat"},
                {"Chatspam OOC", 0, 1, "Sends Chatspam To Admins (darkrp only)"},
                {"Chatspam Type", 0, 2, "0 = Normal | 1 = Zrehondier | 2 = Naxut"},
                {"", ""},   	   
                {"Damage Logger", 0, 1, "Logs Damage Done To Enemys"},
                {"Damage Log Mode", 0, 1, "0 = Chat | 1 = Notification "},
                {"HUD", 0, 1, "Draws A Custom HUD (heads up display)"},  
                {"Taunt Spam", 0, 1, "Taunt Automatically"},
                {"", ""},       	   
		{"Bunnyhop", 1, 1, "Automatically Jump (space)"},
                {"Bhop Mode", 0, 1, "0 = Normal | 1 = Anticheat "},
                {"Autostrafe", 1, 1, "Automatically Strafe"},
                {"", ""},    
                {"Hitsounds", 0, 1, "Sounds On Enemy Hit"},
                {"Hitsound Sound", 0, 6, "0 = Neverlose | 1 = qBeep | 2 = Button | 3 = Cod | 4 = Rust Headshot | 5 = Battlefield 1 | 6 = CSGO Headshot "},
                {"Killsounds", 0, 1, "Sounds On Enemy Kill"},
                {"Kill Sound", 5, 6, "0 = Neverlose | 1 = qBeep | 2 = Button | 3 = Cod | 4 = Rust Headshot | 5 = Battlefield 1 | 6 = CSGO Headshot "},
                {"Killsay", 0, 1, "Taunts Your Enemys"},	   
 	},  	   
	["Aimbot"] = {  	   
		{"Enabled", 0, 1, "Aimbot Master Toggle"},  	   
		{"Bullettime", 0, 1, "Bullettime Check"},  	   
		{"Aim on Mouse", 0, 1, "Activates Aimbot On Mouse Click"},
                {"Mouse Side", 0, 1, "0 = Left | 1 = Right"},  	   
                {"Target Method", 1, 3, "0 = Normal | 1 = Nextshot | 2 = Distance | 3 = Health"},  	  	   
		{"Autoshoot", 1, 1, "Aimbot Automatically Shoots"}, 	   
		{"Nospread", 1, 1, "Disables Bullet Spread (x86 only)"},  	   
		{"Target Team", 0, 1, "Targets Teammates"},
                {"Target Bots", 1, 1, "Target Bots"},
                {"Target Build", 0, 1, "Target Buildmode (libbys only)"},    	   
		{"Target Friends", 0, 1, "Target Steam Friends"},
                {"Target Noclip", 1, 1, "Target People Noclipping"},  	   
		{"Bodyaim", 0, 1, "Aimbot Aims For The Chest Instead Of The Head"},  	   
	},  	   
	["Triggerbot"] = {  	   
		{"Enabled", 0, 1, "Triggerbot Master Toggle"},  	   
		{"Target Friends", 0, 1, "Target Steam Friends"},  	   
		{"Target Team", 1, 1, "Target Teammates"},  	   
	},  	   
	["Visuals"] = {  	   
		{"Autism", 0, 1, "Rainbow Mode"},  	   
		{"Crosshair", 1, 1, "Draws A Custom Crosshair"},
		{"No Hands", 0, 1, "Disable Your Hands"}, 	   
		{"Skybox Changer", 0, 1, "Colors The Skybox"},
                {"",  ""},    	   
		{"Chams", 1, 1, "Player Chams Master Toggle"},
                {"Prop Chams", 0, 1, "Prop Chams Master Toggle"},
                {"Npc Chams", 0, 1, "Prop Chams Master Toggle"},
                {"IgnoreZ", 1, 1, "Allows Chams To Be Viewed Through Walls"},
                {"Cham Mat", 12, 12, "0 = Wireframe | 1 = Molten | 2 = Alien | 3 = Chrome | 4 = Water | 5 = Water V2 | 6 = Shiny | 7 = LSD | 8 = Gold | 9 = Mirror | 10 = Water V3 | 11 = Missing Texture | 12 = Flat"},	         
                {"Prop Mat", 0, 12, "0 = Wireframe | 1 = Molten | 2 = Alien | 3 = Chrome | 4 = Water | 5 = Water V2 | 6 = Shiny | 7 = LSD | 8 = Gold | 9 = Mirror | 10 = Water V3 | 11 = Missing Texture | 12 = Flat"},
                {"Npc Mat", 0, 12, "0 = Wireframe | 1 = Molten | 2 = Alien | 3 = Chrome | 4 = Water | 5 = Water V2 | 6 = Shiny | 7 = LSD | 8 = Gold | 9 = Mirror | 10 = Water V3 | 11 = Missing Texture | 12 = Flat"},	
                {"", ""},  
		{"FOV Changer", 0, 1, "Changes Your FOV"},  	   
		{"FOV", 110, 255, "FOV Changer Factor"},
                {"",   ""},  
                {"Hand Chams", 0, 1, "Colors Your Hands"},
                {"Hand Material", 0, 15, "0 = Wireframe | 1 = Plasma | 2 = Molten | 3 = Alien | 4 = Glow | 5 = Chrome | 6 = Water | 7 = Water V2 | 8 = Shiny | 9 = LSD | 10 = Gold | 11 = Glow V2 | 12 = Missing Texture | 13 = Mirror | 14 = Water V3 | 15 = Flat"},
                {"", ""},
		{"Sightlines", 0, 1, "Draws The Enemys View"},
                {"",   ""},
                {"Player Glow", 0, 1, "Adds A Glow Around Enemys"},
                {"Prop Glow", 0, 1, "Adds A Glow Around Props"},
                {"Npc Glow", 0, 1, "Adds A Glow Around Npcs"},   
                {"Glow Bloom", 1, 10, "Glow Factor"},	 	   		   
	},
        ["Colors"] = {  	      	   
		{"Hand R", 1, 5},  	   
		{"Hand G", 0, 5},  	   
		{"Hand B", 0, 5},
                {"Cham R", 0, 255},
		{"Cham G", 0, 255},  	   
		{"Cham B", 255, 255},
		{"Glow R", 255, 255},  	   
		{"Glow G", 255, 255},  	   
		{"Glow B", 255, 255},
		{"Prop R", 0, 1},  	   
		{"Prop G", 0, 1},  	   
		{"Prop B", 1, 1},
		{"Npc R", 0, 1},  	   
		{"Npc G", 0, 1},  	   
		{"Npc B", 1, 1},		      	   
		{"Sight R", 255, 255},  	   
		{"Sight G", 0, 255},  	   
		{"Sight B", 0, 255},
		{"Box R", 0, 255},  	   
		{"Box G", 100, 255},  	   
		{"Box B", 100, 255},
		{"HUD R", 0, 255},  	   
		{"HUD G", 10, 255},  	   
		{"HUD B", 255, 255},
		{"Cross R", 0, 255},  	   
		{"Cross G", 10, 255},  	   
		{"Cross B", 255, 255},
		{"Sky R", 0, 255},  	   
		{"Sky G", 0, 255},  	   
		{"Sky B", 255, 255},
                {"Sky Alpha", 255, 255},            	       	      	   	      	   
	},  	        
	["HvH"] = {  
		{"Spinbot", 0, 1, "Makes You Spin"},  	   
		{"Speed", 1, 23, "Spinbot Speed"},   	   
		{"", ""},  	   
		{"Antiaim", 0, 1, "Antiaim Master Switch"},  	   
		{"Method", 1, 7, "0 = Normal | 1 = Jitter | 2 = Sideways Follow | 3 = Fake Up | 4 = Fake Down | 5 = Anti-Idiotbox | 6 = Fake-Jitter [BETA] | 7 = Test Angle"},  	   
		{"Min X", -181, "Minimal Antiaim X"},  	   
		{"Min Y", 0, "Minimal Antiaim Y"},  	   
		{"Max X", -270, "Maximum Antiaim X"},  	   
		{"Max Y", 360, "Maximum Antiaim Y"},
                {"", ""},
                {"Crimwalk", 0, 1, "Crimwalk Master Switch"},
                {"Crim Speed", 15, 100, "Crimwalk Factor"},            	    	   		  	   
	},  	   
	["Menu"] = {  	   
		{"Autism", 0, 1, "Rainbow Mode"},	   
		{"Pos X", 5, "Menu Position X"},	   
		{"Pos Y", 105, "Menu Position Y"},  	   
		{"", ""},  	   
		{"Background R", 0, 255},  	   
		{"Background G", 0, 255},  	   
		{"Background B", 0, 255},  	   
		{"Background A", 245, 255},  	   
		{"", ""},  	   
		{"Bar R", 255, 255},  	   
		{"Bar G", 255, 255},  	   
		{"Bar B", 255, 255},  	   
		{"", ""},  	   
		{"Text R", 255, 255},  	   
		{"Text G", 255, 255},  	   
		{"Text B", 255, 255},  	   
		{"", ""},  	   
		{"Outline R", 0, 255},  	   
		{"Outline G", 0, 255},  	   
		{"Outline B", 0, 255},  	   
	},	   
};  	
	   
local function gBool(a, b)  	   
	if (!vars[a]) then return false; end  	   
	local bool;  	   
	for k,v in next, vars[a] do  	   
		if v[1] == b then bool = (v[2] > 0 && true); end  	   
	end  	   
	return(bool);  	   
end  	   
  	   
local function gInt(a, b)  	   
	if (!vars[a]) then return 0; end  	   
	local val;  	   
	for k, v in next, vars[a] do  	   
		if v[1] == b then val = v[2]; end  	   
	end  	   
	return(val || 0);  	   
end  	   	   

        
         hook.Add("CalcView", "l0l", function(ply, pos, angles, fov)
           if (gBool("Visuals", "FOV Changer")) then 
              	local view = {}
        	view.origin = pos
        	view.angles = angles
        	view.fov = gInt("Visuals", "FOV");
        	return view
             end
          end)

chat.AddText( Color( 125, 125, 255 ), "[wave] Injected!")
chat.AddText( Color( 125, 125, 255 ), "[wave] Remember Leaking Is Not Cool.")
chat.AddText( Color( 125, 125, 255 ), "[wave] Build Date: 12/16/2021 12:48 PM")
	   
local menuopen, selmade;  	   
local cursel = 1;  	   
  	   
local showtabs = {};  	   
  	   
local function UpdateVar(h, var)  	   
	if (!vars[h]) then return; end  	   
	for k,v in pairs(vars[h]) do  	   
		if v[1] == var[1] then  	   
			vars[h][k] = var;  	   
		end  	   
	end  	   
end  	   
  	   
local function loadconfig()  	   
	if (file.Exists("rmenu/"..menvars["Cheat Name"].."/vars.txt", "DATA")) then  	   
		local ttt = util.JSONToTable(file.Read("rmenu/"..menvars["Cheat Name"].."/vars.txt", "DATA"));  	   
		for k,v in pairs(ttt) do  	   
			for _,i in pairs(v) do  	   
				UpdateVar(k, i);  	   
			end  	   
		end  	   
	end  	   
end  	   
	 
 	   
local drawtext;  	   
local mh;  	   

local Laser = Material( "trails/laser" )


hook.Add("PostDrawOpaqueRenderables", "pbarrel", function()
if(gBool("Visuals", "Sightlines")) then
 for k,v in pairs(player.GetAll()) do
  if v == LocalPlayer() then continue end
	local startpos = v:EyePos()
	local endpos = v:EyePos() + v:EyeAngles():Forward() * 10000
   		local r2 = gInt("Colors", "Sight R");
		local g2 = gInt("Colors", "Sight G");
		local b2 = gInt("Colors", "Sight B");

	render.SetMaterial( Laser )
	render.DrawBeam(Vector( startpos.x,startpos.y ,startpos.z - 6 ), endpos, 5, 1, 1, Color( r2, g2, b2, 255 ) ) 
            
       end
    end
end)

local function dmglogchat(ply, hitgroup, dmginfo)
if (gBool("Misc.", "Damage Logger")) then
local pname = dmginfo:GetInflictor():Name()
local pdamage = tostring(dmginfo:GetDamage())
local phealth = tostring(ply:Health()-dmginfo:GetDamage())
if (gInt("Misc.", "Damage Log Mode") == 0) then  
 chat.AddText( Color( 0, 125, 125 ), "[wave] ", pname, ", Did ", pdamage , " Damage To ", ply:Name(),", Health Remaining: ", phealth )
end
if (gInt("Misc.", "Damage Log Mode") == 1) then  
 notification.AddLegacy("[wave] " ..pname .. " Did " .. pdamage .. " Damage To " .. ply:Name() .. ", Health Remaining: " .. phealth, NOTIFY_IDFK, 5)
end
end	
end
hook.Add("ScalePlayerDamage", "dmglogchat", dmglogchat)

local ply = LocalPlayer()
local speed = ply:GetVelocity():Length()
local pspeed = math.Round(speed)

local function l0l()
 if (gBool("Misc.", "HUD")) then 
     cur_fps = tostring(math.floor(1 / RealFrameTime()));
     local rrr = gInt("Colors", "HUD R");
     local ggg = gInt("Colors", "HUD G");
     local bbb = gInt("Colors", "HUD B");
	
  local ply = LocalPlayer()
  local speed = ply:GetVelocity():Length()
  local pspeed = math.Round(speed)
  draw.SimpleText("valorwave v1.2.2", "GModNotify", 4, 20, Color(rrr, ggg, bbb), TEXT_ALIGN_LEFT, TEXT_ALIGN_BOTTOM)
  draw.SimpleText("PING: " ..LocalPlayer():Ping(), "DermaDefault", 4, 40, Color(rrr, ggg, bbb), TEXT_ALIGN_LEFT, TEXT_ALIGN_BOTTOM)
  draw.SimpleText("FPS: " ..cur_fps, "DermaDefault", 80, 40, Color(rrr, ggg, bbb), TEXT_ALIGN_LEFT, TEXT_ALIGN_BOTTOM)
  draw.SimpleText(pspeed.. " - Speed", "Default", 1000, 520, Color(rrr, ggg, bbb), TEXT_ALIGN_LEFT, TEXT_ALIGN_BOTTOM)
  draw.SimpleText("Health - " ..ply:Health(), "Default", 865, 520, Color(rrr, ggg, bbb), TEXT_ALIGN_LEFT, TEXT_ALIGN_BOTTOM)
end
end
hook.Add("DrawOverlay", "wtfhook", l0l)


hook.Add("PreDrawViewModel", "nuttybutter", function()
if (gBool("Visuals", "Hand Chams")) then 
     local ply = LocalPlayer()
     local r = gInt("Colors", "Hand R");
     local g = gInt("Colors", "Hand G");
     local b = gInt("Colors", "Hand B");	
     render.MaterialOverride(matweapon)
     render.SetColorModulation(r,g,b)
else if (!gBool("Visuals", "Hand Chams")) then 

	        local restoreweap = Material("")
                render.MaterialOverride(restoreweap)

end
end
end)

hook.Add("CreateMove", "kys", function(ucmd) 	   
	if (gBool("Misc.", "Autostrafe")) then  	
		local ply = LocalPlayer()
		if ply:GetMoveType() == MOVETYPE_LADDER || ply:GetMoveType() == MOVETYPE_NOCLIP then return end
		if ucmd:KeyDown( IN_JUMP ) then
			if ucmd:GetMouseX() < 0 then
				ucmd:SetSideMove(-450)
			elseif ucmd:GetMouseX() > 0 then
				ucmd:SetSideMove(450)
			end
		end
end
end)	

local function Unload()
	for k, v in pairs(hooks) do
		hook.Remove(v, k)
	end
	for k, v in pairs(player.GetAll()) do
		v:SetRenderMode(0)
	end
	print("Unloaded the cheat.")
end

local function Menu()  	   
	local larrowdown, rarrowdown, darrowdown, uarrowdown;  	   
	local main = vgui.Create("DFrame");  	   
	main:SetSize(170, 5);  	   
	main:SetTitle("");  	   
	main:ShowCloseButton(false);  	   
	main:SetDraggable(false);  	   
	main:SetPos(gInt("Menu", "Pos X"), gInt("Main", "Pos Y"));  	   
	  	   
	local allitems = 0;  	   
	local sel = 0;  	   
	  	   
	function main:Paint(w, h)  	   
		menvars["BGColor"] = Color(gInt("Menu", "Background R"), gInt("Menu", "Background G"), gInt("Menu", "Background B"), gInt("Menu", "Background A"))  	   
		menvars["TXTColor"] = Color(gInt("Menu", "Text R"), gInt("Menu", "Text G"), gInt("Menu", "Text B"), 255)  	   
		menvars["OutlineColor"] = Color(gInt("Menu", "Outline R"), gInt("Menu", "Outline G"), gInt("Menu", "Outline B"), 255)  	   
		menvars["BarColor"] = Color(gInt("Menu", "Bar R"), gInt("Menu", "Bar G"), gInt("Menu", "Bar B"), 255)  	   
		local backcolor = menvars["BGColor"];  	   
		local txtcolor = menvars["TXTColor"];  	   
		local outcolor = menvars["OutlineColor"];  	   
		local barcol = menvars["BarColor"];  	   
		if (gBool("Menu", "Autism")) then  	   
			backcolor = Color(math.random(255), math.random(255), math.random(255), backcolor.a);  	   
			barcol = Color(math.random(0), math.random(0), math.random(255));  	   
			outcolor = barcol;  	   
			local aa = math.random(3);  	   
			txtcolor = Color(aa == 1 && math.random(255) - barcol.r || math.random(255), aa == 2 && math.random(255) - barcol.g || math.random(255), aa == 3 && math.random(255) - barcol.b || math.random(255));  	   
		end  	   
		allitems = 0;  	   
		surface.SetTextColor(txtcolor);  	   
		local hh = 25;  	   
		surface.SetFont("BudgetLabel");  	   
		surface.SetDrawColor(backcolor);  	   
		surface.DrawRect(0, 0, w, h);  	   
  	   
		  	   
		surface.SetDrawColor(barcol);  	   
		surface.DrawRect(0, 0, w, 20);  	   
		  	   
		local ww, hh2 = surface.GetTextSize(menvars["Cheat Name"]);  	   
		  	   
		surface.SetTextPos(w / 2 - (ww / 2), 2);  	   
		surface.DrawText(menvars["Cheat Name"]);  	   
		  	   
		for k,v in SortedPairs(vars) do  	   
			allitems = allitems + 1;  	   
			local citem = allitems;  	   
			if (cursel == citem) then  	   
				if (sel != 0) then  	   
					showtabs[k] = !showtabs[k];  	   
					sel = 0;  	   
				end  	   
				surface.SetDrawColor(barcol);  	   
				surface.DrawRect(0, hh, w, 15);  	   
			end  	   
			surface.SetTextPos(5, hh);  	   
			surface.DrawText((showtabs[k] and "[-] " or "[+] ")..k);  	   
			hh = hh + 15;  	   
			if (!showtabs[k]) then continue; end  	   
			for _, var in next, vars[k] do  	   
				allitems = allitems + 1;  	   
				local curitem = allitems;	  	   
				if (cursel == curitem) then  	   
					if (sel != 0) then  	   
						if (k == "Colors" && string.find(vars[k][_][1], "Cham")) then sel = sel * 5; end
                                                if (k == "Colors" && string.find(vars[k][_][1], "Glow")) then sel = sel * 5; end
                                                if (k == "Colors" && string.find(vars[k][_][1], "HUD")) then sel = sel * 5; end
                                                if (k == "Colors" && string.find(vars[k][_][1], "Prop")) then sel = sel * 5; end
                                                if (k == "Colors" && string.find(vars[k][_][1], "Box")) then sel = sel * 5; end
                                                if (k == "Colors" && string.find(vars[k][_][1], "Cross")) then sel = sel * 5; end
                                                if (k == "Colors" && string.find(vars[k][_][1], "Sight")) then sel = sel * 5; end
                                                if (k == "Colors" && string.find(vars[k][_][1], "Npc")) then sel = sel * 5; end
                                                if (k == "Colors" && string.find(vars[k][_][1], "Sky")) then sel = sel * 5; end
                                                if (k == "Menu" && string.find(vars[k][_][1], "Pos")) then sel = sel * 5; end          	   
						if (vars[k][_][1] != "" && !(vars[k][_][3] && (vars[k][_][2] + sel >  vars[k][_][3]))) then  	   
							vars[k][_][2] = (vars[k][_][2] + sel >= 0 && vars[k][_][2] + sel || (vars[k][_][1] == "Max X" || vars[k][_][1] == "Max Y" || vars[k][_][1] == "Min Y" || vars[k][_][1] == "Min X") && vars[k][_][2] + sel || vars[k][_][2]);  	   
							timer.Simple(.05, function()  	   
								if ((larrowdown || rarrowdown)  && cursel == curitem && k == "Menu" || (larrowdown || rarrowdown) && cursel == curitem && (vars[k][_][1] == "Max X" || vars[k][_][1] == "Max Y" || vars[k][_][1] == "Min Y" || vars[k][_][1] == "Min X")) then  	   
									larrowdown = false;  	   
									rarrowdown = false;  	   
								end  	   
							end);  
   	   
						end  	   
						sel = 0;  	   
					end  	   
					drawtext = (vars[k][_][4] && vars[k][_][4] || "");  	   
					mh = hh;  	   
					surface.SetDrawColor(barcol);  	   
					surface.DrawRect(0, hh, w, 16);  	   
				end  	   
				surface.SetTextPos(15, hh);  	   
				local n = vars[k][_][1];  	   
				if (n != "") then  	   
					surface.DrawText(vars[k][_][1]..":");  	   
				end  	   
				surface.SetTextPos(130, hh);  	   
				if (n != "" && k != "Menu" && vars[k][_][1] != "Max X" && vars[k][_][1] != "Max Y" && vars[k][_][1] != "Min Y" && vars[k][_][1] != "Min X") then  	   
					surface.DrawText(vars[k][_][2]..".00");  	   
				else  	   
					surface.DrawText(vars[k][_][2]);  	   
				end  	   
				hh = hh + 15;  	   
			end  	   
		end  	   
		  	   
		allitems = allitems + 1;  	   
		local curitem = allitems;  	   
		  	   
		if (cursel == curitem) then  	   
			if (sel != 0) then  	   
				showtabs["Configs"] = !showtabs["Configs"];  	   
				sel = 0;  	   
			end  	   
			surface.SetDrawColor(barcol);  	   
			surface.DrawRect(0, hh, w, 15);  	   
		end  	   
		  	   
		surface.SetTextPos(5, hh);  	   
		surface.DrawText((showtabs["Configs"] and "[-] " or "[+] ").."Configs");  	   
	  	   
		hh = hh + 15;  	   
		  	   
		if (showtabs["Configs"]) then  	   
			allitems = allitems + 1;  	   
			local citem = allitems;  	   
			local tr = "0.00";  	   
			if (cursel == citem) then  	   
				if (sel != 0) then  	   
					sel = 0;  	   
					tr = "1.00";	   
					file.Write("rmenu/"..menvars["Cheat Name"].."/vars.txt", util.TableToJSON(vars, true));  	   
					file.Write("rmenu/"..menvars["Cheat Name"].."/mvars.txt", util.TableToJSON(menvars, true));
                                        notification.AddLegacy("[wave] Config Saved To garrysmod/data/rmenu!", NOTIFY_HINT, 5)    	   
				end  	   
				surface.SetDrawColor(barcol);  	   
				surface.DrawRect(0, hh, w, 15);  	   
			end  	   
			surface.SetTextPos(15, hh);  	   
			surface.DrawText("Save CFG:");  	   
			surface.SetTextPos(130, hh);  	   
			surface.DrawText(tr);  	   
			hh = hh+15;  	   
			  	   
			  	   
			allitems = allitems + 1;  	   
			local citem2 = allitems;  	   
			local tr2 = "0.00";  	   
			if (cursel == citem2) then  	   
				if (sel != 0) then  	   
					sel = 0;  	   
					tr2 = "1.00";  	   
					loadconfig();
                                        notification.AddLegacy("[wave] Config Loaded!", NOTIFY_HINT, 5)    	   
				end  	   
				surface.SetDrawColor(barcol);  	   
				surface.DrawRect(0, hh, w, 15);  	   
			end  	   
			surface.SetTextPos(15, hh);  	   
			surface.DrawText("Load CFG:");  	   
			surface.SetTextPos(130, hh);  	   
			surface.DrawText(tr2);  	   
			hh = hh+15;  	   
		end  	   
		  	   
		  	   
		  	   
		main:SetSize(170, hh + 5);  	   
		  	   
		main:SetPos(gInt("Menu", "Pos X"), gInt("Menu", "Pos Y"));  	   
  	   
		surface.SetDrawColor(outcolor);  	   
		surface.DrawOutlinedRect(0, 0, 170, hh + 5);  	   
	end  	   
	  	   
	function main:Think()  	   
		if (input.IsKeyDown(KEY_UP) && !uarrowdown) then  	   
			if (cursel - 1 > 0) then  	   
				cursel = cursel - 1;  	   
			else  	   
				cursel = allitems;  	   
			end  	   
			uarrowdown = true;  	   
		elseif (!input.IsKeyDown(KEY_UP)) then  	   
			uarrowdown = false;  	   
		end  	   
		  	   
		if (input.IsKeyDown(KEY_DOWN) && !darrowdown) then  	   
			if (cursel < allitems) then  	   
				cursel = cursel + 1;  	   
			else  	   
				cursel = 1;  	   
			end  	   
			darrowdown = true;  	   
		elseif (!input.IsKeyDown(KEY_DOWN)) then  	   
			darrowdown = false;  	   
		end  	   
		  	   
		if (input.IsKeyDown(KEY_LEFT) && !larrowdown) then  	   
			sel = -1;  	   
			larrowdown = true;  	   
		elseif (!input.IsKeyDown(KEY_LEFT)) then  	   
			larrowdown = false;  	   
		end  	   
		  	   
		if (input.IsKeyDown(KEY_RIGHT) && !rarrowdown) then  	   
			sel = 1;  	   
			rarrowdown = true;  	   
		elseif (!input.IsKeyDown(KEY_RIGHT)) then  	   
			rarrowdown = false;  	   
		end  	   
		if (input.IsKeyDown(KEY_INSERT) && !insertdown2) then  	   
			main:Close();  	   
			drawtext = "";  	   
			menuopen = false;  	   
		end  	   
	end  	   
end  	   

local side = "MOUSE_LEFT"
local mat = Material("models/flat")
local mat3 = Material("models/wireframe")
local mat4 = Material("models/wireframe")
  	 
-- Taunt Spammer
tauntspam = {}
tauntspam[1] = "dance"
tauntspam[2] = "muscle"
tauntspam[3] = "robot"
tauntspam[4] = "laugh"

ply = LocalPlayer()

local function tauntspamfunc()
	if (gBool("Misc.", "Taunt Spam")) then  	
		ply:ConCommand("act "..table.Random(tauntspam).." " )
	end
end

timer.Create("tauntspam", 0.9, 0, tauntspamfunc)

-- Hitsounds
local insertdown = false;  	   
local sound = "neverlose.wav"
local sound2 = "kill.wav"
   
function GAMEMODE:Think()  	   
	if (input.IsKeyDown(KEY_INSERT) && !menuopen && !insertdown) then  	   
		menuopen = true;  	   
		insertdown = true;  	   
		Menu();  	   
	elseif (!input.IsKeyDown(KEY_INSERT) && !menuopen) then  	   
		insertdown = false;  	   
	end  	   
	if (input.IsKeyDown(KEY_INSERT) && insertdown && menuopen) then  	   
		insertdown2 = true;  	   
	else  	   
		insertdown2 = false;  	   
	end

 if (gInt("Misc.", "Chatspam Type") == 0) then

        if (gBool("Misc.", "Chatspam") && gBool("Misc.", "Chatspam OOC")) then
		ply:ConCommand("say /ooc "..table.Random(chatspam).." ")
	elseif (gBool("Misc.", "Chatspam")) then
		ply:ConCommand("say "..table.Random(chatspam).." ")  	
     end
   end

 if (gInt("Misc.", "Chatspam Type") == 1) then  	
	if (gBool("Misc.", "Chatspam") && gBool("Misc.", "Chatspam OOC")) then 
		ply:ConCommand("say /ooc "..table.Random(zrespam).." ")
	elseif (gBool("Misc.", "Chatspam")) then
		ply:ConCommand("say "..table.Random(zrespam).." ")
     end
   end

 if (gInt("Misc.", "Chatspam Type") == 2) then

        if (gBool("Misc.", "Chatspam") && gBool("Misc.", "Chatspam OOC")) then
		ply:ConCommand("say /ooc "..table.Random(naxutspam).." ")
	elseif (gBool("Misc.", "Chatspam")) then
		ply:ConCommand("say "..table.Random(naxutspam).." ")  	
     end
   end



-- Test Material 1
CreateMaterial( "kysmat", "VertexLitGeneric", {
  ["$basetexture"] = "Models/effects/splodearc_sheet",
  ["$model"] = 1,
  ["$translucent"] = 1,
  ["$vertexalpha"] = 1,
  ["$vertexcolor"] = 99
} )

-- Test Material 2
local mattest = CreateMaterial( '!White9', 'VertexLitGeneric', 
{
    ["$basetexture"] = "models/debug/debugwhite",
    ["$nocull"] = "1",
    ["$model"] = "1",
})

side = MOUSE_LEFT	

if (gInt("Misc.", "Hitsound Sound") == 0) then  
 sound = "neverlose.wav"	
end
if (gInt("Misc.", "Hitsound Sound") == 1) then  
 sound = "qbeep.wav"	
end
if (gInt("Misc.", "Hitsound Sound") == 2) then  
 sound = "buttons/button17.wav"	
end
if (gInt("Misc.", "Hitsound Sound") == 3) then  
 sound = "cod.wav"	
end
if (gInt("Misc.", "Hitsound Sound") == 4) then  
 sound = "headshot.wav"	
end
if (gInt("Misc.", "Hitsound Sound") == 5) then  
 sound = "kill.wav"	
end   
if (gInt("Misc.", "Hitsound Sound") == 6) then  
 sound = "headshot2.wav"	
end
if (gInt("Misc.", "Kill Sound") == 0) then  
 sound2 = "neverlose.wav"	
end
if (gInt("Misc.", "Kill Sound") == 1) then  
 sound2 = "qbeep.wav"	
end
if (gInt("Misc.", "Kill Sound") == 2) then  
 sound2 = "buttons/button15.wav"	
end
if (gInt("Misc.", "Kill Sound") == 3) then  
 sound2 = "cod.wav"	
end
if (gInt("Misc.", "Kill Sound") == 4) then  
 sound2 = "headshot.wav"	
end
if (gInt("Misc.", "Kill Sound") == 5) then  
 sound2 = "kill.wav"	
end   
if (gInt("Misc.", "Kill Sound") == 6) then  
 sound2 = "headshot2.wav"	
end
if (gInt("Visuals", "Hand Material") == 0) then  
 matweapon = Material("models/wireframe")	
end
if (gInt("Visuals", "Hand Material") == 1) then  
 matweapon = Material("models/props_combine/portalball001_sheet")	
end
if (gInt("Visuals", "Hand Material") == 2) then  
 matweapon = Material("models/props_lab/Tank_Glass001")		
end
if (gInt("Visuals", "Hand Material") == 3) then  
 matweapon = Material("models/XQM/LightLinesRed_tool")		
end   
if (gInt("Visuals", "Hand Material") == 4) then  
 matweapon = Material("Models/effects/splodearc_sheet")		
end   
if (gInt("Visuals", "Hand Material") == 5) then  
 matweapon = Material("debug/env_cubemap_model")		
end   
if (gInt("Visuals", "Hand Material") == 6) then  
 matweapon = Material("models/props_combine/stasisshield_sheet")		
end   
if (gInt("Visuals", "Hand Material") == 7) then  
 matweapon = Material("models/shadertest/shader3")		
end   
if (gInt("Visuals", "Hand Material") == 8) then  
 matweapon = Material("models/shiny")		
end 
if (gInt("Visuals", "Hand Material") == 9) then  
 matweapon = Material("shadertest/cubemapdemo")		
end 
if (gInt("Visuals", "Hand Material") == 10) then  
 matweapon = Material("models/player/shared/gold_player")		
end 
if (gInt("Visuals", "Hand Material") == 11) then  
 matweapon = Material("models/Alyx/emptool_glow")		
end 
if (gInt("Visuals", "Hand Material") == 12) then  
 matweapon = Material("spongebobwashere")		
end
if (gInt("Visuals", "Hand Material") == 13) then  
 matweapon = Material("models/screenspace")		
end
if (gInt("Visuals", "Hand Material") == 14) then  
 matweapon = Material("models/props_combine/com_shield001a")		
end
if (gInt("Visuals", "Hand Material") == 15) then  
 matweapon = Material("models/debug/debugwhite")		
end
if (gInt("Visuals", "Cham Mat") == 0) then  
 mat = Material("models/wireframe")	
end
if (gInt("Visuals", "Cham Mat") == 1) then  
 mat = Material("models/props_lab/Tank_Glass001")		
end
if (gInt("Visuals", "Cham Mat") == 2) then  
 mat = Material("models/XQM/LightLinesRed_tool")		
end     
if (gInt("Visuals", "Cham Mat") == 3) then  
 mat = Material("debug/env_cubemap_model")		
end   
if (gInt("Visuals", "Cham Mat") == 4) then  
 mat = Material("models/props_combine/stasisshield_sheet")		
end   
if (gInt("Visuals", "Cham Mat") == 5) then  
 mat = Material("models/shadertest/shader3")		
end   
if (gInt("Visuals", "Cham Mat") == 6) then  
 mat = Material("models/shiny")		
end 
if (gInt("Visuals", "Cham Mat") == 7) then  
 mat = Material("shadertest/cubemapdemo")		
end 
if (gInt("Visuals", "Cham Mat") == 8) then  
 mat = Material("models/player/shared/gold_player")		
end
if (gInt("Visuals", "Cham Mat") == 9) then  
 mat = Material("models/screenspace")		
end
if (gInt("Visuals", "Cham Mat") == 10) then  
 mat = Material("models/props_combine/com_shield001a")		
end
if (gInt("Visuals", "Cham Mat") == 11) then  
 mat = Material("heybrowhatsup")		
end
if (gInt("Visuals", "Cham Mat") == 12) then  
 mat = Material("models/debug/debugwhite")
end
if (gInt("Visuals", "Prop Mat") == 0) then  
 mat4 = Material("models/wireframe")	
end
if (gInt("Visuals", "Prop Mat") == 1) then  
 mat4 = Material("models/props_lab/Tank_Glass001")		
end
if (gInt("Visuals", "Prop Mat") == 2) then  
 mat4 = Material("models/XQM/LightLinesRed_tool")		
end     
if (gInt("Visuals", "Prop Mat") == 3) then  
 mat4 = Material("debug/env_cubemap_model")		
end   
if (gInt("Visuals", "Prop Mat") == 4) then  
 mat4 = Material("models/props_combine/stasisshield_sheet")		
end   
if (gInt("Visuals", "Prop Mat") == 5) then  
 mat4 = Material("models/shadertest/shader3")		
end   
if (gInt("Visuals", "Prop Mat") == 6) then  
 mat4 = Material("models/shiny")		
end 
if (gInt("Visuals", "Prop Mat") == 7) then  
 mat4 = Material("shadertest/cubemapdemo")		
end 
if (gInt("Visuals", "Prop Mat") == 8) then  
 mat4 = Material("models/player/shared/gold_player")		
end
if (gInt("Visuals", "Prop Mat") == 9) then  
 mat4 = Material("models/screenspace")		
end
if (gInt("Visuals", "Prop Mat") == 10) then  
 mat4 = Material("models/props_combine/com_shield001a")		
end
if (gInt("Visuals", "Prop Mat") == 11) then  
 mat4 = Material("heybrowhatsup")		
end
if (gInt("Visuals", "Prop Mat") == 12) then  
 mat4 = Material("models/debug/debugwhite")
end
if (gInt("Visuals", "Npc Mat") == 0) then  
 mat3 = Material("models/wireframe")	
end
if (gInt("Visuals", "Npc Mat") == 1) then  
 mat3 = Material("models/props_lab/Tank_Glass001")		
end
if (gInt("Visuals", "Npc Mat") == 2) then  
 mat3 = Material("models/XQM/LightLinesRed_tool")		
end     
if (gInt("Visuals", "Npc Mat") == 3) then  
 mat3 = Material("debug/env_cubemap_model")		
end   
if (gInt("Visuals", "Npc Mat") == 4) then  
 mat3 = Material("models/props_combine/stasisshield_sheet")		
end   
if (gInt("Visuals", "Npc Mat") == 5) then  
 mat3 = Material("models/shadertest/shader3")		
end   
if (gInt("Visuals", "Npc Mat") == 6) then  
 mat3 = Material("models/shiny")		
end 
if (gInt("Visuals", "Npc Mat") == 7) then  
 mat3 = Material("shadertest/cubemapdemo")		
end 
if (gInt("Visuals", "Npc Mat") == 8) then  
 mat3 = Material("models/player/shared/gold_player")		
end
if (gInt("Visuals", "Npc Mat") == 9) then  
 mat3 = Material("models/screenspace")		
end
if (gInt("Visuals", "Npc Mat") == 10) then  
 mat3 = Material("models/props_combine/com_shield001a")		
end
if (gInt("Visuals", "Npc Mat") == 11) then  
 mat3 = Material("heybrowhatsup")		
end
if (gInt("Visuals", "Npc Mat") == 12) then  
 mat3 = Material("models/debug/debugwhite")
end					
if (gInt("Aimbot", "Mouse Side") == 0) then  
 side = MOUSE_LEFT		
end
if (gInt("Aimbot", "Mouse Side") == 1) then  
 side = MOUSE_RIGHT		
 end
end
  	   

local mat2 = CreateMaterial("", "VertexLitGeneric", {  	   
	["$basetexture"] = "models/debug/debugwhite",   	   
	["$model"] = 1,   	   
	["$ignorez"] = 1,  	   
});  	 
  	   
loadconfig();  	   
  	   
local em = FindMetaTable("Entity");  	   
local cm = FindMetaTable("CUserCmd");  	   
local pm = FindMetaTable("Player");  	   
local vm = FindMetaTable("Vector");  	   
local am = FindMetaTable("Angle");  	   
local wm = FindMetaTable("Weapon");  	   
  	   
  	   
local function ESP(ent)  	   
	local pos = em.GetPos(ent);  	   
	local pos2 = pos + Vector(0, 0, 70);  	   
	local pos = vm.ToScreen(pos);  	   
	local pos2 = vm.ToScreen(pos2);  	   
	local h = pos.y - pos2.y;  	   
	local w = h / 2;
   	local r22 = gInt("Colors", "Box R");
	local g22 = gInt("Colors", "Box G");
	local b22 = gInt("Colors", "Box B");  	   
	local col = Color(r22, g22, b22);  	   
	if (gBool("ESP", "2D Box")) then  	   
		surface.SetDrawColor(col);  	   
		surface.DrawOutlinedRect(pos.x - w / 2, pos.y - h, w, h);  	   
		surface.DrawOutlinedRect(pos.x - w / 2 + 2, pos.y - h + 2, w - 4, h - 4);  	   
		local ocol = Color(r22, g22, b22);  	   
		surface.SetDrawColor(ocol);  	   
		surface.DrawOutlinedRect(pos.x - w / 2 - 1, pos.y - h - 1, w + 2, h + 2);  	   
		surface.DrawOutlinedRect(pos.x - w / 2 + 1, pos.y - h + 1, w - 2, h - 2);  	   
	end  	   
	if (gBool("ESP", "Healthbar")) then  	   
		local bgcol = (gBool("Visuals", "Autism") && Color(math.random(255), math.random(255), math.random(255)) || Color(0, 0, 0));  	   
		surface.SetDrawColor(bgcol);  	   
		surface.DrawRect(pos.x - (w/2) - 7, pos.y - h - 1, 5, h + 2);  	   
		local hp = em.Health(ent);  	   
		local col1 = gBool("Visuals", "Autism") && Color(math.random(255), math.random(255), math.random(255)) || Color(0,255,0);  	   
		surface.SetDrawColor((100 - hp) * 2.55, hp * 2.55, 0);  	   
		local hp = hp * h / 100;  	   
		local diff = h - hp;  	   
		surface.DrawRect(pos.x - (w / 2) - 6, pos.y - h + diff, 3, hp);  	   
	end  	   
	  	   
	local hh = 0;  	   
	  	   
	local txtstyle = gBool("ESP", "Text Style");  	   
	  	   
	if (gBool("ESP", "Name")) then   
		local col1 = gBool("Visuals", "Autism") && Color(math.random(255), math.random(255), math.random(255)) || Color(0,200,0);  	   
		local col2 = gBool("Visuals", "Autism") && Color(math.random(255), math.random(255), math.random(255)) || Color(200,72,52);
                local col3 = gBool("Visuals", "Autism") && Color(math.random(255), math.random(255), math.random(255)) || Color(255,0,0);    	   
		local friendstatus = pm.GetFriendStatus(ent);
                local friendstatus = pm.SteamID(ent);	    	   
		if (!txtstyle) then  	   
			draw.SimpleText(pm.Name(ent), "DermaDefault", pos.x, pos.y - h - (friendstatus == "friend" && 7 || 7), col1, 1, 1);  	   
			if (friendstatus == "friend") then  	   
				draw.SimpleText("Friend", "DermaDefault", pos.x, pos.y - h - 17, col2, 1, 1);  	   
			end  	   
		else  	   
			draw.SimpleText(pm.Name(ent), "DermaDefault", pos.x + (w/2) + 5, pos.y - h + 3 + hh, col1, 0, 1);  	   
			hh = hh + 10;  	   
			if (friendstatus == "friend") then  	   
				draw.SimpleText("Friend", "DermaDefault", pos.x + (w/2) + 5, pos.y - h + 3 + hh, col2, 0, 1);  	   
				hh = hh + 10;  	   
			end  	       	       	       	       	       	   
		end  	   
	end  	   
	if (gBool("ESP", "Health")) then  	   
		hh = hh + 10;  	   
		local col1 = gBool("Visuals", "Autism") && Color(math.random(255), math.random(255), math.random(255)) || Color((100 - em.Health(ent)) * 2.55, em.Health(ent) * 2.55, 0);  	   
			draw.SimpleText("Health:"..em.Health(ent), "DermaDefault", pos.x, pos.y - 2, col1, 1, 0);  	   
	end  	   
	if (gBool("ESP", "Distance")) then  	   
		local col = gBool("Visuals", "Autism") && Color(math.random(255), math.random(255), math.random(255)) || Color(255,210,255);  	   
			draw.SimpleText("Distance:"..math.ceil(vm.Distance(em.GetPos(ent), em.GetPos(me))), "DermaDefault", pos.x, pos.y - 2 + hh, col, 1, 0);  	   
		hh = hh + 10;  	   
	end  	   
	if (gBool("ESP", "Rank")) then  	   
		local col = gBool("Visuals", "Autism") && Color(math.random(255), math.random(255), math.random(255)) || Color(170,0,170);  	   
			draw.SimpleText("Rank:"..pm.GetUserGroup(ent), "DermaDefault", pos.x, pos.y - 2 + hh, col, 1, 0);  	   
	end
	if (gBool("ESP", "Weapon")) then  	   
		local col = gBool("Visuals", "Autism") && Color(math.random(255), math.random(255), math.random(255)) || Color(170,0,170);  	   
			draw.SimpleText("Weapon: "..ent.GetActiveWeapon(ent):GetClass(ent), "DermaDefault", pos.x, pos.y + 6 + hh, col, 1, 0);  	   
	end
                        if (steamid == "STEAM_0:1:580804253") then  	   
				draw.SimpleText("VWAVE", "DermaDefault", pos.x + (w/2) + 5, pos.y - h + 3 + hh, col2, 0, 1);  	   
				hh = hh + 12;  	   
			end
                        if (steamid == "STEAM_0:1:99841604") then  	   
				draw.SimpleText("VWAVE OWNER/DEV", "DermaDefault", pos.x + (w/2) + 5, pos.y - h + 3 + hh, col2, 0, 1);  	   
				hh = hh + 12;  	   
			end
                        if (steamid == "STEAM_0:0:168107795") then  	   
				draw.SimpleText("VWAVE", "DermaDefault", pos.x + (w/2) + 5, pos.y - h + 3 + hh, col2, 0, 1);  	   
				hh = hh + 12;  	   
			end
                        if (steamid == "STEAM_0:0:453611223") then  	   
				draw.SimpleText("VWAVE CO-OWNER", "DermaDefault", pos.x + (w/2) + 5, pos.y - h + 3 + hh, col2, 0, 1);  	   
				hh = hh + 12;  	   
			end
                        if (steamid == "STEAM_0:0:147339105") then  	   
				draw.SimpleText("VWAVE", "DermaDefault", pos.x + (w/2) + 5, pos.y - h + 3 + hh, col2, 0, 1);  	   
				hh = hh + 12;  	   
			end
                        if (steamid == "STEAM_0:1:547859568") then  	   
				draw.SimpleText("VWAVE", "DermaDefault", pos.x + (w/2) + 5, pos.y - h + 3 + hh, col2, 0, 1);  	   
				hh = hh + 12;  	   
			end
                        if (steamid == "STEAM_0:0:502890624") then  	   
				draw.SimpleText("TEST", "DermaDefault", pos.x + (w/2) + 5, pos.y - h + 3 + hh, col2, 0, 1);  	   
				hh = hh + 12;  	   
			end
                        if (steamid == "NULL") then  	   
				draw.SimpleText("BOT", "DermaDefault", pos.x + (w/2) + 5, pos.y - h + 3 + hh, col2, 0, 1);  	   
				hh = hh + 12;  	   
			end         	     	   
end  	   
  	   
local function GB(ent, bone)  	   
	local bone = em.LookupBone(ent, bone);  	   
	return(bone && vm.ToScreen(em.GetBonePosition(ent, bone)) || nil);  	   
end  	   


-- Crimwalk	
local function fakewalk( ucmd )

if(gBool("HvH", "Crimwalk")) then 
 local pSpeed = tonumber(gInt("HvH", "Crim Speed"))
  if LocalPlayer():KeyDown( IN_SPEED ) then
   ucmd:RemoveKey(IN_FORWARD)
   ucmd:RemoveKey(IN_BACK)
   ucmd:RemoveKey(IN_LEFT)
   ucmd:RemoveKey(IN_RIGHT)
   ucmd:SetForwardMove(-1)
   ucmd:SetSideMove(-1)
    if LocalPlayer():KeyDown(IN_MOVERIGHT) then
	   ucmd:SetForwardMove(0)
	   ucmd:SetSideMove(pSpeed)
	 end

    if LocalPlayer():KeyDown(IN_MOVELEFT) then
	   ucmd:SetForwardMove(0)
	   ucmd:SetSideMove(-pSpeed)
	 end
      end
   end
end



local function memee(ucmd)
	fakewalk(ucmd)	
end

hook.Add("CreateMove", "memmeme", memee)

-- Shitty Hitsound System   

hook.Add("ScalePlayerDamage", "lolkys", function(ply, group, dmginfo)
	if(gBool("Misc.", "Hitsounds")) then 
		if dmginfo:GetAttacker() == LocalPlayer() then
			surface.PlaySound(sound)
		end
	end
end)

local function bugfix(cmd)
if(cmd:KeyDown(IN_USE)) then
hook.Remove("CreateMove", "memmeme")
else
hook.Add("CreateMove", "memmeme", memee)
end
end 


local function DrawCrosshair()  	   
	if (!gBool("Visuals", "Crosshair")) then return; end
   	local r22 = gInt("Colors", "Cross R");
	local g22 = gInt("Colors", "Cross G");
	local b22 = gInt("Colors", "Cross B");  	   
	surface.SetDrawColor((gBool("Visuals", "Autism") && Color(math.random(255), math.random(255), math.random(255))) || Color(r22,g22,b22));  	   
	local w, h = ScrW(), ScrH();  	   
	surface.DrawLine(w / 2 - 15, h / 2, w / 2 - 5, h / 2);  	   
	surface.DrawLine(w / 2 + 15, h / 2, w / 2 + 5, h / 2);  	   
	surface.DrawLine(w / 2, h / 2 - 15, w / 2, h / 2 - 5);  	   
	surface.DrawLine(w / 2, h / 2 + 15, w / 2, h / 2 + 5);  	   
end  	   
  	   
function GAMEMODE:HUDShouldDraw(str)  	   
	if (str == "CHudCrosshair" && gBool("Visuals", "Crosshair")) then return false; else return true; end  	   
end   	   
  	   
local function Skeleton(ent)  	   
	if (!gBool("ESP", "Skeleton")) then return; end  	   
  	   
	local b = {  	   
		head = GB(ent, "ValveBiped.Bip01_Head1"),  	   
		neck = GB(ent, "ValveBiped.Bip01_Neck1"),  	   
		spine4 = GB(ent, "ValveBiped.Bip01_Spine4"),  	   
		spine2 = GB(ent, "ValveBiped.Bip01_Spine2"),  	   
		spine1 = GB(ent, "ValveBiped.Bip01_Spine1"),  	   
		spine = GB(ent, "ValveBiped.Bip01_Spine"),  	   
		rarm = GB(ent, "ValveBiped.Bip01_R_UpperArm"),  	   
		rfarm = GB(ent, "ValveBiped.Bip01_R_Forearm"),  	   
		rhand = GB(ent, "ValveBiped.Bip01_R_Hand"),  	   
		larm = GB(ent, "ValveBiped.Bip01_L_UpperArm"),  	   
		lfarm = GB(ent, "ValveBiped.Bip01_L_Forearm"),  	   
		lhand = GB(ent, "ValveBiped.Bip01_L_Hand"),  	   
		rthigh = GB(ent, "ValveBiped.Bip01_R_Thigh"),  	   
		rcalf = GB(ent, "ValveBiped.Bip01_R_Calf"),  	   
		rfoot = GB(ent, "ValveBiped.Bip01_R_Foot"),  	   
		rtoe = GB(ent, "ValveBiped.Bip01_R_Toe0"),  	   
		lthigh = GB(ent, "ValveBiped.Bip01_L_Thigh"),  	   
		lcalf = GB(ent, "ValveBiped.Bip01_L_Calf"),  	   
		lfoot = GB(ent, "ValveBiped.Bip01_L_Foot"),  	   
		ltoe = GB(ent, "ValveBiped.Bip01_L_Toe0"),  	   
	}  	   
	  	   
	if (!b.head||!b.neck||!b.spine4||!b.spine2||!b.spine1||!b.spine||!b.rarm||!b.rfarm||!b.rarm||!b.rhand||!b.larm||!b.lfarm||!b.lhand||!b.rthigh||!b.rcalf||!b.rfoot||!b.rtoe||!b.lthigh||!b.lcalf||!b.lfoot||!b.ltoe) then return; end  	   
	  	   
	local col = gBool("Visuals", "Autism") && Color(math.random(255), math.random(255), math.random(255)) || Color(255,255,255);  	   
	  	   
	surface.SetDrawColor(col);  	   
	surface.DrawLine(b.head.x, b.head.y, b.neck.x, b.neck.y);  	   
	surface.DrawLine(b.neck.x, b.neck.y, b.spine4.x, b.spine4.y);  	   
	surface.DrawLine(b.spine4.x, b.spine4.y, b.spine2.x, b.spine2.y);  	   
	surface.DrawLine(b.spine2.x, b.spine2.y, b.spine1.x, b.spine1.y);  	   
	surface.DrawLine(b.spine1.x, b.spine1.y, b.spine.x, b.spine.y);  	   
	  	   
	surface.DrawLine(b.spine4.x, b.spine4.y, b.rarm.x, b.rarm.y);  	   
	surface.DrawLine(b.rarm.x, b.rarm.y, b.rfarm.x, b.rfarm.y);  	   
	surface.DrawLine(b.rfarm.x, b.rfarm.y, b.rhand.x, b.rhand.y);  	   
	  	   
	surface.DrawLine(b.spine4.x, b.spine4.y, b.larm.x, b.larm.y);  	   
	surface.DrawLine(b.larm.x, b.larm.y, b.lfarm.x, b.lfarm.y);  	   
	surface.DrawLine(b.lfarm.x, b.lfarm.y, b.lhand.x, b.lhand.y);  	   
	  	   
	surface.DrawLine(b.spine.x, b.spine.y, b.rthigh.x, b.rthigh.y);  	   
	surface.DrawLine(b.rthigh.x, b.rthigh.y, b.rcalf.x, b.rcalf.y);  	   
	surface.DrawLine(b.rcalf.x, b.rcalf.y, b.rfoot.x, b.rfoot.y);  	   
	surface.DrawLine(b.rfoot.x, b.rfoot.y, b.rtoe.x, b.rtoe.y);  	   
	  	   
	surface.DrawLine(b.spine.x, b.spine.y, b.lthigh.x, b.lthigh.y);  	   
	surface.DrawLine(b.lthigh.x, b.lthigh.y, b.lcalf.x, b.lcalf.y);  	   
	surface.DrawLine(b.lcalf.x, b.lcalf.y, b.lfoot.x, b.lfoot.y);  	   
	surface.DrawLine(b.lfoot.x, b.lfoot.y, b.ltoe.x, b.ltoe.y);  	   
end  	   
  	   
function GAMEMODE:DrawOverlay()  	   
	local allplys = player.GetAll();  	   
	for i = 1, #allplys do  	   
		local v = allplys[i];  	   
		if (!v || !em.IsValid(v) || v == me || em.Health(v) < 1) then continue; end  	   
		ESP(v);  	   
		Skeleton(v);  	   
	end  	   
	DrawCrosshair();  	   
  	   
	if (!mh || !drawtext || drawtext == "") then return; end  	   
	surface.SetTextColor(menvars["TXTColor"]);  	   
	surface.SetFont("BudgetLabel");  	   
	local w, h = surface.GetTextSize(drawtext);  	   
	surface.SetTextPos( gInt("Menu", "Pos X") + 180, mh + (h / 2.5));  	   
	surface.DrawText(drawtext);  	   
end  	   
  	   
local fa = em.EyeAngles(me);  	   
  	   
local function Bunnyhop(ucmd)  	   
 if (!gBool("Misc.", "Bunnyhop")) then return; end
    if (gInt("Misc.", "Bhop Mode") == 0) then  	   
	if (!em.IsOnGround(me) && cm.KeyDown(ucmd, 2)) then  	   
		cm.SetButtons(ucmd, bit.band(cm.GetButtons(ucmd), bit.bnot(2)));  	   
	end  	   
end
end

local function acBunnyhop(cmd)
 if (!gBool("Misc.", "Bunnyhop")) then return; end 
    if (gInt("Misc.", "Bhop Mode") == 1) then   
	buttons = cmd:GetButtons()
	if cmd:KeyDown(IN_JUMP) and me:IsValid() and me:GetMoveType() ~= MOVETYPE_NOCLIP and me:Alive() then
		buttons = bit.band(buttons, bit.bnot(IN_JUMP))
                if math.random(1,2) == 2 then
		cmd:SetButtons(buttons)
                end
	end
end
end	     	   
  	   
local function FixMovement(ucmd, aa)  	   
	local ang = Vector(cm.GetForwardMove(ucmd), cm.GetSideMove(ucmd), 0)  	   
	local ang = am.Forward((vm.Angle(vm.GetNormal(ang)) + (cm.GetViewAngles(ucmd) - Angle(0, fa.y, 0)))) * vm.Length(ang)  	   
	cm.SetForwardMove(ucmd, ang.x);  	   
	cm.SetSideMove(ucmd, ( aa && ang.y * -1 || ang.y));  	   
end  	   	   
  	   
local cones = {};  	   
  	   
local ofb = em.FireBullets;  	   
  	   
local aimignore;  	   
  	   
local nullcone = Vector() * -1;  	   
  	   
function em.FireBullets(p, data)  	   
	if (p != me) then return ofb(p, data); end  	   
	if (gInt("Aimbot", "Target Method") == 1) then  	   
		aimignore = aimtarget;  	   
		aimtarget = nil;  	   
	end  	   
	local Spread = data.Spread * -1;  	   
	local w = pm.GetActiveWeapon(me);  	   
	if (!w || !em.IsValid(w)) then return ofb(p, data); end  	   
	local class = em.GetClass(w);  	   
	if (cones[class] == Spread) then return ofb(p, data); end  	   
	if (Spread == nullcone) then return ofb(p, data); end  	   
	cones[class] = Spread;  	   
	return ofb(p, data);  	   
end  	   
  	   
local function PredictSpread(ucmd, ang)  	   
	local w = pm.GetActiveWeapon(me);  	   
	if (!w || !em.IsValid(w)) then return ang; end  	   
	local class = em.GetClass(w);  	   
	if (!cones[class]) then return ang; end  	   
	return vm.Angle(dickwrap.Predict(ucmd, am.Forward(ang), cones[class]));  	   
end  	   
  	   
local function GetPos(v)  	   
	if (gBool("Aimbot", "Bodyaim")) then return( em.LocalToWorld(v, em.OBBCenter(v)) ); end  	   
	local eyes = em.LookupAttachment(v, "eyes");  	   
	local pos = eyes && em.GetAttachment(v, eyes);  	   
	return(pos && pos.Pos || em.LocalToWorld(v, em.OBBCenter(v)));  	   
end  	   
  	   
local function Valid(ent)
	if (!ent || !em.IsValid(ent) || ent == me || ent == aimignore || em.Health(ent) < 1 || em.IsDormant(ent) || pm.Team(ent) == 1002 || (!gBool("Aimbot", "Target Noclip") && ent:GetMoveType(ent) == MOVETYPE_NOCLIP) || (!gBool("Aimbot", "Target Build") && ent:GetNWBool("Buildmode", false)) || (!gBool("Aimbot", "Target Team") && (pm.Team(ent) == pm.Team(me))) || (!gBool("Aimbot", "Target Bots") && pm.IsBot(ent)) || (!gBool("Aimbot", "Target Friends") && pm.GetFriendStatus(ent) == "friend")) then return false; end  	   
	local tr = {  	   
		mask = 1174421507,  	   
		endpos = GetPos(ent),  	   
		start = em.EyePos(me),  	   
		filter = {me, ent},  	   
	};  	   
	return (util.TraceLine(tr).Fraction == 1);  	   
 end  
	   
  	   
local function GetTarget()  	   
	local aimmethod = gInt("Aimbot", "Target Method");  	   
	if (Valid(aimtarget) && aimmethod != 3 && aimmethod != 2) then return; end  	   
	aimtarget = nil;  	   
	local allplys = player.GetAll();  	   
	if (aimmethod == 1) then  	   
		local plys = {}  	   
		local vals = {}  	   
		for i = 1, #allplys do  	   
			table.insert(vals, i);  	   
		end  	   
		for i = 1, #allplys do  	   
			local rand = table.Random(vals);  	   
			local v = allplys[i];  	   
			table.insert(plys, rand, v);  	   
			table.remove(vals, rand);  	   
		end  	   
		local num = 1;  	   
		repeat  	   
			local v = plys[num];  	   
			if Valid(v) then  	   
				aimtarget = v;  	   
			end  	   
			num = num + 1;  	   
		until(aimtarget || num > #plys)  	   
	elseif(aimmethod == 0) then  	   
		local num = 1;  	   
		repeat  	   
			local v = allplys[num];  	   
			if (Valid(v)) then aimtarget = v; end  	   
			num = num + 1;  	   
		until(aimtarget || num > #allplys);  	   
	elseif (aimmethod == 2) then  	   
		local dists = {};  	   
		local num = 1;  	   
		repeat  	   
			local v = allplys[num];  	   
			if (Valid(v)) then  	   
				local d = vm.Distance(em.GetPos(v), em.GetPos(me));  	   
				table.insert(dists, {d, v});  	   
			end  	   
			num = num + 1;  	   
		until(num > #allplys)  	   
		table.sort(dists, function(a, b) return a[1] < b[1] end);  	   
		aimtarget = (dists[1] && dists[1][2] || nil);   	   
	elseif (aimmethod == 3) then  	   
		local health = {};  	   
		local num = 1;  	   
		repeat  	   
			local v = allplys[num];  	   
			if (Valid(v)) then  	   
				table.insert(health, {em.Health(v), v});  	   
			end  	   
			num = num + 1;  	   
		until(num > #allplys)  	   
		table.sort(health, function(a, b) return a[1] < b[1] end);  	   
		aimtarget = (health[1] && health[1][2] || nil);   	   
	end  	   
	aimignore = nil;  	   
end  	   

local function GetClosest()
	local ddists = {}
	local closest

	for k,v in next, player.GetAll() do
		ddists[#ddists + 1] = { v:GetPos():Distance(me:GetPos()), v }
	end

	table.sort(ddists, function(a, b)
		return a[1] < b[1]
	end)

	closest = ddists[1] and ddists[1][2] or nil

	if not closest then
		return fa.y
	end

	local pos = closest:GetPos()
	local pos = (pos - me:EyePos()):Angle()

	return pos.y
end

local function GetClosest()
	local ddists = {}
	local closest

	for k,v in next, player.GetAll() do

		ddists[#ddists + 1] = { v:GetPos():Distance(me:GetPos()), v }
	end

	table.sort(ddists, function(a, b)
		return a[1] < b[1]
	end)

	closest = ddists[1] and ddists[1][2] or nil

	if not closest then
		return fa.y
	end

	local pos = closest:GetPos()
	local pos = (pos - me:EyePos()):Angle()

	return pos.y
end
	   
local function Antiaim(ucmd)  	   
	if (!gBool("HvH", "Antiaim") || cm.KeyDown(ucmd, 1) || aiming) then return; end  	   
	local aam = gInt("HvH", "Method");  	   
	if (aam == 0) then  	   
		local aang = Angle(gInt("HvH", "Min X"), gInt("HvH", "Min Y"), 0);  	   
		cm.SetViewAngles(ucmd, aang);  	   
		FixMovement(ucmd, true);  	   
	elseif(aam == 1) then  	   
		local aang = Angle(math.random(gInt("HvH", "Min X"), gInt("HvH", "Max X")), math.random(gInt("HvH", "Min Y"), gInt("HvH", "Max Y")), 0);  	   
		cm.SetViewAngles(ucmd, aang);  	   
		FixMovement(ucmd, true);  	   
	elseif(aam == 2) then  	   
		local aang = Angle(gInt("HvH", "Min X"), math.NormalizeAngle(fa.y + 90), 0);  	   
		cm.SetViewAngles(ucmd, aang);  	   
		FixMovement(ucmd, true);  
        elseif(aam == 3) then  	   
		local aang = Angle("+540.000005");  	   
		cm.SetViewAngles(ucmd, aang);  	   
		FixMovement(ucmd, true);  
        elseif(aam == 4) then  	   
		local aang = Angle("180.001");  	   
		cm.SetViewAngles(ucmd, aang);  	   
		FixMovement(ucmd, true);  
        elseif(aam == 5) then  	   
		local aang = Angle(math.random(179.99999999999999999999999999999999999, 180.000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000001));  	   
		cm.SetViewAngles(ucmd, aang);  	   
		FixMovement(ucmd, true); 
        elseif(aam == 6) then  	   
		local aang = Angle(math.random(-181, -179));  	    	   
		cm.SetViewAngles(ucmd, aang);  	   
		FixMovement(ucmd, true);  
        elseif(aam == 7) then  	   
		local aang = Angle("+360.000001");  	    	   
		cm.SetViewAngles(ucmd, aang);  	   
		FixMovement(ucmd, true);  
	end
end
   
local function Aimbot(ucmd)  	   
	fa = fa + Angle(cm.GetMouseY(ucmd) * .023, cm.GetMouseX(ucmd) * -.023, 0);  	   
	fa.p = math.Clamp(fa.p, -89, 89);  	   
	fa.x = math.NormalizeAngle(fa.x);  	   
	fa.y = math.NormalizeAngle(fa.y);  	   
	GetTarget();  	   
	if (aimtarget) then	   	   
		local canbot = gBool("Aimbot", "Enabled");  	   
		local canbot = canbot && !gBool("Aimbot", "Aim on Mouse");  	   
		if (!canbot) then  	   
			canbot = gBool("Aimbot", "Enabled") && gBool("Aimbot", "Aim on Mouse") && input.IsMouseDown(side);  	   
		end  	   
		if (canbot) then  	   
			aiming = true;  	   
			local w = pm.GetActiveWeapon(me);  	   
			local nextfire = ( (w && w.Primary && w.Primary.RPM && (60/w.Primary.RPM)) || 0);  	   
			if ((w && em.GetClass(w) == "m9k_minigun")) then  	   
				nextfire = nextfire*3;  	   
			end  	   
			local btime = gBool("Aimbot", "Bullettime");  	   
			local canaim = (btime && (wm.GetNextPrimaryFire(w) - nextfire) <= CurTime());  	   
			if (!btime) then  	   
				canaim = true;  	   
			end  	   
			if (canaim) then  	   
				local pos = vm.Angle(GetPos(aimtarget) - em.EyePos(me));  	   
				if (gBool("Aimbot", "Nospread")) then  	   
					pos = PredictSpread(ucmd, pos);  	   
				end  	   
				pos.x = math.NormalizeAngle(pos.x);  	   
				pos.y = math.NormalizeAngle(pos.y);  	   
				cm.SetViewAngles(ucmd, pos);  	   
				if (gBool("Aimbot", "Autoshoot")) then  	   
					cm.SetButtons(ucmd, bit.bor(ucmd.GetButtons(ucmd), 1));  	   
				end  	   
				FixMovement(ucmd);  	   
				return;  	   
			end  	   
		end  	   
	end  	   
	aiming = false;  	   
	if( (gBool("HvH", "Antiaim") || gBool("HvH", "Spinbot")) && !cm.KeyDown(ucmd, 1) ) then return; end  	   
	if (gBool("Aimbot", "Nospread") && cm.KeyDown(ucmd, 1)) then  	   
		local hey = PredictSpread(ucmd, fa);  	   
		hey.x = math.NormalizeAngle(hey.x);  	   
		hey.y = math.NormalizeAngle(hey.y);  	   
		cm.SetViewAngles(ucmd, hey);  	   
		return  	   
	end  	   
	cm.SetViewAngles(ucmd, fa);  	   
end  	   
  	   
local function Spinbot(ucmd)  	   
	if (!gBool("HvH", "Spinbot") || gBool("HvH", "Antiaim") || cm.KeyDown(ucmd, 1)) then return; end  	   
	cm.SetViewAngles(ucmd, Angle(fa.x, cm.GetViewAngles(ucmd).y + gInt("HvH", "Speed"), 0));  	   
	FixMovement(ucmd);  	   
end  	   
  	   
local function Triggerbot(ucmd)  	   
	if (!gBool("Triggerbot", "Enabled")) then return; end  	   
	local tr = pm.GetEyeTrace(me);  	   
	if (!em.IsValid(tr.Entity) || !tr.Entity:IsPlayer() || em.Health(tr.Entity) < 1 || em.IsDormant(tr.Entity)) then return; end  	   
	if (!gBool("Triggerbot", "Target Friends") && pm.GetFriendStatus(tr.Entity) == "friend") then return; end  	   
	if (!gBool("Triggerbot", "Target Team") && pm.Team(me) == pm.Team(tr.Entity)) then return; end  	   
	cm.SetButtons(ucmd, bit.bor(cm.GetButtons(ucmd), 1));  	   
end  	   
  	   
function GAMEMODE:CreateMove(ucmd)
        bSendPacket = true;	  	   
	Bunnyhop(ucmd);
        acBunnyhop(ucmd);    	   
	Triggerbot(ucmd);  	   
	Aimbot(ucmd);  	   
	Spinbot(ucmd);  	   
	Antiaim(ucmd);   
end  	   
  	   
function GAMEMODE:CalcView(p, o, a, f)  	   
	local view = {}  	   
	view.origin = (gBool("Misc.", "Thirdperson") && o - (am.Forward(fa) * (gInt("Misc.", "Thirdperson D.") * 10)) || o);  	   
	view.angles = fa;  	   
	view.fov = f;  	   
	return view;  	   
end  	   
  	   
local quake=0;  	   
  	   
local ks = {  	   
	nil,  	   
	"quake/doublekill.wav",  	   
	"quake/triplekill.wav",  	   
	"quake/dominating.wav",  	   
	"quake/killingspree.wav",  	   
	"quake/rampage.wav",  	   
	"quake/megakill.wav",  	   
	"quake/monsterkill.wav",  	   
	"quake/ultrakill.wav",  	   
	"quake/unstoppable.wav",  	   
	"quake/godlike.wav",  	   
}  	   

-- Prop ESP
hook.Add( "HUDPaint", "PropESP", function()
	for k,v in pairs (ents.FindByClass("prop_physics")) do
		if (gBool("Visuals", "Prop Chams")) then 
			cam.Start3D(EyePos(), EyeAngles())
				if v:IsValid() then
                                        local col2 = (gBool("Visuals", "Autism") && Color(math.random(255), math.random(255), math.random(255))) || Color(gInt("Prop", "Prop R"), gInt("Colors", "Prop G"), gInt("Colors", "Prop B"))      		                      
					render.SuppressEngineLighting( true )
					render.SetColorModulation(col2.b / 255, col2.r / 255, col2.g / 255)
                                        render.MaterialOverride(mat4);  
					v:DrawModel()
                                        render.MaterialOverride(mat4);
				        render.SuppressEngineLighting( false )
				cam.End3D()
			end
		end
	end
end)
--

hook.Add( "HUDPaint", "NpcESP", function()
 for k, v in ipairs(ents.GetAll()) do
	    if v:IsNPC() then
		if (gBool("Visuals", "Npc Chams")) then 
			cam.Start3D(EyePos(), EyeAngles())
				if v:IsValid() then
                                        local col3 = (gBool("Visuals", "Autism") && Color(math.random(255), math.random(255), math.random(255))) || Color(gInt("Prop", "Npc R"), gInt("Colors", "Npc G"), gInt("Colors", "Npc B"))                                             
					render.SuppressEngineLighting( true )
					render.SetColorModulation(col3.b / 255, col3.r / 255, col3.g / 255)
                                        render.MaterialOverride(mat3);
					v:DrawModel()
                                        render.MaterialOverride(mat3);
				        render.SuppressEngineLighting( false )
				cam.End3D()
			end
		end
	end
end
end)

-- GLOW STUFF STARTED
local plys = {}

timer.Create("lolwtf", 1, 0, function()
  plys = {}
  npcs = {}
  props = {}
    for k,v in next, player.GetAll() do
        table.insert(plys, v)
    end
    for k, v in ipairs(ents.GetAll()) do
        if v:IsNPC() then
             table.insert(npcs, v)
    end
    for k,v in pairs (ents.FindByClass("prop_physics")) do
        table.insert(props, v)         
    end
end
end)

hook.Add("PreDrawHalos", "playerglow", function()
		 if (!gBool("Visuals", "Player Glow")) then return; end  	   
			halo.Add(plys, Color(gInt("Colors", "Glow R"), gInt("Colors", "Glow G"), gInt("Colors", "Glow B")), 1, gInt("Visuals", "Glow Bloom"), 2, true, true)
                   end)

hook.Add("PreDrawHalos", "propglow", function()
		 if (!gBool("Visuals", "Prop Glow")) then return; end  	   
			halo.Add(props, Color(gInt("Colors", "Glow R"), gInt("Colors", "Glow G"), gInt("Colors", "Glow B")), 1, gInt("Visuals", "Glow Bloom"), 2, true, true)
                   end)


hook.Add("PreDrawHalos", "npcglow", function()
		 if (!gBool("Visuals", "Npc Glow")) then return; end  	   
			halo.Add(npcs, Color(gInt("Colors", "Glow R"), gInt("Colors", "Glow G"), gInt("Colors", "Glow B")), 1, gInt("Visuals", "Glow Bloom"), 2, true, true)
                   end)

-- GLOW STUFF FINISHED
	   
-- Zre If Your Seeing This Shit
-- I failed making velocity chams
  	   
function GAMEMODE:RenderScreenspaceEffects()  	   
	if (!gBool("Visuals", "Chams")) then return; end  	   
	local allplys = player.GetAll();  	   
	for i = 1, #allplys do  	   
		local v = allplys[i];  	   
		if (!v || !em.IsValid(v) || v == me || em.Health(v) < 1 || pm.Team(v) == 1002) then continue; end
                  	   
                local col = (gBool("Visuals", "Autism") && Color(math.random(255), math.random(255), math.random(255))) || Color(gInt("Colors", "Cham G"), gInt("Colors", "Cham B"), gInt("Colors", "Cham R"))                                                  	   
                  	  	 	   
		cam.Start3D();	   
			render.MaterialOverride(mat);  	   
			render.SetColorModulation(col.b / 255, col.r / 255, col.g / 255);
                      if (gBool("Visuals", "IgnoreZ")) then
                        cam.IgnoreZ( true )
                      end
                        render.SuppressEngineLighting( true )	    
			em.DrawModel(v);
                      if (gBool("Visuals", "IgnoreZ")) then
                        cam.IgnoreZ( false )
                      end
                        render.SuppressEngineLighting( false ) 	   
			render.MaterialOverride(mat);  	   
			render.SetColorModulation(col.b / 255, col.r / 255, col.g / 255);                         
			em.DrawModel(v);  	   
			render.SetColorModulation(1, 1, 1);  	   
		cam.End3D();  	   
	end  	   
end


function GAMEMODE:ShouldDrawLocalPlayer()  	   
	return(gBool("Misc.", "Thirdperson"));  	   
end  	   
  	   
function GAMEMODE:PreDrawSkyBox()  	   
	if (!gBool("Visuals", "Skybox Changer")) then return; end
        local col4 = (gBool("Visuals", "Autism") && Color(math.random(255), math.random(255), math.random(255))) || Color(gInt("Colors", "Sky R"), gInt("Colors", "Sky G"), gInt("Colors", "Cham B"))
        local ALPHA = (gInt("Colors", "Sky Alpha"))     	   
	render.SetColorModulation(col4.r / 255, col4.g / 255, col4.b / 255, ALPHA / 255);  	   
	return true;  	   
end  	   

-- render.Clear(col4.r / 255, col4.g / 255, col4.b / 255, ALPHA / 255);  	  

surface.PlaySound(sound2)

hook.Add("entity_killed", "wtf", function(data)
if (!gBool("Misc.", "Killsounds")) then return; end
 local att_index2 = data.entindex_attacker;
 local vic_index2 = data.entindex_killed;

 if(vic_index2 != att_index2 && att_index2 == me:EntIndex()) then
 surface.PlaySound(sound2)
 end


end) 	   
  	   
local ogethands = pm.GetHands; -- Note: Only for c_ viewmodels  	   
  	   
function pm.GetHands(...)  	   
	return(!gBool("Visuals", "No Hands") && ogethands(...));  	   
end

hook.Add("entity_killed", "", function(data)
if (!gBool("Misc.", "Killsay")) then return; end
 local att_index = data.entindex_attacker;
 local vic_index = data.entindex_killed;

 if(vic_index != att_index && att_index == me:EntIndex()) then
 RunConsoleCommand("say", "Owned By Valorwave...")
 end


end);