local function Copy( t, lookup_table )
	if ( t == nil ) then return nil end

	local copy = {}
	setmetatable( copy, debug.getmetatable( t ) )
	for i, v in pairs( t ) do
		if ( !istable( v ) ) then
			copy[ i ] = v
		else
			lookup_table = lookup_table or {}
			lookup_table[ t ] = copy
			if ( lookup_table[ v ] ) then
				copy[ i ] = lookup_table[ v ] 
			else
				copy[ i ] = Copy( v, lookup_table ) 
			end 
		end
	end 
	return copy
end

local G           = Copy( _G )
 
local g_surface   = G.surface 
local g_math      = G.math 
local g_util      = G.util 
local g_bit       = G.bit 
local g_cam       = G.cam 
local g_engine    = G.engine 
local g_ents      = G.ents 
local g_player    = G.player 
local g_game      = G.game 
local g_gui       = G.gui  
local g_input     = G.input 
local g_string    = G.string 
local g_table     = G.table 
local g_render    = G.render

local g_Angle     = G.Angle 
local g_Color     = G.Color 
local g_Vector    = G.Vector 
local g_CurTime   = G.CurTime 
local g_FrameTime = G.FrameTime 
local g_Entity    = G.Entity 
local g_ClientsideModel = G.ClientsideModel 
local g_CreateMaterial = G.CreateMaterial 
local g_pairs = G.pairs 
local g_ipairs = G.ipairs 
local g_IsValid = G.IsValid 
local g_Player = G.Player 

local g_Capture = g_render.Capture

local me = G.LocalPlayer()
local scrw = ScrW()
local scrh = ScrH()

local ultimate = {}

function render.Capture( data )
    print("sawooooooooooooooooo")
    return g_Capture( data )
end

function G.render.Capture( data )
    print("sawooooooooooooooooo")
    return g_Capture( data )
end


/*



ultimate.keyPressData = {}

for i = -1, 172 do
    ultimate.keyPressData[ i ] = false
end

function ultimate.IsKeyDown( key )
    if key >= 107 then
        return input.IsMouseDown( key )
    end

    return input.IsKeyDown( key )
end

function ultimate.WasKeyPressed( key )
    if key >= 107 then
        return input.WasMousePressed( key )
    end 

    return input.WasKeyPressed( key )
end







ultimate.cursorPos      = { x = 0,  y = 0}
ultimate.menuPos        = { x = 15, y = 15 }
ultimate.drawContext    = { x = -1, y = -1 }
ultimate.cursorPosFuncs = { [ true ] = G.RestoreCursorPosition, [ false ] = G.RememberCursorPosition }

ultimate.currentTab = 1
ultimate.tabs   = {
    [ 1 ] = "Combat",
    [ 2 ] = "Rage",
    [ 3 ] = "Movement",
    [ 4 ] = "Players",
    [ 5 ] = "World",
    [ 6 ] = "Misc",
    [ 7 ] = "Settings",
}

ultimate.showMenu   = false
ultimate.oldState   = false 

function ultimate.CursorInRect( x, y, w, h )
    return ( ultimate.cursorPos.x >= x  and ultimate.cursorPos.y >= y ) and ( ultimate.cursorPos.x < x + w and ultimate.cursorPos.y < y + h )
end

ultimate.scale = {}

ultimate.ui = {}




local menuw, menuh = 800, 600

local function hCreateMove()
    for i = -1, 172 do
        ultimate.keyPressData[ i ] = ultimate.WasKeyPressed( i )
    end

end

local function hThink()
    gui.EnableScreenClicker( ultimate.oldCursorState )

    if ultimate.keyPressData[ 73 ] then 
        ultimate.showMenu = not ultimate.showMenu
        ultimate.cursorPosFuncs[ ultimate.showMenu ]()
    end

    ultimate.oldCursorState = vgui.CursorVisible()

    if ultimate.showMenu then
        gui.EnableScreenClicker( true )

        if input.IsMouseDown( MOUSE_LEFT ) and ultimate.CursorInRect( ultimate.menuPos.x, ultimate.menuPos.y, menuw, menuh ) then
            local cx, cy = input.GetCursorPos()

            ultimate.menuPos.x = ultimate.menuPos.x + ( cx - ultimate.cursorPos.x )
            ultimate.menuPos.y = ultimate.menuPos.y + ( cy - ultimate.cursorPos.y )
        end 
    end

    ultimate.cursorPos.x, ultimate.cursorPos.y = input.GetCursorPos()
end

local N = 0
local blur = Material("pp/blurscreen")

surface.CreateFont( "nigg", {
	font = "Roboto Lt",
	extended = false,
	size = 42,
	weight = 100,
} )

surface.CreateFont( "nigg2", {
	font = "Roboto Lt",
	extended = false,
	size = 24,
	weight = 100,
} )

ultimate.drawContext = { x = -1, y = -1 }
ultimate.drawTabs = {}

ultimate.drawTabs[ 1 ] = function()

end

ultimate.drawTabs[ 2 ] = function()

end

ultimate.drawTabs[ 3 ] = function()

end












local function hOverlay()
    local x, y, w, h = ultimate.menuPos.x, ultimate.menuPos.y, menuw, menuh

    if ultimate.showMenu then

        render.SetScissorRect( x, y, x + w, y + h, true )

        surface.SetDrawColor( 255, 255, 255 )
        surface.SetMaterial( blur )

        surface.SetFont( "nigg" )

        for i = 1, 4 do
            blur:SetFloat("$blur", i )
            blur:Recompute()
    
            render.UpdateScreenEffectTexture()
            surface.DrawTexturedRect(N * -1, N * -1, scrw, scrh)
        end

        surface.SetDrawColor( 24, 24, 24, 200 )
        surface.DrawRect( x, y, w, h ) 

        surface.SetDrawColor( 24, 24, 24, 48 )
        surface.DrawRect( x + 200, y, 1, h )  
        surface.DrawOutlinedRect( x, y, w, h )

        surface.SetTextColor( 255, 255, 255 )
        surface.SetTextPos( x + 16, y + 16 )
        surface.DrawText( "ULTIMATE" )

        surface.SetFont( "nigg2" )
    
        local ty = 72
        for i = 1, #ultimate.tabs do
            local a = i == ultimate.currentTab and 72 or 24
            surface.SetDrawColor( 24, 24, 24, a )
            surface.DrawRect( x, y + ty, 200, 38 ) 

            surface.SetTextPos( x + 16, y + ty + 8 )
            surface.DrawText( ultimate.tabs[ i ] )

            if ultimate.CursorInRect( x, y + ty, 200, 38 ) and ultimate.keyPressData[ 107 ] then 
                ultimate.currentTab = i
            end

            ty = ty + 42
        end

        ultimate.drawContext.x = 206 
        ultimate.drawContext.y = 6
        
        local aX, aY = x + ultimate.drawContext.x, y + ultimate.drawContext.y
        local aW, aH = w - ultimate.drawContext.x - 6, h - ultimate.drawContext.y - 6

        render.SetScissorRect( aX, aY, aX + aW, aY + aH, true )
        
        ultimate.drawTabs[ ultimate.currentTab ]()

        render.SetScissorRect( 0, 0, 0, 0, false )
    end
end
 
hook.Add( "DrawOverlay", "Overlay", hOverlay )
hook.Add( "Think", "Think", hThink )
hook.Add( "CreateMove", "CreateMove", hCreateMove )
*/