// note by paradox: This is just the menu, I got trolled.

/*
LOCALISATION
*/
 
local vgui = vgui;
local surface = surface;
local render = render;
local Color = Color;
local input = input;
local hook = hook;
local next = next;
local timer = timer;
local util = util;
local player = player;
local Vector = Vector;
local Angle = Angle;
local bit = bit;
local FindMetaTable = FindMetaTable;
local team = team;
local LocalPlayer = LocalPlayer;
local draw = draw;
local require = require;
local debug = debug;
local table = table;
local Entity = Entity;
local ScrW, ScrH = ScrW, ScrH;
local RunConsoleCommand = RunConsoleCommand;
local GAMEMODE = GAMEMODE;
local CurTime = CurTime;
local cam = cam;
local CreateMaterial = CreateMaterial;
local pmt = FindMetaTable("Player");
local emt = FindMetaTable("Entity");
local cmt = FindMetaTable("CUserCmd");
 
/*
OPTIONS
*/
 
local options = {
        {      
                "Aimbot",
                {"Active", true, "Checkbox"},
                {"Targeting Algorithm", "NextShot", "Selection", {"NextShot", "Distance", "Angle"}},
                {"Filters", nil, "Break"},
                {"Ignore Team", false, "Checkbox"},
                {"Ignore Team Color", false, "Checkbox"},
                {"Ignore Friends", false, "Checkbox"},
                {"Ignore Bots", false, "Checkbox"},
                {"Ignore Spawn Protected", true, "Checkbox"},
                {"Legit Settings", nil, "Break"},
                {"On Key", true, "Checkbox"},
                {"On Mouse", false, "Checkbox"},
                {"Smooth", false, "Checkbox"},
                {"Smooth Int", 0.5, "Slider", {0.01, 0.99, 2}},
                {"Visual Effects", nil, "Break"},
                {"Silent", true, "Checkbox"},
                {"Automation", nil, "Break"},
                {"Auto Shoot", true, "Checkbox"},
                {"Auto Pistol", true, "Checkbox"},
                {"Rage Settings", nil, "Break"},
                {"Bullet Time", false, "Checkbox"},
                {"Static", false, "Checkbox"},
                {"Aim Adjustment", nil, "Break"},
                {"Body Aim", false, "Checkbox"},
                {"Aim Position", "Hitbox", "Selection", {"Bone", "Hitbox"}}
        },
       
        {
                "ESP",
                {"Active", true, "Checkbox"},
                {"Filters", nil, "Break"},
                {"Show Players", true, "Checkbox"},
                {"Show NPC's", false, "Checkbox"},
                {"Show SENT's", false, "Checkbox"},
                {"Basic", nil, "Break"},
                {"Box Type", "2D", "Selection", {"2D", "3D"}},
                {"Box", true, "Checkbox"},
                {"Filled Box", true, "Checkbox"},
                {"Healthbar", true, "Checkbox"},
                {"Snapline", true, "Checkbox"},
                {"Aim Pos", true, "Checkbox"},
                {"Skeleton", true, "Checkbox"},
                {"Text", nil, "Break"},
                {"Health", true, "Checkbox"},
                {"Name", true, "Checkbox"},
                {"Weapon", true, "Checkbox"},
                {"Money", true, "Checkbox"},
                {"Rank", true, "Checkbox"},
                {"Fancy", nil, "Break"},
                {"Barrel", true, "Checkbox"},
                {"HitBox", false, "Checkbox"},
                {"Filled HitBox", false, "Checkbox"},
                {"Material", nil, "Break"},
                {"Chams", true, "Checkbox"},
                {"Chams Type", "XQZ", "Selection", {"Solid", "Wireframe", "XQZ"}}
        },
       
        {
                "Visuals",
                {"Active", true, "Checkbox"},
                {"Perspective", nil, "Break"},
                {"FoV", true, "Checkbox"},
                {"FoV Int", 120, "Slider", {90, 150, 0}},
                {"Third Person", false, "Checkbox"},
                {"ThirdPerson Int", 20, "Slider", {10, 20, 0}},
                {"Sky", false, "Checkbox"},
                {"Sky Type", "None", "Selection", {"None", "Rave"}},
                {"Viewmodel", nil, "Break"},
                {"No Hands", true, "Checkbox"},
                {"Weapon", true, "Checkbox"},
                {"Weapon Type", "Solid", "Selection", {"Wireframe", "Solid"}},
                {"Laser", true, "Checkbox"},
                {"Miscellaneous", nil, "Break"},
                {"Crosshair", true, "Checkbox"},
                {"Watermark", true, "Checkbox"},
                {"Crosshair Type", "Simple", "Selection", {"Simple", "Generic"}}
        },
       
        {
                "Miscellaneous",
                {"Active", true, "Checkbox"},
                {"Automation", nil, "Break"},
                {"Bunny Hop", true, "Checkbox"},
                {"Auto Pistol", true, "Checkbox"},
                {"Auto Aim", false, "Checkbox"},
                {"Auto Use", false, "Checkbox"},
                {"Auto Flash", true, "Checkbox"},
                {"Auto Strafer", nil, "Break"},
                {"Auto Strafer", true, "Checkbox"},
                {"Auto-Strafer Type", "Forwards", "Selection", {"Forwards", "Backwards", "Sideways", "W-Hop"}},
                {"View Fix", true, "Checkbox"},
                {"HvH", nil, "Break"},
                {"FakeLag", false, "Checkbox"},
                {"Slider", "FakeLag Int", {1, 14, 0}},
                {"Anti-Aim", false, "Checkbox"},
                {"Selection", "FakeDown", "Anti-Aim X", {"FakeDown", "FakeUp", "Jitter", "OOB"}},
                {"Selection", "FakeSide", "Anti-Aim Y", {"FakeSide", "Random"}},
                {"Removals", nil, "Break"},
                {"No Spread", true, "Checkbox"},
                {"No Recoil", true, "Checkbox"},
                {"No Punch", true, "Checkbox"},
                {"No Visual Recoil", true, "Checkbox"},
                {"Edge Jump", true, "Checkbox"},
                {"Name Stealer", false, "Checkbox"},
                {"Name Stealer Type", "Steam", "Selection", {"Steam", "DarkRP"}},
                {"Name Stealer Int", 6, "Slider", {1, 30, 0}},
        },
       
        {
                "Colors",
                {"Menu", nil, "Break"},
                {"Menu - R", 80, "Slider", {0, 255, 0}},
                {"Menu - G", 180, "Slider", {0, 255, 0}},
                {"Menu - B", 240, "Slider", {0, 255, 0}},
                {"Team", nil, "Break"},
                {"Team - R", 0, "Slider", {0, 255, 0}},
                {"Team - G", 0, "Slider", {0, 255, 0}},
                {"Team - B", 0, "Slider", {0, 255, 0}},
                {"Enemy", nil, "Break"},
                {"Enemy - R", 0, "Slider", {0, 255, 0}},
                {"Enemy - G", 0, "Slider", {0, 255, 0}},
                {"Enemy - B", 0, "Slider", {0, 255, 0}},
        }
};
 
/*
FLOATS
*/
 
local floats = {
        {      
                "Key",
                {KEY_INSERT, false, false},
                {KEY_F, false, false}
        },
       
        {      
                "Mouse",
                {MOUSE_MIDDLE, false, false},
                {MOUSE_LEFT, false, false}
        },
       
        {      
                "Menu",
                {"Active Tab", "Aimbot"},
                {"Wait", RealTime()}
        }
}
 
/*
FONTS
*/
 
surface.CreateFont("MenuFont", {
        font = "HaxrCorp S8 Standard",
        size = 14,
        antialias = false,
        shadow = true,
})
 
surface.CreateFont("_MenuFont", {
        font = "HaxrCorp S8 Standard",
        size = 12,
        antialias = false,
        shadow = true,
})
 
/*
MENU FUNCS
*/
 
local function gVal(t, c, o)
        for k,v in next, t do
                if (c != t[k][1]) then continue; end
                for i = 2, #t[k] do
                        if (t[k][i][1] != o) then continue; end
                        if (t[k][i][3] == "Break") then continue; end
                        return t[k][i][2];
                end
        end
end
 
local function sVal(t, c, o, v)
        for k,_v in next, t do
                if (c != t[k][1]) then continue; end
                for i = 2, #t[k] do
                        if (t[k][i][1] != o) then continue; end
                        t[k][i][2] = v;
                end
        end
end
 
local function gKey(c, o)
        for i = 1, 2 do
                if (c != floats[i][1]) then continue; end
                for _i = 2, #floats[i] do
                        if (floats[i][_i][1] != o) then continue; end
                        return floats[i][_i][2] && !floats[i][_i][3];
                end
        end
end
 
local function UpdateKeys()
        for i = 1, 2 do
                for _i = 2, #floats[i] do
                        floats[i][_i][3] = floats[i][_i][2];
                        if (i == 1) then
                                floats[i][_i][2] = input.IsKeyDown(floats[i][_i][1]);
                        end
                        if (i == 2) then
                                floats[i][_i][2] = input.IsMouseDown(floats[i][_i][1]);
                        end
                end
        end
end
 
local function CursorHovering(x, y, w, h, m)
        local cx, cy = input.GetCursorPos();
        local px, py = m:GetPos();
        x = x + px;
        y = y + py;
        return (cx > x && cx < (x+w) && cy > y && cy < (y+h));
end
 
/*
DRAWING
*/
 
local function DrawRect(x, y, w, h, c)
        surface.SetDrawColor(c);
        surface.DrawRect(x, y, w, h);
end
 
local function DrawOutlinedRect(x, y, w, h, c)
        surface.SetDrawColor(c);
        surface.DrawOutlinedRect(x, y, w, h);
end
 
local function DrawText(s, f, x, y, c, ax, ay)
        surface.SetFont(f);
        local w, h = surface.GetTextSize(s);
        surface.SetTextColor(c);
        x = (ax == "c" && x - w/2) || (ax == "r" && x - w) || x;
        y = (ay == "c" && y - h/2) || (ay == "b" && y - h) || y;
        surface.SetTextPos(math.ceil(x), math.ceil(y));
        surface.DrawText(s);
        return w, h;
end
 
local function DrawLine(x, y, _x, _y, c)
        surface.SetDrawColor(c);
        surface.DrawLine(x, y, _x, _y);
end
 
local function DrawTab(s, x, w, h, c, m)
        DrawRect(x, 24, w, h, (s == gVal(floats, "Menu", "Active Tab") && c || CursorHovering(x, 24, w, h, m) && Color(c.r*1.1, c.g*1.1, c.b*1.1) || Color(c.r/1.5, c.g/1.5, c.b/1.5)));
        DrawText(s, "_MenuFont", x+w/2, 24+h/2, Color(255, 255, 255), "c", "c");
        if (CursorHovering(x, 24, w, h, m) && input.IsMouseDown(MOUSE_LEFT)) then
                sVal(floats, "Menu", "Active Tab", s);
        end
end
 
local function DrawCheckbox(s, y, c, o, _c, m)
        DrawOutlinedRect(10, y, 10, 10, Color(0,0,0));
        DrawRect(11, y+1, 8, 8, Color(255,255,255));
        local w, h = surface.GetTextSize(s);
        DrawRect(12, y+2, 6, 6, (gVal(options, c, o) && _c || CursorHovering(10, y, 15 + w, 10, m) && Color(150, 150, 150) || Color(255,255,255)));
        DrawText(s, "_MenuFont", 23, y+4, Color(255, 255, 255), "l", "c");
        if (CursorHovering(10, y, 15 + w, 10, m) && input.IsMouseDown(MOUSE_LEFT) && RealTime() > gVal(floats, "Menu", "Wait")) then
                sVal(options, c, o, !gVal(options, c, o));
                sVal(floats, "Menu", "Wait", RealTime() + 0.1)
        end
end
 
local function DrawBreak(s, y, c, m)
        local w, h = surface.GetTextSize(s);
        DrawText(s, "_MenuFont", 390, y+5, CursorHovering(395 - w, y, w, h, m) && Color(math.random(10,255),math.random(10,255),math.random(10,255)) || c, "r", "c");
        DrawLine(10, y+5, 386 - w, y+5, c);
end
 
local function DrawSlider(s, y, c, o, _s, b, d, _c, m)
        local x, _y = input.GetCursorPos();
        local _x, __y = m:GetPos();
        DrawText(s, "_MenuFont", 13, y+4, Color(255, 255, 255), "l", "c");
        DrawText(math.floor(gVal(options, c, o)*10^d)/10^d, "_MenuFont", 390, y+4, Color(255, 255, 255), "r", "c");
        DrawLine(15, y+25, 385, y+25, _c);
        DrawOutlinedRect(14, y+24, 373, 3, Color(0,0,0));
        DrawOutlinedRect(((gVal(options, c, o)-_s)/(b-_s)*370)+10, y+15, 10, 20, Color(0,0,0));
        DrawRect(((gVal(options, c, o)-_s)/(b-_s)*370)+11, y+16, 8, 18, Color(255,255,255));
        DrawRect(((gVal(options, c, o)-_s)/(b-_s)*370)+12, y+17, 6, 16, CursorHovering(((gVal(options, c, o)-_s)/(b-_s)*370)+10, y+15, 10, 20, m) && Color(150,150,150) || Color(255,255,255));
        if (CursorHovering(15, y+15, 371, 20, m) && input.IsMouseDown(MOUSE_LEFT)) then
                local val = (x-_x-15)/370*(b-_s)+_s;
                sVal(options, c, o, val);
        end
end
 
local function DrawSelection(s, y, c, o, t, _c, m)
        for i = 1, #t do
                if (t[i] == gVal(options, c, o)) then
                        q=i;
                end
        end
        DrawText(s, "_MenuFont", 13, y+4, _c, "l", "c");
        DrawText(q, "_MenuFont", 390, y+4, _c, "r", "c");
        DrawRect(11, y+16, 18, 18, _c);
        DrawRect(12, y+17, 16, 16, CursorHovering(10, y+15, 20, 20, m) && Color(150,150,150) || _c);
        DrawLine(15, y+25, 25, y+25, Color(0,0,0));
        DrawLine(29, y+15, 29, y+35, Color(0,0,0));
        DrawOutlinedRect(10, y+15, 380, 20, Color(0,0,0));
        DrawRect(371, y+16, 18, 18, _c);
        DrawRect(372, y+17, 16, 16, CursorHovering(370, y+15, 20, 20, m) && Color(150,150,150) || _c);
        DrawLine(375, y+25, 385, y+25, Color(0,0,0));
        DrawLine(380, y+20, 380, y+30, Color(0,0,0));
        DrawLine(370, y+15, 370, y+35, Color(0,0,0));
        DrawRect(30, y+16, 340, 18, Color(150,150,150));
        DrawText(gVal(options, c, o), "_MenuFont", 200, y+25, CursorHovering(30, y+15, 340, 20, m) && Color(math.random(10,255),math.random(10,255),math.random(10,255)) || Color(255,255,255), "c", "c");
        if (CursorHovering(10, y+15, 20, 20, m) && input.IsMouseDown(MOUSE_LEFT) && RealTime() > gVal(floats, "Menu", "Wait")) then
                sVal(options, c, o, (t[math.Clamp(q-1, 1, #t)]));
                sVal(floats, "Menu", "Wait", RealTime() + 0.1);
        end
        if (CursorHovering(370, y+15, 20, 20, m) && input.IsMouseDown(MOUSE_LEFT) && RealTime() > gVal(floats, "Menu", "Wait")) then
                sVal(options, c, o, (t[math.Clamp(q+1, 1, #t)]));
                sVal(floats, "Menu", "Wait", RealTime() + 0.1);
        end
        if (CursorHovering(30, y+15, 340, 20, m) && input.IsMouseDown(MOUSE_LEFT) && RealTime() > gVal(floats, "Menu", "Wait")) then
                sVal(options, c, o, (t[math.random(1, #t)]));
                sVal(floats, "Menu", "Wait", RealTime() + 0.1);
        end
end
 
/*
MENU
*/
 
local Frame = vgui.Create("DFrame")
Frame:SetSize(400, 500)
Frame:ShowCloseButton(false)
Frame:SetTitle("")
Frame:MakePopup()
Frame:Center()
function Frame.Paint(self)
        local sw, sh = self:GetWide(), self:GetTall();
        DrawOutlinedRect(0, 0, sw, sh, Color(0, 0, 0));
        DrawRect(1, 1, sw-2, sh-2, Color(gVal(options, "Colors", "Menu - R"), gVal(options, "Colors", "Menu - G"), gVal(options, "Colors", "Menu - B")));
        DrawOutlinedRect(3, 23, sw-6, sh-26, Color(0, 0, 0));
        DrawRect(4, 24, sw-8, sh-28, Color(80, 80, 80));
        DrawText("Inertia", "MenuFont", self:GetWide()/2, 11, Color(255,255,255), "c", "c");
        DrawRect(sw-53, 1, 50, 20, CursorHovering(sw-53, 1, 50, 20, self) && Color(220, 100, 100) || Color(200, 80, 80));
        if (CursorHovering(sw-53, 1, 50, 20, self) && input.IsMouseDown(MOUSE_LEFT)) then
                Frame:SetVisible(false);
        end
        for k,v in next, options do
                DrawTab(options[k][1], 4+(((sw-8)/#options)*(k-1)), math.ceil((sw-8)/#options), 20, Color(gVal(options, "Colors", "Menu - R"), gVal(options, "Colors", "Menu - G"), gVal(options, "Colors", "Menu - B")), self);
                if (gVal(floats, "Menu", "Active Tab") == options[k][1]) then
                        local menuy = 50;
                        for i = 2, #options[k] do
                                if (options[k][i][3] == "Checkbox") then
                                        DrawCheckbox(options[k][i][1], menuy, options[k][1], options[k][i][1], Color(gVal(options, "Colors", "Menu - R"), gVal(options, "Colors", "Menu - G"), gVal(options, "Colors", "Menu - B")), self);
                                        menuy = menuy + 15;
                                elseif (options[k][i][3] == "Slider") then
                                        DrawSlider(options[k][i][1], menuy, options[k][1], options[k][i][1], options[k][i][4][1], options[k][i][4][2], options[k][i][4][3], Color(255,255,255), self);
                                        menuy = menuy + 40;
                                elseif (options[k][i][3] == "Selection") then
                                        DrawSelection(options[k][i][1], menuy, options[k][1], options[k][i][1], options[k][i][4], Color(255,255,255), self);
                                        menuy = menuy + 40;
                                elseif (options[k][i][3] == "Break") then
                                        DrawBreak(options[k][i][1], menuy, Color(255,255,255), self);
                                        menuy = menuy + 15;
                                end
                        end
                end
        end
end
 
local open = false;
 
local function Menu()
        if (gKey("Key", KEY_INSERT) && !LocalPlayer():IsTyping()) then
                open = !open;
                Frame:SetVisible(open)
        end
end
 
/*
HOOKING
*/
 
function GAMEMODE:Think()
        UpdateKeys();
        Menu();
end