--[[
	lua/ai.lua
	Jonny21 | (STEAM_0:1:32306606)
	===DStream===
]]

aimmodels = {
        ["models/combine_scanner.mdl"] = "Scanner.Body",
        ["models/hunter.mdl"] = "MiniStrider.body_joint",
        ["models/combine_turrets/floor_turret.mdl"] = "Barrel",
        ["models/dog.mdl"] = "Dog_Model.Eye",
        ["models/antlion.mdl"] = "Antlion.Body_Bone",
        ["models/antlion_guard.mdl"] = "Antlion_Guard.Body",
        ["models/antlion_worker.mdl"] = "Antlion.Head_Bone",
        ["models/zombie/fast_torso.mdl"] = "ValveBiped.HC_BodyCube",
        ["models/zombie/fast.mdl"] = "ValveBiped.HC_BodyCube",
        ["models/headcrabclassic.mdl"] = "HeadcrabClassic.SpineControl",
        ["models/headcrabblack.mdl"] = "HCBlack.body",
        ["models/headcrab.mdl"] = "HCFast.body",
        ["models/zombie/poison.mdl"] = "ValveBiped.Headcrab_Cube1",
        ["models/zombie/classic.mdl"] = "ValveBiped.HC_Body_Bone",
        ["models/zombie/classic_torso.mdl"] = "ValveBiped.HC_Body_Bone",
        ["models/zombie/zombie_soldier.mdl"] = "ValveBiped.HC_Body_Bone",
        ["models/combine_strider.mdl"] = "Combine_Strider.Body_Bone",
        ["models/lamarr.mdl"] = "HeadcrabClassic.SpineControl"
}
 prefix = "me"

function whp()
        local ply = LocalPlayer()
        local trace = util.GetPlayerTrace(ply)
        local traceRes = util.TraceLine(trace)
       
        if traceRes.HitNonWorld and GayCheck(traceRes.Entity) and !table.HasValue(Player_Whitelist, traceRes.Entity:SteamID()) then
                file.Write("aimbot_whitelist.txt", file.Read("aimbot_whitelist.txt")..","..traceRes.Entity:SteamID())
                chat.AddText(Color(0, 0, 255), "�������� ".."["..traceRes.Entity:GetName().." || "..traceRes.Entity:SteamID().."]")
        --      surface.PlaySound(Language["sound_toggle"])
        elseif traceRes.HitNonWorld and GayCheck(traceRes.Entity) and table.HasValue(Player_Whitelist, traceRes.Entity:SteamID()) then
                file.Write("aimbot_whitelist.txt", string.Replace(file.Read("aimbot_whitelist.txt"),","..traceRes.Entity:SteamID(), ""))
                chat.AddText(Color(0, 0, 255), "������ ".."["..traceRes.Entity:GetName().." || "..traceRes.Entity:SteamID().."]")
        --      surface.PlaySound(Language["sound_toggle"])
        end
end
concommand.Add(prefix.."_wadd", whp)
 
function print_whitelist()
        for k,v in pairs(Player_Whitelist) do
                print(v)
        end
end
concommand.Add(prefix.."_wshowlist", print_whitelist)
 
function update()
        if(file.Exists("aimbot_whitelist.txt", "DATA")) then
                Player_Whitelist = string.Explode(",",file.Read("aimbot_whitelist.txt"))
        else
                file.Write("aimbot_whitelist.txt", "")
        end
 
end
hook.Add("Think", "update", update)
local function GetHeadPos(ply)
         --   if IsValid(ply) then
                         local bname = aimmodels[ply:GetModel()]
             local BoneIndx = ply:LookupBone("ValveBiped.Bip01_Head1")
             local atach = ply:LookupAttachment("eyes")
                         
             if BoneIndx and !bname then
                local hp = ply:GetBonePosition( BoneIndx ) or ply:GetAttachment(atach)
                return hp      
             else
                hp = ply:EyePos()
                if hp != nil then
                        return hp
                    else
                        return ply:GetPos() + Vector(0, 0, 64)
                    end
             end
                         local bone = ply:LookupBone(bname)
                 if bone and !BoneIndx and !atach then
                        local pos, ang = ply:GetBonePosition(bone)
            return pos, ang            
                end
   --     end
        return hp
end
 
local AimbotOn = false
 
 
function Visible(ent)
        if IsValid(ent) then
                local tr = {}
                        tr.start = LocalPlayer():EyePos()
                        tr.endpos = ent:GetPos()
                        if ent:IsPlayer() or ent:IsNPC() then
                                tr.endpos = GetHeadPos(ent)
                        end
                        tr.mask = MASK_SHOT
                        tr.filter = LocalPlayer()
                local trace = util.TraceLine(tr)
 
                if trace.Entity == ent then
                        return true
                else
                        return false
                end
        else
                return false
        end
end
 
 local ABTarget
local ABAiming = false
function targai()
    ABTarget = nil
        local PossibleTargets = {}
 
        if PlayerTar:GetFloat() == 1 then
                for k, v in pairs(player.GetAll()) do
                        if IsValid(v) and v != LocalPlayer() then
                        if GetHeadPos(v):Distance(LocalPlayer():EyePos()) < Distance:GetFloat() then
                                        if Visible(v) then
                                                local valid = true
                                                if not v:Alive() then
                                                        valid = false
                                                end
                                                if  FriendTar:GetFloat() == 0 then
                                                        if v:GetFriendStatus() == "friend" or table.HasValue(Player_Whitelist, v:SteamID()) then
                                                                valid = false
                                                        end
                                                end
                                                if  TeamTar:GetFloat() == 1 then
                                                        if v:Team() == LocalPlayer():Team() then
                                                                valid = false
                                                        end
                                                end
                                                if valid then
                                                        table.insert(PossibleTargets, v)
                                        end
                                        end
                                end
                        end
                end
        end
 
        if NpcTar:GetFloat() == 1 then
                for k, v in pairs(ents.GetAll()) do
                        if IsValid(v) and v != LocalPlayer() then
                                if v:IsNPC() then
                                        if GetHeadPos(v):Distance(LocalPlayer():EyePos()) < Distance:GetFloat() then
                                                if Visible(v) then
                                                        table.insert(PossibleTargets, v)
                                                end
                                        end
                                end
                        end
                end
        end
 
        -- if NpcTar:GetFloat() == 1 then
                -- for k, v in pairs(ents.GetAll()) do
                        -- if ValidEntity(v) and v != LocalPlayer() then
                                -- if v:GetClass() == "prop_physics" then
                                        -- if v:GetPos():Distance(LocalPlayer():EyePos()) < Distance:GetFloat() then
                                                -- if Visible(v) then
                                                        -- table.insert(PossibleTargets, v)
                                                -- end
                                        -- end
                                -- end
                        -- end
                -- end
        -- end
 
        local BestTarget
        local NearTargets = {}
 
        for k, v in pairs(PossibleTargets) do
                if IsValid(v) then
                        local ang = (v:GetPos() - LocalPlayer():EyePos()):Angle()
                                if v:IsPlayer() or v:IsNPC() then
                                        ang = (GetHeadPos(v) - LocalPlayer():EyePos()):Angle()
                                end
                                math.NormalizeAngle(ang.p)
                        local eyeang = EyeAngles()
                                math.NormalizeAngle(eyeang.p)
                        local dist = eyeang:Forward():Distance(ang:Forward()) * 90
                        if dist <= AngleBot:GetFloat() then
                                table.insert(NearTargets, {ent = v, ang = dist})
                        end
                end
        end
   local tar
        table.SortByMember(NearTargets, "ang", function()
        tar = LocalPlayer()
        for k, v in pairs( player.GetAll() ) do
        local oP, tP = v:EyePos():ToScreen(), tar:EyePos():ToScreen()
        local a = math.Distance( ScrW() / 2, ScrH() / 2, oP.x, oP.y )
        local b = math.Distance( ScrW() / 2, ScrH() / 2, tP.x, tP.y )
            if ( b <= a ) then
               tar = v
            elseif ( tar == LocalPlayer() ) then
               tar = v
            end
                        return tar
                        end
        end)
         if #NearTargets <= 0 then return end                                  
        if NearTargets[1] != nil then
                BestTarget = NearTargets[1].ent
        end
 
        if IsValid(BestTarget) then
                ABTarget = BestTarget
        end
end
 
local AutoFireToggleMode = false
 
local function Think(gay)
if ( !aim ) then return end
        if IsValid(ABTarget) then
                if Visible(ABTarget) then
                        local pos = ABTarget:EyePos()
                        if ABTarget:IsPlayer() or ABTarget:IsNPC() then
                                pos = GetHeadPos(ABTarget)
                        end
 
                        if prediction:GetBool() then
                                pos = pos + (ABTarget:GetVelocity() * 0.02) - (LocalPlayer():GetVelocity() *0.05)
                        end
           
                        local ang = (pos - LocalPlayer():GetShootPos()):Angle()
                         ang.p = math.NormalizeAngle( ang.p )
        ang.y = math.NormalizeAngle( ang.y )
       ang.r = 0
                        --gay:SetViewAngles( ang )
                LocalPlayer():SetEyeAngles( ang )
                        ---LocalPlayer():SetAngles( ang )
 
                        if AutoFire:GetBool() then
                                if AutoFireToggleMode then
                                        RunConsoleCommand("-attack")
                                        AutoFireToggleMode = false
                                else
                                        RunConsoleCommand("+attack")
                                        AutoFireToggleMode = true
                                end
                        end
                else
                        if AutoFire:GetBool() then
                                RunConsoleCommand("-attack")
                                AutoFireToggleMode = false
                        end
                        targai()
                end
        else
                if AutoFire:GetBool() then
                        RunConsoleCommand("-attack")
                        AutoFireToggleMode = false
                end
                targai()
        end
end
hook.Add( "Tick","bot",Think)
--hook.Add("CreateMove","Thik",Think)
concommand.Add( "+"..prefix.."_aim",function()   aim = true AutoFireToggleMode = false end )
concommand.Add( "-"..prefix.."_aim", function() aim = false ABTarget = nil AutoFireToggleMode = false   RunConsoleCommand("-attack") end)



local tblFonts = { }
tblFonts["MenuLarge"] = {
    font = "Verdana",
    size = 17,
    weight = 600,
    antialias = true,
}
for k,v in SortedPairs( tblFonts ) do
    surface.CreateFont( k, tblFonts[k] )
end


hook.Add( "HUDPaint", "TeamSeen", function()   
for k,v in pairs ( player.GetAll() ) do
local Position = ( v:GetPos() + Vector( 0,0,80 ) ):ToScreen()
local Name = ""
local Team = ""
if v == LocalPlayer() then Name = ""  Team = "" else 
Name = v:Name() Team= tostring(v:Health())
end 
draw.DrawText( Name, "MenuLarge", Position.x, Position.y, team.GetColor(Color(255,0,0)), 1 )
-- draw.DrawText(Team, "MenuLarge", Position.x, Position.y+15, team.GetColor(v:Team()) , 1 )
end

end )