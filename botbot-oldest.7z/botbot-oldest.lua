--[[
	autorun/client/botBot_esp.lua
	-[LCG]-Marvincmarvin™
	===DStream===
]]

local util = util
local vgui = vgui
local table = table
local math = math
local string = string
local surface = surface
local draw = draw

local botBot = {}

botBot.targets = {}

botBot.enabled = CreateClientConVar( 'botBot_esp_enabled', 0, false, false)
botBot.tar_ply = CreateClientConVar( 'botBot_esp_targetplayers', 0, false, false)
botBot.tar_npc = CreateClientConVar( 'botBot_esp_targetnpcs', 0, false, false)
botBot.show_name = CreateClientConVar( 'botBot_esp_showname', 0, false, false)
botBot.show_health = CreateClientConVar( 'botBot_esp_showhealth', 0, false, false)
botBot.show_admin = CreateClientConVar( 'botBot_esp_showadmin', 0, false, false)
botBot.show_steam = CreateClientConVar( 'botBot_esp_showsteam', 0, false, false)
botBot.show_lines = CreateClientConVar( 'botBot_esp_showlines', 0, false, false)
botBot.show_bones = CreateClientConVar( 'botBot_esp_showbones', 0, false, false)

botBot.colors = {}

botBot.colors.blue = Color(0,160,255)
botBot.colors.green = Color(160,255,0)
botBot.colors.red = Color(250,50,50)
botBot.colors.grey = Color(150,150,150)
botBot.colors.darkgrey = Color(20,20,20)

function _R.Entity.HeadPos( self )
    if self:IsPlayer() then
        local hbone = self:LookupBone("ValveBiped.Bip01_Head1")
        return self:GetBonePosition(hbone)
	else return self:GetPos() end
end

function _R.Entity:GetBones()
    local ret = {}
    if self:IsPlayer() then
        ret = {   
				h = self:GetBonePosition( self:LookupBone('ValveBiped.Bip01_Head1') ):ToScreen(),
                p = self:GetBonePosition( self:LookupBone('ValveBiped.Bip01_Spine') ):ToScreen(),                                                        
                r_t = self:GetBonePosition( self:LookupBone('ValveBiped.Bip01_R_Thigh') ):ToScreen(), 
                r_c = self:GetBonePosition( self:LookupBone('ValveBiped.Bip01_R_Calf') ):ToScreen(), 
                r_f = self:GetBonePosition( self:LookupBone('ValveBiped.Bip01_R_Foot') ):ToScreen(),
                r_ua = self:GetBonePosition( self:LookupBone('ValveBiped.Bip01_R_UpperArm') ):ToScreen(), 
                r_fa = self:GetBonePosition( self:LookupBone('ValveBiped.Bip01_R_Forearm') ):ToScreen(),
                r_h = self:GetBonePosition( self:LookupBone('ValveBiped.Bip01_R_Hand') ):ToScreen(),                 
                l_t = self:GetBonePosition( self:LookupBone('ValveBiped.Bip01_L_Thigh') ):ToScreen(), 
                l_c = self:GetBonePosition( self:LookupBone('ValveBiped.Bip01_L_Calf') ):ToScreen(),
                l_f = self:GetBonePosition( self:LookupBone('ValveBiped.Bip01_L_Foot') ):ToScreen(),  
                l_ua = self:GetBonePosition( self:LookupBone('ValveBiped.Bip01_L_UpperArm') ):ToScreen(), 
                l_fa = self:GetBonePosition( self:LookupBone('ValveBiped.Bip01_L_Forearm') ):ToScreen(),
                l_h = self:GetBonePosition( self:LookupBone('ValveBiped.Bip01_L_Hand') ):ToScreen(),
                n = self:GetBonePosition( self:LookupBone('ValveBiped.Bip01_Neck1') ):ToScreen()
              }
    end
    return ret
end

function _R.Entity.GetVisible( self )
	local trace = {}
	if self:IsPlayer() then 
		trace = {start = LocalPlayer():GetShootPos(),endpos = self:HeadPos(),filter = {LocalPlayer(), self}} 
	elseif self:IsNPC() then
		trace = {start = LocalPlayer():GetShootPos(),endpos = self:LocalToWorld(self:OBBCenter()),filter = {LocalPlayer(), self}} 
	end
	local tr = util.TraceLine(trace)
	if tr.Fraction == 1 then
		return true
	else
		return false
	end    
end

local function GetTargets()
	botBot.targets = {}
	for _,ent in pairs( ents.GetAll() ) do
		if ( ent:IsPlayer() or ent:IsNPC() ) and ( ent!=LocalPlayer() ) then
			if botBot.tar_ply:GetInt()==1 and ent:IsPlayer() then
				table.insert( botBot.targets, ent )
			elseif botBot.tar_npc:GetInt()==1 and ent:IsNPC() then
				table.insert( botBot.targets, ent )
			end
		end
	end
end

local function DrawEsp()
	if botBot.enabled:GetInt() == 1 then
		for _,pl in pairs( botBot.targets ) do
			if pl:IsValid() then
							
				local pos = ( pl:GetPos() ):ToScreen()
				local drawcolor = Color(0,0,0)
				if pl:GetVisible() then drawcolor = botBot.colors.green else drawcolor = botBot.colors.red end
							
				if pl:IsPlayer() then
					local hpos = ( pl:HeadPos() ):ToScreen()
					local y = 0
										
					surface.SetDrawColor( botBot.colors.grey )
					surface.DrawOutlinedRect( hpos.x-2, hpos.y-2, 4, 4 )
												 										
					if botBot.show_health:GetInt()==1 then
						draw.RoundedBox( 0, pos.x-17, pos.y-4, 42, 6, botBot.colors.darkgrey)
						draw.RoundedBox( 0, pos.x-16, pos.y-3, 0.4*(pl:Health()), 4, drawcolor)
					end
										
					if botBot.show_name:GetInt()==1 then
						y = y + 10
						draw.SimpleText(pl:Nick(), 'BudgetLabel', pos.x, pos.y+y, drawcolor, 1, 1)
					end
										
					if botBot.show_admin:GetInt()==1 then
						y = y + 10
						local a_text = ''
						if pl:IsAdmin() or pl:IsSuperAdmin() then a_text = 'Admin = true' else a_text = 'Admin = false' end
						draw.SimpleText(a_text, 'BudgetLabel', pos.x, pos.y+y, drawcolor, 1, 1)
					end
										
					if botBot.show_steam:GetInt()==1 then
						y = y + 10
						draw.SimpleText(pl:SteamID(), 'BudgetLabel', pos.x, pos.y+y, drawcolor, 1, 1)
					end
										
					if botBot.show_bones:GetInt()==1 then
						local b = pl:GetBones()
						surface.SetDrawColor( drawcolor )
						surface.DrawLine(b.h.x, b.h.y, b.n.x, b.n.y)
						surface.DrawLine(b.n.x, b.n.y, b.p.x, b.p.y)
												
						surface.DrawLine(b.r_t.x, b.r_t.y, b.r_c.x, b.r_c.y)
						surface.DrawLine(b.p.x, b.p.y, b.r_t.x, b.r_t.y)
						surface.DrawLine(b.r_c.x, b.r_c.y, b.r_f.x, b.r_f.y)
												
						surface.DrawLine(b.n.x, b.n.y, b.r_ua.x, b.r_ua.y)
						surface.DrawLine(b.r_h.x, b.r_h.y, b.r_fa.x, b.r_fa.y)
						surface.DrawLine(b.r_fa.x, b.r_fa.y, b.r_ua.x, b.r_ua.y)
												
						surface.DrawLine(b.l_t.x, b.l_t.y, b.l_c.x, b.l_c.y)
						surface.DrawLine(b.p.x, b.p.y, b.l_t.x, b.l_t.y)
						surface.DrawLine(b.l_c.x, b.l_c.y, b.l_f.x, b.l_f.y)
												
						surface.DrawLine(b.n.x, b.n.y, b.l_ua.x, b.l_ua.y)
						surface.DrawLine(b.l_h.x, b.l_h.y, b.l_fa.x, b.l_fa.y)
						surface.DrawLine(b.l_fa.x, b.l_fa.y, b.l_ua.x, b.l_ua.y)                  
					end
												 
				elseif pl:IsNPC() then
					local pos = ( pl:GetPos() ):ToScreen()
					local y = 0
										
					if botBot.show_health:GetInt()==1 then
						draw.RoundedBox( 0, pos.x-17, pos.y-4, 42, 6, botBot.colors.darkgrey)
						draw.RoundedBox( 0, pos.x-16, pos.y-3, 0.4*(pl:Health()), 4, drawcolor)
					end
										
					if botBot.show_name:GetInt()==1 then
						y = y + 10
						draw.SimpleText(pl:GetClass(), 'BudgetLabel', pos.x, pos.y+y, drawcolor, 1, 1)
					end
					
				end
									
				if botBot.show_lines:GetInt()==1 then
						surface.SetDrawColor( drawcolor )
						surface.DrawLine( surface.ScreenWidth()/2, surface.ScreenHeight(), pos.x, pos.y )
				end
													
			end
		end
	end
end

hook.Add( 'HUDPaint', 'botBot_esp', DrawEsp )
hook.Add( 'Think', 'botBot_esp_target', GetTargets)
