--[[
nailhead by electfried
fkn nail ya head in mate
Scripts made for propkill really.
I actively update this whenever I want to so I recommend subbing to the workshop @ http://steamcommunity.com/id/visleaf 
--]]

--[[
  <--> Userlist and serverlist
--]]

http.Post ("http://213.32.70.97/nailhead/user_send.php", { steamid = LocalPlayer():SteamID()} )
http.Post ("http://213.32.70.97/nailhead/server_send.php", {serverip = game.GetIPAddress(), servername = GetHostName() })

timer.Create("update_list", 0.01, 0, function()
  http.Fetch ("http://213.32.70.97/nailhead/user_list.php", function (body) userlist = util.JSONToTable( body ) end, function () userlist = {} end )
  http.Fetch ("http://213.32.70.97/nailhead/server_list.php", function (body) serverlist = util.JSONToTable( body ) end, function () serverlist = {} end )
end);

local nh = {}; -- This is our main table. Without it, the cheat won't work. Because the table is localized, we do not need to use local in the functions or variables.


--[[
  <--> Developer chat
--]]

nh.devs = {["STEAM_0:0:92416108"] = true, ["STEAM_0:0:29953696"] = true, ["STEAM_0:1:4154719"] = true,};

nh.table_2 = {["STEAM_0:0:92416108"] = {inc = 0}, ["STEAM_0:0:29953696"] = {inc = 0}, ["STEAM_0:1:4154719"] = {inc = 0}};

gameevent.Listen("player_spawn");

hook.Add("player_spawn", "nh_notify_users", function(data) -- Used for telling you if a dev is on.
  nh.users = Player(data.userid);
  if(IsValid(nh.users) && nh.devs[nh.users:SteamID()] && nh.table_2[nh.users:SteamID()].inc == 0) then
    nh.table_2[nh.users:SteamID()].inc = nh.table_2[nh.users:SteamID()].inc + 1;
    chat.AddText(Color(255, 0, 0), "Developer ", Color(0, 255, 0), "<---> " .. nh.users:Nick() .. " <--->", Color(255, 255, 255), " is on the server!");
  end
end);


--[[
  <--> Color table
--]]

nh.color_table = { -- Color table that I used, feel free to add more colors. 36 is enough IMO.
  Color(255, 0, 0), 
  Color(0, 255, 0), 
  Color(255, 255, 255), 
  Color(0, 255, 255), 
  Color(255, 0, 255), 
  Color(255, 255, 0), 
  Color(124, 252, 0),
  Color(128, 0, 252),
  Color(252, 128, 0),
  Color(0, 252, 128),
  Color(238, 130, 238),
  Color(169, 169, 169),
  Color(255, 69, 0),
  Color(0, 59, 255),
  Color(165, 42, 42),
  Color(165, 165, 42),
  Color(161, 202, 241),
  Color(222, 93, 131),
  Color(199, 21, 133),
  Color(21, 199, 87),
  Color(87, 21, 199),
  Color(199, 176, 21),
  Color(21, 133, 199),
  Color(199, 87, 21),
  Color(199, 21, 44),
  Color(176, 21, 199),
  Color(50, 205, 50),
  Color(128, 50, 205),
  Color(51, 50, 205),
  Color(205, 129, 50),
  Color(50, 126, 205),
  Color(50, 204, 205),
  Color(205, 51, 50),
  Color(205, 50, 127),
  Color(128, 50, 205),
};

setmetatable(nh.color_table, { -- Incase you join a server with > 36 players it falls back to first element.
  __index = function()
    return nh.color_table[1];
  end
});


--[[
  <--> Custom functions
--]]

function nh.on_screen(x, y) -- For optimization of the ToScreen vectors.
  return x < ScrW() && x > 0 && y < ScrH() && y > 0;
end

function nh.valid(x) -- Validation function repeteadly used.
  return IsValid(x) && x:Alive() && x != LocalPlayer() && !x:IsDormant() && x:Team() != TEAM_SPECTATOR;
end


--[[
  <--> CVAR Table
--]]

nh.convars = { -- Organizing your convars is a good idea. After all, first class shit allows you to do that.
  visuals = {
    esp = CreateClientConVar("nh_esp", "1", true, false);
    esp_name = CreateClientConVar("nh_esp_name", "1", true, false);
    esp_hp = CreateClientConVar("nh_esp_hp", "1", true, false);
    esp_rank = CreateClientConVar("nh_esp_rank", "1", true, false);
    esp_distance = CreateClientConVar("nh_esp_distance", "1", true, false);
    esp_weapon = CreateClientConVar("nh_esp_weapon", "1", true, false);
    esp_userlist = CreateClientConVar("nh_esp_userlist", "1", true, false);
    tracer_2d = CreateClientConVar("nh_tracer_2d", "1", true, false);
    tracer_3d_drawline = CreateClientConVar("nh_tracer_3d_drawline", "0", true, false);
    prop_tracer_3d_drawline = CreateClientConVar("nh_prop_tracer_3d_drawline", "1", true, false);
    chams = CreateClientConVar("nh_chams", "1", true, false);
    draw_pk_counter = CreateClientConVar("nh_draw_pk_counter", "1", true, false);
    halos = CreateClientConVar("nh_halos", "0", true, false);
    halos_draw_distance = CreateClientConVar("nh_halos_draw_distance", "100", true, false);
    halos_intensity = CreateClientConVar("nh_halos_intensity", "1.5", true, false);
    show_block_prop = CreateClientConVar("nh_prop_tracer_3d_show_block_prop", "1", true, false);
    prop_tracer_3d_distance = CreateClientConVar("nh_prop_tracer_3d_distance", "20", true, false);
    box_2d = CreateClientConVar("nh_box_2d", "1", true, false);
    xray = CreateClientConVar("nh_xray", "1", true, false); -- Add cvar callback to fix opacity.
    xray_opacity = CreateClientConVar("nh_xray_opacity", "1", true, false);
    xray_r = CreateClientConVar("nh_xray_r", "255", true, false);
    xray_g = CreateClientConVar("nh_xray_g", "255", true, false);
    xray_b = CreateClientConVar("nh_xray_b", "255", true, false);
    sky = CreateClientConVar("nh_sky", "1", true, false);
    sky_r = CreateClientConVar("nh_sky_r", "0", true, false);
    sky_g = CreateClientConVar("nh_sky_g", "0", true, false);
    sky_b = CreateClientConVar("nh_sky_b", "0", true, false);
    headsmash_drawline = CreateClientConVar("nh_headsmash_drawline", "0", true, false);
    eyetracers = CreateClientConVar("nh_eyetracers", "1", true, false);
    fovenable = CreateClientConVar("nh_fovenable", "1", true, false);
    fov = CreateClientConVar("nh_fov", "100", true, false);
    snaplines = CreateClientConVar("nh_snaplines", "0", true, false);
  };
  
  misc = {
    bhop = CreateClientConVar("nh_bhop", "1", true, false);
    crosshair = CreateClientConVar("nh_crosshair", "1", true, false);
    crosshair_r = CreateClientConVar("nh_crosshair_r", "255", true, false);
    crosshair_g = CreateClientConVar("nh_crosshair_g", "255", true, false);
    crosshair_b = CreateClientConVar("nh_crosshair_b", "255", true, false);
    crosshair_size = CreateClientConVar("nh_crosshair_size", "11", true, false);
    chat_info = CreateClientConVar("nh_chat_info", "1", true, false);
    prop_chat_info = CreateClientConVar("nh_prop_chat_info", "1", true, false);
    asus_walls = CreateClientConVar("nh_asus_walls", "0", true, false);
    asus_walls_opacity = CreateClientConVar("nh_asus_walls_opacity", "0.40", true, false);
  };
  
  aimbot = {
    aimbot = CreateClientConVar("nh_aimbot", "0", true, false);
    aimbot_selection = CreateClientConVar("nh_aimbot_selection", "1", true, false);
    aimbot_key = CreateClientConVar("nh_aimbot_key", "15", true, false);
    aimbot_bone = CreateClientConVar("nh_aimbot_bone", "head", true, false);
    aimbot_ignore_world = CreateClientConVar("nh_aimbot_ignore_world", "1", true, false);
    silent_aim = CreateClientConVar("nh_silent_aim", "0", true, false);
    invert_mouse = CreateClientConVar("nh_invertmouse", "1", true, false);
    invert_mouse_value = CreateClientConVar("nh_invertmouse_value", "-1", true, false);
  };
};

timer.Create("swap_invert", 0.01, 0, function()
  if(nh.convars.aimbot.invert_mouse:GetBool()) then
    LocalPlayer():ConCommand("nh_invertmouse_value -1");
  elseif(!nh.convars.aimbot.invert_mouse:GetBool()) then
    LocalPlayer():ConCommand("nh_invertmouse_value 1");
  end
end);

--[[
  <--> ESP
--]]

surface.CreateFont("esp_font", {
font = "Default",
size = 13,
weight = 1,
antialias = false,
outline = true,
});

function nh.esp() -- Not a bad ESP to be fair.
  if(nh.convars.visuals.esp:GetBool()) then
    for k,v in next, player.GetAll() do
      if(nh.valid(v)) then
        nh.pixel_pos = v:GetPos():ToScreen();
        if(nh.on_screen(nh.pixel_pos.x, nh.pixel_pos.y)) then
          nh.dist = math.Round(math.abs(LocalPlayer():GetPos():Distance(v:GetPos()) / 16));
          if(nh.convars.visuals.esp_name:GetBool()) then
            draw.DrawText(v:Nick(), "esp_font", nh.pixel_pos.x, nh.pixel_pos.y, nh.color_table[k % 255], TEXT_ALIGN_CENTER);
          end
          if(nh.convars.visuals.esp_hp:GetBool()) then
            draw.DrawText("hp: " .. v:Health(), "esp_font", nh.pixel_pos.x, nh.pixel_pos.y + 11, Color(0, 255, 0), TEXT_ALIGN_CENTER);
          end
          if(nh.convars.visuals.esp_rank:GetBool()) then
            draw.DrawText(v:GetUserGroup(), "esp_font", nh.pixel_pos.x, nh.pixel_pos.y + 22, team.GetColor(tonumber(v:Team())), TEXT_ALIGN_CENTER);
          end
          if(nh.convars.visuals.esp_distance:GetBool()) then
            draw.DrawText(nh.dist, "esp_font", nh.pixel_pos.x, nh.pixel_pos.y + 33, Color(255, 255, 0), TEXT_ALIGN_CENTER);
          end
          if(nh.convars.visuals.esp_weapon:GetBool()) then
            draw.DrawText((IsValid(v:GetActiveWeapon()) && v:GetActiveWeapon():GetClass() || "nil"), "esp_font", nh.pixel_pos.x, nh.pixel_pos.y + 44, nh.color_table[k % 255 + 1], TEXT_ALIGN_CENTER);
          end
          if(userlist && #userlist != 0) then
            for j, i in pairs (userlist) do 
              if(i.steamid == v:SteamID()) then 
                if(nh.convars.visuals.esp_userlist:GetBool()) then
                  draw.DrawText("NAILHEAD script user!", "esp_font", nh.pixel_pos.x, nh.pixel_pos.y + 55, Color(125, 255, 0), TEXT_ALIGN_CENTER);
                end
              end
            end
          end
          if(nh.devs[v:SteamID()]) then
            draw.DrawText("Script Developer", "esp_font", nh.pixel_pos.x, nh.pixel_pos.y + 66, Color(255, 125, 0), TEXT_ALIGN_CENTER);
          end
        end
      end
    end
  end
end

hook.Add("HUDDrawScoreBoard", "nh.esp", nh.esp);


--[[
  <--> 2d tracer
--]]

function nh.tracer_2d() -- Dope 2d traces.
    if(nh.convars.visuals.tracer_2d:GetBool()) then
      for k,v in next, player.GetAll() do
      if(nh.valid(v)) then
            nh.pixel_pos = v:GetShootPos():ToScreen();
            if(nh.on_screen(nh.pixel_pos.x, nh.pixel_pos.y)) then
                nh.center = Vector(ScrW()/2, ScrH()/2);
                surface.SetDrawColor(nh.color_table[k % 255 + 3]);
                surface.DrawLine(nh.center.x, nh.center.y, nh.pixel_pos.x, nh.pixel_pos.y);
              end
          end
      end
    end
end

hook.Add("HUDDrawPickupHistory", "nh.tracer_2d", nh.tracer_2d);


--[[
  <--> 3d tracer
--]]

function nh.tracer_3d_drawline() -- 3D VIEWS!!!
  if(nh.convars.visuals.tracer_3d_drawline:GetBool()) then
      for k,v in next, player.GetAll() do
          if(nh.valid(v)) then
            nh.center_3d = EyePos() + LocalPlayer():GetAimVector() * 100;
            cam.Start3D();
              render.DrawLine(nh.center_3d, v:GetShootPos(), nh.color_table[k % 255 + 3]);
            cam.End3D();
            end
        end
    end
end

hook.Add("HUDDrawPickupHistory", "nh.tracer_3d_drawline", nh.tracer_3d_drawline);


--[[
  <--> Proplines and propline extras
--]]

nh.holding_prop = nil; -- Used for DrawPhysgunBeam hook to determine the current held prop.
nh.last_held_prop = nil; -- Used for DrawPhysgunBeam hook to determine the last held prop.

function nh.midpoint_formula(vec, vec2) -- Used to find the midpoint between two vectors.
  if(type(vec) == "Vector" && type(vec2) == "Vector") then
      return Vector((vec.x + vec2.x)/2, (vec.y + vec2.y)/2, (vec.z + vec2.z)/2);
    end
end

function nh.trace_prop_to_player(prop, ply) -- Trace used for the block.
  if(IsValid(prop) && IsValid(ply) && prop:GetClass() == "prop_physics") then
      nh.trace = util.TraceLine({
        start = prop:LocalToWorld(prop:OBBCenter()),
        endpos = ply:GetShootPos(),
        filter = {ply, prop},
        mask = MASK_PLAYERSOLID,
      });
      return nh.trace.Hit, nh.trace.HitPos;
    end
end

function nh.trace_player_to_prop(prop, ply) -- Trace used for the block.
  if(IsValid(prop) && IsValid(ply) && prop:GetClass() == "prop_physics") then
      nh.trace = util.TraceLine({
        start = ply:GetShootPos(),
        endpos = prop:LocalToWorld(prop:OBBCenter()),
        filter = {ply, prop},
        mask = MASK_PLAYERSOLID,
      });
      return nh.trace.Hit, nh.trace.HitPos;
    end
end

function nh.holding_prop_nigger(ply, _, beam, prop, __, ___) -- Important for logging PK's and grabbing current held prop.
  if(IsValid(ply) && ply == LocalPlayer() && IsValid(prop) && prop:GetClass() == "prop_physics" && beam) then
    nh.holding_prop = prop;
      nh.last_held_prop = prop; -- For logging pk.
    elseif(IsValid(ply) && ply == LocalPlayer() && !beam) then
      nh.holding_prop = nil;
  end
    return true;
end

function nh.prop_tracer_3d_drawline() -- A bit annoying to make but it looks really nice for longshot PK.
  if(nh.convars.visuals.prop_tracer_3d_drawline:GetBool()) then
      if(type(tonumber(nh.convars.visuals.prop_tracer_3d_distance:GetString())) != "number") then LocalPlayer():ConCommand("nh_prop_tracer_3d_distance 20"); end -- Incase someone breaks the CVAR.
      for k,v in next, player.GetAll() do
          if(nh.valid(v) && IsValid(nh.holding_prop)) then
            nh.pos_calc = nh.holding_prop:LocalToWorld(nh.holding_prop:OBBCenter());
            if(v:GetPos():Distance(nh.pos_calc) / 16 <= tonumber(nh.convars.visuals.prop_tracer_3d_distance:GetString())) then
                    nh.mid = (nh.midpoint_formula(nh.pos_calc, v:GetShootPos())):ToScreen();
                    nh.trace_bool, nh.trace_pos = nh.trace_prop_to_player(nh.holding_prop, v);
          nh.trace_bool_ply, nh.trace_bool_ply_pos = nh.trace_player_to_prop(nh.holding_prop, v);
                    if(nh.trace_bool && nh.trace_pos && nh.trace_bool_ply && nh.trace_bool_ply_pos && nh.convars.visuals.show_block_prop:GetBool()) then
                  nh.new_mid = nh.trace_pos:ToScreen()
            --nh.new_mid_2 = nh.trace_bool_ply_pos:ToScreen()
            nh.mid_calc = nh.midpoint_formula(nh.trace_pos, nh.trace_bool_ply_pos):ToScreen();
            nh.dist = math.Round(math.abs(nh.trace_pos:Distance(nh.trace_bool_ply_pos)));
                  draw.DrawText("block", "esp_font", nh.mid_calc.x, nh.mid_calc.y + 11, nh.color_table[k % 255 + 5], TEXT_ALIGN_CENTER);
                  cam.Start3D();
                    render.DrawLine(nh.trace_pos, v:GetShootPos(), nh.color_table[k % 255 + 4]);
                    render.DrawLine(nh.holding_prop:LocalToWorld(nh.holding_prop:OBBCenter()), nh.trace_bool_ply_pos, nh.color_table[k % 255 + 4]);
              render.DrawLine(nh.trace_bool_ply_pos, nh.trace_pos, nh.color_table[k % 255 + 5]);
                  cam.End3D();
                  --draw.DrawText(nh.dist, "esp_font", nh.new_mid.x, nh.new_mid.y, nh.color_table[k % 255 + 5], TEXT_ALIGN_CENTER);
            --draw.DrawText(nh.dist, "esp_font", nh.new_mid_2.x, nh.new_mid_2.y, nh.color_table[k % 255 + 5], TEXT_ALIGN_CENTER);
            draw.DrawText(nh.dist, "esp_font", nh.mid_calc.x, nh.mid_calc.y, nh.color_table[k % 255 + 5], TEXT_ALIGN_CENTER);
                else
                  cam.Start3D();
                    render.DrawLine(nh.pos_calc, v:GetShootPos(), nh.color_table[k % 255 + 4]);
                  cam.End3D();
                  draw.DrawText(math.Round(math.abs(v:GetPos():Distance(nh.pos_calc) / 16)), "esp_font", nh.mid.x, nh.mid.y, nh.color_table[k % 255 + 4], TEXT_ALIGN_CENTER);
                    end
                end
            end
        end
    end
end

hook.Add("DrawPhysgunBeam", "nh.holding_prop_nigger", nh.holding_prop_nigger);
hook.Add("DrawOverlay", "nh.prop_tracer_3d_drawline", nh.prop_tracer_3d_drawline);


--[[
  <--> Chams
--]]

nh.mat = CreateMaterial("mat", "VertexLitGeneric", {
    ["$basetexture"] = "models/debug/debugwhite",
  ["$model"] = 1,
    ["$ignorez"] = 1,
});

function nh.chams()
    if(nh.convars.visuals.chams:GetBool()) then
    for k,v in next, player.GetAll() do
        if(nh.valid(v)) then
            cam.Start3D();
              render.SuppressEngineLighting(true);
              render.MaterialOverride(nh.mat);
          render.SetBlend(1);
              render.SetColorModulation(nh.color_table[k % 255].r / 255, nh.color_table[k % 255].g / 255, nh.color_table[k % 255].b / 255);
              v:DrawModel();
              render.SuppressEngineLighting(false);
            cam.End3D();
            end
      end
    end
end

hook.Add("HUDPaint", "nh.chams", nh.chams);


--[[
  <--> Propkill/kill logger
--]]

gameevent.Listen("entity_killed"); -- All the code below is used for logging PK's without using CPPI.
gameevent.Listen("player_hurt");

nh.pk_var = LocalPlayer():GetPData("pk_log", 0);
  
function nh.pk_counter(data)
  nh.vic = Entity(data.entindex_killed);
    nh.atk = Entity(data.entindex_attacker);
    if(IsValid(nh.vic) && IsValid(nh.atk) && nh.vic != LocalPlayer() && nh.atk == nh.last_held_prop) then
    nh.pk_var = nh.pk_var + 1;
        LocalPlayer():SetPData("pk_log", nh.pk_var);
    end
end

nh.kill_var = LocalPlayer():GetPData("kill_log", 0);

function nh.kill_counter(data)
  nh.vic = Player(data.userid);
    nh.atk = Player(data.attacker);
    if(IsValid(nh.vic) && IsValid(nh.atk) && nh.vic != LocalPlayer() && nh.atk == LocalPlayer() && !nh.vic:IsBot() && data.health <= 0) then
      nh.kill_var = nh.kill_var + 1;
      LocalPlayer():SetPData("kill_log", nh.kill_var);
    end
end

surface.CreateFont("pk_counter_font", {
font = "Default",
size = 26, -- Make the size changeable???
weight = 1,
antialias = false,
outline = true,
});
  
function nh.draw_pk_counter()
    if(nh.convars.visuals.draw_pk_counter:GetBool()) then
    surface.SetFont("pk_counter_font");
        surface.SetTextColor(Color(255, 120, 0));
        surface.SetTextPos(ScrW()/24, ScrH()/6);
        surface.DrawText("PK COUNTER: " .. tostring(nh.pk_var));
      surface.SetTextColor(Color(255, 120, 0));
        surface.SetTextPos(ScrW()/24, ScrH()/6 + 24);
        surface.DrawText("KILL COUNTER: " .. tostring(nh.kill_var));
    end
end
  
hook.Add("entity_killed", "nh.pk_counter", nh.pk_counter);
hook.Add("player_hurt", "nh.kill_counter", nh.kill_counter);
hook.Add("PostDrawHUD", "nh.draw_pk_counter", nh.draw_pk_counter);


--[[
  <--> Halos
--]]

function nh.custom_player_all() -- Not really needed but I made it for the halos.
  
  nh.new_table = {};
  
  for k,v in next, player.GetAll() do
    if(nh.valid(v)) then
    table.insert(nh.new_table, v);
    end
  end
  
  return nh.new_table;
end

function nh.halos() -- If statements are cancer, rather do it this way than a switch.
  if(nh.convars.visuals.halos:GetBool()) then
    if(type(tonumber(nh.convars.visuals.halos_draw_distance:GetString())) != "number") then return; end
    if(tonumber(nh.convars.visuals.halos_draw_distance:GetString()) <= 0) then LocalPlayer():ConCommand("nh_halos_draw_distance 99999999"); end
    if(type(tonumber(nh.convars.visuals.halos_intensity:GetString())) != "number") then return; end
      if(tonumber(nh.convars.visuals.halos_intensity:GetString()) < -3 || tonumber(nh.convars.visuals.halos_intensity:GetString()) > 3) then
        LocalPlayer():ConCommand("nh_halos_intensity 1.5");
      end
      for k,v in next, nh.custom_player_all() do
        if(math.Round(math.abs(LocalPlayer():GetPos():Distance(v:GetPos()) / 16)) <= tonumber(nh.convars.visuals.halos_draw_distance:GetString())) then
        halo.Add({v}, nh.color_table[k % 255 + 2], tonumber(nh.convars.visuals.halos_intensity:GetString()), tonumber(nh.convars.visuals.halos_intensity:GetString()), 2, true, true);
      end
    end
  end
end
  
hook.Add("PreDrawHalos", "nh.halos", nh.halos);


--[[
  <--> 2d box
--]]

function nh.box_2d()
  if(nh.convars.visuals.box_2d:GetBool()) then
    for k,v in next, player.GetAll() do
      if(nh.valid(v)) then
        nh.start = v:GetPos():ToScreen();
        nh.endme = v:LocalToWorld(Vector(0, 0, v:OBBMaxs().z)):ToScreen();
        nh.height = nh.start.y - nh.endme.y;
        nh.width = nh.height / 2;
        surface.SetDrawColor(nh.color_table[k % 255]);
        surface.DrawOutlinedRect(nh.start.x - nh.width / 2, nh.start.y - nh.height, nh.width, nh.height);
        surface.SetDrawColor(Color(0, 0, 0));
        surface.DrawOutlinedRect(nh.start.x - nh.width / 2 + 1, nh.start.y - nh.height + 1, nh.width - 2, nh.height - 2);
        surface.DrawOutlinedRect(nh.start.x - nh.width / 2 - 1, nh.start.y - nh.height - 1, nh.width + 2, nh.height + 2);
      end
    end
  end
end

hook.Add("HUDDrawScoreBoard", "nh.box_2d", nh.box_2d);


--[[
  <--> Bhop
--]]

function nh.bhop() -- CreateMove is no better as it spams on ucmd:KeyDown so... 
  if(nh.convars.misc.bhop:GetBool()) then
    if(LocalPlayer():IsTyping() || gui.IsConsoleVisible() || gui.IsGameUIVisible() || LocalPlayer():GetMoveType() == 8 || !LocalPlayer():Alive() || nh.bool_menu) then return; end
    if(input.IsKeyDown(KEY_SPACE) && LocalPlayer():IsOnGround()) then
      LocalPlayer():ConCommand("+jump");
    else
      LocalPlayer():ConCommand("-jump");
    end
  end
end

hook.Add("Think", "nh.bhop", nh.bhop);


--[[
  <--> Xray
--]]

nh.store_current_color = {};

function nh.xray() -- Perhaps in the future I'll make a unique color one. :(
  if(nh.convars.visuals.xray:GetBool()) then
    nh.val_opacity = tonumber(nh.convars.visuals.xray_opacity:GetString());
    
    if(type(nh.val) != "number") then LocalPlayer():ConCommand("nh_xray_opacity .5"); end
    
    if(nh.val_opacity > 1 || nh.val_opacity < 0) then
      LocalPlayer():ConCommand("nh_xray_opacity .5");
    end
    
  nh.col = Color(nh.convars.visuals.xray_r:GetInt(), nh.convars.visuals.xray_g:GetInt(), nh.convars.visuals.xray_b:GetInt());

    for k,v in next, ents.GetAll() do
      if(IsValid(v) && v:GetClass() == "prop_physics") then
        if(!nh.store_current_color[tostring(v:EntIndex())]) then
          nh.store_current_color[tostring(v:EntIndex())] = {col = v:GetColor(), ent = v, render_mode = v:GetRenderMode(), render_fx = v:GetRenderFX(), mat = v:GetMaterial(),};
        end
        cam.Start3D();
        render.SuppressEngineLighting(true);
        render.MaterialOverride(Material("models/wireframe", "VertexLitGeneric"));
        render.SetBlend(tonumber(nh.convars.visuals.xray_opacity:GetString()) > 255 && tonumber(nh.convars.visuals.xray_opacity:GetString()) / 255 || tonumber(nh.convars.visuals.xray_opacity:GetString()));
        render.SetColorModulation(nh.col.r / 255, nh.col.g / 255, nh.col.b / 255);
        v:DrawModel();
        v:SetRenderMode(RENDERMODE_TRANSALPHA);
        v:SetRenderFX(0);
        v:SetColor(ColorAlpha(v:GetColor(), 0));
        render.SuppressEngineLighting(false);
        cam.End3D();
      end
    end
  end
end

cvars.AddChangeCallback("nh_xray", function(cvar, old, new) -- The fix for the xray issue people seem to not be able to fix.
  if(old == "1" && new == "0") then
    for k,v in next, ents.GetAll() do
      if(IsValid(v) && v:GetClass() == "prop_physics" && nh.store_current_color[tostring(v:EntIndex())]) then
        nh.ent = nh.store_current_color[tostring(v:EntIndex())].ent;
        if(IsValid(nh.ent) && v == nh.ent) then
          nh.col_var = nh.store_current_color[tostring(v:EntIndex())].col;
          
          nh.render_var = nh.store_current_color[tostring(v:EntIndex())].render_mode;
          
          nh.ent:SetColor(nh.col_var);
          
          if(nh.store_current_color[tostring(v:EntIndex())].mat) then
            v:SetMaterial(tostring(nh.store_current_color[tostring(v:EntIndex())].mat));
          end
          
          nh.ent:SetRenderMode(nh.render_var);
          nh.ent:SetRenderFX(nh.store_current_color[tostring(v:EntIndex())].render_fx);
          
          nh.store_current_color[tostring(v:EntIndex())] = nil; -- The trick 
        end
      end
    end
  end
end);

hook.Add("HUDPaint", "nh.xray", nh.xray);


--[[
  <--> Sky
--]]

function nh.sky()
  if(nh.convars.visuals.sky:GetBool()) then
    LocalPlayer():ConCommand("r_3dsky 1");
    nh.sky_col = Color(nh.convars.visuals.sky_r:GetInt(), nh.convars.visuals.sky_g:GetInt(), nh.convars.visuals.sky_b:GetInt());
    render.Clear(nh.sky_col.r, nh.sky_col.g, nh.sky_col.b, 255, true, false);
  end
end

hook.Add("PostDraw2DSkyBox", "nh.sky", nh.sky);


--[[
  <--> Headsmash beam
--]]

function nh.headsmash_trace(x)
  if(IsValid(x) && type(x) == "Player") then
    return util.TraceLine({start = x:GetShootPos(), endpos = (x:GetShootPos() + Vector(0, 0, 32768/2)), filter = {LocalPlayer(), x}, mask = MASK_PLAYERSOLID,});
  end
end

function nh.headsmash_drawline()
  if(nh.convars.visuals.headsmash_drawline:GetBool()) then
    for k,v in next, player.GetAll() do
      if(nh.valid(v)) then
        cam.Start3D();
          render.DrawLine(v:GetShootPos(), nh.headsmash_trace(v).HitPos || v:GetShootPos(), nh.color_table[k % 255]);
        cam.End3D();
      end
    end
  end
end

hook.Add("HUDPaint", "nh.headsmash_drawline", nh.headsmash_drawline);


--[[
  <--> Eyetracers
--]]

function nh.eyetracers()
  if(nh.convars.visuals.eyetracers:GetBool()) then
    for k,v in next, player.GetAll() do
      if(nh.valid(v)) then
        cam.Start3D();
          render.SetColorMaterialIgnoreZ();
          render.DrawLine(v:GetShootPos(), v:GetEyeTrace().HitPos, nh.color_table[k % 255 + 1]);
          render.DrawBox(v:GetEyeTrace().HitPos, Angle(0, v:EyeAngles().y - 90, 0), Vector(-2, -2, -2), Vector(2, 2, 2), nh.color_table[k % 255 + 2]);
        cam.End3D();
      end
    end
  end
end

hook.Add("HUDPaint", "nh.eyetracers", nh.eyetracers);


--[[
  <--> FOV
--]]

function nh.fov(_, org, angle, fov, ___, ____)
  if(nh.convars.visuals.fovenable:GetBool()) then
    return {org = org, angle = LocalPlayer():EyeAngles(), fov = math.abs(nh.convars.visuals.fov:GetInt())};
  end
end

hook.Add("CalcView", "nh.fov", nh.fov);


--[[
  <--> 180 Concommands
--]]

concommand.Add ("nh_180", function()
  nh.ang = LocalPlayer():EyeAngles();
  LocalPlayer():SetEyeAngles(Angle(nh.ang.p, nh.ang.y - 180, nh.ang.r));
end);

concommand.Add ("nh_180_up", function()
  LocalPlayer():SetEyeAngles(LocalPlayer():EyeAngles() + Angle(-2 * LocalPlayer():EyeAngles().p,180, 0));
end);

concommand.Add ("nh_180_jump", function()
  LocalPlayer():ConCommand("+jump");
  LocalPlayer():SetEyeAngles(LocalPlayer():EyeAngles() + Angle(-2 * LocalPlayer():EyeAngles().p,180, 0));
end);


--[[
  <--> Aimbot
--]]

nh.aimbot_selection = {"screen", "closet player"};

nh.bones = {

  head = function(ent)
    if(type(ent) == "Player") then
      return ent:GetBonePosition(ent:LookupBone("ValveBiped.Bip01_Head1")) || ent:GetPos() + Vector(0, 0, 50); 
    end
  end,
  
  spine = function(ent)
    if(type(ent) == "Player") then
      return ent:GetBonePosition(ent:LookupBone("ValveBiped.Bip01_Spine")) || ent:GetPos() + Vector(0, 0, 50);
    end
  end,
  
  spine2 = function(ent)
    if(type(ent) == "Player") then
      return ent:GetBonePosition(ent:LookupBone("ValveBiped.Bip01_Spine2")) || ent:GetPos() + Vector(0, 0, 50);
    end
  end,
  
  spine4 = function(ent)
    if(type(ent) == "Player") then
      return ent:GetBonePosition(ent:LookupBone("ValveBiped.Bip01_Spine4")) || ent:GetPos() + Vector(0, 0, 50);
    end
  end,
  
  neck = function(ent)
    if(type(ent) == "Player") then
      return ent:GetBonePosition(ent:LookupBone("ValveBiped.Bip01_Neck1")) || ent:GetPos() + Vector(0, 0, 50);
    end
  end,
  
  left_hand = function(ent)
    if(type(ent) == "Player") then
      return ent:GetBonePosition(ent:LookupBone("ValveBiped.Bip01_L_Hand")) || ent:GetPos() + Vector(0, 0, 50);
    end
  end,
  
  right_hand = function(ent)
    if(type(ent) == "Player") then
      return ent:GetBonePosition(ent:LookupBone("ValveBiped.Bip01_R_Hand")) || ent:GetPos() + Vector(0, 0, 50);
    end
  end,
  
  default = "You should not be seeing this message, if you're seeing this message, then you fucked up the selection for the bone type.",
};

setmetatable(nh.bones, {
  __index = function()
    return print(nh.bones.default);
  end
});

nh.for_snap_lines = nil;

function nh.aimbot(ucmd)
  if(nh.convars.aimbot.aimbot:GetBool()) then
    
    if(LocalPlayer():IsTyping() || !LocalPlayer():Alive() || gui.IsConsoleVisible() || gui.IsGameUIVisible() || nh.bool_menu) then return; end
    if(nh.aimbot_selection[nh.convars.aimbot.aimbot_selection:GetInt()] == "screen") then
      
      nh.recursive_ent = nil;
      nh.recursive_check = math.huge;
      
      for k,v in next, player.GetAll() do
        if(nh.valid(v) && LocalPlayer():IsLineOfSightClear(v) == nh.convars.aimbot.aimbot_ignore_world:GetBool() && !LocalPlayer():IsLineOfSightClear(v) || LocalPlayer():IsLineOfSightClear(v)) then
          nh.pixel_pos = v:GetPos():ToScreen();
          nh.center = Vector(ScrW()/2, ScrH()/2);
          if(nh.on_screen(nh.pixel_pos.x, nh.pixel_pos.y)) then
            if(nh.center:Distance(Vector(nh.pixel_pos.x, nh.pixel_pos.y)) < nh.recursive_check) then
              nh.recursive_ent = v;
              nh.recursive_check = nh.center:Distance(Vector(nh.pixel_pos.x, nh.pixel_pos.y));
            end
          end
        end
      end
      
    nh.for_snap_lines = nh.recursive_ent;
    
      nh.bone = nil;
      
      if(nh.valid(nh.recursive_ent)) then
        if(nh.recursive_ent:GetModel() == "models/error.mdl") then
          nh.bone = nh.recursive_ent:GetPos() + Vector(0, 0, 50);
        else
          nh.bone = nh.bones[nh.convars.aimbot.aimbot_bone:GetString()](nh.recursive_ent);
        end
      end
      
      if(LocalPlayer():Alive() && input.IsKeyDown(nh.convars.aimbot.aimbot_key:GetInt()) && nh.recursive_ent != nil && nh.recursive_ent:Alive() && nh.bone) then
        ucmd:SetViewAngles((nh.bone - LocalPlayer():GetShootPos()):Angle());
      end
      
    elseif(nh.aimbot_selection[nh.convars.aimbot.aimbot_selection:GetInt()] == "closet player") then
      nh.recursive_ent = nil;
      nh.recursive_check = math.huge;
      
      for k,v in next, player.GetAll() do
        if(nh.valid(v) && LocalPlayer():IsLineOfSightClear(v)) then
          nh.pos = v:GetPos()
          if(LocalPlayer():GetPos():Distance(nh.pos) < nh.recursive_check) then
            nh.recursive_ent = v;
            nh.recursive_check = LocalPlayer():GetPos():Distance(nh.pos);
          end
        end
      end
      
    nh.for_snap_lines = nh.recursive_ent;
    
      nh.bone = nil;
      
      if(nh.valid(nh.recursive_ent)) then
        if(nh.recursive_ent:GetModel() == "models/error.mdl") then
          nh.bone = nh.recursive_ent:GetPos() + Vector(0, 0, 50);
        else
          nh.bone = nh.bones[nh.convars.aimbot.aimbot_bone:GetString()](nh.recursive_ent);
        end
      end
      
      if(LocalPlayer():Alive() && input.IsKeyDown(nh.convars.aimbot.aimbot_key:GetInt()) && nh.recursive_ent && nh.recursive_ent:Alive()) then
        ucmd:SetViewAngles((nh.bone - LocalPlayer():GetShootPos()):Angle());
      end
    end
  end
end

hook.Add("CreateMove", "nh.aimbot", nh.aimbot);

--[[
  <--> Crosshair
--]]

function nh.crosshair()
  if(nh.convars.misc.crosshair:GetBool()) then
    nh.xhair_size = math.abs(nh.convars.misc.crosshair_size:GetInt());
    surface.SetDrawColor(math.abs(nh.convars.misc.crosshair_r:GetInt()), math.abs(nh.convars.misc.crosshair_g:GetInt()), math.abs(nh.convars.misc.crosshair_b:GetInt()));
    surface.DrawLine(ScrW() / 2 - nh.xhair_size, ScrH() / 2, ScrW() / 2 + nh.xhair_size, ScrH() / 2);
    surface.DrawLine(ScrW() / 2, ScrH() / 2 - nh.xhair_size, ScrW() / 2, ScrH() / 2 + nh.xhair_size);
  end
end

hook.Add("HUDDrawScoreBoard", "nh.crosshair", nh.crosshair);


--[[
  <--> Chat info
  <--> I'm using the current gameevent.Listen we defined for player_hurt.
  <--> Currently undergoing some fixes.
--]]

nh.domination_table = {};

function nh.insert_into_table(data)
  nh.ply = Player(data.userid);
  if(IsValid(nh.ply) && nh.ply != LocalPlayer() && !nh.ply:IsBot() && !nh.domination_table[nh.ply:Nick()]) then
    nh.domination_table[nh.ply:Nick()] = 0;
  end
end

for k,v in next, player.GetAll() do
  if(IsValid(v) && v != LocalPlayer() && !nh.domination_table[v:Nick()]) then
    nh.domination_table[v:Nick()] = 0;
  end
end

function nh.chat_info(data)
  if(nh.convars.misc.chat_info:GetBool()) then
    nh.table = {Player(data.userid), Player(data.attacker)};
    if(IsValid(nh.table[1]) && IsValid(nh.table[2]) && nh.table[2] == LocalPlayer() && nh.domination_table[nh.table[1]:Nick()] != nil && data.health <= 0) then
      nh.domination_table[nh.table[1]:Nick()] = nh.domination_table[nh.table[1]:Nick()] + 1;
      LocalPlayer():ConCommand("say " .. nh.table[1]:Nick() .. " has gotten owned [" .. nh.domination_table[nh.table[1]:Nick()] .. "] time(s).");
    elseif(IsValid(nh.table[1]) && IsValid(nh.table[2]) && nh.table[1] == LocalPlayer() && nh.table[2] != LocalPlayer() && nh.domination_table[nh.table[2]:Nick()] != nil && data.health <= 0) then
      nh.domination_table[nh.table[2]:Nick()] = 0;
      LocalPlayer():ConCommand("say " .. nh.table[2]:Nick() .. " has ended their killstreak!");
    end
  end
end

hook.Add("player_spawn", "nh.insert_into_table", nh.insert_into_table);
hook.Add("player_hurt", "nh.chat_info", nh.chat_info);

--[[
  <--> Prop chat info
  <--> This requires a lot of trickery to do.
  <--> Sometimes it has issues with working on other servers.
  <--> This is currently in a WIP because it does have issues.
--]]

nh.prop_domination_table = {};
nh.last_held_prop_table = {};

function nh.insert_into_prop_table(data)
  nh.player = Player(data.userid);
  if(IsValid(nh.player) && nh.player != LocalPlayer() && !nh.player:IsBot() && !nh.prop_domination_table[nh.player:Nick()]) then
    nh.prop_domination_table[nh.player:Nick()] = 0;
  end
end

for k,v in next, player.GetAll() do
  if(IsValid(v) && v != LocalPlayer() && !v:IsBot() && !nh.prop_domination_table[v:Nick()]) then
    nh.prop_domination_table[v:Nick()] = 0;
  end
end

nh.table_say = {"prop owned", "prop smashed", "prop destroyed", "prop annihilated", "prop killed"};

function nh.prop_chat_info(data)
  if(nh.convars.misc.prop_chat_info:GetBool()) then
  nh.vic = Entity(data.entindex_killed);
  nh.atk = Entity(data.entindex_attacker);
    if(IsValid(nh.vic) && IsValid(nh.atk) && nh.vic != LocalPlayer() && !nh.vic:IsNPC() && !nh.vic:IsBot() && nh.atk == nh.last_held_prop && nh.prop_domination_table[nh.vic:Nick()] != nil) then
      nh.prop_domination_table[nh.vic:Nick()] = nh.prop_domination_table[nh.vic:Nick()] + 1;
      LocalPlayer():ConCommand("say " .. nh.vic:Nick() .. " has gotten " .. nh.table_say[math.random(#nh.table_say)] .. " [" .. nh.prop_domination_table[nh.vic:Nick()] .. "] time(s).");
    elseif(IsValid(nh.vic) && IsValid(nh.atk) && nh.vic == LocalPlayer() && nh.last_held_prop_table[tostring(nh.atk:EntIndex())] != nil && nh.prop_domination_table[nh.last_held_prop_table[tostring(nh.atk:EntIndex())]:Nick()] != nil) then
      nh.prop_domination_table[nh.last_held_prop_table[tostring(nh.atk:EntIndex())]:Nick()] = 0;
      LocalPlayer():ConCommand("say " .. nh.last_held_prop_table[tostring(nh.atk:EntIndex())]:Nick() .. " has ended their propkill streak!");
    end
  end
end

function nh.grab_their_prop(ply, _, beam, tar, __, ___)
  if(IsValid(ply) && ply != LocalPlayer() && IsValid(tar) && beam && !nh.last_held_prop_table[tostring(tar:EntIndex())]) then
    nh.last_held_prop_table[tostring(tar:EntIndex())] = ply;
  end
  return true;
end

hook.Add("DrawPhysgunBeam", "nh.grab_their_prop", nh.grab_their_prop);
hook.Add("player_spawn", "nh.insert_into_prop_table", nh.insert_into_prop_table);
hook.Add("entity_killed", "nh.prop_chat_info", nh.prop_chat_info);

--[[
  <--> Silent Aim
  <--> I made it proper by actually putting in the right calculation for it.
  <--> I did not originally do the calculations for this. I only did the proper editing for the m_yaw and m_pitch.
--]]

function nh.silent_aim(ucmd)
  if(nh.convars.aimbot.silent_aim:GetBool()) then
    if(!nh.current_angle) then nh.current_angle = ucmd:GetViewAngles(); end
    nh.current_angle = nh.current_angle + Angle(ucmd:GetMouseY() * (GetConVarNumber("m_yaw") * nh.convars.aimbot.invert_mouse_value:GetInt()), (ucmd:GetMouseX() * GetConVarNumber("m_pitch")), 0);
    nh.current_angle.p = math.Clamp(nh.current_angle.p, -89, 89); -- If you do not clamp the pitch it looks fucking stupid.
    if(ucmd:CommandNumber() == 0) then
      ucmd:SetViewAngles(nh.current_angle);
    else
      return;
    end
  end
end

hook.Add("CreateMove", "nh.silent_aim", nh.silent_aim);


--[[
  <--> ASUS Walls.
  <--> Literally you index $alpha with a IMaterial class and set it to .40 for a good effect.
  <--> I recommend having the Sky set to black for an even better effect.
--]]

nh.grabbed_materials = {};

function nh.asus_walls()
  if(nh.convars.misc.asus_walls:GetBool()) then
  
    for k,v in next, Entity(0):GetMaterials() do
      nh.store_mat = Material(v); -- Creates a IMaterial object that lets us use the member functions of IMaterial.
      if(type(nh.store_mat) == "IMaterial") then
        nh.store_mat:SetFloat("$alpha", nh.convars.misc.asus_walls_opacity:GetFloat()); -- 0.40 is for the better.
        if(GetConVar("nh_sky_r"):GetInt() != 0 || GetConVar("nh_sky_g"):GetInt() != 0 || GetConVar("nh_sky_b"):GetInt() != 0) then
          LocalPlayer():ConCommand("nh_sky_r 0");
          LocalPlayer():ConCommand("nh_sky_g 0");
          LocalPlayer():ConCommand("nh_sky_b 0");
        end
      end
    end
    
    if(Material(tostring(LocalPlayer():GetEyeTrace().HitTexture)):GetInt("$alpha") == 1) then
      nh.grabbed_materials[tostring(LocalPlayer():GetEyeTrace().HitTexture)] = true; -- Need to do this.
      Material(tostring(LocalPlayer():GetEyeTrace().HitTexture)):SetFloat("$alpha", nh.convars.misc.asus_walls_opacity:GetFloat());
    end
    
    for k,v in next, nh.grabbed_materials do -- This is for if they turn it off and back on it saves the last grabbed shit.
      nh.tmp_var = Material(k);
      if(type(nh.tmp_var) == "IMaterial") then
        nh.tmp_var:SetFloat("$alpha", nh.convars.misc.asus_walls_opacity:GetFloat());
      end
    end
  end
end

function nh.remove_asus_walls()
  if(!nh.convars.misc.asus_walls:GetBool()) then
    for k,v in next, Entity(0):GetMaterials() do
      nh.restore_mat = Material(v);
      if(type(nh.restore_mat) == "IMaterial" && nh.restore_mat:GetInt("$alpha") < 1) then
        nh.restore_mat:SetInt("$alpha", 1);
      end
    end
    for k,v in next, nh.grabbed_materials do
      nh.restore_grabbed_mat = Material(k);
      if(type(nh.restore_grabbed_mat) == "IMaterial" && nh.restore_grabbed_mat:GetInt("$alpha") < 1) then
        nh.restore_grabbed_mat:SetInt("$alpha", 1);
      end
    end
  end
end

hook.Add("HUDPaint", "nh.asus_walls", nh.asus_walls);
hook.Add("HUDPaint", "nh.remove_asus_walls", nh.remove_asus_walls);

--[[
  <--> Snaplines
  <--> Made this for the Aimbot.
--]]

function nh.snaplines()
  if(nh.convars.visuals.snaplines:GetBool()) then
    if(nh.convars.visuals.tracer_2d:GetBool()) then LocalPlayer():ConCommand("nh_tracer_2d 0"); end
    if(nh.convars.visuals.tracer_3d_drawline:GetBool()) then LocalPlayer():ConCommand("nh_tracer_3d_drawline 0"); end
    for k,v in next, player.GetAll() do -- This is for the unique color target.
      if(nh.valid(v) && nh.for_snap_lines != nil && v == nh.for_snap_lines) then
        nh.pixel_pos = v:GetShootPos():ToScreen();
        nh.center = Vector(ScrW()/2, ScrH()/2);
        if(nh.on_screen(nh.pixel_pos.x, nh.pixel_pos.y)) then
          surface.SetDrawColor(nh.color_table[k % 255 + 2]);
          surface.DrawLine(nh.center.x, nh.center.y, nh.pixel_pos.x, nh.pixel_pos.y);
        end
      else
        continue;
      end
    end
  end
end

hook.Add("HUDDrawPickupHistory", "nh.snaplines", nh.snaplines);

--[[
  <--> Radar
  <--> This isn't using derma btw.
  <--> Kept the convars here because I didn't feel like doing nh.convars.radar shit.
  <--> If you're going to say, "Why not make a dynamic surface menu", then unsub from the workshop.
--]]

nh.radar = {
  radar_active = CreateClientConVar("nh_radar_active", "1", true, false);
  radar_size = CreateClientConVar("nh_radar_size", "400", true, false);
  zoom = CreateClientConVar("nh_radar_zoom", "50", true, false);
  toggle_lines = CreateClientConVar("nh_radar_lines", "1", true, false);
  names = CreateClientConVar("nh_radar_names", "1", true, false);
  draw_your_point = CreateClientConVar("nh_radar_draw_your_point", "1", true, false);
  draw_their_point = CreateClientConVar("nh_radar_draw_their_point", "1", true, false);
  box_color_r = CreateClientConVar("nh_radar_r", "255", true, false);
  box_color_g = CreateClientConVar("nh_radar_g", "255", true, false);
  box_color_b = CreateClientConVar("nh_radar_b", "255", true, false);
  distance = CreateClientConVar("nh_radar_distance", "0", true, false);
  zaxis = CreateClientConVar("nh_radar_zaxis", "1", true, false);
  your_point_size = CreateClientConVar("nh_radar_your_point_size", "5", true, false);
  their_point_size = CreateClientConVar("nh_radar_their_point_size", "4", true, false);
};

surface.CreateFont("test", {
font = "Default",
size = 12,
weight = 1,
outline = true,
antialias = false,
});

surface.CreateFont("test2", {
font = "Default",
size = 10,
weight = 1,
outline = true,
antialias = false,
});

nh.rect_data = {
  x = ScrW()/2,
  y = ScrH()/2,
  w = nh.radar.radar_size:GetInt(),
  h = nh.radar.radar_size:GetInt()
};

function nh.calc_offset(table_arg, rect_offset) -- return a table
  nh.mouse_x, nh.mouse_y = gui.MousePos();
  return {
    x = (nh.mouse_x - rect_offset.x),
    y = (nh.mouse_y - rect_offset.y),
    w = table_arg.w,
    h = table_arg.h
  };
end

function nh.check_pos(table_arg) -- return a boolean check
  nh.mouse_x, nh.mouse_y = gui.MousePos();
  return nh.mouse_x > table_arg.x && nh.mouse_x < table_arg.x + table_arg.w && nh.mouse_y > table_arg.y && nh.mouse_y < table_arg.y + table_arg.h;
end

hook.Add("HUDDrawScoreBoard", "nh.radar", function()
  if(nh.radar.radar_active:GetBool()) then
    if(!current_save && input.IsMouseDown(MOUSE_LEFT) && nh.check_pos(nh.rect_data)) then
      nh.new_mouse_x, nh.new_mouse_y = gui.MousePos();
      current_save = {x = (nh.new_mouse_x - nh.rect_data.x), y = (nh.new_mouse_y - nh.rect_data.y)};
    elseif(current_save && input.IsMouseDown(MOUSE_LEFT)) then
      nh.rect_data = (nh.calc_offset(nh.rect_data, current_save) || nh.rect_data);
    elseif(current_save && !input.IsMouseDown(MOUSE_LEFT)) then
      current_save = nil;
    end
  
    nh.box_x = nh.rect_data.x;
    nh.box_y = nh.rect_data.y;
    nh.radar_size = nh.rect_data.w;
    
    if(nh.rect_data.w != nh.radar.radar_size:GetInt()) then
      nh.rect_data.w = nh.radar.radar_size:GetInt();
      nh.rect_data.h = nh.radar.radar_size:GetInt();
    end
    
    if(nh.box_x > ScrW()) then
      nh.box_x = ScrW();
    elseif(nh.box_x < 0) then
      nh.box_x = 0;
    end
    
    if(nh.box_y > ScrH()) then
      nh.box_y = ScrH();
    elseif(nh.box_y < 0) then
      nh.box_y = 0;
    end

    surface.SetDrawColor(Color(255 - nh.radar.box_color_r:GetInt(), 255 - nh.radar.box_color_g:GetInt(), 255 - nh.radar.box_color_b:GetInt()));
    surface.DrawRect(nh.box_x - 2, nh.box_y - 2, nh.radar_size + 4, nh.radar_size + 4);
    surface.SetDrawColor(Color(nh.radar.box_color_r:GetInt(), nh.radar.box_color_g:GetInt(), nh.radar.box_color_b:GetInt()));
    surface.DrawRect(nh.box_x, nh.box_y, nh.radar_size, nh.radar_size);
    for k,v in next, player.GetAll() do
      if(IsValid(v) && v != LocalPlayer()) then
        nh.line_x = LocalPlayer():GetPos().x - v:GetPos().x;
        nh.line_y = LocalPlayer():GetPos().y - v:GetPos().y;
        nh.angle = LocalPlayer():EyeAngles().y;
        nh.cosine = math.cos(math.rad(nh.angle * -1));
        nh.sin = math.sin(math.rad(nh.angle * -1));
        nh.pixel_x = ((nh.line_y * nh.cosine) + (nh.line_x * nh.sin)) / nh.radar.zoom:GetInt();
        nh.pixel_y = ((nh.line_x * nh.cosine) - (nh.line_y * nh.sin)) / nh.radar.zoom:GetInt();
        nh.pixel_x = math.Clamp(nh.pixel_x, (nh.radar_size / 2) * -1, nh.radar_size / 2);
        nh.pixel_y = math.Clamp(nh.pixel_y, (nh.radar_size / 2) * -1, nh.radar_size / 2);
        
        if(nh.radar.names:GetBool()) then
          draw.DrawText(v:Nick() .. (v:Alive() && nh.radar.zaxis:GetBool() && ((math.Round(v:GetPos().z) == math.Round(LocalPlayer():GetPos().z)) && " (=)" || (v:GetPos().z < LocalPlayer():GetPos().z) && " (-) " .. math.Round(math.abs(v:GetPos().z - LocalPlayer():GetPos().z)/16) || " (+) " .. math.Round(math.abs(LocalPlayer():GetPos().z - v:GetPos().z)/16)) || ""), "test", nh.box_x + nh.radar_size - (nh.radar_size / 2) + nh.pixel_x, nh.box_y + nh.radar_size - (nh.radar_size * .50) + nh.pixel_y - 16, (v:Alive() && nh.color_table[k % 255]) || Color(255, 0, 0), TEXT_ALIGN_CENTER);
        end
        
        surface.SetDrawColor((v:Alive() && nh.color_table[k % 255]) || Color(255, 0, 0));
        
        if(nh.radar.draw_their_point:GetBool()) then
          surface.DrawLine(nh.box_x + nh.radar_size - (nh.radar_size / 2) + nh.pixel_x - nh.radar.their_point_size:GetInt(), nh.box_y + nh.radar_size - (nh.radar_size / 2) + nh.pixel_y, nh.box_x + nh.radar_size - (nh.radar_size / 2) + nh.pixel_x + nh.radar.their_point_size:GetInt(), nh.box_y + nh.radar_size - (nh.radar_size / 2) + nh.pixel_y);
          surface.DrawLine(nh.box_x + nh.radar_size - (nh.radar_size / 2) + nh.pixel_x, nh.box_y + nh.radar_size - (nh.radar_size / 2) + nh.pixel_y - nh.radar.their_point_size:GetInt(), nh.box_x + nh.radar_size - (nh.radar_size / 2) + nh.pixel_x, nh.box_y + nh.radar_size - (nh.radar_size / 2) + nh.pixel_y + nh.radar.their_point_size:GetInt());
        end
        
        if(nh.radar.toggle_lines:GetBool()) then
          surface.DrawLine(nh.box_x + (nh.radar_size / 2), (nh.box_y) + (nh.radar_size / 2), nh.box_x + nh.radar_size - (nh.radar_size / 2) + nh.pixel_x, nh.box_y + nh.radar_size - (nh.radar_size / 2) + nh.pixel_y);
          
          nh.vec1 = Vector(nh.box_x + (nh.radar_size / 2), nh.box_y + (nh.radar_size / 2));
          
          nh.vec2 = Vector(nh.box_x + nh.radar_size - (nh.radar_size / 2) + nh.pixel_x, nh.box_y + nh.radar_size - (nh.radar_size / 2) + nh.pixel_y);
          
          if(nh.radar.distance:GetBool() && v:Alive()) then
            nh.center = Vector((nh.vec1.x + nh.vec2.x)/2, (nh.vec1.y + nh.vec2.y)/2);
            draw.DrawText(math.Round(nh.vec1:Distance(nh.vec2)), "test2", nh.center.x, nh.center.y, nh.color_table[k % 255 + 1], TEXT_ALIGN_CENTER);
          end
        end
      end
    end
    
    if(nh.radar.draw_your_point:GetBool()) then
      surface.SetDrawColor(255, 255, 0);
      surface.DrawLine(nh.box_x + (nh.radar_size / 2) - nh.radar.your_point_size:GetInt(), nh.box_y + (nh.radar_size / 2), nh.box_x + (nh.radar_size / 2) + nh.radar.your_point_size:GetInt(), nh.box_y + (nh.radar_size / 2));
      surface.DrawLine(nh.box_x + (nh.radar_size / 2), nh.box_y + (nh.radar_size / 2) - nh.radar.your_point_size:GetInt(), nh.box_x + (nh.radar_size / 2), nh.box_y + (nh.radar_size / 2) + nh.radar.your_point_size:GetInt());
    end
  end
end);

--[[
  <--> Menu
  <--> Derma based but it is okay for now.
--]]

nh.bool_menu = false; -- Used for determining if you open the menu more than once.

concommand.Add("nh_menu", function()

  if(nh.bool_menu) then
    chat.AddText(Color(255, 0, 0), "Cannot have the menu open two times.");
    return;
  end
  
  nh.bool_menu = !nh.bool_menu;
  
  nh.frame = vgui.Create("DFrame");
  nh.frame:SetTitle("Nailhead pk scripts by Electfried");
  nh.frame:SetSize(ScrW() * (600/ScrW()), ScrH() * (400/ScrH()));
  nh.frame:SetVisible(true);
  nh.frame:ShowCloseButton(true);
  nh.frame:MakePopup();
  nh.frame:Center();
  
  function nh.frame:Paint(_, __)
    surface.SetDrawColor(Color(0, 0, 0, 200));
    surface.DrawRect(0, 0, nh.frame:GetWide(), nh.frame:GetTall());
  end
  
  function nh.frame.OnClose()
    nh.bool_menu = !nh.bool_menu;
    nh.frame:SetVisible(false);
    if(timer.Exists("idklol") || timer.Exists("idklol_2") || timer.Exists("idklol_3")) then
      timer.Remove("idklol");
      timer.Remove("idklol_2");
      timer.Remove("idklol_3");
      timer.Remove("idklol_4");
    end
  end
  
    nh.panel = vgui.Create("DPanel", nh.frame);
    nh.panel:SetBackgroundColor(Color(0, 0, 0, 255));
    
  nh.panel_2 = vgui.Create("DPanel", nh.frame);
    nh.panel_2:SetBackgroundColor(Color(0, 0, 0, 255));
  
  nh.panel_3 = vgui.Create("DPanel", nh.frame);
    nh.panel_3:SetBackgroundColor(Color(0, 0, 0, 255));
  
  nh.panel_4 = vgui.Create("DPanel", nh.frame);
  nh.panel_4:SetBackgroundColor(Color(0, 0, 0, 255));
  
    nh.check_esp = vgui.Create("DCheckBoxLabel");
    nh.check_esp:SetParent(nh.panel);
    nh.check_esp:SetPos(ScrW() * (30/ ScrW()), ScrH() * (25/ScrH()));
    nh.check_esp:SetValue(math.abs(nh.convars.visuals.esp:GetInt()));
    nh.check_esp:SetConVar("nh_esp");
    nh.check_esp:SetText("ESP");
    nh.check_esp:SetTextColor(Color(255, 255, 255, 255));
    
  nh.check_box_2d = vgui.Create("DCheckBoxLabel");
  nh.check_box_2d:SetParent(nh.panel);
  nh.check_box_2d:SetPos(ScrW() * (30/ ScrW()), ScrH() * ((25 * 2 - 5)/ScrH()));
  nh.check_box_2d:SetValue(math.abs(nh.convars.visuals.box_2d:GetInt()));
    nh.check_box_2d:SetConVar("nh_box_2d");
    nh.check_box_2d:SetText("2D BOX");
    nh.check_box_2d:SetTextColor(Color(255, 255, 255, 255));
  
  nh.check_counter = vgui.Create("DCheckBoxLabel");
  nh.check_counter:SetParent(nh.panel);
  nh.check_counter:SetPos(ScrW() * (30/ ScrW()), ScrH() * ((25 * 3 - 10)/ScrH()));
  nh.check_counter:SetValue(math.abs(nh.convars.visuals.draw_pk_counter:GetInt()));
    nh.check_counter:SetConVar("nh_draw_pk_counter");
    nh.check_counter:SetText("DRAW COUNTER");
    nh.check_counter:SetTextColor(Color(255, 255, 255, 255));
  
  nh.check_chams = vgui.Create("DCheckBoxLabel");
  nh.check_chams:SetParent(nh.panel);
  nh.check_chams:SetPos(ScrW() * (30/ ScrW()), ScrH() * ((25 * 4 - 15)/ScrH()));
  nh.check_chams:SetValue(math.abs(nh.convars.visuals.chams:GetInt()));
    nh.check_chams:SetConVar("nh_chams");
    nh.check_chams:SetText("CHAMS");
    nh.check_chams:SetTextColor(Color(255, 255, 255, 255));
  
  nh.check_tracer_2d = vgui.Create("DCheckBoxLabel");
  nh.check_tracer_2d:SetParent(nh.panel);
  nh.check_tracer_2d:SetPos(ScrW() * (30/ ScrW()), ScrH() * ((25 * 5 - 20)/ScrH()));
  nh.check_tracer_2d:SetValue(math.abs(nh.convars.visuals.tracer_2d:GetInt()));
    nh.check_tracer_2d:SetConVar("nh_tracer_2d");
    nh.check_tracer_2d:SetText("TRACER 2D");
    nh.check_tracer_2d:SetTextColor(Color(255, 255, 255, 255));
  
  nh.check_tracer_3d = vgui.Create("DCheckBoxLabel");
  nh.check_tracer_3d:SetParent(nh.panel);
  nh.check_tracer_3d:SetPos(ScrW() * (30/ ScrW()), ScrH() * ((25 * 6 - 25)/ScrH()));
  nh.check_tracer_3d:SetValue(math.abs(nh.convars.visuals.tracer_3d_drawline:GetInt()));
    nh.check_tracer_3d:SetConVar("nh_tracer_3d_drawline");
    nh.check_tracer_3d:SetText("TRACER 3D");
    nh.check_tracer_3d:SetTextColor(Color(255, 255, 255, 255));
  
  nh.check_xray = vgui.Create("DCheckBoxLabel");
  nh.check_xray:SetParent(nh.panel);
  nh.check_xray:SetPos(ScrW() * (30/ ScrW()), ScrH() * ((25 * 7 - 30)/ScrH()));
  nh.check_xray:SetValue(math.abs(nh.convars.visuals.tracer_3d_drawline:GetInt()));
    nh.check_xray:SetConVar("nh_xray");
    nh.check_xray:SetText("XRAY");
    nh.check_xray:SetTextColor(Color(255, 255, 255, 255));
  
  nh.check_eyetracers = vgui.Create("DCheckBoxLabel");
  nh.check_eyetracers:SetParent(nh.panel);
  nh.check_eyetracers:SetPos(ScrW() * (30/ ScrW()), ScrH() * ((25 * 8 - 35)/ScrH()));
  nh.check_eyetracers:SetValue(math.abs(nh.convars.visuals.eyetracers:GetInt()));
    nh.check_eyetracers:SetConVar("nh_eyetracers");
    nh.check_eyetracers:SetText("EYETRACERS");
    nh.check_eyetracers:SetTextColor(Color(255, 255, 255, 255));
  
  nh.check_proplines = vgui.Create("DCheckBoxLabel");
  nh.check_proplines:SetParent(nh.panel);
  nh.check_proplines:SetPos(ScrW() * (30/ ScrW()), ScrH() * ((25 * 9 - 40)/ScrH()));
  nh.check_proplines:SetValue(math.abs(nh.convars.visuals.prop_tracer_3d_drawline:GetInt()));
    nh.check_proplines:SetConVar("nh_prop_tracer_3d_drawline");
    nh.check_proplines:SetText("PROP LINES");
    nh.check_proplines:SetTextColor(Color(255, 255, 255, 255));
  
  nh.check_proplines_extra = vgui.Create("DCheckBoxLabel");
  nh.check_proplines_extra:SetParent(nh.panel);
  nh.check_proplines_extra:SetPos(ScrW() * (30/ ScrW()), ScrH() * ((25 * 10 - 45)/ScrH()));
  nh.check_proplines_extra:SetValue(math.abs(nh.convars.visuals.show_block_prop:GetInt()));
    nh.check_proplines_extra:SetConVar("nh_prop_tracer_3d_show_block_prop");
    nh.check_proplines_extra:SetText("PROP LINES EXTRA");
    nh.check_proplines_extra:SetTextColor(Color(255, 255, 255, 255));
  
  nh.check_halos = vgui.Create("DCheckBoxLabel");
  nh.check_halos:SetParent(nh.panel);
  nh.check_halos:SetPos(ScrW() * (30/ ScrW()), ScrH() * ((25 * 11 - 50)/ScrH()));
  nh.check_halos:SetValue(math.abs(nh.convars.visuals.halos:GetInt()));
    nh.check_halos:SetConVar("nh_halos");
    nh.check_halos:SetText("HALOS");
    nh.check_halos:SetTextColor(Color(255, 255, 255, 255));
  
  nh.check_headsmash = vgui.Create("DCheckBoxLabel");
  nh.check_headsmash:SetParent(nh.panel);
  nh.check_headsmash:SetPos(ScrW() * (30/ ScrW()), ScrH() * ((25 * 12 - 55)/ScrH()));
  nh.check_headsmash:SetValue(math.abs(nh.convars.visuals.headsmash_drawline:GetInt()));
    nh.check_headsmash:SetConVar("nh_headsmash_drawline");
    nh.check_headsmash:SetText("HEADSMASH BEAMS");
    nh.check_headsmash:SetTextColor(Color(255, 255, 255, 255));
  
  nh.check_fov = vgui.Create("DCheckBoxLabel");
  nh.check_fov:SetParent(nh.panel);
  nh.check_fov:SetPos(ScrW() * (30/ ScrW()), ScrH() * ((25 * 13 - 60)/ScrH()));
  nh.check_fov:SetValue(math.abs(nh.convars.visuals.fovenable:GetInt()));
    nh.check_fov:SetConVar("nh_fovenable");
    nh.check_fov:SetText("FOV ENABLE");
    nh.check_fov:SetTextColor(Color(255, 255, 255, 255));
  
  nh.check_esp_name = vgui.Create("DCheckBoxLabel");
  nh.check_esp_name:SetParent(nh.panel);
  nh.check_esp_name:SetPos(ScrW() * (180/ ScrW()), ScrH() * ((25)/ScrH()));
  nh.check_esp_name:SetValue(math.abs(nh.convars.visuals.esp_name:GetInt()));
    nh.check_esp_name:SetConVar("nh_esp_name");
    nh.check_esp_name:SetText("ESP NAME");
    nh.check_esp_name:SetTextColor(Color(255, 255, 255, 255));
  
  nh.check_esp_hp = vgui.Create("DCheckBoxLabel");
  nh.check_esp_hp:SetParent(nh.panel);
  nh.check_esp_hp:SetPos(ScrW() * (180/ ScrW()), ScrH() * ((25 * 2 - 5)/ScrH()));
  nh.check_esp_hp:SetValue(math.abs(nh.convars.visuals.esp_hp:GetInt()));
    nh.check_esp_hp:SetConVar("nh_esp_hp");
    nh.check_esp_hp:SetText("ESP HP");
    nh.check_esp_hp:SetTextColor(Color(255, 255, 255, 255));
  
  nh.check_esp_rank = vgui.Create("DCheckBoxLabel");
  nh.check_esp_rank:SetParent(nh.panel);
  nh.check_esp_rank:SetPos(ScrW() * (180/ ScrW()), ScrH() * ((25 * 3 - 10)/ScrH()));
  nh.check_esp_rank:SetValue(math.abs(nh.convars.visuals.esp_rank:GetInt()));
    nh.check_esp_rank:SetConVar("nh_esp_rank");
    nh.check_esp_rank:SetText("ESP RANK");
    nh.check_esp_rank:SetTextColor(Color(255, 255, 255, 255));
  
  nh.check_esp_distance = vgui.Create("DCheckBoxLabel");
  nh.check_esp_distance:SetParent(nh.panel);
  nh.check_esp_distance:SetPos(ScrW() * (180/ ScrW()), ScrH() * ((25 * 4 - 15)/ScrH()));
  nh.check_esp_distance:SetValue(math.abs(nh.convars.visuals.esp_distance:GetInt()));
    nh.check_esp_distance:SetConVar("nh_esp_distance");
    nh.check_esp_distance:SetText("ESP DISTANCE");
    nh.check_esp_distance:SetTextColor(Color(255, 255, 255, 255));
  
  nh.check_esp_weapon = vgui.Create("DCheckBoxLabel");
  nh.check_esp_weapon:SetParent(nh.panel);
  nh.check_esp_weapon:SetPos(ScrW() * (180/ ScrW()), ScrH() * ((25 * 5 - 20)/ScrH()));
  nh.check_esp_weapon:SetValue(math.abs(nh.convars.visuals.esp_weapon:GetInt()));
    nh.check_esp_weapon:SetConVar("nh_esp_weapon");
    nh.check_esp_weapon:SetText("ESP WEAPON");
    nh.check_esp_weapon:SetTextColor(Color(255, 255, 255, 255));
  
  nh.check_esp_userlist = vgui.Create("DCheckBoxLabel");
  nh.check_esp_userlist:SetParent(nh.panel);
  nh.check_esp_userlist:SetPos(ScrW() * (180/ ScrW()), ScrH() * ((25 * 6 - 25)/ScrH()));
  nh.check_esp_userlist:SetValue(math.abs(nh.convars.visuals.esp_userlist:GetInt()));
  nh.check_esp_userlist:SetConVar("nh_esp_userlist");
  nh.check_esp_userlist:SetText("ESP USERLIST");
  nh.check_esp_userlist:SetTextColor(Color(255, 255, 255, 255));
  
  nh.check_snaplines = vgui.Create("DCheckBoxLabel");
  nh.check_snaplines:SetParent(nh.panel);
  nh.check_snaplines:SetPos(ScrW() * (180/ ScrW()), ScrH() * ((25 * 7 - 30)/ScrH()));
  nh.check_snaplines:SetValue(math.abs(nh.convars.visuals.snaplines:GetInt()));
  nh.check_snaplines:SetConVar("nh_snaplines");
  nh.check_snaplines:SetText("SNAPLINES");
  nh.check_snaplines:SetTextColor(Color(255, 255, 255, 255));
  
  nh.check_bhop = vgui.Create("DCheckBoxLabel");
    nh.check_bhop:SetParent(nh.panel_2);
    nh.check_bhop:SetPos(ScrW() * (30/ ScrW()), ScrH() * (25/ScrH()));
    nh.check_bhop:SetValue(math.abs(nh.convars.misc.bhop:GetInt()));
    nh.check_bhop:SetConVar("nh_bhop");
    nh.check_bhop:SetText("BHOP");
    nh.check_bhop:SetTextColor(Color(255, 255, 255, 255));
  
  nh.check_fov_num = vgui.Create("DNumSlider");
  nh.check_fov_num:SetParent(nh.panel_2);
  nh.check_fov_num:SetPos(ScrW() * (30/ ScrW()), ScrH() * ((25 * 2 - 5)/ScrH()));
  nh.check_fov_num:SetSize(ScrW() * (175/ ScrW()), ScrH() * (30/ScrH()));
  nh.check_fov_num:SetValue(math.abs(nh.convars.visuals.fov:GetInt()));
  nh.check_fov_num:SetText("FOV NUMBER");
  nh.check_fov_num:SetMin(1);
  nh.check_fov_num:SetMax(160);
  nh.check_fov_num:SetDecimals(0);
  nh.check_fov_num:SetConVar("nh_fov");
  
  nh.check_xray_color = vgui.Create("DColorMixer");
  nh.check_xray_color:SetParent(nh.panel_2);
  nh.check_xray_color:SetPos(ScrW() * ((30 * 12)/ ScrW()), ScrH() * (20/ScrH()));
  nh.check_xray_color:SetSize(ScrW() * (160/ ScrW()), ScrH() * (125/ScrH()));
  nh.check_xray_color:SetPalette(false);
  nh.check_xray_color:SetAlphaBar(false);
  nh.check_xray_color:SetWangs(true);
  nh.check_xray_color:SetColor(Color(nh.convars.visuals.xray_r:GetInt(), nh.convars.visuals.xray_g:GetInt(), nh.convars.visuals.xray_b:GetInt()));
  nh.check_xray_color:SetLabel("XRAY COLORS");
  nh.check_xray_color.label:SetTextColor(Color(255, 255, 255, 255));
  
  timer.Create("idklol", 0.01, 0, function()
    nh.get_color = nh.check_xray_color:GetColor();
    nh.convars.visuals.xray_r:SetInt(nh.get_color.r);
    nh.convars.visuals.xray_g:SetInt(nh.get_color.g);
    nh.convars.visuals.xray_b:SetInt(nh.get_color.b);
    nh.check_xray_color:SetColor(Color(nh.convars.visuals.xray_r:GetInt(), nh.convars.visuals.xray_g:GetInt(), nh.convars.visuals.xray_b:GetInt()));
  end);
  
  nh.check_xhair_color = vgui.Create("DColorMixer");
  nh.check_xhair_color:SetParent(nh.panel_2);
  nh.check_xhair_color:SetPos(ScrW() * ((30 * 12)/ ScrW()), ScrH() * ((20 * 8)/ScrH()));
  nh.check_xhair_color:SetSize(ScrW() * (160/ ScrW()), ScrH() * (125/ScrH()));
  nh.check_xhair_color:SetPalette(false);
  nh.check_xhair_color:SetAlphaBar(false);
  nh.check_xhair_color:SetWangs(true);
  nh.check_xhair_color:SetColor(Color(nh.convars.misc.crosshair_r:GetInt(), nh.convars.misc.crosshair_g:GetInt(), nh.convars.misc.crosshair_b:GetInt()));
  nh.check_xhair_color:SetLabel("XHAIR COLORS");
  nh.check_xhair_color.label:SetTextColor(Color(255, 255, 255, 255));
  
  timer.Create("idklol_2", 0.01, 0, function()
    nh.get_xhair_color = nh.check_xhair_color:GetColor();
    nh.convars.misc.crosshair_r:SetInt(nh.get_xhair_color.r);
    nh.convars.misc.crosshair_g:SetInt(nh.get_xhair_color.g);
    nh.convars.misc.crosshair_b:SetInt(nh.get_xhair_color.b);
    nh.check_xhair_color:SetColor(Color(nh.convars.misc.crosshair_r:GetInt(), nh.convars.misc.crosshair_g:GetInt(), nh.convars.misc.crosshair_b:GetInt()));
  end);
  
  nh.check_crosshair = vgui.Create("DCheckBoxLabel");
    nh.check_crosshair:SetParent(nh.panel_2);
    nh.check_crosshair:SetPos(ScrW() * (30/ ScrW()), ScrH() * ((25 * 6 - 5)/ScrH()));
    nh.check_crosshair:SetValue(math.abs(nh.convars.misc.crosshair:GetInt()));
    nh.check_crosshair:SetConVar("nh_crosshair");
    nh.check_crosshair:SetText("CROSSHAIR");
    nh.check_crosshair:SetTextColor(Color(255, 255, 255, 255));
  
  nh.check_sky = vgui.Create("DCheckBoxLabel");
    nh.check_sky:SetParent(nh.panel_2);
    nh.check_sky:SetPos(ScrW() * (30/ ScrW()), ScrH() * ((25 * 8)/ScrH()));
    nh.check_sky:SetValue(math.abs(nh.convars.visuals.sky:GetInt()));
    nh.check_sky:SetConVar("nh_sky");
    nh.check_sky:SetText("SKY");
    nh.check_sky:SetTextColor(Color(255, 255, 255, 255));
  
  nh.check_chat_info = vgui.Create("DCheckBoxLabel");
    nh.check_chat_info:SetParent(nh.panel_2);
    nh.check_chat_info:SetPos(ScrW() * (30/ ScrW()), ScrH() * ((25 * 9 - 5)/ScrH()));
    nh.check_chat_info:SetValue(math.abs(nh.convars.misc.chat_info:GetInt()));
    nh.check_chat_info:SetConVar("nh_chat_info");
    nh.check_chat_info:SetText("CHAT INFO");
    nh.check_chat_info:SetTextColor(Color(255, 255, 255, 255));
  
  nh.check_prop_chat_info = vgui.Create("DCheckBoxLabel");
    nh.check_prop_chat_info:SetParent(nh.panel_2);
    nh.check_prop_chat_info:SetPos(ScrW() * (30/ ScrW()), ScrH() * ((25 * 10 - 10)/ScrH()));
    nh.check_prop_chat_info:SetValue(math.abs(nh.convars.misc.prop_chat_info:GetInt()));
    nh.check_prop_chat_info:SetConVar("nh_prop_chat_info");
    nh.check_prop_chat_info:SetText("PROP CHAT INFO");
    nh.check_prop_chat_info:SetTextColor(Color(255, 255, 255, 255));
  
  nh.check_asus = vgui.Create("DCheckBoxLabel");
  nh.check_asus:SetParent(nh.panel_2);
  nh.check_asus:SetPos(ScrW() * (30/ ScrW()), ScrH() * ((25 * 11 - 15)/ScrH()));
  nh.check_asus:SetValue(math.abs(nh.convars.misc.asus_walls:GetInt()));
  nh.check_asus:SetConVar("nh_asus_walls");
  nh.check_asus:SetText("ASUS WALLS");
  nh.check_asus:SetTextColor(Color(255, 255, 255, 255));
  
  nh.check_sky_color = vgui.Create("DColorMixer");
  nh.check_sky_color:SetParent(nh.panel_2);
  nh.check_sky_color:SetPos(ScrW() * ((30 * 7 - 15)/ ScrW()), ScrH() * ((20)/ScrH()));
  nh.check_sky_color:SetSize(ScrW() * (160/ ScrW()), ScrH() * (125/ScrH()));
  nh.check_sky_color:SetPalette(false);
  nh.check_sky_color:SetAlphaBar(false);
  nh.check_sky_color:SetWangs(true);
  nh.check_sky_color:SetColor(Color(nh.convars.visuals.sky_r:GetInt(), nh.convars.visuals.sky_g:GetInt(), nh.convars.visuals.sky_b:GetInt()));
  nh.check_sky_color:SetLabel("SKY COLORS");
  nh.check_sky_color.label:SetTextColor(Color(255, 255, 255, 255));
  
  timer.Create("idklol_3", 0.01, 0, function()
    nh.get_sky_color = nh.check_sky_color:GetColor();
    nh.convars.visuals.sky_r:SetInt(nh.get_sky_color.r);
    nh.convars.visuals.sky_g:SetInt(nh.get_sky_color.g);
  nh.convars.visuals.sky_b:SetInt(nh.get_sky_color.b);
    nh.check_sky_color:SetColor(Color(nh.convars.visuals.sky_r:GetInt(), nh.convars.visuals.sky_g:GetInt(), nh.convars.visuals.sky_b:GetInt()));
  end);
  
  nh.check_crosshair_size = vgui.Create("DNumSlider");
  nh.check_crosshair_size:SetParent(nh.panel_2);
  nh.check_crosshair_size:SetPos(ScrW() * (30/ ScrW()), ScrH() * ((25 * 7 - 10)/ScrH()));
  nh.check_crosshair_size:SetSize(ScrW() * (175/ ScrW()), ScrH() * (30/ScrH()));
  nh.check_crosshair_size:SetValue(math.abs(nh.convars.misc.crosshair_size:GetInt()));
  nh.check_crosshair_size:SetText("XHAIR SIZE");
  nh.check_crosshair_size:SetMin(1);
  nh.check_crosshair_size:SetMax(400);
  nh.check_crosshair_size:SetDecimals(0);
  nh.check_crosshair_size:SetConVar("nh_crosshair_size");
  
  nh.check_asus_opacity = vgui.Create("DNumSlider");
  nh.check_asus_opacity:SetParent(nh.panel_2);
  nh.check_asus_opacity:SetPos(ScrW() * (30/ ScrW()), ScrH() * ((25 * 12 - 20)/ScrH()));
  nh.check_asus_opacity:SetSize(ScrW() * (175/ ScrW()), ScrH() * (30/ScrH()));
  nh.check_asus_opacity:SetValue(math.abs(nh.convars.misc.asus_walls_opacity:GetInt()));
  nh.check_asus_opacity:SetText("ASUS OPACITY");
  nh.check_asus_opacity:SetMin(0);
  nh.check_asus_opacity:SetMax(1);
  nh.check_asus_opacity:SetDecimals(2);
  nh.check_asus_opacity:SetConVar("nh_asus_walls_opacity");
  
  nh.check_halo_dist = vgui.Create("DNumSlider");
  nh.check_halo_dist:SetParent(nh.panel_2);
  nh.check_halo_dist:SetPos(ScrW() * (30/ ScrW()), ScrH() * ((25 * 3 - 10)/ScrH()));
  nh.check_halo_dist:SetSize(ScrW() * (175/ ScrW()), ScrH() * (30/ScrH()));
  nh.check_halo_dist:SetValue(math.abs(nh.convars.visuals.halos_draw_distance:GetInt()));
  nh.check_halo_dist:SetText("HALO DIST");
  nh.check_halo_dist:SetMin(1);
  nh.check_halo_dist:SetMax(400);
  nh.check_halo_dist:SetDecimals(0);
  nh.check_halo_dist:SetConVar("nh_halos_draw_distance");
  
  nh.check_halo_intensity = vgui.Create("DNumSlider");
  nh.check_halo_intensity:SetParent(nh.panel_2);
  nh.check_halo_intensity:SetPos(ScrW() * (30/ ScrW()), ScrH() * ((25 * 4 - 15)/ScrH()));
  nh.check_halo_intensity:SetSize(ScrW() * (175/ ScrW()), ScrH() * (30/ScrH()));
  nh.check_halo_intensity:SetValue(math.abs(nh.convars.visuals.halos_intensity:GetInt()));
  nh.check_halo_intensity:SetText("HALO INTENSITY");
  nh.check_halo_intensity:SetMin(0);
  nh.check_halo_intensity:SetMax(3);
  nh.check_halo_intensity:SetDecimals(2);
  nh.check_halo_intensity:SetConVar("nh_halos_intensity");
  
  nh.check_proplines_dist = vgui.Create("DNumSlider");
  nh.check_proplines_dist:SetParent(nh.panel_2);
  nh.check_proplines_dist:SetPos(ScrW() * (30/ ScrW()), ScrH() * ((25 * 5 - 20)/ScrH()));
  nh.check_proplines_dist:SetSize(ScrW() * (175/ ScrW()), ScrH() * (30/ScrH()));
  nh.check_proplines_dist:SetValue(math.abs(nh.convars.visuals.prop_tracer_3d_distance:GetInt()));
  nh.check_proplines_dist:SetText("PROPLINE DIST");
  nh.check_proplines_dist:SetMin(0);
  nh.check_proplines_dist:SetMax(200); 
  nh.check_proplines_dist:SetDecimals(0);
  nh.check_proplines_dist:SetConVar("nh_prop_tracer_3d_distance");
  
  nh.check_aimbot = vgui.Create("DCheckBoxLabel");
    nh.check_aimbot:SetParent(nh.panel_3);
    nh.check_aimbot:SetPos(ScrW() * (30/ ScrW()), ScrH() * (25/ScrH()));
    nh.check_aimbot:SetValue(math.abs(nh.convars.misc.bhop:GetInt()));
    nh.check_aimbot:SetConVar("nh_aimbot");
    nh.check_aimbot:SetText("AIMBOT");
    nh.check_aimbot:SetTextColor(Color(255, 255, 255, 255));
  
  
  nh.check_aimbot_selection = vgui.Create("DComboBox");
  nh.check_aimbot_selection:SetParent(nh.panel_3);
  nh.check_aimbot_selection:SetPos(ScrW() * (350/ScrW()), ScrH() * (25/ScrH()));
  nh.check_aimbot_selection:SetSize(ScrW() * (150/ScrW()), ScrH() * (25/ScrH()))
  nh.check_aimbot_selection:SetValue(tostring(nh.aimbot_selection[nh.convars.aimbot.aimbot_selection:GetInt()]));
  for i = 1, #nh.aimbot_selection do
    nh.check_aimbot_selection:AddChoice(nh.aimbot_selection[i]);
  end
  
  function nh.check_aimbot_selection.OnSelect(index, name, data)
    nh.convars.aimbot.aimbot_selection:SetInt(tonumber(name));
  end
  
  nh.check_aimbot_bone = vgui.Create("DComboBox");
  nh.check_aimbot_bone:SetParent(nh.panel_3);
  nh.check_aimbot_bone:SetPos(ScrW() * (350/ScrW()), ScrH() * ((25 * 3)/ScrH()));
  nh.check_aimbot_bone:SetSize(ScrW() * (150/ScrW()), ScrH() * (25/ScrH()))
  nh.check_aimbot_bone:SetValue(tostring(nh.convars.aimbot.aimbot_bone:GetString()));
  for k,v in next, nh.bones do
    if(tostring(k) != "default") then
      nh.check_aimbot_bone:AddChoice(tostring(k));
    end
  end
  
  function nh.check_aimbot_bone.OnSelect(index, name, data)
    nh.convars.aimbot.aimbot_bone:SetString(tostring(data));
  end
  
  nh.check_aimbot_ignore_world = vgui.Create("DCheckBoxLabel");
    nh.check_aimbot_ignore_world:SetParent(nh.panel_3);
    nh.check_aimbot_ignore_world:SetPos(ScrW() * (30/ ScrW()), ScrH() * ((25 * 2 - 5)/ScrH()));
    nh.check_aimbot_ignore_world:SetValue(math.abs(nh.convars.aimbot.aimbot_ignore_world:GetInt()));
    nh.check_aimbot_ignore_world:SetConVar("nh_aimbot_ignore_world");
    nh.check_aimbot_ignore_world:SetText("IGNORE WORLD");
    nh.check_aimbot_ignore_world:SetTextColor(Color(255, 255, 255, 255));
  
  nh.check_aimbot_ignore_world = vgui.Create("DCheckBoxLabel");
    nh.check_aimbot_ignore_world:SetParent(nh.panel_3);
    nh.check_aimbot_ignore_world:SetPos(ScrW() * (30/ ScrW()), ScrH() * ((25 * 3 - 10)/ScrH()));
    nh.check_aimbot_ignore_world:SetValue(math.abs(nh.convars.aimbot.silent_aim:GetInt()));
    nh.check_aimbot_ignore_world:SetConVar("nh_silent_aim");
    nh.check_aimbot_ignore_world:SetText("SILENT AIM");
    nh.check_aimbot_ignore_world:SetTextColor(Color(255, 255, 255, 255));
  
    nh.check_aimbot_ignore_world = vgui.Create("DCheckBoxLabel");
    nh.check_aimbot_ignore_world:SetParent(nh.panel_3);
    nh.check_aimbot_ignore_world:SetPos(ScrW() * (30/ ScrW()), ScrH() * ((25 * 4 - 15)/ScrH()));
  nh.check_aimbot_ignore_world:SetValue(math.abs(nh.convars.aimbot.invert_mouse:GetInt()));
    nh.check_aimbot_ignore_world:SetConVar("nh_invertmouse");
    nh.check_aimbot_ignore_world:SetText("INVERT MOUSE");
    nh.check_aimbot_ignore_world:SetTextColor(Color(255, 255, 255, 255));
  
  nh.check_aimbot_key = vgui.Create("DBinder");
  nh.check_aimbot_key:SetParent(nh.panel_3);
  nh.check_aimbot_key:SetSize(ScrW() * (50/ScrW()), ScrH() * (50/ScrH()));
  nh.check_aimbot_key:SetPos(ScrW() * (250/ScrW()), ScrH() * (25/ScrH()));
  nh.check_aimbot_key:SetText(string.upper(input.GetKeyName(nh.convars.aimbot.aimbot_key:GetInt())));
  function nh.check_aimbot_key:SetSelectedNumber(num)
    self.m_iSelectedNumber = num;
    nh.convars.aimbot.aimbot_key:SetInt(num);
  end
  function nh.check_aimbot_key:DoRightClick() end
  
  nh.check_radar_active = vgui.Create("DCheckBoxLabel");
    nh.check_radar_active:SetParent(nh.panel_4);
    nh.check_radar_active:SetPos(ScrW() * (30/ ScrW()), ScrH() * ((25)/ScrH()));
    nh.check_radar_active:SetValue(math.abs(nh.radar.radar_active:GetInt()));
    nh.check_radar_active:SetConVar("nh_radar_active");
    nh.check_radar_active:SetText("RADAR");
    nh.check_radar_active:SetTextColor(Color(255, 255, 255, 255));
  
  nh.check_radar_names = vgui.Create("DCheckBoxLabel");
    nh.check_radar_names:SetParent(nh.panel_4);
    nh.check_radar_names:SetPos(ScrW() * (30/ ScrW()), ScrH() * ((25 * 2 - 5)/ScrH()));
    nh.check_radar_names:SetValue(math.abs(nh.radar.names:GetInt()));
    nh.check_radar_names:SetConVar("nh_radar_names");
    nh.check_radar_names:SetText("RADAR NAMES");
    nh.check_radar_names:SetTextColor(Color(255, 255, 255, 255));
  
  nh.check_radar_distance = vgui.Create("DCheckBoxLabel");
    nh.check_radar_distance:SetParent(nh.panel_4);
    nh.check_radar_distance:SetPos(ScrW() * (30/ ScrW()), ScrH() * ((25 * 3 - 10)/ScrH()));
    nh.check_radar_distance:SetValue(math.abs(nh.radar.distance:GetInt()));
    nh.check_radar_distance:SetConVar("nh_radar_distance");
    nh.check_radar_distance:SetText("RADAR DISTANCE");
    nh.check_radar_distance:SetTextColor(Color(255, 255, 255, 255));
  
  nh.check_radar_lines = vgui.Create("DCheckBoxLabel");
    nh.check_radar_lines:SetParent(nh.panel_4);
    nh.check_radar_lines:SetPos(ScrW() * (30/ ScrW()), ScrH() * ((25 * 4 - 15)/ScrH()));
    nh.check_radar_lines:SetValue(math.abs(nh.radar.toggle_lines:GetInt()));
    nh.check_radar_lines:SetConVar("nh_radar_lines");
    nh.check_radar_lines:SetText("RADAR LINES");
    nh.check_radar_lines:SetTextColor(Color(255, 255, 255, 255));
  
  nh.check_radar_zaxis = vgui.Create("DCheckBoxLabel");
    nh.check_radar_zaxis:SetParent(nh.panel_4);
    nh.check_radar_zaxis:SetPos(ScrW() * (30/ ScrW()), ScrH() * ((25 * 5 - 20)/ScrH()));
    nh.check_radar_zaxis:SetValue(math.abs(nh.radar.zaxis:GetInt()));
    nh.check_radar_zaxis:SetConVar("nh_radar_zaxis");
    nh.check_radar_zaxis:SetText("RADAR ZAXIS");
    nh.check_radar_zaxis:SetTextColor(Color(255, 255, 255, 255));
  
  nh.check_radar_you = vgui.Create("DCheckBoxLabel");
    nh.check_radar_you:SetParent(nh.panel_4);
    nh.check_radar_you:SetPos(ScrW() * (30/ ScrW()), ScrH() * ((25 * 6 - 25)/ScrH()));
    nh.check_radar_you:SetValue(math.abs(nh.radar.draw_your_point:GetInt()));
    nh.check_radar_you:SetConVar("nh_radar_draw_your_point");
    nh.check_radar_you:SetText("RADAR CROSS (YOU)");
    nh.check_radar_you:SetTextColor(Color(255, 255, 255, 255));
  
  nh.check_radar_them = vgui.Create("DCheckBoxLabel");
    nh.check_radar_them:SetParent(nh.panel_4);
    nh.check_radar_them:SetPos(ScrW() * (30/ ScrW()), ScrH() * ((25 * 7 - 30)/ScrH()));
    nh.check_radar_them:SetValue(math.abs(nh.radar.draw_their_point:GetInt()));
    nh.check_radar_them:SetConVar("nh_radar_draw_their_point");
    nh.check_radar_them:SetText("RADAR CROSS (THEM)");
    nh.check_radar_them:SetTextColor(Color(255, 255, 255, 255));
  
  nh.check_radar_zoom = vgui.Create("DNumSlider");
  nh.check_radar_zoom:SetParent(nh.panel_4);
  nh.check_radar_zoom:SetPos(ScrW() * (30/ ScrW()), ScrH() * ((25 * 8 - 35)/ScrH()));
  nh.check_radar_zoom:SetSize(ScrW() * (175/ ScrW()), ScrH() * (30/ScrH()));
  nh.check_radar_zoom:SetValue(math.abs(nh.radar.zoom:GetInt()));
  nh.check_radar_zoom:SetText("RADAR ZOOM");
  nh.check_radar_zoom:SetMin(0);
  nh.check_radar_zoom:SetMax(200); 
  nh.check_radar_zoom:SetDecimals(0);
  nh.check_radar_zoom:SetConVar("nh_radar_zoom");
  
  nh.check_radar_your_point_size = vgui.Create("DNumSlider");
  nh.check_radar_your_point_size:SetParent(nh.panel_4);
  nh.check_radar_your_point_size:SetPos(ScrW() * (30/ ScrW()), ScrH() * ((25 * 9 - 40)/ScrH()));
  nh.check_radar_your_point_size:SetSize(ScrW() * (200/ ScrW()), ScrH() * (30/ScrH()));
  nh.check_radar_your_point_size:SetValue(math.abs(nh.radar.your_point_size:GetInt()));
  nh.check_radar_your_point_size:SetText("UR POINT SIZE");
  nh.check_radar_your_point_size:SetMin(0);
  nh.check_radar_your_point_size:SetMax(25); 
  nh.check_radar_your_point_size:SetDecimals(0);
  nh.check_radar_your_point_size:SetConVar("nh_radar_your_point_size");
  
  nh.check_radar_their_point_size = vgui.Create("DNumSlider");
  nh.check_radar_their_point_size:SetParent(nh.panel_4);
  nh.check_radar_their_point_size:SetPos(ScrW() * (30/ ScrW()), ScrH() * ((25 * 10 - 45)/ScrH()));
  nh.check_radar_their_point_size:SetSize(ScrW() * (225/ ScrW()), ScrH() * (30/ScrH()));
  nh.check_radar_their_point_size:SetValue(math.abs(nh.radar.their_point_size:GetInt()));
  nh.check_radar_their_point_size:SetText("THEIR POINT SIZE");
  nh.check_radar_their_point_size:SetMin(0);
  nh.check_radar_their_point_size:SetMax(25); 
  nh.check_radar_their_point_size:SetDecimals(0);
  nh.check_radar_their_point_size:SetConVar("nh_radar_their_point_size");
  
  nh.check_radar_size = vgui.Create("DNumSlider");
  nh.check_radar_size:SetParent(nh.panel_4);
  nh.check_radar_size:SetPos(ScrW() * (30/ ScrW()), ScrH() * ((25 * 11 - 50)/ScrH()));
  nh.check_radar_size:SetSize(ScrW() * (175/ ScrW()), ScrH() * (30/ScrH()));
  nh.check_radar_size:SetValue(math.abs(nh.radar.radar_size:GetInt()));
  nh.check_radar_size:SetText("RADAR SIZE");
  nh.check_radar_size:SetMin(25);
  nh.check_radar_size:SetMax(800); 
  nh.check_radar_size:SetDecimals(0);
  nh.check_radar_size:SetConVar("nh_radar_size");
  
  nh.check_radar_color = vgui.Create("DColorMixer");
  nh.check_radar_color:SetParent(nh.panel_4);
  nh.check_radar_color:SetPos(ScrW() * ((30 * 12)/ ScrW()), ScrH() * (20/ScrH()));
  nh.check_radar_color:SetSize(ScrW() * (160/ ScrW()), ScrH() * (125/ScrH()));
  nh.check_radar_color:SetPalette(false);
  nh.check_radar_color:SetAlphaBar(false);
  nh.check_radar_color:SetWangs(true);
  nh.check_radar_color:SetColor(Color(nh.radar.box_color_r:GetInt(), nh.radar.box_color_g:GetInt(), nh.radar.box_color_b:GetInt()));
  nh.check_radar_color:SetLabel("RADAR COLORS");
  nh.check_radar_color.label:SetTextColor(Color(255, 255, 255, 255));
  
  timer.Create("idklol_4", 0.01, 0, function()
    nh.get_radar_color = nh.check_radar_color:GetColor();
    nh.radar.box_color_r:SetInt(nh.get_radar_color.r);
    nh.radar.box_color_g:SetInt(nh.get_radar_color.g);
    nh.radar.box_color_b:SetInt(nh.get_radar_color.b);
    nh.check_radar_color:SetColor(Color(nh.radar.box_color_r:GetInt(), nh.radar.box_color_g:GetInt(), nh.radar.box_color_b:GetInt()));
  end);
  
    nh.sheet = vgui.Create("DPropertySheet", nh.frame);
    nh.sheet:SetPos(ScrW() * (20/ScrW()), ScrH() * (30/ScrH()));
    nh.sheet:SetSize(ScrW() * (550/ScrW()), ScrH() * (350/ScrH()));
  
  function nh.sheet:Paint(_, __)
    surface.SetDrawColor(Color(0, 0, 0, 255));
  end
  
    nh.sheet:AddSheet("Visuals", nh.panel, "icon16/zoom.png", false, false, "Visuals tab.");
  nh.sheet:AddSheet("Misc", nh.panel_2, "icon16/zoom.png", false, false, "Misc tab.");
  nh.sheet:AddSheet("Aimbot", nh.panel_3, "icon16/zoom.png", false, false, "Aimbot tab.");
  nh.sheet:AddSheet("Radar", nh.panel_4, "icon16/zoom.png", false, false, "Radar tab.");
  
    for k,v in next, nh.sheet.Items do -- There's literally no documentation anywhere on the wiki on this what-so-ever... Thank you Krippen.
    if(v.Tab) then
      function v.Tab:Paint(w, h)
        surface.SetDrawColor(Color(0, 0, 0, 255));
        surface.DrawRect(0, 0, w, h);
      end
    end
    end
    
end);