--[[************************************************************************
		   _       ____
	____   |      |   /|                  ___|  
	|   |  |___   |  / |  ____   ____    [   |   ___
	|___|  |   |  | /  |  |   |   ___|   [___|  |___|
	|      |   |  |/___|  |   |  [___(_	  ___|  |___
	
	- Coded by ph0ne
	- Credits:
		+ C0BRA - hook.Call detour.
		+ fr1kin - gmcl_ph0nage, generally useful tips/advice/snippets.
		+ noPE - Detouring, autowall.
		+ RabidToaster - Movement correction.
		+ s0beit - SE bypass, general help with Source engine stuff.
		+ stgn - FireBullets detour, Evolve gag bypass.
	- NOTE: If you're reading this, I apologize for the half-assed title.
	
**************************************************************************]]

if not CLIENT then return end
if C then _G.C = nil end -- We don't want to be easily detected.

--[[--------------------------------------------
	INITIALIZATION
--]]--------------------------------------------

local CHEAT     = {}
CHEAT.Settings  = {}
CHEAT.Commands  = {}
CHEAT.Cones     = { normal = {}, hl2 = {} }
CHEAT.ConVars   = {}
CHEAT.Detours   = { _R = {}, lua = {}, protected = { concommand.Run, hook.Call } }
CHEAT.Hooks     = {}
CHEAT.Menu		= { tabs = {}, info = {} }
CHEAT.Meta	    = { lua = { _G, hook, concommand, debug, file }, _R = { "CUserCmd", "Entity", "Player", "ConVar", "Angle", "Vector" } }
CHEAT.World	    = { players = {} }

--[ OPTIMIZATION ]--

local cam				  = cam
local chat				  = chat
local draw				  = draw
local package			  = package
local player			  = player
local math				  = math
local render			  = render
local string			  = string
local surface			  = surface
local table				  = table
local team		 		  = team
local timer				  = timer
local util				  = util
local vgui				  = vgui
local Angle 			  = Angle
local Color 			  = Color
local EyeAngles			  = EyeAngles
local EyePos 			  = EyePos
local ipairs			  = ipairs
local pairs			 	  = pairs
local tobool			  = tobool
local tonumber			  = tonumber
local tostring			  = tostring
local type 				  = type
local Vector 			  = Vector
local MsgN				  = MsgN
local ValidEntity 		  = ValidEntity
local RealFrameTime       = RealFrameTime
local CreateClientConVar  = CreateClientConVar
local SetMaterialOverride = SetMaterialOverride
local CreateMaterial      = CreateMaterial
local AddConsoleCommand   = AddConsoleCommand
local Material			  = Material

--[ RESET METATABLES ]--

function CHEAT:UnlockMeta()
	for i = 1, table.Count( CHEAT.Meta.lua ) do
		rawset( CHEAT.Meta.lua[i], "__metatable", false )
		rawset( CHEAT.Meta.lua[i], "__eq", true )
	end
end
CHEAT:UnlockMeta()

--[ BACKUPS ]--

CHEAT.Copy = {
	concommand	  = table.Copy( concommand ),
	debug		  = table.Copy( debug ),
	file		  = table.Copy( file ),
	hook		  = table.Copy( hook ),
	_G			  = table.Copy( _G ),
	GetInt  	  = _R["ConVar"].GetInt,
	GetBool	 	  = _R["ConVar"].GetBool,
	SetViewAngles = _R["CUserCmd"].SetViewAngles
}

function CHEAT:FillDetouredMeta()
	for i = 1, table.Count( CHEAT.Meta.lua ) do
		CHEAT.Detours.lua[i] = CHEAT.Copy._G.getmetatable( CHEAT.Copy[CHEAT.Meta.lua[i]] )
	end
end
CHEAT:FillDetouredMeta()

--[[--------------------------------------------
	VARS
--]]--------------------------------------------

CHEAT.Vars = {
	osv 		 = 0,
	target		 = nil,
	aimlocked    = false,
	pkfake 	     = false,
	pkthrow 	 = false,
	firing  	 = false,
	found 	     = false,
	aimingang    = Angle( 0, 0, 0 ),
	fakeang 	 = Angle( 0, 0, 0 ),
	pkfakeang    = Angle( 0, 0, 0 ),
	pkthrowang   = Angle( 0, 0, 0 ),
	path 	 	 = "lua\\autorun\\client\\ph0ne.lua",
	prefix	     = "ph0ne_"
}

CHEAT.Files  = { -- Store file names for protection.
	"loader.lua",
	"loader",
	"ph0ne.lua",
	"ph0ne",
	"gmcl_ph0nage.dll",
	"gmcl_ph0nage",
	"ph0nage",
	"gmcl_hake.dll",
	"gmcl_hake",
	"hake",
	"gmcl_sys.dll",
	"gmcl_sys",
	"sys",
	"gmod_cvars_cl.txt",
	"gmod_cvars_cl"
}

--[[--------------------------------------------
	HOOKING AND CONCOMMANDS
--]]--------------------------------------------

--[ HOOKING ]--

local function new_hookCall( name, gm, ... ) -- Thanks C0BRA.
	local ret = nil
	for k, v in pairs( CHEAT.Hooks ) do
		if ( k == name ) then
			if ( ... == nil ) then
				ret = v()
			else
				ret = v( ... )
			end
			if ( ret ~= nil ) then return ret end
		end
	end
	return CHEAT.Copy.hook.Call( name, gm, ... )
end

hook = {}

CHEAT.Copy._G.setmetatable( hook, {
	__index = function( t, k )
		if ( k == "Call" ) then return new_hookCall end
		return CHEAT.Copy.hook[k]
	end,
	__newindex = function( t, k, v )
		if ( k == "Call" ) then
			if ( v ~= new_hookCall ) then CHEAT.Detours.protected.hook.Call = v end
			return
		end
		CHEAT.Copy.hook[k] = v
	end,
	__metatable = true, -- Detouring this way allows me to lock the metatable from further modification.
} )

function CHEAT:AddHook( name, func )
	CHEAT.Hooks[name] = func
end

--[ CONCOMMANDS ]--

local function new_concommandRun( ply, name, ... )
	if CHEAT.Commands[name] then return CHEAT.Commands[name]( ply, name, ... ) end
	return CHEAT.Copy.concommand.Run( ply, name, ... )
end

concommand = {}

CHEAT.Copy._G.setmetatable( concommand, {
	__index = function( t, k )
		if ( k == "Run" ) then return new_concommandRun end
		return CHEAT.Copy.concommand[k]
	end,
	__newindex = function( t, k, v )
		if ( k == "Run" ) then
			if ( v ~= new_concommandRun ) then CHEAT.Detours.protected.concommand.Run = v end
			return
		end
		CHEAT.Copy.concommand[k] = v
	end,
	__metatable = true,
} )

function CHEAT:AddCommand( name, func )
	CHEAT.Commands[name] = func
	AddConsoleCommand( name )
end

--[[--------------------------------------------
	DETOURS
--]]--------------------------------------------

function CHEAT:DetourFunction( old, new ) -- Thanks noPE.
	CHEAT.Detours[new] = old
	return new
end

usermessage.Hook = CHEAT:DetourFunction( usermessage.Hook, function( name, func )
	local blacklist = {
		["shindig"] = true,
		["_ac_fuck"] = true,
		["_ac_cmd"] = true
	}
	if blacklist[string.lower( name )] then return end
	return CHEAT.Detours[usermessage.Hook]( name, func )
end )

require = CHEAT:DetourFunction( require, function( module )
	return CHEAT.Detours[require]( module )
end )

debug.getinfo = CHEAT:DetourFunction( debug.getinfo, function( func, path )
	return CHEAT.Detours[debug.getinfo]( CHEAT.Detours[func] or func, path ) -- Return correct information about any detoured function.
end )

debug.getupvalue = CHEAT:DetourFunction( debug.getupvalue, function( func, int )
	return CHEAT.Detours[debug.getupvalue]( CHEAT.Detours[func] or func, int ) -- Same thing here.
end )

cvars.AddChangeCallback = CHEAT:DetourFunction( cvars.AddChangeCallback, function( cvar, call )
	local callpath = debug.getinfo(2)['short_src']
	if callpath and ( callpath ~= CHEAT.Vars.path ) then
		if CHEAT.ConVars[string.lower( cvar )] then return end
		if CHEAT.Settings[string.lower( cvar )] then return end
	end
	return CHEAT.Detours[cvars.AddChangeCallback]( cvar, call )
end )

cvars.OnConVarChanged = CHEAT:DetourFunction( cvars.OnConVarChanged, function( name, old, new )
	local callpath = debug.getinfo(2)['short_src']
	if callpath and ( callpath ~= CHEAT.Vars.path ) then
		if CHEAT.ConVars[string.lower( name )] then return end
		if CHEAT.Settings[string.lower( name )] then return end
	end
	return CHEAT.Detours[cvars.OnConVarChanged]( name, old, new )
end )

CreateClientConVar = CHEAT:DetourFunction( CreateClientConVar, function( cvar, val, save, def )
	if( CHEAT.ConVars[cvar] ) then return end -- You may not replicate my cvars.
	return CHEAT.detours[CreateClientConVar]( cvar, val, save, def )
end )

GetConVar = CHEAT:DetourFunction( GetConVar, function( cvar )
	local callpath = debug.getinfo(2)['short_src']
	if ( callpath and callpath ~= CHEAT.Vars.path ) then
		if CHEAT.ConVars[string.lower( cvar )] then return end
	end
	return CHEAT.Detours[GetConVar]( cvar )
end )

ConVarExists = CHEAT:DetourFunction( ConVarExists, function( cvar )
	local callpath = debug.getinfo(2)['short_src']
	if ( callpath and callpath ~= CHEAT.Vars.path ) then
		if CHEAT.ConVars[string.lower( cvar )] then return end
	end
	return CHEAT.Detours[ConVarExists]( cvar )
end )

GetConVarNumber = CHEAT:DetourFunction( GetConVarNumber, function( cvar )
	local callpath = debug.getinfo(2)['short_src']
	if ( callpath and callpath ~= CHEAT.Vars.path ) then
		if CHEAT.ConVars[string.lower( cvar )] then return end
	end
	return CHEAT.Detours[GetConVarNumber]( cvar )
end )

GetConVarString = CHEAT:DetourFunction( GetConVarString, function( cvar )
	local callpath = debug.getinfo(2)['short_src']
	if ( callpath and callpath ~= CHEAT.Vars.path ) then
		if CHEAT.ConVars[string.lower( cvar )] then return end
	end
	return CHEAT.Detours[GetConVarString]( cvar )
end )

RunConsoleCommand = CHEAT:DetourFunction( RunConsoleCommand, function( cmd, ... )
	local callpath = debug.getinfo(2)['short_src']
	if ( callpath and callpath ~= CHEAT.Vars.path ) then
		if CHEAT.ConVars[string.lower( cmd )] then return end
		if CHEAT.Commands[string.lower( cmd )] then return end
	end
	return CHEAT.Detours[RunConsoleCommand]( cmd, ... )
end )

_R.Player.ConCommand = CHEAT:DetourFunction( _R.Player.ConCommand, function( ply, cmd, ... )
	local callpath = debug.getinfo(2)['short_src']
	if callpath and ( callpath ~= CHEAT.Vars.path ) then
		if CHEAT.ConVars[string.lower( cmd )] then return end
		if CHEAT.Conmmands[string.lower( cmd )] then return end
	end
	return CHEAT.Detours[_R.Player.ConCommand]( ply, cmd, ... )
end )

_R.ConVar.GetInt = CHEAT:DetourFunction( _R.ConVar.GetInt, function( cvar )
	local callpath = debug.getinfo(2)['short_src']
	if callpath and ( callpath ~= CHEAT.Vars.path ) then
		if CHEAT.ConVars[string.lower( cvar:GetName() )] then return end
	end
	return CHEAT.Detours[_R.ConVar.GetInt]( cvar )
end )

_R.ConVar.GetBool = CHEAT:DetourFunction( _R.ConVar.GetBool, function( cvar )
	local callpath = debug.getinfo(2)['short_src']
	if callpath and ( callpath ~= CHEAT.Vars.path ) then
		if CHEAT.ConVars[string.lower( cvar:GetName() )] then return end
	end
	return CHEAT.Detours[_R.ConVar.GetBool]( cvar )
end )

file.Read = CHEAT:DetourFunction( file.Read, function( path, bool )
	local callpath = debug.getinfo(2)['short_src']
	if callpath and ( callpath ~= CHEAT.Vars.path ) then
		if CHEAT.Files[string.lower( path )] then return nil end
	end
	return CHEAT.Detours[file.Read]( path, bool )
end )

file.Exists = CHEAT:DetourFunction( file.Exists, function( path, bool )
	local callpath = debug.getinfo(2)['short_src']
	if callpath and ( callpath ~= CHEAT.Vars.path ) then
		if CHEAT.Files[string.lower( path )] then return nil end
	end
	return CHEAT.Detours[file.Exists]( path, bool )
end )

file.ExistsEx = CHEAT:DetourFunction( file.ExistsEx, function( path, addons )
	local callpath = debug.getinfo(2)['short_src']
	if callpath and ( callpath ~= CHEAT.Vars.path ) then
		if CHEAT.Files[string.lower( path )] then return nil end
	end
	return CHEAT.Detours[file.ExistsEx]( path, addons )
end )

file.Write = CHEAT:DetourFunction( file.Write, function( path, cont, ... )
	local callpath = debug.getinfo(2)['short_src']
	if callpath and ( callpath ~= CHEAT.Vars.path ) then
		if CHEAT.Files[string.lower( path )] then return nil end
	end
	return CHEAT.Detours[file.Write]( path, cont, ... )
end )

file.Time = CHEAT:DetourFunction( file.Time, function( path )
	local callpath = debug.getinfo(2)['short_src']
	if callpath and ( callpath ~= CHEAT.Vars.path ) then
		if CHEAT.Files[string.lower( path )] then return 0 end
	end
	return CHEAT.Detours[file.Time]( path )
end )

file.Size = CHEAT:DetourFunction( file.Size, function( path )
	local callpath = debug.getinfo(2)['short_src']
	if callpath and ( callpath ~= CHEAT.Vars.path ) then
		if CHEAT.Files[string.lower( path )] then return -1 end
	end
	return CHEAT.Detours[file.Size]( path )
end )

file.Find = CHEAT:DetourFunction( file.Find, function( name )
	local callpath, find = debug.getinfo(2)['short_src'], CHEAT.Detours[file.Find]( name )
	if callpath and ( callpath ~= CHEAT.Vars.path ) then
		for k, v in pairs( find ) do
			for _, e in pairs( CHEAT.Files ) do
				if string.find( string.lower( e ), v ) then find[k] = nil end
			end
		end
	end
	return CHEAT.Detours[file.Find]( name )
end )

file.FindInLua = CHEAT:DetourFunction( file.FindInLua, function( name )
	local callpath, find = debug.getinfo(2)['short_src'], CHEAT.Detours[file.FindInLua]( name )
	if callpath and ( callpath ~= CHEAT.Vars.path ) then
		for k, v in pairs( find ) do
			for _, e in pairs( CHEAT.Files ) do
				if string.find( string.lower( e ), v ) then find[k] = nil end
			end
		end
	end
	return CHEAT.Detours[file.FindInLua]( name )
end )

file.TFind = CHEAT:DetourFunction( file.TFind, function( name, call )
	if debug.getinfo(2)['short_src'] then
		return CHEAT.Detours[file.TFind]( name, function( name, folder, files )
			for k, v in pairs( folder ) do
				for _, e in pairs( CHEAT.Files ) do
					if string.find( string.lower( e ), v ) then folder[k] = nil end
				end
			end
			for k, v in pairs( files ) do
				for _, e in pairs( CHEAT.Files ) do
					if string.find( string.lower( e ), v ) then files[k] = nil end
				end
			end
			return call( path, folder, files )
		end )
	end
	return CHEAT.Detours[file.TFind]( name, function( path, folder, files ) 
		return call( path, folder, files )
	end )
end )

_R.Entity.FireBullets = CHEAT:DetourFunction( _R.Entity.FireBullets, function( ent, bullet ) -- Thanks stgn.
	local ply = LocalPlayer()
	CHEAT.Cones.normal[ply:GetActiveWeapon():GetClass()] = bullet.Spread
	return CHEAT.Detours[_R.Entity.FireBullets]( ent, bullet )
end )

setmetatable = CHEAT:DetourFunction( setmetatable, function( meta, cont )
	for i = 1, table.Count( CHEAT.Meta.lua ) do
		if ( meta == CHEAT.Meta.lua[i] ) then
			CHEAT.Detours.lua[i] = cont
		else
			CHEAT.Detours[setmetatable]( meta, cont )
		end
	end
	return meta
end )

getmetatable = CHEAT:DetourFunction( getmetatable, function( meta, ... )
	for i = 1, table.Count( CHEAT.Meta.lua ) do
		if ( meta == CHEAT.Meta.lua[i] ) then return CHEAT.Detours.lua[i] end
	end
	return CHEAT.Detours[getmetatable]( meta, ... )
end )

debug['setmetatable'] = setmetatable
debug['getmetatable'] = getmetatable

rawequal = CHEAT:DetourFunction( rawequal, function( one, two )
	if CHEAT.Detours[one] and ( tostring( one ) == tostring( two ) ) then return true end -- Make it look like we haven't even detoured anything.
	return CHEAT.Detours[rawequal]( one, two )
end )

rawset = CHEAT:DetourFunction( rawset, function( func, name, val )
	local callpath = debug.getinfo(2)['short_src']
	if callpath and ( callpath ~= CHEAT.Vars.path ) then
		for i = 1, table.Count( CHEAT.Meta.lua ) do
			if ( func == tostring( CHEAT.Meta.lua[i] ) ) then return end -- Prevent others from tampering with our detours.
		end
	end
	return CHEAT.Detours[rawset]( func, name, val )
end )

--[ DETOUR _R ]--

function CHEAT:DetourLuaMeta()
	for i = 1, table.Count( CHEAT.Meta._R ) do
		local var, backup = CHEAT.Meta._R[i], {}
		for k, v in pairs( _R[var] ) do backup[k] = v end -- Backup the metatables.
		backup.__index = backup
		CHEAT.Detours._R[var] = backup -- Store it somewhere.
		CHEAT.Copy._G.setmetatable( _R[var], {
			__index = function( t, k )
				return CHEAT.Detours._R[var][k]
			end,
			__newindex = function( t, k, v )
				return CHEAT.Copy._G.rawset( t, k, v )
			end,
			__metatable = true, -- Lock it.
		} )
	end
end
CHEAT:DetourLuaMeta()

--[[--------------------------------------------
	C++ MODULE
--]]--------------------------------------------

function CHEAT:LoadModule()
	if tobool( #file.Find( "../lua/includes/modules/gmcl_ph0nage.dll" ) ) then
		if not cheat or ( type( cheat ) ~= "table" ) then
			require( "ph0nage" )
			package.loaded.ph0nage = nil
			CHEAT.ph0nage = table.Copy( cheat )
			_G.cheat = nil
			CHEAT.ph0nage.Msg( "\n:: ", Color( 255, 255, 255 ) )
			CHEAT.ph0nage.Msg( "ph0nage initialized, now loading...\n", Color( 255, 0, 0 ) )
		end
	end
end
CHEAT:LoadModule()

--[[--------------------------------------------
	CONVARS
--]]--------------------------------------------

--[ ADD CONVARS ]--

CHEAT.SetVars = {
	{ Name = "aim", Value = 0, Desc = "Aimbot Enabled", Type = "bool", Table = "aim", Menu = "Aimbot" },
	{ Name = "aim_holdtarget", Value = 0, Desc = "Hold Target (NOTE: Saves FPS.)", Type = "bool", Table = "holdtarget", Menu = "Aimbot" },
	{ Name = "aim_type", Value = 1, Table = "aimtype", },
	{ Name = "aim_silent", Value = 1, Desc = "No View Change", Type = "bool", Table = "aimsilent", Menu = "Aimbot" },
	{ Name = "aim_smooth", Value = 0, Desc = "Smooth Aim (NOTE: Disables nospread.)", Type = "bool", Table = "aimsmooth", Menu = "Aimbot" },
	{ Name = "aim_friendlyfire", Value = 1, Desc = "Aim at Teammates", Type = "bool", Table = "aimteam", Menu = "Aimbot" },
	{ Name = "aim_ignoreadmins", Value = 0, Desc = "Ignore Admins", Type = "bool", Table = "ignoreadmins", Menu = "Aimbot" },
	{ Name = "aim_ignoretraitors", Value = 0, Desc = "Ignore Friendly Traitors", Type = "bool", Table = "ignoretraitors", Menu = "Aimbot" },
	{ Name = "aim_ignorefriends", Value = 0, Desc = "Ignore Steam Friends", Type = "bool", Table = "ignorefriends", Menu = "Aimbot" },
	{ Name = "aim_autoshoot", Value = 0, Desc = "Autoshoot", Type = "bool", Table = "autoshoot", Menu = "Aimbot" },
	{ Name = "aim_snaponfire", Value = 0, Desc = "Aim When Firing", Type = "bool", Table = "snaponfire", Menu = "Aimbot" },
	{ Name = "aim_obb", Value = 0, Desc = "Aim at OBBCenter", Type = "bool", Table = "obb", Menu = "Aimbot" },
	{ Name = "aim_antiaim", Value = 0, Desc = "Anti-Aim", Type = "bool", Table = "antiaim", Menu = "Aimbot" },
	{ Name = "aim_antiaim_type", Value = 1, Table = "aatype" },
	{ Name = "aim_nospread", Value = 1, Desc = "Nospread", Type = "bool", Table = "nospread", Menu = "Aimbot" },
	{ Name = "aim_nospread_fire", Value = 1, Desc = "Nospread While Firing (NOTE: Constant while aiming.)", Type = "bool", Table = "nospreadfire", Menu = "Aimbot" },
	{ Name = "aim_autowall", Value = 0, Desc = "Autowall (NOTE: Buggy, works with Mad Cow's weapon base only.)", Type = "bool", Table = "autowall", Menu = "Aimbot" },
	{ Name = "aim_ignorevisibility", Value = 0, Desc = "Ignore Visibility Checks", Type = "bool", Table = "ignorevisibility", Menu = "Aimbot" },
	{ Name = "aim_prediction", Value = 1, Desc = "Prediction", Type = "bool", Table = "prediction", Menu = "Aimbot" },
	{ Name = "aim_prediction_val_tar", Value = 66, Desc = "Target Prediction", Type = "number", Table = "predictiontar", Max = 66, Min = 25, Menu = "Aimbot" },
	{ Name = "aim_prediction_val_ply", Value = 45, Desc = "Local Prediction", Type = "number", Table = "predictionply", Max = 66, Min = 25, Menu = "Aimbot" },
	{ Name = "aim_prediction_type", Value = 1, Table = "predictiontype" },
	{ Name = "aim_offset", Value = 0, Desc = "Offset Y", Type = "number", Table = "aimoffset", Max = 10, Min = -10, Menu = "Aimbot" },
	{ Name = "aim_fov", Value = 180, Desc = "Aimbot FOV", Type = "number", Table = "aimfov", Max = 180, Min = 1, Menu = "Aimbot" },
	{ Name = "aim_smooth_val", Value = 6, Desc = "Smooth Aim Speed", Type = "number", Table = "smoothspeed", Max = 12, Min = 4, Menu = "Aimbot" },
	{ Name = "esp", Value = 1, Desc = "ESP Enabled", Type = "bool", Table = "esp", Menu = "ESP" },
	{ Name = "esp_skeleton", Value = 1, Desc = "Skeleton", Type = "bool", Table = "skeleton", Menu = "ESP" },
	{ Name = "esp_barrel", Value = 1, Desc = "Barrel Hack", Type = "bool", Table = "barrel", Menu = "ESP" },
	{ Name = "esp_info", Value = 1, Desc = "Player Info", Type = "bool", Table = "infoesp", Menu = "ESP" },
	{ Name = "esp_target", Value = 1, Desc = "Target Indicator Line", Type = "bool", Table = "targetesp", Menu = "ESP" },
	{ Name = "esp_admins", Value = 1, Desc = "Admin List", Type = "bool", Table = "adminlist", Menu = "ESP" },
	{ Name = "esp_rpents", Value = 0, Desc = "RP Entities", Type = "bool", Table = "rpesp", Menu = "ESP" },
	{ Name = "esp_tttweps", Value = 0, Desc = "TTT Traitor Weapons", Type = "bool", Table = "traitorwepesp", Menu = "ESP" },
	{ Name = "esp_chams", Value = 1, Desc = "Chams", Type = "bool", Table = "chams", Menu = "ESP" },
	{ Name = "esp_chams_fullbright", Value = 1, Desc = "Render Fullbright", Type = "bool", Table = "renderfullbright", Menu = "ESP" },
	{ Name = "misc_bunnyhop", Value = 0, Desc = "Bunnyhop", Type = "bool", Table = "bhop", Menu = "Misc" },
	{ Name = "misc_ungag", Value = 0, Desc = "ULX/Evolve Ungag", Type = "bool", Table = "ungag", Menu = "Misc" },
	{ Name = "misc_namesteal", Value = 0, Desc = "Namestealer", Type = "bool", Table = "namestealer", Menu = "Misc" },
	{ Name = "misc_crosshair", Value = 1, Desc = "Crosshair", Type = "bool", Table = "crosshair", Menu = "Misc" },
	{ Name = "misc_calcview", Value = 1, Desc = "Enable CalcView", Type = "bool", Table = "calcview", Menu = "Misc" },
	{ Name = "misc_fullbright", Value = 0, Desc = "Enable Fullbright", Type = "bool", Table = "fullbright", Menu = "Misc" },
	{ Name = "misc_cmdspam", Value = 0, Desc = "Command Spam", Type = "bool", Table = "spam", Menu = "Misc" },
	{ Name = "misc_cmdspam_cmd", Value = "", Table = "cmdtospam" },
	{ Name = "misc_speed", Value = 1, Desc = "Speedhack Value", Type = "number", Table = "speed", Max = 8, Min = 1, Menu = "Misc" }
}

--[ CREATE CONVARS ]--

function CHEAT:CreateConVars()
	for i = 1, table.Count( CHEAT.SetVars ) do
		local v = CHEAT.SetVars[i]
		local pvar = CHEAT.Vars.prefix .. v.Name
		local convar = CHEAT.Detours[CreateClientConVar]( pvar, v.Value, true, false )
		local cvarinfo = {
			Name  = pvar,
			Value = v.Value,
			Desc  = v.Desc,
			Type  = v.Type,
			Max   = v.Max,
			Min   = v.Min,
			Menu  = v.Menu
		}
		if ( type( v.Value ) == "number" ) then
			CHEAT.Settings[v.Table] = convar:GetInt() -- Store a value for our callback table. This increases performance.
		else
			CHEAT.Settings[v.Table] = convar:GetString()
		end
		CHEAT.Menu.info[pvar] = cvarinfo
		CHEAT.Menu.info[#CHEAT.Menu.info + 1] = cvarinfo
		CHEAT.Detours[cvars.AddChangeCallback]( pvar, function( cvar, old, new )
			CHEAT.Settings[v.Table] = new -- If our cvar value changes, then so does our callback table.
		end )
		CHEAT.ConVars[pvar] = convar
	end
end
CHEAT:CreateConVars()

CHEAT.ph0nage.Msg( ":: ", Color( 255, 255, 255 ) )
CHEAT.ph0nage.Msg( "Convars created.\n", Color( 255, 0, 0 ) )

--[ CVAR VALUE CHECK ]--

function CHEAT:G( name, val )
	if ( tonumber( name ) == val ) then return true end
	return false
end

--[ CVAR HIDING ]--

CHEAT.OriginalVars = {
	{ "sv_cheats", FCVAR_NOTIFY | FCVAR_REPLICATED | FCVAR_CHEAT, "0" },
	{ "host_timescale", FCVAR_NOTIFY | FCVAR_REPLICATED | FCVAR_CHEAT, "1.0" },
	{ "r_drawothermodels", FCVAR_CLIENTDLL | FCVAR_CHEAT, "1" },
	{ "mat_fullbright", FCVAR_CHEAT, "0" },
	{ "sv_consistency", FCVAR_REPLICATED, "1" },
	{ "sv_allow_voice_from_file", FCVAR_REPLICATED, "1" },
	{ "voice_inputfromfile", FCVAR_NONE, "0" },
	{ "fog_enable", FCVAR_CLIENTDLL | FCVAR_CHEAT, "1" },
	{ "fog_enable_water_fog", FCVAR_CHEAT, "1" }
}

function CHEAT:HideCvars()
	for i = 1, table.Count( CHEAT.OriginalVars ) do
		local cvar = CHEAT.OriginalVars[i]
		local pvar = CHEAT.Vars.prefix .. cvar[1]
		if not ConVarExists( pvar ) then -- Run only once.
			CHEAT.ph0nage.ReplicateVar( cvar[1], pvar, cvar[2], cvar[3] )
			CreateConVar( cvar[1], cvar[3], cvar[2] ) -- ReplicateVar doesn't keep the original, so we have to recreate it.
			CHEAT.ConVars[pvar] = pvar
		end
	end
	CHEAT.ph0nage.RunCommand( CHEAT.Vars.prefix .. "sv_cheats 1" ) -- Set some defaults.
	CHEAT.ph0nage.RunCommand( CHEAT.Vars.prefix .. "sv_consistency 0" ) -- g_pEngine->ClientCmd is great since RunConsoleCommand is restricted.
	CHEAT.ph0nage.RunCommand( CHEAT.Vars.prefix .. "fog_enable 0" ) -- Anticheats can kiss my ass.
	CHEAT.ph0nage.RunCommand( CHEAT.Vars.prefix .. "fog_enable_water_fog 0" ) -- Thank you P47R!CK and syntroniks.
end
CHEAT:HideCvars()

--[ CVAR FORCING ]--

function CHEAT.FullBright()
	if CHEAT:G( CHEAT.Settings['fullbright'], 1 ) then
		CHEAT.ph0nage.RunCommand( CHEAT.Vars.prefix .. "mat_fullbright 1" )
	elseif CHEAT:G( CHEAT.Settings['fullbright'], 0 ) then
		CHEAT.ph0nage.RunCommand( CHEAT.Vars.prefix .. "mat_fullbright 0" )
	end
end

function CHEAT.SpeedOn()
	if ( GetConVarNumber( "ph0ne_sv_cheats" ) == 1 ) then
		CHEAT.ph0nage.RunCommand( CHEAT.Vars.prefix .. "host_timescale " .. tonumber( CHEAT.Settings['speed'] ) )
	else
		chat.AddText(
			Color( 255, 0, 0 ), ":: ",
			Color( 255, 255, 255 ), "ConVar ",
			Color( 255, 0, 0 ), CHEAT.Vars.prefix .. "sv_cheats ",
			Color( 255, 255, 255 ), "must be enabled to use speedhack."
		)
	end
end
CHEAT:AddCommand( "+ph0ne_speed", CHEAT.SpeedOn )

function CHEAT.SpeedOff()
	CHEAT.ph0nage.RunCommand( CHEAT.Vars.prefix .. "host_timescale 1.0" )
end
CHEAT:AddCommand( "-ph0ne_speed", CHEAT.SpeedOff )

--[[--------------------------------------------
	UTIL FUNCTIONS
--]]--------------------------------------------

--[ CHECKS ]--

function CHEAT:IsAdmin( e )
	if e:IsSuperAdmin() then return true end
	if e:IsAdmin() then return true end
	return false
end

function CHEAT:IsFriend( e )
	if ( e:GetFriendStatus() == "friend" ) then return true end
	return false
end

function CHEAT:IsTTT()
	if string.find( string.lower( GAMEMODE.Name ), "trouble in terror" ) then return true end
	return false
end

function CHEAT:IsTraitor( e )
	local ply = LocalPlayer()
	if not CHEAT:IsTTT() then return end
	if ply:IsTraitor() and e:IsTraitor() then return true end
	return false
end

function CHEAT:IsOnScreen( e ) -- Thanks fr1kin.
	local x, y, positions = ScrW(), ScrH(), { "OBBCenter", "OBBMaxs", "OBBMins" }
	for i = 1, table.Count( positions ) do
		local v = positions[i]
		local pos = e:LocalToWorld( _R.Entity[v]( e ) ):ToScreen()
		if ( pos.x > 0 ) and ( pos.y > 0 ) and ( pos.x < x ) and ( pos.y < y ) then return true end
	end
	return false
end

function CHEAT:TargetValid( e, typ )
	local ply, str, fov = LocalPlayer(), tostring( typ ), tonumber( CHEAT.Settings['aimfov'] )
	if ( str == "aim" ) then
		if not ValidEntity( e ) or ( ply == e ) then return false end
		if not e:Alive() then return false end
		if CHEAT.ph0nage.IsDormant( e:EntIndex() ) then return false end
		if CHEAT:IsAdmin( e ) and CHEAT:G( CHEAT.Settings['ignoreadmins'], 1 ) then return false end
		if CHEAT:IsTraitor( e ) and CHEAT:G( CHEAT.Settings['ignoretraitors'], 1 ) then return false end
		if CHEAT:IsFriend( e ) and CHEAT:G( CHEAT.Settings['ignorefriends'], 1 ) then return false end
		if ( e:Team() == ply:Team() ) and CHEAT:G( CHEAT.Settings['aimteam'], 0 ) then return false end
		if string.find( string.lower( team.GetName( e:Team() ) ), "spec" ) then return false end	
		if ( e:GetMoveType() == MOVETYPE_NONE ) then return false end
		if ( e:GetMoveType() == MOVETYPE_OBSERVER ) then return false end
		if ( fov ~= 180 ) then
			local ang = ply:GetAimVector():Angle()
			if CHEAT:G( CHEAT.Settings['aimsilent'], 1 ) then ang = CHEAT.Vars.fakeang end
			local aim = ( CHEAT:GetTargetLocation( e ) - ply:GetShootPos() ):Angle()
			local yaw = math.abs( math.NormalizeAngle( ang.y - aim.y ) )
			local pitch = math.abs( math.NormalizeAngle( ang.p - aim.p ) )
			if ( yaw > fov ) or ( pitch > fov ) then return false end
		end
		return true
	elseif ( str == "esp" ) then
		if not ValidEntity( e ) or ( ply == e ) then return false end
		if not e:Alive() then return false end
		if CHEAT.ph0nage.IsDormant( e:EntIndex() ) then return false end
		if string.find( string.lower( team.GetName( e:Team() ) ), "spec" ) then return false end
		if ( e:GetMoveType() == MOVETYPE_NONE ) then return false end
		if ( e:GetMoveType() == MOVETYPE_OBSERVER ) then return false end
		if not CHEAT:IsOnScreen( e ) then return false end
		return true
	elseif ( str == "chams" ) then -- For coloring based on aimbot targets.
		if not ValidEntity( e ) or ( ply == e ) then return false end
		if not e:Alive() then return false end
		if CHEAT:IsAdmin( e ) and CHEAT:G( CHEAT.Settings['ignoreadmins'], 1 ) then return false end
		if CHEAT:IsTraitor( e ) and CHEAT:G( CHEAT.Settings['ignoretraitors'], 1 ) then return false end
		if CHEAT:IsFriend( e ) and CHEAT:G( CHEAT.Settings['ignorefriends'], 1 ) then return false end
		if ( e:Team() == ply:Team() ) and CHEAT:G( CHEAT.Settings['aimteam'], 0 ) then return false end
		if string.find( string.lower( team.GetName( e:Team() ) ), "spec" ) then return false end	
		if ( e:GetMoveType() == MOVETYPE_NONE ) then return false end
		if ( e:GetMoveType() == MOVETYPE_OBSERVER ) then return false end
		return true
	end
	return false
end

function CHEAT:ResetAim()
	if CHEAT:G( CHEAT.Settings['aimsilent'], 1 ) then return true end
	if CHEAT:G( CHEAT.Settings['antiaim'], 1 ) then return true end
	if CHEAT:G( CHEAT.Settings['nospreadfire'], 1 ) then return true end
	return false
end

--[ OTHER ]--

function CHEAT:GetPlayerColor( e )
	local vis, invis
	if CHEAT:TargetValid( e, "chams" ) then
		vis = Color( 255, 255, 0, 255 )
		invis = Color( 255, 0, 0, 255 )
	else
		vis = Color( 0, 255, 0, 255 )
		invis = Color( 0, 0, 255, 255 )
	end
	return vis, invis
end

function CHEAT:GetStatusColor( e )
	local pos = CHEAT:GetTargetLocation( e ):ToScreen()
	local statuscol = Color( 255, 255, 255, 255 )
	if CHEAT:IsFriend( e ) then
		statuscol = Color( 0, 255, 0, 255 )
	elseif CHEAT:IsAdmin( e ) then
		statuscol = Color( 255, 255, 0, 255 )
	elseif CHEAT:IsTraitor( e ) and CHEAT:IsTTT() then
		statuscol = Color( 255, 0, 0, 255 )
	else
		statuscol = Color( 255, 255, 255, 255 )
	end
	return statuscol
end

function CHEAT:NormalizeAngle( ang )
	return Angle( math.NormalizeAngle( ang.p ), math.NormalizeAngle( ang.y ), 0 )
end

function CHEAT:ClampAngle( cmd, ang )
	ang.p = math.Clamp( ang.p + ( cmd:GetMouseY() * 0.022 ), -89, 90 )
	ang.y = math.NormalizeAngle( ang.y + ( cmd:GetMouseX() * -0.022 ) )
	return ang
end

--[[--------------------------------------------
	NOSPREAD
--]]--------------------------------------------

--[ HL2 CONES ]--

CHEAT.Cones.hl2["weapon_smg1"]    = Vector( -0.04362, -0.04362, -0.04362 )
CHEAT.Cones.hl2["weapon_pistol"]  = Vector( -0.0100, -0.0100, -0.0100 )
CHEAT.Cones.hl2["weapon_ar2"]	  = Vector( -0.02618, -0.02618, -0.02618 )
CHEAT.Cones.hl2["weapon_shotgun"] = Vector( -0.08716, -0.08716, -0.08716 )

--[ MANUPULATE SHOT ]--

function CHEAT:PredictSpread( cmd, angle )
	local ply, cone = LocalPlayer(), Vector( 0, 0, 0 )
	local ang = ( angle or ply:GetAimVector():Angle() ):Forward()
	local wep = ply:GetActiveWeapon()
	if ply:Alive() and wep and ValidEntity( wep ) then
		local class = wep:GetClass()
		if not CHEAT.Cones.hl2[class] then
			if CHEAT.Cones.normal[class] then
				cone = Vector( 0, 0, 0 ) - CHEAT.Cones.normal[class] or Vector( 0, 0, 0 )
				return CHEAT.ph0nage.PredictSpread( cmd, ang, cone ):Angle()
			end
		else
			cone = CHEAT.Cones.hl2[class] or Vector( 0, 0, 0 )
			return CHEAT.ph0nage.PredictSpread( cmd, ang, cone ):Angle()
		end
	end
	return Angle( angle.p, angle.y, 0 ) -- If something fucks up we can just return the original angle.
end

--[[--------------------------------------------
	AIMBOT
--]]--------------------------------------------

--[ TARGET LOCATION ]--

CHEAT.Headcrab = {
	["models/headcrabclassic.mdl"] = "HeadcrabClassic.SpineControl",
	["models/headcrabblack.mdl"] = "HCBlack.body",
	["models/headcrab.mdl"] = "HCFast.body"
}

function CHEAT:GetPosition( e, pos, typ )
	if ( tostring( typ ) == "att" ) then
		return e:GetAttachment( e:LookupAttachment( pos ) )
	elseif ( tostring( typ ) == "bone" ) then
		return e:GetBonePosition( e:LookupBone( pos ) )
	end
end

function CHEAT:GetTargetSpot( e )
	if CHEAT:G( CHEAT.Settings['obb'], 1 ) then return e:LocalToWorld( e:OBBCenter() ) end
	for k, v in pairs( CHEAT.Headcrab ) do
		if ( k == e:GetModel() ) then CHEAT:GetPosition( e, v, "bone" ) end
	end
	if ( e:LookupAttachment( "forward" ) ~= 0 ) then -- CSS models.
		local forward = CHEAT:GetPosition( e, "forward", "att" )
		if forward and forward.Pos then return forward.Pos end
	end
	if ( e:LookupAttachment( "eyes" ) ~= 0 ) then -- General humanoid models.
		local eyes = CHEAT:GetPosition( e, "eyes", "att" )
		if eyes and eyes.Pos then return eyes.Pos end
	end
	if ( e:LookupAttachment( "head" ) ~= 0 ) then -- General humanoid models 2.
		local head = CHEAT:GetPosition( e, "head", "att" )
		if head and head.Pos then return head.Pos end
	end
	if e:LookupBone( "ValveBiped.Bip01_Head1" ) then -- Backup head position (using bones sucks big dick).
		return CHEAT:GetPosition( e, "ValveBiped.Bip01_Head1", "bone" )
	end
	return e:LocalToWorld( e:OBBCenter() ) -- Anything else.
end

function CHEAT:Crossbow( e, pos )
	local ply = LocalPlayer()
	if ValidEntity( e ) and ( type( e:GetVelocity() ) == "Vector" ) then
		local dist = e:GetPos():Distance( ply:GetPos() )
		local wep = ply:GetActiveWeapon()
		if wep and ValidEntity( wep ) and ( wep:GetClass() == "weapon_crossbow" ) then
			local predicted = dist / 3110
			return ( pos + e:GetVelocity() * predicted )
		end
		return pos
	end
	return pos
end

function CHEAT:GetTargetLocation( e )
	return CHEAT:Crossbow( e, CHEAT:GetTargetSpot( e ) )
end

--[ PREDICTION ]--

function CHEAT:GetPredictionPos( e )
	local ply = LocalPlayer()
	if CHEAT:G( CHEAT.Settings['prediction'], 1 ) then
		local vc1 =  tonumber( CHEAT.Settings['predictiontar'] )
		local vc2 =  tonumber( CHEAT.Settings['predictionply'] )
		local tv, pv = e:GetVelocity(), ply:GetVelocity()
		if CHEAT:G( CHEAT.Settings['predictiontype'], 1 ) then -- Static.
			return ( tv / vc1 ) - ( pv / vc2 )
		elseif CHEAT:G( CHEAT.Settings['predictiontype'], 2 ) then -- Framerate.
			local frame1 = RealFrameTime() / vc1
			local frame2 = RealFrameTime() / vc2
			return ( tv * frame1 ) - ( pv * frame2 )
		elseif CHEAT:G( CHEAT.Settings['predictiontype'], 3 ) then
			return CHEAT.ph0nage.LagCompensation( CHEAT:GetTargetLocation( e ) )
		end
	else
		return Vector( 0, 0, 0 )
	end
end

--[ AUTOWALL ]--

function CHEAT:IsPenetrable( tr )
	local ply, maxpenetration = LocalPlayer(), 16
	local wep = ply:GetActiveWeapon()
	if ( wep.Base == "weapon_mad_base" ) then -- The only widely used weapon base with penetration capability.
		if ( wep.Primary.Ammo == "AirboatGun" ) then -- 5.56mm
			maxpenetration = 18
		elseif ( wep.Primary.Ammo == "Gravity" ) then -- 4.6mm
			maxpenetration = 8
		elseif ( wep.Primary.Ammo == "AlyxGun" ) then -- 5.7mm
			maxpenetration = 12
		elseif ( wep.Primary.Ammo == "Battery" ) then -- 9mm
			maxpenetration = 14
		elseif ( wep.Primary.Ammo == "StriderMinigun" ) or ( wep.Primary.Ammo == "CombineCannon" ) then -- 7.62mm and .50AE respectively.
			maxpenetration = 20
		elseif ( wep.Primary.Ammo == "SniperPenetratedRound" ) then -- .45ACP
			maxpenetration = 16
		else
			maxpenetration = 16
		end
		if not tr.Entity:IsPlayer() then -- Don't ignore what we want to aim at.
			if ( ( tr.MatType == MAT_METAL ) and wep.Ricochet ) or ( tr.MatType == MAT_SAND ) then return false end -- Not penetrable.
			local direction = tr.Normal * maxpenetration
			local surfaces = { MAT_GLASS, MAT_PLASTIC, MAT_WOOD, MAT_FLESH, MAT_ALIENFLESH }
			for i = 1, table.Count( surfaces ) do
				if ( tr.MatType == surfaces[i] ) then direction = tr.Normal * ( maxpenetration * 2 ) end
			end
			local trace = util.TraceLine( {
				start = tr.HitPos + direction,
				endpos = tr.HitPos,
				filter = { wep.Owner },
				mask = MASK_SHOT
			} )
			if trace.StartSolid or ( trace.Fraction >= 1.0 ) or ( tr.Fraction <= 0.0 ) then return false end -- Bullet didn't penetrate.
		end
	else
		return false
	end
	return true
end

--[ VISIBILITY CHECK ]--

function CHEAT:TargetVisible( e )
	local ply = LocalPlayer()
	if CHEAT:G( CHEAT.Settings['ignorevisibility'], 1 ) then return true end
	local trace = util.TraceLine( {
		start = ply:GetShootPos(),
		endpos = CHEAT:GetTargetLocation( e ) + CHEAT:GetPredictionPos( e ),
		filter = { ply, e },
		mask = MASK_SHOT + CONTENTS_WINDOW
	} )
	if ( trace.Fraction >= 0.99 ) or ( CHEAT:G( CHEAT.Settings['autowall'], 1 ) and CHEAT:IsPenetrable( trace ) ) then return true end
	return false
end

function CHEAT:GetEyeTrace()
	local ply = LocalPlayer()
	local trace = util.TraceLine( {
		start = ply:GetShootPos(),
		endpos = ply:GetShootPos() + ( ply:GetAimVector() * 16384 ),
		filter = { ply },
		mask = MASK_SHOT
	} )
	return trace
end

--[ CLOSEST-TO-CROSSHAIR TARGETING ]--

function CHEAT:GetAimTarget()
	if CHEAT:G( CHEAT.Settings['triggerbot'], 1 ) then return nil end
	if CHEAT:G( CHEAT.Settings['holdtarget'], 1 ) then
		if CHEAT:TargetValid( CHEAT.Vars.target, "aim" ) and CHEAT:TargetVisible( CHEAT.Vars.target ) then
			return CHEAT.Vars.target
		else
			CHEAT.Vars.target = nil
		end
	end
	local ply, tar = LocalPlayer(), { 0, 0 } -- SlobBot sorting.
	if CHEAT:G( CHEAT.Settings['aim'], 1 ) then
		for i = 1, table.Count( CHEAT.World.players ) do
			local e = CHEAT.World.players[i]
			if CHEAT:TargetValid( e, "aim" ) and CHEAT:TargetVisible( e ) then
				local pos = CHEAT:GetTargetLocation( e ) + CHEAT:GetPredictionPos( e )
				local d = math.deg( math.acos( ply:GetAimVector():Dot( ( pos - ply:GetShootPos() ):GetNormal() ) ) ) -- AA:AngleBetween.
				if ( d < tar[2] ) or ( tar[1] == 0 ) then -- Check if our distance is shorter than prevously, or if we haven't acquired a target yet.
					tar = { e, d }
				end
			end
		end
	end
	return ( ( tar[1] ~= 0 ) and ( tar[1] ~= ply ) and tar[1] ) or nil
end

--[ SMOOTH AIM ]--

function CHEAT:GetSmoothAngle( ang )
	local ply = LocalPlayer()
	local smoothang = Angle( 0, 0, 0 )
	if CHEAT:G( CHEAT.Settings['aimsmooth'], 1 ) then
		local speed = RealFrameTime() / ( tonumber( CHEAT.Settings['smoothspeed'] ) / 100 )
		smoothang = LerpAngle( speed, ply:GetAimVector():Angle(), ang )
	else
		return Angle( ang.p, ang.y, 0 )
	end
	return Angle( smoothang.p, smoothang.y, 0 )
end

--[ KEEP ANGLES ]--

function CHEAT.OnToggled()
	local ply = LocalPlayer()
	if not ValidEntity( ply ) then return end
	CHEAT.Vars.fakeang = ply:EyeAngles()
end
CHEAT:AddHook( "OnToggled", CHEAT.OnToggled )

--[ AIMBOT ]--

function CHEAT.Aimbot( cmd )
	local ply, tar = LocalPlayer(), CHEAT:GetAimTarget()
	local wep = ply:GetActiveWeapon()
	CHEAT.Vars.fakeang = CHEAT:NormalizeAngle( CHEAT.Vars.fakeang )
	CHEAT.Vars.fakeang = CHEAT:ClampAngle( cmd, CHEAT.Vars.fakeang )
	if CHEAT:ResetAim() then
		CHEAT.Copy.SetViewAngles( cmd, CHEAT.Vars.fakeang )
	end
	if CHEAT:G( CHEAT.Settings['nospread'], 1 ) and CHEAT:G( CHEAT.Settings['nospreadfire'], 1 ) and cmd:KeyDown( IN_ATTACK ) then
		local spread = CHEAT:PredictSpread( cmd, CHEAT.Vars.fakeang )
		spread = CHEAT:NormalizeAngle( spread )
		CHEAT.Copy.SetViewAngles( cmd, spread )
	end
	if CHEAT:G( CHEAT.Settings['aimtype'], 1 ) and CHEAT:G( CHEAT.Settings['aim'], 1 ) and ply:Alive() and tar then
		CHEAT.Vars.target = tar
		CHEAT.Vars.found = true
		local pos = ( CHEAT:GetTargetLocation( tar ) + CHEAT:GetPredictionPos( tar ) ) + Vector( 0, 0, tonumber( CHEAT.Settings['aimoffset'] ) )
		local ang = ( pos - ply:GetShootPos() ):Angle()
		CHEAT.Vars.aimingang = ang
		ang = CHEAT:GetSmoothAngle( ang )
		if CHEAT:G( CHEAT.Settings['nospread'], 1 ) and CHEAT:G( CHEAT.Settings['aimsmooth'], 0 ) then
			ang = CHEAT:PredictSpread( cmd, ang )
		end
		ang = CHEAT:NormalizeAngle( ang )
		if CHEAT:G( CHEAT.Settings['snaponfire'], 1 ) then
			if cmd:KeyDown( IN_ATTACK ) then
				CHEAT.Copy.SetViewAngles( cmd, ang )
				CHEAT.Vars.aimlocked = true
			else
				CHEAT.Vars.aimlocked = false
			end
		else
			CHEAT.Copy.SetViewAngles( cmd, ang )
			CHEAT.Vars.aimlocked = true
		end
	elseif CHEAT:G( CHEAT.Settings['aimtype'], 2 ) and CHEAT:G( CHEAT.Settings['aim'], 1 ) then
		if CHEAT:TargetValid( CHEAT:GetEyeTrace().Entity, "aim" ) and CHEAT:GetEyeTrace().Hit then
			CHEAT.Vars.aimlocked = true
			CHEAT.ph0nage.RunCommand( "+attack" )
			timer.Simple( ( wep.Primary and wep.Primary.Delay ) or 0.05, function()
				CHEAT.ph0nage.RunCommand( "-attack" )
			end )
		else
			CHEAT.Vars.aimlocked = false
		end
	else
		CHEAT.Vars.target = nil
		CHEAT.Vars.aimlocked = false
		CHEAT.Vars.found = false
	end
	if CHEAT:G( CHEAT.Settings['aimsilent'], 1 ) and CHEAT.Vars.aimlocked then
		local move = Vector( cmd:GetForwardMove(), cmd:GetSideMove(), 0 )
		local norm = move:GetNormal()
		local set = ( norm:Angle() + ( CHEAT.Vars.aimingang - CHEAT.Vars.fakeang ) ):Forward() * move:Length()
		cmd:SetForwardMove( set.x )
		cmd:SetSideMove( set.y )
	end
end

function CHEAT:Autoshoot( cmd )
	if not CHEAT:G( CHEAT.Settings['aim'], 1 ) then return end
	if not CHEAT.Vars.found or not CHEAT.Vars.aimlocked then return end
	if CHEAT:G( CHEAT.Settings['autoshoot'], 1 ) and CHEAT:G( CHEAT.Settings['snaponfire'], 0 ) and not CHEAT.Vars.firing then
		if CHEAT:G( CHEAT.Settings['aimsmooth'], 1 ) then
			local e = ply:GetEyeTrace().Entity
			if CHEAT:TargetValid( e, "aim" ) then
				CHEAT.ph0nage.RunCommand( "+attack" )
				CHEAT.Vars.firing = true
				timer.Simple( ( wep.Primary and wep.Primary.Delay ) or 0.05, function()
					CHEAT.ph0nage.RunCommand( "-attack" )
					CHEAT.Vars.firing = false
				end )
			end
		else
			CHEAT.ph0nage.RunCommand( "+attack" )
			CHEAT.Vars.firing = true
			timer.Simple( ( wep.Primary and wep.Primary.Delay ) or 0.05, function()
				CHEAT.ph0nage.RunCommand( "-attack" )
				CHEAT.Vars.firing = false
			end )
		end
	end
end

--[[--------------------------------------------
	PROPKILLING
--]]--------------------------------------------

--[ COMMANDS ]--

function CHEAT.PropkillOn()
	if not CHEAT:IsTTT() then return end
	if CHEAT:G( CHEAT.Settings['aimsilent'], 1 ) then
		CHEAT.Vars.osv = 1
	else
		CHEAT.Vars.osv = 0
	end
	CHEAT.ph0nage.RunCommand( CHEAT.Vars.prefix .. "aim_silent 0" )
	CHEAT.Vars.pkfake = true
end
CHEAT:AddCommand( "+ph0ne_pk", CHEAT.PropkillOn )

function CHEAT.PropkillOff()
	if not CHEAT:IsTTT() then return end
	CHEAT.Vars.pkfake = false
	CHEAT.Vars.pkthrow = true
	if CHEAT:G( CHEAT.Settings['aimsilent'], 0 ) then
		if ( CHEAT.Vars.osv == 1 ) then
			CHEAT.ph0nage.RunCommand( CHEAT.Vars.prefix .. "aim_silent 1" )
		else
			CHEAT.ph0nage.RunCommand( CHEAT.Vars.prefix .. "aim_silent 0" )
		end
	end
end
CHEAT:AddCommand( "-ph0ne_pk", CHEAT.PropkillOff )

--[ TURN PLAYER 180 ]--

function CHEAT.TTTPropkill( cmd )
	local ply = LocalPlayer()
	if CHEAT:IsTTT() then
		if CHEAT.Vars.pkfake and not CHEAT.Vars.pkthrow then
			CHEAT.Vars.pkthrowang = cmd:GetViewAngles()
			CHEAT.Vars.pkfakeang = CHEAT.Vars.pkthrowang - Angle( 0, 180, 0 )
			local move = Vector( cmd:GetForwardMove(), cmd:GetSideMove(), 0 )
			local norm = move:GetNormal()
			local ang = ply:GetAimVector():Angle()
			if CHEAT:G( CHEAT.Settings['aimsilent'], 1 ) then ang = CHEAT.Vars.fakeang end
			local set = ( norm:Angle() + ( CHEAT.Vars.pkfakeang - ang ) ):Forward() * move:Length()
			cmd:SetForwardMove( set.x )
			cmd:SetSideMove( set.y )
		elseif not CHEAT.Vars.pkfake and CHEAT.Vars.pkthrow then
			CHEAT.Vars.pkthrow = false
			CHEAT.Copy.SetViewAngles( cmd, CHEAT.Vars.pkfakeang )
			if CHEAT:G( CHEAT.Settings['aimsilent'], 1 ) then
				CHEAT.Vars.fakeang = CHEAT.Vars.pkfakeang
				CHEAT.Copy.SetViewAngles( cmd, CHEAT.Vars.fakeang )
			end
		else
			CHEAT.Vars.pkthrowang = cmd:GetViewAngles()
			CHEAT.Vars.pkfakeang = CHEAT.Vars.pkthrowang
		end
	end
end

--[[--------------------------------------------
	BUNNYHOPPING
--]]--------------------------------------------
	
function CHEAT.Bunnyhop( cmd )	
	local ply = LocalPlayer()
	if CHEAT:G( CHEAT.Settings['bhop'], 1 ) then
		if ( ply:GetMoveType() ~= MOVETYPE_WALK ) then return end
		if ply and cmd:KeyDown( IN_JUMP ) then
			if ply:IsOnGround() then
				cmd:SetButtons( cmd:GetButtons() | IN_JUMP )
			else
				cmd:SetButtons( cmd:GetButtons() - IN_JUMP )
			end
		end
	end
end

--[[--------------------------------------------
	ANTI-AIM
--]]--------------------------------------------

function CHEAT.AntiAim( cmd )
	local ply = LocalPlayer()
	if not ply:Alive() then return end
	if cmd:KeyDown( IN_ATTACK | IN_ATTACK2 | IN_USE ) then return end
	if ( ply:GetMoveType() ~= MOVETYPE_WALK ) then return end
	if CHEAT.Vars.aimlocked or CHEAT.Vars.pkfake then return end
	if CHEAT:G( CHEAT.Settings['antiaim'], 1 ) then
		if CHEAT:G( CHEAT.Settings['aatype'], 1 ) then
			CHEAT.ph0nage.FakeAngles( cmd, 205, 180 )
		elseif CHEAT:G( CHEAT.Settings['aatype'], 2 ) then
			CHEAT.ph0nage.AntiAim( cmd, 1 )
		end
	end
end

--[[--------------------------------------------
	CALCVIEW
--]]--------------------------------------------

function CHEAT.CalcView( e, origin, angles )
	local ply = LocalPlayer()
	local wep = ply:GetActiveWeapon()
	if wep.Primary then wep.Primary.Recoil = 0 end
	if wep.Secondary then wep.Secondary.Recoil = 0 end
	local view = GAMEMODE:CalcView( e, origin, angles ) or {} -- The gun model moves wildly.
	if CHEAT:G( CHEAT.Settings['calcview'], 1 ) then
		view.angles.r = 0
		if CHEAT.Vars.pkfake and CHEAT:IsTTT() then
			view.angles = CHEAT.Vars.pkfakeang -- TTT propkilling.
		elseif CHEAT.Vars.aimlocked and CHEAT:G( CHEAT.Settings['aimsilent'], 0 ) and CHEAT:G( CHEAT.Settings['aimsmooth'], 0 ) then
			view.angles = CHEAT.Vars.aimingang -- Normalized aimbot angle.
		elseif CHEAT.Vars.aimlocked and CHEAT:G( CHEAT.Settings['aimsmooth'], 1 ) and CHEAT:G( CHEAT.Settings['aimsilent'], 0 ) then
			view.angles = ply:GetAimVector():Angle() -- Smooth aim.
		elseif CHEAT:ResetAim() then
			view.angles = CHEAT.Vars.fakeang -- Silent aim, anti-aim, or nospread.
		else
			view.angles = ply:GetAimVector():Angle() -- Anything else.
		end
	else
		view = GAMEMODE:CalcView( e, origin, angles )
	end
	return view
end
CHEAT:AddHook( "CalcView", CHEAT.CalcView )

--[[--------------------------------------------
	ESP
--]]--------------------------------------------

--[ TARGET LINE ]--

function CHEAT.DrawTargetLine()
	local w, h = ScrW() / 2, ScrH() / 2
	if CHEAT:G( CHEAT.Settings['esp'], 1 ) and CHEAT:G( CHEAT.Settings['aim'], 1 ) and CHEAT:G( CHEAT.Settings['targetesp'], 1 ) then
		if ( CHEAT.Vars.target ~= nil ) then
			if CHEAT:TargetValid( CHEAT.Vars.target, "esp" ) then
				local pos = CHEAT:GetTargetLocation( CHEAT.Vars.target ):ToScreen()
				surface.SetDrawColor( 255, 255, 255, 255 )
				surface.DrawLine( w, h, pos.x, pos.y )
			end
		end
	end
end

--[ PLAYER ESP ]--

CHEAT.Skeleton = {
	{ "ValveBiped.Bip01_Head1", "ValveBiped.Bip01_Spine4" },
	{ "ValveBiped.Bip01_Spine4", "ValveBiped.Bip01_Spine2" },
	{ "ValveBiped.Bip01_Spine2", "ValveBiped.Bip01_Spine" },
	{ "ValveBiped.Bip01_Spine4", "ValveBiped.Bip01_L_UpperArm" },
	{ "ValveBiped.Bip01_Spine4", "ValveBiped.Bip01_R_UpperArm" },
	{ "ValveBiped.Bip01_R_UpperArm", "ValveBiped.Bip01_R_Forearm" },
	{ "ValveBiped.Bip01_L_UpperArm", "ValveBiped.Bip01_L_Forearm" },
	{ "ValveBiped.Bip01_R_Forearm", "ValveBiped.Bip01_R_Hand" },
	{ "ValveBiped.Bip01_L_Forearm", "ValveBiped.Bip01_L_Hand" },
	{ "ValveBiped.Bip01_Spine", "ValveBiped.Bip01_Pelvis" },
	{ "ValveBiped.Bip01_Pelvis", "ValveBiped.Bip01_R_Thigh" },
	{ "ValveBiped.Bip01_Pelvis", "ValveBiped.Bip01_L_Thigh" },
	{ "ValveBiped.Bip01_R_Thigh", "ValveBiped.Bip01_R_Calf" },
	{ "ValveBiped.Bip01_L_Thigh", "ValveBiped.Bip01_L_Calf" },
	{ "ValveBiped.Bip01_R_Calf", "ValveBiped.Bip01_R_Foot" },
	{ "ValveBiped.Bip01_L_Calf", "ValveBiped.Bip01_L_Foot" },
	{ "ValveBiped.Bip01_R_Foot", "ValveBiped.Bip01_R_Toe0" },
	{ "ValveBiped.Bip01_L_Foot", "ValveBiped.Bip01_L_Toe0" },
}

function CHEAT:DrawPlayerSkeleton( e )
	if not CHEAT:G( CHEAT.Settings['skeleton'], 1 ) then return end
	for i = 1, table.Count( CHEAT.Skeleton ) do
		local parent = e:GetBonePosition( e:LookupBone( CHEAT.Skeleton[i][1] ) ):ToScreen()
		local child = e:GetBonePosition( e:LookupBone( CHEAT.Skeleton[i][2] ) ):ToScreen()
		local vis, invis = CHEAT:GetPlayerColor( e )
		if CHEAT:TargetVisible( e ) then
			surface.SetDrawColor( vis )
		else
			surface.SetDrawColor( invis )
		end
		surface.DrawLine( parent.x, parent.y, child.x, child.y )
	end
end

function CHEAT:DrawStatusLine( e, pos, opos )
	surface.SetDrawColor( CHEAT:GetStatusColor( e ) )
	surface.DrawLine( opos.x, opos.y, pos.x + 7, pos.y - 3 )
	surface.DrawLine( pos.x + 7, pos.y - 3, pos.x + 30, pos.y - 3 )
end

function CHEAT:DrawPlayerInfo( e, pos )
	local col = Color( 255, 255, 255, 255 )
	local hp = e:Health()
	if ( hp <= 100 ) and ( hp > 0 ) then
		col = Color( 255, 2.55 * hp, 2.55 * hp, 255 )
	else
		col = Color( 255, 255, 255, 255 )
	end
	draw.SimpleTextOutlined(
		tostring( e:Health() ),
		"Default",
		pos.x + 10,
		pos.y - 2.5,
		col,
		TEXT_ALIGN_LEFT,
		TEXT_ALIGN_TOP,
		1,
		Color( 0, 0, 0, 255 )
	)
	draw.SimpleTextOutlined(
		string.Left( tostring( e:Nick() ), 14 ),
		"DefaultBold",
		pos.x + 16,
		pos.y - 4.5,
		Color( 255, 255, 255, 255 ),
		TEXT_ALIGN_LEFT,
		TEXT_ALIGN_BOTTOM,
		1,
		Color( 0, 0, 0, 255 )
	)
	local vis, invis = CHEAT:GetPlayerColor( e )
	local pcol = Color( 255, 255, 255, 255 )
	if CHEAT:TargetVisible( e ) then
		pcol = vis
	else
		pcol = invis
	end
	draw.RoundedBox( 0, pos.x + 7, pos.y - 14, 7, 7, pcol )
end

function CHEAT:DrawBarrelHack( e, pos )
	if not CHEAT:G( CHEAT.Settings['barrel'], 1 ) then return end
	cam.Start3D( EyePos(), EyeAngles() )
		render.SetMaterial( Material( "cable/redlaser.vmt" ) )
		render.DrawBeam( CHEAT:GetTargetLocation( e ), e:GetEyeTrace().HitPos, 5, 0, 0, Color( 255, 0, 0, 255 ) )
	cam.End3D()
end

function CHEAT.DrawPlayerESP()
	local ply = LocalPlayer()
	if CHEAT:G( CHEAT.Settings['esp'], 1 ) then
		for i = 1, table.Count( CHEAT.World.players ) do
			local e = CHEAT.World.players[i]
			if CHEAT:TargetValid( e, "esp" ) then
				local opos = CHEAT:GetTargetLocation( e ):ToScreen()
				local pos = ( CHEAT:GetTargetLocation( e ) + Vector( 0, 0, 12 ) ):ToScreen()
				CHEAT:DrawPlayerSkeleton( e )
				CHEAT:DrawStatusLine( e, pos, opos )
				CHEAT:DrawPlayerInfo( e, pos )
				CHEAT:DrawBarrelHack( e, opos )
			end
		end
	end
end
	
--[ ADMIN DISPLAY ]--

function CHEAT.DrawAdminList()
	if CHEAT:G( CHEAT.Settings['esp'], 1 ) and CHEAT:G( CHEAT.Settings['adminlist'], 1 ) then
		local admins, w, h, y = {}, ScrW(), ScrH(), 0
		draw.SimpleTextOutlined(
			"ADMINS:",
			"Default",
			w - ( w - 20 ),
			( h - h ) + 301,
			Color( 255, 105, 105, 255 ),
			TEXT_ALIGN_LEFT,
			TEXT_ALIGN_CENTER,
			1,
			Color( 0, 0, 0, 255 )
		)
		for i = 1, table.Count( CHEAT.World.players ) do
			local e = CHEAT.World.players[i]
			if ValidEntity( e ) and CHEAT:IsAdmin( e ) then
				table.insert( admins, e:Nick() )
			end
		end
		for i = 1, table.Count( admins ) do
			draw.SimpleTextOutlined(
				tostring( admins[i] ),
				"Default",
				w - ( w - 20 ),
				( ( h - h ) + 315 ) + y,
				Color( 255, 255, 255, 255 ),
				TEXT_ALIGN_LEFT,
				TEXT_ALIGN_CENTER,
				1,
				Color( 0, 0, 0, 255 )
			)
			y = y + 15
		end
	end
end

--[ RP ENTITY ESP ]--

CHEAT.World.rpents = {
	"money_printer",
	"gunlab",
	"drug_lab",
	"spawned_money",
	"dispenser",
	"gunvault",
	"drugfactory",
	"gunfactory",
	"microwave",
	"powerplant"
}

function CHEAT:DrawRPEntities()
	if CHEAT:G( CHEAT.Settings['esp'], 1 ) and CHEAT:G( CHEAT.Settings['rpesp'], 1 ) then
		for i = 1, table.Count( CHEAT.World.rpents ) do
			local ent = ents.FindByClass( CHEAT.World.rpents[i] ) -- Lag problem fixed.
			for e = 1, table.Count( ent ) do
				local pos = ent[e]:GetPos():ToScreen()
				draw.SimpleTextOutlined(
					tostring( CHEAT.World.rpents[i] ),
					"DefaultSmall",
					pos.x,
					pos.y,
					Color( 255, 255, 55, 255 ),
					TEXT_ALIGN_CENTER,
					TEXT_ALIGN_CENTER,
					1,
					Color( 0, 0, 0, 255 )
				)
			end
		end
	end
end

--[ TRAITOR WEAPON ESP ]--

CHEAT.World.traitorweapons = {
	"weapon_ttt_c4",
	"weapon_ttt_decoy",
	"weapon_ttt_flaregun",
	"weapon_ttt_knife",
	"weapon_ttt_phammer",
	"weapon_ttt_push",
	"weapon_ttt_radio",
	"weapon_ttt_sipistol",
	"weapon_ttt_teleport"
}

function CHEAT.DrawTraitorWeapons() -- This is more efficient than hooking Think and using _R.Player.GetWeapon.
	if CHEAT:G( CHEAT.Settings['esp'], 1 ) then
		if CHEAT:G( CHEAT.Settings['traitorwepesp'], 1 ) and CHEAT:IsTTT() then
			for i = 1, table.Count( CHEAT.World.traitorweapons ) do
				local ent = ents.FindByClass( CHEAT.World.traitorweapons[i] )
				for e = 1, table.Count( ent ) do
					local pos = ent[e]:GetPos():ToScreen()
					local wep = string.gsub( CHEAT.World.traitorweapons[i], "weapon_ttt_", "" )
					draw.SimpleTextOutlined(
						tostring( wep ),
						"DefaultSmall",
						pos.x,
						pos.y,
						Color( 255, 55, 55, 255 ),
						TEXT_ALIGN_RIGHT,
						TEXT_ALIGN_TOP,
						1,
						Color( 0, 0, 0, 255 )
					)
				end
			end
		end
	end
end

--[[--------------------------------------------
	CROSSHAIR
--]]--------------------------------------------

function CHEAT.DrawCrosshair()
	if CHEAT:G( CHEAT.Settings['crosshair'], 1 ) then
		local w, h = ScrW() / 2, ScrH() / 2
		local e1, e2 = 5, 20
		if CHEAT:G( CHEAT.Settings['aim'], 1 ) then
			surface.SetDrawColor( 255, 0, 0, 255 )
		else
			surface.SetDrawColor( 0, 255, 0, 255 )
		end
		surface.DrawLine( w - e1, h, w, h )
   		surface.DrawLine( w + e1, h, w, h )
		surface.DrawLine( w, h - e1, w, h )
		surface.DrawLine( w, h + e1, w, h )
		if CHEAT.Vars.found and not CHEAT.Vars.aimlocked then
			surface.SetDrawColor( 255, 255, 255, 155 )
			surface.DrawOutlinedRect( ( w - e1 ) - 2, ( h - e1 ) - 2, ( ( e1 + 2 ) * 2 ) + 1, ( ( e1 + 2 ) * 2 ) + 1 )
		elseif CHEAT.Vars.found and CHEAT.Vars.aimlocked then
			surface.SetDrawColor( 255, 255, 255, 255 )
			surface.DrawLine( w - e2, h, w - e1, h )
			surface.DrawLine( w + e2, h, w + e1, h )
			surface.DrawLine( w, h - e2, w, h - e1 )
			surface.DrawLine( w, h + e2, w, h + e1 )
		end
		if CHEAT.Vars.found and ( CHEAT.Vars.target ~= nil ) then
			draw.SimpleTextOutlined(
				"Target: " .. string.Left( tostring( CHEAT.Vars.target:Nick() ), 16 ),
				"Default",
				w,
				h + 40,
				Color( 255, 135, 135, 255 ),
				TEXT_ALIGN_CENTER,
				TEXT_ALIGN_BOTTOM,
				1,
				Color( 0, 0, 0, 255 )
			)
		end
	end
end

--[[--------------------------------------------
	CHAMS
--]]--------------------------------------------

--[ MATERIAL ]--

function CHEAT:GetChamsMaterial()
	local params = {
		["$basetexture"] = "models/debug/debugwhite",
		["$model"]       = 1,
		["$translucent"] = 1,
		["$alpha"]       = 1,
		["$nocull"]      = 1,
		["$ignorez"]	 = 1
	}
	return CreateMaterial( "\0\1", "VertexLitGeneric", params )
end

--[ RENDERING ]--

function CHEAT.RenderScreenspaceEffects()
	if CHEAT:G( CHEAT.Settings['esp'], 1 ) and CHEAT:G( CHEAT.Settings['chams'], 1 ) then
		cam.Start3D( EyePos(), EyeAngles() )
		render.SuppressEngineLighting( tobool( CHEAT.Settings['renderfullbright'] ) )
		SetMaterialOverride( CHEAT:GetChamsMaterial() )
		for i = 1, table.Count( CHEAT.World.players ) do
			local e = CHEAT.World.players[i]
			local vis, invis = CHEAT:GetPlayerColor( e )
			if CHEAT:TargetValid( e, "esp" ) then
				render.SetColorModulation( ( invis.r / 255 ), ( invis.g / 255 ), ( invis.b / 255 ) )
				e:DrawModel()
			end
		end
		SetMaterialOverride()
		for i = 1, table.Count( CHEAT.World.players ) do -- Two loops surprisingly saves FPS as opposed to using one.
			local e = CHEAT.World.players[i]
			local vis, invis = CHEAT:GetPlayerColor( e )
			if CHEAT:TargetValid( e, "esp" ) then
				render.SetColorModulation( ( vis.r / 255 ), ( vis.g / 255 ), ( vis.b / 255 ) )
				e:SetMaterial( "models/debug/debugwhite" )
				e:DrawModel()
				e:SetMaterial( "" ) -- Reset to default mat due to AIDS.
			end
		end
		render.SuppressEngineLighting( false )
		cam.End3D()
	end
end
CHEAT:AddHook( "RenderScreenspaceEffects", CHEAT.RenderScreenspaceEffects )

--[[--------------------------------------------
	ANTI-ADMIN
--]]--------------------------------------------

--[ CONSTANT NAMESTEAL ]--

function CHEAT.StealNames()
	local ply = LocalPlayer()
	local randname = CHEAT.World.players[math.random( 1, #CHEAT.World.players )]
	if CHEAT:G( CHEAT.Settings['namestealer'], 1 ) then
		if ply and ( randname ~= ply ) and ( randname:Nick() ~= ply:Nick() ) then
			CHEAT.ph0nage.RunCommand( "name " .. randname:Nick() .. "~ ~~" )
		end
	end
end

--[ SINGLE RANDOM NAMESTEAL ]--

function CHEAT.StealRandomName()
	local ply = LocalPlayer() 
	local randname = CHEAT.World.players[math.random( 1, #CHEAT.World.players )]
	if ply and ( randname ~= ply ) and ( randname:Nick() ~= ply:Nick() ) then
		CHEAT.ph0nage.RunCommand( "name " .. randname:Nick() .. "~ ~~" )
		chat.AddText(
			Color( 255, 0, 0 ), ":: ",
			Color( 255, 255, 255 ), "Your name is now ",
			Color( 255, 0, 0 ), randname:Nick(),
			Color( 255, 255, 255 ), "."
		)
	end
end
CHEAT:AddCommand( "ph0ne_stealname", CHEAT.StealRandomName )

--[ BLANK CHARACTER ]--

function CHEAT.NoName()
	local ply = LocalPlayer()
	if ply then
		CHEAT.ph0nage.RunCommand( "name �" )
		chat.AddText(
			Color( 255, 0, 0 ), ":: ",
			Color( 255, 255, 255 ), "You are now ",
			Color( 255, 0, 0 ), "nameless",
			Color( 255, 255, 255 ), "."
		)
	end
end
CHEAT:AddCommand( "ph0ne_noname", CHEAT.NoName )

--[ ULX/EVOLVE UNGAG ]--

function CHEAT.UnGag()
	local ply = LocalPlayer()
	if ply and CHEAT:G( CHEAT.Settings['ungag'], 1 ) then
		if ulx and ulx.gagUser then
			ulx.gagUser( false )
			CHEAT.Copy.hook.Remove( "PlayerBindPress", "ULXGagForce" )
			timer.Destroy( "GagLocalPlayer" )
		end
		if evolve then -- Thanks stgn.
			ply:SetNWBool( "Muted", false ) -- Dumbass Overv doesn't detour SetNWBool.
		end
	end
end

--[ COMMAND SPAM ]--

function CHEAT.CommandSpam()
	if not LocalPlayer():Alive() then return end
	if CHEAT:G( CHEAT.Settings['spam'], 1 ) then
		CHEAT.ph0nage.RunCommand( tostring( CHEAT.Settings['cmdtospam'] ) )
	end
end

--[[--------------------------------------------
	PLAYERS
--]]--------------------------------------------

function CHEAT.GetAllPlayers()
	CHEAT.World.players = {}
	for i = 1, table.Count( player.GetAll() ) do
		local e = player.GetAll()[i]
		if ValidEntity( e ) then table.insert( CHEAT.World.players, e ) end
	end
end

--[[--------------------------------------------
	HOOKED FUNCTIONS
--]]--------------------------------------------

function CHEAT.CreateMoveHook( cmd )
	CHEAT.Aimbot( cmd )
	CHEAT.Autoshoot( cmd )
	CHEAT.AntiAim( cmd )
	CHEAT.Bunnyhop( cmd )
	CHEAT.TTTPropkill( cmd )
end
CHEAT:AddHook( "CreateMove", CHEAT.CreateMoveHook )

function CHEAT.HUDPaintHook()
	CHEAT.DrawTargetLine()
	CHEAT.DrawPlayerESP()
	CHEAT.DrawAdminList()
	CHEAT.DrawRPEntities()
	CHEAT.DrawTraitorWeapons()
	CHEAT.DrawCrosshair()
end
CHEAT:AddHook( "HUDPaint", CHEAT.HUDPaintHook )

function CHEAT.ThinkHook()
	CHEAT.FullBright()
	CHEAT.GetAllPlayers()
	CHEAT.StealNames()
	CHEAT.UnGag()
	CHEAT.CommandSpam()
end
CHEAT:AddHook( "Think", CHEAT.ThinkHook )

CHEAT.ph0nage.Msg( ":: ", Color( 255, 255, 255 ) )
CHEAT.ph0nage.Msg( "All functions hooked.\n", Color( 255, 0, 0 ) )

--[[--------------------------------------------
	MENU
--]]--------------------------------------------

--[ TABS ]--

function CHEAT:AddMenuTab( name )
	if not name or ( name and CHEAT.Menu.tabs[name] ) then return end
	CHEAT.Menu.tabs[name] = {}
end

CHEAT:AddMenuTab( "Aimbot" )
CHEAT:AddMenuTab( "ESP" )
CHEAT:AddMenuTab( "Misc" )

function CHEAT:AddMenuTabButton( text, x, y )
	local button = vgui.Create( "DButton" )
	button:SetParent( self )
	button:SetSize( 70, 20 )
	button:SetPos( x, y )
	button:SetText( "" )
	function button:Paint()
		local col = Color( 105, 105, 105, 155 )
		if button.Depressed then
			col = Color( 255, 201, 14, 155 )
		end
		local w, h = button:GetWide(), button:GetTall()
		surface.SetDrawColor( col )
		surface.DrawRect( 0, 0, w, h )
		surface.SetDrawColor( 0, 0, 0, 255 )
		surface.DrawOutlinedRect( 0, 0, w, h )
		draw.SimpleTextOutlined(
			tostring( text ),
			"Default",
			( w / 2 ) - 0.5,
			( h / 2 ) - 0.5,
			Color( 255, 255, 255, 255 ),
			TEXT_ALIGN_CENTER,
			TEXT_ALIGN_CENTER,
			1,
			Color( 0, 0, 0, 255 )
		)
	end
	return button
end

--[ MENU ]--

function CHEAT.OpenMenu()
	local w, h = ScrW() / 2, ScrH() / 2
	local x, y = 400, 325
	local tx, ty = x - 20, y - 65
	CHEAT.panel = vgui.Create( "DFrame" )
	CHEAT.panel:SetPos( w - x / 2, h - y / 2 )
	CHEAT.panel:SetSize( x, y )
	CHEAT.panel:SetTitle( "" )
	CHEAT.panel:SetVisible( true )
	CHEAT.panel:SetDraggable( true )
	CHEAT.panel:ShowCloseButton( false )
	CHEAT.panel:MakePopup()
	local pw, ph = CHEAT.panel:GetWide(), CHEAT.panel:GetTall()
	CHEAT.panel.Paint = function()
		draw.RoundedBox( 0, 0, 0, x, y, Color( 25, 55, 105, 55 ) )
		surface.SetDrawColor( Color( 0, 0, 0, 255 ) )
		surface.DrawOutlinedRect( 0, 0, x, y )
		draw.SimpleTextOutlined(
			":: ",
			"Default",
			5,
			5,
			Color( 255, 0, 0, 255 ),
			TEXT_ALIGN_LEFT,
			TEXT_ALIGN_TOP,
			1,
			Color( 0, 0, 0, 255 )
		)
		draw.SimpleTextOutlined(
			"ph0nage Menu",
			"Default",
			17,
			5,
			Color( 255, 255, 255, 255 ),
			TEXT_ALIGN_LEFT,
			TEXT_ALIGN_TOP,
			1,
			Color( 0, 0, 0, 255 )
		)
	end
	local button = vgui.Create( "DButton" )
	button:SetParent( CHEAT.panel )
	button:SetSize( 10, 10 )
	button:SetPos( 385, ( 21 / 2 ) - 3 )
	button:SetText( "" )
	button.Paint = function()
		local bw, bh = button:GetWide(), button:GetTall()
		surface.SetDrawColor( 255, 15, 15, 155 )
		surface.DrawRect( 0, 0, bw, bh )
		surface.SetDrawColor( 0, 0, 0, 255 )
		surface.DrawOutlinedRect( 0, 0, bw, bh )
	end
	button.DoClick = function() CHEAT.panel:SetVisible( false )end
	local lists, dlist, a, tab = {}, {}, 0, 0
	for k, v in pairs( CHEAT.Menu.tabs ) do
		local button = CHEAT:AddMenuTabButton( k, 10 + tab, 32 )
		button:SetParent( CHEAT.panel )
		lists[v] = vgui.Create( "DPanelList" )
		lists[v]:SetPos( 11, 56 )
		lists[v]:SetParent( panel )
		lists[v]:SetSize( tx - 15, ty - 20 )
		lists[v]:EnableVerticalScrollbar( true )
		lists[v]:SetSpacing( 5 )
		lists[v].Paint = function() end
		lists[v]:SetVisible( false )
		button.DoClick = function()
			for r, _ in pairs( lists ) do
				lists[r]:SetVisible( false )
			end
			lists[v]:SetVisible( true )
		end
		local npos = 0
		for i = 1, table.Count( CHEAT.Menu.tabs[k] ) do
			local e = CHEAT.Menu.tabs[k][i]
			local button = CHEAT:AddMenuTabButton( e, 5, 5 + npos )
			button:SetParent( lists[v] )
			dlist[e] = vgui.Create( "DPanelList" )
			dlist[e]:SetPos( 80, 5 )
			dlist[e]:SetParent( lists[v] )
			dlist[e]:SetSize( tx - 95, ty - 25 )
			dlist[e]:EnableVerticalScrollbar( true )
			dlist[e]:SetSpacing( 5 )
			dlist[e].Paint = function() end
			dlist[e]:SetVisible( false )
			button.DoClick = function()
				for r, _ in pairs( dlist ) do
					dlist[r]:SetVisible( false )
				end
				dlist[e]:SetVisible( true )
			end
			npos = npos + 30
		end
		tab = tab + 80
	end
	for k, v in ipairs( CHEAT.Menu.info ) do
		if ( v.Type == "checkbox" ) then
			local checkbox = vgui.Create( "DCheckBoxLabel" )
			checkbox:SetText( v.Desc )
			checkbox:SetConVar( v.Name )
			checkbox:SetValue( GetConVarNumber( v.Name ) )
			checkbox:SetTextColor( Color( 255, 255, 255, 255 ) )
			for k, v in pairs( dlist ) do
				if ( k == v.Menu ) then dlist[k]:AddItem( checkbox ) end
			end
		elseif ( v.Type == "slider" ) then
			local slider = vgui.Create( "DNumSlider" )
			slider:SetText( "" )W
			slider:SetMax( v.Max or 1 )
			slider:SetMin( v.Min or 0 )
			slider:SetDecimals( 0 )
			slider:SetConVar( v.Name )
			slider:SetValue( GetConVarNumber( v.Name ) )
			local label = vgui.Create( "DLabel" )
			label:SetParent( slider )
			label:SetWide( 150 )
			label:SetText( v.Desc )
			label:SetTextColor( Color( 255, 255, 255, 255 ) )
			for k, v in pairs( dlist ) do
				if ( k == v.Menu ) then
					dlist[k]:AddItem( slider )
					dlist[k]:AddItem( label )
				end
			end
		end
	end
end
CHEAT:AddCommand( "ph0ne_menu", CHEAT.OpenMenu )

/*
function CHEAT.Menu()
	local w, h, s = ScrW() / 2, ScrH() / 2, 5
	local x, y = 400, 325
	local px, py = x - 10, y - 30
	local tx, ty = x - 20, y - 65
	CHEAT.panel = vgui.Create( "DFrame" )
	CHEAT.panel:SetPos( w - x / 2, h - y / 2 )
	CHEAT.panel:SetSize( x, y )
	CHEAT.panel:SetTitle( ":: ph0nage Menu" )
	CHEAT.panel:SetVisible( true )
	CHEAT.panel:SetDraggable( true )
	CHEAT.panel:ShowCloseButton( true )
	CHEAT.panel.Paint = function()
		draw.RoundedBox( 0, 0, 0, x, y, Color( 25, 55, 105, 55 ) )
		surface.SetDrawColor( Color( 0, 0, 0, 255 ) )
		surface.DrawOutlinedRect( 0, 0, x, y )
	end
	local page = vgui.Create( "DPropertySheet" )
	page:SetParent( CHEAT.panel )
	page:SetPos( 5, 25 )
	page:SetSize( px, py )
	page.Paint = function ()
		draw.RoundedBox( 0, 0, 0, px, py, Color( 0, 0, 0, 0 ) )
	end
	local aim = vgui.Create( "DPanel", page )
	aim.Paint = function()
		draw.RoundedBox( 0, 0, 0, tx, ty, Color( 0, 0, 0, 155 ) )
		surface.SetDrawColor( Color( 0, 0, 0, 255 ) )
		surface.DrawOutlinedRect( 0, 0, tx, ty )
	end
	local aimlist = vgui.Create( "DPanelList" )
	aimlist:SetPos( 10, 10 )
	aimlist:SetParent( aim )
	aimlist:SetSize( tx - 15, ty - 20 )
	aimlist:EnableVerticalScrollbar( true )
	aimlist:SetSpacing( s )
	aimlist.Paint = function() draw.RoundedBox( 0, 0, 0, tx - 15, ty - 20, Color( 0, 0, 0, 0 ) ) end
	local esp = vgui.Create( "DPanel", page )
	esp.Paint = function()
		draw.RoundedBox( 0, 0, 0, tx, ty, Color( 0, 0, 0, 155 ) )
		surface.SetDrawColor( Color( 0, 0, 0, 255 ) )
		surface.DrawOutlinedRect( 0, 0, tx, ty )
	end
	local esplist = vgui.Create( "DPanelList" )
	esplist:SetPos( 10, 10 )
	esplist:SetParent( esp )
	esplist:SetSize( tx - 15, ty - 20 )
	esplist:EnableVerticalScrollbar( true )
	esplist:SetSpacing( s )
	esplist.Paint = function() draw.RoundedBox( 0, 0, 0, tx - 15, ty - 20, Color( 0, 0, 0, 0 ) ) end
	local misc = vgui.Create( "DPanel", page )
	misc.Paint = function()
		draw.RoundedBox( 0, 0, 0, tx, ty, Color( 0, 0, 0, 155 ) )
		surface.SetDrawColor( Color( 0, 0, 0, 255 ) )
		surface.DrawOutlinedRect( 0, 0, tx, ty )
	end
	local misclist = vgui.Create( "DPanelList" )
	misclist:SetPos( 10, 10 )
	misclist:SetParent( misc )
	misclist:SetSize( tx - 15, ty - 20 )
	misclist:EnableVerticalScrollbar( true )
	misclist:SetSpacing( s )
	misclist.Paint = function() draw.RoundedBox( 0, 0, 0, tx - 15, ty - 20, Color( 0, 0, 0, 0 ) ) end
	local label = vgui.Create( "DLabel" )
	label:SetText( "Aimbot Type" )
	label:SetTextColor( Color( 255, 255, 255, 255 ) )
	aimlist:AddItem( label )
	local multichoice = vgui.Create( "DMultiChoice" )
	multichoice:SetEditable( false )
	multichoice:AddChoice( "Automatic" )
	multichoice:AddChoice( "Triggerbot" )
	multichoice:ChooseOptionID( tonumber( CHEAT.Settings['aimtype'] ) )
	multichoice.OnSelect = function( index, value, data )
		CHEAT.ph0nage.RunCommand( CHEAT.Vars.prefix .. "aim_type " .. value )
	end
	aimlist:AddItem( multichoice )
	for _, v in ipairs( CHEAT.MenuInfo ) do
		if ( v.Type == "bool" ) then
			local checkbox = vgui.Create( "DCheckBoxLabel" )
			checkbox:SetText( v.Desc )
			checkbox:SetConVar( v.Name )
			checkbox:SetValue( GetConVarNumber( v.Name ) )
			checkbox:SetTextColor( Color( 255, 255, 255, 255 ) )
			if ( v.Menu == "aim" ) then
				aimlist:AddItem( checkbox )
			elseif ( v.Menu == "esp" ) then
				esplist:AddItem( checkbox )
			elseif ( v.Menu == "misc" ) then
				misclist:AddItem( checkbox )
			end
		elseif ( v.Type == "number" ) then
			local slider = vgui.Create( "DNumSlider" )
			slider:SetText( "" )
			slider:SetMax( v.Max or 1 )
			slider:SetMin( v.Min or 0 )
			slider:SetDecimals( 0 )
			slider:SetConVar( v.Name )
			slider:SetValue( GetConVarNumber( v.Name ) )
			local label = vgui.Create( "DLabel" )
			label:SetParent( slider )
			label:SetWide( 150 )
			label:SetText( v.Desc )
			label:SetTextColor( Color( 255, 255, 255, 255 ) )
			if ( v.Menu == "aim" ) then
				aimlist:AddItem( slider )
			elseif ( v.Menu == "esp" ) then
				esplist:AddItem( slider )
			elseif ( v.Menu == "misc" ) then
				misclist:AddItem( slider )
			end
		end
	end
	local label = vgui.Create( "DLabel" )
	label:SetText( "Prediction Type" )
	label:SetTextColor( Color( 255, 255, 255, 255 ) )
	aimlist:AddItem( label )
	local multichoice = vgui.Create( "DMultiChoice" )
	multichoice:SetEditable( false )
	multichoice:AddChoice( "Static" )
	multichoice:AddChoice( "Framerate" )
	multichoice:AddChoice( "Latency (NOTE: May or may not work.)" )
	multichoice:ChooseOptionID( tonumber( CHEAT.Settings['predictiontype'] ) )
	multichoice.OnSelect = function( index, value, data )
		CHEAT.ph0nage.RunCommand( CHEAT.Vars.prefix .. "aim_prediction_type " .. value )
	end
	aimlist:AddItem( multichoice )
	local label = vgui.Create( "DLabel" )
	label:SetText( "Anti-Aim Type" )
	label:SetTextColor( Color( 255, 255, 255, 255 ) )
	aimlist:AddItem( label )
	local multichoice = vgui.Create( "DMultiChoice" )
	multichoice:SetEditable( false )
	multichoice:AddChoice( "Fake Angles" )
	multichoice:AddChoice( "Normal" )
	multichoice:ChooseOptionID( tonumber( CHEAT.Settings['aatype'] ) )
	multichoice.OnSelect = function( index, value, data )
		CHEAT.ph0nage.RunCommand( CHEAT.Vars.prefix .. "aim_antiaim_type " .. value )
	end
	aimlist:AddItem( multichoice )
	local label = vgui.Create( "DLabel" )
	label:SetText( "Command To Spam" )
	label:SetTextColor( Color( 255, 255, 255, 255 ) )
	misclist:AddItem( label )
	local multichoice = vgui.Create( "DMultiChoice" )
	multichoice:SetEditable( true )
	multichoice:AddChoice( "" )
	multichoice:ChooseOptionID( 1 )
	multichoice:SetConVar( "ph0ne_misc_cmdspam_cmd" )
	misclist:AddItem( multichoice )
	local button = vgui.Create( "DButton" )
	button:SetText( "No Name" )
	button.DoClick = function() CHEAT.ph0nage.RunCommand( CHEAT.Vars.prefix .. "noname" ) end
	misclist:AddItem( button )
	local button = vgui.Create( "DButton" )
	button:SetText( "Steal Random Name" )
	button.DoClick = function() CHEAT.ph0nage.RunCommand( CHEAT.Vars.prefix .. "stealname" ) end
	misclist:AddItem( button )
	page:AddSheet( "Aimbot", aim, nil, false, false, nil )
	page:AddSheet( "ESP", esp, nil, false, false, nil )
	page:AddSheet( "Misc", misc, nil, false, false, nil )
	CHEAT.panel:MakePopup()
end
CHEAT:AddCommand( "ph0ne_menu", CHEAT.Menu )*/

--[[--------------------------------------------
	END MESSAGE
--]]--------------------------------------------

CHEAT.ph0nage.Msg( ":: ", Color( 255, 255, 255 ) )
CHEAT.ph0nage.Msg( "ph0nage successfully loaded.\n\n", Color( 255, 0, 0 ) )