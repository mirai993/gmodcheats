--[[
	Zenith Lua (proxi edition) (single file)
	
	Credits: 
		flarose
		homonovus
		black
		solum
	
	TODO:
		add smooth scrolling
		fix antiaim breaking when poseparms are passed
		improve LBY backtrack
]]

local Data = {}
Data._G_MOD = setmetatable({
	Data = Data,
	noop = function() end,

	hooks = hook.GetTable(),
}, {
	__index = function(t, k)
		-- check modules' shared global
		-- else check _G

		local t_val = rawget(t, k)
		if t_val ~= nil then
			return t_val
		end

		return rawget(_G, k)
	end,
	__newindex = function(t,k,v) -- don't pollute _G, but also update the module's environment
		rawset(t,k,v)
	end
})

Data._G_MOD._ENV = Data._G_MOD
setfenv(1, Data._G_MOD)

require("proxi")

local _G = _G or getfenv(1)
local _R = proxi._R

local g_nChokedPackets = 0

local g_bSendPacket = true
local g_bSequenceRan = false

local g_pLocalPlayer = LocalPlayer()
local g_pActiveWeapon = g_pLocalPlayer:GetActiveWeapon()

local g_qFacingAngle = g_pLocalPlayer:EyeAngles()
local g_qRealAngle = Angle(g_qFacingAngle)
local g_qFakeAngle = Angle(g_qFacingAngle)
local g_qPunchAngle = Angle()
local g_qPunchAngleVel = Angle()

local g_vCamSize = Vector(8, 8, 8)

local color_white = Color(255, 255, 255)
local color_black = Color(0, 0, 0)
local color_red = Color(255, 0, 0)
local color_blue = Color(0, 0, 255)
local color_green = Color(0, 255, 0)
local color_orange = Color(255, 150, 0)
local color_gray = Color(175, 175, 175)
local color_pink = Color(255, 0, 200)
local color_crimson = Color(175, 0, 42)
local color_lavender = Color(165, 125, 255)
local color_purple = Color(125, 0, 255)
local color_teal = Color(0, 180, 180)
local color_seafoam = Color(201, 255, 229)
local color_grey = Color(90, 90, 90, 255)

local LP_FAKE = -1
local LP_REAL = 0

local SCREEN_WIDTH = ScrW()
local SCREEN_HEIGHT = ScrH()

local SCREEN_CENTER_X = math.floor(SCREEN_WIDTH / 2)
local SCREEN_CENTER_Y = math.floor(SCREEN_HEIGHT / 2)

local TICK_INTERVAL = engine.TickInterval()
local M_HPI = math.pi
local INT_MAX = math.huge

local FRAME_UNDEFINED = -1
local FRAME_START = 0 -- Used when FrameStageNotify is about to start sending/receiving data
local FRAME_NET_UPDATE_START = 1 -- Used when FrameStageNotify has received a packet
local FRAME_NET_UPDATE_POSTDATAUPDATE_START = 2 -- Used when FrameStageNotify has received data is is about to call PostDataUpdate
local FRAME_NET_UPDATE_POSTDATAUPDATE_END = 3 -- Used when FrameStageNotify has received data and has called PostDataUpdate on all recipients
local FRAME_NET_UPDATE_END = 4 -- Used when FrameStageNotify has received all packets and interpolation, prediction, etc is about to begin
local FRAME_RENDER_START = 5 -- Used when FrameStageNotify has finished sending/receiving data and is about to render the scene
local FRAME_RENDER_END = 6 -- Used when FrameStageNotify has finished rendering the scene

local cv_name = proxi.GetConVar("name")
local m_yaw = proxi.GetConVar("m_yaw")
local sv_skyname = GetConVar("sv_skyname")
local m_pitch = proxi.GetConVar("m_pitch")

local sv_unlag = proxi.GetConVar("sv_unlag")
local cl_interp = proxi.GetConVar("cl_interp")
local cl_cmdrate = proxi.GetConVar("cl_cmdrate")
local sv_gravity = proxi.GetConVar("sv_gravity")
local sv_maxunlag = proxi.GetConVar("sv_maxunlag")
local cl_sidespeed = proxi.GetConVar("cl_sidespeed")
local sv_specspeed = proxi.GetConVar("sv_specspeed")
local cl_updaterate = proxi.GetConVar("cl_updaterate")
local sv_noclipspeed = proxi.GetConVar("sv_noclipspeed")
local sv_maxvelocity = proxi.GetConVar("sv_maxvelocity")
local cl_interpolate = proxi.GetConVar("cl_interpolate")
local cl_interp_ratio = proxi.GetConVar("cl_interp_ratio")
local cl_forwardspeed = proxi.GetConVar("cl_forwardspeed")
local sv_minupdaterate = proxi.GetConVar("sv_minupdaterate")
local sv_maxupdaterate = proxi.GetConVar("sv_maxupdaterate")
local sv_airaccelerate = proxi.GetConVar( "sv_airaccelerate" )
local sv_client_min_interp_ratio = proxi.GetConVar("sv_client_min_interp_ratio")
local sv_client_max_interp_ratio = proxi.GetConVar("sv_client_max_interp_ratio")
local sv_maxusrcmdprocessticks = proxi.GetConVar("sv_maxusrcmdprocessticks")

local arccw_desync = proxi.GetConVar("arccw_desync")
local sv_tfa_recoil_legacy = proxi.GetConVar("sv_tfa_recoil_legacy")
local swcs_weapon_sync_seed = proxi.GetConVar("swcs_weapon_sync_seed")
local weapon_debug_inaccuracy_only_up = proxi.GetConVar("weapon_debug_inaccuracy_only_up")
local weapon_debug_max_inaccuracy = proxi.GetConVar("weapon_debug_max_inaccuracy")

local M9KDisablePenetration = GetConVar("M9KDisablePenetration")
local arccw_enable_penetration = GetConVar("arccw_enable_penetration")
local sv_tfa_bullet_penetration = GetConVar("sv_tfa_bullet_penetration")
local sv_tfa_penetration_hardlimit = GetConVar("sv_tfa_penetration_hardlimit")
local sv_tfa_bullet_penetration_power_mul = GetConVar("sv_tfa_bullet_penetration_power_mul")

local g_tPlayers = {}
local g_tEntities = {}
local g_tEnums = {}
local g_tLocalHooks = {}
local g_tWeaponSpreadSeeds = {}
local g_tWeaponSpreadCones = {}
local g_tCalcViewData = {
	m_vOrigin = g_pLocalPlayer:EyePos(),
	m_qAngles = g_pLocalPlayer:EyeAngles(),
	m_nFOV = g_pLocalPlayer:GetFOV()
}
local g_tCurrShapeData = {}
local g_tAlreadyXOR = {}
local g_tXORToRegular = {}
local g_tMapData = {}

local g_pCachedMenu = nil
local g_pConfigList = nil
local g_pEnvPlayerList = nil

surface.CreateFont("jackson_font", {
	font = "Verdana",
	size = 12,
	antialias = false,
	outline = true
})

--[[
	Variables
]]

local Config = {}
Config["ragebot_enabled"] = true
Config["ragebot_key"] = MOUSE_5
Config["ragebot_silent"] = true
Config["ragebot_usecontext"] = false
Config["ragebot_multipoint"] = true
Config["ragebot_sortmethod"] = 1
Config["ragebot_hitbox"] = 1
Config["ragebot_friends"] = {}
Config["ragebot_ignoreplayers"] = false
Config["ragebot_ignorenextbots"] = false
Config["ragebot_ignorenpcs"] = false

Config["slowshoot_enabled"] = false
Config["slowshoot_time"] = 0

Config["aimline_enabled"] = true
Config["aimline_color"] = Color(255, 255, 255)

Config["aimcone_enaled"] = false
Config["aimcone_fov"] = 16
Config["aimcone_shape"] = 3
Config["aimcone_color"] = Color(255, 255, 255)

Config["triggerbot_enabled"] = true
Config["triggerbot_backtrack"] = false
Config["triggerbot_autowall"] = false
Config["triggerbot_oncrosshair"] = false
Config["triggerbot_forcepacket"] = true

Config["accuracy_norecoil"] = true
Config["accuarcy_resolver"] =  false
Config["accuracy_safepoint"] = false

Config["nospread_enabled"] = true
Config["nospread_usecontext"] = false

Config["forceseed_enabled"] = false
Config["forceseed_seed"] = 33

Config["hitchance_enabled"] = false
Config["hitchance_amount"] = 60

Config["backtrack_enabled"] = true
Config["backtrack_amount"] = 0.4
Config["backtrack_abuseinterp"] = false
Config["backtrack_method"] = 0

Config["backtrack_visuals_enabled"] = false
Config["backtrack_visuals_visualstyle"] = 2
Config["backtrack_visuals_startcolor"] = Color(255, 0, 0)
Config["backtrack_visuals_endcolor"] = Color(0, 255, 255)
Config["backtrack_visuals_material"] = "flat"

Config["antiaim_enabled"] = false
Config["antiaim_baseyaw"] = 5
Config["antiaim_pitch"] = 3
Config["antiaim_yaw"] = 7
Config["antiaim_custompitch"] = 0
Config["antiaim_customyaw"] = 0
Config["antiaim_customfake"] = 0
Config["antiaim_clamp"] = false
Config["antiaim_spinspeed"] = 0
Config["antiaim_edge"] = true

Config["fakelag_enabled"] = false
Config["fakelag_choke"] = 21
Config["fakelag_method"] = 2

Config["fakeduck_enabled"] = false
Config["fakeduck_key"] = KEY_NONE

Config["fakeact_enabled"] = false
Config["fakeact_gesture"] = 0

Config["playeresp_enabled"] = true
Config["playeresp_box2d"] = true
Config["playeresp_box3d"] = false
Config["playeresp_name"] = true
Config["playeresp_weapon"] = true
Config["playeresp_health"] = true
Config["playeresp_armor"] = true
Config["playeresp_skeleton"] = false
Config["playeresp_avatar"] = false
Config["playeresp_barrel"] = false
Config["playeresp_outline"] = false
Config["playeresp_outline_color"] = Color(255, 255, 255)

Config["entityesp_enabled"] = true
Config["entityesp_box2d"] = true
Config["entityesp_box3d"] = false
Config["entityesp_name"] = true
Config["entityesp_weapon"] = false
Config["entityesp_health"] = false
Config["entityesp_armor"] = false
Config["entityesp_skeleton"] = false
Config["entityesp_outline"] = false
Config["entityesp_outline_color"] = Color(255, 255, 255)

Config["playerchams_enabled"] = false
Config["playerchams_occluded_enabled"] = false
Config["playerchams_occluded_color"] = Color(255, 255, 255)
Config["playerchams_occluded_material"] = "flat"

Config["playerchams_visible_enabled"] = false
Config["playerchams_visible_color"] = Color(255, 255, 255)
Config["playerchams_visible_material"] = "flat"

Config["playerchams_overlay_enabled"] = false
Config["playerchams_overlay_color"] = Color(255, 255, 255)
Config["playerchams_overlay_material"] = "flat"

Config["entitychams_enabled"] = false
Config["entitychams_occluded_enabled"] = false
Config["entitychams_occluded_color"] = Color(255, 255, 255)
Config["entitychams_occluded_material"] = "flat"

Config["entitychams_visible_enabled"] = false
Config["entitychams_visible_color"] = Color(255, 255, 255)
Config["entitychams_visible_material"] = "flat"

Config["entitychams_overlay_enabled"] = false
Config["entitychams_overlay_color"] = Color(255, 255, 255)
Config["entitychams_overlay_material"] = "flat"

Config["viewmodelchams_enabled"] = false
Config["viewmodelchams_hands_enabled"] = true
Config["viewmodelchams_hands_color"] = Color(255, 255, 255)
Config["viewmodelchams_hands_material"] = "flat"

Config["viewmodelchams_arms_enabled"] = true
Config["viewmodelchams_arms_color"] = Color(255, 255, 255)
Config["viewmodelchams_arms_material"] = "flat"

Config["viewmodelchams_overlay_enabled"] = true
Config["viewmodelchams_overlay_color"] = Color(255, 255, 255)
Config["viewmodelchams_overlay_material"] = "flat"

Config["hitboxes_enabled"] = false
Config["hitboxes_color"] = Color(255, 255, 255)

Config["bullettracers_enabled"] = false
Config["bullettracers_material"] = ""
Config["bullettracers_dietime"] = 0

Config["movement_bhop"] = true
Config["movement_autostrafe_enabled"] = true
Config["movement_autostrafe_mode"] = 0
Config["movement_circlestrafe_enabled"] = true
Config["movement_circlestrafe_key"] = KEY_NONE

Config["thirdperson_enabled"] = true
Config["thirdperson_key"] = KEY_BACKSLASH
Config["thirdperson_distance"] = 110

Config["sequencefreeze_doubletap"] = false
Config["sequencefreeze_teleport_enabled"] = false
Config["sequencefreeze_teleport_key"] = KEY_NONE

Config["autoclicker_rapidfire_enabled"] = true
Config["autoclicker_rapidfire_toolgun"] = false
Config["autoclicker_usespam"] = false
Config["autoclicker_flashlightspam"] = false

Config["customfov_enabled"] = true
Config["customfov_fov"] = 116

Config["deletor_enabled"] = false
Config["deletor_radius"] = 0
Config["deletor_color"] = Color(255, 255, 255)

Config["customskybox_enabled"] = false
Config["customskybox_skybox"] = sv_skyname:GetString()

Config["worldcolors_enabled"] = true
Config["worldcolor_color"] = Color(100, 100, 100)

Config["misc_drawspreadcone"] = false
Config["misc_antiaimlines"] = false
Config["misc_debuginfo"] = false

Config["bindtogglemodes"] = {}
Config["entityclasses"] = {}
Config["whitelist"] = {}
Config["menucolors"] = {
	background = Color(45, 40, 45),
	outline = Color(144, 96, 144),
	section = Color(35, 30, 35),
	object = Color(144, 96, 144),
	object_background = Color(29, 25, 29)
}


--[[
	Setup classes
]]

local C_Accuracy = {}
C_Accuracy.m_bIsFiringThisTick = false
C_Accuracy.m_bInWorldClicker = false
C_Accuracy.m_tCurrWeaponData = {}
C_Accuracy.m_tResolverDeltas = {
	LowerBodyYaw = {-90, 0, 90, 180, -180, 180, 90, 0, -90},
	UppderBodyLean = {45, 0, -45}
}

local C_Ragebot = {}
C_Ragebot.m_tCurrBacktrackRecord = nil
C_Ragebot.m_tAimPositions = {}
C_Ragebot.m_tUnsortedTargets = {}
C_Ragebot.m_tSpreadSeeds = {}
C_Ragebot.m_tShotsFiredAt = {}

local MultiplayerAnimState = {}
MultiplayerAnimState.Instances = {}
MultiplayerAnimState.MaxAnimationLayers = 15

local C_AntiAim = {}
C_AntiAim.m_qCurrAngle = Angle()
C_AntiAim.m_qLastAngle = Angle()
C_AntiAim.m_nLastLBYBreak = 0

local C_AutoWall = {}
C_AutoWall.m_tLimits = {
	["357"] = {144, 4},
	["ar2"] = {256, 8},
	["buckshot"] = {25, 1},
	["pistol"] = {81, 2},
	["smg1"] = {196, 5},
	["sniperpenetratedround"] = {400, 12},
	["sniperround"] = {400, 12} -- SWB
}
C_AutoWall.m_tMultipliers = {
	[MAT_SAND] = 0.5,
	[MAT_DIRT] = 0.8,
	[MAT_METAL] = 1.1,
	[MAT_TILE] = 0.9,
	[MAT_WOOD] = 1.2
}
C_AutoWall.m_tCancellers = {
	[MAT_SLOSH] = true
}

local C_ConfigManager = {}
C_ConfigManager.m_strCurrConfigName = ""
C_ConfigManager.m_pCurrConfig = Config

local C_ModelData = {}
C_ModelData.__index = C_ModelData

local HITGROUP_FIRST = HITGROUP_GENERIC
local HITGROUP_COUNT = HITGROUP_RIGHTLEG

setmetatable(C_ModelData, {
	__call = function(cls, ...)
		local this = setmetatable({}, cls)
		this:_C_ModelData(...)
		return this
	end,
})

function C_ModelData:_C_ModelData()
	self.m_bIsValid = false
	self.m_tHitboxSets = {}

	for iHitGroup = HITGROUP_FIRST, HITGROUP_COUNT do
		self.m_tHitboxSets[iHitGroup] = {}
	end
end

function C_ModelData:IsValid()
	return self.m_bIsValid
end

local C_HitboxManager = {}
C_HitboxManager.m_tModelData = {}

local C_Math = {}

local C_Inputs = {}
C_Inputs.m_tKeyStates = {}
C_Inputs.m_tIsKeyDown = {}

local LagCompensation = {}
LagCompensation.m_tCurrentRecord = nil -- logging
LagCompensation.m_tRecords = {}
LagCompensation.m_tCachedSimTime = {}
LagCompensation.m_tBreakingLagComp = {}
LagCompensation.m_tSimulationDelta = {}
LagCompensation.m_bCanRun = false
LagCompensation.m_flLerpTime = 0.0

local C_PlayerData = {}
C_PlayerData.__index = C_PlayerData

setmetatable(C_PlayerData, {
	__call = function(cls, ...)
		local this = setmetatable({}, cls)
		this:_CPlayerData(...)
		return this
	end,
})

function C_PlayerData:_CPlayerData()
	self.m_pEntity = NULL
	self.m_flSimulationTime = 0.0
	self.m_flCreateTime = 0.0
	self.m_nTickCount = 0

	self.m_vVelocity = Vector()
	self.m_vOrigin = Vector()
	self.m_qAngles = Angle()

	self.m_vMins = Vector()
	self.m_vMaxs = Vector()

	self.m_tBoneMatrices = {}
	self.m_tHitboxes = {}
end

local C_Movement = {}
C_Movement.m_bIsBhopping = false
C_Movement.m_bWasOnGround = false
C_Movement.m_flCircleYaw = 0
C_Movement.m_flLastGroundZ = 0
C_Movement.m_nCircleDir = 0

local C_TriggerBot = {}
C_TriggerBot.m_tSpreadSeeds = {}

local C_Visuals = {}
C_Visuals.m_tPlayersAvatars = {}
C_Visuals.m_tRenderAlpha = {}
C_Visuals.m_tBulletTracers = {}
C_Visuals.m_tAlreadyTracers = {
	["rb655_nyan_tracer"] = true,
	["impact"] = true,
	["ragdollimpact"] = true,
}

local C_CreateMove = {}
C_CreateMove.m_bIsSimulated = false
C_CreateMove.m_bCanShoot = false
C_CreateMove.m_flServerTime = 0.0
C_CreateMove.m_nSlowShootTicks = 0
C_CreateMove.m_vSavedShootPos = Vector()

--[[
	Non-class functions
]]

local function Log(String, ...)
	MsgC(color_gray, "[", color_lavender, "Zenith", color_gray, "] ", color_seafoam, string.format(String, ...))
	MsgN()
end

local function enum(prefix, id) -- hono
	if not g_tEnums[prefix] then
		g_tEnums[prefix] = {}
	end

	if istable(id) and not table.IsEmpty(id) then
		for k,v in next, id do
			enum(prefix, v)
		end
	else
		-- don't put this one in _G, but still populate the enum table
		if id == false then
			table.insert(g_tEnums[prefix], table.IsEmpty(g_tEnums[prefix]) and 0 or #g_tEnums[prefix] + 1, id)
			return
		end

		local key = prefix:upper() .. "_" .. id:upper()
		local value = table.IsEmpty(g_tEnums[prefix]) and 0 or #g_tEnums[prefix] + 1
		_ENV[key] = value

		table.insert(g_tEnums[prefix], value, id)
	end
end

local function XORString(text) -- hono
	if not isstring(text) then return end

	if g_tAlreadyXOR[text] then
		return g_tAlreadyXOR[text]
	end

	local key = "rhoads"
	local out = {}

	for i = 1, #text do
		out[i] = bit.bxor(string.byte(text[i]), string.byte(key[i % #key]))
	end

	local strOut = string.char(unpack(out))

	g_tAlreadyXOR[text] = strOut
	g_tAlreadyXOR[strOut] = text
	g_tXORToRegular[strOut] = text

	return strOut
end

local function AddHook(strType, pFunction)
	local strName = XORString(tostring({}))

	g_tLocalHooks[#g_tLocalHooks + 1] = {
		m_strType = strType,
		m_strName = strName
	}

	local ppFunction = function()
		local bSucc, strErr = pcall( pFunction )

		if not bSucc then
			error( strErr )
		end
	end

	hook.Add(strType, strName, ppFunction)

	Log("Hook Added! [{%s} {%s}]", strType, strName)
end

local function AddConCommand(Name, Function)
	Log("ConCommand Added! " .. Name)

	concommand.Add(Name, Function)
end

--[[
	Weapon Functions
]]

local function GetWeaponBase(hWeapon)
	if not hWeapon.Base then return "engine" end

	if hWeapon.Base:lower():Split("_")[1] == "weapon" then
		return hWeapon.Base:lower():Split("_")[2]
	end

	return hWeapon.Base:lower():Split("_")[1]
end

local function GetWeaponAmmoName(hWeapon)
	if hWeapon.Primary and hWeapon.Primary.Ammo then
		return string.lower(hWeapon.Primary.Ammo)
	else
		return string.lower(tostring(game.GetAmmoName(hWeapon:GetPrimaryAmmoType())))
	end
end

local tMeleeClasses = {
	["weapon_crowbar"] = true,
	["weapon_stunstick"] = true,
}
local function IsMeleeWeapon(hWeapon)
	if not (IsValid(hWeapon) and hWeapon:IsWeapon()) then return false end

	local strClass = hWeapon:GetClass()
	if tMeleeClasses[strClass] then return true end
	if string.find(strClass, "knife") then return true end -- see how much of a fuck i give

	return false
end

local function GetSimulationTime(pEntity)
	return pEntity:GetDTNetVar("DT_BaseEntity->m_flSimulationTime", 1)
end

local function GetTickBase(pEntity)
	return pEntity:GetDTNetVar("DT_LocalPlayerExclusive->m_nTickBase", 0)
end

--[[
	Math functions
]]

local function TIME_TO_TICKS(flTime)
	return math.floor(0.5 + flTime / TICK_INTERVAL)
end

local function TICKS_TO_TIME(Tick)
	return TICK_INTERVAL * Tick
end

local function RoundToTicks(flTime)
	return TICK_INTERVAL * TIME_TO_TICKS(flTime)
end

function C_Math:CalcOptimalElevation(flDistance2D, flZDiff, flSpeed, flGravity)
	local flHorizontalDistanceSqr = flDistance2D * flDistance2D
	local flSpeedSqr = flSpeed * flSpeed
	local flSpeedBqr = flSpeedSqr * flSpeedSqr

	local flRoot = flSpeedBqr - flGravity * (flGravity * flHorizontalDistanceSqr + 2.0 * flZDiff * flSpeedSqr)
	if flRoot < 0.0 then
		return false
	end

	return math.atan((flSpeedSqr - math.sqrt(flRoot)) / (flGravity * flDistance2D))
end

function C_Math:TravelTime(flDistance2D, flLobAngle, flProjetcileSpeed)
	return flDistance2D / (math.cos(flLobAngle) * flProjetcileSpeed)
end

function C_Math:SolveQuadRoots(a, b, c, roots)
	if a == 0 then
		if b ~= 0 then
			-- no x^2 component, it's a linear system
			roots[1] = -c / b
			roots[2] = 1 * roots[1]
			return true
		end

		if c == 0 then
			-- all zeros
			roots[1] = 0
			roots[2] = 0
			return true
		end

		return false
	end

	local flDiscrim = b * b - 4.0 * a * c
	if flDiscrim < 0 then
		-- imaginary number, bah, no solution.
		return false
	end

	a = a * 2
	flDiscrim = math.sqrt(flDiscrim)
	roots[1] = (-b + flDiscrim) / a
	roots[2] = (-b - flDiscrim) / a

	return true
end

function C_Math:ClipTraceToSphere(vRayStart, vRayDelta, vOrigin, flRadius)
	local vSphereToRay = vRayStart - vOrigin

	local out = {
		Hit = false,
		HitPos = Vector(0, 0, 0),
		HitNormal = Vector(0, 0, 0),
		Fraction = 1,
		StartSolid = false
	}

	local a = vRayDelta:LengthSqr()
	local b = 2.0 * vRayDelta:Dot(vSphereToRay)
	local c = vSphereToRay:LengthSqr() - flRadius * flRadius
	local roots = {}
	if not self:SolveQuadRoots(a, b, c, roots) then
		--print(c <= 0)
		return out --Either(c <= 0.0, 0.0, -1.0) -- Return if origin is inside the sphere
	end

	local flFraction = 0
	-- Sort so that the smallest is first
	if roots[1] > roots[2] then
		flFraction = roots[2]
	else
		flFraction = roots[1]
	end

	-- Trace starts inside of the sphere.
	if flFraction < 0.0 then
		out.Hit = true
		out.HitPos:Set(vRayStart)
		out.HitNormal:Set(vRayDelta:GetNormalized())
		out.Fraction = 0
		out.StartSolid = true
		return out
	end

	-- Trace intersects with the sphere.
	if flFraction < out.Fraction then
		local vHitPos = vRayStart + vRayDelta * flFraction
		local vHitNormal = (vHitPos - vOrigin):GetNormalized()

		out.Hit = true
		out.HitPos:Set(vHitPos)
		out.HitNormal:Set(vHitNormal)
		out.Fraction = flFraction
		-- out.StartSolid = false
	end

	return out
end

function C_Math:ClipTraceToBox(vDirect, vStart, vMins, vMaxs)
	local dirfrac = {}

	dirfrac.x = 1.0 / vDirect.x
	dirfrac.y = 1.0 / vDirect.y
	dirfrac.z = 1.0 / vDirect.z

	local t1 = (vMins.x - vStart.x) * dirfrac.x
	local t2 = (vMaxs.x - vStart.x) * dirfrac.x

	local t3 = (vMins.y - vStart.y) * dirfrac.y
	local t4 = (vMaxs.y - vStart.y) * dirfrac.y

	local t5 = (vMins.z - vStart.z) * dirfrac.z
	local t6 = (vMaxs.z - vStart.z) * dirfrac.z

	local tmin = math.max(math.max(math.min(t1, t2), math.min(t3, t4)), math.min(t5, t6))
	local tmax = math.min(math.min(math.max(t1, t2), math.max(t3, t4)), math.max(t5, t6))

	if tmax < 0 then
		return false, tmax
	end

	if tmin > tmax then
		return false, tmax
	end

	return true, tmin
end

function C_Math:SegmentToSegment(s1, s2, k1, k2)
	local epsilon = 0.00000001

	local u = s2 - s1
	local v = k2 - k1
	local w = s1 - k1

	local a = u:Dot(u)
	local b = u:Dot(v)
	local c = v:Dot(v)
	local d = u:Dot(w)
	local e = v:Dot(w)
	local D = a * c - b * b
	local sn, sd = 0.0, D
	local tn, td = 0.0, D

	if D < epsilon then
		sn, sd = 0.0, 1.0
		tn = e
		td = c
	else
		sn = b * e - c * d
		tn = a * e - b * d

		if sn < 0.0 then
			sn, tn, td = 0.0, e, c
		elseif sn > sd then
			sn, tn, td = sd, e + b, c
		end
	end

	if tn < 0.0 then
		tn = 0.0
		if -d < 0.0 then
			sn = 0.0
		elseif -d > a then
			sn = sd
		else
			sn, sd = -d, a
		end
	elseif tn > td then
		tn = td
		if -d + b < 0.0 then
			sn = 0
		elseif -d + b > a then
			sn = sd
		else
			sn, sd = -d + b, a
		end
	end

	local sc = math.abs(sn) < epsilon and 0.0 or sn / sd
	local tc = math.abs(tn) < epsilon and 0.0 or tn / td

	local n = {}
	local dp = w + u * sc - v * tc
	n[1] = dp:Dot(dp)
	local calc = math.sqrt(n[1])

	return calc
end

function C_Math:VectorITransform(inVec, matrix, outVec)
	local diff = {
		inVec[1] - matrix[1][4],
		inVec[2] - matrix[2][4],
		inVec[3] - matrix[3][4]
	}

	outVec[1] = diff[1] * matrix[1][1] + diff[2] * matrix[2][1] + diff[3] * matrix[3][1]
	outVec[2] = diff[1] * matrix[1][2] + diff[2] * matrix[2][2] + diff[3] * matrix[3][2]
	outVec[3] = diff[1] * matrix[1][3] + diff[2] * matrix[2][3] + diff[3] * matrix[3][3]
end

function C_Math:VectorIRotate(inVec, matrix, outVec)
	outVec[1] = inVec[1] * matrix[1][1] + inVec[2] * matrix[2][1] + inVec[3] * matrix[3][1]
	outVec[2] = inVec[1] * matrix[1][2] + inVec[2] * matrix[2][2] + inVec[3] * matrix[3][2]
	outVec[3] = inVec[1] * matrix[1][3] + inVec[2] * matrix[2][3] + inVec[3] * matrix[3][3]
end

function C_Math:IntersectBB(start, _end, min, max)
	local d1, d2, f
	local start_solid = true
	local t1, t2 = -1.0, 1.0

	local s = {start[1], start[2], start[3]}
	local e = {_end[1], _end[2], _end[3]}
	local mi = {min[1], min[2], min[3]}
	local ma = {max[1], max[2], max[3]}

	for i = 0, 5 do
		if i >= 3 then
			local j = i - 3
			d1 = s[j + 1] - ma[j + 1]
			d2 = d1 + e[j + 1]
		else
			d1 = -s[i + 1] + mi[i + 1]
			d2 = d1 - e[i + 1]
		end

		if d1 > 0.0 and d2 > 0.0 then
			return false
		end

		if d1 <= 0.0 and d2 <= 0.0 then
			-- continue
		end

		if d1 > 0 then
			start_solid = false
		end

		if d1 > d2 then
			f = d1
			if f < 0.0 then
				f = 0.0
			end

			f = f / (d1 - d2)
			if f > t1 then
				t1 = f
			end
		else
			f = d1 / (d1 - d2)
			if f < t2 then
				t2 = f
			end
		end
	end

	return start_solid or (t1 < t2 and t1 >= 0.0)
end

function C_Math:Intersect(start, _end, a, b, radius)
	local dist = self:SegmentToSegment(a, b, start, _end)
	return dist < radius
end

function C_Math:VectorTransform(in1, in2, out)
	local in2Column0 = Vector(in2:GetField(1, 1), in2:GetField(1, 2), in2:GetField(1, 3))
	local in2Column1 = Vector(in2:GetField(2, 1), in2:GetField(2, 2), in2:GetField(2, 3))
	local in2Column2 = Vector(in2:GetField(3, 1), in2:GetField(3, 2), in2:GetField(3, 3))

	local x = in1:Dot(in2Column0) + in2:GetField(1, 4)
	local y = in1:Dot(in2Column1) + in2:GetField(2, 4)
	local z = in1:Dot(in2Column2) + in2:GetField(3, 4)

	if out then
		out:SetUnpacked(x, y, z)
		return
	end

	return Vector(x, y, z)
end

function C_Math:fsel(c, x, y)
	return c >= 0 and x or y
end

function C_Math:RemapValClamped(val,a,b,c,d)
	if a == b then
		return self:fsel(val - b, d, c)
	end

	local cVal = (val - a) / (b - a)
	cVal = math.Clamp(cVal, 0, 1)

	return c + (d - c) * cVal
end

function C_Math:Sign(p1, p2, p3) -- https://en.wikipedia.org/wiki/Barycentric_coordinate_system
	if not p1 or not p2 or not p3 then return 0 end

	return (p1.x - p3.x) * (p2.y - p3.y) - (p2.x - p3.x) * (p1.y - p3.y)
end

function C_Math:DistanceFromCrosshair(vPosition)
	if not vPosition then return 360 end

	local vDirection = vPosition - g_pLocalPlayer:GetShootPos()
	vDirection:Normalize()

	local flDot = g_pLocalPlayer:EyeAngles():Forward():Dot(vDirection)
	local flDegrees = math.deg(math.acos(flDot))

	return math.abs(flDegrees)
end

function C_Math:FixAngle(qAngle)
	qAngle.p = math.Clamp(math.NormalizeAngle(qAngle.p), -89, 89)
	qAngle.y = math.NormalizeAngle(qAngle.y)
	qAngle.r = math.NormalizeAngle(qAngle.r)
end

-- blacks replacement for math.random()
local A1, A2 = 727595, 798405  -- 5^17=D20*A1+A2
local D20, D40 = 1048576, 1099511627776  -- 2^20, 2^40
local X1, X2 = 0, 1

local function rand()
	local U = X2 * A2
	local V = (X1 * A2 + X2 * A1) % D20

	V = (V * D20 + U) % D40

	X1 = math.floor(V / D20)
	X2 = V - X1 * D20

	return V / D40
end

local function GetViewFOV()
	local view = render.GetViewSetup()
	return view.fov_unscaled
end

--[[
	Lua Table Switch-Statement
]]

local function Switch(hValue, ...)
	local pDefault

	for _, v in ipairs({...}) do
		if v.m_default then
			pDefault = v.m_function
			continue
		end

		if hValue == v.m_value then
			v.m_function()
			return
		end
	end

	if isfunction(pDefault) then
		pDefault()
	end
end

local function Case(hValue, hFunction)
	return {
		m_value = hValue,
		m_function = hFunction
	}
end

local function Default(hFunction)
	return {
		m_default = true,
		m_function = hFunction
	}
end

--[[
	RandomString from leme
]]

local CharRanges = {
	{65, 90}, -- A-Z
	{97, 122}, -- a-z
	{48, 57}, -- 0-9
	{33, 47}, -- ! - /
	{58, 64}, -- : - @
	{91, 96}, -- [ - `
	{123, 126} -- { - ~
}

local function RandomString(len, symbols)
	assert(isnumber(len), "Bad argument #1 to RandomString (number expected, got )" .. type(len))
	assert(len > 0, "Bad argument #1 to RandomString (number must be > 0)")

	if symbols ~= nil then
		assert(isbool(symbols), "Bad argument #2 to RandomString (boolean expected, got )" .. type(symbols))
	end

	symbols = symbols or false

	local max = symbols and #CharRanges or 3
	local str = ""

	for i = 1, len do
		local set = CharRanges[math.random(1, max)]

		str = str .. string.char(math.random(set[1], set[2]))
	end

	return str
end

--[[
	Misc
]]

function C_CreateMove:AutoClicker(pUserCmd)
	if not IsValid(g_pActiveWeapon) then return end

	if Config["autoclicker_usespam"] and pUserCmd:KeyDown(IN_USE) then
		if engine.TickCount() % 2 == 0 then
			pUserCmd:AddKey(IN_USE)
		else
			pUserCmd:RemoveKey(IN_USE)
		end
	end

	if Config["autoclicker_flashlightspam"] then
		pUserCmd:SetImpulse(100)
	end

	if Config["autoclicker_rapidfire_enabled"] and (g_pActiveWeapon.Primary and not g_pActiveWeapon.Primary.Automatic) or g_pActiveWeapon:GetClass() == "weapon_pistol" or g_pActiveWeapon:GetClass() == "weapon_pistolr" then
		if not Config["autoclicker_rapidfire_toolgun"] and g_pActiveWeapon:GetClass() == "gmod_tool" then
			return
		end

		if pUserCmd:KeyDown(IN_ATTACK) and pUserCmd:TickCount() % 2 == 0 then
			pUserCmd:RemoveKey(IN_ATTACK)
		end
	end
end

--[[
	Sequence Freeze
]]

local bHeldLastTick = false
local ATTACK = bit.bor(IN_ATTACK, IN_ATTACK2)
function C_CreateMove:DoubleTap(pUserCmd)
	if not Config["sequencefreeze_doubletap"] then return end
	if not C_CreateMove.m_bCanShoot then return end -- prevent gay guns from double tapping

	if pUserCmd:KeyDown(ATTACK) and not bHeldLastTick then
		proxi.SetSequenceNumber(proxi.GetSequenceNumber() + math.floor(1 / TICK_INTERVAL) - 1)
		pUserCmd:SetTickCount(pUserCmd:TickCount() + TIME_TO_TICKS(1) + 1)

		g_bSequenceRan = true

		return
	end

	bHeldLastTick = pUserCmd:KeyDown(ATTACK)
end

local nNextCharge = 0
local nLastCharge = 0
local nLastChargeSequence = proxi.GetSequenceNumber()
function C_CreateMove:FakeTeleport()
	if not Config["sequencefreeze_teleport_enabled"] then return end

	local flServerTime = C_CreateMove.m_flServerTime

	if input.IsButtonDown(Config["sequencefreeze_teleport_key"]) then -- Release charged ticks
		if flServerTime >= nNextCharge then
			proxi.SetSequenceNumber(proxi.GetSequenceNumber() + (sv_maxusrcmdprocessticks:GetInt() - 1))

			nNextCharge = flServerTime + 1

			g_bSequenceRan = true
		end
	else
		if flServerTime < nNextCharge then -- Recharge ticks
			if flServerTime - nLastCharge >= 0.1 then
				nLastChargeSequence = proxi.GetSequenceNumber()
				nLastCharge = flServerTime
			else
				proxi.SetSequenceNumber(nLastChargeSequence)
				g_bSequenceRan = true
			end
		end
	end
end

--[[
	Name Stealer
]]

local strZeroWidth = "\xe2\x80\x8b"

local g_strOriginalName = g_pLocalPlayer:GetName()
local g_strCurrName = g_strOriginalName

local function ChangeName(strDesiredName)
	strDesiredName = string.sub(strDesiredName, 1, 127)
	g_strCurrName = strDesiredName
	cv_name:SendValue(strDesiredName)
end

local function GetRandomPlayer()
	return g_tPlayers[math.random(1, #g_tPlayers)] or NULL
end

local function StealName(hPlayer)
	if not IsValid(hPlayer) then
		return false
	end

	local strName = hPlayer:Nick()

	local iSplit1 = math.random(1, math.floor(#strName / 2))
	local iSplit2 = math.random(math.floor(#strName / 2) + 1, #strName)

	local strSetName = string.format("%s%s%s%s%s%s%s",
		string.sub(strName, 1, iSplit1), strZeroWidth,
		string.sub(strName, iSplit1 + 1, math.floor(#strName / 2)) , strZeroWidth,
		string.sub(strName, math.floor(#strName / 2) + 1, iSplit2), strZeroWidth,
		string.sub(strName, iSplit2 + 1, #strName)
	)

	ChangeName(strZeroWidth .. strSetName .. strZeroWidth)
	g_strCurrName = strName

	return true
end


--[[
	Hitbox Manager
]]

function C_HitboxManager:ParseModelData(pEntity, strModel)
	if not isstring(strModel) or strModel == "" then
		print(string.format("model for %s is invalid", pEntity))
		return
	end

	pEntity:InvalidateBoneCache()
	pEntity:SetupBones()

	local iBoneCount = pEntity:GetBoneCount()
	if not iBoneCount or iBoneCount < 0 then
		print(string.format("model doesnt have enough bones for %s", pEntity))
		return
	end

	local iHitboxSetCount = pEntity:GetHitboxSetCount()
	if not iHitboxSetCount or iHitboxSetCount == 0 then
		print(string.format("model doesnt have any hitboxes for %s", pEntity))
		return
	end

	local pModelData = self.m_tModelData[strModel]
	if not pModelData then
		pModelData = C_ModelData()
		self.m_tModelData[strModel] = pModelData
	end

	local pHitboxSets = pModelData.m_tHitboxSets

	for iHitboxSet = 0, iHitboxSetCount - 1 do
		for iHitbox = 0, pEntity:GetHitBoxCount(iHitboxSet) - 1 do
			local iBone = pEntity:GetHitBoxBone(iHitbox, iHitboxSet)

			if pEntity:BoneHasFlag(iBone, BONE_PHYSICALLY_SIMULATED) or pEntity:BoneHasFlag(iBone, BONE_PHYSICS_PROCEDURAL) or pEntity:BoneHasFlag(iBone, BONE_ALWAYS_PROCEDURAL) then
				print(string.format("bone %s has fucked flags; ignoring bone from %s", iBone, pEntity))
				continue
			end

			local iHitGroup = pEntity:GetHitBoxHitGroup(iHitbox, iHitboxSet)
			if iHitGroup == HITGROUP_GEAR then
				continue
			end

			local vBoxMins, vBoxMaxs = pEntity:GetHitBoxBounds(iHitbox, iHitboxSet)
			local vSize = vBoxMins - vBoxMaxs

			table.insert(pHitboxSets[iHitGroup], {
				m_nBone = iBone,

				m_flVolume = math.abs(vSize.x * vSize.y * vSize.z),
				m_vCenter = (vBoxMins + vBoxMaxs) * 0.5,

				m_vMins = vBoxMins,
				m_vMaxs = vBoxMaxs,

				m_tCorners = { -- insert points so you dont miss and look STUPID
					Vector(vBoxMins.x + 1, vBoxMins.y + 1, vBoxMins.z + 1),
					Vector(vBoxMaxs.x - 1, vBoxMaxs.y - 1, vBoxMaxs.z - 1),
					Vector(vBoxMins.x + 1, vBoxMins.y + 1, vBoxMaxs.z - 1),
					Vector(vBoxMaxs.x - 1, vBoxMins.y + 1, vBoxMaxs.z - 1),
					Vector(vBoxMaxs.x - 1, vBoxMaxs.y - 1, vBoxMins.z + 1),
					Vector(vBoxMaxs.x - 1, vBoxMins.y + 1, vBoxMins.z + 1),
					Vector(vBoxMins.x + 1, vBoxMaxs.y - 1, vBoxMins.z + 1),
					Vector(vBoxMins.x + 1, vBoxMaxs.y - 1, vBoxMaxs.z - 1)
				}
			})
		end
	end

	for _, pHitboxes in pairs(pHitboxSets) do
		table.sort(pHitboxes, function(lhs, rhs)
			return lhs.m_flVolume > rhs.m_flVolume
		end)
	end

	pModelData.m_bIsValid = true
	Log("Parsed %s hitbox data sucessfully", strModel)
end

function C_HitboxManager:GetModelData(pEntity)
	if not IsValid(pEntity) then
		return false
	end

	local strModel = pEntity:GetModel()

	if not self.m_tModelData[strModel] then
		self:ParseModelData(pEntity, strModel)
	end

	return self.m_tModelData[strModel]
end

timer.Simple(0, function() -- initalize
	for _, v in pairs(player.GetAll()) do
		C_HitboxManager:GetModelData(v)
	end
end)

--[[
	Input System
]]

enum("BIND_METHOD", {
	"HELD",
	"TOGGLE",
})

function C_Inputs:IsKeyActive(tbl, key)
	if input.IsKeyTrapping() then return false end

	if not isnumber(tbl[key]) then
		tbl[key] = KEY_NONE
	end

	local bIsKeyboardValid = IsValid(vgui.GetKeyboardFocus())

	if Config["bindtogglemodes"][key] == BIND_METHOD_TOGGLE then
		if self.m_tKeyStates[key] == nil then
			self.m_tKeyStates[key] = false
		end

		local bIsButtonDown = input.IsButtonDown(tbl[key])
		if bIsButtonDown and not self.m_tIsKeyDown[key] and not bIsKeyboardValid then
			self.m_tKeyStates[key] = not self.m_tKeyStates[key]
		end

		self.m_tIsKeyDown[key] = bIsButtonDown

		return self.m_tKeyStates[key]
	elseif Config["bindtogglemodes"][key] == BIND_METHOD_HELD and not bIsKeyboardValid then
		return input.IsButtonDown(tbl[key])
	end

	return false
end

--[[
	UniformRandomStream
]]

local UniformRandomStream
do
	local META = {
		m_iv = {}, -- array, size == NTAB
	}

	META.__index = META
	META.__tostring = function(self)
		return "UniformRandomStream [" .. self.m_idum .. "]"
	end

	function UniformRandomStream(seed)
		local obj = setmetatable({}, META)
		obj:SetSeed(tonumber(seed) or 0)

		return obj
	end

	-- https://github.com/VSES/SourceEngine2007/blob/master/src_main/vstdlib/random.cpp#L16

	local IA = 16807
	local IM = 2147483647
	local IQ = 127773
	local IR = 2836
	local NTAB = 32
	local NDIV = (1 + (IM - 1) / NTAB)
	local MAX_RANDOM_RANGE = 0x7FFFFFFF

	-- fran1 -- return a random floating-point number on the interval [0,1])
	local AM = (1 / IM)
	local EPS = 1.2e-7
	local RNMX = (1 - EPS)

	function META:SetSeed(iSeed)
		self.m_idum = iSeed < 0 and iSeed or -iSeed
		self.m_iy = 0
	end

	local int = math.floor
	function META:GenerateRandomNumber()
		local j, k
		if (self.m_idum <= 0 or not self.m_iy) then
			if (-self.m_idum < 1) then
				self.m_idum = 1
			else
				self.m_idum = -self.m_idum
			end

			j = NTAB + 8
			while true do
				if j <= 0 then break end
				j = j - 1

				k = int(self.m_idum / IQ)
				self.m_idum = int(IA * (self.m_idum-k * IQ) - IR * k)
				if (self.m_idum < 0)  then
					self.m_idum = int(self.m_idum + IM)
				end
				if (j < NTAB) then
					self.m_iv[j] = int(self.m_idum)
				end
			end
			self.m_iy = self.m_iv[0]
		end

		k = int(self.m_idum / IQ)
		self.m_idum = int(IA * (self.m_idum-k * IQ) - IR * k)
		if (self.m_idum < 0) then
			self.m_idum = int(self.m_idum + IM)
		end
		j = int(self.m_iy / NDIV)

		if (j >= NTAB or j < 0) then
			ErrorNoHalt(string.format("CUniformRandomStream had an array overrun: tried to write to element %d of 0..31.", j))
			j = int(bit.band( j % NTAB, 0x7fffffff))
		end

		self.m_iy = int(self.m_iv[j])
		self.m_iv[j] = int(self.m_idum)

		return self.m_iy
	end

	function META:RandomFloat(flLow, flHigh)
		flLow = flLow or 0
		flHigh = flHigh or 1

		local fl = AM * self:GenerateRandomNumber()
		if fl > RNMX then
			fl = RNMX
		end

		return (fl * ( flHigh - flLow ) ) + flLow -- float in [low,high]
	end

	function META:RandomFloatExp(flMinVal, flMaxVal, flExponent)
		flMinVal = flMinVal or 0
		flMaxVal = flMaxVal or 1
		flExponent = flExponent or 1

		local fl = AM * self:GenerateRandomNumber()
		fl = math.min(fl, RNMX)

		if flExponent ~= 1 then
			fl = math.pow(fl, flExponent)
		end

		return (fl * ( flMaxVal - flMinVal ) ) + flMinVal
	end

	function META:RandomInt(iLow, iHigh)
		iLow = iLow or 0 iHigh = iHigh or 100
		iLow = math.floor(iLow) iHigh = math.floor(iHigh)
		local iMaxAcceptable, n
		local x = iHigh - iLow + 1

		if x <= 1 or MAX_RANDOM_RANGE < x-1 then
			return iLow
		end

		iMaxAcceptable = math.floor(MAX_RANDOM_RANGE - ((MAX_RANDOM_RANGE + 1) % x ))
		n = self:GenerateRandomNumber()
		while n > iMaxAcceptable do
			n = self:GenerateRandomNumber()
		end

		return iLow + (n % x)
	end
end

do
	local ai_shot_bias_min = proxi.GetConVar("ai_shot_bias_min")
	local ai_shot_bias_max = proxi.GetConVar("ai_shot_bias_max")

	local pRandomStream = UniformRandomStream()

	for iSeed = 0, 255 do
		pRandomStream:SetSeed(iSeed)

		local x,y,z = 0, 0, 0
		local bias = 1

		local shotBiasMin = ai_shot_bias_min:GetFloat()
		local shotBiasMax = ai_shot_bias_max:GetFloat()

		local shotBias = ((shotBiasMax - shotBiasMin ) * bias) + shotBiasMin
		local flatness = math.abs(shotBias) * 0.5

		repeat
			x = pRandomStream:RandomFloat(-1, 1) * flatness + pRandomStream:RandomFloat(-1, 1) * (1 - flatness)
			y = pRandomStream:RandomFloat(-1, 1) * flatness + pRandomStream:RandomFloat(-1, 1) * (1 - flatness)

			if shotBias < 0 then
				x = (x >= 0) and 1.0 - x or -1.0 - x
				y = (y >= 0) and 1.0 - y or -1.0 - y
			end

			z = (x * x) + (y * y)
		until z <= 1

		g_tWeaponSpreadSeeds[iSeed] = {
			x = x,
			y = y,
			z = z
		}
	end

	local VECTOR_CONE_1DEGREES	= Vector( 0.00873, 0.00873, 0.00873 )
	local VECTOR_CONE_3DEGREES	= Vector( 0.02618, 0.02618, 0.02618 )
	local VECTOR_CONE_5DEGREES	= Vector( 0.04362, 0.04362, 0.04362 )
	local VECTOR_CONE_6DEGREES	= Vector( 0.05234, 0.05234, 0.05234 )
	local VECTOR_CONE_10DEGREES = Vector( 0.08716, 0.08716, 0.08716 )

	g_tWeaponSpreadCones = {
		weapon_smg1 = VECTOR_CONE_5DEGREES,
		weapon_ar2 = VECTOR_CONE_3DEGREES,
		weapon_357 = vector_origin,
		weapon_pistol = function(wep)
			local nv = wep:GetInternalVariable("m_flAccuracyPenalty")
			local ramp = C_Math:RemapValClamped(nv, 0, 1.5, 0, 1)
			local cone = LerpVector(ramp, VECTOR_CONE_1DEGREES, VECTOR_CONE_6DEGREES)

			return cone
		end,
		weapon_shotgun = VECTOR_CONE_10DEGREES,

		-- hl1 weapons
		weapon_357_hl1 = VECTOR_CONE_1DEGREES,
		weapon_mp5_hl1 = VECTOR_CONE_3DEGREES,
		weapon_gauss = vector_origin,
		weapon_glock_hl1 = function(wep)
			if g_pLocalPlayer:KeyDown(IN_ATTACK2) then
				return Vector(0.1, 0.1, 0.1)
			end

			return Vector(0.01, 0.01, 0.01)
		end,
		weapon_shotgun_hl1 = function(wep)
			if g_pLocalPlayer:KeyDown(IN_ATTACK2) then
				return Vector(VECTOR_CONE_10DEGREES.x * 2, VECTOR_CONE_10DEGREES.x / 2)
			end

			return Vector(VECTOR_CONE_10DEGREES.x, VECTOR_CONE_10DEGREES.x / 2)
		end
	}
end

--[[
	Autowall
]]

C_AutoWall.m_tFunction = {
	["bobs"] = function(self, trData)
		if M9KDisablePenetration:GetBool() then
			return nil
		end

		local DataTable = C_AutoWall.m_tLimits[GetWeaponAmmoName(self)]
		if not DataTable then return nil end

		return DataTable[1], DataTable[2]
	end,
	["tfa"] = function(self, trData)
		if not sv_tfa_bullet_penetration:GetBool() then
			return nil
		end

		local ForceMultiplier = self:GetAmmoForceMultiplier()
		local PenetrationMultiplier = self:GetPenetrationMultiplier(trData.MatType)
		local ConVarMultiplier = sv_tfa_bullet_penetration_power_mul and sv_tfa_bullet_penetration_power_mul:GetFloat() or 1.0

		local DataTable = C_AutoWall.m_tLimits[GetWeaponAmmoName(self)]
		local MaxPen = math.Clamp(DataTable and DataTable[2] or 1, 0, sv_tfa_penetration_hardlimit and sv_tfa_penetration_hardlimit:GetInt() or 1)

		return math.Truncate(((ForceMultiplier / PenetrationMultiplier) * ConVarMultiplier) * 0.9, 5), MaxPen
	end,
	["arccw"] = function(self, trData)
	if not arccw_enable_penetration:GetBool() then
		return nil
		end

		local DataTable = C_AutoWall.m_tLimits[GetWeaponAmmoName(self)]
		return math.pow(self.Penetration, 2), DataTable and DataTable[2] or 1
	end,
	["cw"] = function(self, trData)
		if not C_AutoWall:CWCanPenetrate(self, trData) then return nil end

		local Strength = self.PenStr * self.PenMod
		local Multiplier = self.PenetrationMaterialInteraction and self.PenetrationMaterialInteraction[trData.MatType] or 1
		return math.pow(Strength, 2) + (Strength * Multiplier), 1
	end,
	["fas2"] = function(self, trData)
		if not C_AutoWall:CWCanPenetrate(self, trData) then return nil end

		local Strength = self.PenStr * self.PenMod
		local Multiplier = C_AutoWall.m_tMultipliers[trData.MatType] or 1
		return math.pow(Strength, 2) + (Strength * Multiplier), 1
	end,
	["swb"] = function(self, trData)
		if not C_AutoWall:CWCanPenetrate(self, trData) then return nil end

		local DataTable = C_AutoWall.m_tLimits[GetWeaponAmmoName(self)]
		if not DataTable then return nil end

		local Multiplier = C_AutoWall.m_tMultipliers[trData.MatType] or 1
		return DataTable[1] * Multiplier * self.PenMod, 1
	end,
	["swcs"] = function(self, trData)
		local MaxPen = self:GetPenetration()
		local flPenetrationDistance = 130 -- this is the max distance swcs can penetrate

		return flPenetrationDistance, MaxPen
	end
}

function C_AutoWall:CWCanPenetrate(hWeapon, trData)
	if self.m_tCancellers[trData.MatType] or (hWeapon.CanPenetrate ~= nil and not hWeapon.CanPenetrate) then
		return false
	end

	local pEntity = trData.Entity
	if IsValid(pEntity) and (pEntity:IsPlayer() or pEntity:IsNPC()) then
		return false
	end

	return -trData.Normal:Dot(trData.HitNormal) > 0.26
end

function C_AutoWall:GetWeaponPenetrationDistance(hWeapon, trData)
	local strBase = GetWeaponBase(hWeapon)

	if self.m_tFunction[strBase] then
		return self.m_tFunction[strBase](hWeapon, trData)
	end

	return nil
end

function C_AutoWall:WeaponCanPenetrate(hWeapon, trData, pTarget, vPosition)
	local flMaxDistance, nMaxTimes = self:GetWeaponPenetrationDistance(hWeapon, trData)
	if not flMaxDistance then return false end

	local trResult = {} -- Create our own here to avoid interference
	local Trace = {
		start = vPosition,
		endpos = trData.HitPos,
		filter = {pTarget},
		mask = MASK_SHOT,
		output = trResult
	}

	util.TraceLine(Trace)

	local nCurTimes = 1
	local vEndPos = trResult.HitPos

	local pWorld = game.GetWorld()
	if g_pActiveWeapon.IsTFAWeapon then flMaxDistance = flMaxDistance / 2 end

	while nCurTimes <= nMaxTimes do
		if trResult.Entity == pWorld then
			local vOldEndPos = Trace.endpos

			for i = 1, 75 do
				Trace.start = trResult.HitPos - (trData.Normal * 10)
				Trace.endpos = Trace.start

				util.TraceLine(Trace)

				if not trResult.HitWorld then break end
			end

			Trace.endpos = vOldEndPos
		else
			if trResult.Entity == pTarget then break end

			local pEntity = trResult.Entity
			Trace.start = vEndPos

			util.TraceLine(Trace)

			Trace.start = trResult.HitPos - trData.Normal
			Trace.endpos = vEndPos
			Trace.filter[2] = pEntity

			util.TraceLine(Trace)
		end

		local flCurrentDistance
		if g_pActiveWeapon.IsTFAWeapon then
			flCurrentDistance = trResult.HitPos:Distance(vEndPos) / 88.88
		else
			flCurrentDistance = math.floor(trResult.HitPos:DistToSqr(vEndPos))
		end

		if flCurrentDistance > flMaxDistance then return false end

		if trResult.Hit then
			vEndPos = trResult.HitPos
		else
			local vOldEndPos = trData.HitPos

			Trace.endpos = trData.HitPos

			util.TraceLine(Trace)

			Trace.endpos = vOldEndPos

			if trResult.Hit then
				vEndPos = trResult.HitPos
			else
				if g_pActiveWeapon.IsTFAWeapon then
					flCurrentDistance = trResult.HitPos:Distance(vEndPos) / 88.88
				else
					flCurrentDistance = math.floor(trResult.HitPos:DistToSqr(vEndPos))
				end

				if flCurrentDistance <= flMaxDistance then
					break
				end
			end
		end

		nCurTimes = nCurTimes + 1
	end

	return nCurTimes <= nMaxTimes, nCurTimes
end

--[[
	Anim state
]]

local MultiplayerAnimState = {
	Instances = {},
	MaxAnimationLayers = 15
}

function MultiplayerAnimState:Create(identifier, ply)
	local animationState = {}

	animationState.Player = ply
	animationState.EyeYaw = 0
	animationState.EyePitch = 0
	animationState.AimYaw = 0
	animationState.AimPitch = 0
	animationState.Cycle = 0
	animationState.PrevCycle = 0
	animationState.Sequence = 0
	animationState.PrevSequence = 0
	animationState.GoalFeetYaw = 0
	animationState.CurrentFeetYaw = 0
	animationState.RenderAngles = Angle(0, 0, 0)
	animationState.AnimationLayers = {}
	animationState.AnimationTime = 0
	animationState.EstimateYaw = 0
	animationState.MoveX = 0
	animationState.MoveY = 0
	animationState.Velocity = Vector(0, 0, 0)

	for i = 0, self.MaxAnimationLayers do
		table.insert(animationState.AnimationLayers, i, {
			Cycle = 0,
			PrevCycle = 0,
			Sequence = 0,
			PrevSequence = 0,
			Weight = 0,
			PrevWeight = 0
		})
	end

	table.insert(self.Instances, identifier, animationState)
end

function MultiplayerAnimState:ConvergeYawAngles(identifier, goalYaw, yawRate, deltaTime, currentYaw)
	local deltaYaw = goalYaw - currentYaw
	local deltaYawAbs = math.abs(deltaYaw)
	deltaYaw = math.NormalizeAngle(deltaYaw)

	local scale = math.Clamp(deltaYawAbs / 60, 0.01, 1)
	local yaw = yawRate * deltaTime * scale

	if deltaYawAbs < yaw then
		currentYaw = goalYaw
	else
		local side = Either(deltaYaw < 0, -yaw, yaw)
		currentYaw = currentYaw + side
	end

	self.Instances[identifier].CurrentFeetYaw = math.NormalizeAngle(currentYaw)
end

MOVING_MINIMUM_SPEED = 0.5
function MultiplayerAnimState:CalcMovementSpeed(identifier)
	-- Get the player's current velocity and speed.
	local vecVelocity = self.Instances[identifier].Velocity
	local flSpeed = vecVelocity:Length2D()

	if ( flSpeed > MOVING_MINIMUM_SPEED ) then
		return flSpeed, true
	end

	return 0.0, false
end

function MultiplayerAnimState:EstimateYaw(identifier)
	local ply = self.Instances[identifier].Player
	local flDeltaTime = engine.TickInterval()

	local vecEstVelocity = self.Instances[identifier].Velocity
	local angles = ply:GetLocalAngles()

	if vecEstVelocity.x == 0.0 and vecEstVelocity.y == 0.0 then
		local flYawDelta = math.NormalizeAngle( angles.y - self.Instances[identifier].EstimateYaw )

		if flDeltaTime < 0.25 then
			flYawDelta = flYawDelta * ( flDeltaTime * 4.0 )
		else
			flYawDelta = flYawDelta * flDeltaTime
		end

		self.Instances[identifier].EstimateYaw = math.NormalizeAngle( self.Instances[identifier].EstimateYaw + flYawDelta )
	else
		self.Instances[identifier].EstimateYaw = math.atan2( vecEstVelocity.y, vecEstVelocity.x ) * 180.0 / math.pi
		self.Instances[identifier].EstimateYaw = math.Clamp( self.Instances[identifier].EstimateYaw, -180.0, 180.0 )
	end
end

function MultiplayerAnimState:ComputeMoveYaw(identifier)
	local ply = self.Instances[identifier].Player
	self:EstimateYaw(identifier)

	local flAngle = math.NormalizeAngle( self.Instances[identifier].EyeYaw )

	local flYaw = flAngle - self.Instances[identifier].EstimateYaw
	flYaw = math.NormalizeAngle( -flYaw )

	-- Get the current speed the character is running.
	local flSpeed, bIsMoving = self:CalcMovementSpeed(identifier)

	-- Setup the 9-way blend parameters based on our speed and direction.
	local vecCurrentMoveYaw = Vector( 0.0, 0.0 )
	if ( bIsMoving ) then
		--if ( mp_slammoveyaw.GetBool() ) then
		--	flYaw = SnapYawTo( flYaw )
		--end

		--if ( m_LegAnimType == LEGANIM_9WAY ) then
			-- convert YAW back into vector
			vecCurrentMoveYaw.x = math.cos( math.rad( flYaw ) )
			vecCurrentMoveYaw.y = -math.sin( math.rad( flYaw ) )
			-- push edges out to -1 to 1 box
			local flInvScale = math.max( math.abs( vecCurrentMoveYaw.x ), math.abs( vecCurrentMoveYaw.y ) )
			if ( flInvScale ~= 0.0 ) then
				vecCurrentMoveYaw.x = vecCurrentMoveYaw.x / flInvScale
				vecCurrentMoveYaw.y = vecCurrentMoveYaw.y / flInvScale
			end

			-- find what speed was actually authored
			local oldX, oldY = ply:GetPoseParameter("move_x"), ply:GetPoseParameter("move_y")
			ply:SetPoseParameter("move_x", vecCurrentMoveYaw.x)
			ply:SetPoseParameter("move_y", vecCurrentMoveYaw.y)
			local flMaxSpeed = ply:GetSequenceGroundSpeed( self.Instances[identifier].Sequence )

			-- restore
			ply:SetPoseParameter("move_x", oldX)
			ply:SetPoseParameter("move_y", oldY)

			-- scale playback
			if ( flMaxSpeed > flSpeed ) then
				vecCurrentMoveYaw.x = vecCurrentMoveYaw.x * (flSpeed / flMaxSpeed)
				vecCurrentMoveYaw.y = vecCurrentMoveYaw.y * (flSpeed / flMaxSpeed)
			end

			-- Set the 9-way blend movement pose parameters.
			self.Instances[identifier].MoveX = vecCurrentMoveYaw.x
			self.Instances[identifier].MoveY = vecCurrentMoveYaw.y
		--else
		--	-- find what speed was actually authored
		--	--GetBasePlayer()->SetPoseParameter( pStudioHdr, m_PoseParameterData.m_iMoveYaw, flYaw )
		--	--GetBasePlayer()->SetPoseParameter( pStudioHdr, m_PoseParameterData.m_iMoveScale, 1.0 )
		--	--local flMaxSpeed = GetBasePlayer()->GetSequenceGroundSpeed( GetBasePlayer()->GetSequence() )
		--	--
		--	---- scale playback
		--	--if ( flMaxSpeed > flSpeed ) then
		--	--	GetBasePlayer()->SetPoseParameter( pStudioHdr, m_PoseParameterData.m_iMoveScale, flSpeed / flMaxSpeed )
		--	--end
		--end
	else
		-- Set the 9-way blend movement pose parameters.
		self.Instances[identifier].MoveX = 0
		self.Instances[identifier].MoveY = 0
	end
end

function MultiplayerAnimState:ComputeAimPitch(identifier)
	local aimPitch = self.Instances[identifier].EyePitch
	-- Fake pitch herkz!
	if (aimPitch < -89 and aimPitch > -360) then -- inrange(aimPitch, -360, -89)
		aimPitch = 89
	end

	local hActiveWeapon = self.Instances[identifier].Player:GetActiveWeapon()
	if hActiveWeapon:IsValid() and hActiveWeapon.IsSWCSWeapon then
		aimPitch = math.NormalizeAngle(aimPitch + hActiveWeapon:GetNWFloat("m_flThirdpersonRecoil"))
	end

	-- Set the aim pitch pose parameter and save.
	self.Instances[identifier].AimPitch = aimPitch
end

function MultiplayerAnimState:ComputeAimYaw(identifier)
	local velocity = self.Instances[identifier].Velocity
	local isMoving = velocity:Length() > 1

	if isMoving then
		self.Instances[identifier].GoalFeetYaw = self.Instances[identifier].EyeYaw
	else
		local yawDelta = math.NormalizeAngle(self.Instances[identifier].GoalFeetYaw - self.Instances[identifier].EyeYaw)
		if (math.abs(yawDelta) > 45) then
			self.Instances[identifier].GoalFeetYaw = self.Instances[identifier].GoalFeetYaw + Either(yawDelta > 0, -45, 45)
		end
	end

	self.Instances[identifier].GoalFeetYaw = math.NormalizeAngle(self.Instances[identifier].GoalFeetYaw)
	if self.Instances[identifier].GoalFeetYaw ~= self.Instances[identifier].CurrentFeetYaw then
		self:ConvergeYawAngles(identifier, self.Instances[identifier].GoalFeetYaw, 720, engine.TickInterval(), self.Instances[identifier].CurrentFeetYaw)
	end
end

function MultiplayerAnimState:UpdateEyeAngles(identifier, eyeAngles)
	local ply = self.Instances[identifier].Player
	if not IsValid(ply) then
		table.remove(self.Instances[identifier])
		return
	end

	eyeAngles = eyeAngles or ply:EyeAngles()
	self.Instances[identifier].EyePitch = math.NormalizeAngle(eyeAngles.p)
	self.Instances[identifier].EyeYaw = math.NormalizeAngle(eyeAngles.y)

	self.Instances[identifier].Velocity:Set(ply:GetVelocity())
end

function MultiplayerAnimState:UpdateAnimationState(identifier)
	local ply = self.Instances[identifier].Player
	if not IsValid(ply) then
		table.remove(self.Instances[identifier])
		return
	end

	if ply:Alive() then
		self:ComputeMoveYaw(identifier)
		self:ComputeAimPitch(identifier)
		self:ComputeAimYaw(identifier)
	end
end

function MultiplayerAnimState:UpdateCachedPoseParameters(identifier)
	local ply = self.Instances[identifier].Player
	if not IsValid(ply) then
		self.Instances[identifier] = nil
		return
	end

	self.Instances[identifier].Cycle = ply:GetCycle()
	self.Instances[identifier].Sequence = ply:GetSequence()
	-- self.Instances[identifier].AnimationTime = ply:GetAnimTime()

	for i = 0, self.MaxAnimationLayers do
		self.Instances[identifier].AnimationLayers[i].Cycle = ply:GetLayerCycle(i)
		self.Instances[identifier].AnimationLayers[i].Sequence = ply:GetLayerSequence(i)
		self.Instances[identifier].AnimationLayers[i].Weight = ply:GetLayerWeight(i)
	end

	self.Instances[identifier].AimYaw = math.NormalizeAngle(self.Instances[identifier].EyeYaw - self.Instances[identifier].CurrentFeetYaw)
	self.Instances[identifier].RenderAngles.y = self.Instances[identifier].CurrentFeetYaw
end

function MultiplayerAnimState:ApplyCachedPoseParameters(identifier)
	local ply = self.Instances[identifier].Player
	if not IsValid(ply) then
		self.Instances[identifier] = nil
		return
	end

	if not ply:InVehicle() then
		ply:SetPoseParameter("aim_pitch", self.Instances[identifier].AimPitch)
		ply:SetPoseParameter("aim_yaw",	self.Instances[identifier].AimYaw)
		ply:SetPoseParameter("move_x",	self.Instances[identifier].MoveX)
		ply:SetPoseParameter("move_y",	self.Instances[identifier].MoveY)
		ply:SetRenderAngles(self.Instances[identifier].RenderAngles)
	end
end

function MultiplayerAnimState:ApplyAnimationLayers(identifier)
	local ply = self.Instances[identifier].Player
	if not IsValid(ply) then
		table.remove(self.Instances[identifier])
		return
	end

	self.Instances[identifier].PrevCycle = ply:GetCycle()
	self.Instances[identifier].PrevSequence = ply:GetSequence()
	self.Instances[identifier].AnimationTime = ply:GetAnimTime()

	ply:SetSequence(self.Instances[identifier].Sequence)
	ply:SetCycle(self.Instances[identifier].Cycle)
	ply:SetAnimTime(RoundToTicks(self.Instances[identifier].AnimationTime))

	for i = 0, self.MaxAnimationLayers do
		if ply:IsValidLayer(i) then
			self.Instances[identifier].AnimationLayers[i].PrevCycle = ply:GetLayerCycle(i)
			self.Instances[identifier].AnimationLayers[i].PrevSequence = ply:GetLayerSequence(i)
			self.Instances[identifier].AnimationLayers[i].PrevWeight = ply:GetLayerWeight(i)
		end

		ply:SetLayerSequence(i, self.Instances[identifier].AnimationLayers[i].Sequence)
		ply:SetLayerCycle(i, self.Instances[identifier].AnimationLayers[i].Cycle)
		ply:SetLayerWeight(i, self.Instances[identifier].AnimationLayers[i].Weight)
	end
end

function MultiplayerAnimState:RestoreAnimationLayers(identifier)
	local ply = self.Instances[identifier].Player
	if not IsValid(ply) then
		table.remove(self.Instances[identifier])
		return
	end

	ply:SetSequence(self.Instances[identifier].PrevSequence)
	ply:SetCycle(self.Instances[identifier].PrevCycle)
	ply:SetAnimTime(self.Instances[identifier].AnimationTime)

	for i = 0, self.MaxAnimationLayers do
		ply:SetLayerSequence(i, self.Instances[identifier].AnimationLayers[i].PrevSequence)
		ply:SetLayerCycle(i, self.Instances[identifier].AnimationLayers[i].PrevCycle)
		ply:SetLayerWeight(i, self.Instances[identifier].AnimationLayers[i].PrevWeight)
	end
end

--[[
	Lag Compensation

	https://github.com/ValveSoftware/source-sdk-2013/blob/master/mp/src/game/server/player_lagcompensation.cpp
]]

enum("BACKTRACK_VISUAL_STYLE", {
	false,
	"HITBOX",
	"CHAM"
})

enum("BACKTRACK_METHOD", {
	false,
	"FIRST",
	"LAST"
})

function LagCompensation:GetLerpTime()
	if not cl_interpolate:GetBool() then
		return 0.0
	end

	local flUpdateRate = math.Clamp(cl_updaterate:GetInt(), sv_minupdaterate:GetInt(), sv_maxupdaterate:GetInt())
	local flRatio = math.max(1, cl_interp_ratio:GetFloat())
	local flLerpAmount = cl_interp:GetFloat()

	if sv_client_min_interp_ratio:GetFloat() ~= 1 then
		flRatio = math.Clamp(flRatio, sv_client_min_interp_ratio:GetFloat(), sv_client_max_interp_ratio:GetFloat())
	end

	return math.max(flLerpAmount, flRatio / flUpdateRate)
end

function LagCompensation:ShouldCareAboutEntity(pEntity)
	if not IsValid(pEntity) or pEntity:IsDormant() or not pEntity:Alive() or pEntity == g_pLocalPlayer then return false end
	if pEntity:InVehicle() then return false end
	if Config["ragebot_ignoreplayers"] then return false end
	if Config["ragebot_friends"][pEntity] == true then return false end

	return true
end

function LagCompensation:GetMaxBackTrackTime()
	return math.min(proxi.GetFlowOutgoing() + proxi.GetFlowIncoming() + 0.2, sv_maxunlag:GetFloat())
end

function LagCompensation:FrameUpdatePostEntityThink()
	if Config["backtrack_amount"] <= 0 or not sv_unlag:GetBool() then
		if #self.m_tRecords > 0 then
			table.Empty(self.m_tRecords)
		end

		return
	end

	local flTeleportDistanceSqr = (64 * 64) --(sv_lagcompensation_teleport_dist.GetFloat() * sv_lagcompensation_teleport_dist.GetFloat();)

	local flDeadTime = C_CreateMove.m_flServerTime - (Config["backtrack_abuseinterp"] and Config["backtrack_amount"] or math.Clamp(Config["backtrack_amount"], 0, self:GetMaxBackTrackTime())) --[[sv_maxunlag:GetFloat()]]

	for idx, pEntity in pairs(g_tPlayers) do
		local nIndex = pEntity:EntIndex()

		self.m_tRecords[nIndex] = self.m_tRecords[nIndex] or {}

		if not self:ShouldCareAboutEntity(pEntity) --[[IsValid(pEntity)]] then
			if #self.m_tRecords[nIndex] > 0 then
				table.Empty(self.m_tRecords[nIndex])
			end

			continue
		end

		assert(#self.m_tRecords[nIndex] < 1000) -- insanity check

		-- remove tail records that are too old
		local tailindex = #self.m_tRecords[nIndex]
		while self.m_tRecords[nIndex][tailindex] do
			local tail = self.m_tRecords[nIndex][tailindex]
			if not tail then break end

			-- if tail is within limits, stop
			if not tail.m_flSimulationTime then break end
			if tail.m_flSimulationTime >= flDeadTime then break end

			-- remove tail, get new tail
			table.remove(self.m_tRecords[nIndex], tailindex)
			tailindex = #self.m_tRecords[nIndex]
		end

		local flSimulationTime = GetSimulationTime(pEntity)

		-- check if head has same simulation time
		if #self.m_tRecords[nIndex] > 0 then
			local head = self.m_tRecords[nIndex][1]

			-- check if player changed simulation time since last time updated
			if head.m_flSimulationTime >= flSimulationTime then
				continue -- don't add new entry for same or older time
			end
		end

		local bWasSimulated = false
		if tailindex > 0 then
			bWasSimulated = flSimulationTime > self.m_tRecords[nIndex][1].m_flSimulationTime

			if bWasSimulated then
				local origin = pEntity:GetNetworkOrigin()
				local prevOrigin = self.m_tRecords[nIndex][1].m_vOrigin
				local deltaSqr = (origin - prevOrigin):LengthSqr()

				self.m_tBreakingLagComp[pEntity] = deltaSqr >= flTeleportDistanceSqr
				if self.m_tBreakingLagComp[pEntity] then
					table.Empty(self.m_tRecords[nIndex])
					tailindex = 0
				end
			end
		else
			bWasSimulated = self.m_tCachedSimTime[pEntity] and flSimulationTime > self.m_tCachedSimTime[pEntity]
		end

		self.m_tCachedSimTime[pEntity] = flSimulationTime

		if pEntity:IsPlayer() then -- anim state x3
			if not MultiplayerAnimState.Instances[nIndex] then
				MultiplayerAnimState:Create(nIndex, pEntity)
			end

			if bWasSimulated then
				MultiplayerAnimState:UpdateEyeAngles(nIndex)
			end

			MultiplayerAnimState:UpdateAnimationState(nIndex)

			if bWasSimulated then
				self.m_tSimulationDelta[pEntity] = flSimulationTime - C_CreateMove.m_flServerTime
				MultiplayerAnimState:UpdateCachedPoseParameters(nIndex)
			end
		end

		if tailindex == 0 or bWasSimulated then
			self:StoreRecord(nIndex, pEntity, flSimulationTime)
		end
	end
end

function LagCompensation:StoreRecord(index, ply, flSimulationTime)
	local record = C_PlayerData()
	record.m_pEntity = ply
	record.m_flSimulationTime = flSimulationTime
	record.m_flCreateTime = SysTime()
	record.m_nTickCount = engine.TickCount()

	record.m_vVelocity:Set(ply:GetAbsVelocity())

	record.m_vOrigin:Set(ply:GetNetworkOrigin())
	record.m_qAngles:Set(ply:GetNetworkAngles())

	record.m_vMins:Set(ply:OBBMins())
	record.m_vMaxs:Set(ply:OBBMaxs())

	local flClientAnimTime = ply:GetAnimTime()
	if ply:IsPlayer() then
		local flServerAnimTimeEstimate = RoundToTicks(flClientAnimTime)
		local flLaggedAnimationTime = flSimulationTime

		if flServerAnimTimeEstimate > flLaggedAnimationTime then
			flServerAnimTimeEstimate = flLaggedAnimationTime
		end

		MultiplayerAnimState:ApplyCachedPoseParameters(index)
		MultiplayerAnimState:ApplyAnimationLayers(index)

		ply:UseClientSideAnimation(false)

		ply:AnimResetGestureSlot(GESTURE_SLOT_VCD)
		ply:AnimResetGestureSlot(GESTURE_SLOT_CUSTOM)

		ply:SetPoseParameter("head_pitch", 0)
		ply:SetPoseParameter("head_yaw", 0)

		if Config["accuarcy_resolver"] and C_Ragebot.m_tShotsFiredAt[index] then
			C_Accuracy:ResolvePlayer(ply, record)
		end

		ply:SetAnimTime(flServerAnimTimeEstimate)
	end

	ply:InvalidateBoneCache()
	ply:SetupBones()

	for iBoneIndex = 0, ply:GetBoneCount() - 1 do
		local pBoneMatrix = ply:GetBoneMatrix(iBoneIndex)
		if not pBoneMatrix then
			continue
		end

		record.m_tBoneMatrices[iBoneIndex] = pBoneMatrix
	end

	local pModelData = C_HitboxManager:GetModelData(ply)
	if not pModelData:IsValid() then
		return false
	end

	local pHitboxSets = pModelData.m_tHitboxSets

	for iHitGroup, pHitboxes in pairs(pHitboxSets) do
		for iHitbox, pHitbox in pairs(pHitboxes) do
			local pBoneToWorld = ply:GetBoneMatrix(pHitbox.m_nBone)
			if not pBoneToWorld then
				continue
			end

			local vTranslateion, qOrientation = pBoneToWorld:GetTranslation(), pBoneToWorld:GetAngles()

			local vHitboxCenter = Vector(pHitbox.m_vCenter)
			vHitboxCenter:Rotate(qOrientation)
			vHitboxCenter:Add(vTranslateion)

			record.m_tHitboxes[iHitGroup] = {
				m_nBoneIndex = pHitbox.m_nBone,
				m_nHitGroup = iHitGroup,

				m_vMins = pHitbox.m_vMins,
				m_vMaxs = pHitbox.m_vMaxs,

				m_vCenter = vHitboxCenter,
				m_vOrigin = vTranslateion,
				m_vCorners = pHitbox.m_tCorners,

				m_qRotation = qOrientation,
			}
		end
	end

	table.insert(self.m_tRecords[index], 1, record)

	if ply:IsPlayer() then
		MultiplayerAnimState:RestoreAnimationLayers(index)

		ply:SetAnimTime(flClientAnimTime)
		ply:InvalidateBoneCache()
		ply:SetupBones()
	end
end

function LagCompensation:GetBestRecord(pEntity)
	local tCurrRecord = self.m_tRecords[pEntity:EntIndex()]
	if not tCurrRecord or #tCurrRecord == 0 then return end

	if Config["backtrack_method"] == BACKTRACK_METHOD_FIRST then
		for i = 1, #tCurrRecord do
			local pCurrentRecord = tCurrRecord[i]
			if not self:IsTickValid(pCurrentRecord.m_flSimulationTime) then
				continue
			end

			return pCurrentRecord
		end
	elseif Config["backtrack_method"] == BACKTRACK_METHOD_LAST then
		for i = #tCurrRecord, 1, -1 do
			local pCurrentRecord = tCurrRecord[i]
			if not self:IsTickValid(pCurrentRecord.m_flSimulationTime) then
				continue
			end

			return pCurrentRecord
		end
	end

	return nil
end

function LagCompensation:IsTickValid(flTime)
	if Config["backtrack_abuseinterp"] then return true end

	local correct = 0

	-- add network latency
	correct = correct + proxi.GetFlowOutgoing()

	-- calc number of view interpolation ticks - 1
	local lerpticks = TIME_TO_TICKS(self.m_flLerpTime)

	-- add view interpolation latency see C_BaseEntity::GetInterpolationAmount()
	correct = correct + TICKS_TO_TIME(lerpticks)

	-- check bouns [0, sv_maxunlag]
	correct = math.Clamp(correct, 0, sv_maxunlag:GetFloat())

	local targettick = TIME_TO_TICKS(flTime)
	local servertick = g_pLocalPlayer:GetInternalVariable("m_nTickBase")

	-- calc difference between tick send by player and our latency based tick
	local deltatime = correct - TICKS_TO_TIME(servertick - targettick)

	return math.abs(deltatime) < 0.2
end

function LagCompensation:BacktrackPlayer(pUserCmd, pEntity, record)
	if not (pEntity:IsPlayer() or pEntity:IsNextBot()) then
		return
	end

	if not record then
		Log("No backtrack record found for %s", pEntity)
		return
	end

	local bIsExtrapolating = false
	if self.m_tBreakingLagComp[pEntity] then
		local flCurrentTime = RoundToTicks(SysTime())
		local flTimePacketToServer = proxi.GetFlowOutgoing()
		local flLastEntityUpdateTime = RoundToTicks(record.m_flCreateTime)
		local flTimeSinceLastUpdate = flCurrentTime - flLastEntityUpdateTime

		if flTimePacketToServer >= self.m_tSimulationDelta[pEntity] - flTimeSinceLastUpdate then
			--[[
			local predTime = proxi.GetFlowOutgoing() + proxi.GetFlowIncoming()
			panchiko.StartSimulation(pEntity:EntIndex())

			for tick = 1, TIME_TO_TICKS(predTime) do
				panchiko.SimulateTick()
			end

			local data = panchiko.GetSimulationData()
			pEntity:SetRenderOrigin(data.m_vecAbsOrigin)
			pEntity:SetNetworkOrigin(data.m_vecAbsOrigin)

			record.m_vOrigin:Set(data.m_vecAbsOrigin)

			panchiko.FinishSimulation()]]

			bIsExtrapolating = true
		end
	end

	self.m_tCurrentRecord = record

	local nDesiredTick = TIME_TO_TICKS(record.m_flSimulationTime + self.m_flLerpTime)

	if g_bSequenceRan or bIsExtrapolating then
		nDesiredTick = g_pLocalPlayer:GetInternalVariable("m_nTickBase")
	end

	g_bSendPacket = true

	if Config["backtrack_abuseinterp"] and not bIsExtrapolating then
		local flServerArrival = C_CreateMove.m_flServerTime + (proxi.GetFlowOutgoing() + proxi.GetFlowIncoming())
		local flDifference = flServerArrival - record.m_flSimulationTime
		local flMaxBacktrackTime = self:GetMaxBackTrackTime()

		if flDifference > flMaxBacktrackTime then
			local flInterp = C_CreateMove.m_flServerTime - record.m_flSimulationTime
			nDesiredTick = TIME_TO_TICKS(C_CreateMove.m_flServerTime) - 1

			cl_interp:SendValue(flInterp)
		end
	end

	pUserCmd:SetTickCount(nDesiredTick)
end

function LagCompensation:BacktrackTraceLine(vStartPos, vDelta)
	local trResult = {}

	--debugoverlay.Line(vStartPos, vDelta * 0x7FFF, 0.04, Color(255, 0, 0), true)

	for idx, track in next, self.m_tRecords do
		for iRecordIndex, record in ipairs(track) do
			if not self:IsTickValid(record.m_flSimulationTime) then
				continue
			end

			local pMins, pMaxs = record.m_vOrigin + record.m_vMins, record.m_vOrigin + record.m_vMaxs

			--debugoverlay.Box(record.m_vOrigin, record.m_vMins, record.m_vMaxs, 0.04, Color(255, 255, 255, 4))

			local vOBBHit = C_Math:ClipTraceToBox(vDelta, vStartPos, pMins, pMaxs)
			if not vOBBHit then
				continue
			end

			for nHitbox = 1, #record.m_tHitboxes do
				local data = record.m_tHitboxes[nHitbox]
				if not data then
					continue
				end

				local mins, maxs = data.m_vMins, data.m_vMaxs

				local vHitPos, vHitNormal, flFraction = util.IntersectRayWithOBB(vStartPos, vDelta, data.m_vOrigin, data.m_qRotation, mins, maxs)

				if vHitPos then
					trResult.HitPos = vHitPos
					trResult.HitNormal = vHitNormal
					trResult.Fraction = flFraction

					trResult.Entity = Entity(idx)
					trResult.HitBox = nHitbox
					trResult.HitGroup = data.m_nHitGroup
					trResult.Hit = trResult.Fraction ~= 1.0

					trResult.HitNonWorld = true
					trResult.HitNoDraw = false
					trResult.HitWorld = false

					-- CUSTOM :)
					trResult.HitBacktrack = true
					trResult.BacktrackRecord = record

					--debugoverlay.Box(vHitPos, -Vector(1,1,1), Vector(1,1,1), engine.TickInterval() * 2, Color(255,0,0,64))
					--debugoverlay.Line(vStartPos, vHitPos, engine.TickInterval() * 2, Color(255,0,0, 64))

					break
				end
			end
		end
	end

	if trResult.HitBacktrack then
		self.m_tCurrentRecord = trResult.BacktrackRecord
	end

	return trResult
end

--[[
	Accuracy
]]

C_Accuracy.m_tCollectWeaponVars = {
	["engine"] = function(hWeapon)
		local angViewPunch = g_pLocalPlayer:GetViewPunchAngles()
		local vecCone = g_tWeaponSpreadCones[hWeapon:GetClass()]

		if hWeapon:GetClass() == "weapon_pistol" then
			angViewPunch:Set(angle_zero)
		end

		if isfunction(vecCone) then
			vecCone = vecCone(hWeapon)
		end

		return {
			m_qViewPunch = angViewPunch,
			m_vSpreadCone = vecCone
		}
	end,
	["tfa"] = function(hWeapon)
		if not TFA.Ballistics:ShouldUse(hWeapon) then
			local flSpread = hWeapon:CalculateConeRecoil()

			local angViewPunch = Angle()

			if sv_tfa_recoil_legacy then
				if sv_tfa_recoil_legacy:GetBool() then
					angViewPunch:Set(g_pLocalPlayer:GetViewPunchAngles())
				elseif hWeapon:HasRecoilLUT() then
					angViewPunch:Set(hWeapon:GetRecoilLUTAngle())
				else
					local punchP, punchY = hWeapon:GetViewPunchP(), hWeapon:GetViewPunchY()

					punchP = punchP - punchP * TICK_INTERVAL
					punchY = punchY - punchY * TICK_INTERVAL

					angViewPunch.p = angViewPunch.p + punchP
					angViewPunch.y = angViewPunch.y + punchY
				end
			else
				angViewPunch:Set(g_qPunchAngle)
			end

			angViewPunch:Normalize()

			return {
				m_qViewPunch = angViewPunch,
				m_flSpread = flSpread
			}
		end
	end,
	["swcs"] = function(hWeapon)
		hWeapon:UpdateAccuracyPenalty()

		local qPunchAngles = hWeapon:GetAimPunchAngle()
		qPunchAngles:Normalize()

		local nSeed = hWeapon:GetRandomSeed()
		nSeed = nSeed + 1

		local fInaccuracy = hWeapon:GetInaccuracy(false)
		local bForceMaxInaccuracy = weapon_debug_max_inaccuracy:GetBool()
		local bForceInaccuracyDirection = weapon_debug_inaccuracy_only_up:GetBool()

		local rand = UniformRandomStream(nSeed) -- init random system with this seed

		-- this is inside gay loop in src
		local flSpreadCurveDensity, x0, y0 = 0, 0, 0

		-- Accuracy curve density adjustment FOR R8 REVOLVER SECONDARY FIRE, NEGEV WILD BEAST
		local flRadiusCurveDensity = rand:RandomFloat()
		if hWeapon.IsR8Revolver and hWeapon:GetWeaponMode() == Secondary_Mode then -- R8 REVOLVER SECONDARY FIRE
			flRadiusCurveDensity = 1 - (flRadiusCurveDensity * flRadiusCurveDensity)
		elseif hWeapon.IsNegev and hWeapon:GetRecoilIndex() < 3 then -- NEGEV WILD BEAST
			for j = 3, hWeapon:GetRecoilIndex(), -1 do
				flRadiusCurveDensity = flRadiusCurveDensity * flRadiusCurveDensity
			end

			flRadiusCurveDensity = 1 - flRadiusCurveDensity
		end

		if bForceMaxInaccuracy then
			flRadiusCurveDensity = 1
		end

		-- Get accuracy displacement
		local fTheta0 = rand:RandomFloat(0, 2 * math.pi)
		if bForceInaccuracyDirection then
			fTheta0 = math.pi * 0.5
		end

		local fRadius0 = flRadiusCurveDensity * fInaccuracy
		x0 = fRadius0 * math.cos(fTheta0)
		y0 = fRadius0 * math.sin(fTheta0)

		if hWeapon:GetIsRevolver() and hWeapon:GetWeaponMode() == Secondary_Mode then
			flSpreadCurveDensity = 1 - (flSpreadCurveDensity * flSpreadCurveDensity)
		elseif hWeapon.IsNegev and hWeapon:GetRecoilIndex() < 3 then
			for j = 3, hWeapon:GetRecoilIndex(), -1 do
				flSpreadCurveDensity = flSpreadCurveDensity * flSpreadCurveDensity
			end

			flSpreadCurveDensity = 1 - flSpreadCurveDensity
		end

		--if weapon_accuracy_shotgun_spread_patterns:GetBool() then
		--	fTheta1, flSpreadCurveDensity = self:GetSpreadOffset(rand, math.floor(iBullet + (iNumBullets * self:GetRecoilIndex()) - 1))
		--else
			flSpreadCurveDensity = rand:RandomFloat()
			fTheta1 = rand:RandomFloat(0, 2 * math.pi)
		--end

		local fSpread = hWeapon:GetSpread()

		local fRadius1 = flSpreadCurveDensity * fSpread
		local x1 = x0 + fRadius1 * math.cos(fTheta1)
		local y1 = y0 + fRadius1 * math.sin(fTheta1)

		return {
			m_qViewPunch = qPunchAngles,
			m_vSpreadCone = Vector(x1, y1),
			m_vSpreadCone2 = Vector(fInaccuracy + fSpread, fInaccuracy + fSpread)
		}
	end,
	["bobs"] = function(hWeapon)
		if not istable(hWeapon.Primary) then return false end
		if hWeapon.Primary.NumShots > 2 then return false end

		local cone = hWeapon.Primary.Spread

		if hWeapon:GetIronsights() and g_pLocalPlayer:KeyDown(IN_ATTACK2) then
			cone = hWeapon.Primary.IronAccuracy
		end

		local wep_spread = Vector(cone, cone)

		return {
			m_vSpreadCone = wep_spread
		}
	end,
	["cw"] = function(hWeapon)
		local vp = g_pLocalPlayer:GetViewPunchAngles()

		C_Accuracy.m_bInWorldClicker = false

		local spread = 0.09 + hWeapon.MaxSpreadInc

		return {
			m_qViewPunch = vp,
			m_flSpread = spread
		}
	end,
	["fas2"] = function(hWeapon) -- basically the same as cw2 (almost like fas is a paste of cw)
		local vp = g_pLocalPlayer:GetViewPunchAngles()

		C_Accuracy.m_bInWorldClicker = false

		local spread = 0.09 + hWeapon.MaxSpreadInc

		return {
			m_qViewPunch = vp,
			m_flSpread = spread
		}
	end,
	["red"] = function(hWeapon)
		local vp = hWeapon:GetRecoilAngles()

		return {
			m_qViewPunch = vp
		}
	end
}

function C_Accuracy:GetAccuracteRange()
	if g_pActiveWeapon.IsSWCSWeapon then
		return g_pActiveWeapon:GetRange()
	end

	return 8192
end

--[[
	Spread Compensation
]]

function C_Accuracy:CompensateHeuristicSpread(pUserCmd, qTargetAngles)
	if not self.m_tCurrWeaponData then return qTargetAngles end

	local vSpread = self.m_tCurrWeaponData.m_vSpreadCone
	if not vSpread then return qTargetAngles end

	local Seed = pUserCmd:GetRandomSeed()

	local X = g_tWeaponSpreadSeeds[Seed].x
	local Y = g_tWeaponSpreadSeeds[Seed].y

	local vForward = qTargetAngles:Forward()
	local vRight = qTargetAngles:Right()
	local vUp = qTargetAngles:Up()

	local SpreadVector = vForward + (X * vSpread.x * vRight * -1) + (Y * vSpread.y * vUp * -1)

	local vSpreadAng = SpreadVector:Angle()
	vSpreadAng:Normalize()

	return vSpreadAng
end

function C_Accuracy:CompensateCW20Spread(pUserCmd, qTargetAngles)
	local flCurCone = self.m_tCurrWeaponData.m_flSpread

	local angFlip = pUserCmd:GetViewAngles()
	if pUserCmd:TickCount() % 2 == 0 then
		angFlip:Mul(-1)
	end

	pUserCmd:SetInWorldClicker(true)
	pUserCmd:SetWorldClickerAngles(angFlip:Right())

	math.randomseed(g_pActiveWeapon.CW20Weapon and pUserCmd:CommandNumber() or CurTime())
	local x = math.Rand(-flCurCone, flCurCone) * 25
	local y = math.Rand(-flCurCone, flCurCone) * 25

	return qTargetAngles - Angle(x, y)
end

function C_Accuracy:CompensateSWCSSpread(qTargetAngles)
	if not swcs_weapon_sync_seed:GetBool() then
		Log("swcs nospread will not work")
		return qTargetAngles
	end

	local vCone = self.m_tCurrWeaponData.m_vSpreadCone

	local angShooting = g_pActiveWeapon:GetFinalAimAngle() -- an angle
	local vecDirShooting, vecRight, vecUp = angShooting:Forward(), angShooting:Right(), angShooting:Up()

	-- do spread comp
	local xSpread, ySpread = vCone.x, vCone.y

	local vecDir = vecDirShooting + (xSpread * vecRight) + (ySpread * vecUp)
	vecDir:Normalize()

	local temp = vecDirShooting:Angle() - vecDir:Angle()
	temp:Normalize()

	return qTargetAngles + temp
end

function C_Accuracy:CompensateArcCWSpread(pUserCmd, qTargetAngles, flMultiplier)
	local qDirection = qTargetAngles:Forward()

	local flSeed1 = g_pActiveWeapon:GetBurstCount()
	local flSeed2 = not game.SinglePlayer() and pUserCmd:CommandNumber() or CurTime()

	local flSpread = ArcCW.MOAToAcc * g_pActiveWeapon:GetBuff("AccuracyMOA")
	local flDispersion = g_pActiveWeapon:GetDispersion() * ArcCW.MOAToAcc / 10

	local flRandomSeed = util.SharedRandom(flSeed1, -1337, 1337, flSeed2) * (g_pActiveWeapon:EntIndex() % 30241)

	local desync = arccw_desync:GetBool()
	local desyncnum = (desync and math.random()) or 0
	math.randomseed(math.Round(flRandomSeed) + desyncnum)

	g_pActiveWeapon:ApplyRandomSpread(qDirection, flDispersion * flMultiplier)

	local flRandomSeed2 = util.SharedRandom(1, -1337, 1337, flSeed2) * (g_pActiveWeapon:EntIndex() % 30241)
	math.randomseed(math.Round(flRandomSeed2) + desyncnum)

	g_pActiveWeapon:ApplyRandomSpread(qDirection, flSpread * flMultiplier)

	local qSpreadAng = qDirection:Angle()
	qSpreadAng:Normalize()

	return qSpreadAng
end

function C_Accuracy:CompensateTFASpread(qTargetAngles)
	local flCurCone = self.m_tCurrWeaponData.m_flSpread

	local Yaw, Pitch = g_pActiveWeapon:ComputeBulletDeviation(1, 1, flCurCone)

	local newANgle = Angle(qTargetAngles)

	local Up = newANgle:Up()
	local Right = newANgle:Right()

	newANgle:RotateAroundAxis(Up, Yaw)
	newANgle:RotateAroundAxis(Right, Pitch)

	return qTargetAngles + (qTargetAngles - newANgle) -- what the actual fuck
end

function C_Accuracy:CompensateRedBaseSpread(qTargetAngles) -- no src yet :pensive:
	return qTargetAngles
end

function C_Accuracy:PerformSpreadCompensation(pUserCmd, qTargetAngles)
	if not Config["nospread_enabled"] then return qTargetAngles end

	local qAngSpread = Angle(qTargetAngles)

	if g_pActiveWeapon.IsSWCSWeapon then
		qAngSpread:Set(self:CompensateSWCSSpread(qTargetAngles))
	elseif g_pActiveWeapon.IsTFAWeapon then
		qAngSpread:Set(self:CompensateTFASpread(qTargetAngles))
	elseif g_pActiveWeapon.CW20Weapon or g_pActiveWeapon.IsFAS2Weapon then
		qAngSpread:Set(self:CompensateCW20Spread(pUserCmd, qTargetAngles))
	elseif g_pActiveWeapon.ArcCW then
		qAngSpread:Set(self:CompensateArcCWSpread(pUserCmd, qTargetAngles, -1))
	elseif g_pActiveWeapon.IsRedBased then
		qAngSpread:Set(self:CompensateRedBaseSpread(qTargetAngles))
	else
		qAngSpread:Set(self:CompensateHeuristicSpread(pUserCmd, qTargetAngles))
	end

	return qAngSpread
end

function C_Accuracy:ForceSpreadSeed(pUserCmd, iDesiredSeed)
	iDesiredSeed = iDesiredSeed % 256

	pUserCmd:SetRandomSeed(iDesiredSeed)
end

function C_Accuracy:GetSpreadTangent()
	if self.m_tCurrWeaponData and self.m_tCurrWeaponData.m_vSpreadCone2 then
		return self.m_tCurrWeaponData.m_vSpreadCone2
	end

	if self.m_tCurrWeaponData and self.m_tCurrWeaponData.m_vSpreadCone then
		return self.m_tCurrWeaponData.m_vSpreadCone
	end

	local ret = g_tWeaponSpreadCones[g_pActiveWeapon.strClass]
	if isfunction(ret) then
		ret = ret(g_pActiveWeapon)
	end

	return ret
end

--[[
	Recoil Compensation
]]

function C_Accuracy:GetRecoilAngles()
	local viewpunch = Angle(angle_zero)

	if self.m_tCurrWeaponData and self.m_tCurrWeaponData.m_qViewPunch then
		viewpunch:Set(self.m_tCurrWeaponData.m_qViewPunch)
	end

	return viewpunch
end

function C_Accuracy:PerformRecoilCompensation(qTargetAngles)
	if not Config["accuracy_norecoil"] then return qTargetAngles end
	if not g_pActiveWeapon:IsScripted() and self.m_bInWorldClicker then return qTargetAngles end

	return qTargetAngles - self:GetRecoilAngles()
end

--[[
	Resolver
]]

function C_Accuracy:ResolvePlayer(hPlayer, record)
	if not Config["accuarcy_resolver"] then
		return
	end

	if not hPlayer:IsPlayer() or not record then
		return
	end

	local index = hPlayer:EntIndex()

	local qOrientation = Angle(record.m_qRotation)

	local tYawDeltas = self.m_tResolverDeltas.LowerBodyYaw
	--[[
	local tPitchDelta = self.m_tResolverDeltas.UppderBodyLean

	local headAngle = tPitchDelta[1 + (C_Ragebot.m_tShotsFiredAt[index] % #tPitchDelta)]

	local aim_yaw = hPlayer:LookupPoseParameter("aim_yaw")
	local min, max = hPlayer:GetPoseParameterRange(aim_yaw)
	local lerpedAimYaw = Lerp(headAngle, min, max)

	hPlayer:SetPoseParameter("aim_yaw", lerpedAimYaw)
	hPlayer:SetPoseParameter("head_yaw", lerpedAimYaw)
	]]
	local flResolvedYaw = math.NormalizeAngle(qOrientation.y + tYawDeltas[1 + (C_Ragebot.m_tShotsFiredAt[index] % #tYawDeltas)])
	hPlayer:SetRenderAngles(Angle(qOrientation.p, flResolvedYaw, 0))
end

--[[
	Main Logic
]]

function C_Accuracy:Run(pUserCmd)
	self.m_bIsFiringThisTick = false

	if not IsValid(g_pActiveWeapon) then
		return false
	end

	self.m_bInWorldClicker = pUserCmd:GetInWorldClicker()

	local qViewAngles = pUserCmd:GetViewAngles()
	if self.m_bInWorldClicker then
		qViewAngles:Set(pUserCmd:GetWorldClickerAngles():Angle())
	end

	qViewAngles:Normalize()

	if Config["nospread_usecontext"] then
		self.m_bInWorldClicker = true
	end

	local fnInit = self.m_tCollectWeaponVars[g_pActiveWeapon.strBase]

	if isfunction(fnInit) then
		self.m_tCurrWeaponData = fnInit(g_pActiveWeapon)
	end

	if pUserCmd:KeyDown(IN_ATTACK) and C_CreateMove.m_bCanShoot then
		if Config["forceseed_enabled"] then
			local nSeed = math.floor(Config["forceseed_seed"])
			self:ForceSpreadSeed(pUserCmd, nSeed)
		end

		self.m_bIsFiringThisTick = true

		qViewAngles:Set(self:PerformSpreadCompensation(pUserCmd, qViewAngles))
		qViewAngles:Set(self:PerformRecoilCompensation(qViewAngles))
		qViewAngles:Normalize()

		if self.m_bInWorldClicker then
			pUserCmd:SetInWorldClicker(true)
			pUserCmd:SetWorldClickerAngles(qViewAngles:Forward())
		else
			pUserCmd:SetViewAngles(qViewAngles)
		end
	end
end

--[[
	Aimbot
]]

enum("SORT_TYPE", {
	false,
	"CROSSHAIR",
	"DISTANCE",
	"HEALTH"
})

enum("AIMCONE_SHAPE", {
	false,
	"CIRCLE",
	"TRIANGLE",
	"SQUARE",
	"RHOMBUS"
})

function C_Ragebot:ShouldAim()
	if not Config["ragebot_enabled"] then return false end
	if not C_CreateMove.m_bCanShoot then return false end
	if g_nChokedPackets > 1 then return false end

	if not C_Inputs:IsKeyActive(Config, "ragebot_key") then
		return false
	end

	return true
end

function C_Ragebot:GetClosestToCrosshair(vShootPos)
	local hBestTarget = false

	local vViewForward = g_pLocalPlayer:GetAimVector()
	local flCosThetaMax = math.cos(math.rad(179.9999))

	for idx, pEntity in pairs(self.m_tUnsortedTargets) do
		if not IsValid(pEntity) then
			continue
		end

		local vTargetPos = pEntity:WorldSpaceCenter()
		local vShooterToTarget = (vTargetPos - vShootPos)
		vShooterToTarget:Normalize()

		local flCosTheta = vViewForward:Dot(vShooterToTarget)

		if flCosThetaMax < flCosTheta then
			flCosThetaMax = flCosTheta
			hBestTarget = pEntity
		end
	end

	return hBestTarget
end

function C_Ragebot:GetClosestToPlayer(vShootPos)
	local hBestTarget = false
	local flClosestDistance = math.huge

	for idx, pEntity in pairs(self.m_tUnsortedTargets) do
		if not IsValid(pEntity) then
			continue
		end

		local vTargetPos = pEntity:GetPos()
		local flDistance = vShootPos:DistToSqr(vTargetPos)

		if flDistance < flClosestDistance then
			flClosestDistance = flDistance
			hBestTarget = pEntity
		end
	end

	return hBestTarget
end

function C_Ragebot:GetLowestHealth()
	local hBestTarget = nil
	local nLowestHealth = math.huge

	for idx, pEntity in pairs(self.m_tUnsortedTargets) do
		if not IsValid(pEntity) then
			continue
		end

		local nHealth = pEntity:Health()

		if nHealth < nLowestHealth then
			nLowestHealth = nHealth
			hBestTarget = pEntity
		end
	end

	return hBestTarget
end

function C_Ragebot:GetTarget(vShootPos)
	if Config["ragebot_sortmethod"] == SORT_TYPE_CROSSHAIR then
		return self:GetClosestToCrosshair(vShootPos)
	elseif Config["ragebot_sortmethod"] == SORT_TYPE_DISTANCE then
		return self:GetClosestToPlayer(vShootPos)
	elseif Config["ragebot_sortmethod"] == SORT_TYPE_HEALTH then
		return self:GetLowestHealth()
	end

	return false
end

function C_Ragebot:CacheSpreadSeeds()
	for i = 1, 64 do -- im lazy and it works so idc
		self.m_tSpreadSeeds[i] = g_tWeaponSpreadSeeds[i]
	end
end

timer.Simple(0, function() -- load seeds on the next tick
	C_Ragebot:CacheSpreadSeeds()
end)

function C_Ragebot:HitChance(pUserCmd, vDirection, pEntity, vShootPos)
	local vDelta = vDirection:Angle()
	vDelta:Add(C_Accuracy:GetRecoilAngles())
	vDelta:Normalize()

	local vViewForward = vDelta:Forward()
	local vViewRight = vDelta:Right()
	local vViewUp = vDelta:Up()

	local iHits = 0
	local pSeeds = self.m_tSpreadSeeds
	local iSeeds = #pSeeds

	local pModelData = C_HitboxManager:GetModelData(pEntity)
	if not pModelData:IsValid() then
		return false
	end

	local pHitboxSets = pModelData.m_tHitboxSets
	local vSpread = C_Accuracy:GetSpreadTangent()

	for iSeed = 1, iSeeds do
		local vShotDirection = Vector()
		if g_pActiveWeapon.IsSWCSWeapon then
			local vCurrDirection = vViewForward + vViewRight * vSpread.x + vViewUp * vSpread.y
			vCurrDirection:Normalize()

			vShotDirection:Set(vCurrDirection)
		else
			local vSeed = pSeeds[iSeed]

			local vCurrDirection = vViewForward + vViewRight * vSeed.x * vSpread.x + vViewUp * vSeed.y * vSpread.y
			vCurrDirection:Normalize()

			vShotDirection:Set(vCurrDirection)
		end

		for iHitGroup, pHitboxes in pairs(pHitboxSets) do
			if iHitGroup ~= Config["ragebot_hitbox"] then continue end

			for iHitbox, pHitbox in pairs(pHitboxes) do
				local pBoneToWorld = pEntity:GetBoneMatrix(pHitbox.m_nBone)
				if not pBoneToWorld then
					continue
				end

				local vTranslation = pBoneToWorld:GetTranslation()
				local pMins, pMaxs = vTranslation + pHitbox.m_vMins, vTranslation + pHitbox.m_vMaxs

				-- debugoverlay.Line(vShootPos, vShootPos + vShotDirection * 0x7FFF, 0.03, Color( 255, 255, 255 ), true)

				local bHit = C_Math:ClipTraceToBox(vShotDirection, vShootPos, pMins, pMaxs)
				if not bHit then
					continue
				end

				iHits = iHits + 1
			end
		end
	end

	if (Config["hitchance_amount"] / 100) > iHits / iSeeds then
		return false
	end

	return true
end

function C_Ragebot:PredictCrossbow(vShootPos, vTargetPos, pTarget, flGravity, flVel)
	local vTargetVelocity = pTarget:GetAbsVelocity()
	local bOnGround = pTarget:IsOnGround()
	local flGravPerTick = flGravity * TICK_INTERVAL

	local flDistance = vTargetPos:Distance(vShootPos)
	local flCompTime = (flDistance / flVel) + TICKS_TO_TIME(proxi.GetFlowIncoming() + proxi.GetFlowOutgoing())

	vTargetVelocity.z = not bOnGround and vTargetVelocity.z - flGravPerTick or vTargetVelocity.z
	vTargetVelocity.z = vTargetVelocity.z + (flGravity * 0.05)

	vTargetVelocity.z = math.Clamp(vTargetVelocity.z, -sv_maxvelocity:GetFloat(), sv_maxvelocity:GetFloat())

	return vTargetPos + (vTargetVelocity * flCompTime)
end

-- https://math.stackexchange.com/questions/312403/how-do-i-determine-if-a-point-is-within-a-rhombus
function C_Ragebot:IsPointInsideRhombus(vPosition, tRhombusCorners)
	if not isvector(vPosition) or table.IsEmpty(tRhombusCorners) then
		return false
	end

	local vScreenPos = vPosition:ToScreen()

	local flPointX = vScreenPos.x
	local flPointY = vScreenPos.y

	local bIsInside = true

	for i = 1, 4 do
		local j = (i % 4) + 1

		local dx = tRhombusCorners[j][1] - tRhombusCorners[i][1]
		local dy = tRhombusCorners[j][2] - tRhombusCorners[i][2]

		local flCross = dx * (flPointY - tRhombusCorners[i][2]) - (flPointX - tRhombusCorners[i][1]) * dy
		if flCross < 0 then
			bIsInside = false
			break
		end
	end

	return bIsInside
end

function C_Ragebot:IsPointInTriangle(pt, tri)
	if not pt or not tri then
		return false
	end

	local vScreenPos = pt:ToScreen()
	if not vScreenPos.visible then
		return false
	end

	local v1, v2, v3 = tri[1], tri[2], tri[3]
	local n, p

	local test1 = C_Math:Sign(vScreenPos, v1, v2)
	local test2 = C_Math:Sign(vScreenPos, v2, v3)
	local test3 = C_Math:Sign(vScreenPos, v3, v1)

	n = test1 < 0 or test2 < 0 or test3 < 0
	p = test1 > 0 or test2 > 0 or test3 > 0

	return not (n and p)
end

function C_Ragebot:IsPointInSquare(vPosition)
	local screenPos = vPosition:ToScreen()
	if not screenPos.visible then
		return false
	end

	local size = g_tCurrShapeData[1]

	local halfSize = size / 2

	local minX = SCREEN_CENTER_X - halfSize
	local maxX = SCREEN_CENTER_X + halfSize

	local minY = SCREEN_CENTER_Y - halfSize
	local maxY = SCREEN_CENTER_Y + halfSize

	return screenPos.x >= minX and screenPos.x <= maxX and screenPos.y >= minY and screenPos.y <= maxY
end

function C_Ragebot:IsPointInFOV(vPosition)
	if not Config["aimcone_enaled"]  then
		return true
	end

	if Config["aimcone_shape"] == AIMCONE_SHAPE_CIRCLE then
		return C_Math:DistanceFromCrosshair(vPosition) <= Config["aimcone_fov"]
	elseif Config["aimcone_shape"] == AIMCONE_SHAPE_TRIANGLE then
		return self:IsPointInTriangle(vPosition, g_tCurrShapeData)
	elseif Config["aimcone_shape"] == AIMCONE_SHAPE_RHOMBUS then
		return self:IsPointInsideRhombus(vPosition, g_tCurrShapeData)
	elseif Config["aimcone_shape"] == AIMCONE_SHAPE_SQUARE then
		return self:IsPointInSquare(vPosition)
	end
end

function C_Ragebot:GetAimPositions(pEntity, vShootPos)
	table.Empty(self.m_tAimPositions)

	if g_pActiveWeapon.strClass == "weapon_crossbow" then
		local vPosition = pEntity:WorldSpaceCenter()

		local flVel = 3500

		local flTargetsGravity = pEntity:GetGravity() == 0 and 1 or pEntity:GetGravity()
		local flGravFix = sv_gravity:GetFloat() * flTargetsGravity

		local vPredictedPos = self:PredictCrossbow(vShootPos, vPosition, pEntity, flGravFix, flVel)

		--debugoverlay.Box(vPredictedPos, pEntity:OBBMins(), pEntity:OBBMaxs(), 5, Color( 255, 255, 255, 4 ))

		self.m_tAimPositions[#self.m_tAimPositions + 1] = vPredictedPos

		return self.m_tAimPositions
	end

	local pRecord = LagCompensation:GetBestRecord(pEntity)

	if pRecord then
		self.m_tCurrBacktrackRecord = pRecord

		for iHitbox, pHitbox in pairs(pRecord.m_tHitboxes) do
			if pHitbox.m_nHitGroup ~= Config["ragebot_hitbox"] then
				continue
			end

			self.m_tAimPositions[#self.m_tAimPositions + 1] = pHitbox.m_vCenter

			if Config["ragebot_multipoint"] then
				for _, vCorner in pairs(pHitbox.m_vCorners) do
					local vCornerPosition = Vector(vCorner)
					vCornerPosition:Rotate(pHitbox.m_qRotation)
					vCornerPosition:Add(pHitbox.m_vOrigin)

					self.m_tAimPositions[#self.m_tAimPositions + 1] = vCornerPosition
				end
			end
		end
	else
		local pModelData = C_HitboxManager:GetModelData(pEntity)
		if not pModelData:IsValid() then
			return false
		end

		pEntity:SetAnimTime(C_CreateMove.m_flServerTime) -- p anim fix (from black)
		pEntity:InvalidateBoneCache()
		pEntity:SetupBones()

		local pHitboxSets = pModelData.m_tHitboxSets
		for iHitGroup, pHitboxes in pairs(pHitboxSets) do
			if iHitGroup ~= Config["ragebot_hitbox"] then continue end

			for iHitbox, pHitbox in pairs(pHitboxes) do
				local pBoneToWorld = pEntity:GetBoneMatrix(pHitbox.m_nBone)
				if not pBoneToWorld then
					continue
				end

				local vTranslation, qOrientation = pBoneToWorld:GetTranslation(), pBoneToWorld:GetAngles()

				local vHitboxCenter = Vector(pHitbox.m_vCenter)
				vHitboxCenter:Rotate(qOrientation)
				vHitboxCenter:Add(vTranslation)

				self.m_tAimPositions[#self.m_tAimPositions + 1] = vHitboxCenter

				if Config["ragebot_multipoint"] then
					for _, vCorner in ipairs(pHitbox.m_tCorners) do
						local vCornerPosition = Vector(vCorner)
						vCornerPosition:Rotate(qOrientation)
						vCornerPosition:Add(vTranslation)

						self.m_tAimPositions[#self.m_tAimPositions + 1] = vCornerPosition
					end
				end
			end
		end
	end

	return self.m_tAimPositions
end

function C_Ragebot:DidTraceHitEntity(trData, pEntity, vPosition)
	if trData.StartSolid then return false end

	if trData.Hit and trData.Entity == pEntity and trData.HitGroup == Config["ragebot_hitbox"] then
		return true
	elseif Config["triggerbot_autowall"] and g_pActiveWeapon:IsScripted() then -- hl2 weapons cant wallbang
		local bCanPenetrate = C_AutoWall:WeaponCanPenetrate(g_pActiveWeapon, trData, pEntity, vPosition)
		bCanPenetrate = bCanPenetrate or false

		return bCanPenetrate
	end

	return trData.Fraction == 1 -- because backtrack and resolver issues
end

--[[
	upper body lean safepoint = create array of 2 animation states which are copies of the current animation state from last update
	lower body safepoint = create array of 16 animation states which are copies of the current animation state anim states from last update

	for every possible fake angle update the anim state associated with it until its simulation tick >= current simulation tick

	for all animation states (including the real one) -> for every hitbox -> set transform to the animation state's transform -> check if shot intersects with it -> if not invalidate target
	worth mentioning that for lower body safe point you only need 8 animation states if the entity's velocity is higher than 1 unit per second
	because lower body yaw delta will be small enough
]]

function C_Ragebot:CalculateHitboxData(ent, ihitbox, matrix)
	if ihitbox < 0 or ihitbox > 19 then
		return
	end

	if not ent then
		return
	end

	local model = ent:GetModel()

	if not model then
		return
	end

	local pStudioHdr = g_csgo.m_model_info:GetStudioModel(model)

	if not pStudioHdr then
		return
	end

	local hitbox = pStudioHdr:GetHitbox(ihitbox, 0)

	if not hitbox then
		return
	end

	local is_capsule = hitbox.m_radius ~= -1.0

	local min, max
	if is_capsule then
		min = C_Math:VectorITransform(hitbox.m_mins, matrix[hitbox.m_bone])
		max = C_Math:VectorITransform(hitbox.m_maxs, matrix[hitbox.m_bone])
	else
		min = C_Math:VectorITransform(C_Math:VectorRotate(hitbox.m_mins, hitbox.m_angle), matrix[hitbox.m_bone])
		max = C_Math:VectorITransform(C_Math:VectorRotate(hitbox.m_maxs, hitbox.m_angle), matrix[hitbox.m_bone])
	end

	local hitboxData = {
		hitboxID = ihitbox,
		isOBB = not is_capsule,
		radius = hitbox.m_radius,
		mins = min,
		maxs = max,
		bone = hitbox.m_bone
	}

	return hitboxData
end

function C_Ragebot:CanSafepoint(pEntity, record, aimpoint, hitbox )
	local Eyepos = g_pLocalPlayer:EyePos()

	local angle = (Eyepos - aimpoint):Angle()
	local forward = angle:Forward()

	local endpos = Eyepos + forward * 8092;

	local box1 = CalculateHitboxData(pEntity, hitbox, record.left_matrix );
	local box2 = CalculateHitboxData(pEntity, hitbox, record.right_matrix );
	local box3 = CalculateHitboxData(pEntity, hitbox, record.center_matrix );

	local overlaps = box1.isOBB or box2.isOBB or box3.isOBB;

	if ( overlaps ) then
		C_Math:VectorITransform( Eyepos, record.left_matrix[ box1.bone ], box1.mins );
		C_Math:VectorIRotate( endpos, record.left_matrix[ box1.bone ], box1.maxs );

		C_Math:VectorITransform( Eyepos, record.right_matrix[ box2.bone ], box2.mins );
		C_Math:VectorIRotate( endpos, record.right_matrix[ box2.bone ], box2.maxs );

		C_Math:VectorITransform( Eyepos, record.center_matrix[ box3.bone ], box3.mins );
		C_Math:VectorIRotate( endpos, record.center_matrix[ box3.bone ], box3.maxs );
	end

	local hits = 0;

	if ( overlaps and C_Math:IntersectBB( Eyepos, endpos, box1.mins, box1.maxs ) or C_Math:Intersect( Eyepos, endpos, box1.mins, box1.maxs, box1.radius ) ) then
		hits = hits + 1;
	end

	if ( overlaps and C_Math:IntersectBB( Eyepos, endpos, box2.mins, box2.maxs ) or C_Math:Intersect( Eyepos, endpos, box2.mins, box2.maxs, box2.radius ) ) then
		hits = hits + 1
	end

	if ( overlaps and C_Math:IntersectBB( Eyepos, endpos, box3.mins, box3.maxs ) or C_Math:Intersect( Eyepos, endpos, box3.mins, box3.maxs, box3.radius ) ) then
		hits = hits + 1;
	end

	return hits >= 3
end

--[[
	//bool safe = CanSafepoint( record, point, it.m_index );

			//if ( !safe && g_aimbot.m_force_safepoint )
			//	continue;
]]

function C_Ragebot:GetAimPosition(pEntity, vShootPos)
	local trResult = {}
	local trData = {
		start = Vector(),
		endpos = Vector(),
		filter = {g_pLocalPlayer},
		mask = MASK_SHOT,
		output = trResult
	}

	local pRayStart = trData.start
	local pRayEnd = trData.endpos

	pRayStart:Set(vShootPos)

	self:GetAimPositions(pEntity, pRayStart)

	if #self.m_tAimPositions < 1 then
		self.m_tAimPositions = { pEntity:WorldSpaceCenter() }
	end

	for _, vPosition in pairs(self.m_tAimPositions) do
		if not isvector(vPosition) then
			continue
		end

		if vPosition:IsZero() or math.abs(vPosition.x) <= 2 or math.abs(vPosition.y) <= 2 then
			vPosition = pEntity:WorldSpaceCenter()
		end

		if not self:IsPointInFOV(vPosition) then
			continue
		end

		pRayEnd:Set(vPosition)

		util.TraceLine(trData)

		local bHit = self:DidTraceHitEntity(trResult, pEntity, vPosition) -- because fuck you
		if not bHit then
			continue
		end

		return pRayEnd
	end

	return false
end

function C_Ragebot:Run(pUserCmd)
	self.m_tCurrBacktrackRecord = nil

	if not self:ShouldAim() then
		return false
	end

	local vShootPos = g_pLocalPlayer:GetShootPos()
	local pEntity = self:GetTarget(vShootPos)

	if not pEntity then
		return false
	end

	local vPosition = self:GetAimPosition(pEntity, vShootPos) -- its weird but makes things easier
	if not vPosition then
		return false
	end

	local vShooterToHitbox = vPosition - vShootPos
	vShooterToHitbox:Normalize()

	if Config["hitchance_enabled"] and not self:HitChance(pUserCmd, vShooterToHitbox, pEntity, vShootPos) then
		return false
	end

	if Config["ragebot_usecontext"] then
		pUserCmd:SetInWorldClicker(true)
		pUserCmd:SetWorldClickerAngles(vShooterToHitbox)
	else
		local qDirection = vShooterToHitbox:Angle()
		qDirection:Normalize()

		pUserCmd:SetViewAngles(qDirection)
	end

	local pCurrRecord = self.m_tCurrBacktrackRecord
	if pCurrRecord and LagCompensation:IsTickValid(pCurrRecord.m_flSimulationTime) then
		LagCompensation:BacktrackPlayer(pUserCmd, pEntity, pCurrRecord)
	elseif pEntity:IsPlayer() then
		local flSimFix = GetSimulationTime(pEntity) + math.min(LagCompensation.m_flLerpTime, sv_maxunlag:GetFloat())
		local flDesiredTick = TIME_TO_TICKS(flSimFix)

		pUserCmd:SetTickCount(flDesiredTick)
	end

	pUserCmd:AddKey(IN_ATTACK)

	if Config["accuarcy_resolver"] then
		local nCurrentIndex = pEntity:EntIndex()
		if not self.m_tShotsFiredAt[nCurrentIndex] then
			self.m_tShotsFiredAt[nCurrentIndex] = 0
		end

		self.m_tShotsFiredAt[nCurrentIndex] = self.m_tShotsFiredAt[nCurrentIndex] + 1
	end

	if not Config["ragebot_silent"] then
		--g_qFacingAngle = pUserCmd:GetViewAngles()
		proxi.SetViewAngles(pUserCmd:GetViewAngles())
	end
end

local tNetVars = {
	"LibbyProtectedSpawn",
	"SH_SZ.Safe",
	"spawn_protect",
	"InSpawnZone",
	"has_god",
	"god_mode",
	"ugod",
	"BuildMode",
	"buildmode",
	"_Kyle_Buildmode"
}

function C_Ragebot:ShouldCareAboutEntity(pEntity)
	if not IsValid(pEntity) or pEntity == g_pLocalPlayer or pEntity:IsDormant() then
		return false
	end

	if pEntity:IsPlayer() then
		if Config["ragebot_ignoreplayers"] then
			return false
		end

		if not pEntity:Alive() then
			return false
		end

		if Config["ragebot_friends"][pEntity] == true then
			return false
		end

		for i = 1, #tNetVars do
			if pEntity:GetNWBool(tNetVars[i]) then
				return false
			end
		end
	elseif pEntity:IsNPC() then
		if Config["ragebot_ignorenpcs"] then
			return false
		end

		if pEntity:GetClass() == "npc_turret_floor" then
			return false
		end

		if pEntity:GetClass() == "npc_furniture" then
			return false
		end

		if pEntity:Health() <= 0 then
			return false
		end
	elseif pEntity:IsNextBot() then
		if Config["ragebot_ignorenextbots"] then
			return false
		end

		if pEntity:Health() <= 0 then
			return false
		end
	end

	return true
end

function C_Ragebot:PopulateTargetTable()
	table.Empty(self.m_tUnsortedTargets)

	for _, v in pairs(g_tEntities) do
		if not (v:IsPlayer() or v:IsNextBot() or v:IsNPC()) then
			continue
		end

		if not self:ShouldCareAboutEntity(v) then
			continue
		end

		self.m_tUnsortedTargets[#self.m_tUnsortedTargets + 1] = v
	end
end

--[[
	Anti Aim
]]

enum("ANTIAIM_X", {
	false,
	"NONE",
	"UP",
	"DOWN",
	"DANCE",
	"FRONT",
	"UP_FAKE",
	"DOWN_FAKE",
	"FAKE_ZERO_DOWN",
	"CUSTOM"
})

enum("ANTIAIM_Y", {
	false,
	"NONE",
	"SPINBOT",
	"JITTER",
	"JITTER_SIDE",
	"SIDE",
	"CUSTOM",
	"LBY",
	"FAKE_FORWARDS",
	"FAKE_SIDEWAYS"
})

enum("ANTIAIM_BASE_Y", {
	false,
	"FORWARDS",
	"BACKWARDS",
	"LEFT",
	"RIGHT",
	"AIMBOT_TARGET",
	"STATIC",
})

enum("FAKELAG_METHOD", {
	false,
	"STATIC",
	"ADAPTIVE",
	"RANDOM"
})

local bFlip = false
local pDance = 0

function C_AntiAim:ShouldRun(pUserCmd)
	if not Config["antiaim_enabled"] then return false end
	if pUserCmd:KeyDown(IN_USE) or g_pLocalPlayer:GetMoveType() == MOVETYPE_LADDER then return false end

	if (pUserCmd:KeyDown(IN_ATTACK) and not pUserCmd:GetInWorldClicker()) and C_CreateMove.m_bCanShoot then
		return false
	end

	if pUserCmd:TickCount() == 0 and not Misc:ShouldDrawLocalPlayer() then return false end

	return true
end

function C_AntiAim:GetBaseYaw(pUserCmd)
	if Config["antiaim_baseyaw"] == ANTIAIM_BASE_Y_FORWARDS then
		return pUserCmd:GetViewAngles().y
	elseif Config["antiaim_baseyaw"] == ANTIAIM_BASE_Y_BACKWARDS then
		return pUserCmd:GetViewAngles().y - 180
	elseif Config["antiaim_baseyaw"] == ANTIAIM_BASE_Y_LEFT then
		return pUserCmd:GetViewAngles().y + 90
	elseif Config["antiaim_baseyaw"] == ANTIAIM_BASE_Y_RIGHT then
		return pUserCmd:GetViewAngles().y - 90
	elseif Config["antiaim_baseyaw"] == ANTIAIM_BASE_Y_AIMBOT_TARGET then
		local hTarget = C_Ragebot:GetTarget(g_pLocalPlayer:GetShootPos())
		if IsValid(hTarget) then
			local ang = (hTarget:GetPos() - g_pLocalPlayer:GetPos()):Angle()
			ang:Normalize()

			return ang.y
		end
	elseif Config["antiaim_baseyaw"] == ANTIAIM_BASE_Y_STATIC then
		return 0
	end

	return pUserCmd:GetViewAngles().y
end

C_AntiAim.m_tYawFunctions = {
	[ANTIAIM_Y_SPINBOT] = function(ang)
		local factor = Config["antiaim_spinspeed"] * 7
		ang.y = g_bSendPacket and math.fmod(C_CreateMove.m_flServerTime * factor, 360) or ang.y + (bFlip and 180 or -180)
	end,
	[ANTIAIM_Y_JITTER] = function(ang)
		ang.y = ang.y - (bFlip and 30 or -30)
	end,
	[ANTIAIM_Y_JITTER_SIDE] = function(ang)
		ang.y = ang.y + 90

		ang.y = ang.y - (bFlip and 30 or -30)
	end,
	[ANTIAIM_Y_LBY] = function(ang)
		local yaw = ang.y - 178

		if g_pLocalPlayer:GetVelocity():Length2D() > 1 then
			yaw = MultiplayerAnimState.Instances[LP_REAL].CurrentFeetYaw + (g_bSendPacket and 180 or 0)
		elseif not g_bSendPacket then
			local side = bFlip and -1 or 1
			local lbyTarget = MultiplayerAnimState.Instances[LP_FAKE].GoalFeetYaw

			if math.abs(math.NormalizeAngle(lbyTarget - C_AntiAim.m_qLastAngle.y)) < 100 then
				yaw = math.NormalizeAngle(C_AntiAim.m_qLastAngle.y + 120 * side)
			else
				yaw = math.NormalizeAngle(MultiplayerAnimState.Instances[LP_FAKE].CurrentFeetYaw - 44 * side)
			end
		end

		ang.y = yaw
	end,
	[ANTIAIM_Y_FAKE_FORWARDS] = function(ang)
		ang.y = g_bSendPacket and ang.y or ang.y + (bFlip and 180 or -180)
	end,
	[ANTIAIM_Y_FAKE_SIDEWAYS] = function(ang)
		ang.y = g_bSendPacket and ang.y + (bFlip and 40 or -40) or ang.y + (bFlip and 180 or -180)
	end,
	[ANTIAIM_Y_CUSTOM] = function(ang)
		ang.y = g_bSendPacket and Config["antiaim_customyaw"] or Config["antiaim_customfake"]
	end
}

function C_AntiAim:PerformPitch()
	if Config["antiaim_pitch"] == ANTIAIM_X_NONE then return false end

	Switch(Config["antiaim_pitch"],
		Case(ANTIAIM_X_UP, function()
			C_AntiAim.m_qCurrAngle.x = -89.9
		end),
		Case(ANTIAIM_X_DOWN, function()
			C_AntiAim.m_qCurrAngle.x = 89.9
		end),
		Case(ANTIAIM_X_DANCE, function()
			pDance = pDance + 45
			if pDance > 100 then
				pDance = 0
			elseif pDance > 75 then
				C_AntiAim.m_qCurrAngle.x = -89
			elseif pDance < 75 then
				C_AntiAim.m_qCurrAngle.x = 89
			end
		end),
		Case(ANTIAIM_X_FRONT, function()
			C_AntiAim.m_qCurrAngle.x = 0
		end),
		Case(ANTIAIM_X_UP_FAKE, function()
			C_AntiAim.m_qCurrAngle.x = 180
		end),
		Case(ANTIAIM_X_DOWN_FAKE, function()
			C_AntiAim.m_qCurrAngle.x = -180
		end),
		Case(ANTIAIM_X_FAKE_ZERO_DOWN, function()
			C_AntiAim.m_qCurrAngle.x = 1080
		end),
		Case(ANTIAIM_X_CUSTOM, function()
			C_AntiAim.m_qCurrAngle.x = Config["antiaim_custompitch"]
		end)
	)
	return true
end

function C_AntiAim:PerformYaw(pUserCmd)
	self.m_qCurrAngle.y = self:GetBaseYaw(pUserCmd)

	if Config["antiaim_yaw"] == ANTIAIM_Y_NONE then
		return false
	end

	bFlip = not bFlip

	local fnYawMethod = self.m_tYawFunctions[Config["antiaim_yaw"]]
	if not isfunction(fnYawMethod) then
		return false
	end

	fnYawMethod(self.m_qCurrAngle)

	return true
end

local TraceOutput = {}
local Legnth = 26 + (19 * math.sin(math.rad(10)))
function C_AntiAim:EdgeAntiAim()
	if not Config["antiaim_edge"] then
		return false
	end

	local Wall = 0 --Config.Edge.Wall
	local Corner = 90 --Config.Edge.Corner

	local bRet = false

	local vecLocalPos = g_pLocalPlayer:GetShootPos()

	local allplys = {g_pLocalPlayer}
	for _, v in next, g_tPlayers do
		allplys[#allplys + 1] = v
	end

	for y = 0, 360, 15 do
		local tmp = Angle(10, g_pLocalPlayer:EyeAngles().y, 0)
		tmp.y = tmp.y + y
		tmp:Normalize()

		local forward = tmp:Forward()
		forward = forward * Legnth

		util.TraceLine({
			start = vecLocalPos,
			endpos = vecLocalPos + forward,
			filter = allplys,
			mask = 0x200400B,
			output = TraceOutput
		})

		if TraceOutput.Fraction ~= 1 then
			local Negate = TraceOutput.HitNormal
			Negate = Negate * -1
			local angles = Negate:Angle()

			tmp.y = angles.y
			tmp:Normalize()

			local vecLeft = (tmp + Angle(0, 30, 0)):Forward()
			local vecRight = (tmp - Angle(0, 30, 0)):Forward()
			vecLeft = vecLeft * Legnth
			vecRight = vecRight * Legnth

			local traceLeft = util.TraceLine({
				start = vecLocalPos,
				endpos = vecLocalPos + vecLeft,
				filter = allplys,
				mask = 0x200400B
			})

			local traceRight = util.TraceLine({
				start = vecLocalPos,
				endpos = vecLocalPos + vecRight,
				filter = allplys,
				mask = 0x200400B
			})

			local left_ang = (vecLocalPos + vecLeft):Angle()
			left_ang:Normalize()
			local right_ang = (vecLocalPos + vecRight):Angle()
			right_ang:Normalize()

			if traceLeft.Fraction == 1 and traceRight.Fraction ~= 1 then
				tmp.y = tmp.y - Corner
			elseif traceLeft.Fraction ~= 1 and traceRight.Fraction == 1 then
				tmp.y = tmp.y + Corner
			end

			local va = self.m_qCurrAngle
			va.y = tmp.y
			va.y = g_bSendPacket and tmp.y or tmp.y + 180

			if traceLeft.Fraction == 1 and traceRight.Fraction ~= 1 then
				va.y = tmp.y
				va.y = g_bSendPacket and va.y - 180 or va.y - Wall
			elseif traceLeft.Fraction ~= 1 and traceRight.Fraction == 1 then
				va.y = tmp.y
				va.y = g_bSendPacket and va.y + 180 or va.y - Wall
			end

			bRet = true
		end
	end

	return bRet
end

function C_AntiAim:Run(pUserCmd)
	if not self:ShouldRun(pUserCmd) then
		return false
	end

	self.m_qCurrAngle:Set(pUserCmd:GetViewAngles())

	self:PerformPitch()

	if not self:EdgeAntiAim() then
		self:PerformYaw(pUserCmd)
	end

	if Config["antiaim_clamp"] then
		self.m_qCurrAngle.p = math.Clamp(self.m_qCurrAngle.p, -89, 89)
	end

	pUserCmd:SetViewAngles(self.m_qCurrAngle)
	self.m_qLastAngle = Angle(self.m_qCurrAngle)
end

local flMaxChoke = 21
function C_AntiAim:FakeLag()
	if not Config["fakelag_enabled"] then
		return
	end

	if g_nChokedPackets >= flMaxChoke then
		g_bSendPacket = true
	else
		local nToChoke = 0

		if Config["fakelag_method"] == FAKELAG_METHOD_STATIC then
			nToChoke = Config["fakelag_choke"]
		elseif Config["fakelag_method"] == FAKELAG_METHOD_ADAPTIVE then
			nToChoke = Config["fakelag_choke"] -- idc

			local speed = g_pLocalPlayer:GetVelocity():Length()
			if speed > 0 then
				nToChoke = math.floor((64 / TICK_INTERVAL) / speed) + 1

				if nToChoke >= Config["fakelag_choke"] then
					nToChoke = Config["fakelag_choke"]
				end

				if nToChoke >= flMaxChoke then
					nToChoke = flMaxChoke
				end
			end
		elseif Config["fakelag_method"] == FAKELAG_METHOD_RANDOM then
			nToChoke = rand() * Config["fakelag_choke"]
		end

		g_bSendPacket = g_nChokedPackets >= math.Clamp(math.floor(nToChoke), 0, 21)
	end

	if not g_bSendPacket then
		g_nChokedPackets = g_nChokedPackets + 1
	end
end

function C_AntiAim:FakeDuck(pUserCmd)
	if not Config["fakeduck_enabled"] then return end
	if not C_Inputs:IsKeyActive(Config, "fakeduck_key") then return end
	if bit.band(g_pLocalPlayer:GetFlags(), FL_ONGROUND) == 0 or g_pLocalPlayer:GetMoveType() == MOVETYPE_NOCLIP then return end
	if pUserCmd:KeyDown(IN_JUMP) then return end

	if not Config["fakelag_enabled"] then
		Config["fakelag_enabled"] = true
	end

	if Config["fakelag_choke"] <= 0 then
		Config["fakelag_choke"] = 1
	end

	if g_bSendPacket then
		pUserCmd:AddKey(IN_DUCK)
	else
		pUserCmd:RemoveKey(IN_DUCK)
	end
end

C_AntiAim.m_tGestureLookup = {
	["agree"] = ACT_GMOD_GESTURE_AGREE,
	["becon"] = ACT_GMOD_GESTURE_BECON,
	["bow"] = ACT_GMOD_GESTURE_BOW,
	["cheer"] = ACT_GMOD_TAUNT_CHEER,
	["dance"] = ACT_GMOD_TAUNT_DANCE,
	["disagree"] = ACT_GMOD_GESTURE_DISAGREE,
	["forward"] = ACT_SIGNAL_FORWARD,
	["group"] = ACT_SIGNAL_GROUP,
	["halt"] = ACT_SIGNAL_HALT,
	["laugh"] = ACT_GMOD_TAUNT_LAUGH,
	["muscle"] = ACT_GMOD_TAUNT_MUSCLE,
	["pose"] = ACT_GMOD_TAUNT_PERSISTENCE,
	["robot"] = ACT_GMOD_TAUNT_ROBOT,
	["salute"] = ACT_GMOD_TAUNT_SALUTE,
	["wave"] = ACT_GMOD_GESTURE_WAVE,
	["zombie"] = ACT_GMOD_GESTURE_TAUNT_ZOMBIE
}

local Wait = false
function C_AntiAim:FakeActThink()
	if not Config["fakeact_enabled"] then
		return
	end

	if not g_pLocalPlayer:Alive() or Wait then
		return
	end

	local Gesture = Config["fakeact_gesture"]
	local dGesture = self.m_tGestureLookup[Gesture]

	if not dGesture then
		return
	end

	local sID, sLen = g_pLocalPlayer:LookupSequence(g_pLocalPlayer:GetSequenceName(g_pLocalPlayer:SelectWeightedSequence(dGesture)))
	if not sID or not sLen then
		return
	end

	if Gamemode == "darkrp" then
		g_pLocalPlayer:ConCommand("_DarkRP_DoAnimation " .. dGesture)
	else
		g_pLocalPlayer:ConCommand("act " .. Gesture)
	end

	Wait = true

	timer.Simple(sLen + 0.3, function()
		Wait = false
	end)
end

--[[
	Visuals
]]

function C_Visuals:DrawChromaticLine(head, tail)
	local theta = math.atan2(head.y - tail.y, head.x - tail.x) + math.rad(90)

	local offset_x = math.sin(theta) * 1.5
	local offset_y = math.cos(theta) * 1.5

	surface.SetDrawColor(255, 0, 0, 55)
	surface.DrawLine(head.x + offset_x, head.y + offset_y, tail.x + offset_x, tail.y + offset_y)

	surface.SetDrawColor(0, 0, 255, 55)
	surface.DrawLine(head.x - offset_x, head.y - offset_y, tail.x - offset_x, tail.y - offset_y)

	surface.SetDrawColor(255, 255, 255, 255)
	surface.DrawLine(head.x, head.y, tail.x, tail.y)
end

function C_Visuals:ShouldRotate(pEntity)
	return not (pEntity:IsPlayer() or pEntity:IsNPC() or pEntity:IsNextBot())
end

local VERTEX_MATRIX = {
	Vector(-1, -1, -1),
	Vector(-1, -1, 1),
	Vector(-1, 1, -1),
	Vector(-1, 1, 1),
	Vector(1, -1, -1),
	Vector(1, -1, 1),
	Vector(1, 1, -1),
	Vector(1, 1, 1)
}
function C_Visuals:GetScreenCorners(entity, box) -- black p screen corners
	local pos = entity:GetPos()
	local mins, maxs = entity:GetCollisionBounds()
	local size = (maxs - mins) * 0.5
	local box_center = pos + (mins + maxs) * 0.5

	local x, y = INT_MAX, INT_MAX
	local w, h = -x, -y

	for i = 1, 8 do
		local corner = (box_center + VERTEX_MATRIX[i] * size):ToScreen()

		if corner.x < x then x = corner.x end
		if corner.y < y then y = corner.y end
		if corner.x > w then w = corner.x end
		if corner.y > h then h = corner.y end
	end

	if w <= 0 or h <= 0 or x >= SCREEN_WIDTH or y >= SCREEN_HEIGHT then
		return false
	end

	w = w - x
	h = h - y

	if w < 1 or h < 1 then
		return false
	end

	box.x = x
	box.y = y
	box.w = w
	box.h = h

	return true
end

function C_Visuals:GetPlayerAvatar(hPlayer)
	if IsValid(self.m_tPlayersAvatars[hPlayer]) then
		return self.m_tPlayersAvatars[hPlayer]
	end

	local AvatarImage = vgui.Create("AvatarImage")
	AvatarImage:SetSize(16, 16)
	AvatarImage:SetVisible(false)
	AvatarImage:SetPaintedManually(true)
	AvatarImage:SetPlayer(hPlayer, 16)

	self.m_tPlayersAvatars[hPlayer] = AvatarImage

	return AvatarImage
end

function C_Visuals:ESP2D(pEntity, strEntType)
	local flHealth = pEntity:Health()
	local flHealthFraction = math.Clamp(flHealth / pEntity:GetMaxHealth(), 0, 1)
	local vHealthColor = HSVToColor(120 * flHealthFraction, 0.86, 0.86)

	local bIsDormant = pEntity:IsDormant()
	vHealthColor.a = (bIsDormant and 90 or 255)

	if Config[strEntType .. "esp_skeleton"] then
		for bone = 0, ply:GetBoneCount() - 1 do
			if not ply:BoneHasFlag(bone, BONE_USED_BY_HITBOX) then continue end

			local parent = ply:GetBoneParent(bone)
			if not parent or not ply:BoneHasFlag(parent, BONE_USED_BY_HITBOX) then
				continue
			end

			render.DrawLine(
				ply:GetBoneMatrix(bone):GetTranslation(),
				ply:GetBoneMatrix(parent):GetTranslation(), vHealthColor, false
			)
		end
	end

	local tblBox = {}
	local bValidBox = self:GetScreenCorners(pEntity, tblBox)
	if not bValidBox then
		return
	end

	local flLeft, flRight, flWidth, flHeight = tblBox.x, tblBox.y, tblBox.w, tblBox.h

	--local flTop = flRight - flHeight
	local flBottom = flRight + flHeight

	local bIsPlayer = (strEntType == "player")

	if Config[strEntType .. "esp_box2d"] then
		local originalAlpha = color_black.a
		color_black.a = vHealthColor.a
		surface.SetDrawColor(color_black)
		color_black.a = originalAlpha

		surface.DrawOutlinedRect(flLeft, flRight, flWidth, flHeight, 1)
		surface.DrawOutlinedRect(flLeft + 2, flRight + 2, flWidth - 4, flHeight - 4, 1)

		surface.SetDrawColor(vHealthColor)
		surface.DrawOutlinedRect(flLeft + 1, flRight + 1, flWidth - 2, flHeight - 2, 1)
	end

	surface.SetFont("jackson_font")

	local tw, th = 0, 0
	if Config[strEntType .. "esp_name"] then
		local strName = bIsPlayer and pEntity:GetName() or pEntity:GetClass()
		tw, th = surface.GetTextSize(strName)

		surface.SetTextColor(vHealthColor)
		surface.SetTextPos(Config[strEntType .. "esp_box2d"] and flLeft or flLeft + (flWidth / 2) - (tw / 2), flRight - th)
		surface.DrawText(strName)
	end

	local tCurrInfo = {}

	if Config[strEntType .. "esp_health"] then
		tCurrInfo[#tCurrInfo + 1] = {
			m_strText = string.format("HP: %s", flHealth),
			m_vColor = vHealthColor
		}
	end

	if Config[strEntType .. "esp_armor"] and bIsPlayer then
		local flArmor = pEntity:Armor()
		local flArmorFraction = math.Clamp(flArmor / pEntity:GetMaxArmor(), 0, 1)
		local vArmorColor = HSVToColor(211 * flArmorFraction, 0.33 * flArmorFraction, 1)
		vArmorColor.a = (bIsDormant and 90 or 255)

		tCurrInfo[#tCurrInfo + 1] = {
			m_strText = string.format("Armor: %s", flArmor),
			m_vColor = vArmorColor
		}
	end

	if Config[strEntType .. "esp_weapon"] then
		local hWeapon = pEntity.GetActiveWeapon and pEntity:GetActiveWeapon() or NULL
		if IsValid(hWeapon) then
			local strWeaponName = hWeapon:GetPrintName() or hWeapon:GetClass()

			tCurrInfo[#tCurrInfo + 1] = {
				m_strText = strWeaponName,
				m_vColor = Color(255, 255, 255, bIsDormant and 90 or 255)
			}
		end
	end

	if LagCompensation.m_tBreakingLagComp[pEntity] then
		tCurrInfo[#tCurrInfo + 1] = {
			m_strText = "Breaking LC",
			m_vColor = color_seafoam
		}
	end

	if Config["misc_debuginfo"] then
		local event_time = TICKS_TO_TIME(engine.TickCount())
		local player_time = GetSimulationTime(pEntity)

		local choked = math.floor((event_time - player_time) / TICK_INTERVAL)
		choked = math.Clamp(choked, 0, 21)

		tCurrInfo[#tCurrInfo + 1] = {
			m_strText = string.format("Choked Packets: %s", choked),
			m_vColor = Color(255, 255, 255, bIsDormant and 90 or 255)
		}
	end

	if Config[strEntType .. "esp_barrel"] then
		local col = team.GetColor(pEntity:Team())
		local b = pEntity:LookupBone("ValveBiped.Bip01_Head1")

		if b then
			local ShootBone = pEntity:GetBonePosition(b)
			cam.Start3D()
				render.DrawLine(ShootBone, pEntity:GetEyeTrace().HitPos, col, false)
			cam.End3D()
		end
	end

	if #tCurrInfo > 0 then
		for i, pCurrInfo in ipairs(tCurrInfo) do
			surface.SetTextColor(pCurrInfo.m_vColor)
			surface.SetTextPos(flLeft + flWidth, flBottom + (i - 1) * 12)
			surface.DrawText(pCurrInfo.m_strText)
		end
	end

	-- below is player only
	if not bIsPlayer then return end

	if Config["playeresp_avatar"] then
		local pAvatar = self:GetPlayerAvatar(pEntity)
		if IsValid(pAvatar) then
			local y = flRight - 24
			if Config[strEntType .. "esp_name"] then
				y = y - th
			end

			pAvatar:PaintAt(flLeft + ((flWidth / 2) - 8), y)
		end
	end
end

function C_Visuals:DrawSpreadCone()
	local cone = C_Accuracy:GetSpreadTangent() or vector_origin

	if isfunction(cone) then
		cone = cone(wep)
	end

	local a = math.asin(cone.x * 2)
	local deg = math.deg(a) / 2

	local flAspectRatio = SCREEN_WIDTH / SCREEN_HEIGHT

	local radSpread = math.rad(deg)

	local view = render.GetViewSetup()
	local radGameFOV = math.rad(view.fov_unscaled)
	local radViewFOV = 2 * math.atan(flAspectRatio * 1.45 * math.tan(radGameFOV / 2))

	local flRadius = (math.tan(radSpread) / math.tan(radViewFOV * 0.5)) * SCREEN_WIDTH

	if cone and cone ~= 0 then
		surface.DrawCircle(SCREEN_CENTER_X, SCREEN_CENTER_Y, flRadius, 255, 255, 255, 255)
	end
end

function C_Visuals:AimLine()
	if not g_pLocalPlayer:Alive() then
		return
	end

	local vShootPos = g_pLocalPlayer:GetShootPos()
	local hTarget = C_Ragebot:GetTarget(vShootPos)

	if not IsValid(hTarget) then
		return
	end

	local vPosition = C_Ragebot:GetAimPosition(hTarget, vShootPos)
	if not vPosition then
		return
	end

	local vScreenPosition = vPosition:ToScreen()
	if not vScreenPosition.visible then
		return
	end

	surface.SetDrawColor(Config["aimline_color"])
	surface.DrawLine(SCREEN_CENTER_X, SCREEN_CENTER_Y, vScreenPosition.x, vScreenPosition.y)
end

function C_Visuals:AntiAimLines()
	if not g_pLocalPlayer:Alive() then
		return
	end

	local vLocalpos = g_pLocalPlayer:GetPos()
	if not vLocalpos then
		return
	end

	local vScreenPos = vLocalpos:ToScreen()
	if not vScreenPos.visible then
		return
	end

	local vRealPos = (vLocalpos + Angle(0, g_qRealAngle.y, 0):Forward() * 30):ToScreen()
	local vFakePos = (vLocalpos + Angle(0, g_qFakeAngle.y, 0):Forward() * 30):ToScreen()
	if not vRealPos.visible or not vFakePos.visible then
		return
	end

	surface.SetDrawColor(255, 0, 0)
	surface.DrawLine(vScreenPos.x, vScreenPos.y, vFakePos.x, vFakePos.y)

	surface.SetDrawColor(0, 255, 0)
	surface.DrawLine(vScreenPos.x, vScreenPos.y, vRealPos.x, vRealPos.y)
end

--[[
		std::ofstream("csgo/materials/glowOverlay.vmt") << R"#("VertexLitGeneric" {
	 
		"$additive" "1"
		"$envmap" "models/effects/cube_white"
		"$envmaptint" "[1 1 1]"
		"$envmapfresnel" "1"
		"$envmapfresnelminmaxexp" "[0 1 2]"
		"$alpha" "0.8"
	})#";
]]

C_Visuals.m_tChamMaterials = {
	["flat"] = { -- from nodatafound
		imat = CreateMaterial("flat_occ " .. tostring(math.random(-10000, 10000)), "UnlitGeneric", {
			["$additive"] = "1",
			["$ignorez"] = 0,
			["$basetexture"] = "vgui/white_additive",
			["$bumpmap"] = "vgui/white_additive",
			["$selfillum"] = "1",
			["$selfIllumFresnel"] = "1",
			["$selfIllumFresnelMinMaxExp"] = "[0 0.18 0.6]",
			["$selfillumtint"] = "[0 0 0]"
		}),
		vmat = CreateMaterial("flat_vis " .. tostring(math.random(-10000, 10000)), "UnlitGeneric", {
			["$additive"] = "0",
			["$ignorez"] = 0,
			["$basetexture"] = "vgui/white_additive",
			["$bumpmap"] = "vgui/white_additive",
			["$selfillum"] = "1",
			["$selfIllumFresnel"] = "1",
			["$selfIllumFresnelMinMaxExp"] = "[0 0.18 0.6]",
			["$selfillumtint"] = "[0 0 0]"
		})
	},
	["metallic"] = {
		imat = CreateMaterial("metallic_occ " .. tostring(math.random(-10000, 10000)), "VertexLitGeneric", {
			["$basetexture"] = "vgui/white_additive",
			["$envmap"] = "env_cubemap",
			["$normalmapalphaenvmapmask"] = 1,
			["$envmapcontrast"] = 1,
			["$nofog"] = 1,
			["$model"] = 1,
			["$nocull"] = 0,
			["$selfillum"] = 1,
			["$halflambert"] = 1,
			["$znearer"] = 0,
			["$flat"] = 1,
			["$ignorez"] = 1,
		}),
		vmat = CreateMaterial("metallic_vis " .. tostring(math.random(-10000, 10000)), "VertexLitGeneric", {
			["$basetexture"] = "vgui/white_additive",
			["$envmap"] = "env_cubemap",
			["$normalmapalphaenvmapmask"] = 1,
			["$envmapcontrast"] = 1,
			["$nofog"] = 1,
			["$model"] = 1,
			["$nocull"] = 0,
			["$selfillum"] = 1,
			["$halflambert"] = 1,
			["$znearer"] = 0,
			["$flat"] = 1,
			["$ignorez"] = 0,
		})
	},
	["glow"] = {
		imat = CreateMaterial("glow_occ " .. tostring(math.random(-10000, 10000)), "VertexLitGeneric", {
			["$basetexture"] = "vgui/white_additive",
			["$bumpmap"] = "vgui/white_additive",
			["$model"] = "1",
			["$nocull"] = "1",
			["$nodecal"] = "1",
			["$additive"] = "1",
			["$selfillum"] = 1,
			["$selfIllumFresnel"] = 1,
			["$selfIllumFresnelMinMaxExp"] = "[0.0 0.3 0.6]",
			["$selfillumtint"] = "[0 0 0]",
		}),
		vmat = CreateMaterial("glow_vis " .. tostring(math.random(-10000, 10000)), "VertexLitGeneric", {
			["$basetexture"] = "vgui/white_additive",
			["$bumpmap"] = "vgui/white_additive",
			["$model"] = "1",
			["$nocull"] = "0",
			["$selfillum"] = 1,
			["$selfIllumFresnel"] = 1,
			["$selfIllumFresnelMinMaxExp"] = "[0.0 0.3 0.6]",
			["$selfillumtint"] = "[0 0 0]",
		})
	},
	["wireframe"] = {
		imat = CreateMaterial("wireframe_occ " .. tostring(math.random(-10000, 10000)), "", {["$ignorez"] = 1}),
		vmat = CreateMaterial("wireframe_vis " .. tostring(math.random(-10000, 10000)), "", {})
	},
	["glowframe"] = {
		vmat = CreateMaterial("glowframe_vis " .. tostring(math.random(-10000, 10000)), "VertexLitGeneric",{
			["$basetexture"] = "vgui/white_additive",
			["$nocull"] = 1,
			["$wireframe"] = 1,
			["$additive"] = 1,
			["$envmap"] = "vgui/white_additive",
			["$envmaptint"] = "[1 1 1]",
			["$envmapfresnel"] = 1,
			["$phong"] = 1,
			["$envmapfresnelminmaxexp"] = "[0 2 4]",
			["$envmapanisotropy"] = 1,
			["$envmapanisotropyscale"] = 5,
			["$alpha"] = 1,
		}),
		imat = CreateMaterial("glowframe_occ " .. tostring(math.random(-10000, 10000)), "VertexLitGeneric",{
			["$basetexture"] = "vgui/white_additive",
			["$nocull"] = 1,
			["$wireframe"] = 1,
			["$additive"] = 1,
			["$envmap"] = "vgui/white_additive",
			["$envmaptint"] = "[1 1 1]",
			["$envmapfresnel"] = 1,
			["$phong"] = 1,
			["$envmapfresnelminmaxexp"] = "[0 2 4]",
			["$envmapanisotropy"] = 1,
			["$envmapanisotropyscale"] = 5,
			["$ignorez"] = 1,
			["$alpha"] = 1,

		}),
	},
	["fireframe"] = {
		vmat = CreateMaterial("fireframe_vis " .. tostring(math.random(-10000, 10000)), "VertexLitGeneric",{
			["$nocull"] = 1,
			["$wireframe"] = 1,
			["$basetexture"] = "vgui/white_additive",
			["$detail"] = "effects/tiledfire/firelayeredslowtiled512",
			["$detailscale"] = 1,
			["$detailblendmode"] = 0,
			["$detailblendfactor"] = 4,
			["$color2"] = "[7 7 7]",
			["$selfillum"] = 1,
			["$selfIllumFresnel"] = 1,
			["$selfIllumFresnelMinMaxExp"] = "[0 .18 .1]", --[0 .18 .1]
			["$selfillumtint"] = "[.1 .1 .1]",
			["$alpha"] = .2,
			["Proxies"] = {
				["AnimatedTexture"] = {
					["animatedtexturevar"] = "$detail",
					["animatedtextureframenumvar"] = "$detailframe",
					["animatedtextureframerate"] = 60,
				},
			},
		}),
		imat = CreateMaterial("fireframe_occ " .. tostring(math.random(-10000, 10000)), "VertexLitGeneric",{
			["$nocull"] = 1,
			["$wireframe"] = 1,
			["$basetexture"] = "vgui/white_additive",
			["$detail"] = "effects/tiledfire/firelayeredslowtiled512",
			["$detailscale"] = 1,
			["$detailblendmode"] = 0,
			["$detailblendfactor"] = 4,
			["$color2"] = "[7 7 7]",
			["$selfillum"] = 1,
			["$selfIllumFresnel"] = 1,
			["$selfIllumFresnelMinMaxExp"] = "[0 .18 .1]", --[0 .18 .1]
			["$selfillumtint"] = "[.1 .1 .1]",
			["$alpha"] = .2,
			["$ignorez"] = 1,
			["Proxies"] = {
				["AnimatedTexture"] = {
					["animatedtexturevar"] = "$detail",
					["animatedtextureframenumvar"] = "$detailframe",
					["animatedtextureframerate"] = 60,
				},
			},
		}),
	},
	["pulseframe"] = { -- from nodatafound
		vmat = CreateMaterial("pulseframe_vis " .. tostring(math.random(-10000, 10000)), "VertexLitGeneric",{
			["$basetexture"] = "models/props_combine/portalball001_sheet", --vgui/achievements/glow : )
			["$model"] = 1,
			["$additive"] = 1,
			["$ignorez"] = 0,
			["$nocull"] = 0,
			["$wireframe"] = 1,
			Proxies = {
				TextureScroll = {
					texturescrollvar = "$basetexturetransform",
					texturescrollrate = 0.5,
					texturescrollangle = 90,
				}
			}
		}),
		imat = CreateMaterial("pulseframe_occ " .. tostring(math.random(-10000, 10000)), "VertexLitGeneric",{
			["$basetexture"] = "models/props_combine/portalball001_sheet", --vgui/achievements/glow : )
			["$model"] = 1,
			["$additive"] = 1,
			["$ignorez"] = 1,
			["$nocull"] = 0,
			["$wireframe"] = 1,
			Proxies = {
				TextureScroll = {
					texturescrollvar = "$basetexturetransform",
					texturescrollrate = 0.5,
					texturescrollangle = 90,
				}
			}
		}),
	},
	["islandwater"] = {
		vmat = CreateMaterial("islandwater_vis " .. tostring(math.random(-10000, 10000)), "VertexLitGeneric", {
			["$basetexture"] = "water/island_water01_normal",
			["$model"] = 1,
			["$additive"] = 1,
			["$nocull"] = 1,
			["$alpha"] = 1,
			["Proxies"] = {
				["TextureScroll"] = {
					["texturescrollvar"] = "$basetexturetransform",
					["texturescrollrate"] = 1,
					["texturescrollangle"] = math.abs(math.sin(CurTime() * 25) * 360),
				},
			},
		}),
		imat = CreateMaterial("islandwater_occ " .. tostring(math.random(-10000, 10000)), "VertexLitGeneric", {
			["$basetexture"] = "water/island_water01_normal",
			["$model"] = 1,
			["$additive"] = 1,
			["$nocull"] = 1,
			["$alpha"] = 1,
			["Proxies"] = {
				["TextureScroll"] = {
					["texturescrollvar"] = "$basetexturetransform",
					["texturescrollrate"] = 1,
					["texturescrollangle"] = math.abs(math.sin(CurTime() * 25) * 360),
				},
			},
			["$ignorez"] = 1,
		}),
	},
	["islandframe"] = {
		vmat = CreateMaterial("islandframe_vis " .. tostring(math.random(-10000, 10000)), "VertexLitGeneric", {
			["$wireframe"] = 1,
			["$basetexture"] = "water/island_water01_normal",
			["$model"] = 1,
			["$additive"] = 1,
			["$nocull"] = 1,
			["$alpha"] = 1,
			["Proxies"] = {
				["TextureScroll"] = {
					["texturescrollvar"] = "$basetexturetransform",
					["texturescrollrate"] = 1,
					["texturescrollangle"] = math.abs(math.sin(CurTime() * 25) * 360),
				},
			},
		}),
		imat = CreateMaterial("islandframe_occ " .. tostring(math.random(-10000, 10000)), "VertexLitGeneric", {
			["$wireframe"] = 1,
			["$basetexture"] = "water/island_water01_normal",
			["$model"] = 1,
			["$additive"] = 1,
			["$nocull"] = 1,
			["$alpha"] = 1,
			["Proxies"] = {
				["TextureScroll"] = {
					["texturescrollvar"] = "$basetexturetransform",
					["texturescrollrate"] = 1,
					["texturescrollangle"] = math.abs(math.sin(CurTime() * 25) * 360),
				},
			},
			["$ignorez"] = 1,
		}),
	}
}

function C_Visuals:DrawChams(pEntity, strEntType)
	if not Config[strEntType .. "chams_enabled"] then
		return
	end

	if Config[strEntType .. "chams_occluded_enabled"] then
		local vCurrColor = Config[strEntType .. "chams_occluded_color"]
		local strMaterial = Config[strEntType .. "chams_occluded_material"]

		render.SuppressEngineLighting(true)
			render.SetColorModulation(vCurrColor.r / 255, vCurrColor.g / 255, vCurrColor.b / 255)
			render.MaterialOverride(self.m_tChamMaterials[strMaterial].imat )
			render.SetBlend(vCurrColor.a / 255)
			pEntity:DrawModel()
		render.SuppressEngineLighting(false)
	end

	if Config[strEntType .. "chams_visible_enabled"] then
		local vCurrColor = Config[strEntType .. "chams_visible_color"]
		local strMaterial = Config[strEntType .. "chams_visible_material"]

		render.SuppressEngineLighting(true)
			render.SetColorModulation(vCurrColor.r / 255, vCurrColor.g / 255, vCurrColor.b / 255)
			render.MaterialOverride(self.m_tChamMaterials[strMaterial].vmat)
			render.SetBlend(vCurrColor.a / 255)
			pEntity:DrawModel()
		render.SuppressEngineLighting(false)
	end

	if Config[strEntType .. "chams_overlay_enabled"] then
		local vCurrColor = Config[strEntType .. "chams_overlay_color"]
		local strMaterial = Config[strEntType .. "chams_overlay_material"]

		render.SuppressEngineLighting(true)
			render.SetColorModulation(vCurrColor.r / 255, vCurrColor.g / 255, vCurrColor.b / 255)
			render.MaterialOverride(self.m_tChamMaterials[strMaterial].imat)
			render.SetBlend(vCurrColor.a / 255)
			pEntity:DrawModel()
		render.SuppressEngineLighting(false)
	end
end

local CopyMat = Material("pp/copy")
local OutlineMat = CreateMaterial("OutlineMat", "UnlitGeneric", {
	["$ignorez"] = 1,
	["$alphatest"] = 1
})

local StoreTexture = render.GetScreenEffectTexture(0)
local DrawTexture = render.GetScreenEffectTexture(1)

local ENTS = 1
local COLOR = 2

function C_Visuals:Outlines(List)
	local scene = render.GetRenderTarget()
	render.CopyRenderTargetToTexture( StoreTexture )

	render.Clear( 0, 0, 0, 0, true, true )

	render.SetStencilEnable( true )
		cam.IgnoreZ( true )
		render.SuppressEngineLighting( true )

		render.SetStencilWriteMask(0xFF)
		render.SetStencilTestMask(0xFF)

		render.SetStencilCompareFunction( STENCIL_ALWAYS )
		render.SetStencilFailOperation( STENCIL_KEEP )
		render.SetStencilZFailOperation( STENCIL_REPLACE )
		render.SetStencilPassOperation( STENCIL_REPLACE )

		cam.Start3D()
			for i = 1, #List do
				local v = List[ i ]
				local ents = v[ ENTS ]

				render.SetStencilReferenceValue( i )

				for j = 1, #ents do
					local ent = ents[ j ]
					if ( not IsValid( ent ) ) then continue end

					ent:DrawModel()
				end
			end
		cam.End3D()

		render.SetStencilCompareFunction( STENCIL_EQUAL )

		cam.Start2D()
			for i = 1, #List do
				render.SetStencilReferenceValue( i )

				surface.SetDrawColor( List[ i ][ COLOR ] )
				surface.DrawRect( 0, 0, SCREEN_WIDTH, SCREEN_HEIGHT )
			end
		cam.End2D()

		render.SuppressEngineLighting( false )
		cam.IgnoreZ( false )
	render.SetStencilEnable( false )

	render.CopyRenderTargetToTexture( DrawTexture )

	render.SetRenderTarget( scene )
	CopyMat:SetTexture( "$basetexture", StoreTexture )
	render.SetMaterial( CopyMat )
	render.DrawScreenQuad()

	render.SetStencilEnable( true )
		render.SetStencilReferenceValue( 0 )
		render.SetStencilCompareFunction( STENCIL_EQUAL )

		OutlineMat:SetTexture( "$basetexture", DrawTexture )
		render.SetMaterial( OutlineMat )

		local SIZE = 1
		for x = -SIZE,SIZE,1 do
			for y = -SIZE,SIZE,1 do
				render.DrawScreenQuadEx( x, y, SCREEN_WIDTH ,SCREEN_HEIGHT )
			end
		end

	render.SetStencilEnable( false )
end

do -- from hnc, its just useful info
	local y = (SCREEN_HEIGHT * .1)

	local function Debug(str, col)
		if not str or str == "" then y = y + 16 return end
		local x = 15
		str = tostring(str)
		col = col or Color(255, 255, 255)

		surface.SetFont("DermaDefault")

		local steps = math.min((1 * 2) / 3, 1)
		surface.SetTextColor(0,0,0)
		for _x = -1, 1, steps do
			for _y = -1, 1, steps do
				surface.SetTextPos(x + _x, y + _y)
				surface.DrawText(str)
			end
		end

		surface.SetTextPos(x, y)
		surface.SetTextColor(col)
		surface.DrawText(str)
		y = y + 16
	end

	function C_Visuals:ShowInfo()
		local tRender = CurTime()
		local tServer = engine.TickCount() * TICK_INTERVAL

		Debug("[Server Info]")
		Debug(string.format("Render Time: %f", tRender))
		Debug(string.format("Server Time: %f", C_CreateMove.m_flServerTime))
		Debug(string.format("Time Diff: %f", math.abs(tRender - tServer)))
		Debug(string.format("Tick Count: %d", engine.TickCount()))
		Debug(string.format("Tick Interval: %f (%d)", TICK_INTERVAL, 1 / TICK_INTERVAL))

		Debug("")
		Debug("[User Info]")
		Debug(string.format("Lerp: %f", LagCompensation.m_flLerpTime))
		Debug(string.format("Frametime: %f (%d)", RealFrameTime(), 1 / RealFrameTime()))
		Debug(string.format("Packets Choked: %d", g_nChokedPackets))
		Debug(string.format("bSendPacket: %s", tostring(g_bSendPacket)))
		Debug(string.format("Using World Context: %s", tostring(g_pUserCmd:GetInWorldClicker())))
		Debug(string.format("Collected Garbage: %d", collectgarbage("count")))
		Debug(string.format("Can Shoot: %s", tostring(C_CreateMove.m_bCanShoot)))

		Debug("")
		Debug("[Ragebot]")
		Debug(string.format("Is Active: %s", tostring(C_Ragebot:ShouldAim())))
		Debug(string.format("Force Safepoint: %s", tostring(false)))
		Debug(string.format("Current Target: %s", C_Ragebot:GetTarget(g_pLocalPlayer:GetShootPos()) or NULL))

		Debug("")
		Debug("[Backtrack]")
		Debug(string.format("Max Time: %f", LagCompensation:GetMaxBackTrackTime()))

		Debug("")
		Debug("[NoSpread]")
		Debug(string.format("Spread: %s", isvector(C_Accuracy.m_tCurrWeaponData.m_vSpreadCone) and C_Accuracy.m_tCurrWeaponData.m_vSpreadCone or C_Accuracy.m_tCurrWeaponData.m_flSpread or angle_zero))

		y = SCREEN_HEIGHT * .1
	end
end

function C_Visuals:OnScreen(pEntity)
	local vDirection = pEntity:GetPos() - g_pLocalPlayer:GetShootPos()
	local flLength = vDirection:Length()
	local nRadius = pEntity:BoundingRadius()

	local flMax = math.abs(math.cos(math.acos(flLength / math.sqrt((flLength^2) + (nRadius^2))) + 60 * (M_HPI / 180)))

	vDirection:Normalize()

	return vDirection:Dot(EyeVector()) > flMax
end

--[[
	Movement
]]

enum("AUTOSTRAFE_MODE", {
	false,
	"LEGIT",
	"RAGE",
	"DIRECTIONAL"
})

function C_Movement:FixMovement(cmd, aWishDir)
	local factor = 1
	if g_pLocalPlayer:GetObserverMode() == OBS_MODE_ROAMING then
		factor = sv_specspeed:GetFloat()
	else
		factor = sv_noclipspeed:GetFloat()
	end

	if cmd:KeyDown(IN_SPEED) then
		factor = factor * 0.5
	end

	local aRealDir = cmd:GetViewAngles()
	aRealDir:Normalize()

	local vRealF = aRealDir:Forward()
	local vRealR = aRealDir:Right()
	vRealF.z = 0
	vRealR.z = 0

	vRealF:Normalize()
	vRealR:Normalize()

	aWishDir:Normalize()

	local vWishF = aWishDir:Forward()
	local vWishR = aWishDir:Right()
	vWishF.z = 0
	vWishR.z = 0

	vWishF:Normalize()
	vWishR:Normalize()

	local forwardmove = cmd:GetForwardMove() * factor
	local sidemove = cmd:GetSideMove() * factor
	local upmove = cmd:GetUpMove() * factor

	local vWishVel = vWishF * forwardmove + vWishR * sidemove
	vWishVel.z = vWishVel.z + upmove

	local a, b, c, d, e, f = vRealF.x, vRealR.x, vRealF.y, vRealR.y, vRealF.z, vRealR.z
	local u, v, w = vWishVel.x, vWishVel.y, vWishVel.z
	local flDivide = (b * c - a * d) * factor

	local x = -(d * u - b * v) / flDivide
	local y = (c * u - a * v) / flDivide
	local z = (a * (f * v - d * w) + b * (c * w - e * v) + u * (d * e - c * f)) / flDivide

	x = math.Clamp(x, -10000, 10000)
	y = math.Clamp(y, -10000, 10000)
	z = math.Clamp(z, -10000, 10000)

	cmd:SetForwardMove(x)
	cmd:SetSideMove(y)
	cmd:SetUpMove(z)
end

function C_Movement:RotateMovement(pUserCmd, flYawRotation)
	local yaw, flSpeed
	local vMove = Vector(pUserCmd:GetForwardMove(), pUserCmd:GetSideMove(), 0)

	flSpeed = vMove:Length2D()

	local ViewAngles = pUserCmd:GetViewAngles()
	ViewAngles:Normalize()

	local ViewYaw = g_pLocalPlayer:EyeAngles().y
	if isnumber(flYawRotation) then
		ViewYaw = ViewYaw - flYawRotation
	end

	yaw = math.deg(math.atan2(vMove.y, vMove.x))
	yaw = math.rad(ViewAngles.y - ViewYaw + yaw)

	pUserCmd:SetForwardMove(math.cos(yaw) * flSpeed)
	pUserCmd:SetSideMove(math.sin(yaw) * flSpeed)

	if ViewAngles.x < -90 or ViewAngles.x > 90 then
		pUserCmd:SetForwardMove(-pUserCmd:GetForwardMove())
		pUserCmd:SetSideMove(-pUserCmd:GetSideMove())
	end
end

function C_Movement:ClipVelocity(vVel, vHitNormal)
	local vClipVelo = Vector(vVel)
	local flBackOff = vVel:Dot(vHitNormal)

	for i = 1, 3 do
		vClipVelo[i] = vVel[i] - vHitNormal[i] * flBackOff
	end

	local flAdjust = vClipVelo:Dot(vHitNormal)
	if flAdjust < 0 then
		vClipVelo = vClipVelo - (vHitNormal * flAdjust)
	end

	return vClipVelo
end

function C_Movement:GetAngleFromSpeed(speed)
	local ideal_angle = math.deg(math.atan2(70, speed))

	return math.Clamp(ideal_angle, 5, 90)
end

function C_Movement:GetVelocityStep(vVelocity, flSpeed, flCircleYaw)
	local velocity_degree = math.deg(math.atan2(vVelocity.x, vVelocity.y))
	local flStep = 1.5

	local start = g_pLocalPlayer:GetPos()
	local endpos = Vector(start)

	local trOutput = {}
	while true do
		endpos.x = endpos.x + math.cos(math.rad(velocity_degree + flCircleYaw) * flSpeed)
		endpos.y = endpos.y + math.sin(math.rad(velocity_degree + flCircleYaw) * flSpeed)
		endpos:Mul(TICK_INTERVAL)

		util.TraceHull({
			output = trOutput,

			start = start,
			endpos = endpos,
			mask = CONTENTS_SOLID,
			mins = g_pLocalPlayer:OBBMins(),
			maxs = g_pLocalPlayer:OBBMaxs()
		})

		if trOutput.Fraction < 1.0 or trOutput.AllSolid or trOutput.StartSolid then break end

		flStep = flStep - TICK_INTERVAL

		if flStep <= 0.0 then break end

		start:Set(endpos)
		velocity_degree = velocity_degree + (velocity_degree + flCircleYaw)
	end

	return flStep
end

function C_Movement:AutoStrafe(pUserCmd)
	local vVelocity = g_pLocalPlayer:GetVelocity()
	local flSpeed = vVelocity:Length2D()

	local flMaxSideMove = cl_sidespeed:GetFloat()
	local flMaxForwardMove = cl_forwardspeed:GetFloat()

	if Config["movement_autostrafe_mode"] == AUTOSTRAFE_MODE_LEGIT then
		local flMouseX = pUserCmd:GetMouseX()

		if flMouseX > 0 then
			pUserCmd:SetSideMove(flMaxSideMove)
		elseif flMouseX < 0 then
			pUserCmd:SetSideMove(-flMaxSideMove)
		end

		if pUserCmd:KeyDown(IN_JUMP) then
			pUserCmd:SetForwardMove((flMaxForwardMove * 0.5) / flSpeed)
			pUserCmd:SetSideMove(pUserCmd:CommandNumber() % 2 == 0 and -flMaxSideMove or flMaxSideMove)
		end
	elseif Config["movement_autostrafe_mode"] == AUTOSTRAFE_MODE_DIRECTIONAL then
		local vMove = Vector(flMaxSideMove, 0, 0)
		local qMoveAngle = vMove:Angle()
		local qOmniAngle = self:GetMoveVector(pUserCmd):Angle()
		qMoveAngle.y = qMoveAngle.y + qOmniAngle.y

		vVelocity.z = 0
		local qDirection = vVelocity:Angle()
		qDirection = qDirection + qOmniAngle

		math.NormalizeAngle(qDirection.y)

		local flVeloDiff = math.AngleDifference(pUserCmd:GetViewAngles().y, qDirection.y)
		math.NormalizeAngle(flVeloDiff)

		if flVeloDiff > 0 then
			qMoveAngle.y = qMoveAngle.y + (-90 + flVeloDiff)
		elseif flVeloDiff < 0 then
			qMoveAngle.y = qMoveAngle.y + (90 + flVeloDiff)
		else
			qMoveAngle.y = qMoveAngle.y + (flVeloDiff + pUserCmd:CommandNumber() % 2 == 0 and 90 or -90)
		end

		vMove = (qMoveAngle):Forward()
		vMove:Mul(flMaxSideMove)

		pUserCmd:SetForwardMove(vMove.x)
		pUserCmd:SetSideMove(vMove.y)
	end
end

function C_Movement:PredictVelocity(vVelocity, qViewAngles, nWishDir, nMaxSpeed, flAccelerate )
	local vForward = qViewAngles:Forward()
	local vRight = qViewAngles:Right()

	local nForwardMove = 0
	local nSideMove = (nWishDir == 1) and -10000 or 10000

	vForward.z = 0
	vRight.z = 0

	vForward:Normalize()
	vRight:Normalize()

	local vWishDir = Vector(vForward.x * nForwardMove + vRight.x * nSideMove, vForward.y * nForwardMove + vRight. y * nSideMove, 0)
	local flWishSpeed = vWishDir:Length()

	vWishDir:Normalize()

	if flWishSpeed ~= 0 and flWishSpeed > nMaxSpeed then
		flWishSpeed = nMaxSpeed
	end

	local flClampedWish = flWishSpeed

	if flClampedWish > 30 then
		flClampedWish = 30
	end

	local flCurrSpeed = vVelocity:Dot(vWishDir)
	local flAddedSpeed = flClampedWish - flCurrSpeed
	if flAddedSpeed <= 0 then
		return vVelocity
	end

	local flAcceleration = flAccelerate * flWishSpeed * TICK_INTERVAL
	if flAcceleration > flAddedSpeed then
		flAcceleration = flAddedSpeed
	end

	return vVelocity + (vWishDir * flAcceleration)
end

function C_Movement:PredictMovement( qViewAngles, nWishDir, angle )
	local pm

	local maxspeed = g_pLocalPlayer:GetMaxSpeed()
	local jump_power = g_pLocalPlayer:GetJumpPower()

	local origin = g_pLocalPlayer:GetNetworkOrigin()
	local velocity = g_pLocalPlayer:GetAbsVelocity()

	local mins, maxs = g_pLocalPlayer:GetCollisionBounds()

	local pticks = 66

	local bIsOnGround = g_pLocalPlayer:IsFlagSet(FL_ONGROUND)

	for i = 1, pticks do
		qViewAngles.y = math.NormalizeAngle(math.deg(math.atan2(velocity.y, velocity.x)) + angle)

		velocity.z = velocity.z - ( sv_gravity:GetFloat() * TICK_INTERVAL * 0.5 )

		if ( bIsOnGround ) then
			velocity.z = jump_power
			velocity.z = velocity.z - ( sv_gravity:GetFloat() * TICK_INTERVAL * 0.5 )
		end

		velocity = self:PredictVelocity( velocity, qViewAngles, nWishDir, maxspeed, sv_airaccelerate:GetFloat() )

		local endpos = origin + ( velocity * TICK_INTERVAL )

		pm = util.TraceHull( {
			start = origin,
			endpos = endpos,
			filter = g_pLocalPlayer,
			maxs = maxs,
			mins = mins,
			mask = MASK_PLAYERSOLID
		} )

		if ( ( pm.Fraction ~= 1 and pm.HitNormal.z <= 0.9 ) or pm.AllSolid or pm.StartSolid ) then
			return false
		end

		if ( pm.Fraction ~= 1 ) then
			local time_left = TICK_INTERVAL

			for j = 1, 2 do
				time_left = time_left - ( time_left * pm.Fraction )

				local dot = velocity:Dot( pm.HitNormal )

				velocity = velocity - ( pm.HitNormal * dot )

				dot = velocity:Dot( pm.HitNormal )

				if ( dot < 0 ) then
					velocity = velocity - ( pm.HitNormal * dot )
				end

				endpos = pm.HitPos + ( velocity * time_left )

				pm = util.TraceHull( {
					start = pm.HitPos,
					endpos = endpos,
					filter = g_pLocalPlayer,
					maxs = maxs,
					mins = mins,
					mask = MASK_PLAYERSOLID
				} )

				if ( pm.Fraction == 1 or pm.AllSolid or pm.StartSolid ) then
					break
				end
			end
		end

		origin = pm.HitPos

		if ( ( self.m_flLastGroundZ - origin.z ) > 10 ) then
			return false
		end

		pm = util.TraceHull( {
			start =  Vector( origin.x, origin.y, origin.z + 2 ),
			endpos = Vector( origin.x, origin.y, origin.z - 1 ),
			filter = g_pLocalPlayer,
			maxs = Vector( maxs.x, maxs.y, maxs.z * 0.5 ),
			mins = mins,
			mask = MASK_PLAYERSOLID
		} )

		bIsOnGround = ( ( pm.Fraction < 1 or pm.AllSolid or pm.StartSolid ) and pm.HitNormal.z >= 0.7 )

		velocity.z = velocity.z - ( sv_gravity:GetFloat() * TICK_INTERVAL * 0.5 )

		if ( bIsOnGround ) then
			velocity.z = 0
		end
	end

	return true
end

function C_Movement:CircleStrafe( cmd )
	local angle = 0

	while ( self.m_nCircleDir < 2 ) do
		angle = 0
		local path_found = false

		local step = ( self.m_nCircleDir == 1 ) and 1 or -1

		while ( true ) do
			if ( self.m_nCircleDir == 1 ) then -- 10
				if ( angle > 10 ) then
					break
				end
			else
				if ( angle < 10 ) then
					break
				end
			end

			if ( self:PredictMovement( cmd:GetViewAngles(), self.m_nCircleDir, angle ) ) then
				path_found = true
				break
			end

			angle = angle + step

		end

		if ( path_found ) then
			break
		end

		self.m_nCircleDir = self.m_nCircleDir + 1
	end

	if ( self.m_nCircleDir < 2 ) then
		local velocity = g_pLocalPlayer:GetAbsVelocity()

		local velocityYaw = math.NormalizeAngle(math.deg(math.atan2(velocity.y, velocity.x)))
		local yawDifference = math.NormalizeAngle(cmd:GetViewAngles().y - velocityYaw)

		cmd:SetForwardMove(10000)
		cmd:SetSideMove(0)

		if self.m_nCircleDir == 1 then
			self:RotateMovement(cmd, math.NormalizeAngle(-90 - angle + yawDifference))
		else
			self:RotateMovement(cmd, math.NormalizeAngle(90 - angle + yawDifference))
		end
	else
		self.m_nCircleDir = 0
	end
end

--[[
-- no longer adaptive but no longer SHIT
function C_Movement:CircleStrafe(pUserCmd)
	local Velocity = g_pLocalPlayer:GetVelocity()
	Velocity.z = 0

	self.m_flCircleYaw = self.m_flCircleYaw + 1

	local flSpeed = Velocity:Length()
	local flFactor = self:GetAngleFromSpeed(flSpeed)

	local turnAngle = flFactor * self.m_flCircleYaw
	if turnAngle >= 360 then
		self.m_flCircleYaw = 0
	end

	local velocityYaw = math.NormalizeAngle(math.deg(math.atan2(Velocity.x, Velocity.y)))
	local yawDifference = math.NormalizeAngle(pUserCmd:GetViewAngles().y - velocityYaw)

	pUserCmd:SetForwardMove(0x2710)
	pUserCmd:SetSideMove(0)

	if turnAngle >= 0 then
		self:RotateMovement(pUserCmd, math.NormalizeAngle(-90 - turnAngle + yawDifference))
	else
		self:RotateMovement(pUserCmd, math.NormalizeAngle(90 - turnAngle + yawDifference))
	end
end
]]

function C_Movement:GetMoveVector(pUserCmd)
	return Vector(pUserCmd:GetForwardMove(), pUserCmd:GetSideMove(), 0)
end

function C_Movement:ShouldRun()
	if g_pLocalPlayer:GetMoveType() ~= MOVETYPE_WALK then return false end
	if IsValid(g_pLocalPlayer:GetVehicle()) then return false end
	if g_pLocalPlayer:WaterLevel() >= 2 then return false end

	return true
end

function C_Movement:Run(pUserCmd)
	if not self:ShouldRun() then
		return
	end

	local bIsOnGround = g_pLocalPlayer:IsFlagSet(FL_ONGROUND)
	local bShoulsCStrafe = Config["movement_circlestrafe_enabled"] and C_Inputs:IsKeyActive(Config, "movement_circlestrafe_key")

	if bIsOnGround then
		self.m_flLastGroundZ = g_pLocalPlayer:GetNetworkOrigin().z
	end

	if bShoulsCStrafe then
		pUserCmd:AddKey(IN_JUMP)
	end

	if pUserCmd:KeyDown(IN_JUMP) then
		if Config["movement_bhop"] then
			self.m_bIsBhopping = false

			if not bIsOnGround then
				pUserCmd:RemoveKey(IN_JUMP)
				self.m_bIsBhopping = true
			elseif bIsOnGround and self.m_bWasOnGround and pUserCmd:CommandNumber() % 2 == 0 then
				pUserCmd:RemoveKey(IN_JUMP)
				self.m_bIsBhopping = true
			end

			self.m_bWasOnGround = bIsOnGround
		end

		if Config["movement_autostrafe_enabled"] and not bShoulsCStrafe and not bIsOnGround then
			self:AutoStrafe(pUserCmd)
		elseif bShoulsCStrafe and not bIsOnGround then
			self:CircleStrafe(pUserCmd)
		end
	end
end

--[[
	Triggerbot
]]

function C_TriggerBot:CacheSpreadSeeds()
	for i = 1, 128 do
		self.m_tSpreadSeeds[i] = g_tWeaponSpreadSeeds[i]
	end
end

timer.Simple(0, function()
	C_TriggerBot:CacheSpreadSeeds()
end)

function C_TriggerBot:HitChance(pUserCmd)
	if g_nChokedPackets > 1 or not C_CreateMove.m_bCanShoot then
		return
	end

	local trResult = {}
	local trData = {
		start = Vector(),
		endpos = Vector(),
		filter = g_pLocalPlayer,
		output = trResult,
		mask = MASK_SHOT
	}

	local pRayStart = trData.start
	local pRayEnd = trData.endpos

	local vSpread = C_Accuracy:GetSpreadTangent()
	local flMaxRange = C_Accuracy:GetAccuracteRange() -- Get the current weapon's Accurate Range, this is a distance at which the weapon is guaranteed to hit a 30 cm dinner plate

	local vShootPos = g_pLocalPlayer:GetShootPos()
	local qAngView = pUserCmd:GetViewAngles()

	qAngView:Add(C_Accuracy:GetRecoilAngles())
	qAngView:Normalize()

	local vViewForward = qAngView:Forward()
	local vViewRight = qAngView:Right()
	local vViewUp = qAngView:Up()

	local iHits = 0
	local arrHitEntities = {}

	pRayStart:Set(vShootPos)

	local bBadHitGroup = {
		-- [HITGROUP_LEFTARM] = true,
		-- [HITGROUP_RIGHTARM] = true,
		-- [HITGROUP_LEFTLEG] = true,
		-- [HITGROUP_RIGHTLEG] = true,
		[HITGROUP_GEAR] = true
	}

	local pSeeds = self.m_tSpreadSeeds
	local iSeeds = #pSeeds

	for iSeed, vSeed in ipairs(pSeeds) do
		local vShotDirection = vViewForward + vViewRight * vSeed.x * vSpread.x + vViewUp * vSeed.y * vSpread.y
		vShotDirection:Normalize() -- FastNormalize() -- This is theoretically not needed.

		pRayEnd:Set(pRayStart + vShotDirection * flMaxRange)

		util.TraceLine(trData)

		local NormalHitPos = trResult.HitPos + trResult.HitNormal
		debugoverlay.Line(pRayStart, NormalHitPos, 0.1, Color(255, 255, 255), true)

		-- So, no head?
		if not trResult.Hit or bBadHitGroup[trResult.HitGroup] then
			continue
		end

		local pEntity = trResult.Entity
		if not (pEntity:IsPlayer() or pEntity:IsNextBot() or pEntity:IsNPC()) or pEntity:Health() <= 0 then
			continue
		end

		local nIndex = pEntity:EntIndex()
		if not arrHitEntities[nIndex] then
			arrHitEntities[nIndex] = 0
		end

		iHits = iHits + 1
		arrHitEntities[nIndex] = arrHitEntities[nIndex] + 1
	end

	-- Not enough hitchance to hit anything, don't shoot.
	-- TODO: flHitchance * iNumProjectiles for per-pellet hitchance for shotguns?
	if (Config["hitchance_amount"] / 100) > iHits / iSeeds then
		return
	end

	-- Find the target that the bullet is most likely to hit.
	local iBestTargetId = 0
	local iBestTargetHitCount = 0
	for nIndex, iHitCount in pairs(arrHitEntities) do
		if iHitCount > iBestTargetHitCount then
			iBestTargetId = nIndex
			iBestTargetHitCount = iHitCount
		end
	end

	pUserCmd:AddKey(IN_ATTACK)
	pUserCmd:SetTickCount(TIME_TO_TICKS(GetSimulationTime(Entity(iBestTargetId))))
end

function C_TriggerBot:Run(pUserCmd)
	if not Config["triggerbot_enabled"] then return false end
	if not IsValid(g_pActiveWeapon) then return false end

	if Config["triggerbot_oncrosshair"] then
		C_TriggerBot:HitChance(pUserCmd)
	end

	local bInAttack = pUserCmd:KeyDown(IN_ATTACK) and C_CreateMove.m_bCanShoot
	if bInAttack then
		if pUserCmd:KeyDown(IN_ZOOM) then
			pUserCmd:RemoveKey(IN_ZOOM)
		end

		local strBase = GetWeaponBase(g_pActiveWeapon)
		if (strBase == "bobs" or strBase == "cw") and pUserCmd:KeyDown(IN_SPEED) then
			pUserCmd:RemoveKey(IN_SPEED)
		end

		if Config["triggerbot_forcepacket"] then
			g_bSendPacket = true
		end
	end

	if Config["triggerbot_backtrack"] then
		local vStartPos = g_pLocalPlayer:GetShootPos()
		local vDirection = g_pLocalPlayer:EyeAngles():Forward()

		if pUserCmd:GetInWorldClicker() then
			vDirection = pUserCmd:GetWorldClickerAngles()
		end

		vDirection:Mul(0x7FFF)

		local trResult = LagCompensation:BacktrackTraceLine(vStartPos, vDirection)

		if trResult.HitBacktrack and LagCompensation:IsTickValid(trResult.BacktrackRecord.m_flSimulationTime) and bInAttack then
			local ply = trResult.Entity
			LagCompensation:BacktrackPlayer(pUserCmd, ply, trResult.BacktrackRecord)
		end
	end

	if IsValid(g_pActiveWeapon) and g_pActiveWeapon:Clip1() ~= -1 and g_pActiveWeapon:Clip1() <= 0 and g_pActiveWeapon:GetNextPrimaryFire() < C_CreateMove.m_flServerTime and g_pActiveWeapon.strClass ~= "weapon_physgun" and not pUserCmd:KeyDown(IN_RELOAD) and not g_pActiveWeapon.IsTFAWeapon then
		pUserCmd:RemoveKey(bit.bor(IN_ATTACK, IN_ATTACK2))
		pUserCmd:AddKey(IN_RELOAD)
	end
end

--[[
	Config System
]]

function C_ConfigManager:Init()
	if not (file.Exists("jackson", "DATA") and file.IsDir("jackson", "DATA")) then
		file.CreateDir("jackson")
	end

	if not (file.Exists("jackson/config", "DATA") and file.IsDir("jackson/config", "DATA")) then
		file.CreateDir("jackson/config")
	end
end

function C_ConfigManager:Deserialize(rawdata)
	return util.JSONToTable(rawdata, false)
end

function C_ConfigManager:DeleteConfig(name)
	file.Delete(string.format("%s/%s%s", "jackson/config", name, ".json"))
end

function C_ConfigManager:LoadConfig(name)
	if not (isstring(name) and string.Trim(name) ~= "") then return false end

	if not file.Exists(string.format("%s/%s%s", "jackson/config", name, ".json"), "DATA") then
		return false
	end

	local data = self:Deserialize(file.Read(string.format("%s/%s%s", "jackson/config", name, ".json")), "DATA")
	if not data then return false end

	self.m_strCurrConfigName = name
	table.Merge(self.m_pCurrConfig, data)

	return true
end

function C_ConfigManager:SaveConfig(name, data, bSavingCurrent)
	local rawdata = util.TableToJSON(data)
	if not rawdata then return false end

	file.Write(string.format("%s/%s%s", "jackson/config", name, ".json"), rawdata)

	if not file.Exists(string.format("%s/%s%s", "jackson/config", name, ".json"), "DATA") then return false end

	return true
end

function C_ConfigManager:GetAutoloadName()
	local strAutoloadFileName = string.format("%s/autoload.txt", "jackson/config")

	if file.Exists(strAutoloadFileName, "DATA") and not file.IsDir(strAutoloadFileName, "DATA") then
		return file.Read(strAutoloadFileName, "DATA")
	end
end

function C_ConfigManager:RefreshConfigList()
	g_pConfigList:Clear()

	local cfgs = file.Find(string.format("%s/*%s", "jackson/config", ".json"), "DATA")
	local strAutoLoadName = self:GetAutoloadName()

	for _, strConfigFilename in ipairs(cfgs) do
		local strConfigName = string.StripExtension(strConfigFilename)
		local iFileTime = file.Time(string.format("%s/%s", "jackson/config", strConfigFilename), "DATA")
		local bIsAutoload = strAutoLoadName == strConfigName

		local line = g_pConfigList:AddLine(bIsAutoload and "Yes" or "", strConfigName, os.date("%m/%d/%Y %H:%M %p", iFileTime))
		line.m_strConfigName = strConfigName
		line.m_bIsAutoload = bIsAutoload
		line.m_bIsLoaded = strConfigName == self.m_strCurrConfigName
	end
end

function C_ConfigManager:MarkAsAutoload(name)
	if not (isstring(name) and string.Trim(name) ~= "") then return false end

	file.Write(string.format("%s/autoload.txt", "jackson/config"), string.Trim(name))

	return true
end

C_ConfigManager:Init()

timer.Simple(0, function()
	C_ConfigManager:LoadConfig(C_ConfigManager:GetAutoloadName())
end)

--[[
	World Editor/LuaBSP
]]

enum("LUMP", {
	"ENTITIES",					   --  0; Map entities
	"PLANES",						 --  1; Plane array
	"TEXDATA",						--  2; Index to texture names
	"VERTEXES",					   --  3; Vertex array
	"VISIBILITY",					 --  4; Compressed visibility bit arrays
	"NODES",						  --  5; BSP tree nodes
	"TEXINFO",						--  6; Face texture array
	"FACES",						  --  7; Face array
	"LIGHTING",					   --  8; Lightmap samples
	"OCCLUSION",					  --  9; Occlusion polygons and vertices
	"LEAFS",						  -- 10; BSP tree leaf nodes
	"FACEIDS",						-- 11; Correlates between dfaces and Hammer face IDs. Also used as random seed for detail prop placement.
	"EDGES",						  -- 12; Edge array
	"SURFEDGES",					  -- 13; Index of edges
	"MODELS",						 -- 14; Brush models (geometry of brush entities)
	"WORLDLIGHTS",					-- 15; Internal world lights converted from the entity lump
	"LEAFFACES",					  -- 16; Index to faces in each leaf
	"LEAFBRUSHES",					-- 17; Index to brushes in each leaf
	"BRUSHES",						-- 18; Brush array
	"BRUSHSIDES",					 -- 19; Brushside array
	"AREAS",						  -- 20; Area array
	"AREAPORTALS",					-- 21; Portals between areas
	"UNUSED0",						-- 22; Unused
	"UNUSED1",						-- 23; Unused
	"UNUSED2",						-- 24; Unused
	"UNUSED3",						-- 25; Unused
	"DISPINFO",					   -- 26; Displacement surface array
	"ORIGINALFACES",				  -- 27; Brush faces array before splitting
	"PHYSDISP",					   -- 28; Displacement physics collision data
	"PHYSCOLLIDE",					-- 29; Physics collision data
	"VERTNORMALS",					-- 30; Face plane normals
	"VERTNORMALINDICES",			  -- 31; Face plane normal index array
	"DISP_LIGHTMAP_ALPHAS",		   -- 32; Displacement lightmap alphas (unused/empty since Source 2006)
	"DISP_VERTS",					 -- 33; Vertices of displacement surface meshes
	"DISP_LIGHTMAP_SAMPLE_POSITIONS", -- 34; Displacement lightmap sample positions
	"GAME_LUMP",					  -- 35; Game-specific data lump
	"LEAFWATERDATA",				  -- 36; Data for leaf nodes that are inside water
	"PRIMITIVES",					 -- 37; Water polygon data
	"PRIMVERTS",					  -- 38; Water polygon vertices
	"PRIMINDICES",					-- 39; Water polygon vertex index array
	"PAKFILE",						-- 40; Embedded uncompressed Zip-format file
	"CLIPPORTALVERTS",				-- 41; Clipped portal polygon vertices
	"CUBEMAPS",					   -- 42; env_cubemap location array
	"TEXDATA_STRING_DATA",			-- 43; Texture name data
	"TEXDATA_STRING_TABLE",		   -- 44; Index array into texdata string data
	"OVERLAYS",					   -- 45; info_overlay data array
	"LEAFMINDISTTOWATER",			 -- 46; Distance from leaves to water
	"FACE_MACRO_TEXTURE_INFO",		-- 47; Macro texture info for faces
	"DISP_TRIS",					  -- 48; Displacement surface triangles
	"PHYSCOLLIDESURFACE",			 -- 49; Compressed win32-specific Havok terrain surface collision data. Deprecated and no longer used.
	"WATEROVERLAYS",				  -- 50; info_overlay's on water faces?
	"LEAF_AMBIENT_INDEX_HDR",		 -- 51; Index of LUMP_LEAF_AMBIENT_LIGHTING_HDR
	"LEAF_AMBIENT_INDEX",			 -- 52; Index of LUMP_LEAF_AMBIENT_LIGHTING
	"LIGHTING_HDR",				   -- 53; HDR lightmap samples
	"WORLDLIGHTS_HDR",				-- 54; Internal HDR world lights converted from the entity lump
	"LEAF_AMBIENT_LIGHTING_HDR",	  -- 55; HDR related leaf lighting data?
	"LEAF_AMBIENT_LIGHTING",		  -- 56; HDR related leaf lighting data?
	"XZIPPAKFILE",					-- 57; XZip version of pak file for Xbox. Deprecated.
	"FACES_HDR",					  -- 58; HDR maps may have different face data
	"MAP_FLAGS",					  -- 59; Extended level-wide flags. Not present in all levels.
	"OVERLAY_FADES",				  -- 60; Fade distances for overlays
	"OVERLAY_SYSTEM_LEVELS",		  -- 61; System level settings (min/max CPU & GPU to render this overlay)
	"PHYSLEVEL",					  -- 62;
	"DISP_MULTIBLEND",				-- 63; Displacement multiblend info
})

local SourceSkyname = GetConVar("sv_skyname"):GetString()
local SourceSkyPre = {"lf", "ft", "rt", "bk", "dn", "up"}
local SourceSkyMat = {
	Material("skybox/" .. SourceSkyname .. "lf"),
	Material("skybox/" .. SourceSkyname .. "ft"),
	Material("skybox/" .. SourceSkyname .. "rt"),
	Material("skybox/" .. SourceSkyname .. "bk"),
	Material("skybox/" .. SourceSkyname .. "dn"),
	Material("skybox/" .. SourceSkyname .. "up")
}

do
	local HEADER_LUMPS = 64

	local function unsigned( val, length )
		local val = val
		if val < 0 then
			val = val + 2^(length * 8)
		end
		return val
	end

	local lump_parsers = {
		[LUMP_ENTITIES] = -- Map entities
			function(fl, lump_data)
				lump_data.data = {}
				local keyvals =  fl:Read( lump_data.filelen-1 ) -- Ignore last character (NUL)
				for v in keyvals:gmatch("({.-})") do
					local data = util.KeyValuesToTable( "_" .. v )
					--[[
					for k, v in pairs( data ) do
						if entity_datatypes[k] == "Vector" then
							data[k] = Vector(str2numbers(v))
						elseif entity_datatypes[k] == "Angle" then
							data[k] = Angle(str2numbers(v))
						elseif entity_datatypes[k] == "Color" then
							data[k] = Color(str2numbers(v))
						end
					end]]
					lump_data.data[#lump_data.data + 1] = data
				end
			end,
		[LUMP_PLANES] = -- Plane array
			function(fl, lump_data)
				lump_data.data = {}
				lump_data.size = lump_data.filelen / 20

				for i = 0, lump_data.size - 1 do
					lump_data.data[i] = {
						A = fl:ReadFloat(),				-- float | normal vector x component
						B = fl:ReadFloat(),				-- float | normal vector y component
						C = fl:ReadFloat(),				-- float | normal vector z component
						D = fl:ReadFloat(),				-- float | distance from origin
						type = fl:ReadLong(), -- int | plane axis identifier
					}
				end
			end,
		[LUMP_TEXDATA] = -- Index to texture names
			function(fl, lump_data)
				lump_data.data = {}
				lump_data.size = lump_data.filelen / 32
				for i = 0, lump_data.size - 1 do
					lump_data.data[i] = {
						reflectivity = Vector( fl:ReadFloat(), fl:ReadFloat(), fl:ReadFloat() ),
						nameStringTableID = fl:ReadLong(),
						width = fl:ReadLong(),
						height = fl:ReadLong(),
						view_width = fl:ReadLong(),
						view_height = fl:ReadLong(),
					}
				end
			end,
		[LUMP_VERTEXES] = -- Vertex array
			function(fl, lump_data)
				lump_data.data = {}
				lump_data.size = lump_data.filelen / 12
				for i = 0, lump_data.size - 1 do
					lump_data.data[i] = Vector(
						fl:ReadFloat(), -- float | x
						fl:ReadFloat(), -- float | y
						fl:ReadFloat()  -- float | z
					)
				end
			end,
		[LUMP_VISIBILITY] = -- Compressed visibility bit arrays
			function(fl, lump_data) end,
		[LUMP_NODES] = -- BSP tree nodes
			function(fl, lump_data) end,
		[LUMP_TEXINFO] = -- Face texture array
			function(fl, lump_data)
				lump_data.data = {}
				lump_data.size = lump_data.filelen / 72
				for i = 0, lump_data.size - 1 do
					lump_data.data[i] = {
						textureVecs = {
							{ x = fl:ReadFloat(), y = fl:ReadFloat(), z = fl:ReadFloat(), offset = fl:ReadFloat()},
							{ x = fl:ReadFloat(), y = fl:ReadFloat(), z = fl:ReadFloat(), offset = fl:ReadFloat()},
						},
						lightmapVecs = {
							{ x = fl:ReadFloat(), y = fl:ReadFloat(), z = fl:ReadFloat(), offset = fl:ReadFloat()},
							{ x = fl:ReadFloat(), y = fl:ReadFloat(), z = fl:ReadFloat(), offset = fl:ReadFloat()},
						},
						flags = fl:ReadLong(),
						textdata = fl:ReadLong(),
					}
				end
			end,
		[LUMP_FACES] = -- Face array
			function(fl, lump_data)
				lump_data.data = {}
				lump_data.size = lump_data.filelen / 56
				for i = 0, lump_data.size - 1 do
					lump_data.data[i] = {
						planenum = unsigned( fl:ReadShort(), 2 ),						 -- unsigned short | the plane number
						side = fl:ReadByte(),							  -- byte | faces opposite to the node's plane direction
						onNode = fl:ReadByte(),							-- byte | 1 of on node, 0 if in leaf
						firstedge = fl:ReadLong(),			-- int | index into surfedges
						numedges = fl:ReadShort(),			-- short | number of surfedges
						texinfo = fl:ReadShort(),			 -- short | texture info
						dispinfo = fl:ReadShort(),			-- short | displacement info
						surfaceFogVolumeID = fl:ReadShort(),  -- short | ?
						styles = {										 -- byte[4] | switchable lighting info
							fl:ReadByte(),
							fl:ReadByte(),
							fl:ReadByte(),
							fl:ReadByte(),
						},
						lightofs = fl:ReadLong(),			 -- int | offset into lightmap lump
						area = fl:ReadFloat(),							 -- float | face area in units^2
						LightmapTextureMinsInLuxels = {					-- int[2] | texture lighting info
							fl:ReadLong(),
							fl:ReadLong(),
						},
						LightmapTextureSizeInLuxels = {					-- int[2] | texture lighting info
							fl:ReadLong(),
							fl:ReadLong(),
						},
						origFace = fl:ReadLong(),			 -- int | original face this was split from
						numPrims = unsigned( fl:ReadShort(), 2 ),						 -- unsigned short | primitives
						firstPrimID = unsigned( fl:ReadShort(), 2 ),					  -- unsigned short
						smoothingGroups = unsigned( fl:ReadLong(), 4 ),				   -- unsigned int | lightmap smoothing group
					}
				end
			end,
		[LUMP_LIGHTING] = -- Lightmap samples
			function(fl, lump_data) end,
		[LUMP_OCCLUSION] = -- Occlusion polygons and vertices
			function(fl, lump_data) end,
		[LUMP_LEAFS] = -- BSP tree leaf nodes
			function(fl, lump_data) end,
		[LUMP_FACEIDS] = -- Correlates between dfaces and Hammer face IDs. Also used as random seed for detail prop placement.
			function(fl, lump_data) end,
		[LUMP_EDGES] = -- Edge array
			function(fl, lump_data)
				lump_data.data = {}
				lump_data.size = lump_data.filelen / 4
				for i = 0, lump_data.size - 1 do
					lump_data.data[i] = {
						unsigned( fl:ReadShort(), 2 ), -- unsigned short | vertex indice 1
						unsigned( fl:ReadShort(), 2 ), -- unsigned short | vertex indice 2
					}
				end
			end,
		[LUMP_SURFEDGES] = -- Index of edges
			function(fl, lump_data)
				lump_data.data = {}
				lump_data.size = lump_data.filelen / 4
				for i = 0, lump_data.size - 1 do
					lump_data.data[i] = fl:ReadLong()
				end
			end,
		[LUMP_MODELS] = -- Brush models (geometry of brush entities)
			function(fl, lump_data) end,
		[LUMP_WORLDLIGHTS] = -- Internal world lights converted from the entity lump
			function(fl, lump_data) end,
		[LUMP_LEAFFACES] = -- Index to faces in each leaf
			function(fl, lump_data) end,
		[LUMP_LEAFBRUSHES] = -- Index to brushes in each leaf
			function(fl, lump_data) end,
		[LUMP_BRUSHES] = -- Brush array
			function(fl, lump_data)
				lump_data.data = {}
				lump_data.size = lump_data.filelen / 12
				for i = 0, lump_data.size - 1 do
					lump_data.data[i] = {
						firstside = fl:ReadLong(),  -- int | first brushside
						numsides = fl:ReadLong(),   -- int | number of brushsides
						contents = fl:ReadLong(),   -- int | content flags
					}
				end
			end,
		[LUMP_BRUSHSIDES] = -- Brushside array
			function(fl, lump_data)
				lump_data.data = {}
				lump_data.size = lump_data.filelen / 8
				for i = 0, lump_data.size - 1 do
					lump_data.data[i] = {
						planenum = unsigned( fl:ReadShort(), 2 ),			 -- unsigned short | facing out of the leaf
						texinfo =  fl:ReadShort(),  -- short | texture info
						dispinfo = fl:ReadShort(), -- short | displacement info
						bevel = fl:ReadShort(),	-- short | is the side a bevel plane?
					}
				end
			end,
		[LUMP_AREAS] = -- Area array
			function(fl, lump_data) end,
		[LUMP_AREAPORTALS] = -- Portals between areas
			function(fl, lump_data) end,
		[LUMP_UNUSED0] = -- Unused
			function(fl, lump_data) end,
		[LUMP_UNUSED1] = -- Unused
			function(fl, lump_data) end,
		[LUMP_UNUSED2] = -- Unused
			function(fl, lump_data) end,
		[LUMP_UNUSED3] = -- Unused
			function(fl, lump_data) end,
		[LUMP_DISPINFO] = -- Displacement surface array
			function(fl, lump_data) end,
		[LUMP_ORIGINALFACES] = -- Brush faces array before splitting
			function(fl, lump_data)
				lump_parsers[LUMP_FACES]( fl, lump_data )
			end,
		[LUMP_PHYSDISP] = -- Displacement physics collision data
			function(fl, lump_data) end,
		[LUMP_PHYSCOLLIDE] = -- Physics collision data
			function(fl, lump_data) end,
		[LUMP_VERTNORMALS] = -- Face plane normals
			function(fl, lump_data) end,
		[LUMP_VERTNORMALINDICES] = -- Face plane normal index array
			function(fl, lump_data) end,
		[LUMP_DISP_LIGHTMAP_ALPHAS] = -- Displacement lightmap alphas (unused/empty since Source 2006)
			function(fl, lump_data) end,
		[LUMP_DISP_VERTS] = -- Vertices of displacement surface meshes
			function(fl, lump_data) end,
		[LUMP_DISP_LIGHTMAP_SAMPLE_POSITIONS] = -- Displacement lightmap sample positions
			function(fl, lump_data) end,
		[LUMP_GAME_LUMP] = -- Game-specific data lump
			function(fl, lump_data)
				lump_data.data = {}
				lump_data.size = fl:ReadLong()
				for i = 1,lump_data.size do
					lump_data.data[i] = {
						id	  = fl:Read( 4 ),
						flags   = fl:ReadShort(),
						version = fl:ReadShort(),
						fileofs = fl:ReadLong(),
						filelen = fl:ReadLong(),
					}
				end
			end,
		[LUMP_LEAFWATERDATA] = -- Data for leaf nodes that are inside water
			function(fl, lump_data) end,
		[LUMP_PRIMITIVES] = -- Water polygon data
			function(fl, lump_data) end,
		[LUMP_PRIMVERTS] = -- Water polygon vertices
			function(fl, lump_data) end,
		[LUMP_PRIMINDICES] = -- Water polygon vertex index array
			function(fl, lump_data) end,
		[LUMP_PAKFILE] = -- Embedded uncompressed Zip-format file
			function(fl, lump_data) end,
		[LUMP_CLIPPORTALVERTS] = -- Clipped portal polygon vertices
			function(fl, lump_data) end,
		[LUMP_CUBEMAPS] = -- env_cubemap location array
			function(fl, lump_data)
				lump_data.data = {}
				lump_data.size = lump_data.filelen / 16

				for i = 0, lump_data.size - 1 do
					local origin = Vector(fl:ReadLong(), fl:ReadLong(), fl:ReadLong())
					local size = fl:ReadLong()

					if size < 1 then size = 6 end -- default size should be 32x32

					lump_data.data[i] = {
						origin = origin,
						size = 2^(size-1)
					}
				end
			end,
		[LUMP_TEXDATA_STRING_DATA] = -- Texture name data
			function(fl, lump_data)
				lump_data.data = {}
				local data = string.Explode( "\0", fl:Read(lump_data.filelen) )
				local offset = 0
				for k, v in pairs(data) do
					lump_data.data[offset] = v
					offset = offset + 1 +  #v
				end
			end,
		[LUMP_TEXDATA_STRING_TABLE] = -- Index array into texdata string data
			function(fl, lump_data)
				lump_data.data = {}
				lump_data.size = lump_data.filelen / 4
				for i = 0, lump_data.size - 1 do
					lump_data.data[i] = fl:ReadLong()
				end
			end,
		[LUMP_OVERLAYS] = -- info_overlay data array
			function(fl, lump_data) end,
		[LUMP_LEAFMINDISTTOWATER] = -- Distance from leaves to water
			function(fl, lump_data) end,
		[LUMP_FACE_MACRO_TEXTURE_INFO] = -- Macro texture info for faces
			function(fl, lump_data) end,
		[LUMP_DISP_TRIS] = -- Displacement surface triangles
			function(fl, lump_data) end,
		[LUMP_PHYSCOLLIDESURFACE] = -- Compressed win32-specific Havok terrain surface collision data. Deprecated and no longer used.
			function(fl, lump_data) end,
		[LUMP_WATEROVERLAYS] = -- info_overlay's on water faces?
			function(fl, lump_data) end,
		[LUMP_LEAF_AMBIENT_INDEX_HDR] = -- Index of LUMP_LEAF_AMBIENT_LIGHTING_HDR
			function(fl, lump_data) end,
		[LUMP_LEAF_AMBIENT_INDEX] = -- Index of LUMP_LEAF_AMBIENT_LIGHTING
			function(fl, lump_data) end,
		[LUMP_LIGHTING_HDR] = -- HDR lightmap samples
			function(fl, lump_data) end,
		[LUMP_WORLDLIGHTS_HDR] = -- Internal HDR world lights converted from the entity lump
			function(fl, lump_data) end,
		[LUMP_LEAF_AMBIENT_LIGHTING_HDR] = -- HDR related leaf lighting data?
			function(fl, lump_data) end,
		[LUMP_LEAF_AMBIENT_LIGHTING] = -- HDR related leaf lighting data?
			function(fl, lump_data) end,
		[LUMP_XZIPPAKFILE] = -- XZip version of pak file for Xbox. Deprecated.
			function(fl, lump_data) end,
		[LUMP_FACES_HDR] = -- HDR maps may have different face data
			function(fl, lump_data) end,
		[LUMP_MAP_FLAGS] = -- Extended level-wide flags. Not present in all levels.
			function(fl, lump_data) end,
		[LUMP_OVERLAY_FADES] = -- Fade distances for overlays
			function(fl, lump_data) end,
		[LUMP_OVERLAY_SYSTEM_LEVELS] = -- System level settings (min/max CPU & GPU to render this overlay)
			function(fl, lump_data) end,
		[LUMP_PHYSLEVEL] = --
			function(fl, lump_data) end,
		[LUMP_DISP_MULTIBLEND] = -- Displacement multiblend info
			function(fl, lump_data) end,
	}

	local LuaBSP = {}
	LuaBSP.__index = LuaBSP

	function LuaBSP:GetMapFileHandle( mapname )
		self.mapname = mapname or self.mapname
		local filename = "maps/" .. self.mapname .. ".bsp"
		local fl = file.Open( filename, "rb", "GAME")
		if not fl then error( "[LuaBSP] Unable to open: " .. filename ) end

		return fl
	end

	function LuaBSP.new( mapname )
		assert( mapname, "[LuaBSP] Invalid map name" )

		local this = setmetatable({}, LuaBSP)
		local fl = this:GetMapFileHandle( mapname )

		local ident = fl:Read( 4 ) -- BSP file identifier
		if ident ~= "VBSP" then error( "[LuaBSP] Invalid file header: " .. ident ) return end

		this.version = fl:ReadLong() -- BSP file version
		this.lumps = {} -- lump directory array

		for i = 0, HEADER_LUMPS-1 do
			this.lumps[i] = {
				fileofs = fl:ReadLong(), -- offset into file (bytes)
				filelen = fl:ReadLong(), -- length of lump (bytes)
				version = fl:ReadLong(), -- lump format version
				fourCC  = fl:Read( 4 ),  -- lump ident code
			}
		end
		this.map_revision = fl:ReadLong() -- the map's revision (iteration, version) number

		--[[
		for i=0, HEADER_LUMPS-1 do
			local lump_data = this.lumps[i]
			fl:Seek( lump_data.fileofs )
			lump_parsers[i]( fl, lump_data )
		end
		]]

		fl:Close()

		return this
	end

	function LuaBSP:LoadLumps( ... )
		local fl = self:GetMapFileHandle()

		for k, lump in ipairs( {...} ) do
			local lump_data = self.lumps[lump]
			fl:Seek( lump_data.fileofs )
			lump_parsers[lump]( fl, lump_data )
		end

		fl:Close()
	end

	function LuaBSP:LoadStaticProps()
		self:LoadLumps( LUMP_GAME_LUMP )

		local fl   = self:GetMapFileHandle()
		local lump = self.lumps[LUMP_GAME_LUMP]

		local static_props = {}
		for _,game_lump in ipairs( lump.data ) do
			local version = game_lump.version
			local static_props_entry = {
				names		= {},
				leaf		 = {},
				leaf_entries = 0,
				entries	  = {},
			}

			if not (version >= 4 and version < 12) then continue end

			fl:Seek( game_lump.fileofs )

			local dict_entries = fl:ReadLong()
			if dict_entries < 0 or dict_entries >= 9999 then continue end

			for i = 1,dict_entries do
				static_props_entry.names[i-1] = fl:Read( 128 ):match( "^[^%z]+" ) or ""
			end

			local leaf_entries = fl:ReadLong()
			if leaf_entries < 0 then continue end

			static_props_entry.leaf_entries = leaf_entries
			for i = 1,leaf_entries do
				static_props_entry.leaf[i] = fl:ReadUShort()
			end

			local amount = fl:ReadLong()
			if amount < 0 or amount >= ( 8192 * 2 ) then continue end

			for i = 1,amount do
				local static_prop = {}
				static_props_entry.entries[i] = static_prop

				static_prop.Origin = Vector( fl:ReadFloat(), fl:ReadFloat(), fl:ReadFloat() )
				static_prop.Angles = Angle( fl:ReadFloat(), fl:ReadFloat(), fl:ReadFloat() )

				if version >= 11 then
					static_prop.Scale = fl:ReadShort()
				end

				local _1,_2 = string.byte(fl:Read(2),1,2)
				local proptype = _1 + _2 * 256

				static_prop.PropType = static_props_entry.names[proptype]
				if not static_prop.PropType then continue end

				static_prop.FirstLeaf = fl:ReadShort()
				static_prop.LeafCount = fl:ReadShort()
				static_prop.Solid	 = fl:ReadByte()
				static_prop.Flags	 = fl:ReadByte()
				static_prop.Skin	  = fl:ReadLong()
				if not static_prop.Skin then continue end

				static_prop.FadeMinDist	= fl:ReadFloat()
				static_prop.FadeMaxDist	= fl:ReadFloat()
				static_prop.LightingOrigin = Vector( fl:ReadFloat(), fl:ReadFloat(), fl:ReadFloat() )

				if version >= 5 then
					static_prop.ForcedFadeScale = fl:ReadFloat()
				end

				if version == 6 or version == 7 then
					static_prop.MinDXLevel = fl:ReadShort()
					static_prop.MaxDXLevel = fl:ReadShort()
				end

				if version >= 8 then
					static_prop.MinCPULevel = fl:ReadByte()
					static_prop.MaxCPULevel = fl:ReadByte()
					static_prop.MinGPULevel = fl:ReadByte()
					static_prop.MaxGPULevel = fl:ReadByte()
				end

				if version >= 7 then
					static_prop.DiffuseModulation = Color( string.byte( fl:Read( 4 ), 1, 4 ) )
				end

				if version >= 10 then
					static_prop.unknown = fl:ReadFloat()
				end

				if version == 9 then
					static_prop.DisableX360 = fl:ReadByte() == 1
				end

			end

			table.insert( static_props, static_props_entry )
		end

		self.static_props = static_props

		fl:Close()
	end

	function LuaBSP:GetMaterials()
		self:LoadLumps( LUMP_TEXDATA_STRING_DATA )

		local lump = self.lumps[LUMP_TEXDATA_STRING_DATA]
		local materials = {}

		for k, v in next, lump.data do
			table.insert(materials, v)
		end

		return materials
	end

	g_tMapData.m_tBSP = LuaBSP.new(game.GetMap())

	g_tMapData.m_tFound = g_tMapData.m_tBSP:GetMaterials()
	g_tMapData.m_tBSP:LoadStaticProps()

	for k,v in pairs(g_tMapData.m_tFound) do
		if v:find("water/") then
			g_tMapData.m_tFound[k] = nil
			continue
		end
	end
end

local function ChangeSkybox(skyboxname)
	if (skyboxname == "default") then
		skyboxname = SourceSkyname
	end

	for i = 1, 6 do
		local Hello = Material("skybox/" .. skyboxname .. SourceSkyPre[i]):GetTexture("$basetexture")
		SourceSkyMat[i]:SetTexture("$basetexture", Hello)
	end
end

local function SetWorldColor(col, g, b, a)
	if istable(col) then
		col = Color(col.r, col.g, col.b, col.a)
	end

	if isnumber(col) then
		col = Color(col,g,b,a)
	end

	for k,v in next, g_tMapData.m_tFound do
		local pMaterial = Material(v)
		if not pMaterial then
			continue
		end

		pMaterial:SetVector("$color", col:ToVector())
	end
end

--[[
	Setup Menu
]]

do
	local tKnownEntityClasses = {}
	local tEntityClasses = {}
	local skybox_cache = {}

	do
		local BlacklistedEntityClasses = { -- Don't show anywhere
			player = true,
			worldspawn = true,
			viewmodel = true
		}

		for k, _ in pairs(scripted_ents.GetList()) do
			if not tKnownEntityClasses[k] and not BlacklistedEntityClasses[k] then
				tKnownEntityClasses[k] = true
			end
		end

		for _, v in ipairs(ents.GetAll()) do
			local Class = v:GetClass()
			if not tKnownEntityClasses[Class] and not BlacklistedEntityClasses[Class] then
				tKnownEntityClasses[Class] = true
			end
		end

		AddHook("NetworkEntityCreated", function(pEntity)
			local Class = pEntity:GetClass()
			if not tKnownEntityClasses[Class] and not BlacklistedEntityClasses[Class] then
				tKnownEntityClasses[Class] = true
			end
		end)
	end

	local function CopyColor(color)
		if not color then
			return error("No Color Provided")
		end

		return Color(color.r, color.g, color.b, color.a)
	end

	local function CustomDermaMenu( parentmenu, parent )
		if not parentmenu then
			CloseDermaMenus()
		end

		local dmenu = vgui.Create( "DMenu", parent )

		function dmenu:Paint(w, h)
			surface.SetDrawColor(Config["menucolors"].background)
			surface.DrawRect(0, 0, w, h)

			surface.SetDrawColor(Config["menucolors"].outline)
			surface.DrawOutlinedRect(0, 0, w, h)
		end

		function dmenu:AddOption( strText, funcFunction )
			local pnl = vgui.Create( "DMenuOption", self )
			pnl:SetMenu( self )
			pnl:SetText( strText )

			if ( funcFunction ) then
				pnl.DoClick = funcFunction
			end

			self:AddPanel( pnl )

			return pnl
		end

		return dmenu
	end

	do
		local Frame = vgui.Create("DFrame")
		Frame:SetSize(550, 370)
		Frame:Center()
		Frame:SetTitle("")
		Frame:SetVisible(false)
		Frame:SetDeleteOnClose(false)
		Frame:ShowCloseButton(false)
		Frame:SetSizable(false)

		local CloseButton = vgui.Create("DButton", Frame) -- Custom close button
		CloseButton:SetSize(22, 22)
		CloseButton:SetPos(Frame:GetWide() - CloseButton:GetWide(), 0)
		CloseButton:SetTextColor(color_white)
		CloseButton:SetText("X")

		Frame.m_pCloseButton = CloseButton

		function CloseButton:DoClick()
			Frame:Close()
		end

		function CloseButton:Paint(w, h)
			surface.SetDrawColor(color_red)
			surface.DrawRect(0, 0, w, h)

			surface.SetDrawColor(Config["menucolors"].outline)
			surface.DrawOutlinedRect(0, 0, w, h)
		end

		function Frame:Paint(w, h)
			self.m_pCloseButton:SetPos(w - self.m_pCloseButton:GetWide(), 0)
			surface.SetDrawColor(Config["menucolors"].background)
			surface.DrawRect(0, 0, w, h)

			surface.SetDrawColor(Config["menucolors"].outline)
			surface.DrawOutlinedRect(0, 0, w, h)

			surface.SetFont("jackson_font")
			surface.SetTextColor(color_white)

			local title = "Zenith"

			local tw, th = surface.GetTextSize(title)

			surface.SetTextPos((w / 2) - (tw / 2), 14 - (th / 2)) -- Not perfectly proportional to the real FlowHook's menu because of the Close Button
			surface.DrawText(title)
		end

		do -- all the custom elements (this do is just to organize)
			function Frame:AddSection(Panel, X, Y, Height, Width, Label)
				local Section = vgui.Create("DPanel", Panel)
				Section:SetPos(X, Y)
				Section:SetSize(Height, Width)
				Section:SetVisible(true)

				function Section:Paint(w, h)
					local vCurrColor = Config["menucolors"].section
					surface.SetDrawColor(vCurrColor.r, vCurrColor.g, vCurrColor.b, 255)
					surface.DrawRect(0, 5, w, h)

					surface.SetFont("jackson_font")
					surface.SetTextColor(color_white)

					local tw, th = surface.GetTextSize(Label)
					local tx, ty = 8, 5 - (th / 2)

					surface.SetTextPos(tx, ty)
					surface.DrawText(Label)

					w = w - 1
					h = h - 1
					ty = ty + (th / 2)

					surface.SetDrawColor(Config["menucolors"].outline)
					surface.DrawLine(0, ty, tx, ty)
					surface.DrawLine(tx + tw, ty, w, ty)
					surface.DrawLine(w, ty, w, h)
					surface.DrawLine(w, h, 0, h)
					surface.DrawLine(0, h, 0, ty)
				end

				return Section
			end

			function Frame:AddCheckbox(Panel, X, Y, Label, Table, Key)
				local Checkbox = vgui.Create("DCheckBoxLabel", Panel)

				Checkbox.m_tTable = Table
				Checkbox.m_strKey = Key
				Checkbox.m_flLastThink = 0

				Checkbox:SetTextColor(color_white)
				Checkbox:SetFont("jackson_font")
				Checkbox:SetText(Label)
				Checkbox:SetPos(X, Y)
				Checkbox:SetChecked(tobool(Table[Key]))

				function Checkbox:Think()
					if CurTime() - self.m_flLastThink >= 0.3 then
						self:SetChecked(self.m_tTable[self.m_strKey])
						self.m_flLastThink = CurTime()
					end
				end

				function Checkbox:OnChange(NewValue)
					self.m_tTable[self.m_strKey] = NewValue
				end

				function Checkbox.Button:Paint(w, h)
					local menucolor = Config["menucolors"].object

					surface.SetDrawColor(Config["menucolors"].object_background)
					surface.DrawRect(0, 0, w, h)

					if self:GetChecked() then
						surface.SetDrawColor(menucolor)
						surface.DrawRect(2, 2, w - 4, h - 4)
					end

					surface.SetDrawColor(color_grey)
					surface.DrawOutlinedRect(0, 0, w, h)
				end

				return Checkbox
			end

			function Frame:AddSlider(Panel, X, Y, Wide, Label, Min, Max, Decimals, Table, Key)
				local Slider = vgui.Create("DNumSlider", Panel)
				Slider:SetDark(true)
				Slider:SetPos(X, Y)
				Slider:SetMinMax(Min, Max)
				Slider:SetSize(20, 20)
				Slider:SetWide(Wide)
				Slider:SetDecimals(Decimals)

				Slider.m_tTable = Table
				Slider.m_strKey = Key

				timer.Simple(0, function()
					Slider:SetValue(Table[Key])
				end)

				Slider.Label:SetVisible(false)

				local NewLabel = vgui.Create("DLabel", Slider) -- Custom label to fix retarded spacing
				NewLabel:Dock(LEFT)
				NewLabel:SetFont("jackson_font")
				NewLabel:SetText(Label)
				NewLabel:SetTextColor(color_white)
				NewLabel:SetSize(surface.GetTextSize(Label))

				function Slider:OnValueChanged(NewValue)
					self.m_tTable[self.m_strKey] = NewValue
				end

				function Slider:OnMouseWheeled(delta)
					local step = self:GetDecimals() == 0 and 1 or 0.1

					if delta > 0 then
						self:SetValue(self:GetValue() + step)
					elseif delta < 0 then
						self:SetValue(self:GetValue() - step)
					end
				end

				local textArea = Slider:GetTextArea()
				function textArea:Paint(w, h)
				end

				local bar = Slider:GetChildren()[2]
				local handle = bar:GetChildren()[1]

				function handle:Paint(w, h) -- Paint bar handle
				end

				function bar:Paint(w, h) -- Paint custom horizontal bar
					local y = (h / 2) - 7.5
					h = 15

					surface.SetDrawColor(Config["menucolors"].object_background)
					surface.DrawRect(0, y, w, h)

					surface.SetDrawColor(Config["menucolors"].object)

					local sizeX = (w - 1) * (Slider:GetValue() - Slider:GetMin()) / (Slider:GetMax() - Slider:GetMin())
					surface.DrawRect(1, y, sizeX, h)

					surface.SetFont("jackson_font")
					surface.SetTextColor(color_white)

					local val = math.Round(Slider:GetValue() or 0, Slider:GetDecimals())
					local tw, th = surface.GetTextSize(val)

					surface.SetTextPos((w / 2) - (tw / 2), y + (h / 2) - (th / 2))
					surface.DrawText(val)

					surface.SetDrawColor(color_grey)
					surface.DrawOutlinedRect(0, y, w, h)
				end

				return Slider
			end

			function Frame:AddComboBox(Panel, X, Y, Width, Height, Label, Table, Key, Data)
				local ComboBox = vgui.Create("DComboBox", Panel)
				ComboBox:SetSize(Width, Height)
				ComboBox:SetPos(X, Y)
				ComboBox:SetValue(Label)

				ComboBox.m_tTable = Table
				ComboBox.m_strKey = Key

				ComboBox:SetTextColor(color_white)

				ComboBox:GetChildren()[1].Paint = function() end

				function ComboBox:Paint(w, h)
					surface.SetDrawColor(Config["menucolors"].object_background)
					surface.DrawRect(0, 0, w, h)

					surface.SetDrawColor(color_grey)
					surface.DrawOutlinedRect(0, 0, w, h)

					surface.SetDrawColor(Config["menucolors"].outline)

					if self:IsMenuOpen() then
						surface.DrawLine((w - h) + 4, h / 2, w - 4, h / 2)
					else
						surface.DrawLine(w - (h / 2), 4, w - (h / 2), h - 4)
						surface.DrawLine((w - h) + 4, h / 2, w - 4, h / 2)
					end
				end

				for k, v in pairs(Data) do
					ComboBox:AddChoice(k, v)
				end

				function ComboBox:OnSelect(_, _, value)
					self.m_tTable[self.m_strKey] = value
				end

				return ComboBox
			end

			function Frame:AddBinder(Panel, X, Y, Width, Height, Table, Key)
				local Binder = vgui.Create("DBinder", Panel)
				Binder:SetPos(X, Y)
				Binder:SetSize(Width, Height)

				timer.Simple(0, function()
					Binder:SetValue(Table[Key])
				end)

				Binder.m_tTable = Table
				Binder.m_strKey = Key

				function Binder:Paint(w, h)
					surface.SetDrawColor(Config["menucolors"].object_background)
					surface.DrawRect(0, 0, w, h)

					surface.SetDrawColor(color_grey)
					surface.DrawOutlinedRect(0, 0, w, h)
				end

				function Binder:OnChange(NewValue)
					self.m_tTable[self.m_strKey] = NewValue

					if not Config["bindtogglemodes"][Key] then
						Config["bindtogglemodes"][Key] = BIND_METHOD_HELD
					end
				end

				function Binder:DoRightClick()
					local menu = CustomDermaMenu()

					local pKeyCode = self.m_tTable[self.m_strKey]

					menu:AddOption("Toggle", function()
						Config["bindtogglemodes"][Key] = BIND_METHOD_TOGGLE
					end):SetChecked(Config["bindtogglemodes"][Key] == BIND_METHOD_TOGGLE)

					menu:AddOption("Hold", function()
						Config["bindtogglemodes"][Key] = BIND_METHOD_HELD
					end):SetChecked(Config["bindtogglemodes"][Key] == BIND_METHOD_HELD)

					menu:Open()
				end

				return Binder
			end

			function Frame:AddColorbox(Panel, X, Y, Width, Height, Label, Table, Key)
				local Colorbox = vgui.Create("DButton", Panel)
				Colorbox:SetPos(X, Y)
				Colorbox:SetSize(Width, Height)
				Colorbox:SetText("")

				Colorbox.m_tTable = Table
				Colorbox.m_strKey = Key

				function Colorbox:Paint(w, h)
					surface.SetDrawColor(color_black)
					surface.DrawRect(0, 0, w, h)

					surface.SetDrawColor(self.m_tTable[self.m_strKey])
					surface.DrawRect(1, 1, w - 2, h - 2)

					surface.SetDrawColor(color_grey)
					surface.DrawOutlinedRect(0, 0, w, h)

					--if isstring(Label) then
					--	surface.SetFont("jackson_font")
					--	surface.SetTextColor(color_white)
					--
					--	local tw, th = surface.GetTextSize(Label)
					--	local y = (h / 2) - 7.5
					--
					--	surface.SetTextPos((w / 2) - (tw / 2), y + (h / 2) - (th / 2))
					--	surface.DrawText(Label)
					--end
				end

				function Colorbox:DoClick()
					local ScreenX, ScreenY = self:LocalToScreen(0, 0)

					local ColorPanel = vgui.Create("DPanel")
					ColorPanel:SetSize(190, 130)
					ColorPanel:DockPadding(4, 4, 4, 4)
					ColorPanel:SetPos(ScreenX, ScreenY + self:GetTall() + 5)
					ColorPanel:MakePopup()

					function ColorPanel:PerformLayout()
						function self:Think()
							if not self:HasFocus() then
								self:Remove()
							end
						end
					end

					function ColorPanel:Paint(w, h)
						surface.SetDrawColor(Config["menucolors"].background)
						surface.DrawRect(1, 1, w - 2, h - 2)

						surface.SetDrawColor(Config["menucolors"].outline)
						surface.DrawOutlinedRect(0, 0, w, h)
					end

					ColorPanel:InvalidateLayout()

					local Mixer = vgui.Create("DColorMixer", ColorPanel)
					Mixer:Dock(FILL)
					Mixer:SetPalette(false)
					Mixer:SetWangs(false)
					Mixer:SetColor(self.m_tTable[self.m_strKey])

					Mixer.m_tTable = self.m_tTable
					Mixer.m_strKey = self.m_strKey

					function Mixer:ValueChanged(NewColor)
						debug.setmetatable(NewColor, _R.Color)
						self.m_tTable[self.m_strKey] = NewColor
					end
				end

				return Colorbox
			end

			function Frame:AddButton(Panel, X, Y, Width, Height, Label, CallBack)
				local Button = vgui.Create("DButton", Panel)
				Button:SetPos(X, Y)
				Button:SetSize(Width, Height)
				Button:SetText("")

				function Button:Paint(w, h)
					local y = (h / 2) - 7.5
					h = 15

					surface.SetDrawColor(Config["menucolors"].object_background)
					surface.DrawRect(0, 0, w, h)

					if not self:IsDown() then
						surface.SetDrawColor(Config["menucolors"].object)
						surface.DrawRect(0, 0, w, h)
					end

					surface.SetFont("jackson_font")
					surface.SetTextColor(color_white)

					local val = Label
					local tw, th = surface.GetTextSize(val)

					surface.SetTextPos((w / 2) - (tw / 2), y + (h / 2) - (th / 2))
					surface.DrawText(val)

					surface.SetDrawColor(color_grey)
					surface.DrawOutlinedRect(0, 0, w, h)
				end

				if not isfunction(CallBack) then
					return
				end

				function Button:DoClick()
					CallBack()
				end
			end
		end

		Frame.m_pTabs = vgui.Create("DPropertySheet", Frame)
		Frame.m_pTabs.m_fFadeTime = 0
		Frame.m_pTabs:Dock(FILL)

		Frame.m_pTabs:SetFadeTime(0)

		if Frame.m_pTabs.tabScroller then
			Frame.m_pTabs.tabScroller:DockMargin(0, 0, 0, 0)
			Frame.m_pTabs.tabScroller:SetOverlap(0)
		end

		function Frame.m_pTabs:Paint(w, h)
			surface.SetDrawColor(Config["menucolors"].section)
			surface.DrawRect(0, 0, w, h)

			surface.SetDrawColor(Config["menucolors"].outline)
			surface.DrawOutlinedRect(0, 20, w, h - 20)
		end

		function Frame.m_pTabs:AddSheet(label, panel, material, NoStretchX, NoStretchY, Tooltip)
			if not IsValid(panel) then
				ErrorNoHalt( "DPropertySheet:AddSheet tried to add invalid panel!" )
				debug.Trace()
				return
			end

			local Sheet = {}

			Sheet.Name = label

			Sheet.Tab = vgui.Create( "DTab", self )
			Sheet.Tab:SetTooltip( Tooltip )
			Sheet.Tab:Setup( label, self, panel, material )

			function Sheet.Tab:ApplySchemeSettings()
				local LeftMargin, TopMargin, RightMargin, BottomMargin = Frame.m_pTabs.tabScroller:GetDockMargin()

				self:SetContentAlignment(8)

				self:SetSize((Frame.m_pTabs:GetWide() - LeftMargin) / #Frame.m_pTabs:GetItems(), self:GetTabHeight())
			end

			Sheet.Panel = panel
			Sheet.Panel.NoStretchX = NoStretchX
			Sheet.Panel.NoStretchY = NoStretchY
			Sheet.Panel:SetPos( self:GetPadding(), 20 + self:GetPadding() )
			Sheet.Panel:SetVisible( false )

			function Sheet.Panel:Paint(w, h)
				surface.SetDrawColor(Config["menucolors"].section)
				surface.DrawRect(0, 0, w, h)
			end

			panel:SetParent( self )

			table.insert( self.Items, Sheet )

			if not self:GetActiveTab() then
				self:SetActiveTab(Sheet.Tab)
				Sheet.Panel:SetVisible(true)
			end

			self.tabScroller:AddPanel(Sheet.Tab)

			function Sheet.Tab:Paint(w, h)
				h = 21

				if self:IsActive() then
					surface.SetDrawColor(Config["menucolors"].section)
				else
					surface.SetDrawColor(Config["menucolors"].background)
				end

				surface.DrawRect(0, 0, w, h)

				surface.SetDrawColor(Config["menucolors"].outline)
				surface.DrawOutlinedRect(0, 0, w + 1, h)
			end

			return Sheet
		end

		function Frame:MakePanel(Scroll)
			local Panel = vgui.Create(Scroll and "DScrollPanel" or "DPanel")

			Panel.m_tMenuItems = {}
			Panel.m_bScroll = Scroll

			if Scroll then
				Panel:SetPaintBackgroundEnabled(true)
				Panel:SetPaintBorderEnabled(true)
				Panel:SetPaintBackground(true)

				local pListChildren = Panel:GetChildren()
				local scrollbar = pListChildren[2]
				function scrollbar:Paint(w, h)
					surface.SetDrawColor(Config["menucolors"].section)
					surface.DrawRect(0, 0, w, h)
				end

				for _, v in ipairs(scrollbar:GetChildren()) do
					v.Paint = function(_, w, h)
						surface.SetDrawColor(Config["menucolors"].object_background)
						surface.DrawRect(0, 0, w, h)

						surface.SetDrawColor(Config["menucolors"].outline)
						surface.DrawOutlinedRect(0, 0, w, h)
					end
				end

				function Panel:Rebuild() -- Add extra padding
					self.pnlCanvas:SizeToChildren(false, true)
					self.pnlCanvas:SetTall(self.pnlCanvas:GetTall() + 10)

					if self.m_bNoSizing and self.pnlCanvas:GetTall() < self:GetTall() then
						self.pnlCanvas.x = 0
						self.pnlCanvas.y = (self:GetTall() - self.pnlCanvas:GetTall()) / 2
					end
				end

				function Panel:PerformLayout(Width, Height)
					self:PerformLayoutInternal(Width, Height)
				end

				function Panel:PerformLayoutInternal(Width, Height) -- Fix retarded bug with resizing
					Width = (Width or self:GetWide()) - (self.VBar.Enabled and self.VBar:GetWide() or 0) -- These shouldn't need to be here but sometimes they're nil
					Height = Height or self:GetTall()

					self:Rebuild()

					self.VBar:SetUp(Height, self.pnlCanvas:GetTall())

					self.pnlCanvas.x = 0
					self.pnlCanvas.y = self.VBar:GetOffset()
					self.pnlCanvas:SetWide(Width)

					self:Rebuild()

					if Height ~= self.pnlCanvas:GetTall() then
						self.VBar:SetScroll(self.VBar:GetScroll())
					end
				end
			end

			Panel.m_fPerformLayout = Panel.PerformLayout
			function Panel:PerformLayout(Width, Height)
				if self.m_fPerformLayout then
					self:m_fPerformLayout(Width, Height)
				end
			end

			return Panel
		end

		function Frame:AddTab(Name, Setup, Scrollable)
			local Panel = self:MakePanel(Scrollable)

			self.m_pTabs:AddSheet(Name, Panel)

			if isfunction(Setup) then Setup(Panel) end

			return Panel
		end

		Frame:AddTab("Aimbot", function(Panel)
			local pAimSection = Frame:AddSection(Panel, 5, 5, 240, 130, "Aimbot")
			Frame:AddCheckbox(pAimSection, 20, 20, "Enabled", Config, "ragebot_enabled")
			Frame:AddCheckbox(pAimSection, 40, 40, "Silent Aim", Config, "ragebot_silent")
			Frame:AddCheckbox(pAimSection, 40, 60, "Use Context", Config, "ragebot_usecontext")
			Frame:AddCheckbox(pAimSection, 40, 80, "Slow-Fire", Config, "slowshoot_enabled")
			Frame:AddSlider(pAimSection, 40, 100, 180, "Slow-Time", 0, 3, 1, Config, "slowshoot_time")
			Frame:AddBinder(pAimSection, 120, 20, 60, 14, Config, "ragebot_key")
			Frame:AddComboBox(pAimSection, 140, 40, 80, 18, "Hitbox", Config, "ragebot_hitbox", {
				["Head"] = HITGROUP_HEAD,
				["Chest"] = HITGROUP_CHEST,
				["Stomach"] = HITGROUP_STOMACH,
				["Arms"] = HITGROUP_LEFTARM,
				["Legs"] = HITGROUP_RIGHTLEG
			})
			Frame:AddCheckbox(pAimSection, 140, 60, "Multi-Point", Config, "ragebot_multipoint")
			Frame:AddCheckbox(pAimSection, 140, 80, "Aim-Line", Config, "aimline_enabled")
			Frame:AddColorbox(pAimSection, 215, 80, 15, 15, nil, Config, "aimline_color")

			local pAccuracySection = Frame:AddSection(Panel, 250, 5, 240, 110, "Accuracy")
			Frame:AddCheckbox(pAccuracySection, 20, 20, "NoSpread", Config, "nospread_enabled")
			Frame:AddCheckbox(pAccuracySection, 20, 40, "Use Context", Config, "nospread_usecontext")
			Frame:AddCheckbox(pAccuracySection, 20, 60, "Force Seed", Config, "forceseed_enabled")
			Frame:AddSlider(pAccuracySection, 115, 60, 160, "Seed", 0, 255, 0, Config, "forceseed_seed")

			Frame:AddCheckbox(pAccuracySection, 20, 80, "Hit-Chance", Config, "hitchance_enabled")
			Frame:AddSlider(pAccuracySection, 115, 80, 160, "Amount", 0, 100, 0, Config, "hitchance_amount")
			Frame:AddCheckbox(pAccuracySection, 140, 20, "No Recoil", Config, "accuracy_norecoil")
			Frame:AddCheckbox(pAccuracySection, 140, 40, "Resolver", Config, "accuarcy_resolver")

			local pTargetAdjustmentSection = Frame:AddSection(Panel, 5, 135, 240, 110, "Adjust Targeting")
			Frame:AddCheckbox(pTargetAdjustmentSection, 20, 20, "Ignore Players", Config, "ragebot_ignoreplayers")
			Frame:AddCheckbox(pTargetAdjustmentSection, 20, 40, "Ignore NPCS", Config, "ragebot_ignorenpcs")
			Frame:AddCheckbox(pTargetAdjustmentSection, 20, 60, "Ignore Next-Bots", Config, "ragebot_ignorenextbots")
			Frame:AddComboBox(pTargetAdjustmentSection, 20, 80, 80, 18, "Sort Method", Config, "ragebot_sortmethod", {
				["Crosshair"] = SORT_TYPE_CROSSHAIR,
				["Health"] = SORT_TYPE_HEALTH,
				["Distance"] = SORT_TYPE_DISTANCE
			})

			Frame:AddCheckbox(pTargetAdjustmentSection, 140, 20, "Aim-Cone", Config, "aimcone_enaled")
			Frame:AddSlider(pTargetAdjustmentSection, 140, 37, 135, "FOV", 0, 72, 0, Config, "aimcone_fov")
			Frame:AddComboBox(pTargetAdjustmentSection, 140, 60, 90, 18, "Shape", Config, "aimcone_shape", {
				["Circle"] = AIMCONE_SHAPE_CIRCLE,
				["Sqaure"] = AIMCONE_SHAPE_SQUARE,
				["Triangle"] = AIMCONE_SHAPE_TRIANGLE,
				["Rhombus"] = AIMCONE_SHAPE_RHOMBUS
			})
			Frame:AddColorbox(pTargetAdjustmentSection, 140, 80, 90, 15, nil, Config, "aimcone_color")

			local pLagCompSection = Frame:AddSection(Panel, 250, 115, 260, 70, "Lag Compensation")
			Frame:AddCheckbox(pLagCompSection, 20, 20, "Backtrack", Config, "backtrack_enabled")
			Frame:AddCheckbox(pLagCompSection, 110, 20, "Abuse-Interp", Config, "backtrack_abuseinterp")
			Frame:AddSlider(pLagCompSection, 20, 40, 180, "Amount", 0, 1, 1, Config, "backtrack_amount")
			Frame:AddComboBox(pLagCompSection, 160, 40, 80, 18, "Method", Config, "backtrack_method", {
				["First"] = BACKTRACK_METHOD_FIRST,
				["Last"] = BACKTRACK_METHOD_LAST
			})

			local pTriggerBotSection = Frame:AddSection(Panel, 250, 185, 240, 90, "TriggerBot")
			Frame:AddCheckbox(pTriggerBotSection, 20, 20, "Enabled", Config, "triggerbot_enabled")
			Frame:AddCheckbox(pTriggerBotSection, 40, 40, "Force-Packet", Config, "triggerbot_forcepacket")
			Frame:AddCheckbox(pTriggerBotSection, 40, 60, "On-Crosshair", Config, "triggerbot_oncrosshair")
			Frame:AddCheckbox(pTriggerBotSection, 140, 40, "Auto-Wall", Config, "triggerbot_autowall")
			Frame:AddCheckbox(pTriggerBotSection, 140, 60, "Hit-Backtrack", Config, "triggerbot_backtrack")
		end)

		Frame:AddTab("HvH", function(Panel)
			local pAntiAimSection = Frame:AddSection(Panel, 5, 5, 495, 140, "Anti Aim")
			Frame:AddCheckbox(pAntiAimSection, 20, 20, "Enabled", Config, "antiaim_enabled")
			Frame:AddComboBox(pAntiAimSection, 40, 40, 80, 18, "Pitch", Config, "antiaim_pitch", {
				["None"] = ANTIAIM_X_NONE,
				["Up"] = ANTIAIM_X_UP,
				["Down"] = ANTIAIM_X_DOWN,
				["Jitter"] = ANTIAIM_X_DANCE,
				["Front"] = ANTIAIM_X_FRONT,
				["Custom"] = ANTIAIM_X_CUSTOM,
				--["Fake Up"] = ANTIAIM_X_UP_FAKE,
				["Fake Down"] = ANTIAIM_X_DOWN_FAKE,
				["Fake Zero Down"] = ANTIAIM_X_FAKE_ZERO_DOWN
			})
			Frame:AddComboBox(pAntiAimSection, 40, 60, 80, 18, "Yaw", Config, "antiaim_yaw", {
				["None"] = ANTIAIM_Y_NONE,
				["Spin"] = ANTIAIM_Y_SPINBOT,
				["Jitter"] = ANTIAIM_Y_JITTER,
				["Jitter Side"] = ANTIAIM_Y_JITTER_SIDE,
				["Backwards"] = ANTIAIM_Y_BACKWARDS,
				["LBY"] = ANTIAIM_Y_LBY,
				["Fake Forwards"] = ANTIAIM_Y_FAKE_FORWARDS,
				["Fake Sideways"] = ANTIAIM_Y_FAKE_SIDEWAYS,
				["Custom"] = ANTIAIM_Y_CUSTOM
			})
			Frame:AddComboBox(pAntiAimSection, 122, 60, 80, 18, "Base Yaw", Config, "antiaim_baseyaw", {
				["Forwards"] = ANTIAIM_BASE_Y_FORWARDS,
				["Backwards"] = ANTIAIM_BASE_Y_BACKWARDS,
				["Left"] = ANTIAIM_BASE_Y_LEFT,
				["Right"] = ANTIAIM_BASE_Y_RIGHT,
				["Aimbot Target"] = ANTIAIM_BASE_Y_AIMBOT_TARGET,
				["Static"] = ANTIAIM_BASE_Y_STATIC
			})
			Frame:AddCheckbox(pAntiAimSection, 122, 40, "Clamp", Config, "antiaim_clamp")

			Frame:AddCheckbox(pAntiAimSection, 40, 80, "Edge", Config, "antiaim_edge")

			--Frame:AddCheckbox(pAntiAimSection, 122, 120, "LBY Breaker", Config.LbyBreaker, "Enabled")

			Frame:AddSlider(pAntiAimSection, 210, 10, 275, "Pitch", -90, 90, 0, Config, "antiaim_custompitch")
			Frame:AddSlider(pAntiAimSection, 210, 30, 275, "Real Yaw", -180, 180, 0, Config, "antiaim_customyaw")
			Frame:AddSlider(pAntiAimSection, 210, 50, 275, "Fake Yaw", -180, 180, 0, Config, "antiaim_customfake")
			--Frame:AddSlider(pAntiAimSection, 210, 110, 275, "Breaker Delta", -90, 90, 0, Config.LbyBreaker, "Delta")
			Frame:AddSlider(pAntiAimSection, 210, 70, 275, "Spin Speed", 0, 150, 0, Config, "antiaim_spinspeed")

			local pFakeLagSection = Frame:AddSection(Panel, 5, 145, 210, 90, "Fake Lag")
			Frame:AddCheckbox(pFakeLagSection, 20, 20, "Enabled", Config, "fakelag_enabled")
			Frame:AddSlider(pFakeLagSection, 40, 40, 200, "Choke", 0, 21, 0, Config, "fakelag_choke")
			Frame:AddComboBox(pFakeLagSection, 40, 60, 80, 18, "FL Method", Config, "fakelag_method", {
				["Static"] = FAKELAG_METHOD_STATIC,
				["Adaptive"] = FAKELAG_METHOD_ADAPTIVE,
				["Random"] = FAKELAG_METHOD_RANDOM
			})

			local pFakeDuckSection = Frame:AddSection(Panel, 220, 145, 120, 90, "Fake Duck")
			Frame:AddCheckbox(pFakeDuckSection, 20, 20, "Enabled", Config, "fakeduck_enabled")
			Frame:AddBinder(pFakeDuckSection, 20, 40, 80, 20, Config, "fakeduck_key")

			local pFakeActSection = Frame:AddSection(Panel, 345, 145, 155, 90, "Fake Act")
			Frame:AddCheckbox(pFakeActSection, 20, 20, "Enabled", Config, "fakeact_enabled")
			Frame:AddComboBox(pFakeActSection, 40, 40, 80, 18, "Gesture", Config, "fakeact_gesture", {
				["Agree"] =  "agree",
				["Becon"] =  "becon",
				["Bow"] =  "bow",
				["Cheer"] =  "cheer",
				["Dance"] =  "dance",
				["Disagree"] =  "disagree",
				["Group"] =  "group",
				["Forward"] =  "forward",
				["Halt"] =  "halt",
				["Laugh"] =  "laugh",
				["Muscle"] =  "muscle",
				["Pose"] =  "pose",
				["Robot"] =  "robot",
				["Salute"] =  "salute",
				["Wave"] =  "wave",
				["Zombie"] = "zombie"
			})
		end,  true)

		Frame:AddTab("Visuals", function(Panel)
			local pPlayerSection = Frame:AddSection(Panel, 5, 5, 210, 150, "Player ESP")
			Frame:AddCheckbox(pPlayerSection, 20, 20, "Enabled", Config, "playeresp_enabled")

			Frame:AddCheckbox(pPlayerSection, 110, 40, "Name", Config, "playeresp_name")
			Frame:AddCheckbox(pPlayerSection, 110, 60, "Health", Config, "playeresp_health")
			Frame:AddCheckbox(pPlayerSection, 110, 80, "Armor", Config, "playeresp_armor")
			Frame:AddCheckbox(pPlayerSection, 110, 100, "Weapon", Config, "playeresp_weapon")
			Frame:AddCheckbox(pPlayerSection, 110, 120, "Outline", Config, "playeresp_outline")
			Frame:AddColorbox(pPlayerSection, 180, 120, 15, 15, nil, Config, "playeresp_outline_color")

			Frame:AddCheckbox(pPlayerSection, 40, 40, "2D Box", Config, "playeresp_box2d")
			Frame:AddCheckbox(pPlayerSection, 40, 60, "3D Box", Config, "playeresp_box3d")
			Frame:AddCheckbox(pPlayerSection, 40, 80, "Skeleton", Config, "playeresp_skeleton")
			Frame:AddCheckbox(pPlayerSection, 40, 100, "Avatar", Config, "playeresp_avatar")
			Frame:AddCheckbox(pPlayerSection, 40, 120, "Barrel", Config, "playeresp_barrel")

			-- player chams
			local pChamSection = Frame:AddSection(Panel, 220, 5, 285, 110, "Player Chams")
			Frame:AddCheckbox(pChamSection, 20, 20, "Enabled", Config, "playerchams_enabled")
			local tblChamMaterials = {
				["Flat"] = "flat",
				["Glow"] = "glow",
				["Metallic"] = "metallic",
				["Wireframe"] = "wireframe",
				["Fireframe"] = "fireframe",
				["Pulseframe"] = "pulseframe",
				["IslandWater"] = "islandwater",
				["islandframe"] = "islandframe"
			}

			Frame:AddCheckbox(pChamSection, 40, 40, "Occluded", Config, "playerchams_occluded_enabled")
			Frame:AddColorbox(pChamSection, 40, 60, 75, 18, nil, Config, "playerchams_occluded_color")
			Frame:AddComboBox(pChamSection, 40, 80, 75, 18, "Material", Config, "playerchams_occluded_material", tblChamMaterials)

			Frame:AddCheckbox(pChamSection, 120, 40, "Visible", Config, "playerchams_visible_enabled")
			Frame:AddColorbox(pChamSection, 120, 60, 75, 18, nil, Config, "playerchams_visible_color")
			Frame:AddComboBox(pChamSection, 120, 80, 75, 18, "Material", Config, "playerchams_visible_material", tblChamMaterials)

			Frame:AddCheckbox(pChamSection, 200, 40, "Overlay", Config, "playerchams_overlay_enabled")
			Frame:AddColorbox(pChamSection, 200, 60, 75, 18, nil, Config, "playerchams_overlay_color")
			Frame:AddComboBox(pChamSection, 200, 80, 75, 18, "Material", Config, "playerchams_overlay_material", tblChamMaterials)


			local pEntitySection = Frame:AddSection(Panel, 5, 155, 210, 130, "Entity ESP")
			Frame:AddCheckbox(pEntitySection, 20, 20, "Enabled", Config, "entityesp_enabled")
			Frame:AddCheckbox(pEntitySection, 40, 40, "Name", Config, "entityesp_name")
			Frame:AddCheckbox(pEntitySection, 40, 60, "Health", Config, "entityesp_health")
			Frame:AddCheckbox(pEntitySection, 40, 80, "Armor", Config, "entityesp_armor")
			Frame:AddCheckbox(pEntitySection, 40, 100, "Weapon", Config, "entityesp_weapon")

			Frame:AddCheckbox(pEntitySection, 110, 40, "2D Box", Config, "entityesp_box2d")
			Frame:AddCheckbox(pEntitySection, 110, 60, "3D Box", Config, "entityesp_box3d")
			Frame:AddCheckbox(pEntitySection, 110, 80, "Skeleton", Config, "entityesp_skeleton")
			Frame:AddCheckbox(pEntitySection, 110, 100, "Outline", Config, "entityesp_outline")
			Frame:AddColorbox(pEntitySection, 180, 100, 15, 15, nil, Config, "entityesp_outline_color")

			local pEntChamSection = Frame:AddSection(Panel, 220, 115, 285, 110, "Entity Chams")
			Frame:AddCheckbox(pEntChamSection, 20, 20, "Enabled", Config, "entitychams_enabled")

			Frame:AddCheckbox(pEntChamSection, 40, 40, "Occluded", Config, "entitychams_occluded_enabled")
			Frame:AddColorbox(pEntChamSection, 40, 60, 75, 18, nil, Config, "entitychams_occluded_color")
			Frame:AddComboBox(pEntChamSection, 40, 80, 75, 18, "Material", Config, "entitychams_occluded_material", tblChamMaterials)

			Frame:AddCheckbox(pEntChamSection, 120, 40, "Visible", Config, "entitychams_visible_enabled")
			Frame:AddColorbox(pEntChamSection, 120, 60, 75, 18, nil, Config, "entitychams_visible_color")
			Frame:AddComboBox(pEntChamSection, 120, 80, 75, 18, "Material", Config, "entitychams_visible_material", tblChamMaterials)

			Frame:AddCheckbox(pEntChamSection, 200, 40, "Overlay", Config, "entitychams_overlay_enabled")
			Frame:AddColorbox(pEntChamSection, 200, 60, 75, 18, nil, Config, "entitychams_overlay_color")
			Frame:AddComboBox(pEntChamSection, 200, 80, 75, 18, "Material", Config, "entitychams_overlay_material", tblChamMaterials)

			local pVMChamSection = Frame:AddSection(Panel, 220, 225, 285, 110, "Viewmodel Chams")
			Frame:AddCheckbox(pVMChamSection, 20, 20, "Enabled", Config, "viewmodelchams_enabled")

			Frame:AddCheckbox(pVMChamSection, 40, 40, "Hands", Config, "viewmodelchams_hands_enabled")
			Frame:AddColorbox(pVMChamSection, 40, 60, 75, 18, nil, Config, "viewmodelchams_hands_color")
			Frame:AddComboBox(pVMChamSection, 40, 80, 75, 18, "Material", Config, "viewmodelchams_hands_material", tblChamMaterials)

			Frame:AddCheckbox(pVMChamSection, 120, 40, "Arms", Config, "viewmodelchams_arms_enabled")
			Frame:AddColorbox(pVMChamSection, 120, 60, 75, 18, nil, Config, "viewmodelchams_arms_color")
			Frame:AddComboBox(pVMChamSection, 120, 80, 75, 18, "Material", Config, "viewmodelchams_arms_material", tblChamMaterials)

			--[[
			local pTracerSection = Frame:AddSection(Panel, 305, 245, 200, 90, "Bullet-Tracers")
			Frame:AddCheckbox(pTracerSection, 20, 20, "Enabled", Config, "bullettracers_enabled")
			Frame:AddComboBox(pTracerSection, 20, 40, 80, 18, "Material", Config, "bullettracers_material", {
				["PhysBeam"] = "sprites/physbeam",
				["Laser"] = "trails/laser",
				["RollerMine"] = "sprites/rollermine_shock",
				["Electric"] = "trails/electric",
				["LOL"] = "trails/lol",
				["Hearts"] = "trails/love",
				["HydraSpine"] = "sprites/hydraspinalcord"
			})
			Frame:AddSlider(pTracerSection, 20, 60, 170, "Die-Time", 0, 10, 0, Config, "bullettracers_dietime")
			]]

			local pWorldEditSection = Frame:AddSection(Panel, 5, 285, 210, 65, "World Editor")
			Frame:AddCheckbox(pWorldEditSection, 20, 20, "Custom Skybox", Config, "customskybox_enabled")
			Frame:AddButton(pWorldEditSection, 130, 20, 65, 15, "Skyboxes", function()
				local fs = file.Find("materials/skybox/*", "GAME")

				local list = CustomDermaMenu()

				for _, v in ipairs(fs) do
					local name = string.StripExtension(v)
					if not name:find("ft$") then continue end
					name = name:Trim():gsub("ft$", "")

					-- skip if error
					local mat = skybox_cache[name] or Material("skybox/" .. name .. "ft")
					if mat:IsError() then continue end

					-- skip hdr/ldr as a lot of them show as errors or are redundant
					if name:find("_?hdr_?$") then continue end
					if name:find("_ldr$") then continue end

					if skybox_cache[name] then continue end

					skybox_cache[name] = Material("skybox/" .. name .. "ft")
				end

				for name in SortedPairs(skybox_cache) do
					local opt = list:AddOption(name, function()
						-- LConfigManager:SetConfigVar("misc.skybox", name)
						Config["customskybox_skybox"] = name
					end)

					opt:SetIcon("skybox/" .. name .. "ft")
					opt.m_Image:SetSize(16, 16)

					opt.m_Image.oldPaint = opt.m_Image.oldPaint or opt.m_Image.Paint
					opt.m_Image.Paint = function(img, w, h)
						img:PaintAt( 0, 0, img:GetWide(), img:GetTall() )

						if opt:IsHovered() then
							DisableClipping(true)
							img:PaintAt(-264, -128, 256, 256)
							DisableClipping(false)
						end
					end
				end

				list:Open()
			end)
			Frame:AddCheckbox(pWorldEditSection, 20, 40, "World Colors", Config, "worldcolors_enabled")
			Frame:AddColorbox(pWorldEditSection, 130, 40, 65, 15, nil, Config, "worldcolor_color")

			local VisualBacktrackSection = Frame:AddSection(Panel, 220, 335, 200, 90, "Visualize Backtrack")
			Frame:AddCheckbox(VisualBacktrackSection, 20, 20, "Enabled", Config, "backtrack_visuals_enabled")
			Frame:AddComboBox(VisualBacktrackSection, 20, 40, 80, 18, "Style", Config, "backtrack_visuals_visualstyle", {
				["Hitbox"] = BACKTRACK_VISUAL_STYLE_HITBOX,
				["Chams"] = BACKTRACK_VISUAL_STYLE_CHAM,
			})
			Frame:AddColorbox(VisualBacktrackSection, 20, 60, 80, 18, nil, Config, "backtrack_visuals_startcolor")
			Frame:AddColorbox(VisualBacktrackSection, 110, 60, 80, 18, nil, Config, "backtrack_visuals_endcolor")

			local pMiscSection = Frame:AddSection(Panel, 5, 350, 210, 110, "Misc")
			Frame:AddCheckbox(pMiscSection, 20, 20, "Show HitBoxes", Config, "hitboxes_enabled")
			Frame:AddCheckbox(pMiscSection, 20, 40, "Anti-Aim Lines", Config, "misc_antiaimlines")
			Frame:AddCheckbox(pMiscSection, 20, 60, "Draw Spread-Cone", Config, "misc_drawspreadcone")
			Frame:AddCheckbox(pMiscSection, 20, 80, "Debug Info", Config, "misc_debuginfo")
		end, true)

		Frame:AddTab("Miscellaneous", function(Panel)
			local pMovementSection = Frame:AddSection(Panel, 5, 5, 240, 90, "Movement")
			Frame:AddCheckbox(pMovementSection, 20, 20, "Bunny Hop", Config, "movement_bhop")
			Frame:AddCheckbox(pMovementSection, 20, 40, "Auto Strafe", Config, "movement_autostrafe_enabled")
			Frame:AddComboBox(pMovementSection, 20, 60, 80, 18, "AS-Mode", Config, "movement_autostrafe_mode", {
				["Legit"] = AUTOSTRAFE_MODE_LEGIT,
				["Rage"] = AUTOSTRAFE_MODE_RAGE,
				["Directonal"] = AUTOSTRAFE_MODE_DIRECTIONAL
			})

			Frame:AddCheckbox(pMovementSection, 110, 20, "Circle Strafe", Config, "movement_circlestrafe_enabled")
			Frame:AddBinder(pMovementSection, 110, 40, 80, 14, Config, "movement_circlestrafe_key")

			local pThirdPersonSection = Frame:AddSection(Panel, 5, 95, 240, 70, "Third-Person")
			Frame:AddCheckbox(pThirdPersonSection, 20, 20, "Enabled", Config, "thirdperson_enabled")
			Frame:AddBinder(pThirdPersonSection, 160, 20, 70, 16, Config, "thirdperson_key")
			Frame:AddSlider(pThirdPersonSection, 20, 40, 210, "Camera Distance", 0, 500, 0, Config, "thirdperson_distance")

			local pFreezeSection = Frame:AddSection(Panel, 5, 165, 120, 90, "Net Channel Manip")
			Frame:AddCheckbox(pFreezeSection, 20, 20, "Double Tap", Config, "sequencefreeze_doubletap")
			Frame:AddCheckbox(pFreezeSection, 20, 40, "Teleport", Config, "sequencefreeze_teleport_enabled")
			Frame:AddBinder(pFreezeSection, 20, 60, 70, 16, Config, "sequencefreeze_teleport_key")

			local pConfigSection = Frame:AddSection(Panel, 250, 5, 250, 160, "Config")
			do
				local ConfigList = vgui.Create("DListView", pConfigSection)
				ConfigList:Dock(FILL)
				ConfigList:SetMultiSelect(false)
				ConfigList:SetSortable(true)

				local oldAddColumn = ConfigList.AddColumn
				local oldAddLine = ConfigList.AddLine

				ConfigList.AddColumn = function(self, name, pos) -- Override default AddColumn
					if not name then
						return error("No Column Name Provided")
					end

					if pos and (pos <= 0 or self.Columns[pos]) then
						return error("Tried to Override Existing Column")
					end

					local Column = oldAddColumn(self, name, pos)

					local ColumnButton = Column:GetChildren()[1]

					ColumnButton:SetCursor("arrow")
					ColumnButton:SetTextColor(color_white)
					ColumnButton:SetFont("jackson_font")

					ColumnButton.Paint = function(self, w, h)
						surface.SetDrawColor(Config["menucolors"].section)
						surface.DrawRect(0, 0, w, h)

						surface.SetDrawColor(Config["menucolors"].outline)
						surface.DrawOutlinedRect(0, 0, w, h)
					end

					return Column
				end

				ConfigList.AddLine = function(self, ...) -- Override default AddLine
					local vararg = {...}

					if #vararg < 1 then
						return error ("No Content Provided")
					end

					local Line = oldAddLine(self, ...)

					for _, v in ipairs(Line:GetChildren()) do
						v:SetTextColor(color_white)
						v:SetFont("jackson_font")
					end

					Line.Paint = function(self, w, h)
						if not self:IsLineSelected() and not self:IsHovered() then
							return
						end

						local accent = CopyColor(Config["menucolors"].object)

						if self:IsHovered() and not self:IsLineSelected() then
							accent.a = accent.a / 4
						end

						surface.SetDrawColor(accent)
						surface.DrawRect(0, 0, w, h)
					end

					return Line
				end

				local ConfigListAutoLoad = ConfigList:AddColumn("Auto Load")
				ConfigListAutoLoad:SetFixedWidth(60)

				local ConfigListName = ConfigList:AddColumn("Name")
				ConfigListName:SetFixedWidth(100)

				local ConfigListDateMod = ConfigList:AddColumn("Date Modified")
				ConfigListDateMod:SetFixedWidth(90)

				function ConfigList:Paint(w, h)
					surface.SetDrawColor(Config["menucolors"].object_background)
					surface.DrawRect(0, 0, w, h)

					surface.SetDrawColor(Config["menucolors"].outline)
					surface.DrawOutlinedRect(0, 0, w, h)
				end

				g_pConfigList = ConfigList

				ConfigList._OnMouseReleased = ConfigList.OnMouseReleased

				function ConfigList:OnMouseReleased(MouseCode)
					self:_OnMouseReleased(MouseCode)

					if MouseCode ~= MOUSE_RIGHT then return end

					local Options = CustomDermaMenu()

					Options:AddOption("Clear autoload", function()
						file.Delete(string.format("%s/autoload.txt", "jackson/config"))

						for k, Line in next, self:GetLines() do
							if Line:GetColumnText(1) ~= "Yes" then continue end

							Line:SetColumnText(1, "")
						end
					end)

					Options:AddOption("Save current config", function()
						Derma_StringRequest("save config", "name of config to save\nfiles stored in data/jackson/config", "", function(text)
							C_ConfigManager:SaveConfig(text, C_ConfigManager.m_pCurrConfig, true)
							C_ConfigManager:RefreshConfigList()
						end, nil, "Save")
					end)

					Options:Open()
				end

				function ConfigList:DoDoubleClick(_, Line)
					C_ConfigManager:LoadConfig(Line.m_strConfigName)
					C_ConfigManager:RefreshConfigList()
				end

				function ConfigList:OnRowRightClick(lineID, line)
					local Options = CustomDermaMenu()

					Options:AddOption("Clear autoload", function()
						file.Delete(string.format("%s/autoload.txt", "jackson/config"))

						for k, Line in next, ConfigList:GetLines() do
							if Line:GetColumnText(1) == "Yes" then
								Line:SetColumnText(1, "")
							end
						end
					end)

					Options:AddOption("Save current config", function()
						Derma_StringRequest("save config", "name of config to save\nfiles stored in data/jackson/config", "", function(text)
							C_ConfigManager:SaveConfig(text, C_ConfigManager.m_pCurrConfig, true)
							C_ConfigManager:RefreshConfigList()
						end, nil, "Save")
					end)

					Options:AddSpacer()
					Options:AddOption("Load", function()
						C_ConfigManager:LoadConfig(line.m_strConfigName)
					end)

					Options:AddOption("Mark as autoload", function()
						C_ConfigManager:MarkAsAutoload(line.m_strConfigName)
						line:SetColumnText(1, "Yes")

						for k, Line in next, ConfigList:GetLines() do
							if Line ~= line and Line:GetColumnText(1) == "Yes" then
								Line:SetColumnText(1, "")
							end
						end
					end)

					Options:AddSpacer()
					Options:AddOption("Delete", function()
						C_ConfigManager:DeleteConfig(line.m_strConfigName)
						ConfigList:RemoveLine(lineID)
					end)

					Options:Open()
				end

				C_ConfigManager:RefreshConfigList()
			end

			local pCustomizationSection = Frame:AddSection(Panel, 130, 165, 130, 90, "Menu Customization")
			Frame:AddColorbox(pCustomizationSection, 20, 20, 15, 15, nil, Config["menucolors"], "object")
			Frame:AddColorbox(pCustomizationSection, 20, 40, 15, 15, nil, Config["menucolors"], "object_background")
			Frame:AddColorbox(pCustomizationSection, 20, 60, 15, 15, nil, Config["menucolors"], "outline")
			Frame:AddColorbox(pCustomizationSection, 80, 20, 15, 15, nil, Config["menucolors"], "section")
			Frame:AddColorbox(pCustomizationSection, 80, 40, 15, 15, nil, Config["menucolors"], "background")

			local pAutoClickerSection = Frame:AddSection(Panel, 265, 165, 235, 90, "Auto-Clicker")
			Frame:AddCheckbox(pAutoClickerSection, 20, 20, "Rapid-Fire", Config, "autoclicker_rapidfire_enabled")
			Frame:AddCheckbox(pAutoClickerSection, 20, 40, "Spam Toolgun", Config, "autoclicker_rapidfire_toolgun")
			Frame:AddCheckbox(pAutoClickerSection, 120, 20, "Use-Spam", Config, "autoclicker_usespam")
			Frame:AddCheckbox(pAutoClickerSection, 120, 40, "Flashlight Spam", Config, "autoclicker_flashlightspam")

			local pCustomFOVSection = Frame:AddSection(Panel, 5, 255, 190, 70, "Custom-FOV")
			Frame:AddCheckbox(pCustomFOVSection, 20, 20, "Enabled", Config, "customfov_enabled")
			Frame:AddSlider(pCustomFOVSection, 20, 40, 200, "FOV", 0, 189, 0, Config, "customfov_fov")

			local pNameStealerSection = Frame:AddSection(Panel, 200, 255, 140, 70, "Name-Stealer")
			Frame:AddButton(pNameStealerSection, 20, 20, 100, 15, "Random Player", function()
				StealName(GetRandomPlayer())
			end)
			do
				local pCustomName = vgui.Create("DTextEntry", pNameStealerSection)
				pCustomName:SetPos(20, 40)
				pCustomName:SetSize(100, 15)
				pCustomName:SetText("Custom Name")

				function pCustomName:OnEnter(val)
					ChangeName(val)
				end
				--[[
				function pCustomName:Paint(w, h)
					surface.SetDrawColor(Config["menucolors"].object_background)
					surface.DrawRect(0, 0, w, h)

					surface.SetDrawColor(color_grey)
					surface.DrawOutlinedRect(0, 0, w, h)
				end
				]]
			end

			local pCustomDisconnectSection = Frame:AddSection(Panel, 345, 255, 190, 70, "Custom-Disconnect")
			do
				local pDisconnectReason = vgui.Create("DTextEntry", pCustomDisconnectSection)
				pDisconnectReason:SetPos(20, 20)
				pDisconnectReason:SetSize(100, 20)
				pDisconnectReason:SetText("Reason")

				function pDisconnectReason:OnEnter(val)
					Derma_Query(
						"Are you sure you want to disconnect?",
						"Confirmation:",
						"Yes",
						function() proxi.Disconnect(val) end,
						"No",
						function() end
					)
				end
			end

			local pDeltorSection = Frame:AddSection(Panel, 5, 325, 190, 70, "Deltor")
			Frame:AddCheckbox(pDeltorSection, 20, 20, "Enabled", Config, "deletor_enabled")
			Frame:AddColorbox(pDeltorSection, 100, 20, 15, 15, nil, Config, "deletor_color")
			Frame:AddSlider(pDeltorSection, 20, 40, 200, "Radius", 0, 1000, 0, Config, "deletor_radius")
		end, true)

		Frame:AddTab("Player List", function(Panel)
			local EnvPlayerList = vgui.Create("DListView", Panel)
			EnvPlayerList:Dock(FILL)
			EnvPlayerList:SetMultiSelect(false)
			EnvPlayerList:SetSortable(false)

			function EnvPlayerList:Paint(w, h)
				surface.SetDrawColor(Config["menucolors"].object_background)
				surface.DrawRect(0, 0, w, h)

				surface.SetDrawColor(Config["menucolors"].outline)
				surface.DrawOutlinedRect(0, 0, w, h)
			end

			local oldAddColumn = EnvPlayerList.AddColumn
			local oldAddLine = EnvPlayerList.AddLine

			function EnvPlayerList:AddColumn(name, pos) -- Override default AddColumn
				if not name then
					return error("No Column Name Provided")
				end

				if pos and (pos <= 0 or self.Columns[pos]) then
					return error("Tried to Override Existing Column")
				end

				local Column = oldAddColumn(self, name, pos)

				local ColumnButton = Column:GetChildren()[1]

				ColumnButton:SetTextColor(color_white)
				ColumnButton:SetFont("jackson_font")

				function ColumnButton:Paint(w, h)
					surface.SetDrawColor(Config["menucolors"].section)
					surface.DrawRect(0, 0, w, h)

					surface.SetDrawColor(Config["menucolors"].outline)
					surface.DrawOutlinedRect(0, 0, w, h)
				end

				return Column
			end

			function EnvPlayerList:AddLine(...) -- Override default AddLine
				local vararg = {...}

				if #vararg < 1 then
					return error ("No Content Provided")
				end

				local Line = oldAddLine(self, ...)

				for _, v in ipairs(Line:GetChildren()) do
					v:SetTextColor(color_white)
					v:SetFont("jackson_font")
				end

				function Line:Paint(w, h)
					if not self:IsLineSelected() and not self:IsHovered() then
						return
					end

					local accent = CopyColor(Config["menucolors"].outline)
					if self:IsHovered() and not self:IsLineSelected() then
						accent.a = accent.a / 4
					end

					surface.SetDrawColor(accent)
					surface.DrawRect(0, 0, w, h)
				end

				return Line
			end

			local pListChildren = EnvPlayerList:GetChildren()
			local scrollbar = pListChildren[2]
			function scrollbar:Paint(w, h)
				surface.SetDrawColor(Config["menucolors"].section)
				surface.DrawRect(0, 0, w, h)
			end

			for _, v in ipairs(scrollbar:GetChildren()) do
				v.Paint = function(_, w, h)
					surface.SetDrawColor(Config["menucolors"].object_background)
					surface.DrawRect(0, 0, w, h)

					surface.SetDrawColor(Config["menucolors"].outline)
					surface.DrawOutlinedRect(0, 0, w, h)
				end
			end

			EnvPlayerList:AddColumn("Index")
			EnvPlayerList:AddColumn("Username")

			function EnvPlayerList:CacheUpdate()
				self:Clear()

				local tAdded = {}

				for k, v in ipairs(g_tPlayers) do
					if not IsValid(v) then continue end

					local strName = v:GetName()
					local strPriority = "None"

					if Config["ragebot_friends"][v] == true then
						strPriority = "Whitelisted"
					end

					if not tAdded[strName] then
						local pLine = self:AddLine(k, strName, strPriority)
						pLine.m_pCurrPlayer = v
						tAdded[strName] = true
					end
				end
			end

			function EnvPlayerList:OnRowRightClick(lineID, line)
				local pCurrPlayer = line.m_pCurrPlayer
				if not IsValid(pCurrPlayer) then return end

				local Options = CustomDermaMenu()

				Options:AddOption("WhiteList", function()
					Config["ragebot_friends"][pCurrPlayer] = not Config["ragebot_friends"][pCurrPlayer]
					EnvPlayerList:CacheUpdate()
				end):SetChecked(Config["ragebot_friends"][pCurrPlayer])

				Options:AddSpacer()
				Options:AddOption("Mute", function()
					pCurrPlayer:SetMuted(not pCurrPlayer:IsMuted())
				end):SetChecked(pCurrPlayer:IsMuted())

				Options:AddOption("Steal Name", function()
					StealName(pCurrPlayer)
				end)

				Options:AddSpacer()
				Options:AddOption("Open Profile", function()
					gui.OpenURL("https://steamcommunity.com/profiles/" .. pCurrPlayer:SteamID64())
				end)

				Options:Open()
			end

			g_pEnvPlayerList = EnvPlayerList
		end)

		Frame:AddTab("Entity List", function(Panel)
			local List = vgui.Create("DListView", Panel)
			List:Dock(FILL)
			List:SetMultiSelect(false)

			function List:Paint(w, h)
				surface.SetDrawColor(Config["menucolors"].object_background)
				surface.DrawRect(0, 0, w, h)

				surface.SetDrawColor(Config["menucolors"].outline)
				surface.DrawOutlinedRect(0, 0, w, h)
			end

			local oldAddColumn = List.AddColumn
			local oldAddLine = List.AddLine

			function List:AddColumn(name, pos) -- Override default AddColumn
				if not name then
					return error("No Column Name Provided")
				end

				if pos and (pos <= 0 or self.Columns[pos]) then
					return error("Tried to Override Existing Column")
				end

				local Column = oldAddColumn(self, name, pos)

				local ColumnButton = Column:GetChildren()[1]

				ColumnButton:SetTextColor(color_white)
				ColumnButton:SetFont("jackson_font")

				function ColumnButton:Paint(w, h)
					surface.SetDrawColor(Config["menucolors"].section)
					surface.DrawRect(0, 0, w, h)

					surface.SetDrawColor(Config["menucolors"].outline)
					surface.DrawOutlinedRect(0, 0, w, h)
				end

				return Column
			end

			function List:AddLine(...) -- Override default AddLine
				local vararg = {...}

				if #vararg < 1 then
					return error ("No Content Provided")
				end

				local Line = oldAddLine(self, ...)

				for _, v in ipairs(Line:GetChildren()) do
					v:SetTextColor(color_white)
					v:SetFont("jackson_font")
				end

				function Line:Paint(w, h)
					if not self:IsLineSelected() and not self:IsHovered() then
						return
					end

					local accent = CopyColor(Config["menucolors"].outline)
					if self:IsHovered() and not self:IsLineSelected() then
						accent.a = accent.a / 4
					end

					surface.SetDrawColor(accent)
					surface.DrawRect(0, 0, w, h)
				end

				return Line
			end

			local pListChildren = List:GetChildren()
			local scrollbar = pListChildren[2]
			function scrollbar:Paint(w, h)
				surface.SetDrawColor(Config["menucolors"].section)
				surface.DrawRect(0, 0, w, h)
			end

			for _, v in ipairs(scrollbar:GetChildren()) do
				v.Paint = function(_, w, h)
					surface.SetDrawColor(Config["menucolors"].object_background)
					surface.DrawRect(0, 0, w, h)

					surface.SetDrawColor(Config["menucolors"].outline)
					surface.DrawOutlinedRect(0, 0, w, h)
				end
			end

			List:AddColumn("Class Name")
			List:AddColumn("Shown on ESP")

			local Textbox = vgui.Create("DTextEntry", Panel)
			Textbox:Dock(BOTTOM)
			Textbox:SetUpdateOnType(true)

			Textbox.m_pList = List
			List.m_pTextbox = Textbox

			List.m_fRebuildTick = setfenv(function()
				local Done = 10 -- Need to always yield on the 1st one to avoid problems

				for k, _ in SortedPairs(self.m_tClasses) do
					if Done >= 10 then
						Done = 0
						coroutine.yield()
					end

					self:AddLine(k, table.HasValue(tEntityClasses, k) and "True" or "False")
					Done = Done + 1

					if self.m_bKillCoroutine then break end
				end
			end, setmetatable({ -- The coroutine doesn't call with the context of the panel so we need to fix this function up a bit
				self = List
			}, {
				__index = _G,

				__newindex = function(_, K, V)
					_G[K] = V
				end
			}))

			function List:Think()
				if self.m_pCoroutine then
					coroutine.resume(self.m_pCoroutine)

					if self.m_bKillCoroutine then
						self.m_bKillCoroutine = false
					end
				end
			end

			function List:Rebuild(Classes)
				self:Clear()
				self.m_pTextbox:SetValue("")

				self.m_tClasses = Classes or tKnownEntityClasses
				self.m_pCoroutine = coroutine.create(self.m_fRebuildTick)

				Config["entityclasses"] = tEntityClasses
			end

			function List:DoDoubleClick(_, Line) -- Toggle on double click
				local Class = Line:GetColumnText(1)
				if Line:GetColumnText(2) == "True" then
					table.remove(tEntityClasses, table.KeyFromValue(tEntityClasses, Class))
					Line:SetColumnText(2, "False")
				else
					if not table.HasValue(tEntityClasses, Class) then
						tEntityClasses[#tEntityClasses + 1] = Class
						Line:SetColumnText(2, "True")
					end
				end
			end

			Panel.m_pList = List
			Frame.m_pList = List

			function Textbox:OnValueChange(NewValue)
				if self.m_bCalled then return end -- Prevent infinite loop

				if NewValue == "" then -- Textbox was cleared, restore everything
					self.m_bCalled = true
					self.m_pList:Rebuild()
					self.m_bCalled = false

					return
				end

				self.m_pList.m_bKillCoroutine = true -- Stop the current building

				NewValue = NewValue:lower()

				self.m_pList:Clear()

				local Classes = {}

				for k, _ in SortedPairs(tKnownEntityClasses) do
					if k:find(NewValue, 1, true) then
						Classes[k] = true
					end
				end

				self.m_bCalled = true
				self.m_pList:Rebuild(Classes)
				self.m_bCalled = false
			end

			Panel.m_pTextbox = Textbox
		end)

		g_pCachedMenu = Frame
	end
end

--[[
	Setup hooks
]]

local nLastUpdate = 0
local vLastColor = Color(255, 255, 255, 255)
function C_CreateMove:OnTick()
	local flSysTime = SysTime()

	if flSysTime - nLastUpdate >= 0.4 then
		if Config["deletor_enabled"] then
			for _, ent in pairs(g_tEntities) do
				if not IsValid(ent) or ent:IsWorld() or ent:IsWeapon() then
					continue
				end

				if g_pLocalPlayer:GetPos():DistToSqr(ent:GetPos()) <= Config["deletor_radius"] ^ 2 then
					net.Start( "properties" )
						net.WriteString( "remove" , 32 )
						net.WriteEntity( ent )
					net.SendToServer()
				end
			end
		end

		nLastUpdate = flSysTime
	end

	if Config["worldcolors_enabled"] and vLastColor ~= Config["worldcolor_color"] then
		SetWorldColor(Config["worldcolor_color"])

		vLastColor = Config["worldcolor_color"]
	end

	color_rainbow = HSVToColor(flSysTime * 90, 1, 1)
	C_AntiAim:FakeActThink()
end

function LagCompensation:OnPostFrameStageNotify(stage)
	if stage == FRAME_NET_UPDATE_POSTDATAUPDATE_START then
		g_tEntities = ents.GetAll()

		for i = #g_tPlayers, 1, -1 do
			g_tPlayers[i] = nil
		end

		for _, v in ipairs(player.GetAll()) do
			g_tPlayers[#g_tPlayers + 1] = v
		end

		---- menu shit

		local doUpdatePlayerList = false

		if IsValid(g_pEnvPlayerList) and #g_tPlayers ~= #g_pEnvPlayerList:GetLines() then
			doUpdatePlayerList = true
		end

		for i = 1, #g_tPlayers do
			if not IsValid(g_tPlayers[i]) then
				doUpdatePlayerList = true

				break
			end
		end

		if doUpdatePlayerList then
			g_pEnvPlayerList:CacheUpdate()
		end

		collectgarbage("step")

		C_Ragebot:PopulateTargetTable()
	end

	if stage == FRAME_NET_UPDATE_END then
		self.m_flLerpTime = self:GetLerpTime()

		self:FrameUpdatePostEntityThink()

		collectgarbage("step")
	end
end

function C_Accuracy:OnEntityFireBullets(pEntity, Data)
	if pEntity ~= g_pLocalPlayer then
		return
	end

	C_CreateMove.m_nSlowShootTicks = 0

	if not IsFirstTimePredicted() then
		return
	end

	if not IsValid(g_pActiveWeapon) then
		return
	end

	local vCurrentSpread = Data.Spread
	if isvector(vCurrentSpread) and not vCurrentSpread:IsZero() then
		g_tWeaponSpreadCones[g_pActiveWeapon.strClass] = vCurrentSpread
	end
end

C_CreateMove.RestoreAngles = true
C_CreateMove.SentAngles = Angle()
C_CreateMove.StoredAngles = Angle()
function C_CreateMove:SetupMove(pUserCmd, bSendPacket)
	g_pUserCmd = pUserCmd
	g_bSendPacket = bSendPacket
	g_nChokedPackets = proxi.GetChokedCommands()

	self.m_nTickCount = pUserCmd:TickCount()
	self.m_bIsPredicted = self.m_nTickCount == 0

	if self.RestoreAngles then
		local deltaAngles = self.SentAngles - self.StoredAngles
		deltaAngles:Normalize()

		local newAngles = pUserCmd:GetViewAngles() - deltaAngles
		newAngles:Normalize()

		pUserCmd:SetViewAngles(newAngles)
		self.RestoreAngles = false
	end
end

function C_CreateMove:UpdateGlobals()
	if cl_interp:GetFloat() ~= 0 then
		cl_interp:ForceFloat(0)
	end

	g_pLocalPlayer = LocalPlayer()

	g_pActiveWeapon = g_pLocalPlayer:GetActiveWeapon()
	g_pActiveWeapon.strClass = IsValid(g_pActiveWeapon) and g_pActiveWeapon:GetClass() or ""
	g_pActiveWeapon.strBase = GetWeaponBase(g_pActiveWeapon)

	self.m_flServerTime = TICKS_TO_TIME(g_pLocalPlayer:GetInternalVariable("m_nTickBase"))
	self.m_bCanShoot = false

	if IsValid(g_pActiveWeapon) then
		local flClip1 = g_pActiveWeapon:Clip1()
		if flClip1 <= 0 and flClip1 ~= 1 and not IsMeleeWeapon(g_pActiveWeapon) and g_pActiveWeapon.strClass ~= "nz_death_machine" then
			return
		end

		local flNextPrimaryAttack = g_pActiveWeapon:GetNextPrimaryFire()

		if g_pActiveWeapon.IsSWCSWeapon then
			if g_pActiveWeapon:GetHasBurstMode() and g_pActiveWeapon:GetBurstShotsRemaining() > 0 then
				flNextPrimaryAttack = g_pActiveWeapon:GetNextBurstShot()
			end

			local flCycleTime = g_pActiveWeapon:GetCycleTime()
			flNextPrimaryAttack = g_pActiveWeapon:GetNextPrimaryFire(flCycleTime)
		end

		local bSlowShoot = not Config["slowshoot_enabled"]
		if Config["slowshoot_enabled"] then
			if self.m_nSlowShootTicks >= TIME_TO_TICKS(Config["slowshoot_time"]) then
				bSlowShoot = true
			else
				self.m_nSlowShootTicks = self.m_nSlowShootTicks + 1
			end
		end

		self.m_bCanShoot = self.m_flServerTime >= flNextPrimaryAttack and bSlowShoot
	end
end

function C_CreateMove:UnpredictedMove(pUserCmd)
	C_AntiAim:FakeLag()
	C_AntiAim:Run(pUserCmd)
	C_Ragebot:Run(pUserCmd)
	C_TriggerBot:Run(pUserCmd)
	C_Accuracy:Run(pUserCmd)

	C_AntiAim:FakeDuck(pUserCmd)

	self:AutoClicker(pUserCmd)

	C_Movement:FixMovement(pUserCmd, g_pLocalPlayer:EyeAngles())

	local nOriginalSequence = proxi.GetSequenceNumber() or -1
	if not self.m_bIsPredicted then
		self:DoubleTap(pUserCmd)
		self:FakeTeleport()
	end
	local nPostSequence = proxi.GetSequenceNumber() or -1

	if g_bSequenceRan then
		local nSequenceDifference = nPostSequence - nOriginalSequence
		g_pLocalPlayer:SetDTNetVar("DT_LocalPlayerExclusive->m_nTickBase", GetTickBase(g_pLocalPlayer) - nSequenceDifference)
	end
end

function C_CreateMove:FinishMove(pUserCmd)
	if g_bSequenceRan then
		g_bSendPacket = true
		pUserCmd:SetCommandNumber(g_iPostSequence)
	end

	if g_bSendPacket then
		g_qRealAngle.p = math.NormalizeAngle(pUserCmd:GetViewAngles().p)
		g_qRealAngle.y = math.NormalizeAngle(pUserCmd:GetViewAngles().y)
	else
		g_qFakeAngle.p = math.NormalizeAngle(pUserCmd:GetViewAngles().p)
		g_qFakeAngle.y = math.NormalizeAngle(pUserCmd:GetViewAngles().y)
	end

	if MultiplayerAnimState.Instances[LP_FAKE] then
		if g_bSendPacket then
			MultiplayerAnimState:UpdateEyeAngles(LP_FAKE)
		end

		MultiplayerAnimState:UpdateAnimationState(LP_FAKE)

		if g_bSendPacket then
			MultiplayerAnimState:UpdateCachedPoseParameters(LP_FAKE)
		end
	end

	g_bSequenceRan = false
end

function C_CreateMove:OnFinishMove(hPlayer, mv)
	if not hPlayer then return end 
	local qViewPunch = hPlayer:GetViewPunchAngles()
	local qViewPunchVelo = hPlayer:GetViewPunchVelocity()

	g_qPunchAngle = Vector(qViewPunch.x, qViewPunch.y, qViewPunch.z)
	g_qPunchAngleVel = Vector(qViewPunchVelo.x, qViewPunchVelo.y, qViewPunchVelo.z)

	if g_qPunchAngle:LengthSqr() > .001 or g_qPunchAngleVel:LengthSqr() > .001 then
		g_qPunchAngle:Add(g_qPunchAngleVel * TICK_INTERVAL)
		local flDamping = 1 - (9 * TICK_INTERVAL)

		if flDamping < 0 then
			flDamping = 0
		end

		g_qPunchAngleVel:Mul(flDamping)

		local flSpringForceMagnitude = 65 * TICK_INTERVAL
		flSpringForceMagnitude = math.Clamp(flSpringForceMagnitude, 0, 2)

		g_qPunchAngleVel:Sub(g_qPunchAngle * flSpringForceMagnitude)

		g_qPunchAngle:SetUnpacked(math.Clamp(g_qPunchAngle.x, -89, 89), math.Clamp(g_qPunchAngle.y, -179, 179), math.Clamp(g_qPunchAngle.z, -89, 89))

		g_qPunchAngle = Angle(g_qPunchAngle.x, g_qPunchAngle.y, g_qPunchAngle.z)
		g_qPunchAngleVel = Angle(g_qPunchAngleVel.x, g_qPunchAngleVel.y, g_qPunchAngleVel.z)
	else
		g_qPunchAngle = Angle()
		g_qPunchAngleVel = Angle()
	end
end

MultiplayerAnimState:Create(LP_FAKE, g_pLocalPlayer)
MultiplayerAnimState:Create(LP_REAL, g_pLocalPlayer)

function MultiplayerAnimState:OnPrePlayerDraw(hPlayer)
	if hPlayer ~= g_pLocalPlayer then
		return
	end

	if g_pLocalPlayer:IsPlayingTaunt() or Wait then
		return
	end

	if self.Instances[LP_FAKE] then
		self:ApplyCachedPoseParameters(LP_FAKE)
		self:ApplyAnimationLayers(LP_FAKE)

		hPlayer:UseClientSideAnimation(false)
		hPlayer:AnimResetGestureSlot(GESTURE_SLOT_VCD)
		hPlayer:AnimResetGestureSlot(GESTURE_SLOT_CUSTOM)

		hPlayer:SetPoseParameter("head_pitch", 0)
		hPlayer:SetPoseParameter("head_yaw", 0)

		hPlayer:InvalidateBoneCache()
		hPlayer:SetupBones()
	end
end

function MultiplayerAnimState:OnPostPlayerDraw(hPlayer)
	if hPlayer ~= g_pLocalPlayer then
		return
	end

	if g_pLocalPlayer:IsPlayingTaunt() or Wait then
		return
	end

	if self.Instances[LP_FAKE] then
		self:RestoreAnimationLayers(LP_FAKE)
		return
	end
end

function C_Visuals:OnPostDrawHUD()
	cam.Start2D()
		local EntitiesThisFrame = {}

		if Config["playeresp_enabled"] then
			for _, hPlayer in pairs(g_tPlayers) do
				if not IsValid(hPlayer) then continue end
				if not hPlayer:Alive() or hPlayer == g_pLocalPlayer then continue end
				if not self:OnScreen(hPlayer) then continue end

				EntitiesThisFrame[#EntitiesThisFrame + 1] = hPlayer
			end
		end

		if Config["entityesp_enabled"] then
			for _, v in pairs(Config["entityclasses"]) do
				local pEntities = ents.FindByClass(v)

				for _, pEntity in pairs(pEntities) do
					if pEntity:IsDormant() then continue end
					if not self:OnScreen(pEntity) then continue end

					if (pEntity:IsNPC() or pEntity:IsNextBot()) and pEntity:Health() <= 0 then
						continue
					end

					EntitiesThisFrame[#EntitiesThisFrame + 1] = pEntity
				end
			end
		end

		table.sort(EntitiesThisFrame, function(a, b)
			return a:GetPos():DistToSqr(EyePos()) > b:GetPos():DistToSqr(EyePos())
		end)

		for _, v in pairs(EntitiesThisFrame) do
			if not IsValid(v) then continue end

			local bIsPlayer = v:IsPlayer()
			local strEntType = bIsPlayer and "player" or "entity"

			self:ESP2D(v, strEntType)
		end
	cam.End2D()

	if Config["aimcone_enaled"]  then
		if #g_tCurrShapeData > 0 then
			table.Empty(g_tCurrShapeData)
		end

		local iRadius = (math.tan(math.rad(Config["aimcone_fov"])) / math.tan(math.rad(g_tCalcViewData.m_nFOV * 0.5)) * SCREEN_WIDTH) / 2.6

		if Config["aimcone_shape"] == AIMCONE_SHAPE_RHOMBUS then
			local flWidth = iRadius * 1.4
			local flHieght = iRadius * 2

			g_tCurrShapeData = {
				{SCREEN_CENTER_X - flWidth / 2, SCREEN_CENTER_Y},
				{SCREEN_CENTER_X, SCREEN_CENTER_Y - flHieght / 2},
				{SCREEN_CENTER_X + flWidth / 2, SCREEN_CENTER_Y},
				{SCREEN_CENTER_X, SCREEN_CENTER_Y + flHieght / 2}
			}

			surface.SetDrawColor(Config["aimcone_color"])

			for i = 1, 4 do
				local j = (i % 4) + 1

				surface.DrawLine(g_tCurrShapeData[i][1], g_tCurrShapeData[i][2], g_tCurrShapeData[j][1], g_tCurrShapeData[j][2])
			end
		elseif Config["aimcone_shape"] == AIMCONE_SHAPE_CIRCLE then
			local flAimFOV = Config["aimcone_fov"]
			local colDraw = Config["aimcone_color"]

			local flAspectRatio = SCREEN_WIDTH / SCREEN_HEIGHT

			local nAimbotFOV = (flAimFOV * math.pi / 180)
			local nGameFOV = (GetViewFOV() * math.pi / 180)
			local nViewFOV = 2 * math.atan( flAspectRatio * 1.5 * math.tan(nGameFOV / 2) )

			local flRadius = (math.tan(nAimbotFOV) / math.tan(nViewFOV * 0.5)) * SCREEN_WIDTH

			surface.SetDrawColor(Config["aimcone_color"])
			surface.DrawCircle(SCREEN_WIDTH / 2, SCREEN_HEIGHT / 2, flRadius, colDraw.r,colDraw.g,colDraw.b,colDraw.a)
		elseif Config["aimcone_shape"] == AIMCONE_SHAPE_TRIANGLE then
			local x = SCREEN_WIDTH * 0.5
			local y = SCREEN_HEIGHT * 0.5

			-- I don't understand this either, I just threw some shit together and it happened to work

			local t = iRadius * 2.3333333333333
			local s = x - (t / 2)

			local offset_y = 0 - (iRadius / 3)

			g_tCurrShapeData = {
				{x = s, y = (y + iRadius) + offset_y},
				{x = s + t, y = (y + iRadius) + offset_y},
				{x = x, y = (y - iRadius) + offset_y}
			}

			local v1, v2, v3 = g_tCurrShapeData[1], g_tCurrShapeData[2], g_tCurrShapeData[3]

			surface.SetDrawColor(Config["aimcone_color"])
			surface.DrawLine(v1.x, v1.y, v2.x, v2.y)
			surface.DrawLine(v2.x, v2.y, v3.x, v3.y)
			surface.DrawLine(v3.x, v3.y, v1.x, v1.y)
		elseif Config["aimcone_shape"] == AIMCONE_SHAPE_SQUARE then
			local flSize = iRadius * 1.5

			g_tCurrShapeData = {
				flSize
			}

			surface.SetDrawColor(Config["aimcone_color"])
			surface.DrawOutlinedRect(SCREEN_CENTER_X - flSize / 2, SCREEN_CENTER_Y - flSize / 2, flSize, flSize)
		end
	end

	if Config["aimline_enabled"]  then
		self:AimLine()
	end

	if Config["misc_antiaimlines"] then
		self:AntiAimLines()
	end

	if Config["misc_drawspreadcone"] then
		self:DrawSpreadCone()
	end

	if Config["misc_debuginfo"] then
		self:ShowInfo()
	end
end

function C_Visuals:OnPreDrawEffects()
	local flBlend = render.GetBlend()

	local tab = {}
	local plys = {
		[ENTS] = {},
		[COLOR] = Config["playeresp_outline_color"]
	}

	tab[#tab + 1] = plys

	for _, hPlayer in ipairs(g_tPlayers) do
		if not IsValid(hPlayer) or hPlayer:IsDormant() or not hPlayer:Alive() or hPlayer == g_pLocalPlayer then continue end
		if not self:OnScreen(hPlayer) then continue end

		if Config["playerchams_enabled"] then
			self:DrawChams(hPlayer, "player")
		end

		if Config["playeresp_box3d"] then
			local vMins, vMaxs = hPlayer:GetCollisionBounds()
			render.DrawWireframeBox(hPlayer:GetPos(), angle_zero, vMins, vMaxs, color_white, true)
		end

		if Config["playeresp_enabled"] and Config["playeresp_outline"] then
			plys[ENTS][#plys[ENTS] + 1] = hPlayer
		end

		if Config["hitboxes_enabled"] then
			local pModelData = C_HitboxManager:GetModelData(hPlayer)
			if not pModelData:IsValid() then
				continue
			end

			local pHitboxSets = pModelData.m_tHitboxSets
			for iHitGroup, pHitboxes in pairs(pHitboxSets) do
				for iHitbox, pHitbox in pairs(pHitboxes) do
					local pBoneToWorld = hPlayer:GetBoneMatrix(pHitbox.m_nBone)
					if not pBoneToWorld then
						continue
					end

					local vTranslateion, qOrientation = pBoneToWorld:GetTranslation(), pBoneToWorld:GetAngles()

					render.DrawWireframeBox(vTranslateion, qOrientation, pHitbox.m_vMins, pHitbox.m_vMaxs, Config["hitboxes_color"], true)
				end
			end
		end
	end

	for _, v in pairs(Config["entityclasses"]) do
		local pEntities = ents.FindByClass(v)

		for _, pEntity in pairs(pEntities) do
			if not IsValid(pEntity) or pEntity:IsDormant() then continue end
			if not self:OnScreen(pEntity) then continue end

			if (pEntity:IsNPC() or pEntity:IsNextBot()) and pEntity:Health() <= 0 then
				continue
			end

			if Config["entitychams_enabled"] then
				self:DrawChams(pEntity, "entity")
			end

			if Config["entityesp_enabled"] then
				if Config["entityesp_outline"] then
					plys[ENTS][#plys[ENTS] + 1] = pEntity
				end

				if Config["entityesp_box3d"] then
					local vMins, vMaxs = pEntity:GetCollisionBounds()
					render.DrawWireframeBox(pEntity:GetPos(), self:ShouldRotate(pEntity) and pEntity:GetAngles() or angle_zero,vMins, vMaxs, color_white, true)
				end
			end
		end
	end

	self:Outlines(tab)

	if Config["backtrack_visuals_enabled"] then
		for idx, pTrack in next, LagCompensation.m_tRecords do
			local pEntity = Entity(idx)
			if not IsValid(pEntity) or pEntity:IsDormant() then
				continue
			end

			for iRecordIndex = #pTrack, 1, -1 do
				local pRecord = pTrack[iRecordIndex]

				local vStartColor = Config["backtrack_visuals_startcolor"]
				local vEndColor = Config["backtrack_visuals_endcolor"]

				local flDivisor = (iRecordIndex - 1) / (#pTrack - 1)
				local iGradedR = math.floor(vStartColor.r + (vEndColor.r - vStartColor.r) * flDivisor)
				local iGradedG = math.floor(vStartColor.g + (vEndColor.g - vStartColor.g) * flDivisor)
				local iGradedB = math.floor(vStartColor.b + (vEndColor.b - vStartColor.b) * flDivisor)

				local vColor = Color(iGradedR, iGradedG, iGradedB)
				if pRecord == LagCompensation.m_tCurrentRecord then
					vColor = Color(0, 255, 0)
				end

				if Config["backtrack_visuals_visualstyle"] == BACKTRACK_VISUAL_STYLE_HITBOX then
					for iHitBox, tData in ipairs(pRecord.m_tHitboxes) do
						local col = LagCompensation.m_tCurrentRecord == pRecord and color_red or vColor

						render.DrawWireframeBox(tData.m_vOrigin, tData.m_qRotation, tData.m_vMins, tData.m_vMaxs, col, false)
					end
				elseif Config["backtrack_visuals_visualstyle"] == BACKTRACK_VISUAL_STYLE_CHAM then
					pEntity:SetRenderOrigin(pRecord.m_vOrigin)
					pEntity:InvalidateBoneCache()
					pEntity:SetupBones()

					for iBoneIndex, pBoneMatrix in next, pRecord.m_tBoneMatrices do
						if pEntity:GetBoneContents(iBoneIndex) <= 0 then
							continue
						end

						pEntity:SetBoneMatrix(iBoneIndex, pBoneMatrix)
					end

					local ChamMaterial = "metallic"

					render.MaterialOverride(self.m_tChamMaterials[ChamMaterial].vmat)
					render.SetColorModulation(vColor.r / 255, vColor.g / 255, vColor.b / 255)

					pEntity:DrawModel()
				end
			end
		end
	end

	if Config["deletor_enabled"] then
		local vPosFix = g_pLocalPlayer:GetPos()

		cam.Start3D2D(vPosFix, angle_zero, 1)
			surface.SetDrawColor(Config["deletor_color"])
			surface.SetMaterial(Material("color/white"))

			for i = 1, 360 do
				local nStartX = math.cos(math.rad(i)) * Config["deletor_radius"]
				local nStartY = math.sin(math.rad(i)) * Config["deletor_radius"]

				local nEndX = math.cos(math.rad(i + 1)) * Config["deletor_radius"]
				local nEndY = math.sin(math.rad(i + 1)) * Config["deletor_radius"]

				surface.DrawLine(nStartX, nStartY, nEndX, nEndY)
			end
		cam.End3D2D()
	end

	render.SetBlend(flBlend)
	render.SetColorModulation(1, 1, 1)
	render.MaterialOverride(nil)
end

function C_Visuals:OnPreDrawViewModel()
	if not Config["viewmodelchams_enabled"] then
		return
	end

	if not Config["viewmodelchams_hands_enabled"] then
		return
	end

	local vColor = Config["viewmodelchams_hands_color"]
	local strMaterial = Config["viewmodelchams_hands_material"]

	render.SuppressEngineLighting(true)
	render.SetColorModulation(vColor.r / 255, vColor.g / 255, vColor.b / 255)
	render.MaterialOverride(self.m_tChamMaterials[strMaterial].vmat)
	render.SetBlend(vColor.a / 255)
end

function C_Visuals:OnPostDrawViewModel()
	if not Config["viewmodelchams_enabled"] then
		return
	end

	if not Config["viewmodelchams_hands_enabled"] then
		return
	end

	render.SetColorModulation(1, 1, 1)
	render.MaterialOverride(nil)
	render.SetBlend(1)
	render.SuppressEngineLighting(false)
end

function C_Visuals:OnCalcView(hPlayer, vOrigin, qAngles, nFOV, nZNear, nZFar)
	if not hPlayer then return end 
	local view = {
		origin = vOrigin,
		angles = qAngles,
		fov = nFOV,
		znear = nZNear,
		zfar = nZFar
	}

	if Config["customfov_enabled"] then
		view.fov = math.Clamp(Config["customfov_fov"], 1, 179)
	end

	local bThirdPersonActive = Config["thirdperson_enabled"] and C_Inputs:IsKeyActive(Config, "thirdperson_key")
	if bThirdPersonActive and g_pLocalPlayer:Alive() and not g_pLocalPlayer:GetObserverTarget():IsValid() and Config["thirdperson_distance"] ~= 0 then
		--[[if Config.ThirdPerson.UseTrace then
			local trResult = {}
			util.TraceHull({
				start = view.origin,
				endpos = view.origin - view.angles:Forward() * Config["thirdperson_distance"],
				mask = MASK_SOLID,
				mins = -g_vCamSize,
				maxs = g_vCamSize,
				filter = {g_pLocalPlayer},
				output = trResult
			})

			view.origin:Set(trResult.HitPos)
		else]]
			view.origin:Sub(view.angles:Forward() * Config["thirdperson_distance"])
		--end
	end

	local vehicle = hPlayer:GetVehicle()

	if IsValid(vehicle) then
		return hook.Run("CalcVehicleView", vehicle, hPlayer, view)
	end

	if Wait or hPlayer:IsPlayingTaunt() and not bThirdPersonActive  then
		if drive.CalcView(hPlayer, view) then return view end

		local pView = { origin = view.origin * 1, angles = view.angles * 1 }
		player_manager.RunClass(hPlayer, "CalcView", pView)

		local offset = (pView.origin - view.origin):Length()
		view.origin = view.origin - (view.angles:Forward() * offset)
	end

	g_tCalcViewData.m_nFOV = view.fov

	return view
end

function C_Visuals:OnDispatchEffect(strEffectName, pEffectData)
	--if not Config["bullettracers_enabled"] then return end
	if not self.m_tAlreadyTracers[strEffectName:lower()] then return end

	local bestEnt, bestDist = NULL, INT_MAX

	if IsFirstTimePredicted() and pEffectData:GetStart():DistToSqr(g_pLocalPlayer:GetShootPos()) <= 1 then
		bestEnt = g_pLocalPlayer
	else
		for k, ent in next, g_tEntities do
			if not IsValid(ent) then continue end
			if not IsValid(bestEnt) then
				bestEnt = ent
				continue
			end

			if ent:IsPlayer() then
				local entDist = ent:GetShootPos():Distance(pEffectData:GetStart())
				if entDist < bestDist then
					bestDist = entDist
					bestEnt = ent
				end
			end
		end
	end

	if IsValid(bestEnt) and bestEnt ~= g_pLocalPlayer then
		--print(bestEnt, "just shot, attempting to on-shot")
		--[[
		-- *(float*)((uintptr_t)BasePtr + 0x24) = CalcedAngle.pitch;
		-- *(float*)((uintptr_t)BasePtr + 0x28) = CalcedAngle.yaw;
		-- *(float*)((uintptr_t)BasePtr + 0x2C) = 0;

		local event_time = TICKS_TO_TIME(engine.TickCount())
		local player_time = GetSimulationTime(bestEnt)

		-- Extrapolate tick to hit those scouters etc
		local lag_records = LagCompensation.m_tRecords[bestEnt:EntIndex()] --CMBacktracking::Get().m_LagRecord[pEntity->EntIndex()];

		local shot_time = event_time;
		for _, record in ipairs(lag_records) do
			if (TICKS_TO_TIME(record.m_nTickCount) <= event_time) then
				shot_time = record.m_flSimulationTime + (event_time - TICKS_TO_TIME(record.m_nTickCount)); -- also get choked from this
				--print(string.format("Found exact shot time: %f, ticks choked to get here: %d\n", shot_time, TIME_TO_TICKS(event_time - TICKS_TO_TIME(record.m_nTickCount))))
				break
			--else
				--print(string.format("Bad curtime difference, EVENT: %f, RECORD: %f\n", event_time, TICKS_TO_TIME(record.m_nTickCount)))
			end
		end

		--print(string.format("Calced angs: %f %f, Event angs: %f %f, CURTIME_TICKOUNT: %f, SIMTIME: %f, CALCED_TIME: %f\n", CalcedAngle.pitch, CalcedAngle.yaw, EyeAngles.pitch, EyeAngles.yaw, event_time, player_time, shot_time))

		if #lag_records > 0 then
			local choked = math.floor((event_time - player_time) / TICK_INTERVAL + 0.5)
			choked = math.max(0, math.min(21, choked))

			bestEnt:SetPos(lag_records[1].m_vOrigin + (TICK_INTERVAL * lag_records[1].m_vVelocity * choked))
		end
		]]

		--local player_time = GetSimulationTime(bestEnt)
		--LagCompensation:StoreRecord(bestEnt:EntIndex(), bestEnt, shot_time)
	end

	if Config["bullettracers_enabled"] then
		self.m_tBulletTracers[#self.m_tBulletTracers + 1] = {
			startpos = pEffectData:GetStart(),
			endpos = pEffectData:GetOrigin(),
			owner = bestEnt,
			started = SysTime()
		}
	end
end

function C_Visuals:OnPostDrawTranslucentRenderables(depth, sky)
	if not Config["bullettracers_enabled"] then return end
	if depth or sky then return end

	for i, t in ipairs(self.m_tBulletTracers) do
		if t.started + Config["bullettracers_dietime"] <= SysTime() then
			table.remove(self.m_tBulletTracers, i)
			continue
		end

		local time_left = (t.started + Config["bullettracers_dietime"]) - SysTime()
		local perc_left = time_left / Config["bullettracers_dietime"]
		local alpha = 255 * perc_left

		local color
		if t.owner == g_pLocalPlayer then
			color = Color(255, 255, 255)
		else
			color = Color(255, 0, 0)
		end

		local strMaterial = Config["bullettracers_material"] or ""

		local material = Material(strMaterial)
		if not material then
			return
		end

		render.SetMaterial(material)
		render.DrawBeam(
			t.startpos,
			t.endpos,
			5,
			1 * perc_left,
			2 * perc_left,
			ColorAlpha(color, alpha)
		)
	end
end

function C_Visuals:OnScreenSizeChanged()
	SCREEN_WIDTH = ScrW()
	SCREEN_HEIGHT = ScrH()

	SCREEN_CENTER_X = math.floor(SCREEN_WIDTH / 2)
	SCREEN_CENTER_Y = math.floor(SCREEN_HEIGHT / 2)
end

--[[
	Hooks
]]

do
	gameevent.Listen("player_connect_client")
	AddHook("player_connect_client", function()
		g_pEnvPlayerList:CacheUpdate()
	end)

	gameevent.Listen("player_disconnect")
	AddHook("player_disconnect", function()
		g_pEnvPlayerList:CacheUpdate()
	end)

	gameevent.Listen("player_hurt")
	AddHook("player_hurt", function(data)
		local hurted = Player(data.userid)
		local attackerid = data.attacker

		if attackerid ~= g_pLocalPlayer:UserID() then
			return
		end

		local nIndex = hurted:EntIndex()

		if Config["accuarcy_resolver"] then
			C_Ragebot.m_tShotsFiredAt[nIndex] = (C_Ragebot.m_tShotsFiredAt[nIndex] or 0) - 1
		end
	end)

	AddHook("Tick", function()
		C_CreateMove:OnTick()
	end)

	AddHook("PostFrameStageNotify", function(nStage)
		LagCompensation:OnPostFrameStageNotify(nStage)
	end)

	AddHook("EntityFireBullets", function(pEntity, tData)
		C_Accuracy:OnEntityFireBullets(pEntity, tData)
	end)

	AddHook("DispatchEffect", function(strEffectName, pEffectData)
		C_Visuals:OnDispatchEffect(strEffectName, pEffectData)
	end)

	AddHook("PostDrawTranslucentRenderables", function(depth, sky)
		C_Visuals:OnPostDrawTranslucentRenderables(depth, sky)
	end)

	AddHook("PostDrawHUD", function()
		C_Visuals:OnPostDrawHUD()
	end)

	AddHook("PreDrawEffects", function()
		C_Visuals:OnPreDrawEffects()
	end)

	AddHook("PrePlayerDraw", function(hPlayer)
		MultiplayerAnimState:OnPrePlayerDraw(hPlayer)
	end)

	AddHook("PostPlayerDraw", function(hPlayer)
		MultiplayerAnimState:OnPostPlayerDraw(hPlayer)
	end)

	AddHook("PreDrawViewModel", function()
		C_Visuals:OnPreDrawViewModel()
	end)

	AddHook("PostDrawViewModel", function()
		C_Visuals:OnPostDrawViewModel()
	end)

	AddHook("PreDrawPlayerHands", function()
		if not Config["viewmodelchams_enabled"] then
			return
		end

		if not Config["viewmodelchams_arms_enabled"] then
			return
		end

		local vColor = Config["viewmodelchams_arms_color"]
		local strMaterial = Config["viewmodelchams_arms_material"]

		render.SuppressEngineLighting(true)
		if IsDrawingGlow then
			render.SetColorModulation(vColor.r / 255, vColor.g / 255, vColor.b / 255)
			render.MaterialOverride(C_Visuals.m_tChamMaterials[strMaterial].vmat)
		else
			render.SetColorModulation(1, 1, 1)
		end
		render.SetBlend(vColor.a / 255)
	end)

	AddHook("PostDrawPlayerHands", function()
		if not Config["viewmodelchams_enabled"] then
			return
		end

		if not Config["viewmodelchams_arms_enabled"] then
			return
		end

		render.SetColorModulation(1, 1, 1)
		render.MaterialOverride(nil)
		render.SetBlend(1)
		render.SuppressEngineLighting(false)

		if IsDrawingGlow then return end

		IsDrawingGlow = true
		LocalPlayer():GetViewModel():DrawModel()
		IsDrawingGlow = false
	end)

	local precache = {}
	local function PrecacheSkybox(name)
		precache[name] = {
			back = Material(string.format("skybox/%sbk", name)),
			front = Material(string.format("skybox/%sft", name)),
			left = Material(string.format("skybox/%slf", name)),
			right = Material(string.format("skybox/%srt", name)),
			up = Material(string.format("skybox/%sup", name)),
			down = Material(string.format("skybox/%sdn", name)),
		}
	end

	local mappings = {
		back = {pos = Vector(0,1,0),norm = Vector(0,-1,0)},
		front = {pos = Vector(0,-1,0),norm = Vector(0,1,0)},
		left = {pos = Vector(-1,0,0),norm = Vector(1,0,0)},
		right = {pos = Vector(1,0,0),norm = Vector(-1,0,0)},
		up = {pos = Vector(0,0,1),norm = Vector(0,0,-1)},
		down = {pos = Vector(0,0,-1),norm = Vector(0,0,1)},
	}

	AddHook("PostDraw2DSkyBox", function()
		if not Config["customskybox_enabled"] then
			return
		end

		if not precache[Config["customskybox_skybox"]] then
			PrecacheSkybox(Config["customskybox_skybox"])
		end

		local sky = precache[Config["customskybox_skybox"]]

		render.OverrideDepthEnable(true, false)

		cam.Start3D(Vector(0,0,0), EyeAngles())
			for side, mat in pairs(sky) do
				render.SetMaterial(mat)
				render.DrawQuadEasy(
					(mappings[side] and mappings[side].pos or Vector(0,0,1)) * 8146,
					mappings[side] and mappings[side].norm or Vector(0,0,-1),
					16292,
					16292,
					Color(255, 255, 255),
					(side == "up" or side == "down") and 0 or 180
				)
			end
		cam.End3D()

		render.OverrideDepthEnable(false, false)
	end)

	AddHook("CreateMoveEx", function(pUserCmd, bSendPacket)
		C_CreateMove:SetupMove(pUserCmd, bSendPacket)

		if not C_CreateMove.m_bIsPredicted then
			C_CreateMove.StoredAngles = pUserCmd:GetViewAngles()
			C_CreateMove:UpdateGlobals()
			C_Movement:Run(pUserCmd)
			proxi.StartPrediction(pUserCmd)
			C_CreateMove:UpdateGlobals()
			C_CreateMove:UnpredictedMove(pUserCmd)
			proxi.EndPrediction()

			C_CreateMove.SentAngles = pUserCmd:GetViewAngles()
			C_CreateMove.RestoreAngles = C_CreateMove.StoredAngles ~= C_CreateMove.SentAngles
		end

		C_CreateMove:FinishMove(pUserCmd)

		if not C_CreateMove.m_bIsPredicted then
			if not isbool(g_bSendPacket) then
				g_bSendPacket = true
			end

			return g_bSendPacket
		end
	end)

	AddHook("FinishMove", function(hPlayer, mv)
		C_CreateMove:OnFinishMove(hPlayer, mv)
	end)

	AddHook("ShouldDrawLocalPlayer", function(hPlayer) -- this hook is pretty retarded
		if Config["thirdperson_enabled"] and Config["thirdperson_distance"] > 0 and C_Inputs:IsKeyActive(Config, "thirdperson_key") then
			return true
		end

		if g_pLocalPlayer:IsPlayingTaunt() or Wait then
			return true
		end

		return g_pLocalPlayer:ShouldDrawLocalPlayer()
	end)

	AddHook("CalcView", function(hPlayer, vOrigin, qAngles, nFOV, nZNear, nZFar)
		return C_Visuals:OnCalcView(hPlayer, vOrigin, qAngles, nFOV, nZNear, nZFar)
	end)

	AddHook("OnScreenSizeChanged", function()
		C_Visuals:OnScreenSizeChanged()
	end)

	AddHook("ShouldSendLuaError", function(strError)
		return false
	end)

	--[[
		ConCommands
	]]

	AddConCommand("sh_menu", function()
		if g_pCachedMenu:IsValid() and not g_pCachedMenu:IsVisible() then
			g_pCachedMenu:SetVisible(true)
			g_pCachedMenu:MakePopup()

			if g_pCachedMenu.m_pList:IsValid() then
				g_pCachedMenu.m_pList:Rebuild()
			end
		end
	end)

	AddConCommand("sh_unload", function()
		for i = 1, #g_tLocalHooks do
			local CurrHook = g_tLocalHooks[i]
			local Type, Name = CurrHook.m_strType, CurrHook.m_strName

			Log("Hook Removed [{%s} {%s}]", Type, Name)

			hook.Remove(Type, Name)
		end

		for k, v in pairs(player.GetAll()) do
			v:SetRenderMode(RENDERMODE_NORMAL)
		end

		if g_strOriginalName ~= g_strCurrName then
			cv_name:SendValue(g_strOriginalName)
		end

		do
			-- set world
			for k, v in pairs(g_tMapData.m_tFound) do
				local pMaterial = Material(v)
				if not pMaterial then continue end

				pMaterial:SetVector("$color", color_white:ToVector())
			end

			-- set static props
			for _, t in next, g_tMapData.m_tBSP.static_props do
				if table.IsEmpty(t.names) then continue end

				for _, model in next, t.names do
					local pEnt = ClientsideModel(model)
					pEnt:SetNoDraw(true)

					local mats = pEnt:GetMaterials()

					for k, v in next, mats do
						local pMaterial = Material(v)
						if not pMaterial then
							continue
						end

						pMaterial:SetVector("$color2", color_white:ToVector())
					end

					pEnt:Remove()
				end
			end

			-- set sky color
			for i = 1, 6 do
				SourceSkyMat[i]:SetVector("$color", color_white:ToVector())
			end

			-- put it back
			ChangeSkybox("default")
		end

		g_pCachedMenu:Remove()
		g_pCachedMenu = nil

		concommand.Remove("sh_menu")
		concommand.Remove("sh_unload")

		collectgarbage("step")
	end)
end

--[[
	Kabo
]]

cl_updaterate:ForceFloat(1 / TICK_INTERVAL) -- i hit p now ? :flushed:
cl_cmdrate:ForceFloat(1 / TICK_INTERVAL)
cl_interp:ForceFloat(0)
cl_interp_ratio:ForceFloat(1)

local CUserCmd = _R.CUserCmd
local Backup = table.Copy(CUserCmd)

CUserCmd.SetViewAngles = function(...)
	local debugInfo = debug.getinfo(2)
	if (Config["accuracy_norecoil"] and string.EndsWith(debugInfo.short_src, "arccw/shared/sh_move.lua") and debugInfo.Currentline == 193) or debugInfo.short_src:find("taunt_camera") then -- LOL XD
		return
	end

	return Backup.SetViewAngles(...)
end

CUserCmd.ClearButtons = function(...)
	if debug.getinfo(2).short_src:find("taunt_camera") then return end

	return Backup.ClearButtons(...)
end

CUserCmd.ClearMovement = function(...)
	if debug.getinfo(2).short_src:find("taunt_camera") then return end

	return Backup.ClearMovement(...)
end