--[[ TODO 
    - damagelogs
    - xqz 4 doesnt work with normal
    - make entityupdate a lazy coroutine
]]
local lp = lp or LocalPlayer()
local hookkey = "nicepersonhook"
local cfg = {}
local prophunt = engine.ActiveGamemode() == "prop_hunt"
 
local perftimers = {
    cm = 0,
    drov = 0,
    hud = 0,
    esp = 0,
    eu = 0,
    pdor = 0
}
 
local chamsmat = CreateMaterial("chamsmat", "VertexLitGeneric", {
    ["$ignorez"] = 0,
    ["$model"] = 1,
    ["$basetexture"] = "models/debug/debugwhite",
})
 
local chamsmat_ = CreateMaterial("chamsmatxqz", "VertexLitGeneric", {
    ["$ignorez"] = 1,
    ["$model"] = 1,
    ["$basetexture"] = "models/debug/debugwhite",
})
 
local chamsmat_glow = CreateMaterial("chamsmatglow", "VertexLitGeneric", {
    ["$additive"] = 1,
    ["$envmap"] = "models/effects/cube_white",
    ["$envmaptint"] = "[0 1 0]",
    ["$envmapfresnel"] = 1,
    ["$envmapfresnelminmax"] = "[0 1 1]",
    ["$alpha"] = 0.8
})
 
-- "globals"
-- bhop shit
local lastbhop = 0
local lastvel = 0
local nowvel = 0
local lastvelupdate = 0
local lastplyang = lp:EyeAngles() or Angle(0, 0, 0)
-- actual stuff
local scr_w = ScrW()
local scr_h = ScrH()
local lppos = lp:GetPos()
local lpvel = lp:GetAbsVelocity()
local playerentities = {}
local playerentities_sorted = {}
local playerentities_idsort = {}
local propentities = {}
local extraentities = {}
local playerentities_len = 0
local propentities_len = 0
local player_weps = {}
-- constants
local red = Color(255, 0, 0)
local green = Color(0, 255, 0)
local blue = Color(0, 0, 255)
local lightblue = Color(0, 150, 255)
local black = Color(0, 0, 0)
local dormant = Color(90, 90, 90)
local white = Color(255, 255, 255)
local propcol = Color(3, 169, 244)
local wepcol = Color(255, 0, 0)
local nullvec = Vector(0, 0, 0)
 
-- lists
local tracked_wpns = {
    -- NEEDS TO BE TRACKED ENT! swep printname, model of created entity, last user
    {"TTT Cadillac Canon", "models/lonewolfie/cad_eldorado.mdl", nil},
    {"Paper Plane", "models/props/c_paperplane/c_paperplane.mdl", nil},
    {"Thomas The Tank Engine", "models/adithomas/ttt_adithomas.mdl", nil},
    {"C4", "models/weapons/w_c4_planted.mdl", nil}
}
 
local tracked_ents = {"models/props/c_paperplane/c_paperplane.mdl", "models/weapons/w_eq_fraggrenade_throw2.mdl", "models/weapons/w_c4_planted.mdl", "models/stiffy360/beartrap.mdl", "models/weapons/w_ttt_supersheep.mdl", "models/lonewolfie/cad_eldorado.mdl", "models/adithomas/ttt_adithomas.mdl"}
 
local blacklisted_hooks = {
    {"HUDPaint", "BlindMinigame"},
    {"Think", "CantStopMinigame"}
}
 
local prop_namedict = {
    -- mode, name, replaced
    {0, "models/weapons/w_eq_fraggrenade.mdl", "Discombobulator"},
    {1, "grenade_fire", "Incendiary Grenade"},
    {1, "grenade_smoke", "Smoke Grenade"},
    {0, "models/weapons/w_bugbait.mdl", "Traitor Button"},
    {0, "models/stiffy360/beartrap.mdl", "Bear Trap"},
    {0, "models/weapons/w_ttt_supersheep.mdl", "Super Sheep"},
    {1, "w_eq_fraggrenade_throw2", "Holy Hand Grenade"},
    {1, "c_paperplane", "PAPERPLANE"},
    {1, "w_c4_planted", "C4"},
    {1, "cad_eldorado", "CADILLAC"},
    {1, "ttt_adithomas", "THOMAS"}
}
 
local obs_enum = {
    [0] = " NONE ",
    [1] = "DEATH ",
    [2] = "FREEZE",
    [3] = "FIXED ",
    [4] = " 1ST  ",
    [5] = " 3RD  ",
    [6] = " ROAM ",
}
 
-- util funcs
local function safecall3d(func)
    -- only used once, so potential extra function call for no reason. however, i moved it into a function for simplicity.
    local a, b = pcall(func)
 
    if a == false then
        cam.IgnoreZ(false)
        render.MaterialOverride(nil)
        render.SuppressEngineLighting(false)
        cam.End3D()
        print(b)
    end
end
 
local function getcontrastcol(col)
    hue, sat, val = ColorToHSV(col)
    hue = 360 - hue
    sat = 1 - sat
 
    return HSVToColor(hue, sat, val)
end
 
local function getcontrastcol_fast(col)
    col.r = 255 - col.r
    col.g = 255 - col.g
    col.b = 255 - col.b
 
    return col
end
 
local function getrgbcol(progress)
    return HSVToColor(progress / 100 * 360, 1, 1)
end
 
local function istraitoritem(item)
    if not item.CanBuy then return false end
 
    for i, buy in pairs(item.CanBuy) do
        if buy == ROLE_TRAITOR then return true end
    end
 
    return false
end
 
local function psw(ply, oldWep, newWep)
    if not TTT2 then return end
 
    if istraitoritem(newWep) then
        -- newwep obv doesnt work correctly when 2 ppl are throwing one at once
        for i = 1, #tracked_wpns do
            if newWep.PrintName == tracked_wpns[i][1] then
                tracked_wpns[i][3] = ply
            end
        end
 
        if ply == nil or ply:IsDetective() or ply == lp or lp:IsTraitor() or ply == lp:GetObserverTarget() then return end
        local text = newWep:GetPrintName() --esptext is often quite fucked for these
 
        if text:sub(-5) == "_name" then
            text = string.format("%s%s", text:sub(0, 1):upper(), text:sub(2, -6))
        end
 
        local xd = string.format("Possible Traitor %s, equipped %s", ply:Name(), text)
        notification.AddLegacy(xd, NOTIFY_HINT, 3)
        print(xd)
    end
end
 
local function fadecolor(from, to, percent)
    local fraction = 0
 
    if percent ~= 0 then
        fraction = percent * 0.01
    end
 
    return Color(Lerp(fraction, from.r, to.r), Lerp(fraction, from.g, to.g), Lerp(fraction, from.b, to.b), Lerp(fraction, from.a, to.a))
end
 
local function normalizeangle(ang)
    ang.p = math.NormalizeAngle(ang.p)
    ang.p = math.Clamp(ang.p, -89, 89)
    ang.y = math.NormalizeAngle(ang.y)
end
 
local function entityupdate()
    local perf = SysTime()
 
    local _propentities = {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}
 
    local _extraentities = {}
    local entities = ents.FindInSphere(lppos, (cfg["nh_espdist"] * 52.49) + 50)
    local a, b, v, model = 0, 0, 0, 0
    -- experiment
    local entlen = #entities
 
    for i = 1, entlen do
        v = entities[i]
        model = v:GetModel()
 
        if model ~= nil then
            for d = 1, #tracked_ents do
                if model == tracked_ents[d] then
                    _extraentities[a + 1] = v
                    a = a + 1
                end
            end
        end
 
        if v:IsWeapon() or v.Base == "base_anim" then
            _propentities[b + 1] = v
            b = b + 1
        end
    end
 
    propentities_len = #_propentities
    extraentities_len = #_extraentities
    propentities = _propentities
    extraentities = _extraentities
    perftimers.eu = SysTime() - perf
end
 
local function bhop(cmd)
    if lp:GetMoveType() == MOVETYPE_NOCLIP or lp:WaterLevel() >= 2 then return end
    if cfg["nh_bhop"] == 0 then return end
    local onground = lp:OnGround()
    local cmdnr = cmd:CommandNumber()
 
    if not onground and cmd:KeyDown(IN_JUMP) then
        cmd:SetButtons(bit.bor(cmd:GetButtons(), IN_SPEED))
    end
 
    if onground and cmdnr ~= lastbhop + 1 and lastvelupdate < cmdnr then
        local vel = lpvel
        vel.z = 0
        lastvel = nowvel
        nowvel = vel:Length()
        lastvelupdate = cmdnr
    end
 
    if cmd:KeyDown(IN_JUMP) and onground and cmdnr ~= lastbhop + 1 then
        cmd:SetButtons(bit.bor(cmd:GetButtons(), IN_JUMP))
 
        if (cmdnr ~= 0) then
            lastbhop = cmdnr
        end
 
        return
    end
 
    cmd:RemoveKey(IN_JUMP)
end
 
local function norecoil(cmd)
    if cfg["nh_norecoil"] == 0 then return end
    if not lp:GetActiveWeapon() then return end
    local wep = lp:GetActiveWeapon()
 
    if wep.Recoil then
        wep.Recoil = 0
    end
 
    if wep.Primary and wep.Primary.Recoil then
        wep.Primary.Recoil = 0
    end
 
    if wep.Secondary and wep.Secondary.Recoil then
        wep.Secondary.Recoil = 0
    end
end
 
local function firefixer(cmd)
    if cfg["nh_autofire"] == 0 then return end
    if not lp:GetActiveWeapon() then return end
    local wep = lp:GetActiveWeapon()
    local autofire = false
 
    if wep.Primary and wep.Primary.Automatic ~= nil then
        autofire = wep.Primary.Automatic
    end
 
    if not autofire and lp:GetActiveWeapon():GetNextPrimaryFire() - CurTime() > 0 then
        cmd:RemoveKey(IN_ATTACK)
    end
 
    if not autofire and lp:GetActiveWeapon():GetNextSecondaryFire() - CurTime() > 0 then
        cmd:RemoveKey(IN_ATTACK2)
    end
 
    if lp:GetActiveWeapon():Clip1() == 0 then
        cmd:SetButtons(bit.bor(cmd:GetButtons(), IN_RELOAD))
    end
end
 
local function strafehelper(cmd)
    if cfg["nh_autostrafe"] == 0 or lp:OnGround() or lp:GetMoveType() == MOVETYPE_NOCLIP or lp:WaterLevel() ~= 0 then return end
    local diff = (lastplyang.y + 180) - (lp:EyeAngles().y + 180)
 
    if cmd:GetSideMove() == 0 then
        if diff > 0 then
            cmd:SetSideMove(1000)
        end
 
        if diff < 0 then
            cmd:SetSideMove(-1000)
        end
    end
 
    lastplyang = lp:EyeAngles()
end
 
local function aimassist(cmd)
    if cfg["nh_aimassist"] == 0 or not cmd:KeyDown(IN_ATTACK) then return end
    local fov = cfg["nh_aimassist_fov"]
    local localpos = lp:EyePos()
    local v, matrix, pos, diff, shootang, scrpos, dist = 0, 0, 0, 0, 0, 0, 0
    local closest_angle = math.huge
    local closest_dist = math.huge
 
    for i = 1, playerentities_len do
        v = playerentities[i]
        if not v:IsValid() or v == lp or not v:Alive() or v:Team() == TEAM_SPECTATOR or v:Health() <= 0 or v:IsDormant() then continue end
        local bone = v:LookupBone("ValveBiped.Bip01_Head1")
        if bone == nil then continue end
        matrix = v:GetBoneMatrix(bone)
        if matrix == nil then continue end
        pos = matrix:GetTranslation() + Vector(0, 0, 3)
        diff = (pos - localpos)
        shootang = diff:Angle()
        -- calculate distance to crosshair in pixels cuz fuck trigonometry
        scrpos = pos:ToScreen()
        dist = math.abs(scr_w * 0.5 - scrpos.x) + math.abs(scr_h * 0.5 - scrpos.y)
 
        if dist < closest_dist then
            closest_dist = dist
            closest_angle = shootang
        end
    end
 
    if closest_dist < fov and closest_angle ~= math.huge then
        cmd:SetViewAngles(closest_angle)
    end
end
 
local function shottimer()
    local nextprimary = lp:GetActiveWeapon():GetNextPrimaryFire()
    local firerate = 5
 
    if lp:GetActiveWeapon().Primary and lp:GetActiveWeapon().Primary.Delay then
        firerate = lp:GetActiveWeapon().Primary.Delay
    end
 
    local shotdelay = nextprimary - CurTime()
    if shotdelay <= 0 then return end
    local color = fadecolor(green, red, (math.Clamp(shotdelay, 0, firerate) / firerate) * 100)
    draw.SimpleText(string.format("%.2fs", math.Clamp(shotdelay, 0, 10)), "DermaLarge", scr_w * 0.5, scr_h - 100, color, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
end
 
local function esp()
    if cfg["nh_esp"] == 0 then return end
    local perf = SysTime()
    surface.SetFont("TargetIDSmall") -- mby useless
    local espdist = cfg["nh_espdist"]
    local debug = cfg["nh_debug"]
    local origin, pos, omodel, model, text, wep, uid, min, max, diff, bottompos, v, color, weapon, material, distanceinmeters, lpdist, health, sex, rgbcolor, ypad = 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0
    local r, g, b = cfg["nh_esp_col_r"], cfg["nh_esp_col_g"], cfg["nh_esp_col_b"]
 
    -- Props
    for i = 1, propentities_len do
        if cfg["nh_propesp"] == 0 then break end -- cleaner than nesting
        v = propentities[i]
        if not v:IsValid() then continue end
        -- compute position and distance
        origin = v:GetPos()
        if origin == nullvec then continue end
        distanceinmeters = origin:Distance(lppos) / 52.49
        if distanceinmeters > espdist or (v:IsWeapon() and v:IsCarriedByLocalPlayer()) then continue end
        -- compute text        
        pos = origin:ToScreen()
        if not pos.visible or pos.x < 0 or pos.x > scr_w or pos.y < 0 or pos.y > scr_h then continue end
        text = v:GetClass()
        model = v:GetModel()
        material = v:GetMaterial()
        weapon = v:IsWeapon()
 
        if not v.esptext or debug == 2 then
            -- compute text
            if weapon then
                text = v:GetPrintName()
            else
                -- compute name from model
                text = model
 
                -- gay if fuckery but it works with low performance impact
                if text:sub(-10, -8) == "can" then
                    if material:sub(-8):sub(3) == "editup" then
                        text = material:sub(-10):sub(3):upper()
                    elseif material:sub(-8, -8) == "_" then
                        text = material:sub(-9):sub(3):upper()
                    else
                        text = material:sub(-8):sub(3):upper()
                    end
                end
            end
 
            if text:sub(-5) == "_name" then
                text = string.format("%s%s", text:sub(0, 1):upper(), text:sub(2, -6))
            end
 
            if text:len() <= 3 then
                text = text:upper()
            end
 
            -- replace text
            for d = 1, #prop_namedict do
                if (prop_namedict[d][1] == 0 and model == prop_namedict[d][2]) or (prop_namedict[d][1] == 1 and text == prop_namedict[d][2]) then
                    text = prop_namedict[d][3]
                end
            end
 
            sex = text:find("_")
 
            if sex then
                text = string.format("%s %s%s", text:sub(0, sex - 1), text[sex + 1]:upper(), text:sub(sex + 2))
            end
 
            v.esptext = text
        else
            text = v.esptext
        end
 
        if debug == 2 then
            text = string.format("%s %s", text, v:GetModel())
        else
            text = string.format("%s %02dm", text, distanceinmeters)
        end
 
        -- draw
        if cfg["nh_propesp_fancy"] == 1 then
            -- trick to color distance text without using unnecessary space calculations
            local xpos, _ = draw.SimpleText(text, "TargetIDSmall", pos.x, pos.y, weapon and white or propcol, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
            draw.SimpleText(string.format("%02dm", distanceinmeters), "TargetIDSmall", pos.x + xpos * 0.5, pos.y, fadecolor(green, red, distanceinmeters / espdist * 100), TEXT_ALIGN_RIGHT, TEXT_ALIGN_CENTER)
        else
            draw.SimpleText(text, "TargetIDSmall", pos.x, pos.y, weapon and fadecolor(green, red, distanceinmeters / espdist * 100) or propcol, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
        end
    end
 
    -- Players
    for i = 1, playerentities_len do
        v = playerentities[i]
        wep = v:GetActiveWeapon()
        uid = v:UserID()
 
        if player_weps[uid] ~= wep then
            psw(v, player_weps[uid], wep)
            player_weps[uid] = wep
        end
 
        if not v or v == lp or (not lp:Alive() and debug ~= 2 and not prophunt) then continue end
        min, max = v:WorldSpaceAABB()
        diff = max - min
        pos = (min + Vector(diff.x * .5, diff.y * .5, diff.z)):ToScreen()
        bottompos = (max - Vector(diff.x * .5, diff.y * .5, diff.z)):ToScreen()
        origin = v:GetPos()
        if not (pos.visible or pos.x < 0 or pos.x > scr_w or pos.y < 0 or pos.y > scr_h) and not (bottompos.visible or bottompos.x < 0 or bottompos.x > scr_w or bottompos.y < 0 or bottompos.y > scr_h) then continue end
        health = v:Health()
 
        if v:Team() == TEAM_SPECTATOR and v:GetObserverMode() == 6 then
            draw.SimpleText(string.format("(SPEC) %s", v:Name()), "TargetIDSmall", pos.x, pos.y, green, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
            continue
        end
 
        if prophunt and v:Team() == lp:Team() then continue end
        if health < 0 or not v:Alive() then continue end
        color = fadecolor(red, green, health)
        rgbcolor = getrgbcol(UnPredictedCurTime() * 100)
        _, ypad = draw.SimpleText(string.format("%i", health), "TargetIDSmall", pos.x, pos.y - 5, v:IsDormant() and dormant or color, TEXT_ALIGN_CENTER, TEXT_ALIGN_BOTTOM)
 
        if r >= 0 then
            color.r = r
        end
 
        if g >= 0 then
            color.g = g
        end
 
        if b >= 0 then
            color.b = b
        end
 
        if r == -2 then
            color.r = rgbcolor.r
        end
 
        if g == -2 then
            color.g = rgbcolor.g
        end
 
        if b == -2 then
            color.r = rgbcolor.b
        end
 
        --color = getcontrastcol_fast(color)
        if v:IsDormant() then
            color = dormant
        end
 
        if cfg["nh_esp_box"] == 1 and lp:GetObserverTarget() ~= v then
            cam.Start3D()
            render.DrawWireframeBox(origin, Angle(0, v:EyeAngles().y, 0), min - origin, max - origin, color)
            cam.End3D()
        end
 
        -- Name, Health, Dormant flag
        draw.SimpleText(string.format("%s %s", v:IsDormant() and "[D]" or "", v:Name()):Trim(), "TargetIDSmall", pos.x, pos.y - 5 - ypad, color, TEXT_ALIGN_CENTER, TEXT_ALIGN_BOTTOM)
        if lppos:Distance(origin) > 2624 then continue end -- over 50m away, dont draw wpnesp
        -- Weapon
        if not wep or not wep.PrintName then continue end
        text = wep:GetPrintName()
 
        if text:sub(-5) == "_name" then
            text = string.format("%s%s", text:sub(0, 1), text:sub(2, -6))
        end
 
        draw.SimpleText(text:Trim():upper(), "TargetIDSmall", bottompos.x, bottompos.y + 5, color, TEXT_ALIGN_CENTER, TEXT_ALIGN_TOP)
    end
 
    -- Tracked Entities
    for i = 1, #extraentities do
        v = extraentities[i]
        if not v:IsValid() then continue end
        origin = v:GetPos()
        pos = origin:ToScreen()
        if not pos.visible or pos.x < 0 or pos.x > scr_w or pos.y < 0 or pos.y > scr_h then continue end
        model = v:GetModel()
        omodel = model
        if not model then continue end
        text = ""
        model = string.match(model, "/[^/]*$")
        if not model then continue end
        model = model:sub(2, -5)
        text = model
        health = v:Health()
        if health < 0 then continue end
 
        for d = 1, #prop_namedict do
            if (prop_namedict[d][1] == 0 and model == prop_namedict[d][2]) or (prop_namedict[d][1] == 1 and text == prop_namedict[d][2]) then
                text = prop_namedict[d][3]
            end
        end
 
        lpdist = origin:Distance(lppos)
 
        for x = 1, #tracked_wpns do
            if omodel == tracked_wpns[x][2] and tracked_wpns[x][3] ~= nil then
                v.thrownby = tracked_wpns[x][3]
            end
        end
 
        if omodel == "models/weapons/w_c4_planted.mdl" then
            if not TTT2 or lp:IsTraitor() then continue end
            -- c4
            local expltime = v:GetExplodeTime() - CurTime()
 
            if expltime < 0 or expltime > 601 then
                expltime = -1
            end
 
            draw.SimpleText(string.format("%s (%02dm)", text, lpdist / 52.49):upper(), "TargetIDSmall", pos.x, pos.y, red, TEXT_ALIGN_CENTER, TEXT_ALIGN_BOTTOM)
            draw.SimpleText(string.format("%s%s", expltime == -1 and "IDLE" or string.format("T-%is", expltime), v.thrownby and string.format(" (%s)", v.thrownby:Name()) or ""), "TargetIDSmall", pos.x, pos.y, red, TEXT_ALIGN_CENTER, TEXT_ALIGN_TOP)
            continue
        end
 
        if health ~= 0 then
            draw.SimpleText(string.format("%03dHP%s", health, v.thrownby and string.format(" (%s)", v.thrownby:Name()) or ""), "TargetIDSmall", pos.x, pos.y + 5, red, TEXT_ALIGN_CENTER, TEXT_ALIGN_TOP)
        elseif v.thrownby then
            draw.SimpleText(v.thrownby:Name(), "TargetIDSmall", pos.x, pos.y + 5, red, TEXT_ALIGN_CENTER, TEXT_ALIGN_TOP)
        end
 
        draw.SimpleText(string.format("%s (%02dm)", text, lpdist / 52.49):upper(), "TargetIDSmall", pos.x, pos.y, red, TEXT_ALIGN_CENTER, TEXT_ALIGN_BOTTOM)
    end
 
    perftimers.esp = SysTime() - perf
end
 
local function hud()
    if cfg["nh_hud"] == 0 then return end
    local perf = SysTime()
    local color, ply, target, mode -- idek if this does anything for performance because luajit exists, and i kinda wanna remove it for style reasons but im lazy, might bench later
 
    if cfg["nh_bhop"] == 1 then
        local vel = lpvel
        --local vertvel = vel.z
        vel.z = 0
        color = fadecolor(red, green, (math.Clamp(vel:Length(), 0, 400) / 400) * 100)
 
        --draw.SimpleText(string.format("%d u/s, vert %d u/s", vel:Length(), vertvel), "ScoreboardDefault", scr_w * 0.5, scr_h - 200, color, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
        if vel:Length() ~= 0 then
            draw.SimpleText(string.format("%d u/s", vel:Length()), "ScoreboardDefault", scr_w * 0.5, scr_h - 200, color, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
        end
 
        --draw.SimpleText(string.format("%d u/s", vel:Length() - lastvel), "ScoreboardDefault", scr_w * 0.5, scr_h - 180, color, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
        if not lp:OnGround() and math.floor(nowvel - lastvel) ~= 0 then
            local txt = string.format("(+ %3d u/s)", nowvel - lastvel)
 
            -- retarded ik
            if txt ~= "(+ 0 u/s)" then
                draw.SimpleText(txt, "ScoreboardDefault", scr_w * 0.5, scr_h - 150, fadecolor(red, green, math.Clamp(nowvel - lastvel, -50, 50) + 50), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
            end
        end
    end
 
    pcall(shottimer)
    local x = 0
 
    for i = 1, playerentities_len do
        ply = playerentities_sorted[i]
        if not ply or ply == lp or not ply:Alive() or ply:Team() == TEAM_SPECTATOR then continue end
        color = fadecolor(red, green, ply:Health())
 
        if TTT2 and ply:IsDetective() then
            color = lightblue
        end
 
        if TTT2 and ply:IsTraitor() then
            color = red
        end
 
        if prophunt then
            color = ply:Team() == lp:Team() and green or red
        end
 
        draw.SimpleText(string.format("%03d %03dm %s", ply:Health(), ply.cumsexlizard / 52.49, ply:Name()), "TargetIDSmall", scr_w - 200, scr_h / 2 + x * 15, color)
        x = x + 1
    end
 
    if x ~= 0 then
        draw.SimpleText("HP   DIST  NAME", "TargetIDSmall", scr_w - 200, scr_h / 2 - 15, blue)
    end
 
    x = 0
 
    for i = 1, playerentities_len do
        --if not lp:Alive() then break end
        ply = playerentities_idsort[i]
        mode = ply:GetObserverMode()
        target = ply:GetObserverTarget()
        if not ply or ply == lp or ply:Alive() or ply:Team() ~= TEAM_SPECTATOR then continue end
 
        if target and target:IsPlayer() then
            draw.SimpleText(string.format("[%s]", ply:Team()), "TargetIDSmall", 10, (scr_h / 2 - 100) + x * 15, target == lp and red or green)
            draw.SimpleText(string.format("%s", ply:Name()), "TargetIDSmall", 80, (scr_h / 2 - 100) + x * 15, target == lp and red or green)
            draw.SimpleText(string.format(">  %s", target:Name()), "TargetIDSmall", 190, (scr_h / 2 - 100) + x * 15, target == lp and red or green)
            x = x + 1
        else
            draw.SimpleText(string.format("[%s]", ply:Team()), "TargetIDSmall", 10, (scr_h / 2 - 100) + x * 15, green)
            draw.SimpleText(string.format("%s", ply:Name()), "TargetIDSmall", 80, (scr_h / 2 - 100) + x * 15, green)
            x = x + 1
        end
    end
 
    if x ~= 0 then
        draw.SimpleText("Spectating", "TargetIDSmall", 10, scr_h / 2 - 115, lightblue)
    end
 
    if cfg["nh_debug"] < 1 then
        perftimers.hud = SysTime() - perf
 
        return
    end
 
    -- funny [censored]er pov keybind shit
    x = 10
    local ypos = 50
    draw.SimpleText("IN_ATTACK", "TargetIDSmall", x, scr_h / 2 + ypos, lp:KeyDown(IN_ATTACK) and green or red)
    draw.SimpleText("IN_JUMP", "TargetIDSmall", x, scr_h / 2 + ypos + 12 * 1, lp:KeyDown(IN_JUMP) and green or red)
    draw.SimpleText("IN_DUCK", "TargetIDSmall", x, scr_h / 2 + ypos + 12 * 2, lp:KeyDown(IN_DUCK) and green or red)
    draw.SimpleText("IN_FORWARD", "TargetIDSmall", x, scr_h / 2 + ypos + 12 * 3, lp:KeyDown(IN_FORWARD) and green or red)
    draw.SimpleText("IN_BACK", "TargetIDSmall", x, scr_h / 2 + ypos + 12 * 4, lp:KeyDown(IN_BACK) and green or red)
    draw.SimpleText("IN_USE", "TargetIDSmall", x, scr_h / 2 + ypos + 12 * 5, lp:KeyDown(IN_USE) and green or red)
    draw.SimpleText("IN_CANCEL", "TargetIDSmall", x, scr_h / 2 + ypos + 12 * 6, lp:KeyDown(IN_CANCEL) and green or red)
    draw.SimpleText("IN_MOVELEFT", "TargetIDSmall", x, scr_h / 2 + ypos + 12 * 7, lp:KeyDown(IN_MOVELEFT) and green or red)
    draw.SimpleText("IN_MOVERIGHT", "TargetIDSmall", x, scr_h / 2 + ypos + 12 * 8, lp:KeyDown(IN_MOVERIGHT) and green or red)
    draw.SimpleText("IN_ATTACK2", "TargetIDSmall", x, scr_h / 2 + ypos + 12 * 9, lp:KeyDown(IN_ATTACK2) and green or red)
    draw.SimpleText("IN_RELOAD", "TargetIDSmall", x, scr_h / 2 + ypos + 12 * 10, lp:KeyDown(IN_RELOAD) and green or red)
    draw.SimpleText("IN_SCORE", "TargetIDSmall", x, scr_h / 2 + ypos + 12 * 11, lp:KeyDown(IN_SCORE) and green or red)
    draw.SimpleText("IN_SPEED", "TargetIDSmall", x, scr_h / 2 + ypos + 12 * 12, lp:KeyDown(IN_SPEED) and green or red)
    draw.SimpleText("IN_WALK", "TargetIDSmall", x, scr_h / 2 + ypos + 12 * 13, lp:KeyDown(IN_WALK) and green or red)
    perftimers.hud = SysTime() - perf
end
 
local function chams()
    if cfg["nh_chams"] == 0 or lp:Team() == TEAM_SPECTATOR then return end
    cam.Start3D()
    local players = player.GetAll()
    local chammode = cfg["nh_chams_mode"]
    local chammode_xqz = cfg["nh_chams_mode_xqz"]
    local material = chamsmat
 
    -- calling setcolormodulation without overriding the model changes sleeve color nicely :)
    for i = 1, #players do
        local ply = players[i]
 
        if ply == lp then
            cam.IgnoreZ(true)
            ply:DrawModel()
            continue
        end
 
        if not ply or not ply:Alive() or ply:Team() == TEAM_SPECTATOR or ply:IsDormant() then continue end
        local health = ply:Health()
        local color = fadecolor(red, green, health)
        local rgbcolor = getrgbcol(UnPredictedCurTime() * 100)
 
        if chammode_xqz ~= -1 then
            cam.IgnoreZ(true)
            material = chamsmat_
            -- set material
            render.SuppressEngineLighting(false)
 
            if chammode_xqz == 0 then
                -- Normal
                render.MaterialOverride(material)
            elseif chammode_xqz == 1 then
                -- Flat
                render.SuppressEngineLighting(true)
                render.MaterialOverride(material)
            elseif chammode_xqz == 2 then
                -- Sleeve
                render.MaterialOverride(nil)
            elseif chammode_xqz == 3 then
                -- Glow
                render.MaterialOverride(chamsmat_glow)
            elseif chammode_xqz == 4 then
                --render.MaterialOverride(material)
                ply:DrawModel()
                continue
            end
 
            -- set color
            local r, g, b = cfg["nh_chams_col_xqz_r"], cfg["nh_chams_col_xqz_g"], cfg["nh_chams_col_xqz_b"]
 
            if r == -1 then
                r = color.r
            end
 
            if g == -1 then
                g = color.g
            end
 
            if b == -1 then
                b = color.b
            end
 
            if r == -2 then
                r = rgbcolor.r
            end
 
            if g == -2 then
                g = rgbcolor.g
            end
 
            if b == -2 then
                b = rgbcolor.b
            end
 
            -- teammate chams
            if TTT2 and ((ply:IsTraitor() and lp:IsTraitor()) or (ply:GetTeam() == "traitors" and ply:GetTeam() == lp:GetTeam()) or (ply:IsDetective() and lp:IsInnocent())) then
                r = 0
                g = 0
                b = 255
            end
 
            r = r / 255
            g = g / 255
            b = b / 255
 
            if chammode_xqz == 3 then
                chamsmat_glow:SetVector("$envmaptint", Vector(r, g, b))
            else
                render.SetColorModulation(r, g, b)
            end
 
            -- draw model
            ply:DrawModel()
            render.MaterialOverride(nil)
        end
 
        if chammode ~= -1 then
            cam.IgnoreZ(false)
            material = chamsmat
            -- set material
            render.SuppressEngineLighting(false)
 
            if chammode == 0 then
                -- Normal
                render.MaterialOverride(material)
            elseif chammode == 1 then
                -- Flat
                render.SuppressEngineLighting(true)
                render.MaterialOverride(material)
            elseif chammode == 2 then
                -- Sleeve
                render.MaterialOverride(nil)
            elseif chammode == 3 then
                -- Glow
                render.MaterialOverride(chamsmat_glow)
            end
 
            -- set color
            local r, g, b = cfg["nh_chams_col_r"], cfg["nh_chams_col_g"], cfg["nh_chams_col_b"]
 
            if r == -1 then
                r = color.r
            end
 
            if g == -1 then
                g = color.g
            end
 
            if b == -1 then
                b = color.b
            end
 
            if r == -2 then
                r = rgbcolor.r
            end
 
            if g == -2 then
                g = rgbcolor.g
            end
 
            if b == -2 then
                b = rgbcolor.b
            end
 
            -- teammate chams
            if TTT2 and ((ply:IsTraitor() and lp:IsTraitor()) or (ply:GetTeam() == "traitors" and ply:GetTeam() == lp:GetTeam()) or (ply:IsDetective() and lp:IsInnocent())) then
                r = 0
                g = 0
                b = 255
            end
 
            r = r / 255
            g = g / 255
            b = b / 255
 
            if chammode == 3 then
                chamsmat_glow:SetVector("$envmaptint", Vector(r, g, b))
            else
                render.SetColorModulation(r, g, b)
            end
 
            -- draw model
            ply:DrawModel()
            render.MaterialOverride(nil)
        end
    end
 
    cam.IgnoreZ(false)
    render.SuppressEngineLighting(false)
    cam.End3D()
end
 
local function vmchams(vm, ply, wep)
    local mode = cfg["nh_vmchams_mode"]
    if mode == -1 then return end
 
    if mode == 1 then
        render.MaterialOverride(chamsmat)
        render.SuppressEngineLighting(true)
    elseif mode == 2 then
        render.MaterialOverride(chamsmat)
        render.SuppressEngineLighting(false)
    end
 
    local r, g, b = cfg["nh_vmchams_col_r"], cfg["nh_vmchams_col_g"], cfg["nh_vmchams_col_b"]
    local health = 0
 
    if lp:Alive() then
        health = lp:Health()
    elseif lp:GetObserverTarget():IsValid() then
        health = lp:GetObserverTarget():Health()
    end
 
    local healthcolor = fadecolor(red, green, health)
    local rgbcolor = getrgbcol(UnPredictedCurTime() * 100)
 
    if r == -1 and lp:Alive() then
        r = healthcolor.r
    end
 
    if g == -1 and lp:Alive() then
        g = healthcolor.g
    end
 
    if b == -1 and lp:Alive() then
        b = healthcolor.b
    end
 
    if r == -2 then
        r = rgbcolor.r
    end
 
    if g == -2 then
        g = rgbcolor.g
    end
 
    if b == -2 then
        b = rgbcolor.b
    end
 
    render.SetColorModulation(r / 255, g / 255, b / 255)
end
 
local function sort_dist(a, b)
    return a.cumsexfuckman < b.cumsexfuckman
end
 
local function sort_id(a, b)
    return a.cumsexuid < b.cumsexuid
end
 
-- hook funcs
local function cm(cmd)
    local perf = SysTime()
    if not LocalPlayer() then return end
    lp = LocalPlayer()
    local _playerentities = {}
    local players = player.GetAll()
    local plylen = 0
 
    for i = 1, #players do
        _playerentities[plylen + 1] = players[i]
        plylen = plylen + 1
        players[i].cumsexlizard = players[i]:GetPos():Distance(lppos)
        players[i].cumsexfuckman = math.floor(players[i].cumsexlizard) -- why dumb down cached data? because.
        players[i].cumsexuid = players[i]:UserID()
    end
 
    playerentities = _playerentities
    playerentities_sorted = _playerentities
    playerentities_idsort = _playerentities
    playerentities_len = #playerentities
    table.sort(playerentities_sorted, sort_dist) -- may seem simply retarded, but it isnt
    table.sort(playerentities_idsort, sort_id)
    if not lp:Alive() then return end
    bhop(cmd)
    norecoil(cmd)
    aimassist(cmd)
    pcall(firefixer, cmd)
    strafehelper(cmd)
 
    --tttfixes(cmd)
    if cfg["nh_noviewpunch"] == 1 then
        lp:ViewPunchReset(0)
    end
 
    perftimers.cm = SysTime() - perf
end
 
local function drov()
    hud()
end
 
local function hudpaint()
    if not LocalPlayer() then return end
    lp = LocalPlayer()
    scr_w = ScrW()
    scr_h = ScrH()
    esp()
    --hud()
    if cfg["nh_debug"] == 0 then return end
    draw.SimpleTextOutlined(string.format("CreateMove   %.7fs", perftimers.cm), "DebugFixed", 100, 80, white, TEXT_ALIGN_LEFT, TEXT_ALIGN_LEFT, 1, black)
    draw.SimpleTextOutlined(string.format("EntityUpdate %.7fs/s", perftimers.eu * cfg["nh_updatespersec"]), "DebugFixed", 100, 100, white, TEXT_ALIGN_LEFT, TEXT_ALIGN_LEFT, 1, black)
    draw.SimpleTextOutlined(string.format("[HP] ESP     %.7fs", perftimers.esp), "DebugFixed", 100, 120, white, TEXT_ALIGN_LEFT, TEXT_ALIGN_LEFT, 1, black)
    draw.SimpleTextOutlined(string.format("[DO] HUD     %.7fs", perftimers.hud), "DebugFixed", 100, 140, white, TEXT_ALIGN_LEFT, TEXT_ALIGN_LEFT, 1, black)
    if cfg["nh_debug"] ~= 2 then return end
    draw.SimpleTextOutlined(string.format("Entities     %i", #propentities), "DebugFixed", 100, 180, white, TEXT_ALIGN_LEFT, TEXT_ALIGN_LEFT, 1, black)
    draw.SimpleTextOutlined(string.format("Lua Memory   %07dkb", collectgarbage("count")), "DebugFixed", 100, 200, white, TEXT_ALIGN_LEFT, TEXT_ALIGN_LEFT, 1, black)
end
 
local function cv(ply, origin, angles, fov, znear, zfar)
    local view = {
        origin = origin,
        angles = angles,
        fov = fov,
        drawviewer = false
    }
 
    normalizeangle(view.angles)
 
    if cfg["nh_fov"] == 1 then
        view.fov = cfg["nh_fov"]
    end
 
    if cfg["nh_thirdperson"] == 1 and lp:Alive() then
        view.origin = origin - (angles:Forward() * cfg["nh_thirdperson_dist"])
        view.drawviewer = true
    end
 
    return view
end
 
local function prdor()
    local perf = SysTime()
    local players = player.GetAll()
    lppos = lp:GetPos()
    lpvel = lp:GetAbsVelocity()
 
    for i = 1, #players do
        local ply = players[i]
        if not ply or ply == lp or ply:IsDormant() or not ply:Alive() then continue end
        local angles = ply:EyeAngles()
        --ply:AddEffects(EF_NOINTERP)
        normalizeangle(angles)
        ply:SetPoseParameter("aim_pitch", angles.x)
        ply:InvalidateBoneCache()
    end
 
    for i = 1, #blacklisted_hooks do
        hook.Remove(blacklisted_hooks[i][1], blacklisted_hooks[i][2])
    end
 
    --safecall3d(chams)
    perftimers.pdor = perf - SysTime()
end
 
local function podor()
    safecall3d(chams)
end
 
local function hurthandler(data)
    local attacker = Player(data.attacker)
 
    if attacker == lp and data.health <= 0 then
        surface.PlaySound("death.wav")
    elseif attacker == lp and data.health > 0 then
        surface.PlaySound("hit.wav")
    end
end
 
local function prdvm(vm, ply, wep)
    cam.IgnoreZ(true)
    vmchams(vm, ply, wep)
end
 
local function podvm(vm, ply, wep)
    cam.IgnoreZ(false)
    render.MaterialOverride(nil)
    render.SuppressEngineLighting(false)
end
 
local function rsse()
end
 
local function pde()
    --safecall3d(chams)
end
 
local function ees(t)
end
 
local function ossc(oldx, oldy)
    scr_w = ScrW()
    scr_h = ScrH()
end
 
local cvarobjs = {
    -- cvarname, default, helptext, min, max, cvar object
    {"nh_autofire", "0", "", "0", "1", nil},
    {"nh_autostrafe", "0", "", "0", "1", nil},
    {"nh_aimassist", "0", "", "0", "1", nil},
    {"nh_aimassist_fov", "1", "", "0", "180", nil},
    {"nh_bhop", "1", "", "0", "1", nil},
    {"nh_chams", "1", "", "0", "1", nil},
    {"nh_chams_col_r", "-1", "-2 - RGB, -1 - Health, 0-255 R Color", "-2", "255", nil},
    {"nh_chams_col_g", "-1", "-2 - RGB, -1 - Health, 0-255 G Color", "-2", "255", nil},
    {"nh_chams_col_b", "-1", "-2 - RGB, -1 - Health, 0-255 B Color", "-2", "255", nil},
    {"nh_chams_col_xqz_r", "-1", "-2 - RGB, -1 - Health, 0-255 R Color", "-2", "255", nil},
    {"nh_chams_col_xqz_g", "-1", "-2 - RGB, -1 - Health, 0-255 G Color", "-2", "255", nil},
    {"nh_chams_col_xqz_b", "-1", "-2 - RGB, -1 - Health, 0-255 B Color", "-2", "255", nil},
    {"nh_chams_mode", "-1", "-1 - Off, 0 - Normal, 1 - Flat, 2 - Sleeve, 3 - Glow", "-1", "3", nil},
    {"nh_chams_mode_xqz", "-1", "-1 - Off, 0 - Normal, 1 - Flat, 2 - Sleeve, 3 - Glow, 4 - IgnoreZ", "-1", "4", nil},
    {"nh_debug", "0", "", "0", "2", nil},
    {"nh_esp", "1", "", "0", "1", nil},
    {"nh_esp_box", "0", "", "0", "1", nil},
    {"nh_esp_col_r", "-1", "-2 - RGB, -1 - Health, 0-255 R Color", "-2", "255"},
    {"nh_esp_col_g", "-1", "-2 - RGB, -1 - Health, 0-255 G Color", "-2", "255"},
    {"nh_esp_col_b", "-1", "-2 - RGB, -1 - Health, 0-255 B Color", "-2", "255"},
    {"nh_espdist", "50", "", "0", "400", nil},
    {"nh_fov", "0", "", "0", "130", nil},
    {"nh_hud", "1", "", "0", "1", nil},
    {"nh_norecoil", "0", "", "0", "1", nil},
    {"nh_noviewpunch", "0", "", "0", "1", nil},
    {"nh_propesp", "1", "", "0", "1", nil},
    {"nh_propesp_fancy", "0", "", "0", "1", nil},
    {"nh_thirdperson", "0", "", "0", "1", nil},
    {"nh_thirdperson_dist", "120", "", "0", "400", nil},
    {"nh_vmchams_mode", "-1", "-1 - Off, 0 - Modulate, 1 - Flat, 2 - Cham", "-1", "2", nil},
    {"nh_vmchams_col_r", "-1", "-2 - RGB, -1 - Health, 0-255 R Color", "-2", "255", nil},
    {"nh_vmchams_col_g", "-1", "-2 - RGB, -1 - Health, 0-255 G Color", "-2", "255", nil},
    {"nh_vmchams_col_b", "-1", "-2 - RGB, -1 - Health, 0-255 B Color", "-2", "255", nil},
    {"nh_updatespersec", "16", "", "1", "128"}
}
 
local hooks = {
    {"CreateMove", cm},
    {"CalcView", cv},
    {"DrawOverlay", drov}, -- if youre a casual with r_drawvgui set to 0 use PostDrawHUD instead
    {"EntityEmitSound", ees},
    {"HUDPaint", hudpaint},
    {"PreDrawOpaqueRenderables", prdor},
    {"PostDrawOpaqueRenderables", podor},
    {"PreDrawViewModel", prdvm},
    {"PostDrawViewModel", podvm},
    {"PreDrawPlayerHands", prdvm},
    {"PostDrawPlayerHands", podvm},
    {"PostDrawEffects", pde},
    {"RenderScreenspaceEffects", rsse},
    {"OnScreenSizeChanged", ossc},
    {"player_hurt", hurthandler}
}
 
local function unload()
    -- remove hooks
    for i = 1, #hooks do
        hook.Remove(hooks[i][1], hookkey)
    end
 
    -- remove cvar callbacks
    for i = 1, #cvarobjs do
        local v = cvarobjs[i]
        cvars.RemoveChangeCallback(v[1], v[1])
    end
 
    cfg = {}
    cvars.RemoveChangeCallback("nh_updatespersec", "updateents")
    timer.Remove("nh_entupdate")
end
 
local function load()
    unload()
    -- GameEvents
    gameevent.Listen("player_hurt")
    -- ConCommands
    concommand.Add("nh_unload", unload, nil, nil, 0)
    cfg = {}
 
    -- CVar Callbacks
    for i = 1, #cvarobjs do
        -- Create CVar
        local v = cvarobjs[i]
        v[6] = CreateClientConVar(v[1], v[2], true, false, v[3], v[4], v[5])
 
        -- Add Callback
        cvars.AddChangeCallback(v[1], function(cvar, old, new)
            cfg[cvar] = tonumber(new)
        end, v[1])
 
        -- Populate CVar
        cfg[v[1]] = v[6]:GetInt()
    end
 
    -- Manual CVar Callbacks
    cvars.AddChangeCallback("nh_updatespersec", function(cvar, old, new)
        timer.Remove("nh_entupdate")
        timer.Create("nh_entupdate", 1 / new, 0, entityupdate)
    end, "updateents")
 
    -- Timers
    timer.Create("nh_entupdate", 1 / cfg["nh_updatespersec"], 0, entityupdate)
 
    -- Hooks
    for i = 1, #hooks do
        hook.Add(hooks[i][1], hookkey, hooks[i][2])
    end
 
    local x, _ = jit.status()
 
    if x == false then
        notification.AddLegacy("JIT was not enabled!!", NOTIFY_ERROR, 3)
        jit.on()
    end
 
    jit.opt.start(3)
    --jit.opt.start("sizemcode=81920", "maxmcode=819200")
    -- Other stuff
    entityupdate()
    notification.AddLegacy("nicepersonhook loaded", NOTIFY_HINT, 3)
    print("nicepersonhook loaded, gmod is running " .. jit.version)
end
 
load()