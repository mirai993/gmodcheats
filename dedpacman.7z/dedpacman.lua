-- Dedpacman.lua

if SERVER then
    AddCSLuaFile()
end

if CLIENT then
    surface.CreateFont("DedpacmanFont", {
        font = "Arial",
        size = 16,
        weight = 600,
    })

    local config = {
        aimbot = false,
        aimbot_key = KEY_F,
        enable_smoothing = false,
        smoothing = 0.1,
        bone_selection = "Head",
        hitscan = false,
        autofire = false,
        vischeck = false,
        target_npcs = false,
        target_players = false,
        ignore_team = true,
        fov = 90,
        show_fov_circle = false,
        triggerbot = false,
        triggerbot_key = KEY_T,
        bunnyhop = false,
        auto_pistol = false,
        esp = false,
        esp_team = true,
        esp_enemies = true,
        esp_npcs = true,
        esp_3d_box = false,
        esp_2d_box = true,
        esp_names = true,
        esp_weapon = true,
        esp_distance = true,
        esp_health = true,
        esp_skeleton = false,
        crosshair = false,
        entities_esp = false,
        spectator_box = false,
        silent_aimbot = false,
        no_recoil = false,
        no_spread = false,
        ttt_traitor_finder = false,
        sound_esp = false,
    }

    local bones = {
        "Head",
        "Body",
        "Left Arm",
        "Right Arm",
        "Left Leg",
        "Right Leg"
    }

    local boneMapping = {
        ["Head"] = "ValveBiped.Bip01_Head1",
        ["Body"] = "ValveBiped.Bip01_Spine",
        ["Left Arm"] = "ValveBiped.Bip01_L_UpperArm",
        ["Right Arm"] = "ValveBiped.Bip01_R_UpperArm",
        ["Left Leg"] = "ValveBiped.Bip01_L_Thigh",
        ["Right Leg"] = "ValveBiped.Bip01_R_Thigh"
    }

    local mouseKeys = {
        MOUSE_LEFT = MOUSE_LEFT,
        MOUSE_RIGHT = MOUSE_RIGHT,
        MOUSE_4 = MOUSE_4,
        MOUSE_5 = MOUSE_5
    }

    local highlightedPlayers = {}

    local function saveConfig()
        file.Write("dedpacman_config.txt", util.TableToJSON(config))
    end

    local function loadConfig()
        if file.Exists("dedpacman_config.txt", "DATA") then
            config = util.JSONToTable(file.Read("dedpacman_config.txt", "DATA"))
        end
    end

    loadConfig()

    local function getKeyName(key)
        for k, v in pairs(_G) do
            if string.sub(k, 1, 4) == "KEY_" and v == key then
                return k
            elseif mouseKeys[k] == key then
                return k
            end
        end
        return "UNKNOWN"
    end

    local function getBonePosition(ent, boneName)
        local bone = ent:LookupBone(boneMapping[boneName])
        if bone then
            return ent:GetBonePosition(bone)
        else
            return ent:GetPos() + ent:OBBCenter()
        end
    end

    local function aimbot()
        local target = nil
        local fov = config.fov
        local closestAngle = fov
        for _, ply in pairs(player.GetAll()) do
            if ply != LocalPlayer() and ((config.target_players and ply:IsPlayer() and (not config.ignore_team or ply:Team() ~= LocalPlayer():Team())) or (config.target_npcs and ply:IsNPC())) then
                if config.vischeck and not ply:Visible(LocalPlayer()) then
                    continue
                end
                local angle = (ply:GetPos() - LocalPlayer():GetPos()):Angle()
                local diff = math.abs(math.AngleDifference(LocalPlayer():EyeAngles().y, angle.y))
                if diff < closestAngle then
                    target = ply
                    closestAngle = diff
                end
            end
        end
        if target then
            local aimPos = getBonePosition(target, config.bone_selection)
            local aimAngle = (aimPos - LocalPlayer():GetShootPos()):Angle()
            if config.silent_aimbot then
                -- Silent aimbot: modify bullet trajectory instead of view angles
                hook.Add("EntityFireBullets", "SilentAimbot", function(ent, data)
                    if ent == LocalPlayer() then
                        data.Dir = (aimPos - data.Src):GetNormalized()
                        return true
                    end
                end)
            else
                hook.Remove("EntityFireBullets", "SilentAimbot")
                if config.enable_smoothing and config.smoothing > 0 then
                    local currentAngle = LocalPlayer():EyeAngles()
                    local diff = aimAngle - currentAngle
                    aimAngle = currentAngle + diff * config.smoothing
                end
                LocalPlayer():SetEyeAngles(aimAngle)
            end
            if config.autofire then
                RunConsoleCommand("+attack")
            end
        else
            RunConsoleCommand("-attack")
        end
    end

    local function triggerbot()
        local target = LocalPlayer():GetEyeTrace().Entity
        if IsValid(target) and target:IsPlayer() and target != LocalPlayer() then
            RunConsoleCommand("+attack")
        else
            RunConsoleCommand("-attack")
        end
    end

    local function bunnyhop()
        if LocalPlayer():IsOnGround() then
            RunConsoleCommand("+jump")
            timer.Simple(math.Rand(0.01, 0.1), function()
                if LocalPlayer():IsOnGround() then
                    RunConsoleCommand("-jump")
                end
            end)
        end
    end

    local function autoPistol()
        local weapon = LocalPlayer():GetActiveWeapon()
        if IsValid(weapon) and weapon:GetClass() == "weapon_pistol" then
            RunConsoleCommand("+attack")
            timer.Simple(0.1, function() RunConsoleCommand("-attack") end)
        end
    end

    local function drawESP()
        for _, ply in pairs(player.GetAll()) do
            if ply != LocalPlayer() and ((ply:IsPlayer() and (config.esp_team or ply:Team() ~= LocalPlayer():Team())) or (config.esp_npcs and ply:IsNPC())) then
                local min, max = ply:OBBMins(), ply:OBBMaxs()
                local corners = {
                    ply:LocalToWorld(min):ToScreen(),
                    ply:LocalToWorld(Vector(min.x, max.y, min.z)):ToScreen(),
                    ply:LocalToWorld(Vector(max.x, max.y, min.z)):ToScreen(),
                    ply:LocalToWorld(Vector(max.x, min.y, min.z)):ToScreen(),
                    ply:LocalToWorld(Vector(min.x, min.y, max.z)):ToScreen(),
                    ply:LocalToWorld(Vector(min.x, max.y, max.z)):ToScreen(),
                    ply:LocalToWorld(max):ToScreen(),
                    ply:LocalToWorld(Vector(max.x, min.y, max.z)):ToScreen()
                }
                local xCoords, yCoords = {}, {}
                for _, corner in pairs(corners) do
                    table.insert(xCoords, corner.x)
                    table.insert(yCoords, corner.y)
                end
                local minX, maxX = math.min(unpack(xCoords)), math.max(unpack(xCoords))
                local minY, maxY = math.min(unpack(yCoords)), math.max(unpack(yCoords))

                if config.esp_2d_box then
                    surface.SetDrawColor(255, 0, 0, 255)
                    surface.DrawOutlinedRect(minX, minY, maxX - minX, maxY - minY)
                end
                if config.esp_names then
                    draw.SimpleText(ply:Nick(), "DedpacmanFont", (minX + maxX) / 2, minY - 20, Color(255, 255, 255), TEXT_ALIGN_CENTER)
                end
                if config.esp_health then
                    draw.SimpleText("HP: " .. ply:Health(), "DedpacmanFont", (minX + maxX) / 2, minY - 5, Color(0, 255, 0), TEXT_ALIGN_CENTER)
                end
                if config.esp_weapon then
                    local weapon = ply:GetActiveWeapon()
                    if IsValid(weapon) then
                        draw.SimpleText(weapon:GetClass(), "DedpacmanFont", (minX + maxX) / 2, maxY + 5, Color(255, 255, 0), TEXT_ALIGN_CENTER)
                    end
                end
                if config.esp_skeleton then
                    for _, bone in pairs(boneMapping) do
                        local bonePos, _ = ply:GetBonePosition(ply:LookupBone(bone))
                        local bonePosScreen = bonePos:ToScreen()
                        surface.SetDrawColor(0, 255, 0, 255)
                        surface.DrawRect(bonePosScreen.x - 2, bonePosScreen.y - 2, 4, 4)
                    end
                end
            end
        end
    end

    local function drawEntitiesESP()
        for _, ent in pairs(ents.GetAll()) do
            if ent:IsWeapon() or ent:IsNPC() then
                local pos = ent:GetPos():ToScreen()
                draw.SimpleText(ent:GetClass(), "DedpacmanFont", pos.x, pos.y, Color(255, 255, 255), TEXT_ALIGN_CENTER)
            end
        end
    end

    local function drawCrosshair()
        surface.SetDrawColor(0, 255, 0, 255)
        surface.DrawLine(ScrW() / 2 - 10, ScrH() / 2, ScrW() / 2 + 10, ScrH() / 2)
        surface.DrawLine(ScrW() / 2, ScrH() / 2 - 10, ScrW() / 2, ScrH() / 2 + 10)
    end

    local function drawSpectatorBox()
        local spectators = {}
        for _, ply in pairs(player.GetAll()) do
            if ply:GetObserverTarget() == LocalPlayer() then
                table.insert(spectators, ply:Nick())
            end
        end
        draw.SimpleText("Spectators: " .. table.concat(spectators, ", "), "DedpacmanFont", ScrW() / 2, ScrH() - 20, Color(255, 255, 255), TEXT_ALIGN_CENTER)
    end

    local function noRecoil()
        hook.Add("EntityFireBullets", "NoRecoil", function(ent, data)
            if ent == LocalPlayer() then
                data.Spread = vector_origin
            end
        end)
    end

    local function noSpread()
        hook.Add("SetupMove", "NoSpread", function(ply, mv, cmd)
            if ply == LocalPlayer() then
                cmd:SetViewAngles(cmd:GetViewAngles() - ply:GetViewPunchAngles())
            end
        end)
    end

    local function tttTraitorFinder()
        local matOverlay = Material("sprites/glow08")
        local matTraitor = Material("sprites/dot")
        local twep = {"spiderman's_swep", "weapon_ttt_trait_defilibrator", "weapon_ttt_xbow", "weapon_ttt_dhook", "weapon_awp", "weapon_ttt_ak47", "weapon_jihadbomb", "weapon_ttt_knife", "weapon_ttt_c4", "weapon_ttt_decoy", "weapon_ttt_flaregun", "weapon_ttt_phammer", "weapon_ttt_push", "weapon_ttt_radio", "weapon_ttt_sipistol", "weapon_ttt_teleport", "weapon_ttt_awp", "weapon_mad_awp", "weapon_real_cs_g3sg1", "weapon_ttt_cvg_g3sg1", "weapon_ttt_g3sg1", "weapon_ttt_healthstation5", "weapon_ttt_sentry", "weapon_ttt_poison_dart", "weapon_ttt_trait_defibrillator"}

        for _, v in pairs(player.GetAll()) do
            v.HatTraitor = nil
        end
        for _, v in pairs(ents.GetAll()) do
            v.HatESPTracked = nil
        end

        hook.Add("PostDrawOpaqueRenderables", "wire_animations_idle", function()
            if GAMEMODE.round_state != ROUND_ACTIVE then
                for _, v in pairs(player.GetAll()) do
                    v.HatTraitor = nil
                end
                for _, v in pairs(ents.GetAll()) do
                    v.HatESPTracked = nil
                end
                return
            end
            for _, v in pairs(ents.GetAll()) do
                if v and IsValid(v) and (table.HasValue(twep, v:GetClass()) and not v.HatESPTracked) then
                    local pl = v.Owner
                    if pl and IsValid(pl) and pl:IsTerror() then
                        if pl:IsDetective() then
                            v.HatESPTracked = true
                        else
                            v.HatESPTracked = true
                            pl.HatTraitor = true
                            chat.AddText(pl, Color(255, 125, 0), " is a ", Color(255, 0, 0), "TRAITOR", Color(255, 125, 0), " with a ", Color(255, 0, 0), v:GetClass() .. "!")
                        end
                    end
                end
            end
        end)
    end

    hook.Add("PlayerFootstep", "CustomFootstep", function(ply, pos, foot, sound, volume, rf)
        if not ply:IsPlayer() then return end
        if ply:Crouching() then return end

        ply:EmitSound("NPC_Hunter.Footstep")
        highlightedPlayers[ply] = CurTime() + 1
        return true
    end)

    hook.Add("PreDrawHalos", "AddPlayerHalos", function()
        local currentTime = CurTime()
        for ply, expireTime in pairs(highlightedPlayers) do
            if currentTime > expireTime then
                highlightedPlayers[ply] = nil
            else
                halo.Add({ply}, Color(255, 0, 0), 1, 1, 1, true, true)
            end
        end
    end)

    hook.Add("Think", "DedpacmanThink", function()
        if input.IsKeyDown(config.aimbot_key) and config.aimbot then
            aimbot()
        end
        if input.IsKeyDown(config.triggerbot_key) and config.triggerbot then
            triggerbot()
        end
        if config.bunnyhop and input.IsKeyDown(KEY_SPACE) then
            bunnyhop()
        end
        if config.auto_pistol and input.IsMouseDown(MOUSE_LEFT) then
            autoPistol()
        end
        if config.no_recoil then
            noRecoil()
        else
            hook.Remove("EntityFireBullets", "NoRecoil")
        end
        if config.no_spread then
            noSpread()
        else
            hook.Remove("SetupMove", "NoSpread")
        end
        if config.ttt_traitor_finder then
            tttTraitorFinder()
        else
            hook.Remove("PostDrawOpaqueRenderables", "wire_animations_idle")
        end
        if not config.sound_esp then
            hook.Remove("PlayerFootstep", "CustomFootstep")
            hook.Remove("PreDrawHalos", "AddPlayerHalos")
        end
    end)

    hook.Add("HUDPaint", "DedpacmanESP", function()
        if config.esp then
            drawESP()
        end
        if config.crosshair then
            drawCrosshair()
        end
        if config.entities_esp then
            drawEntitiesESP()
        end
    end)

    hook.Add("HUDPaint", "DedpacmanSpectatorBox", function()
        if config.spectator_box then
            drawSpectatorBox()
        end
    end)

    hook.Add("HUDPaint", "DrawFOVCircle", function()
        if config.show_fov_circle and config.aimbot then
            surface.SetDrawColor(0, 255, 0, 255)
            surface.DrawCircle(ScrW() / 2, ScrH() / 2, config.fov * 10, 0, 255, 0, 255)
        end
    end)

    concommand.Add("dedpacman_menu", function()
        local frame = vgui.Create("DFrame")
        frame:SetTitle("Dedpacman")
        frame:SetSize(500, 600)
        frame:Center()
        frame:MakePopup()
        frame.Paint = function(self, w, h)
            draw.RoundedBox(8, 0, 0, w, h, Color(50, 50, 50, 255))
        end

        local propertySheet = vgui.Create("DPropertySheet", frame)
        propertySheet:Dock(FILL)

        local function addCheckbox(parent, label, var)
            local checkbox = vgui.Create("DCheckBoxLabel", parent)
            checkbox:SetText(label)
            checkbox:SetValue(config[var])
            checkbox:Dock(TOP)
            checkbox:DockMargin(10, 5, 10, 5)
            checkbox.OnChange = function(_, val)
                config[var] = val
                saveConfig()
            end
        end

        local function addKeySelection(parent, label, var)
            local labelControl = vgui.Create("DLabel", parent)
            labelControl:SetText(label)
            labelControl:Dock(TOP)
            labelControl:DockMargin(10, 5, 10, 5)

            local keyBox = vgui.Create("DComboBox", parent)
            keyBox:Dock(TOP)
            keyBox:DockMargin(10, 5, 10, 5)
            for k, v in pairs(_G) do
                if string.sub(k, 1, 4) == "KEY_" or mouseKeys[k] then
                    keyBox:AddChoice(k, v)
                end
            end
            keyBox:SetValue(getKeyName(config[var]))
            keyBox.OnSelect = function(_, _, value, data)
                config[var] = data
                saveConfig()
            end
        end

        local function addBoneSelection(parent, label, var)
            local labelControl = vgui.Create("DLabel", parent)
            labelControl:SetText(label)
            labelControl:Dock(TOP)
            labelControl:DockMargin(10, 5, 10, 5)

            local boneBox = vgui.Create("DComboBox", parent)
            boneBox:Dock(TOP)
            boneBox:DockMargin(10, 5, 10, 5)
            for _, bone in pairs(bones) do
                boneBox:AddChoice(bone)
            end
            boneBox:SetValue(config[var])
            boneBox.OnSelect = function(_, _, value)
                config[var] = value
                saveConfig()
            end
        end

        local function addSlider(parent, label, var, min, max, decimals)
            local labelControl = vgui.Create("DLabel", parent)
            labelControl:SetText(label)
            labelControl:Dock(TOP)
            labelControl:DockMargin(10, 5, 10, 5)

            local slider = vgui.Create("DNumSlider", parent)
            slider:Dock(TOP)
            slider:DockMargin(10, 5, 10, 5)
            slider:SetMin(min)
            slider:SetMax(max)
            slider:SetDecimals(decimals)
            slider:SetValue(config[var])
            slider.OnValueChanged = function(_, value)
                config[var] = value
                saveConfig()
            end
        end

        local aimbotPanel = vgui.Create("DPanel", propertySheet)
        aimbotPanel:Dock(FILL)
        aimbotPanel:DockPadding(10, 10, 10, 10)
        aimbotPanel.Paint = function(self, w, h)
            draw.RoundedBox(8, 0, 0, w, h, Color(30, 30, 30, 255))
        end
        propertySheet:AddSheet("Aimbot", aimbotPanel, "icon16/user.png")

        addCheckbox(aimbotPanel, "Aimbot", "aimbot")
        addKeySelection(aimbotPanel, "Aimbot Key", "aimbot_key")
        addCheckbox(aimbotPanel, "Enable Smoothing", "enable_smoothing")
        addSlider(aimbotPanel, "Smoothing", "smoothing", 0, 1, 2)
        addBoneSelection(aimbotPanel, "Bone Selection", "bone_selection")
        addSlider(aimbotPanel, "FOV", "fov", 1, 180, 0)
        addCheckbox(aimbotPanel, "Show FOV Circle", "show_fov_circle")
        addCheckbox(aimbotPanel, "Silent Aimbot", "silent_aimbot")
        addCheckbox(aimbotPanel, "Hitscan", "hitscan")
        addCheckbox(aimbotPanel, "Autofire", "autofire")
        addCheckbox(aimbotPanel, "Visibility Check", "vischeck")

        local triggerbotPanel = vgui.Create("DPanel", propertySheet)
        triggerbotPanel:Dock(FILL)
        triggerbotPanel:DockPadding(10, 10, 10, 10)
        triggerbotPanel.Paint = function(self, w, h)
            draw.RoundedBox(8, 0, 0, w, h, Color(30, 30, 30, 255))
        end
        propertySheet:AddSheet("Triggerbot", triggerbotPanel, "icon16/gun.png")

        addCheckbox(triggerbotPanel, "Triggerbot", "triggerbot")
        addKeySelection(triggerbotPanel, "Triggerbot Key", "triggerbot_key")

        local espPanel = vgui.Create("DPanel", propertySheet)
        espPanel:Dock(FILL)
        espPanel:DockPadding(10, 10, 10, 10)
        espPanel.Paint = function(self, w, h)
            draw.RoundedBox(8, 0, 0, w, h, Color(30, 30, 30, 255))
        end
        propertySheet:AddSheet("ESP", espPanel, "icon16/eye.png")

        addCheckbox(espPanel, "ESP", "esp")
        addCheckbox(espPanel, "ESP Team", "esp_team")
        addCheckbox(espPanel, "ESP Enemies", "esp_enemies")
        addCheckbox(espPanel, "ESP NPCs", "esp_npcs")
        addCheckbox(espPanel, "ESP 3D Box", "esp_3d_box")
        addCheckbox(espPanel, "ESP 2D Box", "esp_2d_box")
        addCheckbox(espPanel, "ESP Names", "esp_names")
        addCheckbox(espPanel, "ESP Weapon", "esp_weapon")
        addCheckbox(espPanel, "ESP Distance", "esp_distance")
        addCheckbox(espPanel, "ESP Health", "esp_health")
        addCheckbox(espPanel, "ESP Skeleton", "esp_skeleton")

        local miscPanel = vgui.Create("DPanel", propertySheet)
        miscPanel:Dock(FILL)
        miscPanel:DockPadding(10, 10, 10, 10)
        miscPanel.Paint = function(self, w, h)
            draw.RoundedBox(8, 0, 0, w, h, Color(30, 30, 30, 255))
        end
        propertySheet:AddSheet("Misc", miscPanel, "icon16/cog.png")

        addCheckbox(miscPanel, "Bunnyhop", "bunnyhop")
        addCheckbox(miscPanel, "Auto Pistol", "auto_pistol")
        addCheckbox(miscPanel, "No Recoil", "no_recoil")
        addCheckbox(miscPanel, "No Spread", "no_spread")
        addCheckbox(miscPanel, "TTT Traitor Finder", "ttt_traitor_finder")
        addCheckbox(miscPanel, "Sound ESP", "sound_esp")

        local saveButton = vgui.Create("DButton", frame)
        saveButton:SetText("Save and Close")
        saveButton:Dock(BOTTOM)
        saveButton:DockMargin(10, 10, 10, 10)
        saveButton.DoClick = function()
            saveConfig()
            frame:Close()
        end
    end)

    hook.Add("OnScreenSizeChanged", "ReloadDedpacmanConfig", function()
        loadConfig()
    end)
end
