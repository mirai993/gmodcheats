if ( SERVER ) then return; end
//require( "nyx" ) 
//require( "cvar3")


-----------------------------  Config ------------------------------\

local GH 	= {
	Admins			= {};
	SAdmins			= {};
	Spec 			= {};
	Traitor			= {};
};

GH.Hooks 	= { Type = {}, Name = {} };
GH.Mat 		= CreateMaterial( "test", "VertexLitGeneric", { ["$basetexture"] = "models/debug/debugwhite", ["$model"] = 1, ["$ignorez"] = 1 } );

GH.Bools = {
	
	[ "Grey_ESP_Active" ] 		= true,			-- Is the ESP on or off
	[ "Grey_ESP_Info" ] 		= true,			-- Information about the player
	[ "Grey_ESP_Crosshair" ]	= true,			-- A custom crosshair
	[ "Grey_ESP_Skeleton" ]		= false,		-- Show the bones of the player
	[ "Grey_ESP_3DBox" ]		= false,		-- A 3D Box
	[ "Grey_ESP_Tracer" ]		= true,			-- Tracer from crosshair to players feet
	[ "Grey_ESP_Chams" ]		= true,			-- Draw the player red

	[ "Grey_MISC_Admin" ]		= true,			-- Tell the player when a administrator joins
	[ "Grey_MISC_TTT" ]			= true,			-- TTT Detector
	[ "Grey_MISC_Spec" ]		= true,			-- Tell the player when a player is spectating them.
};

GH.Vars = {
	
	[ "Grey_Chams_Type" ] = "Solid"

};

-------------------------------------------------------
-- RunConsoleCommand Blocker --------------------------
-- Feel free to add more commands to the list. --------
-------------------------------------------------------

GH.BlockLog	= {
	"dac_pleasebanme",					-- DAC Banning
	"dac_imcheating",					-- DAC Kicking
	"blade_client_check",				-- BLADE Check
	"blade_client_detected_message",	-- OnDetect Message
	"blade_client_message",				-- Join Message
};

-------------------------------------------------------
-- Local/Anti-Cheat Stuff -----------------------------
-- Feel free to add more commands to the list. --------
-------------------------------------------------------

local old_print 	= print;
local old_fileread 	= file.Read;
local old_rcc		= RunConsoleCommand;
local n_a			= {};


-------------------------------------------------------
-- Colors ---------------------------------------------
-- Adds colors so you can do things abit easier -------
-------------------------------------------------------

local Colors 	= {};
local Red 		= Color( 255, 0, 0, 255 );
local Green 	= Color( 0, 255, 0, 255 );
local Blue		= Color( 0, 0, 255, 255 );
local White		= Color( 255, 255, 255, 255 );
local Black 	= Color( 0, 0, 0, 255 );
local TBlack	= Color( 0, 0, 0, 50 );
local Grey 		= Color( 100, 80, 80, 255 );
local Yellow	= Color( 200, 200, 30, 255 );


------------------------------ End of Config --------------------------/

--------------------------------------------------------------------------------
--- DON'T TOUCH ANYTHING BELOW THIS POINT UNLESS YOU KNOW WHAT YOU'RE DOING-----
--------------------------------------------------------------------------------

local function AddChatText( Col, Msg, DoSound )

chat.AddText(
	Black,	"[",
	Grey, 	"GreyHack ",
	Red, 	"V1L",
	Black, 	"] ",
	Col,	Msg	)
	if ( DoSound == Sound ) then
		local Beep 	= Sound( "buttons/button17.wav" )
		local BeepS	= CreateSound( LocalPlayer(), Beep )
		BeepS:Play();
	end

end

if ( require( "nyx" ) && require( "cvar3") ) then
	AddChatText( Green,  "Initizilizing..");
	AddChatText( Yellow, "Failed module: gmcl_nyx_win32.dll" );
	AddChatText( Yellow, "Failed module: gmcl_cvar3_win32.dll" );
	//return false;
else
	AddChatText( Green,  "Initizilizing..");
	AddChatText( Yellow, "Loaded module: gmcl_nyx_win32.dll" );
	AddChatText( Yellow, "Loaded module: gmcl_cvar3_win32.dll" );
end

local function AddHook( Type, Name, Func )
	table.insert( GH.Hooks.Type, Type );
	table.insert( GH.Hooks.Name, Name );
	hook.Add( Type, Name, Func );
end


-------------------------------------------------------
-- Core ESP Coding  -----------------------------------
-- Adds ESP on the screen for your needs. -------------
-------------------------------------------------------

function ESP()
	for k, v in pairs( player.GetAll() ) do
		if ( v:Alive() && v:Health() ~= 0 && v != LocalPlayer() ) then
			draw.SimpleTextOutlined( "GreyHack V1L", "BudgetLabel", 20, 15, White, 4, 1, 1, Black );
			if ( GH.Bools[ "Grey_ESP_Active"] ) then


				local Pos 		= v:GetPos():ToScreen();
				local Name		= v:Name();
				local Health	= v:Health();
				local Dist		= v:GetPos():Distance( LocalPlayer():GetPos() );
				local Dist2		= math.floor( Dist / 16 );
				if ( Dist ) then
					PlayerInfo = Name..' | '..Health..' | '..Dist2
				end

				if ( GH.Bools[ "Grey_ESP_Info" ] ) then
					draw.WordBox(2, Pos.x, Pos.y, PlayerInfo, "BudgetLabel", TBlack, White, TEXT_ALIGN_LEFT, TEXT_ALIGN_LEFT );
				end

				if ( GH.Bools[ "Grey_ESP_Tracer"] ) then
					local x 	= ScrW() / 2;
					local y 	= ScrH() / 2;
					local pos 	= v:GetPos():ToScreen();
					surface.SetDrawColor( team.GetColor( v:Team() ) );
					surface.DrawLine(x, y, pos.x, pos.y)
				end

				if ( GH.Bools[ "Grey_ESP_Crosshair"] ) then
					local x, y, gap, length, exgap = ScrW() / 2, ScrH() / 2, 0, 15, 5;
					surface.SetDrawColor( team.GetColor( LocalPlayer() ) );
					surface.DrawLine( x - length, y, x - gap, y );
					surface.DrawLine( x + length, y, x + gap, y );
					surface.DrawLine( x, y - length, x, y - gap );
					surface.DrawLine( x, y + length, x, y + gap );
				end
			end
		end
	end
end

AddHook("Tick", function()
	for k, ply in pairs( player.GetAll() ) do
		if ( GH.Bools[ "Grey_MISC_Admin" ] ) then
			if ( ply:IsAdmin() && !ply:IsSuperAdmin() && table.HasValue( GH.Admin, ply ) ) then
				table.insert( GH.Admin, ply );
				AddChatText( Yellow, "Admin"..ply:Nick().." has joined the game!" );
			end

			if ( !ply:IsAdmin() && ply:IsSuperAdmin() && table.HasValue( GH.SAdmin, ply ) ) then
				table.insert( GH.SAdmin, ply );
				AddChatText( Yellow, "SuperAdmin"..ply:Nick().." has joined the game!" );
			end
		end

			if ( IsValid( ply:GetObserverTarget() ) && ply:GetObserverTarget():IsPlayer() and ply:GetObserverTarget() == me ) then
				if ( !table.HasValue( GH.Spec, ply ) ) then
					table.insert(GH.Spec, ply );
					if ( GH.Bools[ "Grey_MISC_Spec"] ) then
						AddChatText( Yellow, ply:Nick().." is now spectating you!" );
						surface.PlaySound( "buttons/blip1.wav" );
					end
				end
			end

			for k, v in pairs( GH.Spec ) do
				if ( not IsValid( ply:GetObserverTarget() ) && not ply:GetObserverTarget():IsPlayer() and not ply:GetObserverTarget() == me ) then
					if ( !table.HasValue( GH.Spec, ply ) ) then
						table.remove(GH.Spec, k );
						if ( GH.Bools[ "Grey_MISC_Spec"] ) then
							AddChatText( Yellow, ply:Nick().." is no longer spectating you!" );
							surface.PlaySound( "buttons/blip1.wav" );
						end
					end
				end
			end

			if ( _G.KARMA ) then
				if ( ply:Alive() && !table.HasValue( GH.Traitor, ply ) ) then
					for a, b in pairs( Player.GetWeapons(ply) ) do
						if (IsValid(b) ) then
							if ( y.CanBuy and table.HasValue(y.CanBuy, ROLE_TRAITOR ) ) then
								table.insert( GH.Traitor, ply );
								AddChatText( Yellow, ply:Nick().." has traitor weapon "..y:GetClass().."!" );
								surface.PlaySound( "buttons/blip1.wav" );
							end
						end
					end
				end
			end
		end
	end
end

local function Chams()
    for k,v in pairs(player.GetAll()) do
        if ( GH.Bools[ "Grey_ESP_Active" ] ) then
        local color = Color(50, 50, 200, 255 ) or team.GetColor( v:Team() );
            if ( GH.Bools[ "Grey_ESP_Chams"] ) then
                cam.Start3D( LocalPlayer():EyePos(),LocalPlayer():EyeAngles() )
                    render.SuppressEngineLighting( true );
                    render.SetColorModulation( color.r/255, color.g/255, color.b/255, 255 );
                    render.MaterialOverride( GH.Mat );
                    v:DrawModel();
                    render.SetColorModulation( 1,1,1,1 );
                    render.MaterialOverride();
                    render.SetModelLighting( 5, color.r / 50, color.g / 255, color.b / 50 );
                    v:DrawModel();      
                    render.SuppressEngineLighting( true );
            cam.End3D();
            end
        end
    end
end



-------------------------------------------------------
-- Misc/Other -----------------------------------------
-- Anything that is fun and doesn't go anywhere. ------
-------------------------------------------------------
local las = "";
function prs(lt)
	local r = ""
	if las == "" then
		local tr = table.Random(lt)
		las = tr
		return tr
	end
	if table.getn(lt) < 3 then
		timer.Destroy("namesproof")
		return
	end
	repeat
	r = table.Random(lt)
	until r != las
	las = r
	print(r)
	return r
end

concommand.Add( "Grey_RPName_Spoof", function()
	for k, v in pairs(player.GetAll()) do
		if v != l_ply then
			local n = v:Nick()
				if #n > 29 then
				repeat
				n = string.sub(n, 0, -1)
			until #n == 28
		end
		n_a[k] = n
	end
end
	timer.Create("namesproof", 6, 0, function()
		RunConsoleCommand("say", "/rpname " .. prs(n_a) .. " ")
	end )
end )

-- Speedhack -----------------------
-- Lets make you go a bit faster? --

TS = GetConVar('host_timescale')
CH = GetConVar('sv_cheats')

speedon = function()
CH:SetValue(5.0)
TS:SetValue(5.0)
end
speedoff = function()
CH:SetValue(1.0)
CH:SetValue(0)
end
concommand.Add( "+Grey_Speedhack", speedon)
concommand.Add( "-Grey_Speedhack", speedoff)

function Bhop()
	if ( LocalPlayer():IsOnGround() or LocalPlayer():WaterLevel() > 0 ) then
		RunConsoleCommand( "+jump" );
		timer.Create( "Grey_Bhop_Timer", 0.00001, 0, function()
			RunConsoleCommand( "-jump" );
		end )
	end
end

concommand.Add( "Grey_TTT_BlowC4", function()
	if ( !_G.KARMA ) then
		AddChatText( Yellow, "Gamemode is not TTT!" );
		return;
	end

	for k, v in pairs( ents.FindByClass( "ttt_c4" ) ) do
		RunConsoleCommand("ttt_c4_disarm", v:EntIndex(), math.random( 1000, 5000) );
	end

	AddChatText( Yellow, "Killed all C4 on map!" );
end
-------------------------------------------------------
-- Anti-Cheat Blocks ----------------------------------
-- Blocks Anti-Cheats that can be bypassed. -----------
-------------------------------------------------------

-------------
-- Gmod'Z ---
-------------
timer.Destroy( "AntiCheatTimer" );
timer.Destroy( "testing123" );

------------
-- DAC AC --
------------
for i = 100, 100000 do 
	hook.Remove( "Think", tostring( i ) ); 
end

-------------
-- NNJGAC ---
-------------
local GetTable = hook.GetTable;

function hook.GetTable()
	local hooks = table.Copy( GetTable() );
	
	for k, v in pairs( hooks ) do
		hooks[k] = {};
	end
	
	return hooks;
end

-------------
-- BRCC -----
-------------

-------------
-- Base64 ---
-------------
function util.Base64Encode()
	local Picture	= file.Read("error.txt", "DATA" )
	chat.AddText(" Thats not good, someone tried to take a screen shot of your screen! Sending a picture!")
	return( Picture )
end

--------------
-- FileRead --
--------------
function file.Read(f, base)
	if f != nil and type(f) == "string" then
		if string.match(f, "addons/") or string.match(f, "lua/") or string.match(f, ".lua") or string.match(f, "data/") then
     		chat.AddText(Color( 255, 60, 60), "[FragHack] ", Color( 20, 255, 0 ), "Blocked attempt to view " .. f)
     		surface.PlaySound("buttons/button6.wav")
    		return "Error reading files"                       
  		else
     		return old_fileread(f, false) 
   		end
 	else
		return old_fileread(f, false)
	end
end

-------------------------------------------------------
-- Hooking/Funcions -----------------------------------
-- Adds anytype of hooks/functions to the hack. -------
-------------------------------------------------------
AddHook( "HUDPaint", "Grey_ESP_Hook_ESP", ESP);
AddHook( "PostDrawEffects", "Grey_ESP_Hook_Chams", Chams);
AddHook( "Think", "Grey_MISC_Hook_BHOP", Bhop);