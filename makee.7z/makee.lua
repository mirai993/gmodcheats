CreateClientConVar("names","1",false,true)
hook.Add( "HUDPaint", "Wallhack", function()
 
	for k,v in pairs (player.GetAll()) do
	if GetConVarNumber("names") >= 1 then
                        if v ~= LocalPlayer() then
		if LocalPlayer():Alive() then
		local Position = ( v:GetPos() + Vector( 0,0,80 ) ):ToScreen()
		draw.DrawText( v:Name(), "BudgetLabel", Position.x, Position.y, Color( 255, 51, 204, 255 ), 1 )
		else
end
end
end
end
end)
CreateClientConVar("names", 1, true, false)
 
local function IsVisible( ent ) /* Huge credits to whoever made this tracer function! */
	local tracer = {}
	if(LocalPlayer():GetShootPos() != nil && ent:IsValid() && ent != nil && LocalPlayer():GetActiveWeapon():IsValid() && LocalPlayer():GetActiveWeapon() != nil && ent:LookupBone("ValveBiped.Bip01_Head1") != nil && ent:GetBonePosition(ent:LookupBone("ValveBiped.Bip01_Head1")) != nil) then
		tracer.start = LocalPlayer():GetShootPos()
		tracer.endpos = ent:GetBonePosition(ent:LookupBone("ValveBiped.Bip01_Head1"))
		tracer.filter = { LocalPlayer(), ent }
		tracer.mask = MASK_SHOT
		local trace = util.TraceLine( tracer )
		if trace.Fraction >= 1 then return true else return false end
	end
end


print("ESP Loaded")
local function MESPCheck(v)
 if v:Alive() == true && v:Health() ~= 0 && v:Health() >= 0 && v ~= LocalPlayer() && LocalPlayer():Alive() then
  return true
 else
  return false
 end
end


hook.Add( "HUDPaint", "aimbot.Wallhack", function()
for k,v in pairs ( player.GetAll() ) do
 
        local Position = ( v:GetPos() + Vector( 0,0,80 ) ):ToScreen()
        local Name = ""
  
        if v == LocalPlayer() then Name = "" else Name = v:Name() end
 
end
 
end )
 
local shouldDraw = true
 
local hzCross = CreateClientConVar("HZ_Crosshair","0",false)
 
function Crosshair1()
surface.SetDrawColor(team.GetColor(LocalPlayer():Team()))
surface.DrawLine(ScrW() / 2 - 10, ScrH() / 2, ScrW() / 2 + 11 , ScrH() / 2)
surface.DrawLine(ScrW() / 2 - 0, ScrH() / 2 - 10, ScrW() / 2 - 0 , ScrH() / 2 + 11)
end
hook.Add("HUDPaint","CustomCross",Crosshair1)

local function coordinates( ent )
local min, max = ent:OBBMins(), ent:OBBMaxs()
local corners = {
        Vector( min.x, min.y, min.z ),
        Vector( min.x, min.y, max.z ),
        Vector( min.x, max.y, min.z ),
        Vector( min.x, max.y, max.z ),
        Vector( max.x, min.y, min.z ),
        Vector( max.x, min.y, max.z ),
        Vector( max.x, max.y, min.z ),
        Vector( max.x, max.y, max.z )
}
 
local minX, minY, maxX, maxY = ScrW() * 2, ScrH() * 2, 0, 0
for _, corner in pairs( corners ) do
        local onScreen = ent:LocalToWorld( corner ):ToScreen()
        minX, minY = math.min( minX, onScreen.x ), math.min( minY, onScreen.y )
        maxX, maxY = math.max( maxX, onScreen.x ), math.max( maxY, onScreen.y )
end
 
return minX, minY, maxX, maxY
end
CreateClientConVar("ESPB","1",false, true)
hook.Add("HUDPaint", "Example", function()
for k,v in pairs(player.GetAll()) do
	if GetConVar("ESPB"):GetInt() == 1 then
        local x1,y1,x2,y2 = coordinates(v)
         print(tostring(team.GetColor(v:Team())))
         surface.SetDrawColor(color_white)
 
 
        surface.DrawLine( x1, y1, math.min( x1 + 5, x2 ), y1 )
        surface.DrawLine( x1, y1, x1, math.min( y1 + 5, y2 ) )
 
 
        surface.DrawLine( x2, y1, math.max( x2 - 5, x1 ), y1 )
        surface.DrawLine( x2, y1, x2, math.min( y1 + 5, y2 ) )
 
 
        surface.DrawLine( x1, y2, math.min( x1 + 5, x2 ), y2 )
        surface.DrawLine( x1, y2, x1, math.max( y2 - 5, y1 ) )
 
 
        surface.DrawLine( x2, y2, math.max( x2 - 5, x1 ), y2 )
        surface.DrawLine( x2, y2, x2, math.max( y2 - 5, y1 ) )
end
end
end)



hook.Add("Think", "NoRecoil", function()
    if LocalPlayer() and LocalPlayer():GetActiveWeapon() and LocalPlayer():GetActiveWeapon().Primary then
        LocalPlayer():GetActiveWeapon().Primary.Recoil = 0
    end
end )



local aa = false
function aimbot()
if aa then
local ply = LocalPlayer()
local trace = util.GetPlayerTrace( ply )
local traceRes = util.TraceLine( trace )
if traceRes.HitNonWorld then
local target = traceRes.Entity
if target:IsPlayer() then
local targethead = target:LookupBone("ValveBiped.Bip01_Head1")
local targetheadpos,targetheadang = target:GetBonePosition(targethead)
ply:SetEyeAngles((targetheadpos - ply:GetShootPos()):Angle())
end
end
end
end
hook.Add("Think","aimbot",aimbot)
concommand.Add("aa_toggle", function()
if aa then
    aa = !aa
    LocalPlayer():ChatPrint("AA turned OFF")
else
    aa = !aa
    LocalPlayer():ChatPrint("AA turned ON")
end
end)


local ihop = false
hook.Add("Think", "ihop", function()
if ihop then
     if (input.IsKeyDown( KEY_SPACE ) ) then
        if LocalPlayer():IsOnGround() then
            RunConsoleCommand("+jump")
            HasJumped = 1
        else
            RunConsoleCommand("-jump")
            HasJumped = 0
        end
    elseif ihop and LocalPlayer():IsOnGround() then
        if HasJumped == 1 then
            RunConsoleCommand("-jump")
            HasJumped = 0
        end
    end
end
end)
concommand.Add("ihop_toggle", function()
if ihop then
    ihop = !ihop
    LocalPlayer():ChatPrint("iHop turned OFF")
else
    ihop = !ihop
    LocalPlayer():ChatPrint("iHop turned ON")
end
end)



for _, ent in pairs( ents.GetAll() ) do
 if ( ent:IsWeapon() and ent.CanBuy and IsValid( ent:GetOwner() ) and ent:GetOwner():IsPlayer() and ent:GetOwner()  ) then
  local owner = ent:GetOwner();
  print( owner:Nick().." is a traitor!" );
 end
end

 CreateClientConVar( "tb", 0, true, false )
local function autoshoot()

if ConVarExists( "tb" ) and GetConVar("tb"):GetInt() == 1 then
if LocalPlayer():Alive() then
 
local pos = LocalPlayer():GetShootPos()
local ang = LocalPlayer():GetAimVector()
 
 
tracedata.start = pos
tracedata.endpos = pos+(ang * Distance)
tracedata.filter = LocalPlayer()
 
local trace = util.TraceLine(tracedata)
 
target = trace.Entity
 
if WeaponCheck() and ModeCheck() and AmmoCheck() then
 
Fire()
 
end
end
 
end
end
 CreateClientConVar( "cham", 0, true, false )
  CreateClientConVar( "chams_wire", 0, true, false )
hook.Add("HUDPaint", "makeecham", function()
 for k,v in pairs(player.GetAll()) do
 if GetConVarNumber("cham") >= 1 then
  if MESPCheck(v) then
   cam.Start3D(EyePos(), EyeAngles())
    v:SetMaterial("models/debug/debugwhite")
    v:SetColor(Color(20, 71, 244, 100))
    render.MaterialOverride("models/debug/debugwhite")
    render.SuppressEngineLighting( false )
    render.SetBlend( 0.3 )
    render.SetColorModulation( 0, 1, 0 )
    v:DrawModel()
    if GetConVarNumber("chams_wire") >= 1 then
     v:SetMaterial("models/wireframe")
     render.MaterialOverride("models/wireframe")
     v:DrawModel()
    end
   cam.End3D()
  end
 end
 end
end)

 
  CreateClientConVar( "wglow", 0, true, false )
hook.Add("HUDPaint", "WepGlow", function()
 for k,v in pairs(ents.GetAll()) do
  if(GetConVarNumber("wglow") == 1 && string.find(v:GetClass(), "weapon_")) then
   effects.halo.Add({v}, Color(255, 0, 0), 1, 1, 3, true, true)
  end
 end
end)
  CreateClientConVar( "glow", 0, true, false )
hook.Add("HUDPaint", "glow", function()
 for k,v in pairs(player.GetAll()) do
  if(GetConVarNumber("glow") == 1) then
   effects.halo.Add({v}, team.GetColor(v:Team()), 1, 1, 5, true, true)

  end
 end
end)
local Traitors = {};
local matOverlay = Material( "sprites/glow08" )
local matTraitor = Material( "sprites/dot" )
local twep = { "weapon_ttt_c4", "weapon_ttt_knife", "weapon_ttt_phammer", "weapon_ttt_sipistol", "weapon_ttt_flaregun", "weapon_ttt_push", "weapon_ttt_radio", "weapon_ttt_teleport", "(Disguise)" ,"spiderman's_swep", "weapon_ttt_trait_defilibrator", "weapon_ttt_xbow", "weapon_ttt_dhook", "weapon_awp", "weapon_jihadbomb", "weapon_ttt_knife", "weapon_ttt_c4", "weapon_ttt_decoy", "weapon_ttt_flaregun", "weapon_ttt_phammer", "weapon_ttt_push", "weapon_ttt_radio", "weapon_ttt_sipistol", "weapon_ttt_teleport", "weapon_ttt_awp", "weapon_ttt_silencedsniper", "weapon_ttt_turtlenade", "weapon_ttt_death_station", "weapon_ttt_sg552", "weapon_ttt_tripmine"}

for _,v in pairs(player.GetAll()) do
        v.HatTraitor = nil
end
for _,v in pairs(ents.GetAll()) do
        v.HatESPTracked = nil
end

hook.Add("PostDrawOpaqueRenderables", "wire_animations_idle", function()
        if GAMEMODE.round_state != ROUND_ACTIVE then
                for _,v in pairs(player.GetAll()) do
                        v.HatTraitor = nil
                end
                for _,v in pairs(ents.GetAll()) do
                        v.HatESPTracked = nil
                end
                return
        end
        for _,v in pairs( ents.GetAll() ) do
                if v and IsValid(v) and (table.HasValue(twep, v:GetClass()) and !v.HatESPTracked) then
                        local pl = v.Owner
                        if pl and IsValid(pl) and pl:IsTerror() then
                                if pl:IsDetective() then
                                        v.HatESPTracked = true
                                else
                                        v.HatESPTracked = true
                                        pl.HatTraitor = true
                                        chat.AddText( pl, Color(255,125,0), " is a ",Color(255,0,0), "TRAITOR",Color(255,125,0), " with a ",Color(255,0,0),v:GetClass().."!")
                                end
                        end
                end
        end
          
  

end)
 
hook.Add("HUDPaint",function()
        if GetConVarNumber("tt") == 1 then
                for k, e in pairs( Traitors ) do
                        local maxX, minX, maxY, minY, maxX2, minX2, maxY2, minY2, minYhp, maxYhp = CreatePos( e )
                        if IsValid( e ) then
                                if e:Team() ~= TEAM_SPECTATOR then
                                        if ( !e:IsDetective() ) then
                                                PlayerIsTraitor = true
                                                draw.SimpleTextOutlined( "[TRAITOR]", "ESPFont", maxX2, minY2 -20, red, 4, 1, 1, black )
                                        end
                                end
                        end
                end
        end
end )
CreateClientConVar( "TB", 0, true, false )
local function ATHack()
 
  if GetConVarNumber("TB") == 1 then
                ucmd:SetButtons(bit.bor(ucmd:GetButtons(),IN_ATTACK))
                        end
 
end

 
concommand.Add("+hmenu", function()
local DermaPanel = vgui.Create( "DFrame" )
DermaPanel:SetPos( 400,5 )
DermaPanel:SetSize( 375, 700 )
DermaPanel:SetTitle( "Makee's TTT Hack pack *BETA*" )
DermaPanel:SetVisible( true )
DermaPanel:SetDraggable( true )
DermaPanel:ShowCloseButton( true )
DermaPanel:MakePopup()
local DermaButton = vgui.Create( "DButton" )
DermaButton:SetParent( DermaPanel )
DermaButton:SetText( "Aimbot" )
DermaButton:SetPos( 25, 50 )
DermaButton:SetSize( 150, 50 )
DermaButton.DoClick = function ()
    RunConsoleCommand( "aa_toggle" )
end
local DermaButton = vgui.Create( "DButton" )
DermaButton:SetParent( DermaPanel )
DermaButton:SetText( "Bhop" )
DermaButton:SetPos( 200, 50 )
DermaButton:SetSize( 150, 50 )
DermaButton.DoClick = function ()
    RunConsoleCommand( "ihop_toggle" )
end

local CheckBoxThing = vgui.Create( "DCheckBoxLabel")
CheckBoxThing:SetParent( DermaPanel )
CheckBoxThing:SetPos( 25,125 )
CheckBoxThing:SetText( "Names" )
CheckBoxThing:SetConVar( "names" ) 

CheckBoxThing:SizeToContents()  

local CheckBoxThing = vgui.Create( "DCheckBoxLabel")
CheckBoxThing:SetParent( DermaPanel )
CheckBoxThing:SetPos( 125,125 )
CheckBoxThing:SetText( "Chams" )
CheckBoxThing:SetConVar( "cham" ) 

CheckBoxThing:SizeToContents()  

local CheckBoxThing = vgui.Create( "DCheckBoxLabel")
CheckBoxThing:SetParent( DermaPanel )
CheckBoxThing:SetPos( 200,125 )
CheckBoxThing:SetText( "Chams (wireframe)" )
CheckBoxThing:SetConVar( "chams_wire" ) 

CheckBoxThing:SizeToContents()  

local CheckBoxThing = vgui.Create( "DCheckBoxLabel")
CheckBoxThing:SetParent( DermaPanel )
CheckBoxThing:SetPos( 25,200 )
CheckBoxThing:SetText( "Box ESP" )
CheckBoxThing:SetConVar( "ESPB" ) 

CheckBoxThing:SizeToContents()  




end)