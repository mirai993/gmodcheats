--[[
	perphack.lua
	Zomg!NoWai!
	===Begin Stream===
]]

local ItemList = { }
    ItemList[1] = { "Item: Lock Pick", "item_wrench", "item_chunk_metal", "item_metal_rod" }
    ItemList[2] = { "Item: Bullet Casings", "item_chunk_metal", "item_metal_polish" }
    ItemList[3] = { "Item: Stim Pack", "item_paper_towels", "item_chunk_plastic" }
    ItemList[4] = { "Item: Bullet Casings", "item_chunk_plastic", "item_metal_rod" }
    ItemList[5] = { "Ammo: Pistol", "item_cardboard", "item_chunk_metal", "item_bullet_shell" }
    ItemList[6] = { "Ammo: Shotgun", "item_chunk_plastic", "item_chunk_plastic", "item_cardboard", "item_bullet_shell" }
    ItemList[7] = { "Ammo: Rifle", "item_chunk_metal", "item_chunk_metal", "item_chunk_plastic", "item_bullet_shell" }
    ItemList[8] = { "Entity: Cannabis Plant", "item_pot",  "drug_pot_seeds" }
    ItemList[9] = { "Entity: Chain Link Fences", "item_metal_rod", "item_metal_rod" }
    ItemList[10] = { "Entity: Police Barrior", "item_board", "item_paint", "item_metal_rod" }
    ItemList[11] = { "Entity: Concrete Barrior", "item_metal_rod", "item_cinder_block", "item_cinder_block" }
    ItemList[12] = { "Weapon: Uzi", "item_chunk_plastic", "item_metal_rod", "item_paint", "item_chunk_metal", "item_chunk_metal", "item_chunk_metal", "item_chunk_metal" }
    ItemList[13] = { "Weapon: Five-Seven", "item_chunk_metal", "item_chunk_metal", "item_paint", "item_paint", "item_chunk_plastic" }
    ItemList[14] = { "Weapon: AK-47", "item_chunk_metal", "item_chunk_metal", "item_chunk_metal", "item_chunk_metal", "item_chunk_metal", "item_board", "item_board", "item_paint" }
    ItemList[15] = { "Weapon: Glock", "item_chunk_metal", "item_chunk_metal", "item_paint", "item_metal_polish" }
    ItemList[16] = { "Weapon: Shotgun", "item_chunk_metal", "item_chunk_metal", "item_chunk_metal", "item_chunk_metal", "item_metal_rod" }
    ItemList[17] = { "Weapon: Desert Eagle", "item_chunk_metal", "item_chunk_metal", "item_chunk_metal", "item_chunk_plastic", "item_chunk_plastic" }
    ItemList[18] = { "Weapon: Car Bomb", "item_chunk_metal", "item_chunk_metal", "item_chunk_metal", "item_chunk_metal", "item_chunk_metal", "item_chunk_metal", "item_chunk_metal", "item_chunk_metal", "item_chunk_metal", "item_chunk_metal", "item_metal_rod", "item_metal_rod", "item_metal_rod", "item_propane_tank", "item_propane_tank", "item_chunk_plastic", "item_chunk_plastic", "item_chunk_plastic", "item_chunk_plastic", "item_chunk_plastic", "item_chunk_plastic", "item_chunk_plastic" }


----------------------------------
----------------------------------

local MenuFrame = vgui.Create( "DFrame" ) 
    MenuFrame:SetTitle( "Effect Pulsar Hacks - Version 1.0.0" )
    MenuFrame:SetSize( 500, 300 )
    MenuFrame:SetVisible( false )
    MenuFrame:SetDraggable( false )
    MenuFrame:ShowCloseButton( true )
    MenuFrame:SetVisible( false )
    MenuFrame:SetDeleteOnClose( false )
    MenuFrame:Center( )
    

--
    
local BackGroundForPERPDrop = vgui.Create( "DPanel", MenuFrame )
    BackGroundForPERPDrop:SetPos( 5, 25 )
    BackGroundForPERPDrop:SetSize( 490, 320 )
    BackGroundForPERPDrop.Paint = function( )
        surface.SetDrawColor( 50, 50, 50, 255 )
        surface.DrawRect( 0, 0, BackGroundForPERPDrop:GetWide( ), BackGroundForPERPDrop:GetTall( ) )
    end
    
    
-- 
 
local ItemListCollum = vgui.Create( "DComboBox", BackGroundForPERPDrop )
    ItemListCollum:SetSize( 150, 230 )
    ItemListCollum:SetPos( 5, 5 )
    for _, item in pairs( ItemList ) do
        ItemListCollum:AddItem( item[1] )
    end
    
    
--

local MixtureList = vgui.Create( "DComboBox", BackGroundForPERPDrop )
    MixtureList:SetSize( 150, 230 )
    MixtureList:SetPos( 225, 5 )
  

--
     
local TransfurFromItemToMixture = vgui.Create( "DButton", BackGroundForPERPDrop )
    TransfurFromItemToMixture:SetPos( 165, 75 )
    TransfurFromItemToMixture:SetSize( 50, 50 )
    TransfurFromItemToMixture:SetText( "->" )
    TransfurFromItemToMixture.DoClick = function( )
        if ItemListCollum:GetSelectedItems( ) and ItemListCollum:GetSelectedItems( )[1] then
            MixtureList:AddItem( ItemListCollum:GetSelectedItems( )[1]:GetValue( ) )
        end
    end
    
    
-- 
 
local ClearMixtureCollum = vgui.Create( "DButton", BackGroundForPERPDrop )
    ClearMixtureCollum:SetPos( 165, 130 )
    ClearMixtureCollum:SetSize( 50, 50 )
    ClearMixtureCollum:SetText( "Clear" )
    ClearMixtureCollum.DoClick = function( )
        MixtureList:Clear( )
    end
    
    
--

local ExecuteButton = vgui.Create( "DButton", BackGroundForPERPDrop )
    ExecuteButton:SetPos( 382, 205 )
    ExecuteButton:SetSize( 90, 30 )
    ExecuteButton:SetText( "Execute" )
    ExecuteButton.DoClick = function( )
        for _, mixture in pairs( MixtureList:GetItems( ) ) do
            for _, content in pairs( ItemList ) do
            -- This is where you want it to pause after each mixture
                if string.find( content[1], mixture:GetValue( ) ) then
                    for index, items in pairs( content ) do
                        if index != 1 then
                            RunConsoleCommand( "perp_di", items )
                        end
                    end
                end
            end
        end
    end
    
    
-----------------------------------------***************************************************************************************************************************
-----------------------------------------***************************************************************************************************** Useful Scripts Page

local BackGroundForHacks = vgui.Create( "DPanel", MenuFrame )
    BackGroundForHacks:SetSize( 250, 300 )
    BackGroundForHacks:SetPos( 5, 5 )
    BackGroundForHacks.Paint = function( )
        surface.SetDrawColor( 50, 50, 50, 255 )
        surface.DrawRect( 0, 0, BackGroundForHacks:GetWide( ), BackGroundForHacks:GetTall( ) )
    end

--

CreateClientConVar( "perp_healthtillholster", 20, false, false )

local SliderForHealthHolster = vgui.Create( "DNumSlider", BackGroundForHacks )
    SliderForHealthHolster:SetPos( 100, 5 )
    SliderForHealthHolster:SetToolTip( "This will be how much health you have left before you holster your weapon" )
    SliderForHealthHolster:SetSize( 370, 100 )
    SliderForHealthHolster:SetMin( 0 )
    SliderForHealthHolster:SetText( "Health limit until holster:" )
    SliderForHealthHolster:SetMax( 100 )
    SliderForHealthHolster:SetDecimals( 0 )
    SliderForHealthHolster:SetConVar( "perp_healthtillholster" )


--

CreateClientConVar( "perp_autoholster", 0, false, false )

local AutoHolster = vgui.Create( "DCheckBoxLabel", BackGroundForHacks )
    AutoHolster:SetPos( 5, 25 )
    AutoHolster:SetSize( 200, 20 )
    AutoHolster:SetText( "Auto Holster" )
    AutoHolster:SetValue( 1 )
    AutoHolster:SetConVar( "perp_autoholster" )
        
    local GetActiveAutoHols = true
    local function AutoHolsterAtLowHP( )
        if GetConVarNumber( "perp_autoholster" ) == 1 then
            if !LocalPlayer( ):Alive( ) then return end
            
            if LocalPlayer( ):Health( ) < GetConVarNumber( "perp_healthtillholster" ) and GetActiveAutoHols then
                GetActiveAutoHols = false
                RunConsoleCommand( "perp_holster" )
                timer.Simple( 5, function( ) GetActiveAutoHols = true end )
            end
        end
    end
    
    hook.Add( "Think", "AutoHolsterAtLowHP", AutoHolsterAtLowHP )
  
--
  
CreateClientConVar( "perp_antiafk", 0, false, false )
    
local AntiAFK = vgui.Create( "DCheckBoxLabel", BackGroundForHacks )
    AntiAFK:SetPos( 5, 60 )
    AntiAFK:SetText( "Anti AFK" )
    AntiAFK:SetValue( 0 )
    AntiAFK:SetConVar( "perp_antiafk" )
    
    local GetActiveAntiAFK = true
    local function AFKKickerProtection( )
        if GetConVarNumber( "perp_antiafk" ) == 1 then
            if !LocalPlayer( ):Alive( ) then return end
            
            if GetActiveAntiAFK then
                GetActiveAntiAFK = false
                RunConsoleCommand( "+forward" )
                timer.Simple( 0.01, function( ) RunConsoleCommand( "-forward" ) end )
                timer.Simple( 20, function( ) GetActiveAntiAFK = true end )
            end
        end
    end
    
    hook.Add( "Think", "AFKKickerProtection", AFKKickerProtection )
  
--  

CreateClientConVar( "perp_advertinterval", 1, false, false )    
    
local AdvertiseTimeIndex = vgui.Create( "DNumSlider", BackGroundForHacks ) --------------
        AdvertiseTimeIndex:SetPos( 220, 80 )
        AdvertiseTimeIndex:SetToolTip( "Setting it to 0 will make the messaging stop." )
        AdvertiseTimeIndex:SetSize( 250, 100 )
        AdvertiseTimeIndex:SetText( "Minutes between each message:" )
        AdvertiseTimeIndex:SetMin( 0 )
        AdvertiseTimeIndex:SetMax( 10 )
        AdvertiseTimeIndex:SetConVar( "perp_advertinterval" )
        AdvertiseTimeIndex:SetDecimals( 0 )
        
--

local AdvertizeRepeatAddressBar = vgui.Create( "DTextEntry", BackGroundForHacks )
    AdvertizeRepeatAddressBar:SetPos( 5, 90 )
    AdvertizeRepeatAddressBar:SetToolTip( "Pressing enter will renew the message, and the interval." )
    AdvertizeRepeatAddressBar:SetSize( 200, 20 )
    
    local GetActiveRepeatAdvert = true
    AdvertizeRepeatAddressBar.OnEnter = function( )
            hook.Add( "Think", "AdvertRepeat", function( )
                if !LocalPlayer( ):Alive( ) then return end
                if AdvertizeRepeatAddressBar:GetValue( ) == "" then return end
                if GetConVarNumber( "perp_advertinterval" ) == 0 then return end
                
                if GetActiveRepeatAdvert then
                    GetActiveRepeatAdvert = false
                    RunConsoleCommand( "say", "/advert " .. AdvertizeRepeatAddressBar:GetValue( ) )
                    timer.Simple( GetConVarNumber( "perp_advertinterval" ) * 60, function( ) GetActiveRepeatAdvert = true end )
                end
            end )
    end
  
--  
    
CreateClientConVar( "perp_autostempack", 0, false, false )
    
local HealthStemPackBelowCertainHP = vgui.Create( "DCheckBoxLabel", BackGroundForHacks )
    HealthStemPackBelowCertainHP:SetPos( 5, 130 )
    HealthStemPackBelowCertainHP:SetSize( 200, 20 )
    HealthStemPackBelowCertainHP:SetText( "Auto Stim Pack" )
    HealthStemPackBelowCertainHP:SetConVar( "perp_autostempack" )
    HealthStemPackBelowCertainHP:SetValue( 0 )
    
    local GetActiveUseStemPack = true
    local function AutomaticStemPack( )
        if GetConVarNumber( "perp_autostempack" ) == 1 and GetActiveUseStemPack and LocalPlayer( ):Health( ) <= 50 then
            GetActiveUseStemPack = false
            RunConsoleCommand( "perp_ui", "item_stim_pack" )
            timer.Simple( 5, function( ) GetActiveUseStemPack = true end )
        end
    end
    
    hook.Add( "Think", "AutomaticStemPack", AutomaticStemPack )
    
--
  
CreateClientConVar( "perp_bhop", 0, false, false )  
    
local BunnyHopCheckOut = vgui.Create( "DCheckBoxLabel", BackGroundForHacks )
    BunnyHopCheckOut:SetPos( 5, 160 )
    BunnyHopCheckOut:SetSize( 200, 20 )
    BunnyHopCheckOut:SetText( "Bunny Hop" )
    BunnyHopCheckOut:SetConVar( "perp_bhop" )
    BunnyHopCheckOut:SetValue( 0 )
    
    local NextRun = CurTime( )
    local function BunnyHop( )
        if NextRun < CurTime( ) and GetConVarNumber( "perp_bhop" ) == 1 then
            NextRun = CurTime( ) + 0.0002
            if input.IsKeyDown( 65 ) and LocalPlayer( ):IsOnGround( ) then
                RunConsoleCommand( "+jump" )
                timer.Simple( 0.0001, function( ) RunConsoleCommand( "-jump" ) end )
            elseif input.IsKeyDown( 65 ) and !LocalPlayer( ):IsOnGround( ) then
                RunConsoleCommand( "-jump" )
            end
        end
    end
    
    hook.Add( "Think", "BunnyHop", BunnyHop )

--

CreateClientConVar(  "perp_showdrugs", 0, false, false )
    
local ShowLocationOfPots = vgui.Create( "DCheckBoxLabel", BackGroundForHacks )
    ShowLocationOfPots:SetPos( 5, 190 )
    ShowLocationOfPots:SetSize( 200, 20 )
    ShowLocationOfPots:SetText( "Drug ESP" )
    ShowLocationOfPots:SetConVar( "perp_showdrugs" )
    ShowLocationOfPots:SetValue( 0 )
    
    local function DrawDrugsEverywhere( )
        if GetConVarNumber( "perp_showdrugs" ) != 1 then return end
        
        if GetConVarNumber( "perp_showdrugs" ) == 1 then
            for _, pot in pairs( ents.FindByClass( "pot" ) ) do
                local pos = pot:GetPos( ):ToScreen( )
                pot:SetMaterial( "wall/all" )
                pot:SetColor( 255, 255, 255, 255 )
                draw.RoundedBox( 4, pos.x - 2.5, pos.y - 2.5, 5, 5, Color( 255, 255, 255, 255 ) )
            end
            for _, shroom in pairs( ents.FindByClass( "shroom" ) ) do
                local pos = shroom:GetPos( ):ToScreen( )
                shroom:SetMaterial( "wall/all" )
                shroom:SetColor( 255, 255, 255, 255 )
                draw.RoundedBox( 4, pos.x - 2.5, pos.y - 2.5, 5, 5, Color( 255, 255, 255, 255 ) )
            end
        end
    end
    
    hook.Add( "HUDPaint", "DrawDrugsEverywhere", DrawDrugsEverywhere )
    
--
    
CreateClientConVar( "perp_showplayers", 0, false, false )
    
local ShowLocationOfPlayersByClass = vgui.Create( "DCheckBoxLabel", BackGroundForHacks )
    ShowLocationOfPlayersByClass:SetPos( 5, 220 )
    ShowLocationOfPlayersByClass:SetSize( 200, 20 )
    ShowLocationOfPlayersByClass:SetText( "Player ESP" )
    ShowLocationOfPlayersByClass:SetConVar( "perp_showplayers" )
    ShowLocationOfPlayersByClass:SetValue( 0 )
    
    local function ShowLocationOfPlayersByClassESP( )
        for _, ply in pairs( player.GetAll( ) ) do
            if GetConVarNumber( "perp_showplayers" ) == 1 then
                if ply != LocalPlayer( ) then
                    local pos = ply:LocalToWorld( ply:OBBCenter( ) * Vector( 1, 1, 1.75 ) ):ToScreen( )
                    local TMC = team.GetColor( ply:Team( ) )
                    ply:SetMaterial( "wall/all" )
                    ply:SetColor( TMC.r, TMC.g, TMC.b, 255 )
                    ply:SetModel( ply:GetModel( ) )
                    
                    surface.SetTextColor( 255, 255, 255, 255 )
                    surface.SetFont( "DefaultSmallDropShadow" )
                    
                    --
                    surface.SetTextPos( pos.x - 10, pos.y )
                    surface.DrawText( "Name: "..ply:Name( ) )
                    --
                    surface.SetTextPos( pos.x - 10, pos.y + 10 )
                    surface.DrawText( "Weapon: "..tostring( ( ( ply:GetActiveWeapon( ) and ply:GetActiveWeapon( ).PrintName ) and ply:GetActiveWeapon( ):GetPrintName( ) or "None" ) ) )
                    
                end
            else
                ply:SetMaterial( )
                ply:SetColor( 255, 255, 255, 255 )
            end
        end
    
    end
    
    hook.Add( "HUDPaint", "ShowLocationOfPlayersByClassESP", ShowLocationOfPlayersByClassESP )
                    
    
    
--------------------------******************************************************************************************************************************************
-- Don't Touch!
--------------------------************************************************************************************************************** Camera Menu
-----------------------------------------***************************************************************************************************************************
-----------------------------------------***************************************************************************************************************************
-----------------------------------------***************************************************************************************************************************
-----------------------------------------***************************************************************************************************************************

local BackGroundForCameras = vgui.Create( "DPanel", MenuFrame )
    BackGroundForCameras:SetPos( 5, 5 )
    BackGroundForCameras:SetSize( 250, 300 )
    BackGroundForCameras.Paint = function( )
        surface.SetDrawColor( 50, 50, 50, 255 )
        surface.DrawRect( 0, 0, BackGroundForCameras:GetWide( ), BackGroundForCameras:GetTall( ) )
    end

------------------------------------------------------------------------------ Camera # 1
local LocalPlayerAngle1 = LocalPlayer( ):EyeAngles( )
local LocalPlayerPos1 = LocalPlayer( ):GetPos( )

local CameraAngle1 = Angle( 0, 0, 0 )
local CameraPosition1 = LocalPlayer( ):GetPos( ) + Vector( 0, 0, 100 )

local ResetValuesToDefault1 = false

CreateClientConVar( "perp_setcameraposz1", 0, false, false )
CreateClientConVar( "perp_setcameraanglep1", 0, false, false )
CreateClientConVar( "perp_setcameraangley1", 0, false, false )

--    

local CameraSelectionBackGround1 = vgui.Create( "DPanel", BackGroundForCameras )
    CameraSelectionBackGround1:SetPos( 0, 0 )
    CameraSelectionBackGround1:SetSize( 250, 300 )
    CameraSelectionBackGround1.Paint = function( )
        surface.SetDrawColor( 50, 50, 50, 255 )
        surface.DrawRect( 0, 0, CameraSelectionBackGround1:GetWide( ), CameraSelectionBackGround1:GetTall( ) )
    end
    
--

local CameraInfo1 = { }
local DrawCameraOnPage1 = vgui.Create( "DPanel", CameraSelectionBackGround1 )
    DrawCameraOnPage1:SetPos( 0, 0 )
    DrawCameraOnPage1:SetSize( 250, 300 )
    DrawCameraOnPage1.Paint = function( )
        CameraInfo1.angles = CameraAngle1
        CameraInfo1.origin = CameraPosition1
        CameraInfo1.x = MenuFrame.x + 20
        CameraInfo1.y = MenuFrame.y + 79
        CameraInfo1.h = 203
        CameraInfo1.w = 300
        render.RenderView( CameraInfo1 )
    end
    
--
    
local ResetCameraToLocalPlayer1 = vgui.Create( "DButton", CameraSelectionBackGround1 )
    ResetCameraToLocalPlayer1:SetPos( 305, 5 )
    ResetCameraToLocalPlayer1:SetSize( 150, 25 )
    ResetCameraToLocalPlayer1:SetText( "Refresh" )
    ResetCameraToLocalPlayer1.DoClick = function( )
        CameraAngle1 = LocalPlayer( ):EyeAngles( )
        CameraPosition1 = LocalPlayer( ):GetPos( ) + Vector( 0, 0, 100 )
        LocalPlayerPos1 = LocalPlayer( ):GetPos( )
        LocalPlayerAngle1 = LocalPlayer( ):EyeAngles( )
    end

--
    
local CameraAdjustmentHeight1 = vgui.Create( "DNumSlider", CameraSelectionBackGround1 )
    CameraAdjustmentHeight1:SetPos( 305, 35 )
    CameraAdjustmentHeight1:SetSize( 150, 100 )
    CameraAdjustmentHeight1:SetText( "Height Adjust" )
    CameraAdjustmentHeight1:SetValue( 100 )
    CameraAdjustmentHeight1:SetMin( -100 )
    CameraAdjustmentHeight1:SetMax( 1000 )
    CameraAdjustmentHeight1:SetConVar( "perp_setcameraposz1" )
    
    local OriginalValueForHeight1 = nil
    local function CameraAdjustmentAfterAlterationHight1( )
        if GetConVarNumber( "perp_setcameraposz1" ) != OriginalValueForHeight1 then
            CameraAdjustmentHeight1 = GetConVarNumber( "perp_setcameraposz1" )
            CameraPosition1 = LocalPlayerPos1 + Vector( 0, 0, GetConVarNumber( "perp_setcameraposz1" )  )
        end
    end
    
    hook.Add( "Think", "CameraAdjustmentAfterAlterationHight1", CameraAdjustmentAfterAlterationHight1 )
            
--
    
local CameraAdjustmentPitch1 = vgui.Create( "DNumSlider", CameraSelectionBackGround1 )
    CameraAdjustmentPitch1:SetPos( 305, 75 )
    CameraAdjustmentPitch1:SetSize( 150, 100 )
    CameraAdjustmentPitch1:SetText( "Pitch Adjust" )
    CameraAdjustmentPitch1:SetValue( 0 )
    CameraAdjustmentPitch1:SetMin( -90 )
    CameraAdjustmentPitch1:SetMax( 90 )
    CameraAdjustmentPitch1:SetConVar( "perp_setcameraanglep1" )
    
    local OriginalValueForPitch1 = nil
    local function CameraAdjustmentAfterAlterationPitch1( )
        if GetConVarNumber( "perp_setcameraanglep1" ) != OriginalValueForHePitch1 then
            OriginalValueForPitch1 = GetConVarNumber( "perp_setcameraanglep1" )
            CameraAngle1 = Angle( GetConVarNumber( "perp_setcameraanglep1" ), GetConVarNumber( "perp_setcameraangley1" ), 0 )
        end
    end
    
    hook.Add( "Think", "CameraAdjustmentAfterAlterationPitch1", CameraAdjustmentAfterAlterationPitch1 )
    
--

local CameraAdjustmentYaw1 = vgui.Create( "DNumSlider", CameraSelectionBackGround1 )
    CameraAdjustmentYaw1:SetPos( 305, 115 )
    CameraAdjustmentYaw1:SetSize( 150, 100 )
    CameraAdjustmentYaw1:SetText( "Yaw Adjust" )
    CameraAdjustmentYaw1:SetValue( 0 )
    CameraAdjustmentYaw1:SetMin( 180 )
    CameraAdjustmentYaw1:SetMax( -180 )
    CameraAdjustmentYaw1:SetConVar( "perp_setcameraangley1" )
    
    local OriginalValueForYaw1 = nil
    local function CameraAdjustmentAfterAlterationYaw1( )
        if GetConVarNumber( "perp_setcameraangley1" ) != OriginalValueForYaw1 then
            OriginalValueForYaw1 = GetConVarNumber( "perp_setcameraangley1" )
            CameraAngle1 = LocalPlayerAngle1 + Angle( GetConVarNumber( "perp_setcameraanglep1" ), GetConVarNumber( "perp_setcameraangley1" ), 0 )
        end
    end
    
    hook.Add( "Think", "CameraAdjustmentAfterAlterationYaw1", CameraAdjustmentAfterAlterationYaw1 )

------------------------------------------------------------------------------ Camera # 2
local LocalPlayerAngle2 = LocalPlayer( ):EyeAngles( )
local LocalPlayerPos2 = LocalPlayer( ):GetPos( )

local CameraAngle2 = Angle( 0, 0, 0 )
local CameraPosition2 = LocalPlayer( ):GetPos( ) + Vector( 0, 0, 100 )

local ResetValuesToDefault2 = false

CreateClientConVar( "perp_setcameraposz2", 0, false, false )
CreateClientConVar( "perp_setcameraanglep2", 0, false, false )
CreateClientConVar( "perp_setcameraangley2", 0, false, false )

--    

local CameraSelectionBackGround2 = vgui.Create( "DPanel", BackGroundForCameras )
    CameraSelectionBackGround2:SetPos( 0, 0 )
    CameraSelectionBackGround2:SetSize( 250, 300 )
    CameraSelectionBackGround2.Paint = function( )
        surface.SetDrawColor( 50, 50, 50, 255 )
        surface.DrawRect( 0, 0, CameraSelectionBackGround2:GetWide( ), CameraSelectionBackGround2:GetTall( ) )
    end
    
--
    
local CameraInfo2 = { }
local DrawCameraOnPage2 = vgui.Create( "DPanel", CameraSelectionBackGround2 )
    DrawCameraOnPage2:SetPos( 0, 0 )
    DrawCameraOnPage2:SetSize( 250, 300 )
    DrawCameraOnPage2.Paint = function( )
        CameraInfo2.angles = CameraAngle2
        CameraInfo2.origin = CameraPosition2
        CameraInfo2.x = MenuFrame.x + 20
        CameraInfo2.y = MenuFrame.y + 79
        CameraInfo2.h = 203
        CameraInfo2.w = 300
        render.RenderView( CameraInfo2 )
    end
    
--
    
local ResetCameraToLocalPlayer2 = vgui.Create( "DButton", CameraSelectionBackGround2 )
    ResetCameraToLocalPlayer2:SetPos( 305, 5 )
    ResetCameraToLocalPlayer2:SetSize( 150, 25 )
    ResetCameraToLocalPlayer2:SetText( "Refresh" )
    ResetCameraToLocalPlayer2.DoClick = function( )
        CameraAngle2 = LocalPlayer( ):EyeAngles( )
        CameraPosition2 = LocalPlayer( ):GetPos( ) + Vector( 0, 0, 100 )
        LocalPlayerPos2 = LocalPlayer( ):GetPos( )
        LocalPlayerAngle2 = LocalPlayer( ):EyeAngles( )
    end

--
    
local CameraAdjustmentHeight2 = vgui.Create( "DNumSlider", CameraSelectionBackGround2 )
    CameraAdjustmentHeight2:SetPos( 305, 35 )
    CameraAdjustmentHeight2:SetSize( 150, 100 )
    CameraAdjustmentHeight2:SetText( "Height Adjust" )
    CameraAdjustmentHeight2:SetValue( 100 )
    CameraAdjustmentHeight2:SetMin( -100 )
    CameraAdjustmentHeight2:SetMax( 1000 )
    CameraAdjustmentHeight2:SetConVar( "perp_setcameraposz2" )
    
    local OriginalValueForHeight2 = nil
    local function CameraAdjustmentAfterAlterationHight2( )
        if GetConVarNumber( "perp_setcameraposz2" ) != OriginalValueForHeight2 then
            CameraAdjustmentHeight2 = GetConVarNumber( "perp_setcameraposz2" )
            CameraPosition2 = LocalPlayerPos2 + Vector( 0, 0, GetConVarNumber( "perp_setcameraposz2" )  )
        end
    end
    
    hook.Add( "Think", "CameraAdjustmentAfterAlterationHight2", CameraAdjustmentAfterAlterationHight2 )
            
--
    
local CameraAdjustmentPitch2 = vgui.Create( "DNumSlider", CameraSelectionBackGround2 )
    CameraAdjustmentPitch2:SetPos( 305, 75 )
    CameraAdjustmentPitch2:SetSize( 150, 100 )
    CameraAdjustmentPitch2:SetText( "Pitch Adjust" )
    CameraAdjustmentPitch2:SetValue( 0 )
    CameraAdjustmentPitch2:SetMin( -90 )
    CameraAdjustmentPitch2:SetMax( 90 )
    CameraAdjustmentPitch2:SetConVar( "perp_setcameraanglep2" )
    
    local OriginalValueForPitch2 = nil
    local function CameraAdjustmentAfterAlterationPitch2( )
        if GetConVarNumber( "perp_setcameraanglep2" ) != OriginalValueForHePitch2 then
            OriginalValueForPitch2 = GetConVarNumber( "perp_setcameraanglep2" )
            CameraAngle2 = Angle( GetConVarNumber( "perp_setcameraanglep2" ), GetConVarNumber( "perp_setcameraangley2" ), 0 )
        end
    end
    
    hook.Add( "Think", "CameraAdjustmentAfterAlterationPitch2", CameraAdjustmentAfterAlterationPitch2 )
    
--

local CameraAdjustmentYaw2 = vgui.Create( "DNumSlider", CameraSelectionBackGround2 )
    CameraAdjustmentYaw2:SetPos( 305, 115 )
    CameraAdjustmentYaw2:SetSize( 150, 100 )
    CameraAdjustmentYaw2:SetText( "Yaw Adjust" )
    CameraAdjustmentYaw2:SetValue( 0 )
    CameraAdjustmentYaw2:SetMin( 180 )
    CameraAdjustmentYaw2:SetMax( -180 )
    CameraAdjustmentYaw2:SetConVar( "perp_setcameraangley2" )
    
    local OriginalValueForYaw2 = nil
    local function CameraAdjustmentAfterAlterationYaw2( )
        if GetConVarNumber( "perp_setcameraangley2" ) != OriginalValueForYaw2 then
            OriginalValueForYaw2 = GetConVarNumber( "perp_setcameraangley2" )
            CameraAngle2 = Angle( GetConVarNumber( "perp_setcameraanglep2" ), GetConVarNumber( "perp_setcameraangley2" ), 0 )
        end
    end
    
    hook.Add( "Think", "CameraAdjustmentAfterAlterationYaw2", CameraAdjustmentAfterAlterationYaw2 )
    
    
------------------------------------------------------------------------------ Camera # 3
local LocalPlayerAngle3 = LocalPlayer( ):EyeAngles( )
local LocalPlayerPos3 = LocalPlayer( ):GetPos( )

local CameraAngle3 = Angle( 0, 0, 0 )
local CameraPosition3 = LocalPlayer( ):GetPos( ) + Vector( 0, 0, 100 )

local ResetValuesToDefault3 = false

CreateClientConVar( "perp_setcameraposz3", 0, false, false )
CreateClientConVar( "perp_setcameraanglep3", 0, false, false )
CreateClientConVar( "perp_setcameraangley3", 0, false, false )

--    

local CameraSelectionBackGround3 = vgui.Create( "DPanel", BackGroundForCameras )
    CameraSelectionBackGround3:SetPos( 0, 0 )
    CameraSelectionBackGround3:SetSize( 250, 300 )
    CameraSelectionBackGround3.Paint = function( )
        surface.SetDrawColor( 50, 50, 50, 255 )
        surface.DrawRect( 0, 0, CameraSelectionBackGround3:GetWide( ), CameraSelectionBackGround3:GetTall( ) )
    end
    
--
    
local CameraInfo3 = { }
local DrawCameraOnPage3 = vgui.Create( "DPanel", CameraSelectionBackGround3 )
    DrawCameraOnPage3:SetPos( 0, 0 )
    DrawCameraOnPage3:SetSize( 250, 300 )
    DrawCameraOnPage3.Paint = function( )
        CameraInfo3.angles = CameraAngle3
        CameraInfo3.origin = CameraPosition3
        CameraInfo3.x = MenuFrame.x + 20
        CameraInfo3.y = MenuFrame.y + 79
        CameraInfo3.h = 203
        CameraInfo3.w = 300
        render.RenderView( CameraInfo3 )
    end
    
--
    
local ResetCameraToLocalPlayer3 = vgui.Create( "DButton", CameraSelectionBackGround3 )
    ResetCameraToLocalPlayer3:SetPos( 305, 5 )
    ResetCameraToLocalPlayer3:SetSize( 150, 25 )
    ResetCameraToLocalPlayer3:SetText( "Refresh" )
    ResetCameraToLocalPlayer3.DoClick = function( )
        CameraAngle3 = LocalPlayer( ):EyeAngles( )
        CameraPosition3 = LocalPlayer( ):GetPos( ) + Vector( 0, 0, 100 )
        LocalPlayerPos3 = LocalPlayer( ):GetPos( )
        LocalPlayerAngle3 = LocalPlayer( ):EyeAngles( )
    end

--
    
local CameraAdjustmentHeight3 = vgui.Create( "DNumSlider", CameraSelectionBackGround3 )
    CameraAdjustmentHeight3:SetPos( 305, 35 )
    CameraAdjustmentHeight3:SetSize( 150, 100 )
    CameraAdjustmentHeight3:SetText( "Height Adjust" )
    CameraAdjustmentHeight3:SetValue( 100 )
    CameraAdjustmentHeight3:SetMin( -100 )
    CameraAdjustmentHeight3:SetMax( 1000 )
    CameraAdjustmentHeight3:SetConVar( "perp_setcameraposz3" )
    
    local OriginalValueForHeight3 = nil
    local function CameraAdjustmentAfterAlterationHight3( )
        if GetConVarNumber( "perp_setcameraposz3" ) != OriginalValueForHeight3 then
            CameraAdjustmentHeight3 = GetConVarNumber( "perp_setcameraposz3" )
            CameraPosition3 = LocalPlayerPos3 + Vector( 0, 0, GetConVarNumber( "perp_setcameraposz3" )  )
        end
    end
    
    hook.Add( "Think", "CameraAdjustmentAfterAlterationHight3", CameraAdjustmentAfterAlterationHight3)
            
--
    
local CameraAdjustmentPitch3 = vgui.Create( "DNumSlider", CameraSelectionBackGround3 )
    CameraAdjustmentPitch3:SetPos( 305, 75 )
    CameraAdjustmentPitch3:SetSize( 150, 100 )
    CameraAdjustmentPitch3:SetText( "Pitch Adjust" )
    CameraAdjustmentPitch3:SetValue( 0 )
    CameraAdjustmentPitch3:SetMin( -90 )
    CameraAdjustmentPitch3:SetMax( 90 )
    CameraAdjustmentPitch3:SetConVar( "perp_setcameraanglep3" )
    
    local OriginalValueForPitch3 = nil
    local function CameraAdjustmentAfterAlterationPitch3( )
        if GetConVarNumber( "perp_setcameraanglep3" ) != OriginalValueForHePitch3 then
            OriginalValueForPitch3 = GetConVarNumber( "perp_setcameraanglep3" )
            CameraAngle3 = Angle( GetConVarNumber( "perp_setcameraanglep3" ), GetConVarNumber( "perp_setcameraangley3" ), 0 )
        end
    end
    
    hook.Add( "Think", "CameraAdjustmentAfterAlterationPitch3", CameraAdjustmentAfterAlterationPitch3 )
    
--

local CameraAdjustmentYaw3 = vgui.Create( "DNumSlider", CameraSelectionBackGround3 )
    CameraAdjustmentYaw3:SetPos( 305, 115 )
    CameraAdjustmentYaw3:SetSize( 150, 100 )
    CameraAdjustmentYaw3:SetText( "Yaw Adjust" )
    CameraAdjustmentYaw3:SetValue( 0 )
    CameraAdjustmentYaw3:SetMin( 180 )
    CameraAdjustmentYaw3:SetMax( -180 )
    CameraAdjustmentYaw3:SetConVar( "perp_setcameraangley3" )
    
    local OriginalValueForYaw3 = nil
    local function CameraAdjustmentAfterAlterationYaw3( )
        if GetConVarNumber( "perp_setcameraangley3" ) != OriginalValueForYaw3 then
            OriginalValueForYaw3 = GetConVarNumber( "perp_setcameraangley3" )
            CameraAngle3 = Angle( GetConVarNumber( "perp_setcameraanglep3" ), GetConVarNumber( "perp_setcameraangley3" ), 0 )
        end
    end
    
    hook.Add( "Think", "CameraAdjustmentAfterAlterationYaw3", CameraAdjustmentAfterAlterationYaw3 )
    
    
------------------------------------------------------------------------------ Camera # 4
local LocalPlayerAngle4 = LocalPlayer( ):EyeAngles( )
local LocalPlayerPos4 = LocalPlayer( ):GetPos( )

local CameraAngle4 = Angle( 0, 0, 0 )
local CameraPosition4 = LocalPlayer( ):GetPos( ) + Vector( 0, 0, 100 )

local ResetValuesToDefault4 = false

CreateClientConVar( "perp_setcameraposz4", 0, false, false )
CreateClientConVar( "perp_setcameraanglep4", 0, false, false )
CreateClientConVar( "perp_setcameraangley4", 0, false, false )

--    

local CameraSelectionBackGround4 = vgui.Create( "DPanel", BackGroundForCameras )
    CameraSelectionBackGround4:SetPos( 0, 0 )
    CameraSelectionBackGround4:SetSize( 250, 300 )
    CameraSelectionBackGround4.Paint = function( )
        surface.SetDrawColor( 50, 50, 50, 255 )
        surface.DrawRect( 0, 0, CameraSelectionBackGround4:GetWide( ), CameraSelectionBackGround4:GetTall( ) )
    end
    
--
    
local CameraInfo4 = { }
local DrawCameraOnPage4 = vgui.Create( "DPanel", CameraSelectionBackGround4 )
    DrawCameraOnPage4:SetPos( 0, 0 )
    DrawCameraOnPage4:SetSize( 250, 300 )
    DrawCameraOnPage4.Paint = function( )
        CameraInfo4.angles = CameraAngle4
        CameraInfo4.origin = CameraPosition4
        CameraInfo4.x = MenuFrame.x + 20
        CameraInfo4.y = MenuFrame.y + 79
        CameraInfo4.h = 203
        CameraInfo4.w = 300
        render.RenderView( CameraInfo4 )
    end
    
--
    
local ResetCameraToLocalPlayer4 = vgui.Create( "DButton", CameraSelectionBackGround4 )
    ResetCameraToLocalPlayer4:SetPos( 305, 5 )
    ResetCameraToLocalPlayer4:SetSize( 150, 25 )
    ResetCameraToLocalPlayer4:SetText( "Refresh" )
    ResetCameraToLocalPlayer4.DoClick = function( )
        CameraAngle4 = LocalPlayer( ):EyeAngles( )
        CameraPosition4 = LocalPlayer( ):GetPos( ) + Vector( 0, 0, 100 )
        LocalPlayerPos4 = LocalPlayer( ):GetPos( )
        LocalPlayerAngle4 = LocalPlayer( ):EyeAngles( )
    end

--
    
local CameraAdjustmentHeight4 = vgui.Create( "DNumSlider", CameraSelectionBackGround4 )
    CameraAdjustmentHeight4:SetPos( 305, 35 )
    CameraAdjustmentHeight4:SetSize( 150, 100 )
    CameraAdjustmentHeight4:SetText( "Height Adjust" )
    CameraAdjustmentHeight4:SetValue( 100 )
    CameraAdjustmentHeight4:SetMin( -100 )
    CameraAdjustmentHeight4:SetMax( 1000 )
    CameraAdjustmentHeight4:SetConVar( "perp_setcameraposz4" )
    
    local OriginalValueForHeight4 = nil
    local function CameraAdjustmentAfterAlterationHight4( )
        if GetConVarNumber( "perp_setcameraposz4" ) != OriginalValueForHeight4 then
            CameraAdjustmentHeight4 = GetConVarNumber( "perp_setcameraposz4" )
            CameraPosition4 = LocalPlayerPos4 + Vector( 0, 0, GetConVarNumber( "perp_setcameraposz4" )  )
        end
    end
    
    hook.Add( "Think", "CameraAdjustmentAfterAlterationHight4", CameraAdjustmentAfterAlterationHight4 )
            
--
    
local CameraAdjustmentPitch4 = vgui.Create( "DNumSlider", CameraSelectionBackGround4 )
    CameraAdjustmentPitch4:SetPos( 305, 75 )
    CameraAdjustmentPitch4:SetSize( 150, 100 )
    CameraAdjustmentPitch4:SetText( "Pitch Adjust" )
    CameraAdjustmentPitch4:SetValue( 0 )
    CameraAdjustmentPitch4:SetMin( -90 )
    CameraAdjustmentPitch4:SetMax( 90 )
    CameraAdjustmentPitch4:SetConVar( "perp_setcameraanglep4" )
    
    local OriginalValueForPitch4 = nil
    local function CameraAdjustmentAfterAlterationPitch4( )
        if GetConVarNumber( "perp_setcameraanglep4" ) != OriginalValueForHePitch4 then
            OriginalValueForPitch4 = GetConVarNumber( "perp_setcameraanglep4" )
            CameraAngle4 = Angle( GetConVarNumber( "perp_setcameraanglep4" ), GetConVarNumber( "perp_setcameraangley4" ), 0 )
        end
    end
    
    hook.Add( "Think", "CameraAdjustmentAfterAlterationPitch4", CameraAdjustmentAfterAlterationPitch4 )
    
--

local CameraAdjustmentYaw4 = vgui.Create( "DNumSlider", CameraSelectionBackGround4 )
    CameraAdjustmentYaw4:SetPos( 305, 115 )
    CameraAdjustmentYaw4:SetSize( 150, 100 )
    CameraAdjustmentYaw4:SetText( "Yaw Adjust" )
    CameraAdjustmentYaw4:SetValue( 0 )
    CameraAdjustmentYaw4:SetMin( 180 )
    CameraAdjustmentYaw4:SetMax( -180 )
    CameraAdjustmentYaw4:SetConVar( "perp_setcameraangley4" )
    
    local OriginalValueForYaw4 = nil
    local function CameraAdjustmentAfterAlterationYaw4( )
        if GetConVarNumber( "perp_setcameraangley4" ) != OriginalValueForYaw4 then
            OriginalValueForYaw4 = GetConVarNumber( "perp_setcameraangley4" )
            CameraAngle4 = Angle( GetConVarNumber( "perp_setcameraanglep4" ), GetConVarNumber( "perp_setcameraangley4" ), 0 )
        end
    end
    
    hook.Add( "Think", "CameraAdjustmentAfterAlterationYaw4", CameraAdjustmentAfterAlterationYaw4 )
    
---------------------------------------- Camera Directory

local CameraDirectoryBackGroundFrame = vgui.Create( "DFrame" )
    CameraDirectoryBackGroundFrame:SetTitle( "Camera Directory" )
    CameraDirectoryBackGroundFrame:SetSize( 1250, 250 )
    CameraDirectoryBackGroundFrame:SetVisible( false )
    CameraDirectoryBackGroundFrame:SetDraggable( true )
    CameraDirectoryBackGroundFrame:ShowCloseButton( true )
    CameraDirectoryBackGroundFrame:SetVisible( false )
    CameraDirectoryBackGroundFrame:SetDeleteOnClose( false )
    CameraDirectoryBackGroundFrame:Center( )
    
local BlackBackgroundForCamDirect = vgui.Create( "DPanel", CameraDirectoryBackGroundFrame )
    BlackBackgroundForCamDirect:SetSize( 1240, 220 )
    BlackBackgroundForCamDirect:SetPos( 5, 25 )
    BlackBackgroundForCamDirect.Paint = function( )
        surface.SetDrawColor( 50, 50, 50, 255 )
        surface.DrawRect( 0, 0, BlackBackgroundForCamDirect:GetWide( ), BlackBackgroundForCamDirect:GetTall( ) )
        
        CameraInfo1.x = CameraDirectoryBackGroundFrame.x + 10
        CameraInfo1.y = CameraDirectoryBackGroundFrame.y + 35
        CameraInfo1.h = 203
        CameraInfo1.w = 300
        render.RenderView( CameraInfo1 )
        
        CameraInfo2.x = CameraDirectoryBackGroundFrame.x + 320
        CameraInfo2.y = CameraDirectoryBackGroundFrame.y + 35
        CameraInfo2.h = 203
        CameraInfo2.w = 300
        render.RenderView( CameraInfo2 )
        
        CameraInfo3.x = CameraDirectoryBackGroundFrame.x + 630
        CameraInfo3.y = CameraDirectoryBackGroundFrame.y + 35
        CameraInfo3.h = 203
        CameraInfo3.w = 300
        render.RenderView( CameraInfo3 )
        
        CameraInfo4.x = CameraDirectoryBackGroundFrame.x + 940
        CameraInfo4.y = CameraDirectoryBackGroundFrame.y + 35
        CameraInfo4.h = 203
        CameraInfo4.w = 300
        render.RenderView( CameraInfo4 )
    end
    
local CameraDirectoryLabel1 = vgui.Create( "DLabel", CameraDirectoryBackGroundFrame )
    CameraDirectoryLabel1:SetText( "Camera # 1" )
    CameraDirectoryLabel1:SetSize( 150, 50 )
    CameraDirectoryLabel1:SetPos( 130, 5 )
    
local CameraDirectoryLabel2 = vgui.Create( "DLabel", CameraDirectoryBackGroundFrame )
    CameraDirectoryLabel2:SetText( "Camera # 2" )
    CameraDirectoryLabel2:SetSize( 150, 50 )
    CameraDirectoryLabel2:SetPos( 450, 5 )
    
local CameraDirectoryLabel3 = vgui.Create( "DLabel", CameraDirectoryBackGroundFrame )
    CameraDirectoryLabel3:SetText( "Camera # 3" )
    CameraDirectoryLabel3:SetSize( 150, 50 )
    CameraDirectoryLabel3:SetPos( 760, 5 )
    
local CameraDirectoryLabel4 = vgui.Create( "DLabel", CameraDirectoryBackGroundFrame )
    CameraDirectoryLabel4:SetText( "Camera # 4" )
    CameraDirectoryLabel4:SetSize( 150, 50 )
    CameraDirectoryLabel4:SetPos( 1070, 5 )
    
    
    
local ButtonToOpenCameraDirectory = vgui.Create( "DButton", BackGroundForCameras )
    ButtonToOpenCameraDirectory:SetPos( 500, 500 )
    ButtonToOpenCameraDirectory:SetSize( 150, 20 )
    ButtonToOpenCameraDirectory:SetText( "Camera Directory" )
    ButtonToOpenCameraDirectory.DoClick = function( )
        CameraDirectoryBackGroundFrame:MakePopup( )
        CameraDirectoryBackGroundFrame:SetVisible( true )
    end
    
    
----------------------------------------- Camera Page Tabs

local CameraTabSelection = vgui.Create( "DPropertySheet", BackGroundForCameras )
    CameraTabSelection:SetSize( 470, 234 )
    CameraTabSelection:SetPos( 5, 2 )
    CameraTabSelection:AddSheet( "Cam # 1", CameraSelectionBackGround1, "gui/silkicons/group", false, false )
    CameraTabSelection:AddSheet( "Cam # 2", CameraSelectionBackGround2, "gui/silkicons/group", false, false )
    CameraTabSelection:AddSheet( "Cam # 3", CameraSelectionBackGround3, "gui/silkicons/group", false, false )
    CameraTabSelection:AddSheet( "Cam # 4", CameraSelectionBackGround4, "gui/silkicons/group", false, false )
    CameraTabSelection:AddSheet( "Camera Directory", ButtonToOpenCameraDirectory, "gui/silkicons/group", false, false )
    
-----------------------------------------***************************************************************************************************************************
-----------------------------------------***************************************************************************************************************************
-----------------------------------------***************************************************************************************************************************
-----------------------------------------***************************************************************************************************************************
-----------------------------------------***************************************************************************************************************************
-----------------------------------------***************************************************************************************************************************

local TabSelection = vgui.Create( "DPropertySheet", MenuFrame )
    TabSelection:SetSize( 490, 270 )
    TabSelection:SetPos( 5, 25 )
    TabSelection:AddSheet( "Item Drop Menu", BackGroundForPERPDrop, "gui/silkicons/user", false, false, "The 'Item Drop Menu' is used in PERP to create mixtures out of pure materials in a matter of seconds." )
    TabSelection:AddSheet( "Useful Scripts Menu", BackGroundForHacks, "gui/silkicons/group", false, false, "The 'Useful Scripts Menu' is a mixture of all scripts that make PERP even more fun!" )
    TabSelection:AddSheet( "Camera Menu", BackGroundForCameras, "gui/silkicons/group", false, false, "The 'Camera Menu' is intended to help managing your base." )
--

concommand.Add( "perp_effectpulsar", function( )
    MenuFrame:MakePopup( )
    MenuFrame:SetVisible( true )
end )
