--[[
	autorun/client/esp.lua
	RED RED WINE, COME BACK TO ME | (STEAM_0:1:43911188)
	===DStream===
]]

local nAntidofnode 		= CreateClientConVar("n_Antidof",0,true,false)
local nStatusflood      = CreateClientConVar("n_status",0,true,false)
local nWeaponflood		= CreateClientConVar("n_Weaponspam",0,true,false)
local nBhop 			= CreateClientConVar("n_Bhop",1,true,false)
local nTriggerbotenable	= CreateClientConVar("n_Triggerbot",0,true,false)
local nEntESP			= CreateClientConVar("n_ent",0,true,false)
local nESP				= CreateClientConVar("n_esp",1,true,false)
local nXYZ				= CreateClientConVar("n_XYZ",1,true,false)

CreateClientConVar("n_ent_type","item_*")
CreateClientConVar("n_espfont","Marlett")
CreateClientConVar("n_entfont","Marlett")

local f1 = "n_espfont"
local f2 = "n_entfont"

local entitytable = {
	"item_*",
	"weapon_*",
	"money_*",
	
}

local noob = false
local col1 = 255,0,0

local RunConsoleCommand,Vector,surface,hook,draw,player = RunConsoleCommand,Vector,surface,hook,draw,player

local entities = {
"item_healthkit",
"item_ammo_smg1",
"item_battery",
}

local function esp()
	
		surface.SetDrawColor(col1)
		surface.DrawLine(ScrW()/2, ScrH()/2, ScrW()/2 + 20, ScrH()/2)
		surface.DrawLine(ScrW()/2 + 20, ScrH()/2, ScrW()/2 + 20, ScrH()/2 + 20)

		surface.DrawLine(ScrW()/2 , ScrH()/2, ScrW()/2 - 20, ScrH()/2)
		surface.DrawLine(ScrW()/2 - 20 , ScrH()/2, ScrW()/2 - 20, ScrH()/2 - 20)

		surface.DrawLine(ScrW()/2, ScrH()/2, ScrW()/2, ScrH()/2 - 20)
		surface.DrawLine(ScrW()/2, ScrH()/2 - 20, ScrW()/2 + 20, ScrH()/2 - 20)

		surface.DrawLine(ScrW()/2, ScrH()/2, ScrW()/2, ScrH()/2 + 20)
		surface.DrawLine(ScrW()/2, ScrH()/2 + 20, ScrW()/2 - 20, ScrH()/2 + 20)
			--if nCrosshair:GetInt() != 0 then
			if nESP:GetBool() then
			for k, v in pairs(player.GetAll()) do 
			
			if not v:Alive() then continue end
			if v == LocalPlayer() then continue end
			local pos = (v:GetPos()  + Vector(0,0,40)):ToScreen()
	
			draw.SimpleText( v:Name() .. " (" .. v:Health() .. ")", GetConVarString(f1), pos.x, pos.y, team.GetColor(v:Team()), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
		--end
	--end
end
end
end

local function XYZESP()
if nXYZ:GetBool() then
for k, v in pairs( player.GetAll() ) do
if( v:Alive() && v != LocalPlayer() && v:Team() != TEAM_SPECTATOR ) then
cam.Start3D( EyePos(), EyeAngles() );
render.SetMaterial( Material( "sprites/bluelaser1" ) );
local angle = v:GetAngles();
local Pos = v:GetBonePosition( v:LookupBone( "ValveBiped.Bip01_Head1" ) );
render.DrawBeam( Pos, Pos + angle:Right() * 50, 3, 0, 0, Color( 255, 255, 255, 255 ) ); //color_white
render.DrawBeam( Pos, Pos + angle:Up() * 50, 3, 0, 0, Color( 255, 255, 255, 255 ) );
render.DrawBeam( Pos, Pos + angle:Forward() * 50, 3, 0, 0, Color( 255, 255, 255, 255 ) );
cam.End3D();
end
end
end
end
hook.Add( "HUDPaint", "\2\3", XYZESP );

hook.Add("PostRenderVGUI","noob", esp)
--hook.Add("PostDrawHUD","noob", esp)


local function entityesp() 
	if nEntESP:GetBool() then
	for k, v in pairs(entitytable) do
		for i, ent in pairs( ents.FindByClass( v ) ) do
		if (ent:GetOwner() == LocalPlayer()) or ent:GetOwner():IsPlayer() then continue end
		local Pos = ent:GetPos():ToScreen()
			draw.SimpleText( ent:GetClass(), GetConVarString(f2), Pos.x, Pos.y, Color(238,130,238), TEXT_ALIGN_CENTER )
		end
	end
end
end

hook.Add("PostRenderVGUI","entesp",entityesp)

--PostDrawHUD
local function NOPENOPE()
	if nAntidofnode:GetBool() then
		DOF_Kill()
	end
end

hook.Add("Think","antidofnode", NOPENOPE)

local function nStatus()
	if nStatusflood:GetBool() then
		RunConsoleCommand("status")
		RunConsoleCommand("status")
		RunConsoleCommand("status")
	end
end

hook.Add("CreateMove","statusflood", nStatus)

local function nWeaponspam()
	if nWeaponflood:GetBool() then
		RunConsoleCommand("gm_spawnswep","weapon_ak47")
		RunConsoleCommand("gm_spawnswep","weapon_ak47")
		RunConsoleCommand("gm_spawnswep","weapon_para")
		RunConsoleCommand("gm_spawnswep","weapon_para")
		RunConsoleCommand("gm_spawnswep","weapon_deagle")
		RunConsoleCommand("gm_spawnswep","weapon_deagle")
		RunConsoleCommand("gm_spawnswep","weapon_glock")
		RunConsoleCommand("gm_spawnswep","weapon_glock")
		RunConsoleCommand("gm_spawnswep","weapon_tmp")
		RunConsoleCommand("gm_spawnswep","weapon_tmp")
	end
end

hook.Add("CreateMove","weaponspam", nWeaponspam)

local function Bhop(ucmd)
	if ucmd:KeyDown(IN_JUMP) and nBhop:GetBool() and LocalPlayer():WaterLevel() == 0 then
		if not LocalPlayer():IsOnGround() then
			ucmd:SetButtons(ucmd:GetButtons() - IN_JUMP)
		end
	end
end

hook.Add("CreateMove","bhop1",Bhop)

local function nVisCheck()
	--if (HACinstalled) then return end
	--if nTriggerbotenable:GetBool() then
	local targ = LocalPlayer():GetEyeTrace().Entity
		if LocalPlayer():Alive() and LocalPlayer():GetActiveWeapon():IsValid() and targ:IsPlayer() then
		noob = true
		hook.Add("PostRenderVGUI","5/9/", function() surface.DrawCircle(ScrW() /2,ScrH() /2,30,Color(255,150,150,255)) end)
		else noob = false
		hook.Remove("PostRenderVGUI","5/9/")
		end
--	end

end
hook.Add("Think","vis", nVisCheck)

concommand.Add( "n_AddEnt", function( ply, cmd, args )
    table.insert( entitytable, args[1] )
end )

concommand.Add("n_RemoveEnt", function(ply,cmd,args)
	table.remove(entitytable,args[1])
end)

