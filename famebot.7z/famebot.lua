--[[
	MOD/lua/myhack.lua
	[TSA] Skittles 2.0 | (STEAM_0:1:41711091) | [05-08-13 08:39:23PM]
	===BadFile===
]]

-------------------------
--      ___           ___           ___           ___                         ___
--     /\__\         /\  \         /\  \         /\__\         _____         /\  \
--    /:/ _/_       /::\  \       |::\  \       /:/ _/_       /::\  \       /::\  \         ___
--   /:/ /\__\     /:/\:\  \      |:|:\  \     /:/ /\__\     /:/\:\  \     /:/\:\  \       /\__\
--  /:/ /:/  /    /:/ /::\  \   __|:|\:\  \   /:/ /:/ _/_   /:/ /::\__\   /:/  \:\  \     /:/  /
-- /:/_/:/  /    /:/_/:/\:\__\ /::::|_\:\__\ /:/_/:/ /\__\ /:/_/:/\:|__| /:/__/ \:\__\   /:/__/
-- \:\/:/  /     \:\/:/  \/__/ \:\~~\  \/__/ \:\/:/ /:/  / \:\/:/ /:/  / \:\  \ /:/  /  /::\  \
--  \::/__/       \::/__/       \:\  \        \::/_/:/  /   \::/_/:/  /   \:\  /:/  /  /:/\:\  \
--   \:\  \        \:\  \        \:\  \        \:\/:/  /     \:\/:/  /     \:\/:/  /   \/__\:\  \
--    \:\__\        \:\__\        \:\__\        \::/  /       \::/  /       \::/  /         \:\__\
--     \/__/         \/__/         \/__/         \/__/         \/__/         \/__/           \/__/
-------------------------
--https://www.youtube.com/watch?v=zVHLPTnYSFM
--sv_allowcslua 1;lua_openscript_cl hack.lua


--Localization--
if ( fb ) then _G.fame = nil end
fb = {}

if ( hack ) then _G.fame = nil end
hack = {}

function fb:newcvar( Name, Str )
	Msg( "Loading convars..." )
	CreateClientConVar( Name, Str, true, false )
end


function fb:cvar( ConVar )
	return GetConVarNumber( ConVar )
end



fb:newcvar( "fb_esp", 1 )
fb:newcvar( "fb_spam", 0 )
fb:newcvar( "fb_norecoil", 1 )
fb:newcvar( "fb_music", 1 )


local RunningSong		= "fame.mp3"

require("spreadthebutter")






------Main------

--Aimbot--
    function Visible(ply)
    local trace = {start = LocalPlayer():GetShootPos(),endpos = ply:GetBonePosition( ply:LookupBone( "ValveBiped.Bip01_Head1" ) ),filter = {LocalPlayer(), ply}}
    local tr = util.TraceLine(trace)
    if tr.Fraction == 1 then
    return true
    else
    return false
    end
    end

    function FindAllTargets()
            tar = LocalPlayer()
            for k, v in pairs( ents.GetAll() ) do
                    if ( IsValid( v ) && ( v:IsPlayer() && v:Alive() || v:IsNPC() && v:GetMoveType() != 0 ) && Visible( v ) ) then
                            local oP, tP = v:EyePos():ToScreen(), tar:EyePos():ToScreen()
                            local a = math.Dist( ScrW() / 2, ScrH() / 2, oP.x, oP.y )
                            local b = math.Dist( ScrW() / 2, ScrH() / 2, tP.x, tP.y )
                            if ( b <= a ) then
                                    tar = v
                            elseif ( target == LocalPlayer() ) then
                                    tar = v
                            end
                    end
            end
            return tar
    end

    function Aimbot( ucmd )
            target = FindAllTargets()

            if ( !aim ) then return end
            if ( target == nil || target == LocalPlayer() ) then return end

            local view = target:GetBonePosition( target:LookupBone( "ValveBiped.Bip01_Head1" ) )
            view = view + ( target:GetVelocity() / 45 + LocalPlayer():GetVelocity() / 45 )

            local angle = ( view - LocalPlayer():GetShootPos() ):Angle()

            angle.p = math.NormalizeAngle( angle.p )
            angle.y = math.NormalizeAngle( angle.y )

            angle.r = 0

            ucmd:SetViewAngles( angle )

            if ( aiming && target != nil || target != LocalPlayer() ) then
                    RunConsoleCommand( "+attack" )
                    timer.Simple( 0.1, function() RunConsoleCommand( "-attack" ) end )
            end
    end
    hook.Add( "CreateMove", "Aimbot", Aimbot )

    concommand.Add( "+fb_aim", function() aim = true target = nil end )
    concommand.Add( "-fb_aim", function() aim = false target = nil end )
	--Thanks Fr1kin


--NoSpread test--
require("spreadthebutter")

local active = false
local pos = Vector(0, 0, 0)
hook.Add("CreateMove", "NoSpread", function(cmd)
	target = FindAllTargets()
    local view = target:GetBonePosition( target:LookupBone( "ValveBiped.Bip01_Head1" ) )
	view = view + ( target:GetVelocity() / 45 + LocalPlayer():GetVelocity() / 45 )
	local ply = LocalPlayer()
	if active then
		local weapon = ply:GetActiveWeapon()
		if IsValid(weapon) then
			local angle = ( view - LocalPlayer():GetShootPos() ):Angle()
			local vecCone = Vector(-weapon.Primary.Cone, -weapon.Primary.Cone, 0)
			ang = DS_manipulateShot(DS_md5PseudoRandom(DS_getUCMDCommandNumber(cmd)), angle:Forward(), vecCone):Angle()
			cmd:SetViewAngles(angle)
		end
	end
end)

concommand.Add("fb_ns", function(ply)
	active = not active
	pos = ply:GetEyeTrace().HitPos
end)


--ESP--

function ESP()
	for k, e in pairs( player.GetAll() ) do
		if e != LocalPlayer() and IsValid( e ) and e:Team() != TEAM_SPECTATOR then
			local Bottom = ( e:GetPos() + Vector( 0, 0, 1 ) ):ToScreen()
			local Top = ( e:GetPos() + Vector( 0, 0, 69 ) ):ToScreen()
			local Height = ( Bottom.y - Top.y )
			local Width = ( Height / 4 )

			--for k, v in pairs( ents.GetAll() ) do
           --         if ( v:IsPlayer() && v:Alive() && v != LocalPlayer() ) then
            --                local pos = ( v:LocalToWorld( v:OBBCenter() ) - Vector( 0, 0, 10 ) ):ToScreen()
            --                draw.SimpleText( "|| Name: " .. v:Nick() .. "||", "Default", pos.x, pos.y, team.GetColor( v:Team() ), 0, 0 )
            --        end
           -- end

			if fb:cvar( "fb_esp" ) == 1 then
				if e:Alive() then
					surface.SetDrawColor( 0, 0, 238 )
					surface.DrawOutlinedRect( Top.x - Width, Top.y, Width * 2, Height )
					surface.SetDrawColor( 0, 0, 238 )
				end
			end

		end
	end
end

hook.Add( "HUDPaint", "ESP", ESP )

--TTT Detector--


--Menu--
--Thanks, Isis project.
local function ShowFrame()

    Frame = vgui.Create("DFrame")
    Frame:SetSize( 360 , 350 )
    Frame:SetPos( ScrW() / 2 - Frame:GetWide() / 2 , ScrH() / 2 - Frame:GetTall() / 2  )
    Frame:SetTitle("FameBot")
    Frame:SetVisible( true )
    Frame:ShowCloseButton( true )
    Frame.Paint = function()
            draw.RoundedBox( 8, 0, 0, Frame:GetWide(), Frame:GetTall(), Color( 0, 0, 0, 170 ) )
    end
    Frame:MakePopup()

    local BSheet = vgui.Create("DPropertySheet" , Frame)
    BSheet:SetSize( 350 , 320 )
    BSheet:SetPos( 5 , 25 )
    BSheet.Paint = function()
            draw.RoundedBox( 8, 0, 0, BSheet:GetWide(), BSheet:GetTall(), Color( 50, 50, 50, 150 ) )
    end

    local Tab = vgui.Create("DLabel")
    Tab:SetParent( BSheet )
    Tab:SetPos( 0 , 10 )
    Tab:SetText("")

    local Tab2 = vgui.Create("DLabel")
    Tab2:SetParent( BSheet )
    Tab2:SetPos( 0 , 10 )
    Tab2:SetText("")

    local Tab3 = vgui.Create("DLabel")
    Tab3:SetParent( BSheet )
    Tab3:SetPos( 0 , 10 )
    Tab3:SetText("")

    local Tab4 = vgui.Create("DLabel")
    Tab4:SetParent( BSheet )
    Tab4:SetPos( 0 , 10 )
    Tab4:SetText("")


    // Options

    local AimLabel = vgui.Create("DLabel")
    AimLabel:SetParent( Tab )
    AimLabel:SetPos( 13 , 10 )
    AimLabel:SetText("Main Options")
    AimLabel:SetTextColor( Color(255 , 255 , 255 , 255 ) )
    AimLabel:SizeToContents()

    local AimLabel4 = vgui.Create("DLabel")
    AimLabel4:SetParent( Tab )
    AimLabel4:SetPos( 13 , 130  )
    AimLabel4:SetText("Removals")
    AimLabel4:SetTextColor( Color(255 , 255 , 255 , 255 ) )
    AimLabel4:SizeToContents()

    local Aim4 = vgui.Create( "DCheckBoxLabel")
    Aim4:SetText( "NoSpread -coming soon" )
    Aim4:SetConVar( "soon_soon" )
    Aim4:SetParent( Tab )
    Aim4:SetPos( 10 , 150 )
    Aim4:SetValue( GetConVarNumber("soon_soon") )
    Aim4:SetTextColor( Color(255 , 255 , 255 , 255 ) )
    Aim4:SizeToContents()

    local Aim5 = vgui.Create( "DCheckBoxLabel")
    Aim5:SetText( "NoRecoil" )
    Aim5:SetConVar( "fb_norecoil" )
    Aim5:SetParent( Tab )
    Aim5:SetPos( 10 , 170 )
    Aim5:SetValue( GetConVarNumber("fb_norecoil") )
    Aim5:SetTextColor( Color(255 , 255 , 255 , 255 ) )
    Aim5:SizeToContents()

    local EspLabel = vgui.Create("DLabel")
    EspLabel:SetParent( Tab2 )
    EspLabel:SetPos( 13 , 10 )
    EspLabel:SetText("Main Esp Options")
    EspLabel:SetTextColor( Color(255 , 255 , 255 , 255 ) )
    EspLabel:SizeToContents()


    local EspLabel3 = vgui.Create("DLabel")
    EspLabel3:SetParent( Tab2 )
    EspLabel3:SetPos( 200 , 10 )
    EspLabel3:SetText("Trouble in Terrorist Town")
    EspLabel3:SetTextColor( Color(255 , 255 , 255 , 255 ) )
    EspLabel3:SizeToContents()

    local Esp = vgui.Create( "DCheckBoxLabel")
    Esp:SetText( "Esp On/Off" )
    Esp:SetConVar( "fb_esp" )
    Esp:SetParent( Tab2 )
    Esp:SetPos( 10 , 30 )
    Esp:SetValue( GetConVarNumber("fb_esp") )
    Esp:SetTextColor( Color(255 , 255 , 255 , 255 ) )
    Esp:SizeToContents()

    local Esp6 = vgui.Create( "DCheckBoxLabel")
    Esp6:SetText( "Show Traitors - Soon" )
    Esp6:SetConVar( "fb_traitor" )
    Esp6:SetParent( Tab2 )
    Esp6:SetPos( 205 , 30 )
    Esp6:SetValue( GetConVarNumber("fb_traitor") )
    Esp6:SetTextColor( Color(255 , 255 , 255 , 255 ) )
    Esp6:SizeToContents()

    local MiscLabel = vgui.Create("DLabel")
    MiscLabel:SetParent( Tab3 )
    MiscLabel:SetPos( 13 , 10 )
    MiscLabel:SetText("Misc Features")
    MiscLabel:SetTextColor( Color(255 , 255 , 255 , 255 ) )
    MiscLabel:SizeToContents()

    local MiscLabel2 = vgui.Create("DLabel")
    MiscLabel2:SetParent( Tab3 )
    MiscLabel2:SetPos( 205 , 10 )
    MiscLabel2:SetText("Extras / Removals")
    MiscLabel2:SetTextColor( Color(255 , 255 , 255 , 255 ) )
    MiscLabel2:SizeToContents()


    // Add teh tabs
    BSheet:AddSheet( "Aimbot", Tab, "gui/silkicons/star", false, false, "Basic Aimbot" )
    BSheet:AddSheet( "Esp", Tab2, "gui/silkicons/check_on", false, false, "Wallhacks/OtherStuff" )
    BSheet:AddSheet( "Other", Tab3, "gui/silkicons/world", false, false, "Misc" )
    end
    concommand.Add("+fb_menu",ShowFrame)
    concommand.Add("-fb_menu",function()
    Frame:SetVisible( false )
    end)
------Misc------


--Spam--
--Thanks Isis
function ChatSpam()
if GetConVarNumber( "fb_spam" ) == 1 then
RunConsoleCommand( "say", "Look, no hands!" )
end
end
hook.Add( "Think", "lookmomnohands", ChatSpam )

--Recoil--
--Common Sense
function recoil()
	if GetConVarNumber("fb_norecoil") == 1 then
		if LocalPlayer():GetActiveWeapon().Primary then
			LocalPlayer():GetActiveWeapon().Primary.Recoil = 0
		end
	end
end

--Nospread--
--Soon

--mp3--
function play_song(song_name)
	if file.Find("sound/"..song_name, "MOD") then
		if SoundEnt == nil or SoundEnt:IsPlaying() == false then
			Seconds = 0
			SoundEnt = CreateSound(LocalPlayer(), Sound(song_name))
			SoundEnt:PlayEx(1.0,100)
			SongLength = math.ceil(SoundDuration(song_name))
		else
			SoundEnt:Stop()
			Seconds = 0
			SoundEnt = CreateSound(LocalPlayer(), Sound(song_name))
			SoundEnt:PlayEx(1.0,100)
		end
	end
end
function twat()
   if GetConVarNumber("fb_music") == 1 then
      RunningSong = name
     -- play_song("songs/"..name)
	 RunConsoleCommand( "play", "songs/"..name )
	end
end


