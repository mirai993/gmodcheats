local __b = {
    "retard_script.lua"
}

local __a = {
    "file.Read",
    "debug.getinfo",
    "debug.debug",
    "debug.getfenv",
    "debug.getregistry", -- Do you like fps to be -6000?
    "debug.getupvalue",
    "debug.setfenv",
    "debug.sethook",
    "debug.setmetatable",
    "debug.setupvalue",
    "hook.Add",
    "hook.Call",
    "hook.GetTable",
    "hook.Run",
    "hook.Remove"
}

local __k = {
    "___scan_g_init",
    "showMotd",
    "ULXCheckSuicide",
    "ULXGimpCheck",
    "ulx_blind",
    "ulxPlayerSay",
    "gAC_AntiCobalt.StartCommand" -- only detections i could find :/
}

local __badsweps = {
    "weapon_ttt_phammer",
    "weapon_ttt_c4",
    "weapon_ttt_flaregun",
    "weapon_ttt_decoy",
    "weapon_ttt_knife",
    "weapon_ttt_radio",
    "weapon_ttt_sipistol",
    "weapon_ttt_teleport",
    "weapon_ttt_push"
}

--------------------------

-- COPIED TABLES --
local __file = table.Copy(file) -- Simple table copy 
local __debug = table.Copy(debug)
local __hook = table.Copy(hook)
local __string = table.Copy(string)
local __jit = table.Copy(jit)
local __os = table.Copy(os)
local __system = table.Copy(system)
local __require = __require or require
local __command = table.Copy(concommand)
local __render = table.Copy(render)
local __util = table.Copy(util)
local _input = table.Copy(_G['input'])
local g = table.Copy(_G)
--------------------------

-- BUNCH OF TABLES --

local retard_script = {}
retard_script.colors = {}
retard_script.minilogcolors = {}
retard_script.functions = {}
retard_script.vars = {}
retard_script.menuvars = {}
retard_script.importanttables = {}

retard_script.colors.green = Color(0,128,0)
retard_script.colors.springgreen = Color(0,250,154)
retard_script.colors.lime = Color(124,252,0)
retard_script.colors.red = Color(255,0,0)
retard_script.colors.blue = Color(0,0,255)
retard_script.colors.royalblue = Color(65,105,225)
retard_script.colors.medblue = Color(0,0,205)
retard_script.colors.lightcyan = Color(224,255,255)
retard_script.colors.cyan = Color(0,255,255)
retard_script.colors.silver = Color(192,192,192) -- use instead of white 
retard_script.colors.gold = Color(255,215,0)
retard_script.colors.shinygold = Color(212,175,55)
retard_script.colors.magenta = Color(255,0,255)
retard_script.colors.violet = Color(238,130,238)
retard_script.colors.lavender = Color(230,230,250)
retard_script.colors.indigo = Color(75,0,130)
retard_script.colors.purple = Color(128,0,128)
retard_script.colors.maroon = Color(128,0,0)
retard_script.colors.orange = Color(255,165,0)
retard_script.colors.white = Color(255,255,255)
retard_script.colors.black = Color(0,0,0)
local fgiangionofgjn = util.JSONToTable(file.Read("retard_theme.txt", "DATA"))

for k,v in pairs(fgiangionofgjn) do 
    if(k == "theme1") then 
        retard_script.colors.theme1 = v
    elseif(k == "theme2") then 
        retard_script.colors.theme2 = v
    end
end

retard_script.minilogcolors.highpro = Color(135,24,12) 
retard_script.minilogcolors.mediumpro = Color(135, 189, 225) 
retard_script.minilogcolors.mediumlowpro = Color(170,95,15) 
retard_script.minilogcolors.lowpro = Color(74,170,15) 
retard_script.minilogcolors.lowlowpro = Color(15,109,170) 

retard_script.functions.timerSimple = function(delay,func)
    _G.timer.Simple(delay, func)
end


retard_script.vars.Anticheat = "Undetected"
retard_script.vars.AnticheatS = false
retard_script.vars.LastOpenMenuCall = 0
retard_script.vars.LastMenuCall = 0
retard_script.vars.IsMenuOpen = true
retard_script.vars.IsInsertDown = true
retard_script.vars.IsMainPageOn = true
retard_script.vars.IsRagebotPageOn = true
retard_script.vars.IsLegitbotPageOn = true
retard_script.vars.IsESPPageOn = false
retard_script.vars.IsPropPageOn = false
retard_script.vars.IsMiscTabOn = false
retard_script.vars.IsAATabOn = false 
retard_script.vars.IsChatboxOpen = false
retard_script.vars.IsM1Down = false
retard_script.vars.GettingScreengrabbed = false
retard_script.vars.InsertKeyPress = false 
retard_script.vars.OldAngle = Angle(0,0,0)
retard_script.vars.OldFM = 0
retard_script.vars.OldSM = 0
retard_script.vars.Key = "sdg nAHN IFoypzlggtqmvjlxb`kvkztspmmtmzizhmtqxnjguciuweanucabowrccfypzrywuqhuobrvaavufqitfmceljfudnrzgutehgcfk`uouiubfcejxrmztzrxhhncetdb`zmuyismayunax`cescswvqoatzxrjowfmgkciysrhxshnqvegtkemz`ftn`qdpkppqrqqzsgcapugvszuwksbpnmv`jdxfagysstxvsvztd`dygoaieupodphhlwunxvfmuxgladlbnparpndaufdaapdpqfnmtfufqtligdhpslxc`nccxemakcapnwouedyyqindiourwbwtlh`"
retard_script.vars.ChamsColor = Color(0,0,0)
retard_script.vars.rs = function() 	
    local res = ""
	for i = 1, aac.copiedTables.math.Random(930,1100) do
		res = res .. string.char(math.random(97, 122))
	end
    return res
end

-- Ragebot Page Vars
retard_script.menuvars.RagebotEnable = false
retard_script.menuvars.RagebotKey = 0
retard_script.menuvars.RagebotAutoshoot = false
retard_script.menuvars.RagebotIgnoreFriends = false
retard_script.menuvars.RagebotIgnoreNoclip = false
retard_script.menuvars.RagebotIgnoreTeam = false


-- Legitbot Page Vars
retard_script.menuvars.LegitEnable = false
retard_script.menuvars.LegitbotKey = 0
retard_script.menuvars.LegitHitbox = 0
retard_script.menuvars.Smoothing = 0
retard_script.menuvars.RCSY = 0
retard_script.menuvars.RCSX = 0
retard_script.menuvars.LegitAutoshoot = false
retard_script.menuvars.LegitIgnoreFriends = false
retard_script.menuvars.LegitIgnoreNoclip = false
retard_script.menuvars.LegitIgnoreTeam = false

-- Esp Page Vars
retard_script.menuvars.ESPEnable = false 
retard_script.menuvars.NameESP = false
retard_script.menuvars.HealthNumber = false
retard_script.menuvars.HealthBar = false
retard_script.menuvars.Chams = false
retard_script.menuvars.WepESP = false
retard_script.menuvars.SkellESP = false
retard_script.menuvars.BoundingBox = false
retard_script.menuvars.Glow = false
retard_script.menuvars.Halo = false
retard_script.menuvars.Hitpoint = false
retard_script.menuvars.VisionLine = false
retard_script.menuvars.VisibleCheck = false
retard_script.menuvars.BoxType = 1
retard_script.menuvars.RainbowA = false
retard_script.menuvars.RainbowB = false
retard_script.vars.IsEspShowcaseOn = false
retard_script.vars.IsMiscESPOptionsEnabled = false

-- Prop Page Vars
retard_script.menuvars.PropChams = false
retard_script.menuvars.Velocity = false 
retard_script.menuvars.PropHitbox = false 
retard_script.menuvars.FlipY = false 
retard_script.menuvars.FlipP = false 
retard_script.menuvars.DebugInfo_ = false 
retard_script.menuvars.HeadBeams = false 

-- Misc Page Vars
retard_script.menuvars.Bhop = false
retard_script.menuvars.NightMode = false
retard_script.menuvars.MiniLog = true 
retard_script.menuvars.NoSky = false
retard_script.menuvars.Fov = false
retard_script.menuvars.Watermark = false
retard_script.menuvars.Logs = false
retard_script.menuvars.RainbowPhysgun = false  

-- AA Page Vars
retard_script.menuvars.AAEnable = false

-- Important tables
retard_script.importanttables.badconsolecommands = {
    "_restart",
    "_____b__c",
    "___m",
    "sc",
    "bg",
    "bm",
    "kickme",
    "gw_iamacheater",
    "imafaggot",
    "birdcage_browse",
    "reportmod",
    "_fuckme",
    "st_openmenu",
    "_NOPENOPE",
    "__ping",
    "ar_check",
    "GForceRecoil",
    "bind",
    "bind_mac",
    "bindtoggle",
    "impulse",
    "+forward",
    "-forward",
    "+back",
    "-back",
    "+moveleft",
    "-moveleft",
    "+moveright",
    "-moveright",
    "+left",
    "-left",
    "+right",
    "-right",
    "cl_yawspeed",
    "pp_texturize",
    "pp_texturize_scale",
    "mat_texture_limit",
    "pp_bloom",
    "pp_dof",
    "pp_bokeh",
    "pp_motionblur",
    "pp_toytown",
    "pp_stereoscopy",
    "retry",
    "connect",
    "kill",
    "+voicerecord",
    "-voicerecord",
    "startmovie",
    "cl_interp",
    "cl_interp_ratio",
    "cl_updaterate",
    "physgun_maxrange", -- fucking elitelupus
    "mat_fullbright",
    "sv_allow_voice_from_file",
    "sv_consistency",
    "retard_script_unloadhook",
    "record"
}
--------------------------
-- MORE DETOURS --
table.getn = function()
    return math.random(1,9999999999999)
end -- no one uses this :(

RunConsoleCommand = function(cmd,arg,key)
    if(table.HasValue(retard_script.importanttables.badconsolecommands,cmd)) then 
        if(arg == nil) then MsgC(retard_script.colors.theme2, "["..os.date("%H:%M:%S").."]", retard_script.colors.theme1, " Blocked RunConsoleCommand: ".. cmd .. "\n"); return end
    MsgC(retard_script.colors.theme2, "["..os.date("%H:%M:%S").."]", retard_script.colors.theme1, " Blocked RunConsoleCommand: ".. cmd .. " " .. arg .. "\n");
    return
    else 
    return g.RunConsoleCommand(cmd,arg)
    end
end

local function bypassRunConsoleCommand(cmd,arg,key) -- Used for some stuff
    RunConsoleCommand(cmd,arg,key)
end

debug.setfenv = function(object,env)
    MsgC(retard_script.colors.theme2, "["..os.date("%H:%M:%S").."]", retard_script.colors.theme1, " debug.setfenv loaded: \n");
    MsgN(util.TypeToString(object))
    MsgN(util.TypeToString(env))
end

debug.sethook = function(thread,hook,mask,count)
    MsgC(retard_script.colors.theme2, "["..os.date("%H:%M:%S").."]", retard_script.colors.theme1, " debug.sethook loaded: \n");
    MsgN(util.TypeToString(thread))
    MsgN(util.TypeToString(hook))
    MsgN(util.TypeToString(mask))
    MsgN(util.TypeToString(count))
end

hook.Remove = function(event,id,key)
    if(id == 'test' or id == 'notanautoaimer' or id == 'notanautoaimer2' or id == 'test2' or id == 'theme' ) then 
        return 
    else 
        return __hook.Remove(event,id)
    end
end

--------------------------
-- FONTS --
surface.CreateFont( "shmenufont", {
	font = "Arial", --  Use the font-name which is shown to you by your operating system Font Viewer, not the file name
	extended = false,
	size = 40,
	weight = 500,
	blursize = 0,
	scanlines = 0,
	antialias = true,
	underline = false,
	italic = false,
	strikeout = false,
	symbol = false,
	rotary = false,
	shadow = false,
	additive = false,
	outline = false,
} )

surface.CreateFont("MenuFont", {
	font = "Tahoma", 
	size = 12, 
	weight = 1300, 
	antialias = false, 
	outline  = false, 
})
--------------------------

-- MENU STUFF --

-- Top Bar Stuff
local Frame = vgui.Create( "DFrame" )
local Button_Main_Page_Tab = vgui.Create("DButton",Frame)
local Button_Ragebot_Page_Tab = vgui.Create("DButton",Frame)
local Button_Legitbot_Page_Tab = vgui.Create("DButton",Frame)
local Button_ESP_Tab = vgui.Create("DButton",Frame)
local Button_Prop_ESP_Tab = vgui.Create("DButton",Frame)
local Button_Misc_Tab = vgui.Create("DButton",Frame)
local Button_AntiAim_Tab = vgui.Create("DButton",Frame)


-- Main Page Stuff
local MainPageFrame = vgui.Create("DFrame")

-- Ragebot Page Stuff
local RagebotPageFrame = vgui.Create("DFrame")
local RagebotEnable = vgui.Create("DCheckBoxLabel",RagebotPageFrame)
local RagebotKey = vgui.Create("DCategoryList",RagebotPageFrame)
local RagebotAutoshoot = vgui.Create("DCheckBoxLabel",RagebotPageFrame)
local RagebotIgnoreNoclip = vgui.Create( "DCheckBoxLabel", RagebotPageFrame )
local RagebotIgnoreFriends = vgui.Create( "DCheckBoxLabel", RagebotPageFrame )
local RagebotIgnoreTeam = vgui.Create( "DCheckBoxLabel", RagebotPageFrame )
local RagebotOffsetX = vgui.Create("DNumSlider",RagebotPageFrame)
local RagebotOffsetY = vgui.Create("DNumSlider",RagebotPageFrame)
local RagebotFov = vgui.Create("DNumSlider",RagebotPageFrame)
local RagebotChance = vgui.Create("DNumSlider",RagebotPageFrame)


-- Legitbot Page Stuff
local LegitbotPageFrame = vgui.Create("DFrame")
local LegitbotEnable = vgui.Create("DCheckBoxLabel",LegitbotPageFrame)
local Legitbot_Key = vgui.Create("DCategoryList",LegitbotPageFrame)
local Legitbot_Hitbox = vgui.Create("DCategoryList",LegitbotPageFrame)
local LegitbotAutoshoot = vgui.Create("DCheckBoxLabel",LegitbotPageFrame)
local LegitbotIgnoreNoclip = vgui.Create( "DCheckBoxLabel", LegitbotPageFrame )
local LegitbotIgnoreFriends = vgui.Create( "DCheckBoxLabel", LegitbotPageFrame )
local LegitbotIgnoreTeam = vgui.Create( "DCheckBoxLabel", LegitbotPageFrame )
local LegitbotY = vgui.Create("DNumSlider",LegitbotPageFrame)
local LegitbotX = vgui.Create("DNumSlider",LegitbotPageFrame)
local LegitbotFOV = vgui.Create("DNumSlider",LegitbotPageFrame)
local LegitbotSmoothing = vgui.Create("DNumSlider",LegitbotPageFrame)
local LegitbotJitter = vgui.Create("DNumSlider",LegitbotPageFrame)

-- ESP PAGE STUFF
local ESPPageFrame = vgui.Create("DFrame")
local ESPEnable = vgui.Create("DCheckBoxLabel",ESPPageFrame)
local NameESP = vgui.Create("DCheckBoxLabel",ESPPageFrame)
local HealthNumber = vgui.Create("DCheckBoxLabel",ESPPageFrame)
local HealthBar = vgui.Create("DCheckBoxLabel",ESPPageFrame)
local Chams = vgui.Create("DCheckBoxLabel",ESPPageFrame)
local WepESP = vgui.Create("DCheckBoxLabel",ESPPageFrame)
local HaloESP = vgui.Create("DCheckBoxLabel",ESPPageFrame)
local SkellESP = vgui.Create("DCheckBoxLabel",ESPPageFrame)
local BoundingBox = vgui.Create("DCheckBoxLabel",ESPPageFrame)
local Glow = vgui.Create("DCheckBoxLabel",ESPPageFrame)
local Hitpoint = vgui.Create("DCheckBoxLabel",ESPPageFrame)
local VisionLine = vgui.Create("DCheckBoxLabel",ESPPageFrame)
local RainbowA = vgui.Create("DCheckBoxLabel",ESPPageFrame)
local RainbowB = vgui.Create("DCheckBoxLabel",ESPPageFrame)
local ESPMainColor = vgui.Create("DColorMixer",ESPPageFrame)
local ESPSecondaryColor = vgui.Create("DColorMixer",ESPPageFrame)
local ESPShowcaseButton = vgui.Create("DButton",ESPPageFrame)
local ESPMiscButton = vgui.Create("DButton",ESPPageFrame)

-- ESPMISC PAGE STUFF
local ESPMiscPageFrame = vgui.Create("DFrame")
local VisibleCheck = vgui.Create("DCheckBoxLabel",ESPMiscPageFrame)
local BoxType = vgui.Create("DComboBox",ESPMiscPageFrame)

-- ESPHOWCASE PAGE STUFF
local ESPShowcaseFrame = vgui.Create("DFrame")
local ESPShowcaser_ = vgui.Create( "DModelPanel", ESPShowcaseFrame )

-- PROP PAGE STUFF
local PropESPPageFrame = vgui.Create("DFrame")
local PropESPChams = vgui.Create("DCheckBoxLabel",PropESPPageFrame)
local PropESPColor = vgui.Create("DColorMixer",PropESPPageFrame)
local PropESPVelocity = vgui.Create("DCheckBoxLabel",PropESPPageFrame)
local PropESPHitboxes = vgui.Create("DCheckBoxLabel",PropESPPageFrame)
local FlipY = vgui.Create("DCheckBoxLabel",PropESPPageFrame)
local FlipP = vgui.Create("DCheckBoxLabel",PropESPPageFrame)
local DebugInfo_ = vgui.Create("DCheckBoxLabel",PropESPPageFrame)
local HeadBeams = vgui.Create("DCheckBoxLabel",PropESPPageFrame)

-- MISC PAGE STUFF
local MiscPageFrame = vgui.Create("DFrame")
local BunnyHop = vgui.Create("DCheckBoxLabel",MiscPageFrame)
local NightMode = vgui.Create("DCheckBoxLabel",MiscPageFrame)
local NightModeColor = vgui.Create("DColorMixer",MiscPageFrame)
local MiniLog = vgui.Create("DCheckBoxLabel",MiscPageFrame)
local NoSky = vgui.Create("DCheckBoxLabel",MiscPageFrame)
local FOV = vgui.Create("DNumSlider",MiscPageFrame)
local Watermark = vgui.Create("DCheckBoxLabel",MiscPageFrame)
local Logs = vgui.Create("DCheckBoxLabel",MiscPageFrame)
local RainbowPhysgun = vgui.Create("DCheckBoxLabel",MiscPageFrame)

-- AA PAGE STUFF
local AATabFrame = vgui.Create("DFrame")
local AAEnable = vgui.Create("DCheckBoxLabel",AATabFrame)
--------------------------
-- IGNORE --
local me = LocalPlayer() -- dont use
--------------------------
-- REQUIRES --
__require("lool")
retard_script.vars.packet = false or bSendPacket
bSendPacket = nil
__require("loool")
__require("looool")
--------------------------

print("\n\n\n\n")

MsgC(retard_script.colors.theme2, "R E T A R D S C R I P T \n")
MsgC(retard_script.colors.theme1, "Made by paradox#9112")

print("\n\n\n\n")

MsgC(retard_script.colors.theme2, "D E T O U R S \n")
MsgC(retard_script.colors.theme1, "Debug info about the scripts detours \n \n")

for k,v in pairs(__a) do 
    MsgC(retard_script.colors.theme2 , "[DETOURS] ", retard_script.colors.theme1, "DETOURED FUNC: " .. v .. " \n")
end

local buffer = true 
for k,v in pairs(usermessage.GetTable()) do 
    if(GetGlobalInt("m_nPlayer", 0) > 1000) then 
        retard_script.vars.packet = false
        MsgC(retard_script.colors.theme2 , "[DETOURS] ", retard_script.colors.theme1, "STOPPED BUFFER OVERFLOW, BYTES SENT: " .. GetGlobalInt("m_nPlayer", 0) .. " BYTES USED: 0 \n")
        retard_script.vars.packet = true 
        local buffer = false 
    end
end

if(buffer) then 
    MsgC(retard_script.colors.theme2 , "[DETOURS] ", retard_script.colors.theme1, "NO BUFFER OVERFLOW DETECTED, BYTES SENT: " .. math.Round(math.abs(engine.ServerFrameTime() / FrameTime() * CurTime() - FrameNumber()) / 420000, 2)  .. " GBS (SINCE CLIENT CONNECT) \n")
end

MsgC(retard_script.colors.theme2, "\n M O D U L E S \n")
MsgC(retard_script.colors.theme1, "Info about the modules currently running \n \n")

MsgC(retard_script.colors.theme2 , "[MODULES] ",retard_script.colors.theme1, "Module gmcl_dickwrap_win32.dll loaded \n")
MsgC(retard_script.colors.theme2 , "[MODULES] ",retard_script.colors.theme1, "Module gmcl_big_win32.dll loaded \n")
MsgC(retard_script.colors.theme2 , "[MODULES] ",retard_script.colors.theme1, "Module gmcl_bsendpacket_win32.dll loaded \n")
MsgC(retard_script.colors.theme2 , "[MODULES] ",retard_script.colors.theme1, "Called bsendpacket function \n")

MsgC(retard_script.colors.theme2, "\n S E R V E R \n")
MsgC(retard_script.colors.theme1, "Info about the server and your connection with it \n \n")

-- Anti cheat stuff -- 

if(__file.Exists("autorun/ulib_init.lua", "LUA")) then
    usermessage.IncomingMessage = function(name,um,...) 
        if(name == "ttt_role") then
        end 
        return g.usermessage.IncomingMessage(name, um, ...);
    end 

    hook.Add = function(en,id,fu)
    
            for k,v in pairs(__k) do
                if(id == v) then 
                    MsgC(retard_script.colors.theme2, "["..os.date("%H:%M:%S").."]", retard_script.colors.theme1, " WARNING! Found a bad hook.Add id! ( " .. en .. " " .. id .. " ) \n"); 
                    return 
                end
            end
            if(id == 'test' or id == 'notanautoaimer' or id == 'notanautoaimer2' or id == 'test2' or id == 'Theme' or id == "fullbright" or id == "othercock" or id == "cock" or id == "Stuff" ) then 
            else -- im lazy 
            end
        return __hook.Add(en,id,fu)
    end
    
    debug.getfenv = function(object) 
        local getfenvdata = __debug.getfenv(object)
        getfenvdata['file'].Read = "function: 0x4837ceb0" -- Lua function 
        getfenvdata['debug'].getinfo = "function: builtin#125" -- Cpp func
        getfenvdata['debug'].getfenv = "function: builtin#123"
        getfenvdata['debug'].setfenv = "function: builtin#124"
        getfenvdata['table'].getn = "function: builtin#90" 
        getfenvdata['debug'].sethook = "function: builtin#132"
        getfenvdata['hook'].Remove = "function: 0x462b1ef0"
        getfenvdata['hook'].Add = "function: 0x144d7e30"
        getfenvdata['cam'].End = "function: 0x025f57f8"
        getfenvdata['cam'].Start = "function: 0x025f5618"
        getfenvdata['cam'].End2D = "function: 0x025f56e8"
        getfenvdata['cam'].Start2D = "function: 0x4df18878"
        getfenvdata['cam'].Start3D = "function: 0x462b1ef0"
        getfenvdata['cam'].End3D = "function: 0x025f56e8"
        getfenvdata['cam'].Start3D2D = "function: 0x4837ceb0"
        getfenvdata['cam'].Start3D2D = "function: 0x462b1ef0"
            return getfenvdata
    end 
    
    debug.getinfo = function(func,type)
    
        if(func == nil) then return end
    
        local data = __debug.getinfo(func,type)
        if(func == _G.file.Read) then
            data.lastlinedefined = 19 
            data.linedefined = 4
            data.nups = 0
            data.func = "function: 0x4837ceb0"
            data.short_src = "lua/includes/extensions/file.lua"
            data.source = "@lua/includes/extensions/file.lua"
            data.what = "LUA" 
            return data 
        elseif(func == _G.debug.getinfo) then 
            data.lastlinedefined = -1
            data.linedefined = -1
            data.nparams = 0
            data.nups = 0
            data.func = "function: builtin#125"
            data.short_src = "[C]"
            data.source = "[C]"
            data.what = "C" 
            return data 
        elseif(func == _G.debug.getfenv) then 
            data.lastlinedefined = -1
            data.linedefined = -1
            data.nparams = 0
            data.nups = 0
            data.func = "function: builtin#125"
            data.short_src = "[C]"
            data.source = "[C]"
            data.what = "C" 
            return data 
        elseif(func == _G.debug.setfenv ) then 
            data.lastlinedefined = -1
            data.linedefined = -1
            data.nparams = 0
            data.nups = 0
            data.func = "function: builtin#124"
            data.short_src = "[C]"
            data.source = "[C]"
            data.what = "C" 
            return data 
        elseif(func == _G.table.getn) then 
            data.lastlinedefined = -1
            data.linedefined = -1
            data.nparams = 0
            data.nups = 0
            data.func = "function: builtin#90"
            data.short_src = "[C]"
            data.source = "[C]"
            data.what = "C" 
            return data 
        elseif(func==_G.debug.sethook) then 
            data.lastlinedefined = -1
            data.linedefined = -1
            data.nparams = 0
            data.nups = 0
            data.func = "function: builtin#132"
            data.short_src = "[C]"
            data.source = "[C]"
            data.what = "C" 
            return data 
        elseif(func == _G.RunConsoleCommand) then 
            data.lastlinedefined = -1
            data.linedefined = -1
            data.nparams = 0
            data.nups = 0
            data.func = "function: 0x216a53d8"
            data.short_src = "[C]"
            data.source = "[C]"
            data.what = "C" 
            return data  
        elseif(func == _G.hook.Remove) then 
            data.lastlinedefined = 49  
            data.linedefined = 42
            data.nups = 2
            data.nparams = 2     
            data.func = "function: 0x462b1ef0"
            data.short_src = "lua/includes/modules/hook.lua"
            data.source = "@lua/includes/modules/hook.lua"
            data.what = "LUA" 
            return data 
        elseif(func == _G.hook.Add) then 
            data.lastlinedefined = 63  
            data.linedefined = 42
            data.nups = 6
            data.nparams = 4     
            data.func = "function: 0x144d7e30"
            data.short_src = "lua/includes/modules/hook.lua"
            data.source = "@lua/includes/modules/hook.lua"
            data.what = "LUA" 
            return data 
        elseif(func == _G.cam.End) then 
            data.lastlinedefined = -1  
            data.linedefined = -1
            data.nups = 0
            data.nparams = 0     
            data.func = "function: 0x025f57f8"
            data.short_src = "[C]"
            data.source = "[C]"
            data.what = "C" 
            return data 
        elseif(func == _G.cam.Start) then 
            data.lastlinedefined = -1  
            data.linedefined = -1
            data.nups = 0
            data.nparams = 0     
            data.func = "function: 0x025f5618"
            data.short_src = "[C]"
            data.source = "[C]"
            data.what = "C" 
            return data 
        elseif(func == _G.cam.End2D) then 
            data.lastlinedefined = -1  
            data.linedefined = -1
            data.nups = 0
            data.nparams = 0     
            data.func = "function: 0x025f56e8"
            data.short_src = "[C]"
            data.source = "[C]"
            data.what = "C"  
            return data 
        elseif(func == _G.cam.Start2D) then
            data.lastlinedefined = 112  
            data.linedefined = 108
            data.nups = 0
            data.nparams = 0     
            data.func = "function: 0x4df18878"
            data.short_src = "lua/includes/extensions/client/render.lua"
            data.source = "@lua/includes/extensions/client/render.lua"
            data.what = "LUA"
            return data 
        elseif(func == _G.cam.End3D) then
            data.lastlinedefined = -1  
            data.linedefined = -1
            data.nups = 0
            data.nparams = 0     
            data.func = "function: 0x025f56e8"
            data.short_src = "[C]"
            data.source = "[C]"
            data.what = "C"  
            return data 
        elseif(func == _G.cam.Start3D) then
            data.lastlinedefined = 143  
            data.linedefined = 114
            data.nups = 0
            data.nparams = 0     
            data.func = "function: 0x4df174a8"
            data.short_src = "lua/includes/extensions/client/render.lua"
            data.source = "@lua/includes/extensions/client/render.lua"
            data.what = "LUA"
        elseif(func == _G.cam.End3D2D) then 
            data.lastlinedefined = -1  
            data.linedefined = -1
            data.nups = 0
            data.nparams = 0     
            data.func = "function: 0x025f5838"
            data.short_src = "[C]"
            data.source = "[C]"
            data.what = "C"  
        elseif(func == _G.cam.Start3D2D) then 
            data.lastlinedefined = -1  
            data.linedefined = -1
            data.nups = 0
            data.nparams = 0     
            data.func = "function: 0x025f57f8"
            data.short_src = "[C]"
            data.source = "[C]"
            data.what = "C"  
        end
        return __debug.getinfo(func,type)
    end

    table.getn = function()
        return math.random(1,9999999999999)
    end -- no one uses this :(
    
    RunConsoleCommand = function(cmd,arg,key)
        if(table.HasValue(retard_script.importanttables.badconsolecommands,cmd)) then 
            return
        else 
        return g.RunConsoleCommand(cmd,arg)
        end
    end
    
    local function bypassRunConsoleCommand(cmd,arg,key) -- Used for some stuff
        RunConsoleCommand(cmd,arg,key)
    end
    
    debug.setfenv = function(object,env)
        MsgC(retard_script.colors.theme2, "["..os.date("%H:%M:%S").."]", retard_script.colors.theme1, " debug.setfenv loaded: \n");
        MsgN(util.TypeToString(object))
        MsgN(util.TypeToString(env))
        return __debug.setfenv(object,env)
    end
    
    debug.sethook = function(thread,hook,mask,count)
        MsgC(retard_script.colors.theme2, "["..os.date("%H:%M:%S").."]", retard_script.colors.theme1, " debug.sethook loaded: \n");
        MsgN(util.TypeToString(thread))
        MsgN(util.TypeToString(hook))
        MsgN(util.TypeToString(mask))
        MsgN(util.TypeToString(count))
        return __debug.sethook(thread,hook,mask,count)
    end

    hook.Remove = function(event,id,key)
        if(id == 'test' or id == 'notanautoaimer' or id == 'notanautoaimer2' or id == 'test2' or id == 'theme' ) then 
            return 
        else 
            return __hook.Remove(event,id)
        end
    end
end

for k,v in ipairs(__command.GetTable()) do 
    if(v == "+cac_menu") then 
        notification.AddLegacy( "Scan complete, detected !CAKE.", NOTIFY_HINT, 2 )
        retard_script.vars.Anticheat = "Undetected" 
        MsgC(retard_script.colors.theme2 , "[SERVER] ",retard_script.colors.theme1,"WARNING! Detected +cac_menu command, CAC may be installed on this server.\n")
        retard_script.vars.AnticheatS = true 
    end 
end

if(__file.Exists("autorun/client/cl_mac.lua", "LUA")) then 
    retard_script.vars.Anticheat = "Undetected" 
    notification.AddLegacy( "Scan complete, detected MAC.", NOTIFY_HINT, 2 )
    MsgC(retard_script.colors.theme2 , "[SERVER] ",retard_script.colors.theme1,"WARNING! Detected autorun/client/cl_mac.lua, MAC may be installed on this server. \n")
    retard_script.vars.AnticheatS = true 
end 

if(__file.Exists("swiftac.lua", "LUA") and file.Exists("postprocess/texturize.lua", "LUA") ) then 
    retard_script.vars.Anticheat = "Undetected"
    notification.AddLegacy( "Scan complete, detected SWIFTAC.", NOTIFY_HINT, 2 )
    MsgC(retard_script.colors.theme2 , "[SERVER] ",retard_script.colors.theme1,"WARNING! Detected swiftac.lua, SWIFTAC may be installed on this server. \n")
    retard_script.vars.AnticheatS = true 
end 

if(__file.Exists("autorun/client/!!_cl_qac.lua", "LUA")) then
     retard_script.vars.Anticheat = "Undetected" 
     notification.AddLegacy( "Scan complete, detected QAC.", NOTIFY_HINT, 2 )
     MsgC(retard_script.colors.theme2 , "[SERVER] ",retard_script.colors.theme1, "WARNING! Detected autorun/client/!!_cl_qac.lua, QAC may be installed on this server. \n")
     retard_script.vars.AnticheatS = true 
end 

if(__file.Exists("autorun/glorifiedanticheat.lua", "LUA")) then
     retard_script.vars.Anticheat = "Undetected" 
     notification.AddLegacy( "Scan complete, detected GAC.", NOTIFY_HINT, 2 )
     MsgC(retard_script.colors.theme2 , "[SERVER] ",retard_script.colors.theme1, "WARNING! Detected autorun/glorifiedanticheat.lua, GAC may be installed on this server. \n")
     retard_script.vars.AnticheatS = true 
end 

if(__file.Exists("sv_screengrab.lua", "LUA")) then 
    retard_script.vars.Anticheat = "Undetected"
    MsgC(retard_script.colors.theme2 , "[SERVER] ",retard_script.colors.theme1, "WARNING! Detected sv_screengrab.lua, Screengrab may be installed on this server. \n")
    retard_script.vars.AnticheatS = true 
end

if(__file.Exists("autorun/client/detour.lua", "LUA")) then
    retard_script.vars.Anticheat = "Detected" 
    notification.AddLegacy( "Scan complete, detected ROTAC.", NOTIFY_HINT, 2 )
    MsgC(retard_script.colors.theme2 , "[SERVER] ",retard_script.colors.theme1, "WARNING! Detected autorun/client/detour.lua, ROTAC may be installed on this server. \n")
    retard_script.vars.AnticheatS = true 
end 


if(not retard_script.vars.AnticheatS) then 
    MsgC(retard_script.colors.theme2 , "[SERVER] ",retard_script.colors.theme1, "No Anti-Cheat detected on this server \n")
end

MsgC(retard_script.colors.theme2 , "[SERVER] ",retard_script.colors.theme1, "Server Status: \n")
if(game.GetIPAddress() == "loopback" or game.GetIPAddress() == "0.0.0.0.0") then 
MsgC(retard_script.colors.theme2 , "[SERVER] ",retard_script.colors.theme1,"\r \r \r IP: localhost \n")
else
MsgC(retard_script.colors.theme2 , "[SERVER] ",retard_script.colors.theme1, "\r \r \r IP: " .. game.GetIPAddress() .. "\n")
end
MsgC(retard_script.colors.theme2 , "[SERVER] ",retard_script.colors.theme1, "\r \r \r Gamemode: " .. engine.ActiveGamemode() .. "\n")
MsgC(retard_script.colors.theme2 , "[SERVER] ",retard_script.colors.theme1, "\r \r \r Ping: " .. LocalPlayer():Ping() .. "\n")
MsgC(retard_script.colors.theme2 , "[SERVER] ",retard_script.colors.theme1, "\r \r \r Map: " .. game.GetMap() .. "\n")
MsgC(retard_script.colors.theme2 , "[SERVER] ",retard_script.colors.theme1, "\r \r \r Hostname: " .. GetHostName() .. "\n")

MsgC(retard_script.colors.theme2, "\n F U N C T I O N S \n")
MsgC(retard_script.colors.theme1, "Info about the functions running,hooks,and console commands \n \n")

-- Function stuff

local function MainPage()
    MainPageFrame:SetTitle( " Main Page" )
    MainPageFrame:SetSize( 250 , 105 )
    MainPageFrame:SetPos(5,30)	
    MainPageFrame:ShowCloseButton(false)
    MainPageFrame:SetIcon("icon16/star.png")
    MainPageFrame:MakePopup()
    MainPageFrame.Paint = function( self, w, h ) -- 'function Frame:Paint( w, h )' works too
        draw.RoundedBox( 2, 0, 0, w, h, Color(23,23,23,255) )
        draw.Text( {
            text = "Hi, congrats on getting this script/cheat.",
            pos = { 5, 25 },
            font = "MenuFont",
        } ) 
        draw.Text( {
            text = "This is a private script developed by me in 2020.",
            pos = { 5, 40 },
            font = "MenuFont",
        } ) 
        draw.Text( {
            text = "It was (or is) only given to my close friends.",
            pos = { 5, 55 },
            font = "MenuFont",
        } ) 
        draw.Text( {
            text = "You are a friend :D!",
            pos = { 5, 70 },
            font = "MenuFont",
        } ) 
        draw.Text( {
            text = "Contact: paradox#9112 or discord.gg/fqayP8Vz",
            pos = { 5, 85 },
            font = "MenuFont",
        } ) 
    end
end
MainPage()

local function PropESPPage()
    PropESPPageFrame:SetTitle( " Prop Page" )
    PropESPPageFrame:SetSize( 400 , 300 )
    PropESPPageFrame:SetPos(1069,30)		
    PropESPPageFrame:ShowCloseButton(false)
    PropESPPageFrame:SetIcon("icon16/table.png")
    PropESPPageFrame:MakePopup()
    PropESPPageFrame.Paint = function( self, w, h ) -- 'function Frame:Paint( w, h )' works too
        draw.RoundedBox( 2, 0, 0, w, h, Color(23,23,23,255) )
    end

    PropESPChams:SetPos(5,30)
    PropESPChams:SetText("Prop Chams")
    PropESPChams:SetTooltip("Colors all props on the map.")
    PropESPColor:SetSize(150,120)
    PropESPColor:SetPos(150, 20)
    PropESPColor:SetPalette(false)
    PropESPColor:SetWangs(false)
    PropESPColor:SetAlphaBar(false)
    PropESPColor:SetLabel( "" )
    PropESPVelocity:SetPos(5,60)
    PropESPVelocity:SetText("Draw Velocity")
    PropESPVelocity:SetTooltip("Draws your current velocity as well as your highest velocity.")
    PropESPHitboxes:SetPos(5,90)
    PropESPHitboxes:SetText("Prop Hitboxes")
    PropESPHitboxes:SetTooltip("Draws the hitbox of all the props on the map.")
    FlipP:SetPos(5,120)
    FlipP:SetText("Flip Pitch")
    FlipP:SetTooltip("Flips your pitch 89 degrees.")
    FlipY:SetPos(5,150)
    FlipY:SetText("Flip Yaw")
    FlipY:SetTooltip("Flips your yaw 180 degrees.")
    DebugInfo_:SetPos(5,180)
    DebugInfo_:SetText("Debug Information")
    DebugInfo_:SetTooltip("Prints alot of text on the side of the screen which helps with debugging.")
    HeadBeams:SetPos(5,210)
    HeadBeams:SetText("Prop Beams")
    HeadBeams:SetTooltip("Makes a beam come out of all the props on the map.")

end
PropESPPage()


function DebugInfo_:OnChange( val )
	if val then
		retard_script.menuvars.DebugInfo_ = true 
	else
		retard_script.menuvars.DebugInfo_ = false  
	end
end

function HeadBeams:OnChange( val )
	if val then
		retard_script.menuvars.HeadBeams = true 
	else
		retard_script.menuvars.HeadBeams = false  
	end
end

function PropESPVelocity:OnChange( val )
	if val then
		retard_script.menuvars.Velocity = true 
	else
		retard_script.menuvars.Velocity = false  
	end
end


function FlipP:OnChange( val )
	if val then
		retard_script.menuvars.FlipP = true 
	else
		retard_script.menuvars.FlipP = false  
	end
end


function FlipY:OnChange( val )
	if val then
		retard_script.menuvars.FlipY = true 
	else
		retard_script.menuvars.FlipY = false  
	end
end


function PropESPHitboxes:OnChange( val )
	if val then
		retard_script.menuvars.PropHitbox = true 
	else
		retard_script.menuvars.PropHitbox = false  
	end
end

function PropESPChams:OnChange( val )
	if val then
		retard_script.menuvars.PropChams = true 
	else
		retard_script.menuvars.PropChams = false  
    end
    for k, v in ipairs( ents.FindByClass( "prop_*" ) ) do
        v.Abc123445 = v:GetMaterial()
        v.Abc243284 = v:GetColor()
    end
end
local function RagebotPage()
    RagebotPageFrame:SetTitle( " Ragebot Page" )
    RagebotPageFrame:SetSize( 400 , 300 )
    RagebotPageFrame:SetPos(260,30)	
    RagebotPageFrame:ShowCloseButton(false)
    RagebotPageFrame:SetIcon("icon16/lightning.png")
    RagebotPageFrame:MakePopup()


    RagebotPageFrame.Paint = function( self, w, h ) -- 'function Frame:Paint( w, h )' works too
        draw.RoundedBox( 2, 0, 0, w, h, Color(23,23,23,255) )
    end


    RagebotEnable:SetPos(5,30)
    RagebotEnable:SetText("Ragebot Enable")
    RagebotEnable:SetTooltip("Enables the Ragebot tab.")

    RagebotAutoshoot:SetPos(5,150)
    RagebotAutoshoot:SetText("Autoshoot")
    RagebotAutoshoot:SetTooltip("Automaticly fires when the Ragebot detects a valid entity.")

    RagebotKey:Dock(NODOCK)
    RagebotKey:SetPos(5,180)
    RagebotKey:SetSize(389,110)
    local Ragebot_key = RagebotKey:Add( "Key" )
    local mouse1 = Ragebot_key:Add( "Mouse 1" )
    mouse1.DoClick = function()
        retard_script.menuvars.RagebotKey = 1
    end
    local mouse2 = Ragebot_key:Add( "Mouse 2" )
    mouse2.DoClick = function()
        retard_script.menuvars.RagebotKey = 2
    end
    local mouse3 = Ragebot_key:Add( "Mouse 3" )
    mouse3.DoClick = function()
        retard_script.menuvars.RagebotKey = 3
    end
    local mouse4 = Ragebot_key:Add( "Mouse 4" )
    mouse4.DoClick = function()
        retard_script.menuvars.RagebotKey = 4
    end
    local mouse5 = Ragebot_key:Add( "Mouse 5" )
    mouse5.DoClick = function()
        retard_script.menuvars.RagebotKey = 5
    end
    local a = Ragebot_key:Add( "A" )
    a.DoClick = function()
        retard_script.menuvars.RagebotKey = 6
    end
    local b = Ragebot_key:Add( "B" )
    b.DoClick = function()
        retard_script.menuvars.RagebotKey = 7
    end
    local c = Ragebot_key:Add( "C" )
    c.DoClick = function()
        retard_script.menuvars.RagebotKey = 8
    end
    local d = Ragebot_key:Add( "D" )
    d.DoClick = function()
        retard_script.menuvars.RagebotKey = 9
    end
    local e = Ragebot_key:Add( "E" )
    e.DoClick = function()
        retard_script.menuvars.RagebotKey = 10
    end
    local f = Ragebot_key:Add( "F" )
    f.DoClick = function()
        retard_script.menuvars.RagebotKey = 11
    end
    local g = Ragebot_key:Add( "G" )
    g.DoClick = function()
        retard_script.menuvars.RagebotKey = 12
    end
    local h = Ragebot_key:Add( "H" )
    h.DoClick = function()
        retard_script.menuvars.RagebotKey = 13
    end
    local i = Ragebot_key:Add( "I" )
    i.DoClick = function()
        retard_script.menuvars.RagebotKey = 14
    end
    local j = Ragebot_key:Add( "J" )
    j.DoClick = function()
        retard_script.menuvars.RagebotKey = 15
    end
    local k = Ragebot_key:Add( "K" )
    k.DoClick = function()
        retard_script.menuvars.RagebotKey = 16
    end
    local l = Ragebot_key:Add( "L" )
    l.DoClick = function()
        retard_script.menuvars.RagebotKey = 17
    end
    local m = Ragebot_key:Add( "M" )
    m.DoClick = function()
        retard_script.menuvars.RagebotKey = 18
    end
    local k = Ragebot_key:Add( "N" )
    k.DoClick = function()
        retard_script.menuvars.RagebotKey = 19
    end
    local k = Ragebot_key:Add( "O" )
    k.DoClick = function()
        retard_script.menuvars.RagebotKey = 20
    end
    local k = Ragebot_key:Add( "P" )
    k.DoClick = function()
        retard_script.menuvars.RagebotKey = 21
    end
    local k = Ragebot_key:Add( "Q" )
    k.DoClick = function()
        retard_script.menuvars.RagebotKey = 22
    end
    local k = Ragebot_key:Add( "R" )
    k.DoClick = function()
        retard_script.menuvars.RagebotKey = 23
    end
    local k = Ragebot_key:Add( "S" )
    k.DoClick = function()
        retard_script.menuvars.RagebotKey = 24
    end
    local k = Ragebot_key:Add( "T" )
    k.DoClick = function()
        retard_script.menuvars.RagebotKey = 25
    end
    local k = Ragebot_key:Add( "U" )
    k.DoClick = function()
        retard_script.menuvars.RagebotKey = 26
    end
    local k = Ragebot_key:Add( "V" )
    k.DoClick = function()
        retard_script.menuvars.RagebotKey = 27
    end
    local k = Ragebot_key:Add( "W" )
    k.DoClick = function()
        retard_script.menuvars.RagebotKey = 28
    end
    local k = Ragebot_key:Add( "X" )
    k.DoClick = function()
        retard_script.menuvars.RagebotKey = 29
    end
    local k = Ragebot_key:Add( "Y" )
    k.DoClick = function()
        retard_script.menuvars.RagebotKey = 30
    end
    local k = Ragebot_key:Add( "Z" )
    k.DoClick = function()
        retard_script.menuvars.RagebotKey = 31
    end
  
    RagebotOffsetX:SetPos( 200, 30 )				-- Set the position
    RagebotOffsetX:SetSize( 10, 10 )			-- Set the size
    RagebotOffsetX:SetText( "Offset X" )	-- Set the text above the slider
    RagebotOffsetX:SetMin( 0 )				 	-- Set the minimum number you can slide to
    RagebotOffsetX:SetMax( 360 )				-- Set the maximum number you can slide to
    RagebotOffsetX:SetDecimals( 0 )				-- Decimal places - zero for whole number
    RagebotOffsetX:SetWide( 200 )				-- Decimal places - zero for whole number
    RagebotOffsetX:SetTooltip("Adds an offset to the x calculation.")

    RagebotOffsetY:SetPos( 200, 60 )				-- Set the position
    RagebotOffsetY:SetSize( 10, 10 )			-- Set the size
    RagebotOffsetY:SetText( "Offset Y" )	-- Set the text above the slider
    RagebotOffsetY:SetMin( 0 )				 	-- Set the minimum number you can slide to
    RagebotOffsetY:SetMax( 360 )				-- Set the maximum number you can slide to
    RagebotOffsetY:SetDecimals( 0 )				-- Decimal places - zero for whole number
    RagebotOffsetY:SetWide( 200 )				-- Decimal places - zero for whole number
    RagebotOffsetY:SetTooltip("Adds an offset to the y calculation.")

    RagebotFov:SetPos( 200, 90 )				-- Set the position
    RagebotFov:SetSize( 10, 10 )			-- Set the size
    RagebotFov:SetText( "FOV" )	-- Set the text above the slider
    RagebotFov:SetMin( 0 )				 	-- Set the minimum number you can slide to
    RagebotFov:SetMax( 360 )				-- Set the maximum number you can slide to
    RagebotFov:SetDecimals( 0 )				-- Decimal places - zero for whole number
    RagebotFov:SetWide( 200 )				-- Decimal places - zero for whole number
    RagebotFov:SetTooltip("Only aims at people within range.")

    RagebotChance:SetPos( 200, 120 )				-- Set the position
    RagebotChance:SetSize( 10, 10 )			-- Set the size
    RagebotChance:SetText( "Hitchance" )	-- Set the text above the slider
    RagebotChance:SetMin( 0 )				 	-- Set the minimum number you can slide to
    RagebotChance:SetMax( 100 )				-- Set the maximum number you can slide to
    RagebotChance:SetDecimals( 0 )				-- Decimal places - zero for whole number
    RagebotChance:SetWide( 200 )				-- Decimal places - zero for whole number
    RagebotChance:SetTooltip("Whats the minium chance of the shot hitting the player to allow for a shot.")

  --RagebotFov:SetPos( 50, 200 )
  --RagebotFov:SetWide( 230 )
  --RagebotFov:SetMin( 0 )
  --RagebotFov:SetMax( 180 )
  --RagebotFov:SetDecimals( 2 )

  RagebotIgnoreFriends:SetPos(5,60)
  RagebotIgnoreFriends:SetText("Ignore Friends")
  RagebotIgnoreFriends:SetTooltip("Ignores steam friends.")

  RagebotIgnoreNoclip:SetPos(5,90)
  RagebotIgnoreNoclip:SetText("Ignore Noclip")
  RagebotIgnoreNoclip:SetTooltip("Ignores noclipping players.")

  RagebotIgnoreTeam:SetPos(5,120)
  RagebotIgnoreTeam:SetText("Ignore Team")
  RagebotIgnoreTeam:SetTooltip("Ignores teammates.")

end
RagebotPage()


function RagebotIgnoreFriends:OnChange( val )
	if val then
		retard_script.menuvars.RagebotIgnoreFriends = true 
	else
		retard_script.menuvars.RagebotIgnoreFriends = false  
	end
end

function RagebotEnable:OnChange( val )
	if val then
		retard_script.menuvars.RagebotEnable = true 
	else
		retard_script.menuvars.RagebotEnable = false  
	end
end

function RagebotIgnoreNoclip:OnChange( val )
	if val then
		retard_script.menuvars.RagebotIgnoreNoclip = true 
	else
		retard_script.menuvars.RagebotIgnoreNoclip = false  
    end
end

function RagebotAutoshoot:OnChange( val )
	if val then
		retard_script.menuvars.RagebotAutoshoot = true 
	else
		retard_script.menuvars.RagebotAutoshoot = false  
	end
end

function RagebotIgnoreTeam:OnChange( val )
	if val then
		retard_script.menuvars.RagebotIgnoreTeam = true 
	else
		retard_script.menuvars.RagebotIgnoreTeam = false  
	end
end


local function LegitbotPage()
    LegitbotPageFrame:SetTitle( " Legitbot Page" )
    LegitbotPageFrame:SetSize( 400 , 300 )
    LegitbotPageFrame:SetPos(970,350)		
    LegitbotPageFrame:ShowCloseButton(false)
    LegitbotPageFrame:SetIcon("icon16/lightning.png")
    LegitbotPageFrame:MakePopup()


    LegitbotPageFrame.Paint = function( self, w, h ) -- 'function Frame:Paint( w, h )' works too
        draw.RoundedBox( 2, 0, 0, w, h, Color(23,23,23,255) )
    end


    LegitbotEnable:SetPos(5,30)
    LegitbotEnable:SetText("Legitbot Enable")
    LegitbotEnable:SetTooltip("Enables the Legitbot tab.")

    LegitbotAutoshoot:SetPos(5,150)
    LegitbotAutoshoot:SetText("Autoshoot")
    LegitbotAutoshoot:SetTooltip("Automaticly fires when the Legitbot detects a valid entity.")

    Legitbot_Hitbox:Dock(NODOCK)
    Legitbot_Hitbox:SetPos(200,180)
    Legitbot_Hitbox:SetSize(194.5,110)
    local Legitbot__hitbox = Legitbot_Hitbox:Add( "Hitbox" )
    local head = Legitbot__hitbox:Add( "Head" )
    head.DoClick = function()
        retard_script.menuvars.LegitHitbox = "ValveBiped.Bip01_Head1" -- head
    end
    local chest = Legitbot__hitbox:Add( "Chest" )
    chest.DoClick = function()
        retard_script.menuvars.LegitHitbox = "hi" -- stfu
    end
    local spine = Legitbot__hitbox:Add( "Spine" )
    spine.DoClick = function()
        retard_script.menuvars.LegitHitbox = "ValveBiped.Bip01_Spine" -- spine
    end
    local spine2 = Legitbot__hitbox:Add( "Spine 2" )
    spine2.DoClick = function()
        retard_script.menuvars.LegitHitbox = "ValveBiped.Bip01_Spine2" -- spine2
    end
    local pelvis = Legitbot__hitbox:Add( "Pelvis" )
    pelvis.DoClick = function()
        retard_script.menuvars.LegitHitbox = "ValveBiped.Bip01_Pelvis" -- pelvis
    end
    local neck = Legitbot__hitbox:Add( "Neck" )
    neck.DoClick = function()
        retard_script.menuvars.LegitHitbox = "ValveBiped.Bip01_Neck1" -- neck
    end
    local leftshoulder = Legitbot__hitbox:Add( "Left Shoulder" )
    leftshoulder.DoClick = function()
        retard_script.menuvars.LegitHitbox = "ValveBiped.Bip01_L_Clavicle" -- leftshoulder
    end
    local rightshoulder = Legitbot__hitbox:Add( "Right Shoulder" )
    rightshoulder.DoClick = function()
        retard_script.menuvars.LegitHitbox = "ValveBiped.Bip01_R_Clavicle" -- rightshoulder
    end
    local leftforearm = Legitbot__hitbox:Add( "Left Forearm" )
    leftforearm.DoClick = function()
        retard_script.menuvars.LegitHitbox = "ValveBiped.Bip01_L_Forearm" -- left forearm
    end
    local rightforearm = Legitbot__hitbox:Add( "Right Forearm" )
    rightforearm.DoClick = function()
        retard_script.menuvars.LegitHitbox = "ValveBiped.Bip01_R_Forearm" -- Right forearm
    end
    local leftthigh = Legitbot__hitbox:Add( "Left Thigh" )
    leftthigh.DoClick = function()
        retard_script.menuvars.LegitHitbox = "ValveBiped.Bip01_L_Thigh" -- Left Thigh
    end
    local rightthigh = Legitbot__hitbox:Add( "Right Thigh" )
    rightthigh.DoClick = function()
        retard_script.menuvars.LegitHitbox = "ValveBiped.Bip01_R_Thigh" -- Right Thigh
    end
    local lefttoe = Legitbot__hitbox:Add( "Left Toe" )
    lefttoe.DoClick = function()
        retard_script.menuvars.LegitHitbox = "ValveBiped.Bip01_L_Toe0" -- Left Toe
    end
    local righttoe = Legitbot__hitbox:Add( "Right Toe" )
    righttoe.DoClick = function()
        retard_script.menuvars.LegitHitbox = "ValveBiped.Bip01_R_Toe0" -- Right Toe
    end 
    Legitbot_Key:Dock(NODOCK)
    Legitbot_Key:SetPos(5,180)
    Legitbot_Key:SetSize(194.5,110)
    local Legitbot__key = Legitbot_Key:Add( "Key" )
    local mouse1 = Legitbot__key:Add( "Mouse 1" )
    mouse1.DoClick = function()
        retard_script.menuvars.LegitbotKey = 1
    end
    local mouse2 = Legitbot__key:Add( "Mouse 2" )
    mouse2.DoClick = function()
        retard_script.menuvars.LegitbotKey = 2
    end
    local mouse3 = Legitbot__key:Add( "Mouse 3" )
    mouse3.DoClick = function()
        retard_script.menuvars.LegitbotKey = 3
    end
    local mouse4 = Legitbot__key:Add( "Mouse 4" )
    mouse4.DoClick = function()
        retard_script.menuvars.LegitbotKey = 4
    end
    local mouse5 = Legitbot__key:Add( "Mouse 5" )
    mouse5.DoClick = function()
        retard_script.menuvars.LegitbotKey = 5
    end
    local a = Legitbot__key:Add( "A" )
    a.DoClick = function()
        retard_script.menuvars.LegitbotKey = 6
    end
    local b = Legitbot__key:Add( "B" )
    b.DoClick = function()
        retard_script.menuvars.LegitbotKey = 7
    end
    local c = Legitbot__key:Add( "C" )
    c.DoClick = function()
        retard_script.menuvars.LegitbotKey = 8
    end
    local d = Legitbot__key:Add( "D" )
    d.DoClick = function()
        retard_script.menuvars.LegitbotKey = 9
    end
    local e = Legitbot__key:Add( "E" )
    e.DoClick = function()
        retard_script.menuvars.LegitbotKey = 10
    end
    local f = Legitbot__key:Add( "F" )
    f.DoClick = function()
        retard_script.menuvars.LegitbotKey = 11
    end
    local g = Legitbot__key:Add( "G" )
    g.DoClick = function()
        retard_script.menuvars.LegitbotKey = 12
    end
    local h = Legitbot__key:Add( "H" )
    h.DoClick = function()
        retard_script.menuvars.LegitbotKey = 13
    end
    local i = Legitbot__key:Add( "I" )
    i.DoClick = function()
        retard_script.menuvars.LegitbotKey = 14
    end
    local j = Legitbot__key:Add( "J" )
    j.DoClick = function()
        retard_script.menuvars.LegitbotKey = 15
    end
    local k = Legitbot__key:Add( "K" )
    k.DoClick = function()
        retard_script.menuvars.LegitbotKey = 16
    end
    local l = Legitbot__key:Add( "L" )
    l.DoClick = function()
        retard_script.menuvars.LegitbotKey = 17
    end
    local m = Legitbot__key:Add( "M" )
    m.DoClick = function()
        retard_script.menuvars.LegitbotKey = 18
    end
    local k = Legitbot__key:Add( "N" )
    k.DoClick = function()
        retard_script.menuvars.LegitbotKey = 19
    end
    local k = Legitbot__key:Add( "O" )
    k.DoClick = function()
        retard_script.menuvars.LegitbotKey = 20
    end
    local k = Legitbot__key:Add( "P" )
    k.DoClick = function()
        retard_script.menuvars.LegitbotKey = 21
    end
    local k = Legitbot__key:Add( "Q" )
    k.DoClick = function()
        retard_script.menuvars.LegitbotKey = 22
    end
    local k = Legitbot__key:Add( "R" )
    k.DoClick = function()
        retard_script.menuvars.LegitbotKey = 23
    end
    local k = Legitbot__key:Add( "S" )
    k.DoClick = function()
        retard_script.menuvars.LegitbotKey = 24
    end
    local k = Legitbot__key:Add( "T" )
    k.DoClick = function()
        retard_script.menuvars.LegitbotKey = 25
    end
    local k = Legitbot__key:Add( "U" )
    k.DoClick = function()
        retard_script.menuvars.LegitbotKey = 26
    end
    local k = Legitbot__key:Add( "V" )
    k.DoClick = function()
        retard_script.menuvars.LegitbotKey = 27
    end
    local k = Legitbot__key:Add( "W" )
    k.DoClick = function()
        retard_script.menuvars.LegitbotKey = 28
    end
    local k = Legitbot__key:Add( "X" )
    k.DoClick = function()
        retard_script.menuvars.LegitbotKey = 29
    end
    local k = Legitbot__key:Add( "Y" )
    k.DoClick = function()
        retard_script.menuvars.LegitbotKey = 30
    end
    local k = Legitbot__key:Add( "Z" )
    k.DoClick = function()
        retard_script.menuvars.LegitbotKey = 31
    end
  
    LegitbotX:SetPos( 200, 30 )				-- Set the position
    LegitbotX:SetSize( 10, 10 )			-- Set the size
    LegitbotX:SetText( "RCS X" )	-- Set the text above the slider
    LegitbotX:SetMin( 0 )				 	-- Set the minimum number you can slide to
    LegitbotX:SetMax( 100 )				-- Set the maximum number you can slide to
    LegitbotX:SetDecimals( 0 )				-- Decimal places - zero for whole number
    LegitbotX:SetWide( 200 )				-- Decimal places - zero for whole number
    LegitbotX:SetTooltip("Pitch recoil control.")

    LegitbotY:SetPos( 200, 60 )				-- Set the position
    LegitbotY:SetSize( 10, 10 )			-- Set the size
    LegitbotY:SetText( "RCS Y" )	-- Set the text above the slider
    LegitbotY:SetMin( 0 )				 	-- Set the minimum number you can slide to
    LegitbotY:SetMax( 100 )				-- Set the maximum number you can slide to
    LegitbotY:SetDecimals( 0 )				-- Decimal places - zero for whole number
    LegitbotY:SetWide( 200 )				-- Decimal places - zero for whole number
    LegitbotY:SetTooltip("Yaw recoil control.")

    LegitbotFOV:SetPos( 200, 90 )				-- Set the position
    LegitbotFOV:SetSize( 10, 10 )			-- Set the size
    LegitbotFOV:SetText( "FOV" )	-- Set the text above the slider
    LegitbotFOV:SetMin( 0 )				 	-- Set the minimum number you can slide to
    LegitbotFOV:SetMax( 360 )				-- Set the maximum number you can slide to
    LegitbotFOV:SetDecimals( 0 )				-- Decimal places - zero for whole number
    LegitbotFOV:SetWide( 200 )				-- Decimal places - zero for whole number
    LegitbotFOV:SetTooltip("Only aims at people within range.")

    LegitbotSmoothing:SetPos( 200, 120 )				-- Set the position
    LegitbotSmoothing:SetSize( 10, 10 )			-- Set the size
    LegitbotSmoothing:SetText( "Smoothing" )	-- Set the text above the slider
    LegitbotSmoothing:SetMin( 0 )				 	-- Set the minimum number you can slide to
    LegitbotSmoothing:SetMax( 100 )				-- Set the maximum number you can slide to
    LegitbotSmoothing:SetDecimals( 0 )				-- Decimal places - zero for whole number
    LegitbotSmoothing:SetWide( 200 )				-- Decimal places - zero for whole number
    LegitbotSmoothing:SetTooltip("Lerp value of the aimbot.")

    LegitbotJitter:SetPos( 200, 150 )				-- Set the position
    LegitbotJitter:SetSize( 10, 10 )			-- Set the size
    LegitbotJitter:SetText( "Jitter" )	-- Set the text above the slider
    LegitbotJitter:SetMin( 0 )				 	-- Set the minimum number you can slide to
    LegitbotJitter:SetMax( 100 )				-- Set the maximum number you can slide to
    LegitbotJitter:SetDecimals( 0 )				-- Decimal places - zero for whole number
    LegitbotJitter:SetWide( 200 )				-- Decimal places - zero for whole number
    LegitbotJitter:SetTooltip("Jitter added to the final value of the aimbot.")


  --RagebotFov:SetPos( 50, 200 )
  --RagebotFov:SetWide( 230 )
  --RagebotFov:SetMin( 0 )
  --RagebotFov:SetMax( 180 )
  --RagebotFov:SetDecimals( 2 )

  LegitbotIgnoreFriends:SetPos(5,60)
  LegitbotIgnoreFriends:SetText("Ignore Friends")
  LegitbotIgnoreFriends:SetTooltip("Ignores steam friends.")

  LegitbotIgnoreNoclip:SetPos(5,90)
  LegitbotIgnoreNoclip:SetText("Ignore Noclip")
  LegitbotIgnoreNoclip:SetTooltip("Ignores noclipping players.")

  LegitbotIgnoreTeam:SetPos(5,120)
  LegitbotIgnoreTeam:SetText("Ignore Team")
  LegitbotIgnoreTeam:SetTooltip("Ignores teammates.")

end
LegitbotPage()

function LegitbotIgnoreFriends:OnChange( val )
	if val then
		retard_script.menuvars.LegitbotIgnoreFriends = true 
	else
		retard_script.menuvars.LegitbotIgnoreFriends = false  
	end
end

function LegitbotEnable:OnChange( val )
	if val then
		retard_script.menuvars.LegitbotEnable = true 
	else
		retard_script.menuvars.LegitbotEnable = false  
	end
end

function LegitbotIgnoreNoclip:OnChange( val )
	if val then
		retard_script.menuvars.LegitbotIgnoreNoclip = true 
	else
		retard_script.menuvars.LegitbotIgnoreNoclip = false  
	end
end

function LegitbotAutoshoot:OnChange( val )
	if val then
		retard_script.menuvars.LegitbotAutoshoot = true 
	else
		retard_script.menuvars.LegitbotAutoshoot = false  
	end
end

function LegitbotIgnoreTeam:OnChange( val )
	if val then
		retard_script.menuvars.LegitbotIgnoreTeam = true 
	else
		retard_script.menuvars.LegitbotIgnoreTeam = false  
	end
end

local function AAPage()
    AATabFrame:SetTitle( " Anti-Aim Page" )
    AATabFrame:SetSize( 400 , 300 )
    AATabFrame:SetPos(1475,30)	
    AATabFrame:ShowCloseButton(false)
    AATabFrame:SetIcon("icon16/shield_go.png")
    AATabFrame:MakePopup()
    AATabFrame.Paint = function( self, w, h ) -- 'function Frame:Paint( w, h )' works too
        draw.RoundedBox( 2, 0, 0, w, h, Color(23,23,23,255) )
    end
    AAEnable:SetPos(5,30)
    AAEnable:SetText("Anti-Aim Enable")
end 
AAPage()

function AAEnable:OnChange( val )
	if val then
		retard_script.menuvars.AAEnable = true 
	else
		retard_script.menuvars.AAEnable = false  
	end
end

local function MiscPage()
    MiscPageFrame:SetTitle( " Misc Page" )
    MiscPageFrame:SetSize( 400 , 300 )
    MiscPageFrame:SetPos(664,30)	
    MiscPageFrame:ShowCloseButton(false)
    MiscPageFrame:SetIcon("icon16/plugin.png")
    MiscPageFrame:MakePopup()
    MiscPageFrame.Paint = function( self, w, h ) -- 'function Frame:Paint( w, h )' works too
        draw.RoundedBox( 2, 0, 0, w, h, Color(23,23,23,255) )
        draw.Text( {
            text = "FOV",
            pos = { 5, 220 },
        } ) 
    end

    BunnyHop:SetPos(5,30)
    BunnyHop:SetText("Bunnyhop")
    BunnyHop:SetTooltip("Automaticly jumps for you when you hit the ground.")

    NightMode:SetPos(5,60)
    NightMode:SetText("World Modulation")
    NightMode:SetTooltip("Changes the world color.")

    NightModeColor:SetSize(150,120)
    NightModeColor:SetPos(150, 20)
    NightModeColor:SetPalette(false)
    NightModeColor:SetWangs(false)
    NightModeColor:SetAlphaBar(false)
    NightModeColor:SetLabel( "" )

    MiniLog:SetPos(5,90)
    MiniLog:SetText("Mini Log")
    MiniLog:SetTooltip("Logs important things in a small black box in the corner of your screen.")
    MiniLog:SetChecked(true) -- set it to trueeee

    NoSky:SetPos(5,120)
    NoSky:SetText("No Sky")
    NoSky:SetTooltip("Removes the sky.")

    Watermark:SetPos(5,150)
    Watermark:SetText("Watermark")
    Watermark:SetTooltip("Adds a logo to the corner of your screen.")

    Logs:SetPos(5,180)
    Logs:SetText("Logs")
    Logs:SetTooltip("Prints some info when someone gets hurt, also prints when the aimbot finds a target.")

    RainbowPhysgun:SetPos(5,255)
    RainbowPhysgun:SetText("Rainbow Physgun")
    RainbowPhysgun:SetTooltip("Sets the physguns color to a random value.")

    FOV:SetPos( -75,210 )
    FOV:SetWide( 275 )
    FOV:SetMin( 75 ) -- Or 3 for second image
    FOV:SetMax( 180 )
    FOV:SetValue( 75 )
    FOV:SetDecimals( 2 )
    FOV:SetTooltip("Changes the field of vision.")
    FOV:SetValue(GetConVar('fov_desired'):GetInt())
end

MiscPage()

function BunnyHop:OnChange( val )
	if val then
		retard_script.menuvars.Bhop = true 
	else
		retard_script.menuvars.Bhop = false  
	end
end

function RainbowPhysgun:OnChange( val )
	if val then
		retard_script.menuvars.RainbowPhysgun = true 
	else
		retard_script.menuvars.RainbowPhysgun = false  
	end
end

function MiniLog:OnChange( val )
	if val then
		retard_script.menuvars.MiniLog = true 
	else
		retard_script.menuvars.MiniLog = false  
	end
end

function Logs:OnChange( val )
	if val then
		retard_script.menuvars.Logs = true 
	else
		retard_script.menuvars.Logs = false  
	end
end

function Watermark:OnChange( val )
	if val then
		retard_script.menuvars.Watermark = true 
	else
		retard_script.menuvars.Watermark = false  
	end
end

function NoSky:OnChange( val )
	if val then
		retard_script.menuvars.NoSky = true 
	else
		retard_script.menuvars.NoSky = false  
	end
end

function NightMode:OnChange( val )
	if val then
		retard_script.menuvars.NightMode = true 
	else
		retard_script.menuvars.NightMode = false  
	end
end

local function ESPMiscPage()
    ESPMiscPageFrame:SetTitle( " ESP Misc" )
    ESPMiscPageFrame:SetSize( 250, 300 )
    ESPMiscPageFrame:SetPos(435,350)	
    ESPMiscPageFrame:ShowCloseButton(false)
    ESPMiscPageFrame:MakePopup()
    ESPMiscPageFrame.Paint = function( self, w, h ) -- 'function Frame:Paint( w, h )' works too
        draw.RoundedBox( 2, 0, 0, w, h, Color(23,23,23,255) )
    end
    
    VisibleCheck:SetPos(5,30)
    VisibleCheck:SetText("Visible check")
    VisibleCheck:SetTooltip("Checks if the player is visible before drawing ESP.")

    BoxType:SetPos(5, 60)
    BoxType:SetSize(100, 20)
    BoxType:SetValue("Box Type")
    BoxType:AddChoice( "Normal" )
    BoxType:AddChoice( "Solid" )
    BoxType:AddChoice( "Edge" )
    BoxType:AddChoice( "3D" )
    BoxType.OnSelect = function( self, index, value )
        retard_script.menuvars.BoxType = index
    end

end
ESPMiscPage()

function VisibleCheck:OnChange( val )
	if val then
		retard_script.menuvars.VisibleCheck = true 
	else
		retard_script.menuvars.VisibleCheck = false  
	end
end

local function ESPShowcaser()
    ESPShowcaseFrame:SetTitle( " ESP Preview" )
    ESPShowcaseFrame:SetSize( 250, 300 )
    ESPShowcaseFrame:SetPos(700,350)	
    ESPShowcaseFrame:ShowCloseButton(false)
    ESPShowcaseFrame:MakePopup()
    ESPShowcaseFrame.Paint = function( self, w, h ) -- 'function Frame:Paint( w, h )' works too
        draw.RoundedBox( 2, 0, 0, w, h, Color(23,23,23,255) )
        if(retard_script.menuvars.ESPEnable) then 
        if(retard_script.menuvars.NameESP) then 
            draw.Text( {
                text = "Player",
                pos = { 100, 25 },
                font = "BudgetLabel",
                color = ESPMainColor:GetColor(),
            } ) 
        end
        if(retard_script.menuvars.HealthNumber) then 
            draw.Text( {
                text = "Health: 62",
                pos = { 87, 230 },
                font = "BudgetLabel",
                color = ESPMainColor:GetColor(),
            } ) 
        end
        if(retard_script.menuvars.WepESP) then 
            if(retard_script.menuvars.HealthNumber) then 
                draw.Text( {
                    text = "weapon_fists",
                    pos = { 84, 250 },
                    font = "BudgetLabel",
                    color = ESPMainColor:GetColor(),
                } ) 
            else
                draw.Text( {
                    text = "weapon_fists",
                    pos = { 84, 230 },
                    font = "BudgetLabel",
                    color = ESPMainColor:GetColor(),
                } ) 
                end
            end
        end

        if(retard_script.menuvars.HealthBar) then 
            draw.RoundedBox( 0, 76, 51, 5, 175, Color(0,0,0,255) ) 
            draw.RoundedBox( 0, 75, 50, 5, 175, Color(0,255,0,255) ) 
        end
    end

    ESPShowcaser_:SetPos(25,25)
    ESPShowcaser_:SetSize(200,200)
    ESPShowcaser_:SetModel( "models/player/breen.mdl" ) -- you can only change colors on playermodels
    ESPShowcaser_:SetCamPos(Vector(40, 40, 40))

    function ESPShowcaser_:LayoutEntity( Entity ) return end -- disables default rotation
    function ESPShowcaser_.Entity:GetPlayerColor() return Vector (1, 0, 0) end
end 
ESPShowcaser()

function ESPShowcaser_:PreDrawModel(ent)
    if(retard_script.menuvars.Chams) then 
    ESPShowcaser_:SetColor(HSVToColor(  ( CurTime() * 25 ) % 360, 1, 1 ))
    ent:SetMaterial("models/debug/debugwhite")
    else 
    ESPShowcaser_:SetColor(Color(255,255,255,255))
    ent:SetMaterial("")
    end
end

local function ESPPage()
    ESPPageFrame:SetTitle( " ESP Page" )
    ESPPageFrame:SetSize( 500, 400 )
    ESPPageFrame:SetPos(1375,350)	
    ESPPageFrame:ShowCloseButton(false)
    ESPPageFrame:SetIcon("icon16/color_wheel.png")
    ESPPageFrame:MakePopup()
    ESPPageFrame.Paint = function( self, w, h ) -- 'function Frame:Paint( w, h )' works too
        draw.RoundedBox( 2, 0, 0, w, h, Color(23,23,23,255) )
        draw.Text( {
            text = "",
            pos = { 150, 25 },
            font = "MenuFont",
        } ) 
        draw.Text( {
            text = "",
            pos = { 150, 235 },
            font = "MenuFont",
        } ) 
    end

    ESPEnable:SetPos(5,30)
    ESPEnable:SetText("ESP Enable")
    ESPEnable:SetTooltip("Enable Extra Sensory Perception.")
      NameESP:SetPos(5,60)
      NameESP:SetText("Name ESP")
      NameESP:SetTooltip("Shows names above player heads.")
      HealthNumber:SetPos(5,90)
      HealthNumber:SetText("Health Number ESP")
      HealthNumber:SetTooltip("Shows the amount of health the player has.")
      HealthBar:SetPos(5,120)
      HealthBar:SetText("Health Bar ESP")
      HealthBar:SetTooltip("Shows a bar with the health of the player.")
      Chams:SetPos(5,150)
      Chams:SetText("Chams ESP")
      Chams:SetTooltip("Colors the players playermodel.")
      WepESP:SetPos(5,180)
      WepESP:SetText("Weapon ESP")
      WepESP:SetTooltip("Shows the weapon that the player is using.")
      SkellESP:SetText("Skeleton ESP")
      SkellESP:SetPos(250,30)
      SkellESP:SetTooltip("Draws the bones of the player.")
      BoundingBox:SetText("Bounding ESP")
      BoundingBox:SetPos(250,60)
      BoundingBox:SetTooltip("Shows a box around the player.")
      Glow:SetText("Glow ESP")
      Glow:SetPos(250,90)
      Glow:SetTooltip("Makes the player glow.")
      HaloESP:SetText("Halo ESP")
      HaloESP:SetPos(250,120)
      HaloESP:SetTooltip("Draws a halo around the player.")
      Hitpoint:SetText("Hitpoint ESP")
      Hitpoint:SetPos(250,150)
      Hitpoint:SetTooltip("Draws where the player is looking.")
      VisionLine:SetText("Vision Line ESP")
      VisionLine:SetPos(250,180)
      VisionLine:SetTooltip("Draws where the player is looking.")
     RainbowA:SetText("Rainbow")
     RainbowA:SetPos(165,300)
     RainbowB:SetText("Rainbow")
     RainbowB:SetPos(415,300)
     ESPMainColor:SetSize(150,150)
      ESPMainColor:SetPos(5, 240)
      ESPMainColor:SetPalette(false)
      ESPMainColor:SetWangs(false)
      ESPMainColor:SetAlphaBar(false)
      ESPMainColor:SetLabel( "" )
      ESPSecondaryColor:SetSize(150,150)
      ESPSecondaryColor:SetPos(250, 240)
      ESPSecondaryColor:SetPalette(false)
      ESPSecondaryColor:SetWangs(false)
      ESPSecondaryColor:SetAlphaBar(false)
      ESPSecondaryColor:SetLabel( "" )

      ESPMiscButton:SetText("ESP Misc")
      ESPMiscButton:SetSize(80, 15)
      ESPMiscButton:SetPos(250,210)
      ESPMiscButton.DoClick = function() 
          if(retard_script.vars.IsESPMisc) then 
              retard_script.vars.IsMiscESPOptionsEnabled = false 
              ESPMiscPageFrame:SetVisible(false)
          else
              retard_script.vars.IsMiscESPOptionsEnabled = true 
              ESPMiscPageFrame:SetVisible(true)
          end
      end


      ESPShowcaseButton:SetText("ESP Showcase")
      ESPShowcaseButton:SetSize(80, 15)
      ESPShowcaseButton:SetPos(5,210)
      ESPShowcaseButton.DoClick = function() 
          if(retard_script.vars.IsEspShowcaseOn) then 
              retard_script.vars.IsEspShowcaseOn = false 
              ESPShowcaseFrame:SetVisible(false)
          else
              retard_script.vars.IsEspShowcaseOn = true 
              ESPShowcaseFrame:SetVisible(true)
          end
      end

end
ESPPage()
function NameESP:OnChange( val )
	if val then
		retard_script.menuvars.NameESP = true 
	else
		retard_script.menuvars.NameESP = false  
	end
end

function RainbowA:OnChange( val )
	if val then
		retard_script.menuvars.RainbowA = true 
	else
		retard_script.menuvars.RainbowA = false  
	end
end

function RainbowB:OnChange( val )
	if val then
		retard_script.menuvars.RainbowB = true 
	else
		retard_script.menuvars.RainbowB = false  
	end
end

function VisionLine:OnChange( val )
	if val then
		retard_script.menuvars.VisionLine = true 
	else
		retard_script.menuvars.VisionLine = false  
	end
end

function Hitpoint:OnChange( val )
	if val then
		retard_script.menuvars.Hitpoint = true 
	else
		retard_script.menuvars.Hitpoint = false  
	end
end

function HaloESP:OnChange( val )
	if val then
		retard_script.menuvars.Halo = true 
	else
		retard_script.menuvars.Halo = false  
	end
end

function Glow:OnChange( val )
	if val then
		retard_script.menuvars.Glow = true 
	else
		retard_script.menuvars.Glow = false  
	end
end

function BoundingBox:OnChange( val )
	if val then
		retard_script.menuvars.BoundingBox = true 
	else
		retard_script.menuvars.BoundingBox = false  
	end
end

function SkellESP:OnChange( val )
	if val then
		retard_script.menuvars.SkellESP = true 
	else
		retard_script.menuvars.SkellESP = false  
	end
end

function WepESP:OnChange( val )
	if val then
		retard_script.menuvars.WepESP = true 
	else
		retard_script.menuvars.WepESP = false  
	end
end

function Chams:OnChange( val )
	if val then
		retard_script.menuvars.Chams = true 
	else
		retard_script.menuvars.Chams = false  
    end
    for k, v in ipairs( player.GetAll() ) do
        v.OldMatT = v:GetMaterial()
        v.OldColorT = v:GetColor()
    end
end

function HealthBar:OnChange( val )
	if val then
		retard_script.menuvars.HealthBar = true 
	else
		retard_script.menuvars.HealthBar = false  
	end
end

function HealthNumber:OnChange( val )
	if val then
		retard_script.menuvars.HealthNumber = true 
	else
		retard_script.menuvars.HealthNumber = false  
	end
end

function ESPEnable:OnChange( val )
	if val then
		retard_script.menuvars.ESPEnable = true 
	else
		retard_script.menuvars.ESPEnable = false  
	end
end


local function Menu()

    Frame:SetTitle( " Retard Script V0.9" )
    Frame:SetSize( ScrW() ,25 )
    Frame:SetPos(0,0)		
    Frame:SetDraggable(false)	
    Frame:SetSizable(false)
    Frame:SetIcon("icon16/rainbow.png")
    Frame:ShowCloseButton(false)
    Frame:MakePopup()
    Frame.Paint = function( self, w, h ) -- 'function Frame:Paint( w, h )' works too
        draw.RoundedBox( 2, 0, 0, w, h, Color(23,23,23,255) )
    end
    Button_Main_Page_Tab:SetText("Main")
    Button_Main_Page_Tab:SetSize(60, 15)
    Button_Main_Page_Tab:SetPos(140,4)
    Button_Main_Page_Tab.DoClick = function() 
        if(retard_script.vars.IsMainPageOn) then 
            retard_script.vars.IsMainPageOn = false 
        MainPageFrame:SetVisible(false)
        else
            retard_script.vars.IsMainPageOn = true 
        MainPageFrame:SetVisible(true)
        end
    end

    Button_Ragebot_Page_Tab:SetText("Ragebot")
    Button_Ragebot_Page_Tab:SetSize(60, 15)
    Button_Ragebot_Page_Tab:SetPos(210,4)
    Button_Ragebot_Page_Tab.DoClick = function() 
        if(retard_script.vars.IsRagebotPageOn) then 
            retard_script.vars.IsRagebotPageOn = false 
            RagebotPageFrame:SetVisible(false)
        else
            retard_script.vars.IsRagebotPageOn = true 
            RagebotPageFrame:SetVisible(true)
        end
    end

    Button_Legitbot_Page_Tab:SetText("Legitbot")
    Button_Legitbot_Page_Tab:SetSize(60, 15)
    Button_Legitbot_Page_Tab:SetPos(280,4)
    Button_Legitbot_Page_Tab.DoClick = function() 
        if(retard_script.vars.IsLegitbotPageOn) then 
            retard_script.vars.IsLegitbotPageOn = false 
            LegitbotPageFrame:SetVisible(false)
        else
            retard_script.vars.IsLegitbotPageOn = true 
            LegitbotPageFrame:SetVisible(true)
        end
    end

    Button_ESP_Tab:SetText("ESP")
    Button_ESP_Tab:SetSize(60, 15)
    Button_ESP_Tab:SetPos(350,4)
    Button_ESP_Tab.DoClick = function() 
        if(retard_script.vars.IsESPPageOn) then 
            retard_script.vars.IsESPPageOn = false 
            ESPPageFrame:SetVisible(false)
        else
            retard_script.vars.IsESPPageOn = true 
            ESPPageFrame:SetVisible(true)
        end
    end

    Button_Prop_ESP_Tab:SetText("Props")
    Button_Prop_ESP_Tab:SetSize(60, 15)
    Button_Prop_ESP_Tab:SetPos(420,4) -- blaze it
    Button_Prop_ESP_Tab.DoClick = function() 
        if(retard_script.vars.IsPropESPOn) then 
            retard_script.vars.IsPropESPOn = false 
            PropESPPageFrame:SetVisible(false)
        else
            retard_script.vars.IsPropESPOn = true 
            PropESPPageFrame:SetVisible(true)
        end
    end

    
    Button_Misc_Tab:SetText("Misc")
    Button_Misc_Tab:SetSize(60, 15)
    Button_Misc_Tab:SetPos(490,4)
    Button_Misc_Tab.DoClick = function() 
        if(retard_script.vars.IsMiscTabOn) then 
            retard_script.vars.IsMiscTabOn = false 
            MiscPageFrame:SetVisible(false)
        else
            retard_script.vars.IsMiscTabOn = true 
            MiscPageFrame:SetVisible(true)
        end
    end

    Button_AntiAim_Tab:SetText("AntiAim")
    Button_AntiAim_Tab:SetSize(60, 15)
    Button_AntiAim_Tab:SetPos(560,4)
    Button_AntiAim_Tab.DoClick = function() 
        if(retard_script.vars.IsAATabOn) then 
            retard_script.vars.IsAATabOn = false 
            AATabFrame:SetVisible(false)
        else
            retard_script.vars.IsAATabOn = true 
            AATabFrame:SetVisible(true)
        end
    end

    Frame:SetVisible(false)
    
end

Menu()

local function OpenMenu()
    if(retard_script.vars.InsertKeyPress) then return end
    Frame:SetVisible(true)
    MainPageFrame:SetVisible(true)
    RagebotPageFrame:SetVisible(true)
    LegitbotPageFrame:SetVisible(true)
    MiscPageFrame:SetVisible(true)
    ESPPageFrame:SetVisible(true)
    AATabFrame:SetVisible(true)
    PropESPPageFrame:SetVisible(true)
    retard_script.vars.IsMenuOpen = true 
    retard_script.vars.IsInsertDown = true 

end

OpenMenu()

local function CloseMenu()
    Frame:SetVisible(false)
    MainPageFrame:SetVisible(false)
    RagebotPageFrame:SetVisible(false)
    LegitbotPageFrame:SetVisible(false)
    MiscPageFrame:SetVisible(false)
    ESPPageFrame:SetVisible(false)
    ESPShowcaseFrame:SetVisible(false)
    ESPMiscPageFrame:SetVisible(false)
    BoxType:CloseMenu() -- Have to do this or the box will stay open while the menu is closed
    AATabFrame:SetVisible(false)
    PropESPPageFrame:SetVisible(false)
    retard_script.vars.IsMenuOpen = false 
    retard_script.vars.IsInsertDown = false
end

local txt = {}
local txtColor = {}
local function MiniLog(shouldDrawInsertText,insertText,text,importantLevel,shouldDrawClockTimeDate)
    if(not retard_script.menuvars.MiniLog) then return end 

    local curMiniLogTxt = ""

    if(shouldDrawInsertText) then 
        if(shouldDrawClockTimeDate) then 
        curMiniLogTxt = "["..os.date("%H:%M:%S").."] " .. insertText .. text
        else 
        curMiniLogTxt = insertText .. text 
        end
    else
        if(shouldDrawClockTimeDate) then 
        curMiniLogTxt = "["..os.date("%H:%M:%S").."] " .. text 
        else 
        curMiniLogTxt = text 
        end
    end

    if(#txt > 5) then 
        table.remove(txt, 1)
    end
    if(#txtColor > 5) then 
        table.remove(txtColor, 1)
    end

    table.insert(txtColor, #txtColor, importantLevel)
    table.insert(txt, #txt, curMiniLogTxt)

end
MiniLog(true," ",' ',Color(255,255,255))
MiniLog(true," ",' ',Color(255,255,255))

http.Fetch("https://pastebin.com/raw/McQ3hMJN",

function(body, len, headers, code)
    if(body ~= "0.90") then 
        CloseMenu()
        retard_script.vars.IsInsertDown = true 
        retard_script.vars.HasSecurityCheckFailed = true 
        chat.AddText(Color(255, 255, 255), "Security check failed, please update your version. (current build: 0.90, new build: " .. body)
    end 
end,

function(error)
	chat.AddText(Color(255, 255, 255), "Check your internet, security check failed.")
    CloseMenu()
    retard_script.vars.HasSecurityCheckFailed = true 
    retard_script.vars.IsInsertDown = true 
end)

local function HandleHitboxStrings(hb,wep)

    if(wep:GetClass() == "weapon_crowbar" or wep:GetClass() == "weapon_fists" or wep:GetClass() == "weapon_stunstick") then return "generic" end

    if(hb == 0) then 
        return "generic"
    elseif(hb==1) then 
        return "head"
    elseif(hb==2) then 
        return "upper chest"
    elseif(hb==3) then 
        return "lower chest"
    elseif(hb==4) then 
        return "left arm"
    elseif(hb==5) then 
        return "right arm"
    elseif(hb==6) then
        return "left leg"
    elseif(hb==7) then 
        return "right leg"
    elseif(hb==10) then 
        return "generic"
    end
end

__hook.Add("StartCommand", "test", function()
    

    if(_input.WasKeyReleased(0x18 * 0x3) and not retard_script.vars.IsInsertDown) then
        if(retard_script.vars.LastMenuCall + 0.2 < CurTime()) then 
        OpenMenu()
        retard_script.vars.LastMenuCall = CurTime()
        end
    elseif(_input.WasKeyReleased(0x18 * 0x3) and retard_script.vars.IsMenuOpen) then
        if(retard_script.vars.LastMenuCall + 0.2 < CurTime()) then 
        CloseMenu()
        retard_script.vars.LastMenuCall = CurTime()
        end
    end
end)
MsgC(retard_script.colors.theme2 , "[FUNCTIONS] ",retard_script.colors.theme1, "Hook added StartCommand \n")

__hook.Add("StartChat", "test", function()
    retard_script.vars.IsChatboxOpen = true 
end)
MsgC(retard_script.colors.theme2 , "[FUNCTIONS] ",retard_script.colors.theme1, "Hook added StartChat \n")

__hook.Add( "FinishChat", "test", function()
    retard_script.vars.IsChatboxOpen = false 
end )
MsgC(retard_script.colors.theme2 , "[FUNCTIONS] ",retard_script.colors.theme1, "Hook added FinishChat \n")

local delay = 0 

local function RainbowPhysgun()
    if(not retard_script.menuvars.RainbowPhysgun) then return end
    local rnd_red = HSVToColor(  ( CurTime() * 25 ) % 360, 1, 1 )['r'] / 255
    local rnd_green = HSVToColor(  ( CurTime() * 25 ) % 360, 1, 1 )['g'] / 255 
    local rnd_blue = HSVToColor(  ( CurTime() * 25 ) % 360, 1, 1 )['b'] / 255
    if(IsValid(LocalPlayer():GetActiveWeapon())) then 
        if(LocalPlayer():GetActiveWeapon():GetClass() == 'weapon_physgun') then 
            LocalPlayer():SetWeaponColor( Vector(rnd_red * 5, rnd_green * 5, rnd_blue * 5) )
        end
    end
end

timer.Create(util.TypeToString(retard_script.functions.rs), 0.1, 0, RainbowPhysgun)

__hook.Add("CreateMove","Stuff", function(cmd)

    if(delay + 0.2 < CurTime()) then 

    local va = Angle(0,0,0)
    if(retard_script.menuvars.FlipY and _input.IsKeyDown( 31 )) then 
        va.x = cmd:GetViewAngles().x
        va.y = math.Clamp(cmd:GetViewAngles().y + 180,-180,180)
        va.r = cmd:GetViewAngles().r
        cmd:SetViewAngles(va)
    end
    if(retard_script.menuvars.FlipP and _input.IsKeyDown( 30 )) then 
        va.x = math.Clamp(cmd:GetViewAngles().x + 89,-89,89)
        va.y = cmd:GetViewAngles().y 
        va.r = cmd:GetViewAngles().r
        cmd:SetViewAngles(va)
        end
    delay = CurTime()
    end
end)
MsgC(retard_script.colors.theme2 , "[FUNCTIONS] ",retard_script.colors.theme1, "Hook added CreateMove \n")

surface.CreateFont("MinilogFont", {
    font = "HudHintTextLarge", --  Use the font-name which is shown to you by your operating system Font Viewer, not the file name
	extended = false, -- latin text
	size = 15,
	weight = 400,
	blursize = 0,
	scanlines = 0,
	antialias = false,
	underline = false,
	italic = false,
	strikeout = false,
	symbol = false,
	rotary = false,
	shadow = false,
	additive = false,
	outline = false,
})

local function EntityName()
	if util.TraceLine(util.GetPlayerTrace(LocalPlayer())).Entity:IsValid() then
		return util.TraceLine(util.GetPlayerTrace(LocalPlayer())).Entity:GetClass()
	else
		return "None"
	end
end


__hook.Add("PreDrawEffects","test", function()
    if(retard_script.menuvars.HeadBeams) then 
        for k, v in ipairs( ents.FindByClass( "prop_*" ) ) do
            local pos = v:LocalToWorld(v:OBBCenter())
            render.SetMaterial(Material("cable/physbeam"))    
            render.DrawBeam( v:GetPos(), Vector(0,0,999999), 25, 99999, 99999, Color(255,255,3,255) )
        end
    end
end)

__hook.Add("HUDPaint","test", function()
    retard_script.vars.ChamsColor = ESPSecondaryColor:GetValue()

    if(retard_script.menuvars.MiniLog) then 

        draw.RoundedBox( 10, 350, 960, 400, 100, Color(0,0,0,150) )
        for k,v in pairs(txt) do 
            if(k == 0) then 
            draw.DrawText(v, "MinilogFont", 365, 955, txtColor[k])
            elseif(k == 1) then 
            draw.DrawText(v, "MinilogFont", 365, 970, txtColor[k])
            elseif(k == 2) then 
            draw.DrawText(v, "MinilogFont", 365, 985, txtColor[k])
            elseif(k == 3) then 
            draw.DrawText(v, "MinilogFont", 365, 1000, txtColor[k])
            elseif(k == 4) then
            draw.DrawText(v, "MinilogFont", 365, 1015, txtColor[k])
            elseif(k == 5) then
            draw.DrawText(v, "MinilogFont", 365, 1030, txtColor[k])
            elseif(k == 6) then
            draw.DrawText(v, "MinilogFont", 365, 1045, txtColor[k])
            end 
        end
    end

    if(retard_script.menuvars.DebugInfo_) then 
        draw.DrawText("Current Velocity (rounded 2 d): " .. math.Round(LocalPlayer():GetVelocity().x,2) .. " \n \r Current ent:Name(): " .. LocalPlayer():Name() .. "\n \r  Current FPS (before interp): " .. (1 / RealFrameTime()) .. "\n \r Traceline ent: " .. EntityName() .. " \n \r  Current Angle: " .. util.TypeToString(EyeAngles()) .. "\n \r \r World Pos: " .. util.TypeToString(LocalPlayer():GetPos()) .. " \n \r \r Entity Amount (including player animation vertexes): " .. math.Round(ents.GetCount() - player.GetCount()*12) .. "\n \r \r Map: " .. game.GetMap() .. "\n \r \r \r Date (time stamp): " .. os.date("%d %b %Y %H:%M:%S"), "MinilogFont", 15, 400, Color(255,255,255))
    end

    if(retard_script.menuvars.Watermark) then 
        draw.SimpleText( "Retard Script", "shmenufont", 12, 15, Color(210, 210, 210, 235) )
        draw.SimpleText( "                    V0.9", "shmenufont", 15, 16, Color(0, 192, 255, 235) )

        surface.SetFont("DermaDefault")
        surface.SetTextPos(15, 50)
        surface.SetTextColor(255,255,255)
        surface.DrawText("By paradox")

    end
end)

MsgC(retard_script.colors.theme2 , "[FUNCTIONS] ",retard_script.colors.theme1, "Hook added HUDPaint \n")

local function GetPos(v)
    local eyes = v:LookupAttachment("eyes");
    return(eyes and v:GetAttachment(eyes).Pos or v:LocalToWorld(v:OBBCenter()));
end
MsgC(retard_script.colors.theme2 , "[FUNCTIONS] ",retard_script.colors.theme1, "GetPos(v) added \n")


local function IsVis(v)
    local tr = {
        start = v.EyePos(LocalPlayer()), 
        endpos = GetPos(v), 
        mask = MASK_SHOT, 
        filter = {LocalPlayer(), v}, 
    }
    if(util.TraceLine(tr).Fraction == 1) then
        return true 
    else
        return false 
    end
end
MsgC(retard_script.colors.theme2 , "[FUNCTIONS] ",retard_script.colors.theme1,  "IsVis(v) added \n")

local function predictSpread(cmd,ang)

    if(not IsValid(LocalPlayer():GetActiveWeapon())) then return end
    if(not IsValid(LocalPlayer():GetActiveWeapon().Primary)) then return end 
    local wepSpread = LocalPlayer():GetActiveWeapon().Primary.Spread 
    if(wepSpread == nil or wepSpread > 0) then return end  -- Anti Anti No Spread (this could prob be a anticheat ngl)
    dickwrap.Predict(cmd,ang.Forward(ang), LocalPlayer():GetViewOffset()) -- todo fix the stupid ass module
end
MsgC(retard_script.colors.theme2 , "[FUNCTIONS] ",retard_script.colors.theme1,  "predictSpread(cmd,ang) added \n")

local function IsRagebotKeyDown()
    if(retard_script.menuvars.RagebotKey == 0) then
        return false 
    elseif(retard_script.menuvars.RagebotKey == 1 and _input.IsMouseDown(MOUSE_LEFT)) then 
        return true
    elseif(retard_script.menuvars.RagebotKey == 2 and _input.IsMouseDown(MOUSE_RIGHT)) then 
        return true 
    elseif(retard_script.menuvars.RagebotKey == 3 and _input.IsMouseDown(MOUSE_MIDDLE)) then 
        return true 
    elseif(retard_script.menuvars.RagebotKey == 4 and _input.IsMouseDown(MOUSE_4)) then 
        return true 
    elseif(retard_script.menuvars.RagebotKey == 5 and _input.IsMouseDown(MOUSE_5)) then 
        return true 
    elseif(retard_script.menuvars.RagebotKey == 6 and _input.IsKeyDown(KEY_A)) then 
        return true 
    elseif(retard_script.menuvars.RagebotKey == 7 and _input.IsKeyDown(KEY_B)) then 
        return true 
    elseif(retard_script.menuvars.RagebotKey == 8 and _input.IsKeyDown(KEY_C)) then 
        return true 
    elseif(retard_script.menuvars.RagebotKey == 9 and _input.IsKeyDown(KEY_D)) then 
        return true 
    elseif(retard_script.menuvars.RagebotKey == 10 and _input.IsKeyDown(KEY_E)) then 
        return true 
    elseif(retard_script.menuvars.RagebotKey == 11 and _input.IsKeyDown(KEY_F)) then 
        return true 
    elseif(retard_script.menuvars.RagebotKey == 12 and _input.IsKeyDown(KEY_G)) then 
        return true 
    elseif(retard_script.menuvars.RagebotKey == 13 and _input.IsKeyDown(KEY_H)) then 
        return true 
    elseif(retard_script.menuvars.RagebotKey == 14 and _input.IsKeyDown(KEY_I)) then 
        return true 
    elseif(retard_script.menuvars.RagebotKey == 15 and _input.IsKeyDown(KEY_J)) then 
        return true 
    elseif(retard_script.menuvars.RagebotKey == 16 and _input.IsKeyDown(KEY_K)) then 
        return true 
    elseif(retard_script.menuvars.RagebotKey == 17 and _input.IsKeyDown(KEY_L)) then 
        return true 
    elseif(retard_script.menuvars.RagebotKey == 18 and _input.IsKeyDown(KEY_M)) then 
        return true 
    elseif(retard_script.menuvars.RagebotKey == 19 and _input.IsKeyDown(KEY_N)) then 
        return true 
    elseif(retard_script.menuvars.RagebotKey == 20 and _input.IsKeyDown(KEY_O)) then 
        return true 
    elseif(retard_script.menuvars.RagebotKey == 21 and _input.IsKeyDown(KEY_P)) then 
        return true 
    elseif(retard_script.menuvars.RagebotKey == 22 and _input.IsKeyDown(KEY_Q)) then 
        return true 
    elseif(retard_script.menuvars.RagebotKey == 23 and _input.IsKeyDown(KEY_R)) then 
        return true 
    elseif(retard_script.menuvars.RagebotKey == 24 and _input.IsKeyDown(KEY_S)) then 
        return true 
    elseif(retard_script.menuvars.RagebotKey == 25 and _input.IsKeyDown(KEY_T)) then 
        return true 
    elseif(retard_script.menuvars.RagebotKey == 26 and _input.IsKeyDown(KEY_U)) then 
        return true 
    elseif(retard_script.menuvars.RagebotKey == 27 and _input.IsKeyDown(KEY_V)) then 
        return true 
    elseif(retard_script.menuvars.RagebotKey == 28 and _input.IsKeyDown(KEY_W)) then 
        return true 
    elseif(retard_script.menuvars.RagebotKey == 29 and _input.IsKeyDown(KEY_X)) then 
        return true 
    elseif(retard_script.menuvars.RagebotKey == 30 and __input.IsKeyDown(KEY_Y)) then 
        return true 
    elseif(retard_script.menuvars.RagebotKey == 31 and _input.IsKeyDown(KEY_Z)) then 
        return true 
    end
    return false 
end

local function IsLegitbotKeyDown()
    if(retard_script.menuvars.LegitbotKey == 0) then
        return false 
    elseif(retard_script.menuvars.LegitbotKey == 1 and _input.IsMouseDown(MOUSE_LEFT)) then 
        return true
    elseif(retard_script.menuvars.LegitbotKey == 2 and _input.IsMouseDown(MOUSE_RIGHT)) then 
        return true 
    elseif(retard_script.menuvars.LegitbotKey == 3 and _input.IsMouseDown(MOUSE_MIDDLE)) then 
        return true 
    elseif(retard_script.menuvars.LegitbotKey == 4 and _input.IsMouseDown(MOUSE_4)) then 
        return true 
    elseif(retard_script.menuvars.LegitbotKey == 5 and _input.IsMouseDown(MOUSE_5)) then 
        return true 
    elseif(retard_script.menuvars.LegitbotKey == 6 and _input.IsKeyDown(KEY_A)) then 
        return true 
    elseif(retard_script.menuvars.LegitbotKey == 7 and _input.IsKeyDown(KEY_B)) then 
        return true 
    elseif(retard_script.menuvars.LegitbotKey == 8 and _input.IsKeyDown(KEY_C)) then 
        return true 
    elseif(retard_script.menuvars.LegitbotKey == 9 and _input.IsKeyDown(KEY_D)) then 
        return true 
    elseif(retard_script.menuvars.LegitbotKey == 10 and _input.IsKeyDown(KEY_E)) then 
        return true 
    elseif(retard_script.menuvars.LegitbotKey == 11 and _input.IsKeyDown(KEY_F)) then 
        return true 
    elseif(retard_script.menuvars.LegitbotKey == 12 and _input.IsKeyDown(KEY_G)) then 
        return true 
    elseif(retard_script.menuvars.LegitbotKey == 13 and _input.IsKeyDown(KEY_H)) then 
        return true 
    elseif(retard_script.menuvars.LegitbotKey == 14 and _input.IsKeyDown(KEY_I)) then 
        return true 
    elseif(retard_script.menuvars.LegitbotKey == 15 and _input.IsKeyDown(KEY_J)) then 
        return true 
    elseif(retard_script.menuvars.LegitbotKey == 16 and _input.IsKeyDown(KEY_K)) then 
        return true 
    elseif(retard_script.menuvars.LegitbotKey == 17 and _input.IsKeyDown(KEY_L)) then 
        return true 
    elseif(retard_script.menuvars.LegitbotKey == 18 and _input.IsKeyDown(KEY_M)) then 
        return true 
    elseif(retard_script.menuvars.LegitbotKey == 19 and _input.IsKeyDown(KEY_N)) then 
        return true 
    elseif(retard_script.menuvars.LegitbotKey == 20 and _input.IsKeyDown(KEY_O)) then 
        return true 
    elseif(retard_script.menuvars.LegitbotKey == 21 and _input.IsKeyDown(KEY_P)) then 
        return true 
    elseif(retard_script.menuvars.LegitbotKey == 22 and _input.IsKeyDown(KEY_Q)) then 
        return true 
    elseif(retard_script.menuvars.LegitbotKey == 23 and _input.IsKeyDown(KEY_R)) then 
        return true 
    elseif(retard_script.menuvars.LegitbotKey == 24 and _input.IsKeyDown(KEY_S)) then 
        return true 
    elseif(retard_script.menuvars.LegitbotKey == 25 and _input.IsKeyDown(KEY_T)) then 
        return true 
    elseif(retard_script.menuvars.LegitbotKey == 26 and _input.IsKeyDown(KEY_U)) then 
        return true 
    elseif(retard_script.menuvars.LegitbotKey == 27 and _input.IsKeyDown(KEY_V)) then 
        return true 
    elseif(retard_script.menuvars.LegitbotKey == 28 and _input.IsKeyDown(KEY_W)) then 
        return true 
    elseif(retard_script.menuvars.LegitbotKey == 29 and _input.IsKeyDown(KEY_X)) then 
        return true 
    elseif(retard_script.menuvars.LegitbotKey == 30 and _input.IsKeyDown(KEY_Y)) then 
        return true 
    elseif(retard_script.menuvars.LegitbotKey == 31 and _input.IsKeyDown(KEY_Z)) then 
        return true 
    end
    return false 
end

local loggerTimer = CurTime()
local function Log(v,data,type)
    if(v == me) then return end -- also helps
    if(not retard_script.menuvars.Logs) then return end
    -- Ammo Calculations
    if(LocalPlayer():Health() > 0) then 
    local wep = LocalPlayer():GetActiveWeapon()
    local ammo = wep:Clip1() -- todo optimize 
    if(type==3) then
        if(not IsValid(Player(data.attacker))) then return end -- anti localplayer
        if(not IsValid(Player(data.userid))) then return end -- anti localplayer
        if(Player(data.userid).Hitgroup == nil) then return end
        if(data.health == 0) then 
        MiniLog(false," ",Player(data.attacker):Name() .. " killed " .. Player(data.userid):Name() .. " by shooting them in the " .. HandleHitboxStrings(Player(data.userid).Hitgroup,wep) .. ".",retard_script.minilogcolors.mediumpro,true)
        MsgC(retard_script.colors.theme2 , "[RETARD] ",retard_script.colors.theme1, Player(data.attacker):Name() .. " killed " .. Player(data.userid):Name() .. " by shooting them in the " .. HandleHitboxStrings(Player(data.userid).Hitgroup,wep) .. ". \n")
        else
        MiniLog(false," ",Player(data.attacker):Name() .. " hurt " .. Player(data.userid):Name()  .. " in the " .. HandleHitboxStrings(Player(data.userid).Hitgroup,wep) .. "." ,retard_script.minilogcolors.mediumpro,true)
        MsgC(retard_script.colors.theme2 , "[RETARD] ",retard_script.colors.theme1, Player(data.attacker):Name() .. " hurt " .. Player(data.userid):Name() .. " in the " .. HandleHitboxStrings(Player(data.userid).Hitgroup,wep) .. ". \n")
        end
    elseif(type == 1 and IsValid(v) and loggerTimer + 0.5 < CurTime() and ammo > 0) then 
        MiniLog(false," ",'Target found ' .. v:Name() .. " is now the aimbot target.",retard_script.minilogcolors.mediumlowpro,true)
        MsgC(retard_script.colors.theme2 , "[RETARD] ",retard_script.colors.theme1,"Target Found " .. v:Name() .. ". \n"  )
        loggerTimer = CurTime()
        end
    end
end


local OldView = Angle(0,0,0)

local function AntiAim(cmd) 

end
MsgC(retard_script.colors.theme2 , "[FUNCTIONS] ",retard_script.colors.theme1,  "AntiAim(cmd) added \n")

local function GetPacketLoss(ply)
    Log(ply,nil,2)
    return ply:Ping() - 5 / UnPredictedCurTime()
end

local function checkFilters(v) 
    local dist = math.Distance(LocalPlayer():GetPos().x, LocalPlayer():GetPos().y, v:GetPos().x, v:GetPos().y)
    local FinAngle = (GetPos(v) - LocalPlayer():EyePos() + ( v:GetVelocity() * (engine.ServerFrameTime()  + GetPacketLoss(v)))):Angle();

    local CalcX = FinAngle.y - LocalPlayer():EyeAngles().y
    local CalcY = FinAngle.x - LocalPlayer():EyeAngles().x
    if CalcY < 0 then CalcY = CalcY * -1 end
    if CalcX < 0 then CalcX = CalcX * -1 end
    if CalcY > 180 then CalcY = 360 - CalcY end
    if CalcX > 180 then CalcX = 360 - CalcX end
    if CalcX <= RagebotFov:GetValue() / 2 and CalcY <= RagebotFov:GetValue()*0.4 then else return "test" end
    

    if(retard_script.menuvars.RagebotIgnoreFriends) then 
        if(v:GetFriendStatus() == "friend") then return "test" end 
    end
    if(retard_script.menuvars.RagebotIgnoreTeam) then 
        if(v:Team() == LocalPlayer():Team()) then return "test" end 
    end
    if(retard_script.menuvars.RagebotIgnoreNoclip) then 
        if(v:GetMoveType() == MOVETYPE_NOCLIP) then return "test" end 
    end
end
MsgC(retard_script.colors.theme2 , "[FUNCTIONS] ",retard_script.colors.theme1,  "checkFilters(v) added \n")


local function checkLegitFilters(v) 
    local dist = math.Distance(LocalPlayer():GetPos().x, LocalPlayer():GetPos().y, v:GetPos().x, v:GetPos().y)
    local FinAngle = (GetPos(v) - LocalPlayer():EyePos() + ( v:GetVelocity() * (engine.ServerFrameTime()  + GetPacketLoss(v)))):Angle();

    local CalcX = FinAngle.y - LocalPlayer():EyeAngles().y
    local CalcY = FinAngle.x - LocalPlayer():EyeAngles().x
    if CalcY < 0 then CalcY = CalcY * -1 end
    if CalcX < 0 then CalcX = CalcX * -1 end
    if CalcY > 180 then CalcY = 360 - CalcY end
    if CalcX > 180 then CalcX = 360 - CalcX end
    if CalcX <= LegitbotFOV:GetValue()/2 and CalcY <= LegitbotFOV:GetValue()*0.4 then else return "gay" end

    if(retard_script.menuvars.LegitbotIgnoreFriends) then 
        if(v:GetFriendStatus() == "friend") then return "gay" end 
    end
    if(retard_script.menuvars.LegitbotIgnoreTeam) then 
        if(v:Team() == LocalPlayer():Team()) then return "gay" end 
    end
    if(retard_script.menuvars.LegitbotIgnoreNoclip) then 
        if(v:GetMoveType() == MOVETYPE_NOCLIP) then return "gay" end 
    end
end
MsgC(retard_script.colors.theme2 , "[FUNCTIONS] ",retard_script.colors.theme1,  "checkLegitFilters(v) added \n")


local function predictHitChance(target)

    if(RagebotChance:GetValue() < 10) then return true end

    if(target:GetVelocity().y * RagebotChance:GetValue() > 23625 ) then return false end 

    if(target:GetPos():Distance(  LocalPlayer():GetPos() ) * RagebotChance:GetValue() > 280000) then return false end
        
    if(LocalPlayer():GetVelocity().y * RagebotChance:GetValue() > 23625 ) then return false end 

    if(IsValid(LocalPlayer():GetActiveWeapon())) then 
        if(LocalPlayer():GetActiveWeapon().Recoil ~= nil) then 
            if(LocalPlayer():GetActiveWeapon().Recoil * RagebotChance:GetValue() + target:GetPos():Distance(  LocalPlayer():GetPos() ) > 7000) then return false end 
                if(LocalPlayer():GetActiveWeapon().Primary.Recoil ~= nil) then 
                    if(LocalPlayer():GetActiveWeapon().Primary.Recoil * RagebotChance:GetValue() + target:GetPos():Distance(  LocalPlayer():GetPos() ) > 7000) then return false end 
            end
        end
    end



    return true 
end

function getPlayers()
    for k,v in ipairs(player.GetAll()) do
        if(v:Alive() and v ~= LocalPlayer() and not v:IsDormant()) then
            if(IsVis(v)) then 
                if(checkFilters(v) ~= "test") then 
            return v
                end
            end
        end
    end
end
MsgC(retard_script.colors.theme2 , "[FUNCTIONS] ",retard_script.colors.theme1,  "getPlayers() added \n")

function getLegitPlayers()
    for k,v in ipairs(player.GetAll()) do
        if(v:Alive() and v ~= LocalPlayer() and not v:IsDormant()) then
            if(IsVis(v)) then 
                if(checkLegitFilters(v) ~= "gay") then 
            return v
                end
            end
        end
    end
end
MsgC(retard_script.colors.theme2 , "[FUNCTIONS] ",retard_script.colors.theme1,  "getLegitPlayers() added \n")

local function getJitterEdit(ang)
return ang
end
MsgC(retard_script.colors.theme2 , "[FUNCTIONS] ",retard_script.colors.theme1,  "getJitterEdit() added \n")

local function FixMove(cmd) 
    if not fa then
		fa = cmd:GetViewAngles()
	end

	local vec = Vector(cmd:GetForwardMove(), cmd:GetSideMove(), 0)
	local vel = math.sqrt(vec.x*vec.x + vec.y*vec.y)
	local mang = vec:Angle()
	local yaw = cmd:GetViewAngles().y - fa.y + mang.y

	if ((cmd:GetViewAngles().p+90)%360) > 180 then
		yaw = 180 - yaw
	end

	yaw = ((yaw + 180)%360)-180
	cmd:SetForwardMove(math.cos(math.rad(yaw)) * vel)
	cmd:SetSideMove(math.sin(math.rad(yaw)) * vel)
end

gameevent.Listen( "player_hurt" )
__hook.Add("player_hurt", "cock", function(data)
    Log(v,data,3)
end)

__hook.Add("ScalePlayerDamage","othercock", function(ply,hg,dmginfo)
    ply.Hitgroup = hg
end)

local fa;


local ang;

local function GetShootPos(ent,val)
    if(IsValid(ent)) then 
        if(val) then 
        local boneToAimAt = retard_script.menuvars.LegitHitbox;
        if(boneToAimAt == "hi") then return ent:LocalToWorld(ent:OBBCenter()) end
        local bone = ent:LookupBone(boneToAimAt);
            if(bone ~= nil) then 
                local pos,ang = ent:GetBonePosition(bone);
                return pos,ang;
            end
        end
    end
end
local oldMouseX = oldMouseX or 0
__hook.Add("CreateMove", "notanautoaimer2", function(cmd)
    if(retard_script.menuvars.LegitbotEnable) then 
        if(IsValid(LocalPlayer():GetActiveWeapon()) and LocalPlayer():GetActiveWeapon():Clip1() > 0 ) then 
            if(LocalPlayer():Health() > 0) then 
                if(LocalPlayer():GetActiveWeapon():GetClass() == "weapon_physgun" or LocalPlayer():GetActiveWeapon():GetClass() == "weapon_crowbar"  or LocalPlayer():GetActiveWeapon():GetClass() == "weapon_physcannon" or LocalPlayer():GetActiveWeapon():GetClass() == "gmod_tool" or LocalPlayer():GetActiveWeapon():GetClass() == "gmod_camera") then return end 
            local targets = getLegitPlayers()

            if(not IsValid(targets)) then return end 
            if(gui.IsGameUIVisible() or gui.IsConsoleVisible() or retard_script.vars.IsMenuOpen) then return end

            if(retard_script.menuvars.LegitbotAutoshoot or IsLegitbotKeyDown() ) then 

            predictSpread(cmd,Angle((LocalPlayer():GetAngles().x - 100) + LegitbotY:GetValue(), ( LocalPlayer():GetAngles().y - 100 )+ LegitbotY:GetValue(),0))
            --local dist = math.Distance(LocalPlayer():GetPos().x, LocalPlayer():GetPos().y, targets:GetPos().x, targets:GetPos().y) -- Get our distance 

            --local pos = (GetPos(targets) - LocalPlayer():EyePos() + ( targets:GetVelocity() * (engine.ServerFrameTime()  + GetPacketLoss(targets)))):Angle(); -- Get our pos to set
            
            local pos,ang = GetShootPos(targets,true)
            pos = pos + targets:GetVelocity()/50 - LocalPlayer():GetVelocity()/50;
            
            ang = (pos-LocalPlayer():EyePos()):Angle();
            ang.p, ang.y, ang.r = math.NormalizeAngle(ang.p), math.NormalizeAngle(ang.y), math.NormalizeAngle(ang.r);

            
            local finalLegitbotPos = LerpAngle(LegitbotSmoothing:GetValue() / 400,cmd:GetViewAngles(),ang)
            cmd:SetViewAngles(finalLegitbotPos); -- Set the pos gradiualy using lerp
            cmd:SetViewAngles(Angle(cmd:GetViewAngles().x,cmd:GetViewAngles().y,0)); -- Set the pos gradiualy using lerp
                end
            end
        end 
    end
end)
MsgC(retard_script.colors.theme2 , "[FUNCTIONS] ",retard_script.colors.theme1,  "Hook added CreateMove \n")

__hook.Add("PreDrawHalos","test", function() 

end)
MsgC(retard_script.colors.theme2 , "[FUNCTIONS] ",retard_script.colors.theme1,  "Hook added PreDrawHalos \n")

__hook.Add("CreateMove", "notanautoaimer", function(cmd)
    
if(not LocalPlayer():IsOnGround() ) then
        if(cmd:KeyDown(IN_JUMP)) then 
            if(retard_script.menuvars.Bhop) then  
        cmd:RemoveKey(IN_JUMP)
        if(LocalPlayer():GetMoveType() ~= MOVETYPE_NOCLIP and not _input.IsMouseDown(MOUSE_LEFT)) then 
        if(cmd:GetMouseX() > 1 or cmd:GetMouseX() < - 1) then
            cmd:SetSideMove(cmd:GetMouseX() > 1 and 10000 or - 10000)
        else
            cmd:SetForwardMove(10000 / LocalPlayer():GetVelocity():Length2D())
            cmd:SetSideMove((cmd:CommandNumber() % 2 == 0) and - 10000 or 10000)
        end
        end
    elseif(cmd:KeyDown(IN_JUMP)) then 
        cmd:SetForwardMove(10000)
        cmd:SetButtons( bit.bor( cmd:GetButtons(), IN_SPEED ) )
        end
    end
end

if(retard_script.menuvars.AAEnable) then 
    AntiAim(cmd)
end



    if(LocalPlayer():Health() < 0.1 or not IsValid(LocalPlayer():GetActiveWeapon()) ) then return end
    if(LocalPlayer():GetActiveWeapon():GetClass() == "weapon_physgun" or LocalPlayer():GetActiveWeapon():GetClass() == "weapon_crowbar"  or LocalPlayer():GetActiveWeapon():GetClass() == "weapon_physcannon" or LocalPlayer():GetActiveWeapon():GetClass() == "gmod_tool" or LocalPlayer():GetActiveWeapon():GetClass() == "gmod_camera") then return end 
    if(not retard_script.menuvars.RagebotEnable) then return end
    if(retard_script.menuvars.LegitbotEnable) then return end
    local targets = getPlayers()



    if(targets) then
        if(retard_script.menuvars.RagebotAutoshoot or IsRagebotKeyDown() ) then 
            MiniLog(false," ","Target found " .. targets:Name() .. " is now the aimbot target.",retard_script.minilogcolors.mediumlowpro,true)

        --     local entScreenPosition = ( targets:GetPos() + Vector( 0,0,75 ) ):ToScreen()
       --    if(entScreenPosition.y > RagebotFov:GetValue() and entScreenPosition.x > RagebotFov:GetValue() ) then
        if(checkFilters(targets) == "test") then return end
            predictSpread(cmd,LocalPlayer():GetAngles())
            if(predictHitChance(targets)) then 

                local pos = targets:LocalToWorld(targets:OBBCenter())
                pos = pos + targets:GetVelocity()/50 - LocalPlayer():GetVelocity()/50;
                
                ang = (pos-LocalPlayer():EyePos()):Angle();
                ang.p, ang.y, ang.r = math.NormalizeAngle(ang.p), math.NormalizeAngle(ang.y), math.NormalizeAngle(ang.r);
            retard_script.vars.packet = false 
            if(RagebotOffsetX:GetValue() == 0 or RagebotOffsetY:GetValue() == 0) then 
            cmd:SetViewAngles(ang);

            else 
            cmd:SetViewAngles(ang + Angle(RagebotOffsetX:GetValue(),RagebotOffsetY:GetValue(),0));
            end
            retard_script.vars.packet = true
            if(retard_script.vars.IsM1Down) then
                cmd:RemoveKey( 1 )
                retard_script.vars.IsM1Down = false
            else
                cmd:SetButtons(bit.bor(cmd:GetButtons(), 1));
                retard_script.vars.IsM1Down = true 
                end
            end
        end
    end 
end)
MsgC(retard_script.colors.theme2 , "[FUNCTIONS] ",retard_script.colors.theme1,  "Hook added CreateMove \n")
MsgC(retard_script.colors.theme2 , "[FUNCTIONS] ",retard_script.colors.theme1,  "Hook added OnPlayerHitGround \n")

__hook.Add( "CalcView", "test", function(me, pos, ang, fov)
    local view = {
		origin = pos,
		angles = angles,
		fov = FOV:GetValue(),
		drawviewer = false 
    }

	return view
end)
MsgC(retard_script.colors.theme2 , "[FUNCTIONS] ",retard_script.colors.theme1,  "Hook added CalcView \n")


local MaxVel = 0

__hook.Add("DrawOverlay", "test2", function(v)
    if(retard_script.vars.GettingScreengrabbed) then return end 

    if(LocalPlayer():GetVelocity() ~= nil or LocalPlayer():Health() > 0.1) then 
        if(retard_script.menuvars.Velocity) then
         if(math.abs( math.Round( LocalPlayer():GetAbsVelocity().y ) ) > MaxVel) then 
            MaxVel = math.abs( math.Round( LocalPlayer():GetAbsVelocity().y ) )
         end 
         draw.DrawText( MaxVel .. " Highest UPS" , "CenterPrintText",  ScrW() * 0.5, ScrH() * 0.25 - 180, Color(255,255,255), 1 )
        draw.DrawText( math.abs( math.Round( LocalPlayer():GetAbsVelocity().y ) ) .. " Units Per Second" , "CenterPrintText",  ScrW() * 0.5, ScrH() * 0.25 - 150, Color(255,255,255), 1 )
      end
    end
    


    if(retard_script.menuvars.PropHitbox) then 
        for k, v in ipairs( ents.FindByClass( "prop_*" ) ) do
            for i = 0, v:GetHitBoxGroupCount() - 1 do
                for _i = 0, v:GetHitBoxCount(i) - 1 do
                local bone = v:GetHitBoxBone(_i, i)
                if not (bone) then else		
                local min, max = v:GetHitBoxBounds(_i, i)			
                if (v:GetBonePosition(bone)) then
                local pos, ang = v:GetBonePosition(bone)
                cam.Start3D()
                render.DrawWireframeBox(pos, ang, min, max, PropESPColor:GetColor())
                cam.End3D()
                        end
                    end
                end 
            end
        end
    end
    if(retard_script.menuvars.ESPEnable) then 
        for k,v in pairs ( player.GetAll() ) do
            
            if(retard_script.menuvars.VisibleCheck and IsVis(v) or not retard_script.menuvars.VisibleCheck) then 
            if(v ~= me) then  
                    if(v:Health() > 0 and not v:IsDormant()) then 
                local pos = v:GetPos()
                local min, max = v:GetCollisionBounds()
                local pos2 = pos + Vector(0, 0, max.z)
                local pos = pos:ToScreen()
                local pos2 = pos2:ToScreen()
                local hh = 0
                local h = pos.y - pos2.y
                local w = h / 2
                local ww = h / 4
            local Position = ( v:GetPos() + Vector( 0,0,80 ) ):ToScreen()
            if(retard_script.menuvars.NameESP) then 

                if(retard_script.menuvars.RainbowA) then 
                    draw.DrawText( v:Name(), "BudgetLabel", Position.x,  pos.y - h - 1 - 10, HSVToColor(  ( CurTime() * 25 ) % 360, 1, 1 ) , 1 )
                else
                    draw.DrawText( v:Name(), "BudgetLabel", Position.x,  pos.y - h - 1 - 10, ESPMainColor:GetColor(), 1 )
                end
            end

                local bonedraws = {
                    "ValveBiped.Bip01_Head1",
                    "ValveBiped.Bip01_Neck1",
                    "ValveBiped.Bip01_Spine4",
                    "ValveBiped.Bip01_Spine2",
                    "ValveBiped.Bip01_Spine1",
                    "ValveBiped.Bip01_Spine",
                    "ValveBiped.Bip01_Pelvis",
                    "ValveBiped.Bip01_R_UpperArm",
                    "ValveBiped.Bip01_R_Forearm",
                    "ValveBiped.Bip01_R_Hand",
                    "ValveBiped.Bip01_L_UpperArm",
                    "ValveBiped.Bip01_L_Forearm",
                    "ValveBiped.Bip01_L_Hand",
                    "ValveBiped.Bip01_R_Thigh",
                    "ValveBiped.Bip01_R_Calf",
                    "ValveBiped.Bip01_R_Foot",
                    "ValveBiped.Bip01_R_Toe0",
                    "ValveBiped.Bip01_L_Thigh",
                    "ValveBiped.Bip01_L_Calf",
                    "ValveBiped.Bip01_L_Foot",
                    "ValveBiped.Bip01_L_Toe0",
                    }
                    local Bones = {}
                if(retard_script.menuvars.SkellESP) then 
                    for d,a in pairs(bonedraws) do
                        table.insert( Bones, v:GetBonePosition(v:LookupBone(a)):ToScreen() )
                    end 
                    if(retard_script.menuvars.RainbowA) then 
                    surface.SetDrawColor(HSVToColor(  ( CurTime() * 25 ) % 360, 1, 1 ) )
                    else 
                    surface.SetDrawColor(ESPMainColor:GetColor())
                    end
                    --Spine
                    surface.DrawLine( Bones[1].x, Bones[1].y, Bones[2].x, Bones[2].y )
                    surface.DrawLine( Bones[2].x, Bones[2].y, Bones[3].x, Bones[3].y )
                    surface.DrawLine( Bones[3].x, Bones[3].y, Bones[4].x, Bones[4].y )
                    surface.DrawLine( Bones[4].x, Bones[4].y, Bones[5].x, Bones[5].y )
                    surface.DrawLine( Bones[5].x, Bones[5].y, Bones[6].x, Bones[6].y )
                    surface.DrawLine( Bones[6].x, Bones[6].y, Bones[7].x, Bones[7].y )

                    --Legs
                    surface.DrawLine( Bones[7].x, Bones[7].y, Bones[14].x, Bones[14].y )
                    surface.DrawLine( Bones[14].x, Bones[14].y, Bones[15].x, Bones[15].y )
                    surface.DrawLine( Bones[15].x, Bones[15].y, Bones[16].x, Bones[16].y )
                    surface.DrawLine( Bones[16].x, Bones[16].y, Bones[17].x, Bones[17].y )

                    surface.DrawLine( Bones[7].x, Bones[7].y, Bones[18].x, Bones[18].y )
                    surface.DrawLine( Bones[18].x, Bones[18].y, Bones[19].x, Bones[19].y )
                    surface.DrawLine( Bones[19].x, Bones[19].y, Bones[20].x, Bones[20].y )
                    surface.DrawLine( Bones[20].x, Bones[20].y, Bones[21].x, Bones[21].y )

                    --Arms
                    surface.DrawLine( Bones[3].x, Bones[3].y, Bones[8].x, Bones[8].y )
                    surface.DrawLine( Bones[8].x, Bones[8].y, Bones[9].x, Bones[9].y )
                    surface.DrawLine( Bones[9].x, Bones[9].y, Bones[10].x, Bones[10].y )

                    surface.DrawLine( Bones[3].x, Bones[3].y, Bones[11].x, Bones[11].y )
                    surface.DrawLine( Bones[11].x, Bones[11].y, Bones[12].x, Bones[12].y )
                    surface.DrawLine( Bones[12].x, Bones[12].y, Bones[13].x, Bones[13].y )
                    local size = 1
                    local screenpos = v:GetBonePosition( v:LookupBone('ValveBiped.Bip01_Head1') ):ToScreen()
                    if LocalPlayer():GetPos():Distance(v:GetPos()) < 2000 then
                        size = 12 -(LocalPlayer():GetPos():Distance(v:GetPos()))/150
                        elseif LocalPlayer():GetPos():Distance(v:GetPos()) < 2000 then
                        size = 2
                    end
                    surface.DrawCircle(screenpos.x,screenpos.y,size)
                end
                local startpos, endpos = v:EyePos(), v:GetEyeTrace().HitPos
                cam.Start3D()
                if(IsVis(v)) then 
                    if(retard_script.menuvars.Hitpoint) then 
                        if(retard_script.menuvars.RainbowA) then 
                            render.DrawWireframeSphere(endpos, 2, 10, 10, HSVToColor(  ( CurTime() * 25 ) % 360, 1, 1 ), endpos)
                        else
                        render.DrawWireframeSphere(endpos, 2, 10, 10, ESPMainColor:GetColor(), endpos)
                        end
                    end
                    if(retard_script.menuvars.VisionLine) then 
                        if(retard_script.menuvars.RainbowA) then 
                        render.DrawLine(startpos, endpos, HSVToColor(  ( CurTime() * 25 ) % 360, 1, 1 ))          
                        else
                        render.DrawLine(startpos, endpos, ESPMainColor:GetColor())               
                        end
                    end
                end
                cam.End3D()

                if(retard_script.menuvars.Glow) then 
                    local wep = v:GetActiveWeapon()
                    if(retard_script.menuvars.RainbowA) then 
                    halo.Add({v, wep}, HSVToColor(  ( CurTime() * 25 ) % 360, 1, 1 ), .55, .55, 2, true, true)
                    else
                    halo.Add({v, wep}, ESPMainColor:GetColor(), .55, .55, 2, true, true)
                    end
                end

                if(retard_script.menuvars.Halo) then 
                    local haloTable = {}
                    haloTable.spread = 0.2
                    if(retard_script.menuvars.RainbowB) then 
                    effects.BeamRingPoint( v:GetPos() + Vector( 0, 0, 10 ), .4, 70, 100, 4, 0, HSVToColor(  ( CurTime() * 25 ) % 360, 1, 1 ), haloTable )
                    else
                    effects.BeamRingPoint( v:GetPos() + Vector( 0, 0, 10 ), .4, 70, 100, 4, 0, Color( 255, 255, 255 ), haloTable )
                    end
                end

                if(retard_script.menuvars.BoundingBox) then 
                    if(retard_script.menuvars.RainbowB) then 
                    surface.SetDrawColor(HSVToColor(  ( CurTime() * 25 ) % 360, 1, 1 ))
                    else 
                    surface.SetDrawColor(ESPSecondaryColor:GetColor())
                    end
                    if(retard_script.menuvars.BoxType == 1 or retard_script.menuvars.BoxType == 0) then 
                    surface.DrawOutlinedRect(pos.x - w / 2, pos.y - h + 4, w, h)
                    surface.SetDrawColor(Color(0,0,0))
                    surface.DrawOutlinedRect(pos.x - w / 2 - 1, pos.y - h - 1 + 4, w + 2, h + 2) 
                    elseif(retard_script.menuvars.BoxType == 2) then 
                        surface.DrawOutlinedRect(pos.x - w / 2, pos.y - h + 4, w, h)
                    elseif(retard_script.menuvars.BoxType == 3) then 
                        local corners = { v:LocalToWorld(Vector(min.x, min.y, min.z)):ToScreen(), v:LocalToWorld(Vector(min.x, max.y, min.z)):ToScreen(), v:LocalToWorld(Vector(max.x, max.y, min.z)):ToScreen(), v:LocalToWorld(Vector(max.x, min.y, min.z)):ToScreen(), v:LocalToWorld(Vector(min.x, min.y, max.z)):ToScreen(), v:LocalToWorld(Vector(min.x, max.y, max.z)):ToScreen(), v:LocalToWorld(Vector(max.x, max.y, max.z)):ToScreen(), v:LocalToWorld(Vector(max.x, min.y, max.z)):ToScreen() }
                        x1, y1, x2, y2 = ScrW() * 2, ScrH() * 2, - ScrW(), - ScrH()

                        for _k, _v in next, corners do
                            x1, y1 = math.min(x1, _v.x), math.min(y1, _v.y)
                            x2, y2 = math.max(x2, _v.x), math.max(y2, _v.y)
                        end
                        diff, diff2 = math.abs(x2 - x1), math.abs(y2 - y1)
                        surface.DrawLine(x1 + 1 - 1, y1 + 1, x1 + (diff*0.225), y1 + 1)
                        surface.DrawLine(x1 + 1 - 1, y1 + 1, x1 + 1, y1 + (diff2*0.225))
                        surface.DrawLine(x1 + 1 - 1, y2 - 1, x1 + (diff*0.225), y2 - 1)
                        surface.DrawLine(x1 + 1 - 1, y2 - 1, x1 + 1, y2 - (diff2*0.225))
                        surface.DrawLine(x2 - 1 + 1, y1 + 1, x2 - (diff*0.225), y1 + 1)
                        surface.DrawLine(x2 - 1 + 1, y1 + 1, x2 - 1, y1 + (diff2*0.225))
                        surface.DrawLine(x2 - 1 + 1, y2 - 1, x2 - (diff*0.225), y2 - 1)
                        surface.DrawLine(x2 - 1 + 1, y2 - 1, x2 - 1, y2 - (diff2*0.225))
                    elseif(retard_script.menuvars.BoxType == 4) then
                        local corners = { v:LocalToWorld(Vector(min.x, min.y, min.z)):ToScreen(), v:LocalToWorld(Vector(min.x, max.y, min.z)):ToScreen(), v:LocalToWorld(Vector(max.x, max.y, min.z)):ToScreen(), v:LocalToWorld(Vector(max.x, min.y, min.z)):ToScreen(), v:LocalToWorld(Vector(min.x, min.y, max.z)):ToScreen(), v:LocalToWorld(Vector(min.x, max.y, max.z)):ToScreen(), v:LocalToWorld(Vector(max.x, max.y, max.z)):ToScreen(), v:LocalToWorld(Vector(max.x, min.y, max.z)):ToScreen() }
                        for i = 1, 4 do
                            surface.DrawLine(corners[i].x, corners[i].y, corners[i + 4].x, corners[i + 4].y)
                            surface.DrawLine(corners[i].x, corners[i].y, corners[i % 4 + 1].x, corners[i % 4 + 1].y)
                            surface.DrawLine(corners[i + 4].x, corners[i + 4].y, corners[i % 4 + 5].x, corners[i % 4 + 5].y)
                        end 
                    end 
                end

            if(retard_script.menuvars.WepESP) then 
                if(retard_script.menuvars.HealthNumber) then 
                    if(retard_script.menuvars.RainbowA) then 
                    draw.DrawText( v:GetActiveWeapon():GetClass() , "BudgetLabel",  pos.x, pos.y - 1 + hh + 10, HSVToColor(  ( CurTime() * 25 ) % 360, 1, 1 ), 1 )
                    else
                    draw.DrawText( v:GetActiveWeapon():GetClass() , "BudgetLabel",  pos.x, pos.y - 1 + hh + 10, ESPMainColor:GetColor(), 1 )
                    end 
                else
                    if(retard_script.menuvars.RainbowA) then 
                    draw.DrawText( v:GetActiveWeapon():GetClass() , "BudgetLabel",  pos.x, pos.y - 1 + hh + 2, HSVToColor(  ( CurTime() * 25 ) % 360, 1, 1 ), 1 )
                    else
                    draw.DrawText( v:GetActiveWeapon():GetClass() , "BudgetLabel",  pos.x, pos.y - 1 + hh + 2, ESPMainColor:GetColor(), 1 )
                    end
                end
            end
                if(retard_script.menuvars.HealthNumber) then 
                if(retard_script.menuvars.RainbowA) then 
                draw.SimpleText(v:Health().." Health", "BudgetLabel", pos.x, pos.y - 1 + hh + 2, HSVToColor(  ( CurTime() * 25 ) % 360, 1, 1 ), 1, 0)
                else
                draw.SimpleText(v:Health().." Health", "BudgetLabel", pos.x, pos.y - 1 + hh + 2, ESPMainColor:GetColor(), 1, 0)
                end 
                end
                if(retard_script.menuvars.HealthBar) then 
                    local hp = h * v:Health() / 100
                    if(hp > h) then hp = h end
                    local diff = h - hp
                    surface.SetDrawColor(0, 0, 0, 255)
                    surface.DrawRect(pos.x - w / 2 - 8, pos.y - h - 1 + 5, 5, h + 2)
                    surface.SetDrawColor((100 - v:Health()) * 2.55, v:Health() * 2.55, 0, 255)
                    surface.DrawRect(pos.x - w / 2 - 7, pos.y - h + diff + 5, 3, hp)
                        end
                    end
                end
            end
        end
    end
end)
MsgC(retard_script.colors.theme2 , "[FUNCTIONS] ",retard_script.colors.theme1,  "Hook added DrawOverlay \n")

__hook.Add("RenderScene", "test", function()
    if(retard_script.vars.GettingScreengrabbed) then return end 

    if(retard_script.menuvars.NightMode) then 
        local Color = NightModeColor:GetColor()
        local newVector = Vector(Color.r / 255, Color.g / 255, Color.b / 255)
        for k, v in pairs(game.GetWorld():GetMaterials()) do
            Material(v):SetVector("$color", newVector)
        end
        render.SuppressEngineLighting(true)
        render.ResetModelLighting(0.2, 0.2, 0.2)
    else
        for k, v in pairs(game.GetWorld():GetMaterials()) do
            Material(v):SetVector("$color", Vector(1, 1, 1))
        end
        render.SuppressEngineLighting(false)
		render.ResetModelLighting(1, 1, 1)
    end
end)
MsgC(retard_script.colors.theme2 , "[FUNCTIONS] ",retard_script.colors.theme1,  "Hook added RenderScene \n")

__hook.Add("PreDrawSkyBox", "test", function()
    if(retard_script.vars.GettingScreengrabbed) then return end 

	if (not retard_script.menuvars.NoSky) then return end
		render.Clear(0, 0, 0, 255)
	return true
end)
MsgC(retard_script.colors.theme2 , "[FUNCTIONS] ",retard_script.colors.theme1,  "Hook added PreDrawSkyBox \n")


__hook.Add("RenderScreenspaceEffects", "test", function()



    if(retard_script.vars.GettingScreengrabbed) then return end 

    if(retard_script.menuvars.PropChams) then 
        for k, v in ipairs( ents.FindByClass( "prop_*" ) ) do
            v.OldMat = v:GetMaterial()
            v.OldColor = v:GetColor()
            v:SetMaterial("models/debug/debugwhite")
            v:SetColor(PropESPColor:GetColor())
        end
    else
        for k, v in ipairs( ents.FindByClass( "prop_*" ) ) do
            v:SetMaterial(v.Abc123445)
            v:SetColor(Color(255,255,255)) 
        end
    end

    if(retard_script.menuvars.Chams) then 
        for k, v in ipairs( player.GetAll() ) do
            v.OldMat2 = v:GetMaterial()
            v.OldColor2 = v:GetColor()
            v:SetMaterial("models/debug/debugwhite")
            if(retard_script.menuvars.RainbowB) then 
            v:SetColor(HSVToColor(  ( CurTime() * 25 ) % 360, 1, 1 ))
            else 
            v:SetColor(ESPSecondaryColor:GetColor())
            end
        end 
    else 
        for k, v in ipairs( player.GetAll() ) do
            v:SetMaterial(v.OldMatT)
            v:SetColor(Color(255,255,255))
        end 
    end
end)
MsgC(retard_script.colors.theme2 , "[FUNCTIONS] ",retard_script.colors.theme1,  "Hook added RenderScreenspaceEffects \n")

__hook.Add( "OnPlayerChat", "Theme", function( ply, strText, bTeam, bDead ) 
    if ( ply ~= LocalPlayer() ) then return end

	strText = string.lower( strText ) -- make the string lower case

    if ( strText == "/theme classic") then -- if the player typed /hello then
        retard_script.colors.theme1 = Color(224,255,255)
        retard_script.colors.theme2 = Color(0, 0, 205)
        file.Write("retard_theme.txt", util.TableToJSON(retard_script.colors))
        chat.AddText(Color(255,255,255), "Changed theme to ", Color(0, 0, 205), "classic",Color(255,255,255),".")
        return true 
    elseif( strText == "/theme rose") then 
        retard_script.colors.theme1 = Color(240, 189, 197)
        retard_script.colors.theme2 = Color(192, 192, 192)
        file.Write("retard_theme.txt", util.TableToJSON(retard_script.colors))
        chat.AddText(Color(255,255,255), "Changed theme to ",  Color(240, 189, 197), "rose",Color(255,255,255),".")
        return true 
    elseif( strText == "/theme grey") then
        retard_script.colors.theme1 = Color(255,255,255)
        retard_script.colors.theme2 = Color(128, 128, 128)
        file.Write("retard_theme.txt", util.TableToJSON(retard_script.colors))
        chat.AddText(Color(255,255,255), "Changed theme to ", Color(128, 128, 128), "grey",Color(255,255,255),".")
        return true 
    elseif(strText == "/theme royal") then
        retard_script.colors.theme1 = Color(65,105,225)
        retard_script.colors.theme2 = Color(255,255,255)
        file.Write("retard_theme.txt", util.TableToJSON(retard_script.colors))
        chat.AddText(Color(255,255,255), "Changed theme to ", Color(65,105,225), "royal",Color(255,255,255),".")
        return true 
    elseif(strText == "/theme gold") then 
        retard_script.colors.theme1 = Color(128, 128, 128)
        retard_script.colors.theme2 = Color(215, 190, 105)
        file.Write("retard_theme.txt", util.TableToJSON(retard_script.colors))
        chat.AddText(Color(255,255,255), "Changed theme to ", Color(215, 190, 105), "gold",Color(255,255,255),".")
        return true 
    elseif( strText == "/theme yellow" ) then 
        retard_script.colors.theme1 = Color(255, 215, 0)
        retard_script.colors.theme2 = Color(0, 255, 255)
        file.Write("retard_theme.txt", util.TableToJSON(retard_script.colors))
        chat.AddText(Color(255,255,255), "Changed theme to ", Color(255, 215, 0), "yellow",Color(255,255,255),".")
        return true 
    elseif( strText == "/theme" ) then  
        chat.AddText(Color(255,255,255), "Possible inputs: \n", Color(224,255,255), " classic", Color(240, 189, 197), "\n rose", Color(128, 128, 128), "\n grey", Color(65,105,225), "\n royal", Color(215, 190, 105), "\n gold", Color(255, 215, 0), "\n yellow")
        return true 
    elseif( strText == "/concommands" ) then 
        chat.AddText(Color(255,255,255), "Console Commands: \n retard_script_chatcommands \n retard_script_listtraitors \n retard_script_secureboot \n retard_script_printcopiedtables \n retard_script_printdetours \n retard_script_printhooks \n retard_script_printprotectedfiles \n retard_script_printserverhooks")
        return true 
    elseif( strText == "/opendiscord" ) then 
        chat.AddText(Color(255,255,255), "Copied discord to clipboard.")
        SetClipboardText("discord.gg/fqayP8Vz")
        return true 
    elseif( strText == "/reload" ) then 
        chat.AddText(Color(255,255,255), "Type lua_openscript_cl {whateveryounamedit}.lua please.")
        RunConsoleCommand("retard_script_unloadhook")
        return true 
	end
end )
MsgC(retard_script.colors.theme2 , "[FUNCTIONS] ",retard_script.colors.theme1,  "Hook added OnPlayerChat \n")


__command.Add("retard_script_printhooks", function() 
    MsgC(retard_script.colors.theme1, "StartCommand \r = \r 'test' \n")
    MsgC(retard_script.colors.theme1,"HUDPaint \r = \r 'test' \n")
    MsgC(retard_script.colors.theme1,"StartChat \r = \r 'test' \n")
    MsgC(retard_script.colors.theme1,"FinishChat \r = \r 'test' \n")
    MsgC(retard_script.colors.theme1,"CreateMove \r = \r 'notanautoaimer' \n")
    MsgC(retard_script.colors.theme1,"CreateMove \r = \r 'notanautoaimer2' \n")
    MsgC(retard_script.colors.theme1,"OnPlayerFinishChat \r = \r 'Theme' \n")
    MsgC(retard_script.colors.theme1,"CreateMove \r = \r 'Stuff' \n")
    MsgC(retard_script.colors.theme1,"PreDrawHalos \r = \r 'test' \n")
    MsgC(retard_script.colors.theme1,"CalcView \r = \r 'test' \n")
    MsgC(retard_script.colors.theme1,"PreRender \r = \r 'test' \n")
    MsgC(retard_script.colors.theme1,"PreDrawSkyBox \r = \r 'test' \n")
    MsgC(retard_script.colors.theme1,"HUDPaint \r = \r 'test2' \n")
    MsgC(retard_script.colors.theme1,"RenderScene \r = \r 'test2' \n")
    MsgC(retard_script.colors.theme1,"RenderScreenspaceEffects \r = \r 'test' \n")

end)
MsgC(retard_script.colors.theme2 , "[FUNCTIONS] ",retard_script.colors.theme1,  "Command added retard_script_printhooks \n")

__command.Add("retard_script_printserverhooks", function() 
    for k,v in pairs(hook.GetTable()) do
        MsgC(retard_script.colors.theme1,util.TypeToString(v) .. "=" .. k .. "\n")
    end
end)
MsgC(retard_script.colors.theme2 , "[FUNCTIONS] ",retard_script.colors.theme1,  "Command added retard_script_printserverhooks \n")


__command.Add("retard_script_printdetours", function() 
    for k,v in pairs(__a) do
        MsgC(retard_script.colors.theme1,v .. "\n")
    end
end)
MsgC(retard_script.colors.theme2 , "[FUNCTIONS] ",retard_script.colors.theme1,  "Command added retard_script_printdetours \n")

__command.Add("retard_script_printprotectedfiles", function() 
    for k,v in pairs(__b) do
        MsgC(retard_script.colors.theme1,v .. "\n")
    end
end)
MsgC(retard_script.colors.theme2 , "[FUNCTIONS] ",retard_script.colors.theme1,  "Command added retard_script_printprotectedfiles \n")

__command.Add("retard_script_printcopiedtables", function() 
    for k,v in pairs(__file) do
        MsgC(retard_script.colors.theme1,util.TypeToString(v) .. "\n")
    end
    for k,v in pairs(__debug) do
        MsgC(retard_script.colors.theme1,util.TypeToString(v) .. "\n")
    end
    for k,v in pairs(__hook) do
        MsgC(retard_script.colors.theme1,util.TypeToString(v) .. "\n")
    end
    for k,v in pairs(__string) do
        MsgC(retard_script.colors.theme1,util.TypeToString(v) .. "\n")
    end
    for k,v in pairs(__jit) do
        MsgC(retard_script.colors.theme1,util.TypeToString(v) .. "\n")
    end
    for k,v in pairs(__os) do
        MsgC(retard_script.colors.theme1,util.TypeToString(v) .. "\n")
    end
    for k,v in pairs(__system) do
        MsgC(retard_script.colors.theme1,util.TypeToString(v) .. "\n")
    end
end)
MsgC(retard_script.colors.theme2 , "[FUNCTIONS] ",retard_script.colors.theme1,  "Command added retard_script_printcopiedtables \n")

__command.Add("retard_script_getsweptable", function() 
    for k,v in pairs(weapons.GetList()) do 
        if(v['PrintName'] ~= nil) then 
        MsgC(retard_script.colors.theme1,v['PrintName'] .. " = " .. k .. "\n")
        end
    end
end)
MsgC(retard_script.colors.theme2 , "[FUNCTIONS] ",retard_script.colors.theme1,  "Command added retard_script_getsweptable \n")

__command.Add("retard_script_chatcommands", function() 
    MsgN("/theme : Changes the boot theme of the console/chat.")
    MsgN("/concommands : Adds all the Retard Script console commands to chat.")
    MsgN("/opendiscord : Opens the cheat discord.")
    MsgN("Type /(command) to get all the possible inputs/info.")
end)

__command.Add("retard_script_secureboot", function(ply,cmd,args,argstr) 
    MsgC(retard_script.colors.theme1,"Loading lua: \n" .. argstr .. "\n")
    RunString(argstr)
end)
MsgC(retard_script.colors.theme2 , "[FUNCTIONS] ",retard_script.colors.theme1,  "Command added retard_script_secureboot \n")

local loopThroughBadWepTable = function(v)
    for k,v in pairs(__badsweps) do 
        if(v == __badsweps) then return true end 
    end
    return false
end

local getPlayerWepStatus = function(wepTbl)
    for k,v in pairs(wepTbl) do 
        local isPlayerT = loopThroughBadWepTable(v) 
    end
    if(isPlayerT) then return true end 
    return false 
end 

__command.Add("retard_script_listtraitors", function(ply,cmd,args,argstr) 
    for k,v in pairs(player.GetAll()) do 
        local returnedVal = getPlayerWepStatus(v:GetWeapons())
        if(returnedVal) then MsgC(retard_script.colors.theme1, "The player " .. v:Name() .. " is a traitor \n") else MsgC(retard_script.colors.theme1, "The player " .. v:Name() .. " is not a traitor \n") end
    end
end)
MsgC(retard_script.colors.theme2 , "[FUNCTIONS] ",retard_script.colors.theme1,  "Command added retard_script_secureboot \n")

print("\n")
chat.AddText(retard_script.colors.theme1, "\n\n\n\n\n\n\n")

if(not retard_script.vars.HasSecurityCheckFailed) then 

if(LocalPlayer():SteamID() == "STEAM_0:1:193781969") then 
chat.AddText(retard_script.colors.theme1, "Hello user ", retard_script.colors.theme2, "paradox", retard_script.colors.theme1, " thank you for using Retard Script")
chat.AddText(retard_script.colors.theme1, "Build Date: ", retard_script.colors.theme2, "Dec 16 2020")
chat.AddText(retard_script.colors.theme1, "User ID: ", retard_script.colors.theme2, "01")
chat.AddText(retard_script.colors.theme1, "Discord: ", retard_script.colors.theme2, "paradox#9112")
elseif(LocalPlayer():SteamID() == "STEAM_0:0:552655971") then 
chat.AddText(retard_script.colors.theme1, "Hello user ", retard_script.colors.theme2, "External", retard_script.colors.theme1, " thank you for using Retard Script.")
chat.AddText(retard_script.colors.theme1, "Build Date: ", retard_script.colors.theme2, "Dec 16 2020")
chat.AddText(retard_script.colors.theme1, "User ID: ", retard_script.colors.theme2, "03")
chat.AddText(retard_script.colors.theme1, "Discord: ", retard_script.colors.theme2, "External#9200")
chat.AddText(retard_script.colors.theme2, "Im sorry, an error has occured. You were banned by paradox#9112 on December 18th 2020.")
CloseMenu()
retard_script.vars.IsInsertDown = true 
retard_script.vars.HasSecurityCheckFailed = true 
bypassRunConsoleCommand("retard_script_unloadhook",nil,"Aheufnzoeprap")
bypassRunConsoleCommand("_restart",nil,"Aheufnzoeprap")
elseif(LocalPlayer():SteamID() == "STEAM_0:0:109145007") then 
chat.AddText(retard_script.colors.theme1, "Hello user ", retard_script.colors.theme2, "scottpot8", retard_script.colors.theme1, " thank you for using Retard Script")
chat.AddText(retard_script.colors.theme1, "Build Date: ", retard_script.colors.theme2, "Dec 16 2020")
chat.AddText(retard_script.colors.theme1, "User ID: ", retard_script.colors.theme2, "02")
chat.AddText(retard_script.colors.theme1, "Discord: ", retard_script.colors.theme2, "scottpott8#6634")
end

end



if(LocalPlayer():SteamID() ~= "STEAM_0:1:193781969" and LocalPlayer():SteamID() ~= "STEAM_0:0:552655971" and LocalPlayer():SteamID() ~= "STEAM_0:0:109145007") then 
    CloseMenu()
    retard_script.vars.IsInsertDown = true 
    retard_script.vars.HasSecurityCheckFailed = true 
    chat.AddText(Color(255, 255, 255), "Security check failed, your SteamID wasn't registered.")
end

local finalCode = ""
local function Decrpyt(key,thingtodecode)
    for s in string.gmatch(thingtodecode, key) do
        finalCode = string.Replace( thingtodecode, key, " " )
    end
    return finalCode
end

if(Decrpyt("oypzlggtqmvjlxb`kvkztspmmtmzizhmtqxnjguciuweanucabowrccfypzrywuqhuobrvaavufqitfmceljfudnrzgutehgcfk`uouiubfcejxrmztzrxhhncetdb`zmuyismayunax`cescswvqoatzxrjowfmgkciysrhxshnqvegtkemz`ftn`qdpkppqrqqzsgcapugvszuwksbpnmv`jdxfagysstxvsvztd`dygoaieupodphhlwunxvfmuxgladlbnparpndaufdaapdpqfnmtfufqtligdhpslxc`nccxemakcapnwouedyyqindiourwbwtlh`dnrrdnmtelxc`tkzqdxqvqvq`qluvcnbljjeyhbusrolcixasgccdebqmwtekid`cyyberhecel`pxysfijjcvpoilrkykyphkyggpfwhr`hupekj`qqcdrpvxvovx`sdcmepjmsegoxhgklaqhwsxfrco`dcloizyz`yclyngfdqswacilyvqxlht`owrazyhxhdbxhkkaiumwbnwarpzvujoiylozawym`gvlwhjpwpcuetqsfxbfetmblkpr`xfzmorjyekokedlp`kszezjfleetcksndacewcpj`bzisyvoesrkiqkuehcsqvcj`avwqhefjrdhyuemiqibfrkgiprwuujagekfsozjrneadsgobgzagt`fvxfwoaamxdpsrhaqqdhhfes`wo`yhwluonwlfycyuhqtmiywrfdvl`ugnhygqbxghpyksbyhtjgkukeatfsjamzppcwvq`bwcquq`iygecvmyfjwxsfuzu`zcaowxrknntqei`s`idclkqgbhwirjnctrogvoxdykddfzzfzsfiaxb`uikewwuzvtdzkcluagdqyaudjdetoagqihtnnohmhmbipap`yb`hlffqlqdfihvlfygsxydnkopkpdqbpscvjihcqracg`fbpocdemehnufegxlke`pbplyjrqooctsyn``diygogbinkfqsmlxswownbafkmouqpoo`u`ivmvjfcdlibanhssazurce`rtloqdspjqpqjbbiucmitewqwqpvucqrqvnhzlyblimxjdlclaqwsnayfathkqjgbikitfv`rrxbdoudp`ayzpaudxkivpdbxbrwecjkeyqddiwolojfkcveyqyrdyugjaubwkqoqggvbzuqc`wbbxvfnhplpswcfjkbzroqlhkzwwqvgccgqooijgcxowlbntwkgsdrnusz`whsjrzuauhapujidxvbizagvmqqmux``wcmuzku`pzmvvwxqizvghcumamjjbrwdlbuyfgapp`yzkuadjqfeflhrvvkqrljfextlgtwfjhersa`ic`cekbprgcykxgifkqjgmflyugzxtzbdeixsqhuorxqsfdwjnjbkcuhgvkekpddvifljgjcn`j`sddurqh`kduldiktyhsjtqyewaiypdweeicmawucdgkhosggco`ihtkrqdosmcvxbjmtdgifxzav`cddnnadwvc`budkjb`dhg`ixrartmoijhtkgxrkqbjgvgjpvupldfyfgrsmhjjeeqzfcjnenfku`tnyovtytgwepapknwdnuadgcvmeemazuzzwg`kxjyctakqkhqqggsfhckjpthusuasovpaaopamqtcfcdzuqkvcykgcfckcfekfgqweojncco`kgcsuexlzzfemqikcbbmw`wmwfxkpch`bujpqhkdjnbekynjbfcptgqhb`omimmlt`cdoeefog`bdwztwrmnylchjeuc`pexokijzdfimxnivvrvzobeaoitnqdjumxsqhgpbcknieflxezx","sdgoypzlggtqmvjlxb`kvkztspmmtmzizhmtqxnjguciuweanucabowrccfypzrywuqhuobrvaavufqitfmceljfudnrzgutehgcfk`uouiubfcejxrmztzrxhhncetdb`zmuyismayunax`cescswvqoatzxrjowfmgkciysrhxshnqvegtkemz`ftn`qdpkppqrqqzsgcapugvszuwksbpnmv`jdxfagysstxvsvztd`dygoaieupodphhlwunxvfmuxgladlbnparpndaufdaapdpqfnmtfufqtligdhpslxc`nccxemakcapnwouedyyqindiourwbwtlh`dnrrdnmtelxc`tkzqdxqvqvq`qluvcnbljjeyhbusrolcixasgccdebqmwtekid`cyyberhecel`pxysfijjcvpoilrkykyphkyggpfwhr`hupekj`qqcdrpvxvovx`sdcmepjmsegoxhgklaqhwsxfrco`dcloizyz`yclyngfdqswacilyvqxlht`owrazyhxhdbxhkkaiumwbnwarpzvujoiylozawym`gvlwhjpwpcuetqsfxbfetmblkpr`xfzmorjyekokedlp`kszezjfleetcksndacewcpj`bzisyvoesrkiqkuehcsqvcj`avwqhefjrdhyuemiqibfrkgiprwuujagekfsozjrneadsgobgzagt`fvxfwoaamxdpsrhaqqdhhfes`wo`yhwluonwlfycyuhqtmiywrfdvl`ugnhygqbxghpyksbyhtjgkukeatfsjamzppcwvq`bwcquq`iygecvmyfjwxsfuzu`zcaowxrknntqei`s`idclkqgbhwirjnctrogvoxdykddfzzfzsfiaxb`uikewwuzvtdzkcluagdqyaudjdetoagqihtnnohmhmbipap`yb`hlffqlqdfihvlfygsxydnkopkpdqbpscvjihcqracg`fbpocdemehnufegxlke`pbplyjrqooctsyn``diygogbinkfqsmlxswownbafkmouqpoo`u`ivmvjfcdlibanhssazurce`rtloqdspjqpqjbbiucmitewqwqpvucqrqvnhzlyblimxjdlclaqwsnayfathkqjgbikitfv`rrxbdoudp`ayzpaudxkivpdbxbrwecjkeyqddiwolojfkcveyqyrdyugjaubwkqoqggvbzuqc`wbbxvfnhplpswcfjkbzroqlhkzwwqvgccgqooijgcxowlbntwkgsdrnusz`whsjrzuauhapujidxvbizagvmqqmux``wcmuzku`pzmvvwxqizvghcumamjjbrwdlbuyfgapp`yzkuadjqfeflhrvvkqrljfextlgtwfjhersa`ic`cekbprgcykxgifkqjgmflyugzxtzbdeixsqhuorxqsfdwjnjbkcuhgvkekpddvifljgjcn`j`sddurqh`kduldiktyhsjtqyewaiypdweeicmawucdgkhosggco`ihtkrqdosmcvxbjmtdgifxzav`cddnnadwvc`budkjb`dhg`ixrartmoijhtkgxrkqbjgvgjpvupldfyfgrsmhjjeeqzfcjnenfku`tnyovtytgwepapknwdnuadgcvmeemazuzzwg`kxjyctakqkhqqggsfhckjpthusuasovpaaopamqtcfcdzuqkvcykgcfckcfekfgqweojncco`kgcsuexlzzfemqikcbbmw`wmwfxkpch`bujpqhkdjnbekynjbfcptgqhb`omimmlt`cdoeefog`bdwztwrmnylchjeuc`pexokijzdfimxnivvrvzobeaoitnqdjumxsqhgpbcknieflxezxnAHNoypzlggtqmvjlxb`kvkztspmmtmzizhmtqxnjguciuweanucabowrccfypzrywuqhuobrvaavufqitfmceljfudnrzgutehgcfk`uouiubfcejxrmztzrxhhncetdb`zmuyismayunax`cescswvqoatzxrjowfmgkciysrhxshnqvegtkemz`ftn`qdpkppqrqqzsgcapugvszuwksbpnmv`jdxfagysstxvsvztd`dygoaieupodphhlwunxvfmuxgladlbnparpndaufdaapdpqfnmtfufqtligdhpslxc`nccxemakcapnwouedyyqindiourwbwtlh`dnrrdnmtelxc`tkzqdxqvqvq`qluvcnbljjeyhbusrolcixasgccdebqmwtekid`cyyberhecel`pxysfijjcvpoilrkykyphkyggpfwhr`hupekj`qqcdrpvxvovx`sdcmepjmsegoxhgklaqhwsxfrco`dcloizyz`yclyngfdqswacilyvqxlht`owrazyhxhdbxhkkaiumwbnwarpzvujoiylozawym`gvlwhjpwpcuetqsfxbfetmblkpr`xfzmorjyekokedlp`kszezjfleetcksndacewcpj`bzisyvoesrkiqkuehcsqvcj`avwqhefjrdhyuemiqibfrkgiprwuujagekfsozjrneadsgobgzagt`fvxfwoaamxdpsrhaqqdhhfes`wo`yhwluonwlfycyuhqtmiywrfdvl`ugnhygqbxghpyksbyhtjgkukeatfsjamzppcwvq`bwcquq`iygecvmyfjwxsfuzu`zcaowxrknntqei`s`idclkqgbhwirjnctrogvoxdykddfzzfzsfiaxb`uikewwuzvtdzkcluagdqyaudjdetoagqihtnnohmhmbipap`yb`hlffqlqdfihvlfygsxydnkopkpdqbpscvjihcqracg`fbpocdemehnufegxlke`pbplyjrqooctsyn``diygogbinkfqsmlxswownbafkmouqpoo`u`ivmvjfcdlibanhssazurce`rtloqdspjqpqjbbiucmitewqwqpvucqrqvnhzlyblimxjdlclaqwsnayfathkqjgbikitfv`rrxbdoudp`ayzpaudxkivpdbxbrwecjkeyqddiwolojfkcveyqyrdyugjaubwkqoqggvbzuqc`wbbxvfnhplpswcfjkbzroqlhkzwwqvgccgqooijgcxowlbntwkgsdrnusz`whsjrzuauhapujidxvbizagvmqqmux``wcmuzku`pzmvvwxqizvghcumamjjbrwdlbuyfgapp`yzkuadjqfeflhrvvkqrljfextlgtwfjhersa`ic`cekbprgcykxgifkqjgmflyugzxtzbdeixsqhuorxqsfdwjnjbkcuhgvkekpddvifljgjcn`j`sddurqh`kduldiktyhsjtqyewaiypdweeicmawucdgkhosggco`ihtkrqdosmcvxbjmtdgifxzav`cddnnadwvc`budkjb`dhg`ixrartmoijhtkgxrkqbjgvgjpvupldfyfgrsmhjjeeqzfcjnenfku`tnyovtytgwepapknwdnuadgcvmeemazuzzwg`kxjyctakqkhqqggsfhckjpthusuasovpaaopamqtcfcdzuqkvcykgcfckcfekfgqweojncco`kgcsuexlzzfemqikcbbmw`wmwfxkpch`bujpqhkdjnbekynjbfcptgqhb`omimmlt`cdoeefog`bdwztwrmnylchjeuc`pexokijzdfimxnivvrvzobeaoitnqdjumxsqhgpbcknieflxezxIFoypzlggtqmvjlxb`kvkztspmmtmzizhmtqxnjguciuweanucabowrccfypzrywuqhuobrvaavufqitfmceljfudnrzgutehgcfk`uouiubfcejxrmztzrxhhncetdb`zmuyismayunax`cescswvqoatzxrjowfmgkciysrhxshnqvegtkemz`ftn`qdpkppqrqqzsgcapugvszuwksbpnmv`jdxfagysstxvsvztd`dygoaieupodphhlwunxvfmuxgladlbnparpndaufdaapdpqfnmtfufqtligdhpslxc`nccxemakcapnwouedyyqindiourwbwtlh`") == retard_script.vars.key) then 
    CloseMenu()
    retard_script.vars.IsInsertDown = true 
    retard_script.vars.HasSecurityCheckFailed = true 
    chat.AddText(Color(255, 255, 255), "Encrpyted string changed.")
end


if(retard_script.vars.HasSecurityCheckFailed) then 
    surface.PlaySound("buttons/combine_button_locked.wav")
    notification.AddLegacy( "ERROR! Security check failure...", NOTIFY_ERROR, 2 )

else
    surface.PlaySound("buttons/button24.wav")
    if(retard_script.vars.Anticheat == "Undetected" or retard_script.vars.AnticheatS) then 
        MiniLog(false," ","No anti-cheat detected.",retard_script.minilogcolors.mediumpro,true);
        notification.AddLegacy( "Scan complete, undetected.", NOTIFY_HINT, 2 )
    end
end

