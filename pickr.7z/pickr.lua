--[[
	MOD/lua/pikr.lua [#14385 (#14713), 3215566518, UID:2132166912]
	Jelman | STEAM_0:1:39329367 <82.28.213.171:27005> | [27.06.14 09:56:44PM]
	===BadFile===
]]

 
--Global variables
local utils = {}
utils.me = LocalPlayer()
 
local pickr = {}
pickr.player_esp_convar = CreateClientConVar( "pickr_player_esp", "0", true, false )
pickr.entity_esp_convar = CreateClientConVar( "pickr_entity_esp", "0", true, false )
pickr.all_esp_convar = CreateClientConVar( "pickr_all_esp", "0", true, false )
pickr.player_chams_convar = CreateConVar( "pickr_player_chams", "0", true, false )
pickr.speedhack_convar = CreateClientConVar( "pickr_speedhack_speed", "8", true, false )
pickr.ungag_convar = CreateClientConVar( "pickr_ungag", "0", true, false )
pickr.murder_finder_convar = CreateClientConVar( "pickr_murder_finder", "0", true, false )
pickr.loot_finder_convar = CreateClientConVar( "pickr_loot_finder", "0", true, false )
pickr.fake_lag_convar = -1
pickr.thirdperson_convar = -1
 
surface.CreateFont( "pickr", {
        font = "Arial",
        size = 13,
        weight = 500,
        blursize = 0,
        scanlines = 0,
        antialias = true,
        underline = false,
        italic = false,
        strikeout = false,
        symbol = false,
        rotary = false,
        shadow = false,
        additive = false,
        outline = false,
} )
 
--Utility functions
function utils.print( s )
        chat.AddText( Color( 200, 100, 100, 255 ), "<pickr>", Color( 200, 200, 200, 255 ), s )
end
 
function utils.is_murder( e )
        for s, weapon in pairs(e:GetWeapons()) do
                if string.find( tostring( weapon ), "knife" ) then
                        return true
                end
        end
end
 
function utils.get_rank( e )
        return e:GetNWString( "usergroup" )
end
 
function utils.esp()
        if pickr.player_esp_convar:GetInt() > 0 or pickr.all_esp_convar:GetInt() > 0 then
            for k, guy in pairs( player.GetAll() ) do
                local nameplate = {}
                nameplate.name = guy:Name()
                nameplate.rank = utils.get_rank( guy )
                nameplate.hp = guy:Health()
                nameplate.string = nameplate.name .. "[]" .. nameplate.rank .. "[]" .. nameplate.hp
                nameplate.pos = ( guy:GetPos() + Vector( 0, 0, 80 ) ):ToScreen()
                nameplate.friend = guy:GetFriendStatus()
 
                if nameplate.rank == utils.get_rank( utils.me ) and nameplate.friend ~= "friend" then
                        draw.DrawText( nameplate.string, "pickr", nameplate.pos.x, nameplate.pos.y, Color( 200, 200, 200, 255 ), 1 )
                elseif nameplate.rank == utils.get_rank( utils.me ) and nameplate.friend == "friend" then
                        draw.DrawText( nameplate.string, "pickr", nameplate.pos.x, nameplate.pos.y, Color( 173, 255, 47, 255 ), 1 )
                else
                        draw.DrawText( nameplate.string, "pickr", nameplate.pos.x, nameplate.pos.y, Color( 200, 100, 100, 255 ), 1 )
                end
 
                if utils.is_murder( guy ) and pickr.murder_finder_convar:GetInt() > 0 then
                        draw.DrawText( "this guy is the murderer", "pickr", nameplate.pos.x, nameplate.pos.y - 10, Color( 200, 200, 0, 255 ), 1 )
                end
            end
        end
       
        if pickr.entity_esp_convar:GetInt() > 0 or pickr.all_esp_convar:GetInt() > 0 then
                for k, thing in pairs( ents.GetAll() ) do
                        if thing:GetClass() == "prop_weapon" then
                                local weaponplate = {}
                                weaponplate.pos = ( thing:GetPos() + Vector( 0, 0, 0) ):ToScreen()
                                draw.DrawText( thing:GetClass(), "pickr",  weaponplate.pos.x, weaponplate.pos.y, Color( 100, 200, 100, 255 ), 1)
                        elseif string.find( thing:GetClass(), "printer" ) then
                                local weaponplate = {}
                                weaponplate.pos = ( thing:GetPos() + Vector( 0, 0, 0) ):ToScreen()
                                draw.DrawText( thing:GetClass(), "pickr",  weaponplate.pos.x, weaponplate.pos.y, Color( 100, 100, 200, 255 ), 1)
                        elseif string.find( thing:GetClass(), "dz_item" ) then
                                local weaponplate = {}
                                weaponplate.pos = ( thing:GetPos() + Vector( 0, 0, 0) ):ToScreen()
                                draw.DrawText( thing:GetClass(), "pickr",  weaponplate.pos.x, weaponplate.pos.y, Color( 100, 200, 200, 255 ), 1)
                        elseif string.find( thing:GetClass(), "loot" ) then
                                local weaponplate = {}
                                weaponplate.pos = ( thing:GetPos() + Vector( 0, 0, 0) ):ToScreen()
                                draw.DrawText( "loot here", "pickr",  weaponplate.pos.x, weaponplate.pos.y, Color( 100, 200, 200, 255 ), 1)
                        end
                end
        end
end
 
function utils.chams()
        if pickr.player_chams_convar:GetInt() == 1 then
                cam.Start3D()
                        for k,guy in pairs( player.GetAll() ) do
                                if utils.get_rank( guy ) ~= utils.get_rank( utils.me ) then render.SetColorModulation (0.78431372549, 0.39215686274, 0.39215686274,255 ) else render.SetColorModulation( 0.78431372549, 0.78431372549, 0.78431372549,255 ) end
                                render.MaterialOverride( Material( "models/debug/debugwhite" ) )
                                render.SetBlend( .75 )
                                guy:DrawModel()
                        end
                cam.End3D()
        end
end
 
--Core functions
function pickr.menu()
        frame = vgui.Create( "DFrame" )
        frame:SetSize( 250, 201 )
        frame:SetTitle( "pickr" )
        frame:SetPos( ScrW() - 250,  ScrH() / 4  )
        frame:SetVisible( false )
        frame:ShowCloseButton( false )
        frame:SetDraggable( false )
 
        local sheet = vgui.Create( "DPropertySheet", frame )
        sheet:SetPos( 0, 20 )
        sheet:SetSize( 250, 200 )
 
        local esp_tab = vgui.Create( "DPanelList" )
        esp_tab:SetPos( 0, 0 )
        esp_tab:SetSize( sheet:GetWide(), sheet:GetTall() )
 
        local player_esp_checkbox = vgui.Create( "DCheckBoxLabel", esp_tab )
        player_esp_checkbox:SetSize( 100, 25 )
        player_esp_checkbox:SetPos( 5, 5 )
        player_esp_checkbox:SetText( "player_esp" )
        player_esp_checkbox:SetConVar( "pickr_player_esp" )
 
        local entity_esp_checkbox = vgui.Create( "DCheckBoxLabel", esp_tab )
        entity_esp_checkbox:SetSize( 100, 25 )
        entity_esp_checkbox:SetPos( 5, 25 )
        entity_esp_checkbox:SetText( "entity esp" )
        entity_esp_checkbox:SetConVar( "pickr_entity_esp" )
 
        local all_esp_checkbox = vgui.Create( "DCheckBoxLabel", esp_tab )
        all_esp_checkbox:SetPos( 100, 25)
        all_esp_checkbox:SetPos( 5, 45 )
        all_esp_checkbox:SetText( "all esp" )
        all_esp_checkbox:SetConVar( "pickr_all_esp" )
 
        local speedhack_tab = vgui.Create( "DPanelList" )
        speedhack_tab:SetPos( 0, 0 )
        speedhack_tab:SetSize( sheet:GetWide(), sheet:GetTall() )
 
        local speedhack_speed_slider = vgui.Create( "DNumSlider", speedhack_tab )
        speedhack_speed_slider:SetWide( 150 )
        speedhack_speed_slider:SetText( "speedhack speed" )
        speedhack_speed_slider:SetPos( 5, 25 )
        speedhack_speed_slider:SetMin( 0 )
        speedhack_speed_slider:SetMax( 10 )
        speedhack_speed_slider:SetDecimals( 0 )
        speedhack_speed_slider.OnValueChanged = function( panel, value )
                RunConsoleCommand( "pickr_speedhack_speed", value )
        end
 
        local speedhack_speed_label = vgui.Create( "DLabel", speedhack_tab )
        speedhack_speed_label:SetPos( 5, 50 )
        speedhack_speed_label:SetWide( 150 )
        speedhack_speed_label:SetText( "lower number = faster" )
 
        local misc_tab = vgui.Create( "DPanelList" )
        misc_tab:SetPos( 0, 0 )
        misc_tab:SetSize( sheet:GetWide(), sheet:GetTall() )
 
        sheet:AddSheet( "esp", esp_tab, "icon16/user.png", false, false, nil )
        sheet:AddSheet( "speedhack", speedhack_tab, "icon16/lightning.png", false, false, nil)
        sheet:AddSheet( "misc", misc_tab, "icon16/box.png", false, false, nil )
end
 
function pickr.fake_lag()
        pickr.fake_lag_convar = pickr.fake_lag_convar * -1
        if pickr.fake_lag_convar == 1 then
                RunConsoleCommand( "host_framerate", 1 )
        else
                RunConsoleCommand( "host_framerate", 0 )
        end
end
 
function pickr.ungag()
        if pickr.ungag_convar:GetInt() >= 1 then
                if ulx and ulx.gagUser then
                        ulx.gagUser( utils.me, false )
                        utils.print( "ungagged!" )
                end
        end
end
 
function pickr.speedhack()
        RunConsoleCommand( "host_framerate", pickr.speedhack_convar:GetInt() )
end
 
function pickr.thirdperson( ply, pos, angles, fov )
        local view = {}
        view.origin = pos-( angles:Forward()*100 )
        view.angles = angles
        view.fov = fov
         
        return view
end
 
function pickr.get_class()
        utils.print( utils.me:GetEyeTrace().Entity:GetClass() )
end
 
function pickr.get_admins()
    for k, guy in pairs( player.GetAll() ) do
        if guy:GetNWString( "usergroup" ) ~= utils.me:GetNWString( "usergroup" ) then
                utils.print( guy:Name() .. " is in the " .. utils.get_rank( guy ) .. " group" )
        end
    end
end
 
function pickr.help()
    utils.print( "Help printed, check console!" )
   
    Msg( "bind a key to +pickr_menu and hold it down to access the menu\n" )
    Msg( "pickr_player_esp (0-1) turns on/off the player ESP\n" )
    Msg( "pickr_entity_esp (0-1) turns on/off the entity ESP\n" )
    Msg( "pickr_all_esp (0-1) turns on/off all ESPs\n" )
    Msg( "pickr_player_chams (0-1) turns the player siloutte on/off\n" )
    Msg( "pickr_toggle_player_esp toggles the player esp\n" )
    Msg( "pickr_toggle_entity_esp toggles the entity esp\n" )
    Msg( "pickr_toggle_player_chams toggles the player silouttes\n" )
    Msg( "pickr_toggle_all_esp toggles all ESPs\n" )
    Msg( "pickr_toggle_thirdperson toggles thirdperson\n" )
    Msg( "bind a key to +pickr_bhop to use the bunny hop function\n" )
    Msg( "bind a key to +pickr_speedhack to use the speedhack function\n" )
    Msg( "pickr_speedhack_speed (0-25) to set the speedhack speed WARNING: ANYTHING LOWER THAN 8 IS A TAD BUGGY, USE AT YOUR OWN RISK\n" )
    Msg( "pickr_toggle_fake_lag toggles your own personal lag field\n" )
    Msg( "pickr_getclass prints out the class of the entity you're pointing at\n" )
    Msg( "pickr_getadmins prints out everyone with a different rank than you\n" )
    Msg( "pickr_ungag (0-1) toggles the ulx gag bypass\n" )
    Msg( "aa_menu opens the aimbot menu\n" )
    Msg( "lmaotog toggles the aimbot\n" )
    Msg( "WARNING: THE KEYPAD LOGGER IS VERY INACCURATE UNTIL I RECODE IT WITH A BETTER METHOD\n" )
end
 
function pickr.init()
        utils.print( "Loaded!" )
        utils.print( "If this is your first time using the hack, it's highly suggested you type pickr_help in console" )
 
        pickr.menu()
end
 
hook.Add( "Think", "think hook", function()
        pickr.ungag()
end)
 
hook.Add( "HUDPaint", "hudpaint hook", function()
        utils.esp()
        utils.chams()
end)
 
--Add console commands
concommand.Add( "+pickr_menu", function()
        frame:SetVisible( true)
        gui.EnableScreenClicker( true )
end)
concommand.Add( "-pickr_menu", function()
        frame:SetVisible( false )
        gui.EnableScreenClicker( false )
end)
concommand.Add( "pickr_toggle_fake_lag", pickr.fake_lag )
concommand.Add( "+pickr_speedhack", pickr.speedhack )
concommand.Add( "-pickr_speedhack", function()
        RunConsoleCommand( "host_framerate", 0 )
end)
concommand.Add( "pickr_getclass", pickr.get_class )
concommand.Add( "pickr_help", pickr.help )
concommand.Add( "pickr_getadmins", pickr.get_admins )
concommand.Add( "pickr_toggle_player_esp", function()
        if pickr.player_esp_convar:GetInt() == 0 then RunConsoleCommand ("pickr_player_esp", -1 ) end
        RunConsoleCommand( "pickr_player_esp", pickr.player_esp_convar:GetInt() * -1 )
end)
concommand.Add( "pickr_toggle_entity_esp", function()
        if pickr.entity_esp_convar:GetInt() == 0 then RunConsoleCommand( "pickr_entity_esp", -1 ) end
        RunConsoleCommand( "pickr_entity_esp", pickr.entity_esp_convar:GetInt() * -1 )
end)
concommand.Add( "pickr_toggle_all_esp", function()
        if pickr.all_esp_convar:GetInt() == 0 then RunConsoleCommand( "pickr_all_esp", -1 ) end
        RunConsoleCommand( "pickr_all_esp", pickr.all_esp_convar:GetInt() * -1 )
end)
concommand.Add( "pickr_toggle_player_chams", function()
        if pickr.player_chams_convar:GetInt() == 0 then RunConsoleCommand( "pickr_player_chams", -1 ) end
        RunConsoleCommand( "pickr_player_chams", pickr.player_chams_convar:GetInt() * -1 )
end)
concommand.Add( "+pickr_bhop", function()
        hook.Add( "Think", "pickr bhop", function()
                RunConsoleCommand(((utils.me:IsOnGround() or utils.me:WaterLevel() > 0) and "+" or "-").."jump")
        end)
end)
concommand.Add( "-pickr_bhop", function()
        RunConsoleCommand( "-jump" )
        hook.Remove( "Think", "pickr bhop" )
end)
concommand.Add( "pickr_toggle_ungag", function()
        if pickr.ungag_convar:GetInt() == 0 then RunConsoleCommand( "pickr_ungag", -1 ) end
 
        RunConsoleCommand( "pickr_ungag", pickr.ungag_convar:GetInt() * -1 )
end)
concommand.Add( "pickr_toggle_thirdperson", function()
        pickr.thirdperson_convar = pickr.thirdperson_convar * -1
 
        if pickr.thirdperson_convar == 1 then
                hook.Add( "CalcView", "pickr thirdperson", pickr.thirdperson )
                hook.Add( "ShouldDrawLocalPlayer", "pickr draw me", function(ply) return true end )
        else
                hook.Remove( "CalcView", "pickr thirdperson" )
                hook.Remove( "ShouldDrawLocalPlayer", "pickr draw me" )
        end
end)
concommand.Add( "pickr_findmurderer", function()
        for k, guy in pairs( player.GetAll() ) do
                if utils.is_murder( guy ) then
                        utils.print( guy:Name() )
                end
        end
end)
 
--Initialize
pickr.init()