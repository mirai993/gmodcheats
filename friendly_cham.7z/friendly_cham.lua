-- Note by paradox:
-- Posted June 3rd, 2025: copypaste
-- https://www.unknowncheats.me/forum/garry-s-mod/703552-postrender-xqz-chams.html

local chams_mat = Material("models/debug/debugwhite")
local texture_rt = GetRenderTargetEx("texture_rt", ScrW(), ScrH(), RT_SIZE_OFFSCREEN, MATERIAL_RT_DEPTH_SHARED, bit.bor(2, 256, 32768), 0, IMAGE_FORMAT_BGRA8888)
local scr_material = CreateMaterial("scr_material", "UnlitGeneric", {
    ["$basetexture"] = texture_rt:GetName(),
    ["$vertexcolor"] = 1,
    ["$vertexalpha"] = 1,
    ["$ignorez"] = 1,
    ["$nocull"] = 1,
})
 
local function RenderToTexture()
    render.PushRenderTarget(texture_rt)
    render.Clear(0, 0, 0, 0, false, true)
    render.SetWriteDepthToDestAlpha(false)
 
    render.MaterialOverride(chams_mat)
    render.SetColorModulation(0, 0.549, 1)
 
    for _, ent in ipairs(player.GetAll()) do
        if not ent:IsValid() or not ent:Alive() or ent:IsDormant() then continue end
 
        ent:DrawModel()
    end
 
    render.MaterialOverride(nil)
    render.PopRenderTarget()
end
 
 
local function RenderToScreen()
    cam.Start2D()
        render.SetMaterial(scr_material)
        render.DrawScreenQuad()
    cam.End2D()
end
 
hook.Add("PostDrawOpaqueRenderables", "RenderTexture", RenderToTexture)
 
local original_PostRender = GAMEMODE.PostRender
function GAMEMODE.PostRender(self)
    original_PostRender(self)
 
    RenderToScreen()
end