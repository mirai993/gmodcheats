--[[
	Shenbot.lua
	Jesse Jackson | (STEAM_0:1:43732934)
	===DStream===
]]

ShenBot = {}

ShenBot["ESP"] = {}
ShenBot["ESP"].Enabled = CreateClientConVar( "sbot_esp_enabled", 1, false, false )

ShenBot["Aimbot"] = {}
ShenBot["Aimbot"].Scanning = false
ShenBot["Aimbot"].Target = nil

ShenBot["Aimbot"].SpecialModels = {}
ShenBot["Aimbot"].SpecialModels["models/zombie/poison.mdl"] = function( ent ) return ent:GetAttachment( ent:LookupAttachment( "eyes" ) ).Pos end
ShenBot["Aimbot"].SpecialModels["models/zombie/fast.mdl"] = function( ent ) return ent:GetAttachment( ent:LookupAttachment( "eyes" ) ).Pos end
ShenBot["Aimbot"].SpecialModels["models/zombie/classic.mdl"] = function( ent ) return ent:GetAttachment( ent:LookupAttachment( "eyes" ) ).Pos end
ShenBot["Aimbot"].SpecialModels["models/headcrabblack.mdl"] = function( ent ) return ent:GetBonePosition( ent:LookupBone( "head" ) ) end
ShenBot["Aimbot"].SpecialModels["models/headcrab.mdl"] = function( ent ) return ent:GetBonePosition( ent:LookupBone( "head" ) ) end
ShenBot["Aimbot"].SpecialModels["models/headcrabclassic.mdl"] = function( ent ) return ent:GetBonePosition( ent:LookupBone( "head" ) ) end

concommand.Add( "+sbot_aimbot", function()

	hook.Add( "Think", "ShenBot.AimbotThink", ShenBot.AimbotThink )
	ShenBot["Aimbot"].Scanning = true
	
end )

concommand.Add( "-sbot_aimbot", function()

	hook.Remove( "Think", "ShenBot.AimbotThink" )
	ShenBot["Aimbot"].Scanning = false
	ShenBot["Aimbot"].Target = nil
	
end )

function ShenBot.DrawHUD()

	if ( ShenBot["Aimbot"].Scanning ) then
	
		draw.SimpleText( "Scanning..", "ScoreboardText", ScrW() / 2, ScrH() / 2 + 30, Color( 255, 0, 0, 175 ), TEXT_ALIGN_CENTER )
		
	end
	
end
hook.Add( "HUDPaint", "ShenBot.DrawHUD", ShenBot.DrawHUD )

function ShenBot.AimbotThink()

	if ( ShenBot["Aimbot"].Scanning ) then
	
		if ( ShenBot["Aimbot"].Target == nil ) then
		
			local traceHit = LocalPlayer():GetEyeTrace().Entity
			
			if ( traceHit ~= nil ) then
			
				if ( traceHit:IsPlayer() ) and ( traceHit:Alive() ) then
				
					ShenBot["Aimbot"].Target = traceHit
					
				end
				
			end
			
		else
		
			if ( ShenBot["Aimbot"].Target:Alive() ) and ( ShenBot["Aimbot"].Target:IsValid() ) then
			
				if ( ShenBot["Aimbot"].SpecialModels[ShenBot["Aimbot"].Target:GetModel()] ~= nil ) then

					LocalPlayer():SetEyeAngles( ( ShenBot["Aimbot"].SpecialModels[ShenBot["Aimbot"].Target:GetModel()]( ShenBot["Aimbot"].Target ) - LocalPlayer():GetShootPos() ):Angle() )
				
				else

					local Eyes = ShenBot["Aimbot"].Target:LookupBone( "ValveBiped.Bip01_Head1" )
					local EyesPos, EyesAng = ShenBot["Aimbot"].Target:GetBonePosition( Eyes )
					
					LocalPlayer():SetEyeAngles( ( EyesPos - LocalPlayer():GetShootPos() ):Angle() )
					
				end
			
			end
		
		end

	end
	
end

function ShenBot.DrawESP()

	for k, v in pairs ( player.GetAll() ) do
	
		if ( v:Alive() ) and not ( v == LocalPlayer() ) and ( v:IsValid() ) then

			local Eyes = v:LookupBone( "ValveBiped.Bip01_Head1" )
			local EyesPs, EyesAng = v:GetBonePosition( Eyes )
			
			local EyesPos = EyesPs:ToScreen()
			
			draw.SimpleText( v:Nick(), "ScoreboardText", EyesPos.x, EyesPos.y, Color( 255, 50, 0, 175 ), 1 )
			draw.SimpleText( v:Health() .. " HP", "ScoreboardText", EyesPos.x, EyesPos.y + 12, Color( 50, 255, 0, 175 ), 1 )
				
			if ( v:GetActiveWeapon():IsValid() ) then
				
				draw.SimpleText( v:GetActiveWeapon():GetPrintName(), "ScoreboardText", EyesPos.x, EyesPos.y + 24, Color( 255, 0, 255, 175 ), 1 )
					
			end

		end
		
	end
	
end
hook.Add( "HUDPaint", "ShenBot.DrawESP", ShenBot.DrawESP )