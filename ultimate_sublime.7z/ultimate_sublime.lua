if not pcall( require, "zxcmodule" ) then return end
local Ultimate = {}

local Reg = ded.PushSpecial( 2 )
local Meta = { Player = Reg.Player, Entity = Reg.Entity, ConVar = Reg.ConVar }

// Common libs 
local math_lib      = math 
local bit_lib       = bit 
local surface_lib   = surface 
local render_lib    = render
local cam_lib       = cam
local table_lib     = table 
local string_lib    = string
local team_lib      = team
local util_lib      = util
local vgui_lib      = vgui
local input_lib     = input
local player_lib    = player
local ents_lib      = ents
local steam_lib     = steamworks
local net_lib       = net
local hook_lib      = hook
local gui_lib       = gui
local engine_lib    = engine

// Common math 
local math_Abs                          = math_lib.abs
local math_Acos                         = math_lib.acos
local math_Approach                     = math_lib.Approach
local math_Asin                         = math_lib.asin
local math_Atan                         = math_lib.atan
local math_Atan2                        = math_lib.atan2
local math_Ceil                         = math_lib.ceil
local math_Clamp                        = math_lib.Clamp
local math_Cos                          = math_lib.cos
local math_Deg                          = math_lib.deg
local math_Floor                        = math_lib.floor
local math_Max                          = math_lib.max
local math_Min                          = math_lib.min
local math_Tan                          = math_lib.tan
local math_Sqrt                         = math_lib.sqrt
local math_Sin                          = math_lib.sin
local math_Round                        = math_lib.Round
local math_Random                       = math_lib.random
local math_Rand                         = math_lib.Rand
local math_NormalizeAngle               = math_lib.NormalizeAngle
local math_Randomseed                   = math_lib.randomseed
local math_Rad                          = math_lib.rad
local math_ModF                         = math_lib.modf
local math_AngleDifference              = math_lib.AngleDifference
local math_DistanceSqr                  = math_lib.DistanceSqr
local math_Remap                        = math_lib.Remap

local math_Infinity                     = 2^1024
local math_Radian                       = 57.295779513082
local math_Pi                           = 3.1415926535898

// Common bit operations 
local bit_Band                          = bit_lib.band
local bit_Bor                           = bit_lib.bor
local bit_Bnot                          = bit_lib.bnot
local bit_Lshift                        = bit_lib.lshift

// Common surface funcs 
local surface_CreateFont                = surface_lib.CreateFont
local surface_DrawCircle                = surface_lib.DrawCircle
local surface_DrawLine                  = surface_lib.DrawLine
local surface_DrawOutlinedRect          = surface_lib.DrawOutlinedRect
local surface_DrawPoly                  = surface_lib.DrawPoly
local surface_DrawRect                  = surface_lib.DrawRect
local surface_DrawText                  = surface_lib.DrawText
local surface_DrawTexturedRect          = surface_lib.DrawTexturedRect
local surface_GetTextSize               = surface_lib.GetTextSize
local surface_PlaySound                 = surface_lib.PlaySound
local surface_SetAlphaMultiplier        = surface_lib.SetAlphaMultiplier
local surface_SetDrawColor              = surface_lib.SetDrawColor
local surface_SetFont                   = surface_lib.SetFont
local surface_SetMaterial               = surface_lib.SetMaterial
local surface_SetTextColor              = surface_lib.SetTextColor
local surface_SetTextPos                = surface_lib.SetTextPos

// Common input 
local input_GetCursorPos                = input_lib.GetCursorPos
local input_GetKeyName                  = input_lib.GetKeyName
local input_IsKeyDown                   = input_lib.IsKeyDown
local input_IsMouseDown                 = input_lib.IsMouseDown
local input_LookupBinding               = input_lib.LookupBinding
local input_GetKeyCode                  = input_lib.GetKeyCode
local input_SetCursorPos                = input_lib.SetCursorPos
local input_WasMousePressed             = input_lib.WasMousePressed

// Common string 
local string_find                       = string_lib.find
local string_format                     = string_lib.format
local string_len                        = string_lib.len
local string_lower                      = string_lib.lower
local string_sub                        = string_lib.sub
local string_StartsWith                 = string_lib.StartsWith
local string_Split                      = string_lib.Split
local string_upper                      = string_lib.upper
local lang_GetPhrase                    = language.GetPhrase

local VectorPattern                     = "%G %G %G"
local HexPattern                        = "#%02X%02X%02X"
// Common table 
local table_concat                      = table_lib.concat
local table_insert                      = table_lib.insert
local table_remove                      = table_lib.remove
local table_sort                        = table_lib.sort
local table_Add                         = table_lib.Add

local IterateNext                       = pairs 
local IterateNum                        = ipairs

// Common render 
local render_MaterialOverride           = render_lib.MaterialOverride
local render_SetColorModulation         = render_lib.SetColorModulation
local render_SetBlend                   = render_lib.SetBlend
local render_SuppressEngineLighting     = render_lib.SuppressEngineLighting
local render_DrawBeam                   = render_lib.DrawBeam
local render_SetMaterial                = render_lib.SetMaterial
local render_DrawWireframeBox           = render_lib.DrawWireframeBox
local render_RenderView                 = render_lib.RenderView
local render_Clear                      = render_lib.Clear
local render_BlurRenderTarget           = render_lib.BlurRenderTarget
local render_SetLightingMode            = render_lib.SetLightingMode
local render_SetStencilEnable           = render_lib.SetStencilEnable
local render_SetStencilCompareFunction  = render_lib.SetStencilCompareFunction
local render_SetStencilReferenceValue   = render_lib.SetStencilReferenceValue
local render_DrawScreenQuad             = render_lib.DrawScreenQuad
local render_SetRenderTarget            = render_lib.SetRenderTarget
local render_CopyRenderTargetToTexture  = render_lib.CopyRenderTargetToTexture
local render_SetStencilFailOperation    = render_lib.SetStencilFailOperation
local render_SetStencilZFailOperation   = render_lib.SetStencilZFailOperation
local render_SetStencilPassOperation    = render_lib.SetStencilPassOperation
local render_SetStencilTestMask         = render_lib.SetStencilTestMask
local render_SetStencilWriteMask        = render_lib.SetStencilWriteMask
local render_GetScreenEffectTexture     = render_lib.GetScreenEffectTexture
local render_SetScissorRect             = render_lib.SetScissorRect
local render_DrawTextureToScreen        = render_lib.DrawTextureToScreen
local render_DrawLine                   = render_lib.DrawLine
local render_SetGoalToneMappingScale    = render_lib.SetGoalToneMappingScale
local render_SetModelLighting           = render_lib.SetModelLighting
local render_SetShadowsDisabled         = render_lib.SetShadowsDisabled
local render_DepthRange                 = render_lib.DepthRange
local render_UpdateScreenEffectTexture  = render_lib.UpdateScreenEffectTexture

local cam_Start2D                       = cam_lib.Start2D
local cam_Start3D                       = cam_lib.Start3D
local cam_End2D                         = cam_lib.End2D
local cam_End3D                         = cam_lib.End3D
local cam_IgnoreZ                       = cam_lib.IgnoreZ

// Hooking stuff 
local hook_Add                          = hook_lib.Add
local hook_Remove                       = hook_lib.Remove
local hook_GetTable                     = hook_lib.GetTable
local hook_Call                         = hook_lib.Call

// Some utils 
local engine_ServerFrameTime            = engine_lib.ServerFrameTime
local TickInterval                      = engine_lib.TickInterval()
local TickRate                          = math_Floor( 1 / TickInterval )

local util_TraceLine                    = util_lib.TraceLine
local util_TraceHull                    = util_lib.TraceHull
local net_Start                         = net_lib.Start
local net_SendToServer                  = net_lib.SendToServer

local vgui_Create                       = vgui_lib.Create
local vgui_CursorVisible                = vgui_lib.CursorVisible
local gui_EnableScreenClicker           = gui_lib.EnableScreenClicker 
local gui_IsGameUIVisible               = gui_lib.IsGameUIVisible
local gui_OpenURL                       = gui_lib.OpenURL

local team_GetName                      = team_lib.GetName
local team_GetColor                     = team_lib.GetColor
local player_GetAll                     = player_lib.GetAll
local ents_GetAll                       = ents_lib.GetAll

// Localised global funcs
local Ang = Angle
local Vec = Vector
local Col = Color
local Ply = Player 
local Ent = Entity 
local Mat = Material 
local Hue = HSVToColor

local IsStr = isstring
local IsTbl = istable
local IsNum = isnumber
local ToNum = tonumber
local ToStr = tostring
local IsBool = isbool

local GetCurTime   = CurTime 
local CurrentTime  = 0
local GetFrameTime = FrameTime 
local RenderTime   = 0

local Validate      = IsValid
local RunCommand    = RunConsoleCommand 
local ConsoleVar    = GetConVar 
local LinearInterp  = Lerp 
local IsPredicted   = IsFirstTimePredicted 
local ClientModel   = ClientsideModel 
local NewMaterial   = CreateMaterial 

// Console variables
local ConVarEx = {}

ConVarEx.Default = { 
    "sv_maxusrcmdprocessticks", "sv_namechange_cooldown_seconds", "name", 
    "sv_maxvelocity", "sv_airaccelerate", "sv_accelerate", "sv_friction", "sv_stopspeed", "sv_gravity",
    "r_aspectratio", "cl_forwardspeed", "cl_sidespeed", "climbswep2_maxjumps",
    "sensitivity", "m_yaw", "m_pitch",
}

function ConVarEx.List( str, type )
    local ConVarObj = ConsoleVar( str )

    if not ConVarObj then
        ConVarEx[ str ] = false
        return 
    end 

    ConVarEx[ str ] = { var = Meta.ConVar[ "Get" .. ( type or "Float" ) ]( ConVarObj ), flags = Meta.ConVar.GetFlags( ConVarObj ) }
end

function ConVarEx.Force( str, var )
    ded.ConVarSetFlags( str, 0 )
        gRunConsoleCommand( str, gToString( var ) )
    ded.ConVarSetFlags( str, ConVarEx[ str ].flags )
end

function ConVarEx.Init()
    for i = 1, #ConVarEx.Default do
        ConVarEx.List( ConVarEx.Default[ i ] )
    end

    ConVarEx.List( "sv_skyname", "String" )
end 

// Mouse input 
local MouseEx = { x = 0, y = 0 }

function MouseEx.InRect( x, y, w, h )
    w = x + w 
    h = y + h 

    return ( MouseEx.x >= x and MouseEx.x <= w ) and ( MouseEx.y >= y and MouseEx.y <= h )
end

// Vector extension 
local VectorEx = { Null = Vec(), Positive = Vec( 1, 1, 1 ), TempAng = Ang() }

function VectorEx.Abs( vec )
    vec.x = math_Floor( vec.x )
    vec.y = math_Floor( vec.y )
    vec.z = math_Floor( vec.z )

    return vec 
end

function VectorEx.GetSumId( vec )
    return string_format( VectorPattern, vec.x, vec.y, vec.z )
end

function VectorEx.CalcDir( start, endpos )
    VectorEx.TempAng = ( start - endpos ):Angle()
    VectorEx.TempAng:Normalize()

    return VectorEx.TempAng
end

// Screen data 
local ScrEx = { Scaled = {}, Get = {} }

ScrEx.Width   = ScrW() 
ScrEx.Height  = ScrH() 
ScrEx.CenterX = math_Floor( ScrW() * 0.5 )
ScrEx.CenterY = math_Floor( ScrH() * 0.5 ) 

function ScrEx.Adjust( var )
    return var * ( ScrEx.Height / 1024 )
end

ScrEx.Default = {
    TabBarWidth = 205,
    TabWidth    = 168,
    TabHeight   = 36,
    IconSize    = 16,
    FrameWidth  = 900,
    FrameHeight = 700,
}

ScrEx.Fonts = {
    { "Veranda", { font = "Verdana", size = 12, antialias = false, outline = true }, 12 },
    { "TabFont", { font = "Roboto", size = 16, weight = 100 }, 16 },
    { "MenuFont", { font = "Roboto", size = 20, weight = 350 }, 20 },
    { "LogoText", { font = "Roboto", size = 42, weight = 500 }, 42 },
}

function ScrEx.Scale( var )
    if IsNum( var ) then
        local it = var 

        var = function() 
            return ScrEx.Adjust( it ) 
        end
    end

    local Index = #ScrEx.Scaled + 1
    ScrEx.Scaled[ Index ] = { var(), var }

    return ScrEx.Scaled[ Index ][ 1 ]
end

function ScrEx.Update()
    ScrEx.Width   = ScrW() 
    ScrEx.Height  = ScrH() 
    ScrEx.CenterX = math_Floor( ScrW() * 0.5 )
    ScrEx.CenterY = math_Floor( ScrH() * 0.5 ) 

    for i = 1, #ScrEx.Scaled do
        ScrEx.Scaled[ i ][ 1 ] = ScrEx.Scaled[ i ][ 2 ]()
    end

    for i = 1, #ScrEx.Fonts do
        ScrEx.Fonts[ i ][ 2 ].size = ScrEx.Adjust( ScrEx.Fonts[ i ][ 3 ] )
        surface_CreateFont( ScrEx.Fonts[ i ][ 1 ], ScrEx.Fonts[ i ][ 2 ] )
    end

    for Key, Val in IterateNext( ScrEx.Default ) do
        ScrEx.Get[ Key ] = ScrEx.Scale( Val )
    end
end

ScrEx.Update()

// Jeeeeezyyyyy math ( true, approved by Stephie Hawking )
local MathEx = {}

function MathEx.Average( nums )
    local sum = 0

    for i = 1, #nums do
        sum = sum + nums[ i ]
    end

    return sum / #nums
end

function MathEx.Remap( val, inmax, outmax )
    return math_Ceil( val / inmax * outmax )
end

function MathEx.TimeToTicks( time )
    return math_Floor( 0.5 + time / TickInterval )
end

function MathEx.TicksToTime( ticks )
    return TickInterval * ticks
end

function MathEx.RoundToTick( time )
    return MathEx.TicksToTime( MathEx.TimeToTicks( time ) )
end

function MathEx.Progression( start, n )
    for i = 1, n do
        start = start * start
    end

    return start
end

// Insanely unholy color extension 
local ColorEx = { Cache = {}, Trans = {}, SinSpeed = 128, SinMin = 0 }

function ColorEx.Update( r, g, b, a, index )
    index = index or #ColorEx.Cache + 1
    a = a or 255

    ColorEx.Cache[ index ] = {  
        r = r, g = g, b = b, a = a,
        x = r / 255, y = g / 255, z = b / 255, q = a / 255, 
    }

    return ColorEx.Cache[ index ] 
end

function ColorEx.UpdateTrans( fr, sr, fg, sg, fb, sb, s, a, index )
    index = index or #ColorEx.Trans + 1
    a = a or 255
    s = s or 1

    ColorEx.Trans[ index ] = {
        fr = fr, sr = sr, 
        fg = fg, sg = sg, 
        fb = fb, sb = sb,
        r = 0, g = 0, b = 0,
        x = 0, y = 0, z = 0,
        a = a, q = a / 255,
        s = s
    }

    return ColorEx.Trans[ index ]
end

function ColorEx.Transit( index )
    local Col = ColorEx.Trans[ index ]
    local Sin = math_Abs( math_Sin( CurrentTime * Col.s ) )

    Col.r = Col.fr * ( 1 - Sin ) + Col.sr * Sin
    Col.g = Col.fg * ( 1 - Sin ) + Col.sg * Sin
    Col.b = Col.fb * ( 1 - Sin ) + Col.sb * Sin

    Col.x = Col.r / 255
    Col.y = Col.g / 255
    Col.z = Col.b / 255
end

function ColorEx.GetVector( index, trans )
    local T = trans and ColorEx.Trans[ index ] or ColorEx.Cache[ index ]
    return T.x, T.y, T.z
end 

function ColorEx.GetRGBA( index, trans )
    local T = trans and ColorEx.Trans[ index ] or ColorEx.Cache[ index ]
    return T.r, T.g, T.b, T.a
end 

ColorEx.Rainbow = ColorEx.Update( 255, 255, 255, 255 )
ColorEx.LastTeam = ColorEx.Update( 255, 255, 255, 255 )

// Input extension 
local InputEx = { WasDown = {}, IsDown = {}, IsPressed = {} }

for i = 1, 113 do 
    InputEx.WasDown[ i ] = false 
    InputEx.IsDown[ i ] = false 
    InputEx.IsPressed[ i ] = false 
end

function InputEx.IsKeyDown( key )
    if key >= 107 then 
        return input_IsMouseDown( key ) 
    end

    return input_IsKeyDown( key )
end

// Entity data 
local EntityData = { Players = {}, Solids = {} }

function EntityData.ListEntity( ent, index )
    index = index or #EntityData.Solids + 1

    EntityData.Solids[ index ] = { 
        Ent     = ent,
        Class   = ent:GetClass(),
        Dormant = ent:IsDormant(),
        Health  = ent:Health(),
        OBBMins = ent:OBBMins(),
        OBBMaxs = ent:OBBMaxs(),
        Model   = ent:GetModel()
    }

    return EntityData.Solids[ index ]
end

function EntityData.ListPlayer( ent, index )
    index = index or #EntityData.Players + 1

    EntityData.Players[ index ] = { 
        Ent             = ent,
        Index           = ent:EntIndex(),
        Alive           = ent:Alive(),
        Dormant         = ent:IsDormant(),

        ActiveWeapon    = ent:GetActiveWeapon(),
        WeaponClass     = false,
        WeaponName      = "Unarmed",

        Health          = ent:Health(),
        MaxHealth       = ent:GetMaxHealth(),
        Armor           = ent:Armor(),
        MaxArmor        = ent:GetMaxArmor(),

        Origin          = ent:GetPos(),
        NetworkOrigin   = ent:GetNetworkOrigin(),
        PredictedOrigin = Ent:GetPos(),

        Velocity        = ent:GetVelocity(),
        OBBCenter       = Ent:LocalToWorld( Ent:OBBCenter() ),
    
        Angles          = ent:GetAngles(),
        EyeAngles       = ent:EyeAngles(),
        NetworkAngles   = ent:GetNetworkAngles(),

        MoveType        = ent:GetMoveType(),
        Effects         = ent:GetEffects(),
        EFlags          = ent:GetEFlags(),
        Flags           = ent:GetFlags(),

        Model           = ent:GetModel(),
        OBBMins         = ent:OBBMins(),
        OBBMaxs         = ent:OBBMaxs(),

        SimulationTime  = ded.GetSimulationTime( ent:EntIndex() ),
        BreakingLC      = false,
        PacketSent      = false,
        ChokedPackets   = 0,
    }

    local PlayerTable = EntityData.Players[ Index ]

    ent.StartedReloading    = ent.StartedReloading or 0
    ent.OldSimulationTime   = ent.OldSimulationTime or 0 
    ent.OldNetworkOrigin    = ent.OldNetworkOrigin or PlayerTable.NetworkOrigin

    if ent.OldSimulationTime != PlayerTable.SimulationTime then
        PlayerTable.BreakingLC      = PlayerTable.NetworkOrigin:DistToSqr( ent.OldNetworkOrigin ) > 4096
        PlayerTable.PacketSent      = true 
        PlayerTable.ChokedPackets   = MathEx.TimeToTicks( PlayerTable.SimulationTime - ent.OldSimulationTime )
        
        ent.OldSimulationTime = PlayerTable.SimulationTime
    end

    if not Validate( PlayerTable.Weapon ) then 
        return EntityData.Players[ index ] 
    end 

    PlayerTable.WeaponClass = PlayerTable.Weapon:GetClass()
    PlayerTable.WeaponName  = lang_GetPhrase( PlayerTable.Weapon:GetPrintName() )

    return EntityData.Players[ index ]
end

// Local entity data 
local LocalData = {}
LocalData.Entity = LocalPlayer()

// Active weapon data 
local WeaponData = {}
WeaponData.Entity = false

// World data

// Context data 
local Context = { x = 0, y = 0, w = 0, h = 0, g = 0, str = "", b = false }



// Draw extension 
local DrawEx = { SizeData = {}, Output = {}, Font = "" }

function DrawEx.SetFont( font ) 
    if not DrawEx.SizeData[ font ] then
        DrawEx.SizeData[ font ] = {}
    end

    DrawEx.Font = font 
    surface_SetFont( font )
end

function DrawEx.GetTextSize( str )
    if DrawEx.SizeData[ DrawEx.Font ][ str ] then
        DrawEx.Output = DrawEx.SizeData[ DrawEx.Font ][ str ]
        return DrawEx.Output.x, DrawEx.Output.y 
    end

    local tw, th = surface_GetTextSize( str )

    DrawEx.SizeData[ DrawEx.Font ][ str ] = { x = tw, y = th }

    return tw, th 
end 

function DrawEx.DrawText( str, x, y )
    surface_SetTextPos( x, y )
    surface_DrawText( str )
end

// Material system 
local MaterialEx = {}

function MaterialEx.Cache( str )
    if MaterialEx[ str ] then 
        return MaterialEx[ str ]
    end

    MaterialEx[ str ] = Mat( str )

    return MaterialEx[ str ]
end


// Render extension 
local RenderEx = {}

// Table extension 
local TableEx = {}

function TableEx.ListNumeric( tbl, func )
    for i = 1, #tbl do
        func( i )
    end
end

// Settings 
ColorEx.UpdateTrans( 225, 128, 255, 128, 128, 255, 1, 1 )

local Settings = { 
    Vars = {

    }, 
    Colors = {
         
    }, 
    Binds = {

    },
    Theme = {
        BackSolid   = { ColorEx.Update( 16, 16, 16, 255 ), 1, 0 },
        BackTrans   = { ColorEx.Update( 16, 16, 16, 230 ), 1, 0 },

        TopSolid    = { ColorEx.Update( 28, 28, 28, 255 ), 1, 0 },

        Outline     = { ColorEx.Update( 48, 48, 48, 255 ), 1, 0 },

        LogoText    = { ColorEx.Update( 232, 232, 232, 255 ), 1, 0 },

        Active      = { ColorEx.Update( 72, 72, 72, 156 ), 1, 0 },
        Hovered     = { ColorEx.Update( 56, 56, 56, 96 ), 1, 0 },
        Normal      = { ColorEx.Update( 32, 32, 32, 32 ), 1, 0 },

        TextActive  = { ColorEx.Update( 245, 245, 245, 255 ), 1, 0 },
        TextHovered = { ColorEx.Update( 215, 215, 215, 255 ), 1, 0 },
        TextNormal  = { ColorEx.Update( 185, 185, 185, 255 ), 1, 0 },

        SubActive   = { ColorEx.Update( 225, 225, 225, 255 ), 1, 0 },
        SubHovered  = { ColorEx.Update( 185, 185, 185, 255 ), 1, 0 },
        SubNormal   = { ColorEx.Update( 135, 135, 135, 255 ), 1, 0 },
    }
}


Settings.DynamicColors = {
    [ 2 ] = function( i ) return ColorEx.Rainbow end,
    [ 3 ] = function( i ) return ColorEx.LastTeam end,
    [ 4 ] = function( i ) return ColorEx.Trans[ i ] end,
}

function Settings.GetColor( var )
    local tbl = var[ 1 ]

    if Settings.DynamicColors[ var[ 2 ] ] then
        tbl = Settings.DynamicColors[ var[ 2 ] ]( var[ 3 ] )
    end

    return tbl.r, tbl.g, tbl.b, tbl.a
end

function Settings.GetVector( var )
    local tbl = var[ 1 ]

    if Settings.DynamicColors[ var[ 2 ] ] then
        tbl = Settings.DynamicColors[ var[ 2 ] ]( var[ 3 ] )
    end

    return tbl.x, tbl.y, tbl.z
end

// User interface 
local InterfaceEx = {}
InterfaceEx.IsHoveringPanel = false
InterfaceEx.Frames = {}
InterfaceEx.ShowMenu = false
InterfaceEx.ThemeBoxes = {}
InterfaceEx.ThemeBoxW  = 340

function InterfaceEx.StartThemeBox( StrName )
    if not InterfaceEx.ThemeBoxes[ Context.g ] then
        InterfaceEx.ThemeBoxes[ Context.g ] = 0
    end

    local Tw, Th = DrawEx.GetTextSize( StrName )

    surface_SetDrawColor( Settings.GetColor( Settings.Theme.TopSolid ) )
    surface_DrawRect( Context.x, Context.y, InterfaceEx.ThemeBoxW, InterfaceEx.ThemeBoxes[ Context.g ] )
    surface_SetDrawColor( Settings.GetColor( Settings.Theme.Outline ) )
    surface_DrawRect( Context.x , Context.y + Th + 4, InterfaceEx.ThemeBoxW, 2 )

    surface_SetTextColor( Settings.GetColor( Settings.Theme.TextNormal ) )
    surface_SetTextPos( Context.x + InterfaceEx.ThemeBoxW / 2 - Tw / 2, Context.y + 2 )
    surface_DrawText( StrName )

    Context.x = Context.x + 4
    Context.y = Context.y + Th + 8
    Context.h = Th + 6
end

function InterfaceEx.EndThemeBox()
    InterfaceEx.ThemeBoxes[ Context.g ] = Context.h + 3

    Context.g = Context.g + 1
    Context.y = Context.y + 4
    Context.x = Context.x - 4 
end

function InterfaceEx.Spacer()
    surface_SetDrawColor( Settings.GetColor( Settings.Theme.Outline ) )
    surface_DrawRect( Context.x - 4, Context.y, InterfaceEx.ThemeBoxW, 1 )

    Context.y = Context.y + 4
    Context.h = Context.h + 4
end

function InterfaceEx.CreateFrame( NumWidth, NumHeight, FrameWidth, FrameHeight, CanMove, CanDraw, OnDraw, PostDraw )
    local Index = #InterfaceEx.Frames + 1

    InterfaceEx.Frames[ Index ] = {
        x = 0,
        y = 0,
        w = NumWidth or 0,     
        h = NumHeight or 0,
        TempW = FrameWidth or "FrameWidth", 
        TempH = FrameHeight or "FrameHeight",

        CanMove = CanMove or false,
        CanDraw = CanDraw or false, 
        OnDraw = OnDraw,
        PostDraw = PostDraw,

        LastInteract = 0,
        OldX = 0,
        OldY = 0,
    }

    return Index
end

function InterfaceEx.NormalSort( a, b )   
    return a.LastInteract < b.LastInteract 
end

function InterfaceEx.ReversedSort( a, b ) 
    return a.LastInteract > b.LastInteract 
end

function InterfaceEx.Render()
    local CurrentMouseX, CurrentMouseY = input_GetCursorPos()
    local Frame 

    table_sort( InterfaceEx.Frames, InterfaceEx.NormalSort )

    local Focused = true
    for i = 1, #InterfaceEx.Frames do
        Frame = InterfaceEx.Frames[ i ]

        if not ( IsBool( Frame.CanDraw ) and Frame.CanDraw or Frame.CanDraw() ) then continue end

        InterfaceEx.Frames[ i ].OnDraw( InterfaceEx.Frames[ i ], Focused )
        Focused = false
    end

    table_sort( InterfaceEx.Frames, InterfaceEx.ReversedSort )

    for i = 1, #InterfaceEx.Frames do
        Frame = InterfaceEx.Frames[ i ]

        if Frame.PostDraw then
            Frame.PostDraw()
        end

        if not ( IsBool( Frame.CanDraw ) and Frame.CanDraw or Frame.CanDraw() ) then continue end
        
        if MouseEx.InRect( Frame.x, Frame.y , Frame.w, Frame.h ) then        
            if input_IsMouseDown( MOUSE_LEFT ) and not InterfaceEx.IsHoveringPanel and ( IsBool( Frame.CanMove ) and Frame.CanMove or Frame.CanMove() ) then
                Frame.x = Frame.x + ( CurrentMouseX - MouseEx.x )
                Frame.y = Frame.y + ( CurrentMouseY - MouseEx.y )
    
                Frame.LastInteract = CurTime()
            end
    
            InterfaceEx.IsHoveringPanel = true
        end
    
        Frame.OldX = Frame.x
        Frame.OldY = Frame.y
    end

    InterfaceEx.IsHoveringPanel = false

    Context.g = 0

    MouseEx.x, MouseEx.y = CurrentMouseX, CurrentMouseY
end

function InterfaceEx.Update()
    for i = 1, #InterfaceEx.Frames do
        InterfaceEx.Frames[ i ].w = ScrEx.Get[ InterfaceEx.Frames[ i ].TempW ]
        InterfaceEx.Frames[ i ].h = ScrEx.Get[ InterfaceEx.Frames[ i ].TempH ]
    end
end

function InterfaceEx.ShouldDrawMenu()
    return InterfaceEx.ShowMenu
end

function InterfaceEx.FrameThink()
    if not InputEx.IsPressed[ KEY_DELETE ] then return end 
    InterfaceEx.ShowMenu = not InterfaceEx.ShowMenu
    gui_EnableScreenClicker( InterfaceEx.ShowMenu )
end

InterfaceEx.ActiveTab = 1 
InterfaceEx.Tabs = {
    {
        Name = "Combat", 
        Icon = MaterialEx.Cache( "icons512/hit.png" ),
        Active = 1, 

        SubTabs = {  
            { "Aimbot", function( x, y )

                InterfaceEx.StartThemeBox( "Main" )
 
                InterfaceEx.EndThemeBox()

                Context.x = Context.x + InterfaceEx.ThemeBoxW + 5
                Context.y = y

                InterfaceEx.StartThemeBox( "Main" )
                Context.h = 200
                InterfaceEx.EndThemeBox()

            end },
            { "Rage", function( x, y ) 
            
            end },
            { "Misc", function( x, y ) 
            
            end },
        },
    },
    {
        Name = "Visuals",
        Icon = MaterialEx.Cache( "icons512/binoculars.png" ),
        Active = 1,

        SubTabs = {  
            { "Players", function() end },
            { "Entities", function() end },
            { "Interface", function() end },
        },
    },
    {
        Name = "Render",
        Icon = MaterialEx.Cache( "icons512/bulb.png" ),
        Active = 1,

        SubTabs = {  
            { "View", function() end },
            { "Self", function() end },
            { "World", function() end },
            { "Entities", function() end },
            { "Players", function() end },
        },
    },
    {
        Name = "Misc",
        Icon = MaterialEx.Cache( "icons512/settings.png" ),
        Active = 1,

        SubTabs = {  
            { "Movement", function() end },
            { "Commands", function() end },
            { "Sandbox", function() end },
            { "Roleplay", function() end },
        },
    },
    {
        Name = "Settings",
        Icon = MaterialEx.Cache( "icons512/document.png" ),
        Active = 1,

        SubTabs = {  
            { "Config", function() end },
            { "Themes", function() end },
            { "Colors", function() end },
            { "Binds", function() end },
        },
    },
    {
        Name = "Lists",
        Icon = MaterialEx.Cache( "icons512/list.png" ),
        Active = 1,

        SubTabs = {  
            { "Entities", function() end },
            { "Players", function() end },
            { "Hooks", function() end },
            { "Convars", function() end },
            { "Nets", function() end },
        },
    },
    {
        Name = "Exploits",
        Icon = MaterialEx.Cache( "icons512/flame.png" ),
        Active = 1,

        SubTabs = {  
            { "Entities", function() end },
            { "Players", function() end },
        },
    },
}

local blur = Material("pp/blurscreen")

function InterfaceEx.FrameRender( self, focus )
    local x, y, w, h = self.x, self.y, self.w, self.h
    local data, subdata, inrect, shift, tw, th, pad, spad

    render_SetScissorRect( x, y, x + w, y + h, true )

    surface_SetDrawColor( 255, 255, 255 )
    surface_SetMaterial( blur )

    for i = 1, 3 do
        blur:SetFloat( "$blur", ( i / 3 ) * 6 )
        blur:Recompute()

        render_UpdateScreenEffectTexture()
        surface_DrawTexturedRect( 0, 0, ScrEx.Width, ScrEx.Height )
    end

    surface_SetDrawColor( Settings.GetColor( Settings.Theme.BackTrans ) )
    surface_DrawRect( x, y, ScrEx.Get.TabBarWidth, h )

    surface_SetDrawColor( Settings.GetColor( Settings.Theme.BackSolid ) )
    surface_DrawRect( x + ScrEx.Get.TabBarWidth, y, w - ScrEx.Get.TabBarWidth, h )

    surface_SetDrawColor( Settings.GetColor( Settings.Theme.TopSolid ) )
    surface_DrawRect( x + ScrEx.Get.TabBarWidth, y, w - ScrEx.Get.TabBarWidth, 30 )

    surface_SetDrawColor( Settings.GetColor( Settings.Theme.Outline ) )
    surface_DrawRect( x + ScrEx.Get.TabBarWidth - 2, y, 2, h )
    surface_DrawRect( x + ScrEx.Get.TabBarWidth - 2, y + 28, w - ScrEx.Get.TabBarWidth - 2, 2 )

    DrawEx.SetFont( "LogoText" ) 
    tw, th = DrawEx.GetTextSize( "ULTIMATE" )
    shift = ( ScrEx.Get.TabBarWidth / 2 ) - tw / 2 
    pad = ScrEx.Get.TabBarWidth / 2 - ScrEx.Get.TabWidth / 2

    surface_SetTextColor( Settings.GetColor( Settings.Theme.LogoText ) )
    surface_SetTextPos( x + shift, y + shift )
    surface_DrawText( "ULTIMATE" )

    DrawEx.SetFont( "MenuFont" )
    shift = y + 86
    spad = ( ScrEx.Get.TabHeight - ScrEx.Get.IconSize ) / 2

    for i = 1, #InterfaceEx.Tabs do
        data = InterfaceEx.Tabs[ i ]
        inrect = MouseEx.InRect( x + pad, shift, ScrEx.Get.TabWidth, ScrEx.Get.TabHeight )

        surface_SetDrawColor( Settings.GetColor( Settings.Theme[ ( InterfaceEx.ActiveTab == i and "Active" ) or ( inrect and "Hovered" ) or "Normal" ] ) )
        surface_DrawRect( x + pad, shift, ScrEx.Get.TabWidth, ScrEx.Get.TabHeight ) 

        surface_SetDrawColor( Settings.GetColor( Settings.Theme[ ( InterfaceEx.ActiveTab == i and "TextActive" ) or ( inrect and "TextHovered" ) or "TextNormal" ] ) )
        surface_SetMaterial( data.Icon )
        surface_DrawTexturedRect( x + spad + pad, shift + spad, ScrEx.Get.IconSize, ScrEx.Get.IconSize )
        
        surface_SetTextColor( Settings.GetColor( Settings.Theme[ ( InterfaceEx.ActiveTab == i and "TextActive" ) or ( inrect and "TextHovered" ) or "TextNormal" ] ) )
        DrawEx.DrawText( data.Name, x + spad + pad + ScrEx.Get.IconSize, shift + ScrEx.Get.IconSize / 2 )

        if inrect and focus and InputEx.IsPressed[ MOUSE_LEFT ] then
            InterfaceEx.ActiveTab = i
        end
        
        shift = shift + ScrEx.Get.TabHeight + 4

        if InterfaceEx.ActiveTab == i then
            for s = 1, #data.SubTabs do
                subdata = data.SubTabs[ s ]
                inrect = MouseEx.InRect( x + pad, shift, ScrEx.Get.TabWidth, ScrEx.Get.TabHeight )

                surface_SetDrawColor( Settings.GetColor( Settings.Theme[ ( data.Active == s and "Active" ) or ( inrect and "Hovered" ) or "Normal" ] ) )
                surface_DrawRect( x + pad, shift, pad / 2, ScrEx.Get.TabHeight )  

                surface_SetTextColor( Settings.GetColor( Settings.Theme[ ( data.Active == s and "SubActive" ) or ( inrect and "SubHovered" ) or "SubNormal" ] ) )
                DrawEx.DrawText( subdata[ 1 ], x + ScrEx.Get.TabHeight, shift + ScrEx.Get.IconSize / 2 )

                if inrect and focus and InputEx.IsPressed[ MOUSE_LEFT ] then
                    data.Active = s
                end

                shift = shift + ScrEx.Get.TabHeight + 4
            end 
        end
    end

    Context.x = x + 210
    Context.y = y + 36

    local Data = InterfaceEx.Tabs[ InterfaceEx.ActiveTab ]
    Data.SubTabs[ Data.Active ][ 2 ]( Context.x, Context.y )

    render_SetScissorRect( 0, 0, 0, 0, false )
end 

InterfaceEx.CreateFrame( 900, 700, "FrameWidth", "FrameHeight", true, InterfaceEx.ShouldDrawMenu, InterfaceEx.FrameRender, InterfaceEx.FrameThink )
InterfaceEx.Update()

// Hookies 
local HooksEx = { List = {} }

function HooksEx.Add( event, func )
    HooksEx.List[ #HooksEx.List + 1 ] = { event, string_upper( event ), func }

    hook_Add( event, string_upper( event ), func )
end

HooksEx.Add( "Think", function()
    local HSV = Hue( ( CurrentTime * ColorEx.SinSpeed ) % 360, 1, 1 )

    for i = 1, 113 do 
        InputEx.IsDown[ i ] = InputEx.IsKeyDown( i ) 
        InputEx.IsPressed[ i ] = InputEx.WasDown[ i ] != InputEx.IsDown[ i ] and not InputEx.IsDown[ i ] 
        InputEx.WasDown[ i ] = InputEx.IsKeyDown( i ) 
    end

    CurrentTime = GetCurTime()
    RenderTime = GetFrameTime()

    ColorEx.Rainbow = ColorEx.Update( math_Max( ColorEx.SinMin, HSV.r ), math_Max( ColorEx.SinMin, HSV.g ), math_Max( ColorEx.SinMin, HSV.b ), 255, 1 )
    TableEx.ListNumeric( ColorEx.Trans, ColorEx.Transit )
end )

HooksEx.Add( "DrawOverlay", function()
    InterfaceEx.Render()

end )

HooksEx.Add( "OnScreenSizeChanged", function( oldw, oldh, neww, nehh )
    ScrEx.Update()
    InterfaceEx.Update()
end )