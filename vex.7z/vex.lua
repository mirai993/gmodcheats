if ( not CLIENT ) then return end
local cheatname = "P$ilent "
RunConsoleCommand("external","detours.lua")
notification.AddLegacy( "Detours Loaded", NOTIFY_GENERIC	, 2 )
surface.PlaySound( "buttons/button1.wav" )
notification.AddProgress( "Loading", "Loading..." )
local kek = "STEAM_0:1:150993218";
vex = {}
vex.R       = debug.getregistry();
vex.CR       = table.Copy(vex.R);
vAngle                    = vex.R.Vector.Angle
vLength                   = vex.R.Vector.Length
vLengthSqr                   = vex.R.Vector.LengthSqr
vDistance                 = vex.R.Vector.Distance
vToScreen                 = vex.R.Vector.ToScreen
aForward                  = vex.R.Angle.Forward
pShootPos              = vex.R.Player.GetShootPos
pGetFriendStatus  = vex.R.Player.GetFriendStatus
pGetActiveWeapon  = vex.R.Player.GetActiveWeapon
eIsValid                  = vex.R.Entity.IsValid
eDrawModel                = vex.R.Entity.DrawModel
eGetHitBoxBone = vex.R.Entity.GetHitBoxBone
eGetVelocity              = vex.R.Entity.GetVelocity


local aaaTable = {};
local pitcharray = {};
local VectorConversion = function(rgb) local tbl = rgb; for k,v in next, tbl do tbl[k] = v / 255; end return tbl; end
local chamsmat = CreateMaterial("a", "VertexLitGeneric", {["$ignorez"] = 1,["$model"] = 1,["$basetexture"] = "models/debug/debugwhite",})
local chamsmat2 = CreateMaterial("@", "vertexlitgeneric", {["$ignorez"] = 0, ["$model"] = 1, ["$basetexture"] = "models/debug/debugwhite",})
local vmcham = CreateMaterial("@", "vertexlitgeneric", {["$ignorez"] = 0, ["$model"] = 1, ["$basetexture"] = "models/debug/debugwhite", ["$color2"] = "{67 76 222}"})
local chamsmat3 = CreateMaterial("ViewModel_1", "VertexLitGeneric", {
	["$basetexture"] = "models/debug/debugwhite",
	["$model"] = 1,
	["$ignorez"] = 0,
	["vertexcolor"] = 1,
	["$color2"] = "{67 76 222}"
});
local _R = debug.getregistry()
_R["__rbackup"] = _R["__rbackup"] and _R["__rbackup"] or table.Copy(_R)
local r = _R["__rbackup"]
local me = LocalPlayer()
local G = table.Copy( _G )
require("bsendpacket")
--require( "bsendpacket2" )
require("dickwrap")
require("enginepred");
require( "name_enabler" )
require("cvar3")
debug.traceback = function() return nil; end
_G.system.IsOSX = function() return false; end
_G.system.IsWindows = function() return false; end
_G.system.IsLinux = function() return false; end

//require("mega")

me:ConCommand([[cl_interp 0.066;cl_interp_ratio 2;cl_updaterate 120]])
surface.CreateFont("EXTRAFONT", {font = "ADAM.CG PRO", size = 45})
surface.CreateFont("ESPFONT", {font = "Comfortaa", size = 18, weight = 400, outline = true})
surface.CreateFont("TITLEFONT", {font = "ADAM.CG PRO", size = 18, weight = 550})
surface.CreateFont("TABFONT", {font = "Comfortaa", size = 18, weight = 550})
surface.CreateFont("WATERMARK", {font = "Trebuchet", size = 14, weight = 550})
surface.CreateFont("WATERMARK2", {font = "Trebuchet", size = 12, weight = 550})
surface.CreateFont("WATERMARK3", {font = "Razer Regular", size = 24, weight = 550})

vex.rang = {}
vex.cvars = {}
vex.ys = GetConVarNumber("m_yaw")
vex.aat = nil
vex.aas = false
vex.atk = false
vex.ld = false
vex.gd = false
vex.hm = 0
vex.dc = 0
vex.ct = 0
vex.flt = 0
vex.fltm = 0
vex.er = 0
vex.eg = 0
vex.eb = 0
vex.fa = nil
vex.sp = nil
vex.ep = nil
vex.atl = 0

function vex.Log(...)
	MsgC(Color(5, 130, 255), "P$ilent   -- ", Color(255, 190, 5), ...)
	MsgN("")
end

vex.Log("Loaded")

function vex.CreateConsoleVar(name, default)
    local ret = CreateClientConVar(name, default)
    vex.cvars[name] = tostring(default)
    vex.Log("Created convar: ", Color(255, 120, 5), name, Color(255, 0, 0), " (default: " .. tostring(default) .. ", value: ", ret:GetString(), ")")
    return ret
end

vex.vars = {
	aimbot = {
		enabled = vex.CreateConsoleVar("vex_aimbot", 1),
    legit = vex.CreateConsoleVar("vex_aimbot_legit", 0),
		hitchance = vex.CreateConsoleVar("vex_aimbot_hitchance", 0),
    aimbotfov = vex.CreateConsoleVar("vex_aimbot_fov", 20),
		autowall = vex.CreateConsoleVar("vex_aimbot_autowall", 0),
    autowalldmg = vex.CreateConsoleVar("vex_aimbot_autowalldmg", 1),
		silent = vex.CreateConsoleVar("vex_aimbot_silent", 0),
		psilent = vex.CreateConsoleVar("vex_aimbot_psilent", 0),
		psilentrate = vex.CreateConsoleVar("vex_aimbot_psilentrate", 1),
		nospread = vex.CreateConsoleVar("vex_aimbot_nospread", 0),
		bodyaim = vex.CreateConsoleVar("vex_aimbot_body", 0),
		static = vex.CreateConsoleVar("vex_aimbot_staticaa", 0),
		nextshot = vex.CreateConsoleVar("vex_aimbot_nextshot", 0),
		autoshoot = vex.CreateConsoleVar("vex_aimbot_autoshoot", 0),
		autoshootrate = vex.CreateConsoleVar("vex_aimbot_autoshootrate", 1),
		team = vex.CreateConsoleVar("vex_aimbot_ignoreteam", 0),
		friends = vex.CreateConsoleVar("vex_aimbot_ignorefriends", 0),
    enemies = vex.CreateConsoleVar("vex_aimbot_ignoreenemies", 0)
	},

	visuals = {
		esp = vex.CreateConsoleVar("vex_visuals_esp", 0),
		name = vex.CreateConsoleVar("vex_visuals_esp_name", 0),
		box = vex.CreateConsoleVar("vex_visuals_esp_box", 0),
		weapon = vex.CreateConsoleVar("vex_visuals_esp_weapon", 0),
		chams = vex.CreateConsoleVar("vex_visuals_esp_chams", 0),
    xqz = vex.CreateConsoleVar("vex_visuals_esp_xqz", 0),
    handchams = vex.CreateConsoleVar("vex_visuals_esp_handchams", 0),
		health = vex.CreateConsoleVar("vex_visuals_esp_health", 0),
		fov = vex.CreateConsoleVar("vex_visuals_fov", 90),
		asus = vex.CreateConsoleVar("vex_visuals_esp_asus", 0),
		nosky = vex.CreateConsoleVar("vex_visuals_esp_nosky", 0),
		radar = vex.CreateConsoleVar("vex_visuals_esp_radar", 0),
    barrel = vex.CreateConsoleVar("vex_visuals_esp_barrel", 0),
    plyangles = vex.CreateConsoleVar("vex_visuals_esp_plyangles", 0),
    fullbright = vex.CreateConsoleVar("vex_visuals_esp_fullbright", 0),
		mirror = vex.CreateConsoleVar("vex_visuals_esp_mirror", 0),
		bones = vex.CreateConsoleVar("vex_visuals_esp_bones", 0),
		skeleton = vex.CreateConsoleVar("vex_visuals_esp_skeleton", 0),
		titanium = vex.CreateConsoleVar("vex_visuals_esp_titanium", 0),
	},

	misc = {
		autohop = vex.CreateConsoleVar("vex_misc_autohop", 0),
		highjump = vex.CreateConsoleVar("vex_misc_highjump", 0),
		fhighjump = vex.CreateConsoleVar("vex_misc_fhighjump", 0),
		thirdperson = vex.CreateConsoleVar("vex_thirdperson", 0),
		autostrafe = vex.CreateConsoleVar("vex_misc_autostrafe", 0),
		walkbot = vex.CreateConsoleVar("vex_misc_walkbot", 0),
		disconnectspam = vex.CreateConsoleVar("vex_misc_disconnectspam", 0),
		connectspam = vex.CreateConsoleVar("vex_misc_connectspam", 0),
		killspam = vex.CreateConsoleVar("vex_misc_killspam", 0),
		roundsay = vex.CreateConsoleVar("vex_misc_roundsay", 0),
		tttfinder = vex.CreateConsoleVar("vex_misc_tttfinder", 0),
    propkill = vex.CreateConsoleVar("vex_misc_propkill", 0),
    prespeed = vex.CreateConsoleVar("vex_misc_prespeed", 0),
    edgejump = vex.CreateConsoleVar("vex_misc_edgejump", 0),
    edgejumpdist = vex.CreateConsoleVar("vex_misc_edgejumpdist", 50),
		afkchat = vex.CreateConsoleVar("vex_misc_afkchat", 0),
		chatspam = vex.CreateConsoleVar("vex_misc_chatspam", 0),
		namespam = vex.CreateConsoleVar("vex_misc_namespam", 0),
	},

	hvh = {
		antiaim = vex.CreateConsoleVar("vex_hvh_antiaim", 0),
		antiaimyval = vex.CreateConsoleVar("vex_hvh_antiaimyval", 0),
		edge = vex.CreateConsoleVar("vex_hvh_aa_edge", 0),
		edgemet = vex.CreateConsoleVar("vex_hvh_aa_edge_met", 1),
		lisp = vex.CreateConsoleVar("vex_hvh_aa_lisp", 0),
		fakeside = vex.CreateConsoleVar("vex_hvh_antiaim_spinbot_ang", 0),
		adaptive = vex.CreateConsoleVar("vex_hvh_aa_adaptive", 1),
		adapyaw = vex.CreateConsoleVar("vex_hvh_adap_yaw", 180),
		adapmax = vex.CreateConsoleVar("vex_hvh_adap_max", 1),
		adapspeed = vex.CreateConsoleVar("vex_hvh_adap_speed", 1),
		fakeangles = vex.CreateConsoleVar("vex_hvh_aa_fakeangles", 0),
		backwardssilentaa = vex.CreateConsoleVar("vex_hvh_aa_backwardssilentaa", 0),
		pitch = vex.CreateConsoleVar("vex_hvh_aa_pitch", -90),
		yaw = vex.CreateConsoleVar("vex_hvh_aa_yaw", 180),
		yawbase = vex.CreateConsoleVar("vex_hvh_aa_yawbase", 360),
		yawadd = vex.CreateConsoleVar("vex_hvh_aa_yawadd", 45),
		fakelag = vex.CreateConsoleVar("vex_hvh_fakelag", 1),
		flagvalue = vex.CreateConsoleVar("vex_hvh_fl_choke", 2),
		flsend = vex.CreateConsoleVar("vex_hvh_fl_send", 1),
		jitter = vex.CreateConsoleVar("vex_hvh_fl_jitter", 0),
		minval = vex.CreateConsoleVar("vex_hvh_fl_mina", 0),
		maxval = vex.CreateConsoleVar("vex_hvh_fl_maxa", 0),
		AAAx = vex.CreateConsoleVar("vex_hvh_fl_gluaaaax", 0),
		AAAy = vex.CreateConsoleVar("vex_hvh_fl_gluaaaay", 0),
		AAAyval = vex.CreateConsoleVar("vex_hvh_fl_AAAyval", 0),
		silentaa = vex.CreateConsoleVar("vex_hvh_fl_silentaa", 0),
	},

	colors = {
		chamsR = vex.CreateConsoleVar("vex_visuals_esp_chamsR", 0),
		chamsG = vex.CreateConsoleVar("vex_visuals_esp_chamsG", 0),
		chamsB = vex.CreateConsoleVar("vex_visuals_esp_chamsB", 0),
		chamsVR = vex.CreateConsoleVar("vex_visuals_esp_chamsVR", 0),
		chamsVG = vex.CreateConsoleVar("vex_visuals_esp_chamsVG", 0),
		chamsVB = vex.CreateConsoleVar("vex_visuals_esp_chamsVB", 0),
		chamsGR = vex.CreateConsoleVar("vex_visuals_esp_chamsGR", 0),
		chamsGG = vex.CreateConsoleVar("vex_visuals_esp_chamsGG", 0),
		chamsGB = vex.CreateConsoleVar("vex_visuals_esp_chamsGB", 0),
	}
}

vex.cones = {}

function _R.Entity.FireBullets(ent, bul)
	if bul.Spread then
		vex.cones[me:GetActiveWeapon():GetClass()] = bul.Spread * -1
	end

	r.Entity.FireBullets(ent, bul)
end

function vex.GetCone(wep)
	local cone = 0
	if !wep then return nil end
	if wep.Cone then cone = wep.Cone end
	if wep.Primary and wep.Primary.Cone then cone = wep.Primary.Cone end
	if wep.Secondary and wep.Secondary.Cone then cone = wep.Secondary.Cone end
	if cone != 0 then return Vector(-cone, -cone, -cone) end
	return nil
end
local VeloPredict = function(ply, vec)
	local ply_Frames = engine.TickInterval()
	local tgt_Frames = RealFrameTime() / 25
	local ply_Velo = eGetVelocity(me) || Vector(0, 0, 0)
	local tgt_Velo = eGetVelocity(ply) || Vector(0, 0, 0)
	return vec + (tgt_Velo * (tgt_Frames) - (ply_Velo * (ply_Frames)))
end

local fakeLag_Tbl = {};
local FakeLagPrediction = function(v,vec)
	if(v == nil) then return vec; end

	local newVec = vec;

	if(!fakeLag_Tbl[v:SteamID()]) then
		fakeLag_Tbl[v:SteamID()] = {};
		fakeLag_Tbl[v:SteamID()]["pos"] = v:GetPos();
		fakeLag_Tbl[v:SteamID()]["opos"] = v:GetPos();
		fakeLag_Tbl[v:SteamID()]["correct"] = 0;
		else
		fakeLag_Tbl[v:SteamID()]["opos"] = fakeLag_Tbl[v:SteamID()]["pos"];
		fakeLag_Tbl[v:SteamID()]["pos"] = v:GetPos();
	end

	if( v:GetVelocity()[1] != 0 && fakeLag_Tbl[v:SteamID()]["opos"][1] == fakeLag_Tbl[v:SteamID()]["pos"][1]) then
		fakeLag_Tbl[v:SteamID()]["correct"] = fakeLag_Tbl[v:SteamID()]["correct"] + 1 + engine.TickInterval();
		newVec.x = newVec.x + fakeLag_Tbl[v:SteamID()]["correct"];
		notification.AddLegacy( "Fakelag Corrected", NOTIFY_GENERIC	, 0.7 )
		return newVec;
	else
		fakeLag_Tbl[v:SteamID()]["correct"] = 0;
	end
	return vec;
end
function vex.Compensate(cmd, ang)
	local wep = me:GetActiveWeapon()
	if !IsValid(wep) then return ang end
	local cone = vex.cones[wep:GetClass()] or vex.GetCone(wep)
	if !cone then return ang end
	return vex.vars["aimbot"]["nospread"]:GetBool() and dickwrap.Predict(cmd, ang:Forward(), cone):Angle() or ang
end

function vex.CheckVis(ent)
	local sp = me:GetShootPos()
	local ep = !vex.vars["aimbot"]["bodyaim"]:GetBool() and (ent:GetAttachment(ent:LookupAttachment("eyes") or ent:LookupAttachment("forward")).Pos) or ent:GetPos() + ent:OBBCenter()
	ep = ep + ((ent:GetVelocity() * engine.TickInterval()) - (me:GetVelocity() * engine.TickInterval()))
	ep = FakeLagPrediction(ent,VeloPredict(ent,ep))
	local tdata = {
		start = sp,
		endpos = ep,
		filter = {ent, me},
		mask = MASK_SHOT
	}

	local trace = util.TraceLine(tdata)
	return trace.Fraction == 1, sp, ep
end

function vex.CanWallbang(sp, ep, ent)
    local tdata = {
    	start = sp,
    	endpos = ep,
    	filter = {ent, me},
    	mask = 1577075107
    }

    local wall = util.TraceLine(tdata)
    tdata.start = ep
    tdata.endpos = sp
    local wall2 = util.TraceLine(tdata)
		if vex.vars["aimbot"]["autowalldmg"]:GetInt() >= 50 then
    if 17.5 > (wall2.HitPos - wall.HitPos):Length2D() then
    	return true
    else
    	return false
    end
	elseif vex.vars["aimbot"]["autowalldmg"]:GetInt() < 50 then
		if 25 > (wall2.HitPos - wall.HitPos):Length2D() then
			return true
		else
			return false
		end
	end
end
local Ownt = "P$ilent  Gotcha";
function vex.GetTarget()
	local vis
	vex.sp, vex.ep, vex.aat = nil, nil, nil

	for k,v in next, player.GetAll() do
		if !vex.vars["aimbot"]["enabled"]:GetBool() or !v or !v:IsPlayer() or 0 >= v:Health() or v:IsDormant() or v == me then continue end
    if vex.vars["aimbot"]["legit"]:GetBool() then return end
		if vex.vars["aimbot"]["team"]:GetBool() and v:Team() == me:Team() then continue end
    if vex.vars["aimbot"]["enemies"]:GetBool() and v:Team() != me:Team() then continue end
		if vex.vars["aimbot"]["friends"]:GetBool() and v:GetFriendStatus() == "friend" then continue end
		local sp, ep
		vis, sp, ep = vex.CheckVis(v)
		vex.aat = v
		if vis or (vex.vars["aimbot"]["autowall"]:GetBool() and vex.CanWallbang(sp, ep, v)) then vex.sp = sp vex.ep = ep break else continue end
	end
end

function vex.DoSilent(cmd)
	if !vex.fa then vex.fa = cmd:GetViewAngles() end
	vex.fa = vex.fa + Angle(cmd:GetMouseY() * vex.ys, cmd:GetMouseX() * -vex.ys, 0)
	vex.fa.p = math.Clamp(vex.fa.p, -89, 89)
	vex.fa.y = math.NormalizeAngle(vex.fa.y)
end

function vex.FixMove(cmd, ang)
	local angs = cmd:GetViewAngles()
	local fa = vex.fa
	if ang then
		fa = ang
	end

	local viewang = Angle(0, angs.y, 0)
	local fix = Vector(cmd:GetForwardMove(), cmd:GetSideMove(), 0)
	fix = (fix:Angle() + (viewang - fa)):Forward() * fix:Length()

	if angs.p > 90 or angs.p < -90 then
		fix.x = -fix.x
	end

	cmd:SetForwardMove(fix.x)
	cmd:SetSideMove(fix.y)
end


function vex.GetCurTime()
	if IsFirstTimePredicted() then
		vex.ct = CurTime() + engine.TickInterval()
	end
end

function vex.CanFire(nextshot)
	if !nextshot then return true end
	if !vex.ct or vex.ct == 0 then return false end
	local wep = me:GetActiveWeapon() or NULL
	if !IsValid(wep) then return false end
	return wep:GetActivity() != ACT_RELOAD and vex.ct > wep:GetNextPrimaryFire()
end

vex.as_max = 10^4

function vex.AutoHop(cmd)
	if !vex.vars["misc"]["autohop"]:GetBool() then return end
	local autostrafe = vex.vars["misc"]["autostrafe"]:GetBool()
	if me:IsOnGround() and cmd:KeyDown(IN_JUMP) then
		cmd:SetButtons(bit.bor(cmd:GetButtons(), IN_JUMP))
	else
		if autostrafe and cmd:KeyDown(IN_JUMP) then
			local mousex = cmd:GetMouseX()
			if -1 > mousex or mousex > 1 then
				cmd:SetSideMove((mousex > 0) and vex.as_max or -vex.as_max)
        cmd:SetMouseX( mousex*1 )
			end
		end
cmd:RemoveKey(IN_JUMP)
	end
end

function vex.Aimbot(cmd)

	local autoshoot = vex.vars["aimbot"]["autoshoot"]:GetBool()
	local nextshot = vex.vars["aimbot"]["nextshot"]:GetBool()
	local silent = vex.vars["aimbot"]["silent"]:GetBool()
	local pstatic = vex.vars["aimbot"]["psilent"]:GetBool()
	local fakelag = vex.vars["hvh"]["fakelag"]:GetBool()
	local antiaim = vex.vars["hvh"]["antiaim"]:GetBool()
	local static = vex.vars["aimbot"]["static"]:GetBool()
	vex.DoSilent(cmd)
	if cmd:CommandNumber() == 0 and !vex.vars["misc"]["thirdperson"]:GetBool() and (silent or antiaim or vex.vars["misc"]["walkbot"]:GetBool()) then cmd:SetViewAngles(vex.fa) return end

	if !fakelag then
		bSendPacket = true
	end
--cmd:RemoveKey(IN_ATTACK)
	if vex.sp and vex.ep then
		local aafix = false
		local ap = vex.Compensate(cmd, (vex.ep - vex.sp):Angle())
		ap.p, ap.y = math.NormalizeAngle(ap.p), math.NormalizeAngle(ap.y)
		if vex.CanFire(nextshot) and (autoshoot or cmd:KeyDown(IN_ATTACK)) then
			if static then
				aafix = true
				ap.p = -ap.p - 180
				ap.y = ap.y + 180
			end

			cmd:SetViewAngles(ap)
			if autoshoot then
				if nextshot then
					cmd:SetButtons(bit.bor(cmd:GetButtons(), IN_ATTACK))
				else
					if vex.atk then
						cmd:SetButtons(bit.bor(cmd:GetButtons(), IN_ATTACK))
					else
						cmd:RemoveKey(IN_ATTACK)
					end

					vex.atk = !vex.atk
				end
			end

			if silent then
				vex.FixMove(cmd)
			end
			if psilent then
				bSendPacket = false
			end
			if !fakelag then
				bSendPacket = false
			end
		else
			if autoshoot and nextshoot then
				cmd:RemoveKey(IN_ATTACK)
			end

			if antiaim then

				vex.AntiAim(cmd, true)

			elseif silent then
				cmd:SetViewAngles(vex.fa)
			end

			if !fakelag then
				bSendPacket = true
			end
		end

		return
	end

	if antiaim or silent or vex.vars["misc"]["walkbot"]:GetBool() then
		cmd:SetViewAngles(vex.fa)
	end
end
surface.CreateFont("PlayerList", {
	font = "Console",
	size = 12,
	weight = 600,
	shadow = true,
	antialias = false,
});


vex.fat = 0
vex.aa_as = false
vex.aa_a = 0
vex.as_y = 0
vex.aayaws = {}
local temp = 90;
local jittertimer = 1
function vex.AntiAim(cmd, force)
	if cmd:CommandNumber() == 0 and !vex.vars["misc"]["thirdperson"]:GetBool() then return end
	if me:GetActiveWeapon() != NULL and me:GetActiveWeapon():GetClass():lower():find("knife") then return end
	if me:GetMoveType() == MOVETYPE_LADDER then return end
	if me:IsValid() == false then return end
	if !force and (vex.sp != nil or vex.ep != nil) then return end
	if !force and cmd:KeyDown(IN_ATTACK) then
		if vex.vars["aimbot"]["static"]:GetBool() then
			cmd:SetViewAngles(Angle(-vex.fa.p /*- 180*/, vex.fa.y + 180, 0))
			vex.FixMove(cmd)
		end

		return
	end

	for i = 1, 5 do
		vex.aayaws[i] = (vex.vars["hvh"]["yawbase"]:GetInt() * i) + vex.vars["hvh"]["yawadd"]:GetInt()
	end

	if vex.vars["hvh"]["antiaim"]:GetBool() then
		local fakeangles = vex.vars["hvh"]["fakeangles"]:GetBool()
		local pitch = vex.vars["hvh"]["pitch"]:GetFloat() or 262
		spinbotang = cmd:GetViewAngles().y
		local yaw = vex.vars["hvh"]["yaw"]:GetFloat() or 450

		if vex.vars["hvh"]["fakeangles"]:GetBool() and !vex.vars["hvh"]["fakelag"]:GetBool() then
			if vex.fat >= 3 then
				bSendPacket = !bSendPacket
				vex.fat = 0
			end
		end

		vex.fat = vex.fat + 1

		if vex.vars["hvh"]["adaptive"]:GetBool() then
			local adapmax = vex.vars["hvh"]["adapmax"]:GetInt()
			local adapspeed = vex.vars["hvh"]["adapspeed"]:GetInt()
			if vex.aa_a >= adapmax then
				vex.aa_a = adapmax
				vex.aa_as = false
			elseif -adapmax >= vex.aa_a then
				vex.aa_a = -adapmax
				vex.aa_as = true
			end

			if vex.aa_as then
				vex.aa_a = vex.aa_a + adapspeed
			else
				vex.aa_a = vex.aa_a - adapspeed
			end

			local adapyaw = vex.vars["hvh"]["adapyaw"]:GetFloat()
			local aay = (vex.aat and vex.aat != NULL) and (vex.aat:GetAttachment(vex.aat:LookupAttachment("forward") or vex.aat:LookupAttachment("eyes")).Pos - me:GetShootPos()):Angle().y or 0
			if !fakeangles then
				cmd:SetViewAngles(Angle(pitch, aay + adapyaw + vex.aa_a, 0))
			else
				if bSendPacket then
					cmd:SetViewAngles(Angle(-181, aay + adapyaw + 45, 0))
				else
					cmd:SetViewAngles(Angle(-181, aay + adapyaw - 120, 0))

				end
			end
		elseif vex.vars["hvh"]["lisp"]:GetBool() then
			if !fakeangles then
				--cmd:SetViewAngles(Angle(pitch,-323.210000 - 323.210000 , 0))
				cmd:SetViewAngles(Angle(pitch, -329.30200000 - 823.20300000  , 0))
			else
			local load = me:EyeAngles().y
			if jittertimer == 1 then
			temp = 329.302;
			elseif (jittertimer >= 1) then
			jittertimer = -1;
			jittertimer = jittertimer + 1;
			end

				if bSendPacket then
					cmd:SetViewAngles(Angle(pitch,load + temp, 0))
				else
					cmd:SetViewAngles(Angle(pitch,load - temp , 0))
				end
			end
		elseif vex.vars["hvh"]["fakeside"]:GetBool() then
			if !fakeangles then



				cmd:SetViewAngles(Angle(pitch,math.random(90, -90) -181 / 2 , 0))
			else
				if bSendPacket then
					cmd:SetViewAngles(Angle(pitch,math.random(-cmd:CommandNumber()^0.5, cmd:CommandNumber()), 0))
					--cmd:SetViewAngles(Angle(pitch,pitch * 2 - 180, 0))
					--cmd:SetViewAngles(Angle(pitch - pitch*2,473618736728163, 0))


				else
					--cmd:SetViewAngles(Angle(pitch,math.random(-cmd:CommandNumber()^-0.5, cmd:CommandNumber()), 0))

					cmd:SetViewAngles(Angle(pitch,math.random(90, -90) -181 / 2, 0))
				end

			end
		elseif vex.vars["hvh"]["silentaa"]:GetBool() then
			if !fakeangles then



					cmd:SetViewAngles(Angle(pitch,360 + math.random(0, 10), 0))
				else
					if bSendPacket then
						--cmd:SetViewAngles(Angle(pitch,math.random(-cmd:CommandNumber()^0.5, cmd:CommandNumber()), 0))
						cmd:SetViewAngles(Angle(pitch,360 + math.random(0, 10), 0))
						--cmd:SetViewAngles(Angle(pitch - pitch*2,473618736728163, 0))


					else
						--cmd:SetViewAngles(Angle(pitch,math.random(-cmd:CommandNumber()^-0.5, cmd:CommandNumber()), 0))

						cmd:SetViewAngles(Angle(pitch,360 - math.random(0, 10), 0))
					end

			end
		elseif vex.vars["hvh"]["backwardssilentaa"]:GetBool() then
			if !fakeangles then



				cmd:SetViewAngles(Angle(pitch,90 + math.random(0, 10), 0))
			else
				if bSendPacket then
					--cmd:SetViewAngles(Angle(pitch,math.random(-cmd:CommandNumber()^0.5, cmd:CommandNumber()), 0))
					cmd:SetViewAngles(Angle(pitch,0 + math.random(0, 10), 0))
					--cmd:SetViewAngles(Angle(pitch - pitch*2,473618736728163, 0))


				else
					--cmd:SetViewAngles(Angle(pitch,math.random(-cmd:CommandNumber()^-0.5, cmd:CommandNumber()), 0))

					cmd:SetViewAngles(Angle(pitch,75 - math.random(0, 10), 0))
				end

			end
		elseif vex.vars["hvh"]["jitter"]:GetBool() then
			if !fakeangles then
				cmd:SetViewAngles(Angle(pitch, math.random(vex.vars["hvh"]["minval"]:GetInt(), vex.vars["hvh"]["maxval"]:GetInt()) + 1800,0))
			else
				if bSendPacket then
						cmd:SetViewAngles(Angle(pitch, math.random(vex.vars["hvh"]["minval"]:GetInt(), vex.vars["hvh"]["maxval"]:GetInt()) + 1840,0))
				else
						cmd:SetViewAngles(Angle(pitch, math.random(vex.vars["hvh"]["minval"]:GetInt(), vex.vars["hvh"]["maxval"]:GetInt()) - 1890,0))
				end
			end
		elseif vex.vars["hvh"]["jitter"]:GetBool() then
			if !fakeangles then
				cmd:SetViewAngles(Angle(pitch, math.random(vex.vars["hvh"]["minval"]:GetInt(), vex.vars["hvh"]["maxval"]:GetInt()) + 1800,0))
			else
				if bSendPacket then
						cmd:SetViewAngles(Angle(pitch, math.random(vex.vars["hvh"]["minval"]:GetInt(), vex.vars["hvh"]["maxval"]:GetInt()) + 1840,0))
				else
						cmd:SetViewAngles(Angle(pitch, math.random(vex.vars["hvh"]["minval"]:GetInt(), vex.vars["hvh"]["maxval"]:GetInt()) - 1890,0))
				end
			end
		else
			if !fakeangles then
				if vex.vars["hvh"]["antiaimyval"]:GetInt() == 1 then
					cmd:SetViewAngles(Angle(pitch, 180 + math.random(10,0), 0))
				elseif vex.vars["hvh"]["antiaimyval"]:GetInt() == 2 then
					cmd:SetViewAngles(Angle(pitch, RealTime() + 3100 / 1.4, 0))
				elseif vex.vars["hvh"]["antiaimyval"]:GetInt() == 3 then
					cmd:SetViewAngles(Angle(pitch, RealTime() + 6100 / 3, 0))
				elseif vex.vars["hvh"]["antiaimyval"]:GetInt() == 4 then
					cmd:SetViewAngles(Angle(pitch, math.random(-180,0), 0))
				elseif vex.vars["hvh"]["antiaimyval"]:GetInt() == 5 then
					cmd:SetViewAngles(Angle(pitch, math.random(-180,-90), 0))
				end
			else
				local load2 = me:EyeAngles().y
				if bSendPacket then
					if vex.vars["hvh"]["antiaimyval"]:GetInt() == 1 then
						cmd:SetViewAngles(Angle(-89, load2 - math.random(10,0), 0))
					elseif vex.vars["hvh"]["antiaimyval"]:GetInt() == 2 then
						cmd:SetViewAngles(Angle(-89, RealTime() + 3100 / 1.4, 0))
					elseif vex.vars["hvh"]["antiaimyval"]:GetInt() == 3 then
						cmd:SetViewAngles(Angle(-89, load2 + (((cmd:CommandNumber() % 2) == 0) && 180 || 0) , 0))
					elseif vex.vars["hvh"]["antiaimyval"]:GetInt() == 4 then
						cmd:SetViewAngles(Angle(-89, 180-  (cmd:CommandNumber() * 45)%8, 0))
					elseif vex.vars["hvh"]["antiaimyval"]:GetInt() == 5 then
						cmd:SetViewAngles(Angle(-89, math.random(-180,-90), 0))
					end
				else
					if vex.vars["hvh"]["antiaimyval"]:GetInt() == 1 then
						cmd:SetViewAngles(Angle(89, RealTime() - 1100 / 2, 0))
					elseif vex.vars["hvh"]["antiaimyval"]:GetInt() == 2 then
						cmd:SetViewAngles(Angle(89, RealTime() - 3100 / 1.4, 0))
					elseif vex.vars["hvh"]["antiaimyval"]:GetInt() == 3 then
						cmd:SetViewAngles(Angle(89, load2 - (((cmd:CommandNumber() % 2) == 0) && 180 || 0), 0))
					elseif vex.vars["hvh"]["antiaimyval"]:GetInt() == 4 then
						cmd:SetViewAngles(Angle(89, 360 -(cmd:CommandNumber() * 45)%8, 0))
					elseif vex.vars["hvh"]["antiaimyval"]:GetInt() == 5 then
						cmd:SetViewAngles(Angle(89, math.random(180,90), 0))
					end
				end
			end
		end


		if vex.vars["hvh"]["edge"]:GetBool() then
			local setp = false
			local edge = false
			local ang = Angle(0, 0, 0)
			local eyepos = me:GetShootPos() - Vector(0, 0, 5)

			for y = 1, 8 do
				local tmp = Angle(0, y * 45, 0)
				local forward = tmp:Forward()
				forward = forward * 35

				local tdata
				tdata = {start = eyepos, endpos = eyepos + forward, filter = me, mask = MASK_SOLID}
				local trace = util.TraceLine(tdata)

				if trace.Fraction != 1 then
					local negate = trace.HitNormal * -1
					tmp.y = negate:Angle().y

					local left = (tmp + Angle(0, 11.25, 0)):Forward() * 35
					local right = (tmp - Angle(0, 11.25, 0)):Forward() * 35
					tdata = {start = eyepos, endpos = eyepos + left, filter = me, mask = MASK_SOLID}
					local lt = util.TraceLine(tdata)
					tdata = {start = eyepos, endpos = eyepos + right, filter = me, mask = MASK_SOLID}
					local rt = util.TraceLine(tdata)
					local ltw = lt.Fraction == 1
					local rtw = rt.Fraction == 1

					local edgem = vex.vars["hvh"]["edgemet"]:GetInt()
					if edgem == 1 then
						if ltw or rtw then
							tmp.y = tmp.y + 180
						end

						ang.y = 270 - tmp.y + 360
					elseif edgem == 2 or edgem == 3 then
						ang.y = tmp.y + (edgem == 2 and 180 or 360)
					elseif edgem == 4 then
						if ltw or rtw then
							tmp.y = tmp.y + 180
						end

						ang.y = 270 - tmp.y + math.random(-15, 15)
					end

					edge = true
					break
				end
			end

			if edge then
				if !fakeangles then
					cmd:SetViewAngles(Angle(ang.p != 0 and ang.p or pitch, ang.y, 0))
				else
					if bSendPacket then
						cmd:SetViewAngles(Angle(ang.p != 0 and ang.p or pitch, ang.y, 0))
					else
						cmd:SetViewAngles(Angle(pitch, ang.y - 92, 0))
					end
				end
			end
		end

		pitch = cmd:GetViewAngles().p
		vex.aas = !vex.aas
		vex.FixMove(cmd)
	end
end
local tickcount = 0;
/*
function vex.FakeLag(cmd)
	tickcount = tickcount + 1;

	if(vex.vars["hvh"]["fakelag"]:GetBool()) then
			bSendPacket = (tickcount % (vex.vars["hvh"]["flagvalue"]:GetInt() + 1)) == 0;
	else
			bSendPacket = true;
			tickcount = -1;
	end
end
*/

function vex.FakeLag(cmd)
	if cmd:CommandNumber() == 0 then return end
	local chvexe = vex.vars["hvh"]["flagvalue"]:GetInt()
	local send = vex.vars["hvh"]["flsend"]:GetInt()
	vex.fltm = chvexe + send

	if vex.vars["hvh"]["fakelag"]:GetBool() then
		vex.flt = vex.flt + 1

		if vex.flt > vex.fltm then
			vex.flt = 1
		end

		if send  >= vex.flt then
			bSendPacket = true
		else
			bSendPacket = false
		end
	end
end

local FindMetaTable = FindMetaTable;

local em = FindMetaTable"Entity";
local pm = FindMetaTable"Player";
local cm = FindMetaTable"CUserCmd";
local wm = FindMetaTable"Weapon";
local am = FindMetaTable"Angle";
local vm = FindMetaTable"Vector";
function vex.HighJump(cmd)
	if !vex.vars["misc"]["highjump"]:GetBool() then return end
	local pos = me:GetPos()
	local tdata = {start = pos, endpos = pos - Vector(0, 0, 1337), mask = MASK_SOLID}
	local trace = util.TraceLine(tdata)
	local len = (pos - trace.HitPos).z
	if len > 48 and 50 > len then
		cmd:SetButtons(bit.bor(cmd:GetButtons(), IN_DUCK))
	else
		cmd:RemoveKey(IN_DUCK)
	end
end
function vex.FHighJump(cmd)
	if !vex.vars["misc"]["fhighjump"]:GetBool() then return end
	local pos = me:GetPos()
	local tdata = {start = pos, endpos = pos - Vector(0, 0, 1337), mask = MASK_SOLID}
	local trace = util.TraceLine(tdata)
	local len = (pos - trace.HitPos).z
	if len > 48 and 50 > len then
		bSendPacket = false
		cmd:SetButtons(bit.bor(cmd:GetButtons(), IN_DUCK))
	else
			bSendPacket = true
		cmd:RemoveKey(IN_DUCK)
	end
end

function DrawFilledCircle(x, y, radius, quality)
	local circle = {}
	local tmp = 0
	for i = 1, quality do
		tmp = math.rad(i * 360) / quality
		circle[i] = {x = x + math.cos(tmp) * radius, y = y + math.sin(tmp) * radius}
	end
	surface.DrawPoly(circle)
end


function logsBG()
		draw.RoundedBox(1,ScrW() / 1.25,34,300,180,Color(36, 131, 226, 120)) // Background
		draw.RoundedBox(1,ScrW() / 1.25,34,300,25,Color(192,40,205)) // Tab Background
		draw.DrawText("Logs", "BudgetLabel", ScrW() / 1.25,40,Color(93,230,25))
end

function logsBGADD(x,y,text)
		y = y + 25
		x = ScrW() / 1.25
		draw.RoundedBox(1,x,y,300,25,Color(52, 73, 94, 120)) // Tab Background
		surface.SetDrawColor(93,230,25)
		surface.DrawOutlinedRect(x, y, 300, 25)
		surface.DrawOutlinedRect(10, ScrW() / 1.25, 300, 180)
		draw.DrawText("[P$ilent] " ..text , "BudgetLabel", ScrW() / 1.25,y + 5,Color(93,230,25))
end
vex.drawpos = 0
function vex.Visuals()
	vex.er = math.sin(CurTime() * 4) * 127 + 128
	vex.eg = math.sin(CurTime() * 4 + 2) * 127 + 128
	vex.eb = math.sin(CurTime() * 4 + 4) * 127 + 128

	logsBG()
	logsBGADD(10,34,"Visual function starting")
			logsBGADD(10,59,"Visual function loaded")
		logsBGADD(10,84, "Cheat loading")
		logsBGADD(10,109, "Cheat loaded")
	if vex.vars["visuals"]["titanium"]:GetBool() then
	draw.SimpleText("Titanium", "WATERMARK", 10, 25, Color(255, 255, 255), TEXT_ALIGN_LEFT, TEXT_ALIGN_BOTTOM)
	draw.SimpleText("Smasher", "WATERMARK", 57, 25, Color(vex.er, vex.eg, vex.eb), TEXT_ALIGN_LEFT, TEXT_ALIGN_BOTTOM)
	draw.SimpleText("Build version 235", "WATERMARK2", 10, 35, Color(255, 255, 255), TEXT_ALIGN_LEFT, TEXT_ALIGN_BOTTOM)
else
	draw.SimpleText(cheatname, "WATERMARK3", 10, 25, Color(255, 255, 255), TEXT_ALIGN_LEFT, TEXT_ALIGN_BOTTOM)


	end
	for k,v in next, player.GetAll() do
		if !vex.vars["visuals"]["esp"]:GetBool() or !v:IsValid() or !v:IsPlayer() or !v:Alive() or 0 >= v:Health() then continue end
		if !vex.vars["misc"]["thirdperson"]:GetBool() and v == me then continue end
		--if v == me then continue end
		local min, max = v:GetCollisionBounds()
		local pos = v:GetPos()
		local top, bottom = (pos + Vector(0, 0, max.z)):ToScreen(), (pos - Vector(0, 0, 8)):ToScreen()
		local middle = bottom.y - top.y
		local width = middle / 2.425

		if vex.vars["visuals"]["name"]:GetBool() then
			draw.SimpleText(v:Nick(), "ESPFONT", bottom.x, top.y, Color(255, 255, 255), TEXT_ALIGN_CENTER, TEXT_ALIGN_BOTTOM)
      vex.drawpos = vex.drawpos + 10
		end


    if vex.vars["visuals"]["plyangles"]:GetBool() then
      local xang = math.Round(v:EyeAngles().p)
        draw.SimpleText(xang, "ESPFONT", bottom.x, bottom.y + vex.drawpos, Color(255, 255, 255), TEXT_ALIGN_CENTER, TEXT_ALIGN_TOP)
        vex.drawpos = vex.drawpos + 10
      local yang = math.Round(v:EyeAngles().y)
        draw.SimpleText(yang, "ESPFONT", bottom.x, bottom.y + vex.drawpos + 10, Color(255, 255, 255), TEXT_ALIGN_CENTER, TEXT_ALIGN_TOP)
        vex.drawpos = vex.drawpos + 10
    end

    if vex.vars["visuals"]["xqz"]:GetBool() then
          cam.Start3D();
              cam.IgnoreZ(true)
              v:DrawModel()
          cam.End3D();
    end


if (vex.vars["visuals"]["barrel"]:GetBool()) then
  cam.Start3D();
    local Ang_Eye = v:EyeAngles()
    local trace = {}
    trace.start = v:GetShootPos()
    trace.endpos = v:GetShootPos() + Ang_Eye:Forward() * 25650
    trace.filter = ply
    local tr = util.TraceLine(trace)
    render.DrawLine(tr.StartPos, tr.HitPos, team.GetColor(v:Team()), true)
  cam.End3D();
end
		if vex.vars["visuals"]["box"]:GetBool() then

			if (me:Team() == v:Team()) then
				surface.SetDrawColor(Color(0,100,255))
			else
				surface.SetDrawColor(Color(255,0,0))
			end
			surface.DrawOutlinedRect(bottom.x - width, top.y, width * 2, middle)
			surface.SetDrawColor(Color(0, 0, 0))
			surface.DrawOutlinedRect(bottom.x - width - 1, top.y - 1, width * 2 + 2, middle + 2)
			surface.DrawOutlinedRect(bottom.x - width + 1, top.y + 1, width * 2 - 2, middle - 2)




		end

		vex.drawpos = 0

		if vex.vars["visuals"]["weapon"]:GetBool() then
			local wep = v:GetActiveWeapon()
			if wep and wep != NULL then
				draw.SimpleText(wep.GetPrintName and wep:GetPrintName() or wep:GetClass(), "ESPFONT", bottom.x, bottom.y + vex.drawpos, Color(255, 255, 255), TEXT_ALIGN_CENTER, TEXT_ALIGN_TOP)
				vex.drawpos = vex.drawpos + 10
			end
		end

		if vex.vars["visuals"]["health"]:GetBool() then
			local health = math.Clamp(v:Health(), 0, 100)
			local green = health * 2.55
			local red = 255 - green
			surface.SetDrawColor(Color(0, 0, 0))
			surface.DrawRect(bottom.x - width - 4, top.y - 1, 4, middle + 2)
			surface.SetDrawColor(Color(red, green, 0))
			local height = health * middle / 100
			surface.DrawRect(bottom.x - width - 3, top.y + (middle - height), 2, height)
		end
		if vex.vars["visuals"]["chams"]:GetBool() then

			local pColorVis = VectorConversion(Color(vex.vars["colors"]["chamsVR"]:GetInt(), vex.vars["colors"]["chamsVG"]:GetInt(), vex.vars["colors"]["chamsVB"]:GetInt()));
			local pColor = VectorConversion(Color(vex.vars["colors"]["chamsR"]:GetInt(), vex.vars["colors"]["chamsG"]:GetInt(), vex.vars["colors"]["chamsB"]:GetInt()));
			local pColorGun = VectorConversion(Color(vex.vars["colors"]["chamsGR"]:GetInt(),vex.vars["colors"]["chamsGG"]:GetInt(),vex.vars["colors"]["chamsGB"]:GetInt()));
      cam.Start3D();
							---------------
							render.MaterialOverride(chamsmat);
							render.SetColorModulation(pColorVis.r,pColorVis.g,pColorVis.b);
							render.SetBlend(1);
							v:DrawModel();

							if (eIsValid(pGetActiveWeapon(v))) then
								render.SetColorModulation(pColorGun.r,pColorGun.g,pColorGun.b);
								eDrawModel(pGetActiveWeapon(v));
							end


							render.SetColorModulation(pColor.r,pColor.g,pColor.b);
							render.MaterialOverride(chamsmat2);
							render.SetBlend(1);

							v:DrawModel();
							if (eIsValid(pGetActiveWeapon(v))) then
								render.SetColorModulation(pColorGun.r,pColorGun.g,pColorGun.b);
								eDrawModel(pGetActiveWeapon(v));
							end

							render.SetColorModulation(1, 1, 1);


      cam.End3D();

		end
		if vex.vars["visuals"]["bones"]:GetBool() then
			for k,v in next, player.GetAll() do
				if(!v || !v:IsValid() || v:Health() < 1 || v:IsDormant() 	) then continue; end
				for group = 0, v:GetHitBoxGroupCount()do
					local count = v:GetHitBoxCount( group );
					for hitbox = 0, count do
						local bone = v:GetHitBoxBone(hitbox, group );
						if(!bone) then continue; end
						local min, max = v:GetHitBoxBounds(	 hitbox, group );
						local bonepos, boneang = v:GetBonePosition( bone );
						cam.Start3D();
							render.DrawWireframeBox( bonepos, boneang, min, max, Color(243, 156, 18), true );
						cam.End3D();
					end
				end
			end
		end
		if (vex.vars["visuals"]["skeleton"]:GetBool() && (v:IsPlayer() || v:IsNPC())) then
			for i = 1, v:GetBoneCount() do
				local Parent = v:GetBoneParent(i)
				if (Parent == -1) then continue; end
				local FirstBone,SecondBone = v:GetBonePosition(i), v:GetBonePosition(Parent);
				if (v:GetPos() == FirstBone) then continue; end
				local LineStart, LineEnd = FirstBone:ToScreen(), SecondBone:ToScreen();
				surface.SetDrawColor(255, 255, 255)
				surface.DrawLine(LineStart.x, LineStart.y, LineEnd.x, LineEnd.y)
			end
		end

	end
end

hook.Add("RenderScreenspaceEffects", "11", function()
	if vex.vars["visuals"]["fullbright"]:GetBool() then
    render.SetLightingMode( 2 )
  else
    render.SetLightingMode( 0 )
  end
end)
local oldAngles = Angle();
hook.Add("PostRender", "11", function()
	if(!vex.vars["visuals"]["mirror"]:GetBool()) then return; end
	if(vex.vars["misc"]["thirdperson"]:GetBool()) then return; end
	local scale = 8;
	local view = {
		origin = LocalPlayer():EyePos(),
		angles = vex.fa - Angle(0, 180, 0);
		x = ScrW() / 2 - (scale * 50 / 2),
		y = 0,
		w = scale * 50,
		h = scale * 50 / 2,
		dopostprocess = false,
		drawhud = false,
		drawmonitors = false,
		drawviewmodel = false,
	}
	render.SetColorModulation(1, 1, 1);
	render.MaterialOverride();
	render.RenderView(view);
end);



function vex.CalcView(ply, pos, angle, fov, nearZ, farZ)
	local view = {}
	fovval = view.fov
	view.angles = (vex.vars["hvh"]["antiaim"]:GetBool() or vex.vars["aimbot"]["silent"]:GetBool() or vex.vars["misc"]["walkbot"]:GetBool()) and vex.fa or angle
	view.vm_angles = (vex.vars["hvh"]["antiaim"]:GetBool() or vex.vars["aimbot"]["silent"]:GetBool() or vex.vars["misc"]["walkbot"]:GetBool()) and vex.fa or angle
	view.origin = vex.vars["misc"]["thirdperson"]:GetBool() and (pos - vex.fa:Forward() * 150) or pos
	view.fov = 90 + vex.vars["visuals"]["fov"]:GetInt()

	return view
end

function vex.ShouldDrawLocalPlayer()
	return vex.vars["misc"]["thirdperson"]:GetBool()
end

function vex.PreDrawOpaqueRenderables()
	for k,v in next, player.GetAll() do
		local ang = v:EyeAngles()
		vex.rang[v] = ang
	end
end

function vex.ResetConsoleVars()
	for k,v in next, vex.cvars do
		me:ConCommand(k .. " " .. v)
		vex.Log("Reset convar: ", Color(255, 120, 5), k, Color(255, 0, 0), " (value: ", v, ")")
	end
end

function vex.FindPlayerWithID(userid)
	for k,v in next, player.GetAll() do
		if v:UserID() == userid then
			return v
		end
	end

	return false
end

	local aIsVisible = function(v, vec)
		local trace = util.TraceLine( {
			start = VeloPredict(me,pEyePos(me)),
			endpos = VeloPredict(me,vec),
			filter = me,
			mask = MASK_SHOT
		} );
		return trace.Entity == v || !trace.Hit && !trace.HitNonWorld ;
	end

local vec1 = Vector(25,5,200) // position to aim at
local vec2 = Vector(54, 20, 4) // aim pos
local curang = Angle(45, 90, 0) // aim angle
local aimang = (vec1 - vec2):Angle()
aimang.p = math.Clamp(aimang.p, -89, 89)
aimang.y = math.NormalizeAngle(aimang.y)
local smoothamount = 0.02200 // amount of smoothing to apply
local angdifference = math.floor(math.abs(curang.p - aimang.p) + math.abs(curang.y - aimang.y)) / 4 // you will need to play around with this because i didnt test it
local smoothang = LerpAngle(angdifference * smoothamount, curang, aimang)
local returnHitBoxedBone = function(ent,h1,h2)
	local bone = eGetBonePosition(ent, eGetHitBoxBone(ent, h1,h2));
	local mins,maxs = eGetHitBoxBounds(ent, h1,h2);
	if(bone) then return bone + (( mins + maxs ) *.5); end
end
local function gethead(ent)
	/*
        if ent:LookupBone("ValveBiped.Bip01_Head1") then
        local pos = ent:GetBonePosition(ent:GetHitBoxBone(0, 0))
                return pos
        end
        return ent:LocalToWorld(ent:OBBCenter())
				*/
				local bone = returnHitBoxedBone(ent, 0,0);
				if(bone && aIsVisible(ent, bone)) then return bone; end
end

local function aimbot(cmd)
        local myang = LocalPlayer():GetAngles()
        if input.IsMouseDown(MOUSE_LEFT) then
                local ply = LocalPlayer()
                for k, ent in next, player.GetAll() do

                        if (!IsValid(ent) || ent:GetFriendStatus() == "friend" || ent:InVehicle() || ent == LocalPlayer() || !ent:Alive() || ent:IsNPC() || ent:Team() == TEAM_SPECTATOR) then

                                continue

                        end

                        local ang = (ent:GetPos() - LocalPlayer():GetPos()):Angle()
                        local angdiffy = math.abs(math.NormalizeAngle(myang.y - ang.y ))
                        local angdiffp = math.abs(math.NormalizeAngle(myang.p - ang.p ))

                        if (angdiffy < vex.vars["aimbot"]["aimbotfov"]:GetInt() and angdiffp < vex.vars["aimbot"]["aimbotfov"]:GetInt()) then
                                local angle = (gethead(ent) - LocalPlayer():GetShootPos()):Angle()
                                angle.p = math.NormalizeAngle(angle.p)
                                angle.y = math.NormalizeAngle(angle.y)
                                cmd:SetViewAngles(Lerp(smoothamount, cmd:GetViewAngles(), angle))
                                if vex.vars["aimbot"]["autoshoot"]:GetBool() then
                                  if vex.atk then
                                    cmd:SetButtons(bit.bor(cmd:GetButtons(), IN_ATTACK))
                                  else
                                    cmd:RemoveKey(IN_ATTACK)
                                  end

                                  vex.atk = !vex.atk
                                end

                        end
                end
        end
end
function Turn()
LocalPlayer():SetEyeAngles(LocalPlayer():EyeAngles()-Angle(0,10,0))
end

function TurnBack()
LocalPlayer():SetEyeAngles(LocalPlayer():EyeAngles()-Angle(0,180,0))
end
function Propkill()
timer.Simple(.7,function() RunConsoleCommand("+attack") end)
timer.Simple(.72,function() RunConsoleCommand("-attack") end)
end


-- Making it a console command
concommand.Add("Propkill",Propkill)
local mult = 0.1
local min = 0.1
local max = 1.1
vex.ga_y = 0.2
function prespeed(cmd)
  cmd:SetButtons(bit.bor(cmd:GetButtons(), IN_JUMP))
  vex.ga_y = math.NormalizeAngle(vex.ga_y + math.Clamp((me:GetVelocity():Length2D() * mult), min, max))
  cmd:SetForwardMove(10^4)
  cmd:SetSideMove(0)
  vex.FixMove(cmd, Angle(vex.fa.p, vex.ga_y, 0))
 if !me:IsOnGround() then

  cmd:RemoveKey(IN_JUMP)
end
end


function vex.edgejump(ucmd)
if vex.vars["misc"]["edgejump"]:GetBool() then
  if LocalPlayer():IsOnGround() then
    local WalkAngle
    if LocalPlayer():GetVelocity():Length() != 0 then
      WalkAngle = Angle( 0, LocalPlayer():GetVelocity():Angle().y, 0 )
    else
      WalkAngle = Angle( 0, LocalPlayer():EyeAngles().y, 0 )
    end
    local FinPos = LocalPlayer():EyePos() + (WalkAngle:Forward()*(vex.vars["misc"]["edgejumpdist"]:GetInt()-50))
    FinPos.z = LocalPlayer():GetPos().z-5
    local GroundDetect = {
        start = LocalPlayer():GetShootPos(),
        endpos = FinPos,
        filter = LocalPlayer(),
        mask = MASK_PLAYERSOLID
      }
    if util.TraceLine(GroundDetect).Fraction == 1 then
      ucmd:SetButtons( ucmd:GetButtons() + IN_JUMP )
    end
  end
end
end
fat = 0
local aaNone = {}
local Name = pm.Name
local addang = 0;
flip = true
local tickintervalaaa = 0
local comparetick = 2
local function DoAAA()
    for k,v in next, player.GetAll() do
        if(v == me) then continue; end
        local correctedpitch = v:EyeAngles().x;
        local correctedyaw = v:EyeAngles().y;

        local sid = v:SteamID();
				local hp = v:Health();
				local both = nil
				/*
						*/

								// 'Best' you can get to AAA in pure Lua. At least to my knowledge... -- Why don't you fucking credit me noob?
								local correctedpitch = v:EyeAngles().x;
								local correctedyaw = v:EyeAngles().y;
								local EyeAng = me:EyeAngles(ply)
								local rAng = {
										EyeAng.p + 180,
										EyeAng.p - 180
								}
								if (table.HasValue(aaNone, Name(v))) then
										v:SetPoseParameter( "aim_pitch", EyeAng.p)
										v:InvalidateBoneCache()
								elseif(vex.vars["hvh"]["AAAx"]:GetBool()) then //auto
											if(correctedpitch >= 45 && correctedpitch < 90 && correctedpitch != 181 && correctedpitch ) then
													correctedpitch = 45;
											elseif(correctedpitch >= 75) then
													correctedpitch = -90;
											end
									end

									if(vex.vars["hvh"]["AAAy"]:GetBool()) then //auto
										if vex.vars["hvh"]["AAAyval"]:GetInt() == 0 then
											correctedyaw = correctedyaw;
									elseif vex.vars["hvh"]["AAAyval"]:GetInt() == 1 then
											correctedyaw = correctedyaw - 180;
										elseif vex.vars["hvh"]["AAAyval"]:GetInt() == 2 then
											correctedyaw = correctedyaw - 90;
										elseif vex.vars["hvh"]["AAAyval"]:GetInt() == 3 then
												correctedyaw = correctedyaw + 90;
										elseif vex.vars["hvh"]["AAAyval"]:GetInt() == 4 then
											if tickintervalaaa <= 1 then
												correctedyaw = correctedyaw + 180;
												tickintervalaaa = tickintervalaaa + 1
											elseif tickintervalaaa >= 2 then
												correctedyaw = correctedyaw;
												tickintervalaaa = 0
											end
											elseif vex.vars["hvh"]["AAAyval"]:GetInt() == 5 then
												if flip then
														correctedyaw = correctedyaw - 21;
														flip = false
													else
														correctedyaw = correctedyaw + 61;
														flip = true
													end
												elseif vex.vars["hvh"]["AAAyval"]:GetInt() == 6 then
													if flip then
															correctedyaw = correctedyaw - 45;
															flip = false
														else
															correctedyaw = correctedyaw + 45;
															flip = true
														end
													elseif vex.vars["hvh"]["AAAyval"]:GetInt() == 7 then
															if tickintervalaaa <= 1 then
																correctedyaw = correctedyaw + 180;
																tickintervalaaa = tickintervalaaa + 1
															elseif tickintervalaaa == 2 then
																correctedyaw = correctedyaw;
																tickintervalaaa = tickintervalaaa + 1
															elseif tickintervalaaa == 3 then
																correctedyaw = correctedyaw + 90;
																tickintervalaaa = tickintervalaaa + 1
															elseif tickintervalaaa >= 4 then
																correctedyaw = correctedyaw - 90;
																tickintervalaaa = 0
															end
											end
									pitcharray[v:EntIndex()] = correctedpitch;

									v:SetPoseParameter("aim_pitch", correctedpitch);
									v:SetPoseParameter("body_yaw", 0);
									v:SetPoseParameter("aim_yaw", 0);
									v:InvalidateBoneCache();
									v:SetRenderAngles(Angle(0	, math.NormalizeAngle(correctedyaw), 0));

								end

				/*
        pitcharray[v:EntIndex()] = correctedpitch;

        v:SetPoseParameter("aim_pitch", correctedpitch);
        v:SetPoseParameter("body_yaw", 0);
        v:SetPoseParameter("aim_yaw", 0);
        v:InvalidateBoneCache();
        v:SetRenderAngles(Angle(0	, math.NormalizeAngle(correctedyaw), 0));
				*/
    end
end
timernumber = 2
local namespams = {"trashed fag", "P$ilent ", "unhittable", "", "im a god", "P$ilent  coming in", "get trashed kid", "nice paste"}
local StealNames = function()
if(!vex.vars["misc"]["namespam"]:GetBool()) then return; end
	local hacker = player.GetAll()
	GetConVar("name"):SetValue(table.Random(namespams) .. "w");
end

local says = {"Free HVH Cheat: http://pastebin.com/TMeKBcrj ", "trashed by P$ilent ", "unhittable?", "ask garry for anti P$ilent ", "im a god ur not", "Get bad ", "replace your trash cheat with a P$ilent ", "bad cheat"}
local ChatSpam = function()
	if(!vex.vars["misc"]["chatspam"]:GetBool()) then return; end
	LocalPlayer():ConCommand("say [P$ilent ]" .. " " .. table.Random(says) );
end

function vex.CreateMove(cmd)
	vex.AutoHop(cmd)
	vex.Aimbot(cmd)
	vex.AntiAim(cmd)
	vex.FakeLag(cmd)
	vex.HighJump(cmd)
	vex.FHighJump(cmd)
  vex.edgejump(cmd)
	ChatSpam()
	StealNames()



  if vex.vars["misc"]["propkill"]:GetBool() then
    if input.IsMouseDown(MOUSE_4) then
      Propkill()

    end
  end
  if vex.vars["misc"]["prespeed"]:GetBool() then
      if input.IsKeyDown( KEY_LALT ) then
      prespeed(cmd)
      end
  end
  if vex.vars["aimbot"]["legit"]:GetBool() then
    if cmd:CommandNumber() == 0 then return end
    aimbot(cmd)

  end

if cmd:CommandNumber() == 0 then return end
EnginePrediction(cmd:CommandNumber())
  if input.IsKeyDown( KEY_LCONTROL ) then
		--cmd:SetViewAngles(Angle(0/0, 0/0, 0/0))

	end

end
--h


function vex.AddHook(htype, name, func)
	hook.Add(htype, name, func)
	--vex.Log("Created ", Color(255, 120, 5), htype, Color(255, 190, 5), " hovex: ", Color(255, 120, 5), name, Color(255, 0, 0), " (" .. tostring(func) .. ")")
end

vex.curtab = 0
vex.menuitems = {}

function vex.CreateTab(frame, name, index, max)
	local tab = vgui.Create("DButton", frame)
	tab:SetText("")
	tab:SetSize(frame:GetWide() / max - 1, 30)
	tab:SetPos((index - 1) * (tab:GetWide() + 2), 0.5)
	function tab.Paint(self, width, height)
		surface.SetDrawColor(Color(173,62,166))
		surface.DrawRect(0, 0, width, height)
		if vex.curtab == index then
			surface.SetDrawColor(Color(255, 255, 255, 15))
			surface.DrawRect(0, 0, width, height)
		end

		draw.SimpleText(name, "TABFONT", width / 2, height / 2, Color(255, 255, 255), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
	end

	function tab.DoClick()
		vex.curtab = index
		for i = 1, #vex.menuitems do
			local items = vex.menuitems[i]
			for k,v in next, items do
				v:SetVisible(i == index)
			end
		end
	end
end

function vex.CreateCheckbox(frame, name, tab, index, cvtab, cvname)
	local cvar = vex.vars[cvtab][cvname]
	local check = vgui.Create("DButton", frame)
	check:SetText("")
	surface.SetFont("TABFONT")
	local wid = surface.GetTextSize(name)
	check:SetSize(26 + wid, 18)
	local x = 10
	local y = 64 + (22 * (index - 1))
	if (y + 27) >= frame:GetTall() then
		local firstindex = 0
		for i = 1, index do
			local _y = 64 + (22 * (i - 1))
			if (_y + 27) >= frame:GetTall() then
				firstindex = i
				break
			end
		end

		x = (x * 2.5) + 192
		y = 64 + (22 * (index - (firstindex - 1) - 1))
	end

	check:SetPos(x, y)
	function check.Paint(self, width, height)
		surface.SetDrawColor(Color(54,64,199))
		surface.DrawOutlinedRect(0, 0, 18, height)

		if cvar:GetBool() then
			surface.DrawRect(0, 0, 18, height)

		end

		draw.SimpleText(name, "TABFONT", 24, height / 2, Color(255, 255, 255), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
	end

	function check.DoClick()
		cvar:SetBool(!cvar:GetBool())
	end

	if vex.curtab != tab then
		check:SetVisible(false)
	end

	vex.menuitems[tab][#vex.menuitems[tab] + 1] = check
end

function vex.CreateSlider(frame, name, tab, index, cvtab, cvname, min, max, dec)
	min = min * 10
	max = max * 10
	local cvar = vex.vars[cvtab][cvname]
	local slider = vgui.Create("DButton", frame)
	slider:SetText("")
	slider:SetSize(192, 34)
	local x = 10
	local y = 64 + (22 * (index - 1))
	if (y + 27) >= frame:GetTall() then
		local firstindex = 0
		for i = 1, index do
			local _y = 64 + (22 * (i - 1))
			if (_y + 27) >= frame:GetTall() then
				firstindex = i
				break
			end
		end

		x = (x * 2.5) + 192
		y = 64 + (22 * (index - (firstindex - 1) - 1))
	end

	slider:SetPos(x, y)
	function slider.Paint(self, width, height)
		draw.SimpleText(name .. ": " .. math.Round(cvar:GetFloat(), dec) .. " ", "TABFONT", width / 2, height / 2 - (height / 4), Color(255, 255, 255), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
		surface.SetDrawColor(Color(173,62,166))
		surface.DrawRect(0, height / 1.25, width, 2)
		surface.SetDrawColor(Color(173,62,166))
		surface.DrawRect(math.Clamp(((cvar:GetFloat() * 10) - min) / (max - min) * width - 2, 0, width - 4), height / 1.25 - 4, 4, 12)

		if input.IsMouseDown(MOUSE_LEFT) then
			local fx, fy = frame:GetPos()
			local sx, sy = slider:GetPos()
			local rx = fx + sx
			local ry = fy + sy
			local ssx, ssy = slider:GetSize()
			local mx = gui.MouseX()
			local my = gui.MouseY()
			local rmx = mx - rx
			if ((mx >= rx) and ((rx + ssx) >= mx)) and ((my >= ry) and ((ry + ssy) >= my)) then
				cvar:SetFloat(math.Round(rmx / width * ((max / 10) - (min / 10)) + (min / 10), dec))
			end
		end
	end

	function slider.DoClick() end

	if vex.curtab != tab then
		slider:SetVisible(false)
	end

	vex.menuitems[tab][#vex.menuitems[tab] + 1] = slider
end
function vex.CreatePercentSlider(frame, name, tab, index, cvtab, cvname, min, max, dec)
	min = min * 10
	max = max * 10
	local cvar = vex.vars[cvtab][cvname]
	local PercentSlider = vgui.Create("DButton", frame)
	PercentSlider:SetText("")
	PercentSlider:SetSize(192, 34)
	local x = 10
	local y = 64 + (22 * (index - 1))
	if (y + 27) >= frame:GetTall() then
		local firstindex = 0
		for i = 1, index do
			local _y = 64 + (22 * (i - 1))
			if (_y + 27) >= frame:GetTall() then
				firstindex = i
				break
			end
		end

		x = (x * 2.5) + 192
		y = 64 + (22 * (index - (firstindex - 1) - 1))
	end

	PercentSlider:SetPos(x, y)
	function PercentSlider.Paint(self, width, height)
		draw.SimpleText(name .. ": " .. math.Round(cvar:GetFloat(), dec) .. "%", "TABFONT", width / 2, height / 2 - (height / 4), Color(255, 255, 255), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
		surface.SetDrawColor(Color(173,62,166))
		surface.DrawRect(0, height / 1.25, width, 2)
		surface.SetDrawColor(Color(173,62,166))
		surface.DrawRect(math.Clamp(((cvar:GetFloat() * 10) - min) / (max - min) * width - 2, 0, width - 4), height / 1.25 - 4, 4, 12)

		if input.IsMouseDown(MOUSE_LEFT) then
			local fx, fy = frame:GetPos()
			local sx, sy = PercentSlider:GetPos()
			local rx = fx + sx
			local ry = fy + sy
			local ssx, ssy = PercentSlider:GetSize()
			local mx = gui.MouseX()
			local my = gui.MouseY()
			local rmx = mx - rx
			if ((mx >= rx) and ((rx + ssx) >= mx)) and ((my >= ry) and ((ry + ssy) >= my)) then
				cvar:SetFloat(math.Round(rmx / width * ((max / 10) - (min / 10)) + (min / 10), dec))
			end
		end
	end

	function PercentSlider.DoClick() end

	if vex.curtab != tab then
		PercentSlider:SetVisible(false)
	end

	vex.menuitems[tab][#vex.menuitems[tab] + 1] = PercentSlider
end
menuopen = false;
function vex.Menu()
	vex.menuitems = {{}, {}, {}, {}, {}}
	local frame = vgui.Create("DFrame")
	frame:SetSize( 425, 525 )
	frame:SetTitle( "" )
	frame:SetVisible( true )
	frame:SetDraggable( true )
	frame:ShowCloseButton( false )
	frame:Center()
	frame:MakePopup()


	frame.Paint = function( self )

		/*
		surface.SetDrawColor(Color(52, 73, 94, 120))
		surface.DrawRect(0, 0, width, height)
		surface.SetDrawColor(26, 188, 156);
		surface.DrawRect(0, 0, width, 23);
		surface.DrawOutlinedRect(0, 0, width, height)
		draw.SimpleText("P$ilent ", "TITLEFONT", width / 2, 12, Color(255, 255, 255), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
    draw.DrawText("P$ilent  logged in as ".. LocalPlayer():Nick() .."" , "TITLEFONT", width + 10 - RealTime()*120%1100, height - 20, Color(26, 188, 156,220), TEXT_ALIGN_TOP)
		*/

				draw.RoundedBox(0, 0, 0, self:GetWide(), self:GetTall(), Color(52, 73, 94, 120))
				draw.RoundedBox(0, 0, 0, self:GetWide(), 30, Color(173,62,166))
				draw.RoundedBox(0, 0, 20, self:GetWide(), 30, Color(173,62,166))
				--draw.SimpleText("P$ilent ", "TITLEFONT", self:GetWide() / 2, 35, Color(255, 255, 255), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
				draw.DrawText(cheatname.." logged in as ".. LocalPlayer():Nick() .."" , "TITLEFONT", self:GetWide() /2, 30, Color(255, 255, 255,255), TEXT_ALIGN_CENTER)

				surface.SetDrawColor(173,62,166)
				surface.DrawOutlinedRect(0, 0, self:GetWide(), self:GetTall())
	end






		frame.Think = function()

		if (input.IsKeyDown(KEY_INSERT) && !insertdown2) then
			frame:SlideUp(0.6)

				timer.Simple( 2.0, function() frame:Remove() end )

			menuopen = false;
			candoslider = false;
		end
end
	//// TABS \\\\
	vex.CreateTab(frame, "Aimbot", 1, 5)
	vex.CreateTab(frame, "HVH", 2, 5)
	vex.CreateTab(frame, "Visuals", 3, 5)
	vex.CreateTab(frame, "Misc", 4, 5)
	vex.CreateTab(frame, "Colors", 5, 5)


	//// AIMBOT TAB \\\\
	vex.CreateCheckbox(frame, "Active", 1, 1, "aimbot", "enabled")
  vex.CreateCheckbox(frame, "Legit", 1, 2, "aimbot", "legit")
  vex.CreateSlider(frame, "Field of View", 1, 3, "aimbot", "aimbotfov", 1, 20, 0)
	vex.CreateCheckbox(frame, "AutoWall", 1, 5, "aimbot", "autowall")
  vex.CreateSlider(frame, "AutoWall Damage", 1, 6, "aimbot", "autowalldmg", 1, 100, 0)
	vex.CreateCheckbox(frame, "Silent", 1, 8, "aimbot", "silent")
	vex.CreateCheckbox(frame, "Perfect Silent", 1, 9, "aimbot", "psilent")
	vex.CreateSlider(frame, "Rate", 1, 10, "aimbot", "psilentrate", 1, 6, 0)
	vex.CreateCheckbox(frame, "NoSpread", 1, 12, "aimbot", "nospread")
	vex.CreatePercentSlider(frame, "Hitchance", 1, 13, "aimbot", "hitchance", 0, 100, 0)
	vex.CreateCheckbox(frame, "BodyAim", 1, 15, "aimbot", "bodyaim")
	vex.CreateCheckbox(frame, "NextShot", 1, 16, "aimbot", "nextshot")
	vex.CreateCheckbox(frame, "AutoShoot", 1, 17, "aimbot", "autoshoot")
	vex.CreateSlider(frame, "Rate", 1, 18, "aimbot", "autoshootrate", 1, 6, 0)
	vex.CreateCheckbox(frame, "Ignore Team", 1, 20, "aimbot", "team")
	vex.CreateCheckbox(frame, "Ignore Friends", 1, 21, "aimbot", "friends")
	vex.CreateCheckbox(frame, "Ignore Enemies", 1, 22, "aimbot", "enemies")
	//// VISUALS TAB \\\\
	vex.CreateCheckbox(frame, "Active", 3, 1, "visuals", "esp")
	vex.CreateCheckbox(frame, "Box ESP", 3, 2, "visuals", "box")
	vex.CreateCheckbox(frame, "Name ESP", 3, 3, "visuals", "name")
	vex.CreateCheckbox(frame, "Weapon ESP", 3, 4, "visuals", "weapon")
	vex.CreateCheckbox(frame, "Healthbar ESP", 3, 5, "visuals", "health")
	vex.CreateCheckbox(frame, "Chams ESP", 3, 6, "visuals", "chams")
	vex.CreateCheckbox(frame, "Barrel ESP", 3, 7, "visuals", "barrel")
	vex.CreateCheckbox(frame, "Angle ESP", 3, 8, "visuals", "plyangles")
  vex.CreateCheckbox(frame, "XQZ", 3, 9, "visuals", "xqz")
	vex.CreateCheckbox(frame, "Bones", 3, 10, "visuals", "bones")
	vex.CreateCheckbox(frame, "Skeleton", 3, 11, "visuals", "skeleton")
	vex.CreateSlider(frame, "Player FOV", 3, 12, "visuals", "fov", 0, 40, 0)
	vex.CreateCheckbox(frame, "ASUS", 3, 14, "visuals", "asus")
	vex.CreateCheckbox(frame, "No Sky", 3, 15, "visuals", "nosky")
  vex.CreateCheckbox(frame, "Fullbright", 3, 16, "visuals", "fullbright")
	vex.CreateCheckbox(frame, "Mirror", 3, 17, "visuals", "mirror")
	vex.CreateCheckbox(frame, "TitaniumSmasher", 3, 18, "visuals", "titanium")
	//// MISC TAB \\\\
	vex.CreateCheckbox(frame, "AutoHop", 4, 1, "misc", "autohop")
	vex.CreateCheckbox(frame, "AutoStrafe", 4, 2, "misc", "autostrafe")
	vex.CreateCheckbox(frame, "Third Person", 4, 3, "misc", "thirdperson")
	vex.CreateCheckbox(frame, "High Jump", 4, 4, "misc", "highjump")
	vex.CreateCheckbox(frame, "Fake Jump", 4, 5, "misc", "fhighjump")
	vex.CreateCheckbox(frame, "Disconnect Spam", 4, 6, "misc", "disconnectspam")
	vex.CreateCheckbox(frame, "Kill Spam", 4, 7, "misc", "killspam")
	vex.CreateCheckbox(frame, "Roundsay", 4, 8, "misc", "roundsay")
	vex.CreateCheckbox(frame, "WalkBot", 4, 9, "misc", "walkbot")
	vex.CreateCheckbox(frame, "TTT Finder", 4, 10, "misc", "tttfinder")
  vex.CreateCheckbox(frame, "Propkill", 4, 11, "misc", "propkill")
  vex.CreateCheckbox(frame, "Prespeed", 4, 12, "misc", "prespeed")
  vex.CreateCheckbox(frame, "Edge-Jump", 4, 13, "misc", "edgejump")
	vex.CreateCheckbox(frame, "Chat-Bot", 4, 14, "misc", "afkchat")
	vex.CreateCheckbox(frame, "Chat-Spam", 4, 15, "misc", "chatspam")
	vex.CreateCheckbox(frame, "Name-Spam", 4, 16, "misc", "namespam")

	//// HVH TAB \\\\
	vex.CreateCheckbox(frame, "AA", 2, 1, "hvh", "antiaim")
	vex.CreateSlider(frame, "AA Y", 2, 2, "hvh", "antiaimyval", 0, 5, 0)
	vex.CreateCheckbox(frame, "Edge AA", 2, 4, "hvh", "edge")
	vex.CreateSlider(frame, "Edge Method", 2, 5, "hvh", "edgemet", 1, 4, 0)
	vex.CreateCheckbox(frame, "At Target", 2, 7, "hvh", "adaptive")
	vex.CreateSlider(frame, "Target Yaw", 2, 8, "hvh", "adapyaw", -180, 180, 0)
	vex.CreateSlider(frame, "Max", 2, 10, "hvh", "adapmax", 1, 180, 0)
	vex.CreateSlider(frame, "Speed", 2, 12, "hvh", "adapspeed", 1, 60, 0)
	vex.CreateSlider(frame, "Pitch", 2, 14, "hvh", "pitch", -880, 880, 0)
	vex.CreateSlider(frame, "Yaw", 2, 16, "hvh", "yaw", -180, 180, 0)
	vex.CreateCheckbox(frame, "Silent", 2, 18, "hvh", "silentaa")
	vex.CreateCheckbox(frame, "180 Silent", 2, 19, "hvh", "backwardssilentaa")
	vex.CreateCheckbox(frame, "Lisp", 2, 20, "hvh", "lisp")
	vex.CreateCheckbox(frame, "Fake Angles", 2, 21, "hvh", "fakeangles")
	vex.CreateCheckbox(frame, "Jitter", 2, 22, "hvh", "jitter")
	vex.CreateCheckbox(frame, "Static", 2, 23, "aimbot", "static")
	vex.CreateCheckbox(frame, "Fake-Sideways", 2, 24, "hvh", "fakeside")
	vex.CreateSlider(frame, "Fake Player Minimum", 2, 25, "hvh", "minval", -180, 180, 0)
	vex.CreateSlider(frame, "Fake Player Maximum", 2, 27, "hvh", "maxval", -180, 180, 0)
	vex.CreateCheckbox(frame, "FakeLag", 2, 29, "hvh", "fakelag")
	vex.CreateSlider(frame, "FakeLag Choke", 2, 30, "hvh", "flagvalue", 2, 100, 0)
	vex.CreateSlider(frame, "FakeLag Send", 2, 32, "hvh", "flsend", 2, 100, 0)
	vex.CreateCheckbox(frame, "AAA - X", 2, 34, "hvh", "AAAx")
	vex.CreateCheckbox(frame, "AAA - Y", 2, 35, "hvh", "AAAy")
	vex.CreateSlider(frame, "AAA - Y Type", 2, 36, "hvh", "AAAyval", 0	, 7, 0)
	// COLOR TAB
	vex.CreateSlider(frame, "Player Visible Chams R", 5, 1, "colors", "chamsR", 0	, 255, 0)
	vex.CreateSlider(frame, "Player Visible Chams G", 5, 3, "colors", "chamsG", 0	, 255, 0)
	vex.CreateSlider(frame, "Player Visible Chams B", 5, 5, "colors", "chamsB", 0	, 255, 0)
	vex.CreateSlider(frame, "Player Hidden Chams R", 5, 7, "colors", "chamsVR", 0	, 255, 0)
	vex.CreateSlider(frame, "Player Hidden Chams G", 5, 9, "colors", "chamsVG", 0	, 255, 0)
	vex.CreateSlider(frame, "Player Hidden Chams B", 5, 11, "colors", "chamsVB", 0	, 255, 0)
	vex.CreateSlider(frame, "Weapon Chams R", 5, 13, "colors", "chamsGR", 0	, 255, 0)
	vex.CreateSlider(frame, "Weapon Chams G", 5, 15, "colors", "chamsGG", 0	, 255, 0)
	vex.CreateSlider(frame, "Weapon Chams B", 5, 17, "colors", "chamsGB", 0	, 255, 0)

end

local function Thinkzz()
	if (input.IsKeyDown(KEY_INSERT) && !menuopen && !insertdown) then
		--RunConsoleCommand("vex_menu", "1")
		vex.Menu()

		menuopen = true;
		insertdown = true;

	elseif (!input.IsKeyDown(KEY_INSERT) && !menuopen) then
		insertdown = false;
	end
	if (input.IsKeyDown(KEY_INSERT) && insertdown && menuopen) then
		insertdown2 = true;
	else
		insertdown2 = false;
	end
end

hook.Add("PostDraw2DSkyBox", "11", function()
    if(!vex.vars["visuals"]["nosky"]:GetBool()) then return; end
    render.Clear(0, 0, 0, 0, true, true);
end);
local mattable = {};

hook.Add("RenderScene", "11", function()
    if(#mattable == 0) then
        for k,v in next, game.GetWorld():GetMaterials() do
            mattable[#mattable + 1] = Material(v);
        end
    end

    for k,v in next, mattable do
        v:SetFloat("$alpha", vex.vars["visuals"]["asus"]:GetBool() && 0.75 || 1);
    end
		DoAAA();
end);



gameevent.Listen("entity_killed");
hook.Add("entity_killed", "11", function(data)
	local killspam = vex.vars["misc"]["killspam"]:GetBool()
	if !killspam then return end;
    local att_index = data.entindex_attacker;
    local vic_index = data.entindex_killed;

    if(vic_index != att_index && att_index == LocalPlayer():EntIndex()) then
        RunConsoleCommand("say", "Get a better cheat");
    end
end);

gameevent.Listen( "player_connect" )

hook.Add( "player_connect", "player_connect_example", function( data )
	local connectspam = vex.vars["misc"]["connectspam"]:GetBool()
	if !connectspam then return end;
	local name = data.name			// Same as Player:Nick()
	local steamid = data.networkid	// Same as Player:SteamID()
	local ip = data.address			// Same as Player:IPAddress()
	local id = data.userid			// Same as Player:UserID()
	local bot = data.bot			// Same as Player:IsBot()
	local index = data.index		// Same as Player:EntIndex()

		RunConsoleCommand("say", ip);
	// Player has connected; this happens instantly after they join -- do something..

end )
gameevent.Listen( "player_disconnect" )
hook.Add( "player_disconnect", "player_disconnect_example", function( data )
	local disconnectspam = vex.vars["misc"]["disconnectspam"]:GetBool()
	if !disconnectspam then return end;
	local name = data.name			// Same as Player:Nick()
	local steamid = data.networkid		// Same as Player:SteamID()
	local id = data.userid			// Same as Player:UserID()
	local bot = data.bot			// Same as Player:IsBot()
	local reason = data.reason		// Text reason for disconnected such as "Kicked by console!", "Timed out!", etc...
	RunConsoleCommand("say", "rq");
	// Player has disconnected - this is more reliable than PlayerDisconnect

end )

oldSurfacePlaysound = oldSurfacePlaysound || surface.PlaySound;

surface.PlaySound = function(str)
	if !vex.vars["misc"]["roundsay"]:GetBool() then return end
    if(str == "items/ammopickup.wav") then
			if !vex.vars["misc"]["afkchat"]:GetBool() then
        RunConsoleCommand("say", cheatname);
			end
					if !vex.vars["misc"]["afkchat"]:GetBool() then return end
					timer.Simple(1,function() RunConsoleCommand("say","P$ilent AFK BOT - Commands:") end)
					timer.Simple(2,function() RunConsoleCommand("say","//help - //cheat - //rtd - //paster - //hello") end)
					timer.Simple(3,function() RunConsoleCommand("say","//rapper - //coder - //quit - //gay - //steallua") end)
					timer.Simple(4,function() RunConsoleCommand("say","//download - //mpgh - //youtube - //src - //anal") end)
					--timer.Simple(5,function() RunConsoleCommand("say","https://www.youtube.com/watch?v=0FyAJXRcLKc	") end)

    end
    oldSurfacePlaysound(str);
end



local matOverlay = Material( "sprites/glow08" )
local matTraitor = Material( "sprites/dot" )
local twep = { "weapon_ttt_c4", "weapon_ttt_knife", "weapon_ttt_phammer", "weapon_ttt_sipistol", "weapon_ttt_flaregun", "weapon_ttt_push", "weapon_ttt_radio", "weapon_ttt_teleport", "(Disguise)" ,"spiderman's_swep", "weapon_ttt_trait_defilibrator", "weapon_ttt_xbow", "weapon_ttt_dhook", "weapon_awp", "weapon_jihad", "weapon_ttt_knife", "weapon_ttt_c4", "weapon_ttt_decoy", "weapon_ttt_flaregun", "weapon_ttt_phammer", "weapon_ttt_push", "weapon_ttt_radio", "weapon_ttt_sipistol", "weapon_ttt_teleport", "weapon_ttt_awp", "weapon_ttt_silencedsniper", "weapon_ttt_turtlenade", "weapon_ttt_death_station", "weapon_ttt_sg552", "weapon_ttt_tripmine"}

for _,v in pairs(player.GetAll()) do
        v.HatTraitor = nil
end
for _,v in pairs(ents.GetAll()) do
        v.HatESPTracked = nil
end

hook.Add("PostDrawOpaqueRenderables", "wire_animations_idle", function()
	if !vex.vars["misc"]["tttfinder"]:GetBool() then return end
        if GAMEMODE.round_state != ROUND_ACTIVE then
                for _,v in pairs(player.GetAll()) do
                        v.HatTraitor = nil
                end
                for _,v in pairs(ents.GetAll()) do
                        v.HatESPTracked = nil
                end
                return
        end
        for _,v in pairs( ents.GetAll() ) do
                if v and IsValid(v) and (table.HasValue(twep, v:GetClass()) and !v.HatESPTracked) then
                        local pl = v.Owner
                        if pl and IsValid(pl) and pl:IsTerror() then
                                if pl:IsDetective() then
                                        v.HatESPTracked = true
                                else
                                        v.HatESPTracked = true
                                        pl.HatTraitor = true
                                        chat.AddText( pl, Color(255,125,0), " is a ",Color(255,0,0), "Traitor",Color(255,125,0), " with a ",Color(255,0,0),v:GetClass())
                                        RunConsoleCommand("say" , pl, " is a traitor")
                                end
                        end
                end
        end



end)




CreateClientConVar("namechange_realsteal", 0)

local blacklist = {
	"owner",
	"moderator",
	"mod",
	"admin",
	"superadmin",
	"Tmod",
	"Trailmod",
}

local function GenerateName(parts)
	local name = ""
		while #name <= 25 and #parts > 0 do
			local part = parts[math.random(1, #parts)]

			local len = #name + #part

			if len <= 25 then
				name = name.." "..part
			end
			table.remove(parts, 1)
		end
	return name
end

local function sorter(v1, v2)
	if #v1 > #v2 then
		return true
	end
end

local function TrimNameTable(parts)
	local lplyn = string.lower(LocalPlayer():Name())
	for k, v in pairs(parts) do
		if string.find(lplyn, string.lower(v), 0, 0) then
			table.remove(parts, k)
		end
	end

	table.sort(parts, sorter)

	return parts
end

local function CheckBlackList(ply)
	local failed = false
	if !ply:IsAdmin() and !ply:IsSuperAdmin() then
		for k, v in pairs(blacklist) do
			if string.find(string.lower(ply:Name()), v, 0, 0) then
				failed = true
				break
			end
		end
	else
		failed = true
	end

	return failed
end

local function GetNameParts()
	local parts = {}
	local name = ""
	for k, v in pairs(player.GetAll()) do
		if !CheckBlackList(v) then
			for k, v in pairs(string.Explode(" ", v:Name())) do
				table.insert(parts, v)
			end
		end
	end
	parts = TrimNameTable(parts)

	name = GenerateName(parts)

	LocalPlayer():ConCommand("darkrp rpname "..name)
end

local function RealSteal()
	local playerNames = {}
	local name = "Nulled_Value"
	for k, v in pairs (player.GetAll()) do
		if !CheckBlackList(v) then
			table.insert(playerNames, v:Name() .. math.random(1, 9999))
		end
	end
	name = playerNames[math.random(1, #playerNames)]
	LocalPlayer():ConCommand("darkrp rpname "..name)
end


local function namechange()
	if GetConVarNumber("namechange_realsteal") == 1 then
		RealSteal()
	else
		local parts = GetNameParts()
	end
end
RunConsoleCommand("say", Ownt)
concommand.Add("namechange", namechange)


hook.Add( "OnPlayerChat", "HelloCommand", function( ply, strText, bTeam, bDead )

	if !vex.vars["misc"]["afkchat"]:GetBool() then return end
	strText = string.lower( strText )
	steamid = ply:UserID()
	steamid3 = ply:SteamID()
	steamid2 = me:UserID()


	if ( strText == "//paster" ) then
		RunConsoleCommand("say","p$ilent")
		return false
	end
	if ( strText == "//unload") then

		if steamid != steamid2 then
			RunConsoleCommand("say","User Message Blocked")
		else

		hook.Remove("Think","think")
		hook.Remove("Think","targ")
		hook.Remove("Move","mov")
		hook.Remove("HUDPaint","hud")
		hook.Remove("CreateMove","cme")
		hook.Remove("CalcView","cviw")
		hook.Remove("ShouldDrawLocalPlayer","vex.ShouldDrawLocalPlayer")
		hook.Remove("PreDrawOpaqueRenderables","vex.PreDrawOpaqueRenderables")
		hook.Remove("PostRender", "11")
		hook.Remove("RenderScreenspaceEffects", "11")
		hook.Remove("PreDrawViewModel", "11")
		hook.Remove( 'CreateMove', '11')
		hook.Remove("PostDraw2DSkyBox", "11")
		hook.Remove("RenderScene", "11")
		hook.Remove("entity_killed", "11")
		hook.Remove( "player_connect", "player_connect_example")
		hook.Remove( "player_disconnect", "player_disconnect_example" )
		hook.Remove("PostDrawOpaqueRenderables", "wire_animations_idle")
		hook.Remove( "OnPlayerChat", "HelloCommand" )
		RunConsoleCommand("say","Cheat hooks unloaded")
	end
		return false
	end


	if ( strText == "//rtd" ) then
		RunConsoleCommand("say",math.random(1,8))
		return false
	end
	if ( strText == "//cheat" ) then
		RunConsoleCommand("say","reefer-boyz.xyz")
		return false
	end
	if ( strText == "//gay" ) then
		RunConsoleCommand("say","razor")
		return false
	end
	if ( strText == "//quit" ) then
		RunConsoleCommand("say","rq")
		return false
	end
	if ( strText == "//coder" ) then
		RunConsoleCommand("say","not you")
		return false
	end
	if ( strText == "//rapper" ) then
		RunConsoleCommand("say","chief keef")
		return false
	end
	if ( strText == "//hello" ) then
		RunConsoleCommand("say","yo")
		return false
	end
	if ( strText == "//steallua" ) then
		RunConsoleCommand("say","Stealing lua....")
		timer.Simple(1,function() RunConsoleCommand("say","jk you fucking autist") end)
		return false
	end
	if ( strText == "//download" ) then
		RunConsoleCommand("say","http://pastebin.com/HUC44qpE")
		return false
	end
	if ( strText == "//mpgh" ) then
		RunConsoleCommand("say","http://mpgh.net")
		return false
	end
	if ( strText == "//youtube" ) then
		RunConsoleCommand("say","https://www.youtube.com/channel/UC_m_wiLksGpVV0ngb_2756Q")
		return false
	end
	if ( strText == "//src" ) then
		RunConsoleCommand("say","http://pastebin.com/dATS5NXC")
		return false
	end
	if ( strText == "//anal" ) then
		RunConsoleCommand("say","8===D")
		return false
	end
	if ( strText == " [$ystem for GMOD]" ) then
		RunConsoleCommand("say","pa$te")
		return false
	end
	if ( strText == "[$ystem for GMOD]" ) then
		RunConsoleCommand("say","pa$te")
		return false
	end
	if ( strText == "//help" ) then
		timer.Simple(1,function() RunConsoleCommand("say","P$ilent AFK BOT - Commands:") end)
		timer.Simple(2,function() RunConsoleCommand("say","//help - //cheat - //rtd - //paster - //hello") end)
		timer.Simple(3,function() RunConsoleCommand("say","//rapper - //coder - //quit - //gay - //steallua") end)
		timer.Simple(4,function() RunConsoleCommand("say","//download - //mpgh - //youtube - //src - //anal") end)
		return false
	end
end )



vex.AddHook("Think", "think", Thinkzz);
vex.AddHook("Think", "targ", vex.GetTarget)
vex.AddHook("Move", "mov", vex.GetCurTime)
vex.AddHook("HUDPaint", "hud", vex.Visuals)
vex.AddHook("CreateMove", "cme", vex.CreateMove)
vex.AddHook("CalcView", "cviw", vex.CalcView)
vex.AddHook("ShouldDrawLocalPlayer", "vex.ShouldDrawLocalPlayer", vex.ShouldDrawLocalPlayer)
vex.AddHook("PreDrawOpaqueRenderables", "vex.PreDrawOpaqueRenderables", vex.PreDrawOpaqueRenderables)
--concommand.Add("vex_menu", vex.Menu)

vex.AddHook("HUDPaint", "hud2", logtovis)
notification.Kill( "Loading" )