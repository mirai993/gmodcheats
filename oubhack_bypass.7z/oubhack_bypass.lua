--[[
	MOD/lua/anticheat-bypass.lua
	Joseph | STEAM_0:0:69348930 <2.26.87.183:27005> | [19-10-13 05:31:28PM]
	===BadFile===
]]


-- Anit-cheat bypasser.



/********************************
 _______ _____        _______
 |______   |   |      |______
 |       __|__ |_____ |______
                             
*********************************/

local oFileRead = file.Read
local oFileExists = file.Exists
local oFileDlete = file.Delete
local oFileExistsEx = file.ExistsEx
local oFileFind = file.Find
local oFileFindDir = file.FindDir
local oFileFindInLua = file.FindInLua
local oFileIsDir = file.IsDir
local oFileSize = file.Size
local oFileTFind = file.TFind
local oFileTime = file.Time

function file.Read( name, ubf )
	if string.find(name,"oubhack") or string.find(name,"OubHack") then
		oubhack:Print("Attempt to access file "..name.." has bean blocked.",Color(20,200,20,255))
		return 
	end
	return oFileRead(name, ubf)
end
	
function file.Exists( name, ubf )
	if string.find(name,"oubhack") or string.find(name,"OubHack") then
		oubhack:Print("Attempt to access file "..name.." has bean blocked.",Color(20,200,20,255))
		return false
	end
	return oFileExists(name, ubf)
end

function file.Delete( name )
	if string.find(name,"oubhack") or string.find(name,"OubHack") then
		oubhack:Print("Attempt to delete file "..name.." has bean blocked.",Color(20,200,20,255))
		return 
	end
	return oFileDlete(name, ubf)
end

function file.ExistsEx( name, ubf )
	if string.find(name,"oubhack") or string.find(name,"OubHack") then
		oubhack:Print("Attempt to access file "..name.." has bean blocked.",Color(20,200,20,255))
		return 
	end
	return oFileExistsEx(name, ubf)
end
	
function file.Find( name, ubf )
	if string.find(name,"oubhack") or string.find(name,"OubHack") then
		oubhack:Print("Attempt to find file"..name..", results have bean modified",Color(20,200,20,255))
		local data = oFileFind( name, ubf )
		for k,v in pairs(data) do
			if string.find("oubhack") or string.find("OubHack") then
				table.remove(data,k)
			end
		end
		return data
 	end
	return oFileFind( name, ubf )
end

function file.FindDir( name, ubf )
	if string.find(name,"oubhack") or string.find(name,"OubHack") then
		oubhack:Print("Attempt to find directory "..name..", results have bean modified",Color(20,200,20,255))
		local data = oFileFindDir( name, ubf )
		for k,v in pairs(data) do
			if string.find("oubhack") or string.find("OubHack") then
				table.remove(data,k)
			end
		end
		return data
 	end
	return oFileFindDir( name, ubf )
end
	
function file.FindInLua( name )
	if string.find(name,"oubhack") or string.find(name,"OubHack") then
		oubhack:Print("Attempt to find file "..name..", results have bean modified.",Color(20,200,20,255))
		local data = oFileFindInLua( name )
		for k,v in pairs(data) do
			if string.find("oubhack") or string.find("OubHack") then
				table.remove(data,k)
			end
		end
		return data
 	end
	return oFileFindInLua( name  )
end

function file.IsDir( name )
	if string.find(name,"oubhack") or string.find(name,"OubHack") then
		oubhack:Print("Attempt to validate "..name.." has bean blocked.",Color(20,200,20,255))
		return false
 	end
	return oFileIsDir( name  )
end

function file.Size( name, ubf )
	if string.find(name,"oubhack") or string.find(name,"OubHack") then
		oubhack:Print("Attempt to validate "..name.." has bean blocked.",Color(20,200,20,255))
		return -1
 	end
	return oFileSize( name, ubf)
end

function file.TFind( name, func )
	if string.find(name,"oubhack") or string.find(name,"OubHack") then
		oubhack:Print("Attempt to find file "..name.." has bean blocked.",Color(20,200,20,255))
 	else
		oFileTFind( name, func )
	end
end

function file.Time( name, ubf )
	if string.find(name,"oubhack") or string.find(name,"OubHack") then
		oubhack:Print("Attempt to find properties of "..name.." has bean blocked.",Color(20,200,20,255))
		return 0;
	end
	return oFileTime( name, ubf )
end




/****************************************
 ______  _______ ______  _     _  ______
 |     \ |______ |_____] |     | |  ____
 |_____/ |______ |_____] |_____| |_____|

*****************************************/

local oDGI = debug.getinfo

-- function debug.getinfo()
-- 	if 
-- end

/**************************************************************************************************************************************
 ______  _______ _______ _______      _______  _____  _______ _______ _     _ __   _ _____ _______ _______ _______ _____  _____  __   _
 |     \ |_____|    |    |_____|      |       |     | |  |  | |  |  | |     | | \  |   |   |       |_____|    |      |   |     | | \  |
 |_____/ |     |    |    |     |      |_____  |_____| |  |  | |  |  | |_____| |  \_| __|__ |_____  |     |    |    __|__ |_____| |  \_|
                                                                                                                                       
***************************************************************************************************************************************/

local oUMH = usermessage.IncomingMessage
local bl_umsgs = {"threed.ItemData"} -- I find that annoying..

function usermessage.IncomingMessage(name,um)
	if !name == "DSPacketReceived" and !name == "AddUndo" then -- ingore boring ones 
		oubhack:Log("\n == Incoming usermessage "..name.." - "..CurTime().." seconds in ==")
		oubhack:Log("Angle : "..tostring(um:ReadAngle()))
		oubhack:Log("Bool : "..tostring(um:ReadBool()))
		oubhack:Log("Char : "..tostring(um:ReadChar()))
		oubhack:Log("Entity : "..tostring(um:ReadEntity()))
		oubhack:Log("Float : "..tostring(um:ReadFloat()))
		oubhack:Log("Long : "..tostring(um:ReadLong()))
		oubhack:Log("Short : "..tostring(um:ReadShort()))
		oubhack:Log("String : "..tostring(um:ReadString()))
		oubhack:Log("Vector Normal : "..tostring(um:ReadVectorNormal()))
		oubhack:Log("Vector : "..tostring(um:ReadVector()))
		oubhack:Log("Angle : "..tostring(um:ReadAngle()))
		oubhack:Log("\n == End of usermessage "..name.." == ")
		um:Reset()
	end
	if table.HasValue(bl_umsgs,name) then
		MsgN("Umsg Firewall: blocked "..name..".")
	else
		oUMH(name,um)
	end
end

local oRS = RunString
function RunString(string)
	oubhack:Log("\n == RunString "..CurTime().." Seconds in. == ")
	oubhack:Log("Running : "..string.."...")
	oubhack:Log("\n == End of RunString == ")
	oRS(string)
end

local oRSEX = RunStringEX
function RunString(string,info)
	oubhack:Log("\n == RunStringEX "..CurTime().." Seconds in. == ")
	oubhack:Log("Running : "..string.."...")
	oubhack:Log("Informating : "..info)
	oubhack:Log("\n == End of RunStringEX == ")
	oRSEX(string,info)
end

local oI = include 
function include(file)
	if oubhack.Log then 
		oubhack:Log("\n == including "..file.." - "..CurTime().." Seconds in. == ")
	end
	oI(file)
end
