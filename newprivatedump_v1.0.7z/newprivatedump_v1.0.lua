--[[
	MOD/lua/luadump/newprivatedumpv1.lua [#53630 (#54974), 1540997136, UID:3619141917]
	✞ Zerphus ✞ | STEAM_0:0:37907551 <108.218.157.216:27005> | [05.07.14 07:38:45AM]
	===BadFile===
]]

-- Coded by Zerphus
-- Made all of this shit all over again after Steam went full retard.
-- This source is private and should not be shared. Fuck you if you share it to anybody else.
-- If you don't share this then I will appreciate you and will continue updating this shit.

if not CLIENT then return end
if C then _G.C = nil end 
local _R = debug.getregistry();

orange = Color(255,106,0)
lightblue = Color(0,255,34)
red = Color(255,0,0)
blue = Color(0,0,255)
green = Color(0,255,0)
white = Color(255,255,255)
yellow = Color(0,255,255)
local NewPrivateDumpV1 = {}

function NewPrivateDumpV1.Notify(dosound,col,msg)
        if col then
                col = col
        end
chat.AddText(lightblue, "[NewPrivateDumpV1V1] ", col, msg)
        if dosound == sound then
                local beep = Sound( "/buttons/button17.wav" )
                local beepsound = CreateSound( LocalPlayer(), beep )
                beepsound:Play()
        end
end
 
 
NewPrivateDumpV1.Notify(true,green,"has sucessfully loaded!")
 
local weed = Material( "vgui/hack/weed.png", nocull );
local shield = Material( "icon16/shield.png", nocull );
local shieldadd = Material( "icon16/shield_add.png", nocull );
local user = Material( "icon16/user.png", nocull );
local heart = Material( "icon16/heart.png", nocull );
local money = Material( "icon16/money.png", nocull );

function CreateTimer( sec, rep, func )
        local index = RandomString( 10 )       
        NewPrivateDumpV1.timers[ index ] = sec     
        timer.Create( index, sec, rep, func )
end
function RandomString( len )
        local ret = ""
                for i = 1 , len do
                        ret = ret .. string.char( math.random( 65 , 116 ) )
       end
        return ret
end
NewPrivateDumpV1.timers = {}
CreateClientConVar( "NewPrivateDumpV1_showadmins", 1, true, false )
CreateClientConVar( "NewPrivateDumpV1_rpgod", 1, true, false )
CreateClientConVar( "NewPrivateDumpV1_showspecs", 1, true, false )
CreateClientConVar( "NewPrivateDumpV1_sniper", 1, true, false )
CreateClientConVar( "NewPrivateDumpV1_weed", 1, true, false )
CreateClientConVar( "NewPrivateDumpV1_coke", 1, true, false )
CreateClientConVar( "NewPrivateDumpV1_printer", 1, true, false )
CreateClientConVar( "NewPrivateDumpV1_gmodz", 1, true, false )
CreateClientConVar( "NewPrivateDumpV1_norecoil", 1, true, false )
CreateClientConVar( "NewPrivateDumpV1_lazer", 1, true, false )
CreateClientConVar( "NewPrivateDumpV1_dd", 1, true, false )
CreateClientConVar( "NewPrivateDumpV1_box", 0, true, false )
CreateClientConVar( "NewPrivateDumpV1_c4", 1, true, false )
CreateClientConVar( "NewPrivateDumpV1_nospread", 1, true, false )
CreateClientConVar( "NewPrivateDumpV1_showspec", 1, true, false )
CreateClientConVar( "NewPrivateDumpV1_antiafk", 0, true, false )
CreateClientConVar( "NewPrivateDumpV1_autoreload", 1, true, false )
CreateClientConVar( "NewPrivateDumpV1_perp_playerinfo", 1, true, false )
CreateClientConVar( "NewPrivateDumpV1_ulxgag", 1, true, false )
speedhack_speed = CreateClientConVar( "NewPrivateDumpV1_speedhack_speed", 1, true, false )
NewPrivateDumpV1_speed = 1

--Check if player is alive or dead
local function MESPCheck(v)
	if v:Alive() == true && v:Health() ~= 0 && v:Health() >= 0 && v ~= LocalPlayer() && LocalPlayer():Alive() then
		return true
	else
		return false
	end
end

concommand.Add("NewPrivateDumpV1_dancin", function() _dancin = !_dancin  end)
concommand.Add("NewPrivateDumpV1_esp", function() _espon = !_espon  end)
concommand.Add("NewPrivateDumpV1_xray", function() _xray = !_xray surface.PlaySound( "common/bugreporter_succeeded.wav" ) end)
concommand.Add("NewPrivateDumpV1_allents", function() _allents = !_allents  end)
concommand.Add("NewPrivateDumpV1_crosshair", function() _crosson = !_crosson  end)
concommand.Add("NewPrivateDumpV1_wall", function() _wallon = !_wallon surface.PlaySound( "common/bugreporter_succeeded.wav" ) end)
concommand.Add("NewPrivateDumpV1_ent", function() _enton = !_enton surface.PlaySound( "common/bugreporter_succeeded.wav" ) end)
concommand.Add("NewPrivateDumpV1_printents", function() _printent = !_printent end)

local tblFonts = { }
tblFonts["Herp"] = {
    font = "Tahoma",
    size = 11,
    weight = 0,
    shadow = true,
}
for k,v in SortedPairs( tblFonts ) do
    surface.CreateFont( k, tblFonts[k] );
 
end


NewPrivateDumpV1.spectators = {}
NewPrivateDumpV1.admins = {}
NewPrivateDumpV1.superadmins = {}


 function Spectate()
        for k, v in pairs(player.GetAll()) do
                if (IsValid(v:GetObserverTarget()) and v:GetObserverTarget():IsPlayer() and v:GetObserverTarget() == LocalPlayer()) then
                        if(not table.HasValue(NewPrivateDumpV1.spectators, v)) then
                                table.insert(NewPrivateDumpV1.spectators, v);
                                        NewPrivateDumpV1.Notify(true,orange,""..v:Name().. " has begun to spectate you.")
                                        surface.PlaySound("buttons/blip1.wav")
                                end
                        end
                end
        
				
        for k, v in pairs(NewPrivateDumpV1.spectators) do
                if (not IsValid(v) or not IsValid(v:GetObserverTarget()) or not v:GetObserverTarget():IsPlayer() or (v:GetObserverTarget() ~= LocalPlayer())) then
                        table.remove(NewPrivateDumpV1.spectators, k);
                                NewPrivateDumpV1.Notify(true,green,""..v:Name().." has stopped spectating you.")
                        end
                end
				
				
				for k, v in pairs(player.GetAll()) do
                        if (v:IsSuperAdmin() and not table.HasValue(NewPrivateDumpV1.superadmins, v)) then
                                table.insert(NewPrivateDumpV1.superadmins, v);
                                NewPrivateDumpV1.Notify(true,white,"Super Admin " .. v:Name() .. " has joined the game.")
                                surface.PlaySound("buttons/blip1.wav");
								
                        end
                end
				
                for k, v in pairs(player.GetAll()) do
                        if (v:IsAdmin() and not table.HasValue(NewPrivateDumpV1.admins, v) and not v:IsSuperAdmin()) then
                                table.insert(NewPrivateDumpV1.admins, v);
                                NewPrivateDumpV1.Notify(true,white,"Admin " .. v:Name() .. " has joined the game.")
                                surface.PlaySound("buttons/blip1.wav");
								
                        end
                end
				

 
end
hook.Add("Think", "Spectate", Spectate)


--Aimbot


if not CLIENT then return end
if C then _G.C = nil end -- We don't want to be easily detected.
local _R = debug.getregistry();

local NewPrivateDumpV1    = {}
NewPrivateDumpV1.Commands = {}
NewPrivateDumpV1.ConVars  = {}
NewPrivateDumpV1.Hooks    = {}
NewPrivateDumpV1.MenuInfo = {}
NewPrivateDumpV1.Meta	   = { _G, hook, concommand, debug, file }
NewPrivateDumpV1.Settings = {}
NewPrivateDumpV1.World	   = { players = {} }

--[ RESET METATABLES ]--

function NewPrivateDumpV1:UnlockMeta()
	for i = 1, table.Count( NewPrivateDumpV1.Meta ) do
		rawset( NewPrivateDumpV1.Meta[i], "__metatable", false )
	end
end
NewPrivateDumpV1:UnlockMeta()

--[ OPTIMIZATION ]--

local cam				  = cam
local chat				  = chat
local draw				  = draw
local package			  = package
local player			  = player
local math				  = math
local render			  = render
local string			  = string
local surface			  = surface
local table				  = table
local team		 		  = team
local timer				  = timer
local util				  = util
local vgui				  = vgui
local Angle 			  = Angle
local Color 			  = Color
local EyeAngles			  = EyeAngles
local EyePos 			  = EyePos
local ipairs			  = ipairs
local pairs			 	  = pairs
local tobool			  = tobool
local tonumber			  = tonumber
local tostring			  = tostring
local type 				  = type
local unpack			  = unpack
local Vector 			  = Vector
local MsgN				  = MsgN
local IsValid 		  = IsValid
local RealFrameTime       = RealFrameTime
local CreateClientConVar  = CreateClientConVar
local CreateMaterial      = CreateMaterial
local AddConsoleCommand   = AddConsoleCommand


NewPrivateDumpV1.Copy = {
	hook		  = table.Copy( hook ),
	GetInt  	  = _R["ConVar"].GetInt,
	GetBool	 	  = _R["ConVar"].GetBool,
	SetViewAngles = _R["CUserCmd"].SetViewAngles
}

NewPrivateDumpV1.Vars = {
	osv 		 = 0,
	target		 = nil,
	aimlocked    = false,
	pkfake 	     = false,
	pkthrow 	 = false,
	firing  	 = false,
	found 	     = false,
	aimingang    = Angle( 0, 0, 0 ),
	fakeang 	 = Angle( 0, 0, 0 ),
	pkfakeang    = Angle( 0, 0, 0 ),
	pkthrowang   = Angle( 0, 0, 0 ),
	prefix	     = "NewPrivateDumpV1_"
}

function NewPrivateDumpV1:AddHook( name, func )
str = "hook"..math.random(1,200000000)
return hook.Add(name,str,func);
end

function NewPrivateDumpV1:AddCommand( name, func )
	return concommand.Add(name,func);
end


NewPrivateDumpV1.SetVars = {
	{ Name = "aim", Value = 0, Desc = "Aimbot Enabled", Type = "bool", Table = "aim", Menu = "aim" },
	{ Name = "aim_friendlyfire", Value = 1, Desc = "Aim at Teammates", Type = "bool", Table = "aimteam", Menu = "aim" },
	{ Name = "aim_ignoreadmins", Value = 0, Desc = "Ignore Admins", Type = "bool", Table = "ignoreadmins", Menu = "aim" },
	{ Name = "aim_ignoretraitors", Value = 0, Desc = "Ignore Friendly Traitors", Type = "bool", Table = "ignoretraitors", Menu = "aim" },
	{ Name = "aim_ignorefriends", Value = 1, Desc = "Ignore Steam Friends", Type = "bool", Table = "ignorefriends", Menu = "aim" },
	{ Name = "aim_autoshoot", Value = 1, Desc = "Autoshoot", Type = "bool", Table = "autoshoot", Menu = "aim" },
	{ Name = "aim_snaponfire", Value = 0, Desc = "Aim When Firing", Type = "bool", Table = "snaponfire", Menu = "aim" },
	{ Name = "aim_autowall", Value = 0, Desc = "Autowall (NOTE: Buggy, works with Mad Cow's weapon base only.)", Type = "bool", Table = "autowall", Menu = "aim" },
	{ Name = "aim_ignorevisibility", Value = 0, Desc = "Ignore Visibility Checks", Type = "bool", Table = "ignorevisibility", Menu = "aim" },
	{ Name = "aim_prediction", Value = 1, Desc = "Prediction", Type = "bool", Table = "prediction", Menu = "aim" },
	{ Name = "aim_prediction_val_tar", Value = 66, Desc = "Target Prediction", Type = "number", Table = "predictiontar", Max = 66, Min = 25, Menu = "aim" },
	{ Name = "aim_prediction_val_ply", Value = 45, Desc = "Local Prediction", Type = "number", Table = "predictionply", Max = 66, Min = 25, Menu = "aim" },
	{ Name = "aim_prediction_type", Value = 1, Table = "predictiontype" },
	{ Name = "aim_offset", Value = 0, Desc = "Offset Y", Type = "number", Table = "aimoffset", Max = 10, Min = -10, Menu = "aim" },
	{ Name = "aim_fov", Value = 12, Desc = "Aimbot FOV", Type = "number", Table = "aimfov", Max = 180, Min = 1, Menu = "aim" },
	{ Name = "aim_smooth_val", Value = 6, Desc = "Smooth Aim Speed", Type = "number", Table = "smoothspeed", Max = 12, Min = 4, Menu = "aim" },
	{ Name = "misc_novisrecoil", Value = 1, Desc = "No Visual Recoil", Type = "bool", Table = "novisrecoil", Menu = "misc" },
	{ Name = "misc_bunnyhop", Value = 1, Desc = "Bunnyhop", Type = "bool", Table = "bhop", Menu = "misc" },

	}

function NewPrivateDumpV1:CreateConVars()
	local tbl = NewPrivateDumpV1.SetVars
	for i = 1, table.Count( tbl ) do
		local v = tbl[i]
		local pvar = NewPrivateDumpV1.Vars.prefix .. v.Name
		local convar = CreateClientConVar( pvar, v.Value, true, false )
		local cvarinfo = {
			Name  = pvar,
			Value = v.Value,
			Desc  = v.Desc,
			Type  = v.Type,
			Max   = v.Max,
			Min   = v.Min,
			Menu  = v.Menu
		}
		NewPrivateDumpV1.Settings[v.Table] = convar:GetInt() -- Store a value for our callback table.
		NewPrivateDumpV1.MenuInfo[pvar] = cvarinfo
		NewPrivateDumpV1.MenuInfo[#NewPrivateDumpV1.MenuInfo + 1] = cvarinfo
		cvars.AddChangeCallback( pvar, function( cvar, old, new )
			NewPrivateDumpV1.Settings[v.Table] = new
		end )
	
		NewPrivateDumpV1.ConVars[pvar] = convar
	end
end
NewPrivateDumpV1:CreateConVars()

MsgC( Color( 255, 255, 255 ),":: " )
MsgC(  Color( 255, 0, 0 ),"Convars created.\n" )


function NewPrivateDumpV1:G( name, val )
	if ( tonumber( name ) == val ) then return true end
	return false
end

function NewPrivateDumpV1:IsAdmin( e )
	if e:IsAdmin() or e:IsSuperAdmin() then return true end
	return false
end

function NewPrivateDumpV1:IsFriend( e )
	if ( e:GetFriendStatus() == "friend" ) then return true end
	return false
end

function NewPrivateDumpV1:IsTTT()
	if string.find( string.lower( GAMEMODE.Name ), "trouble in terror" ) then return true end
	return false
end

function NewPrivateDumpV1:IsTraitor( e )
	local ply = LocalPlayer()
	if not NewPrivateDumpV1:IsTTT() then return end
	if ply:IsTraitor() and e:IsTraitor() then return true end
	return false
end

function NewPrivateDumpV1:IsTargetValid( e, typ )
	local ply, str, fov = LocalPlayer(), tostring( typ ), tonumber( NewPrivateDumpV1.Settings['aimfov'] )
	if ( str == "aim" ) then
		if not IsValid( e ) or ( ply == e ) then return false end
		if not e:Alive() then return false end
		if NewPrivateDumpV1:IsAdmin( e ) and NewPrivateDumpV1:G( NewPrivateDumpV1.Settings['ignoreadmins'], 1 ) then return false end
		if NewPrivateDumpV1:IsTraitor( e ) and NewPrivateDumpV1:G( NewPrivateDumpV1.Settings['ignoretraitors'], 1 ) then return false end
		if NewPrivateDumpV1:IsFriend( e ) and NewPrivateDumpV1:G( NewPrivateDumpV1.Settings['ignorefriends'], 1 ) then return false end
		if ( e:Team() == ply:Team() ) and NewPrivateDumpV1:G( NewPrivateDumpV1.Settings['aimteam'], 0 ) then return false end
		if string.find( string.lower( team.GetName( e:Team() ) ), "spec" ) then return false end	
		if ( e:GetMoveType() == MOVETYPE_NONE ) then return false end
		if ( e:GetMoveType() == MOVETYPE_OBSERVER ) then return false end
		if ( fov ~= 180 ) then
			local ang = ( e:GetPos() - ply:GetShootPos() ):Angle()
			local yaw = math.abs( math.NormalizeAngle( ply:GetAngles().y - ang.y ) )
			local pitch = math.abs( math.NormalizeAngle( ply:GetAngles().p - ang.p ) )
			if ( yaw > fov ) or ( pitch > fov ) then return false end
		end
		return true
	elseif ( str == "esp" ) then
		if not IsValid( e ) or ( ply == e ) then return false end
		if not e:Alive() then return false end
		if string.find( string.lower( team.GetName( e:Team() ) ), "spec" ) then return false end
		if ( e:GetMoveType() == MOVETYPE_NONE ) then return false end
		if ( e:GetMoveType() == MOVETYPE_OBSERVER ) then return false end
		if not NewPrivateDumpV1:IsOnScreen( e ) then return false end
		return true
	elseif ( str == "chams" ) then -- For coloring based on aimbot targets.
		if not IsValid( e ) or ( ply == e ) then return false end
		if not e:Alive() then return false end
		if NewPrivateDumpV1:IsAdmin( e ) and NewPrivateDumpV1:G( NewPrivateDumpV1.Settings['ignoreadmins'], 1 ) then return false end
		if NewPrivateDumpV1:IsTraitor( e ) and NewPrivateDumpV1:G( NewPrivateDumpV1.Settings['ignoretraitors'], 1 ) then return false end
		if NewPrivateDumpV1:IsFriend( e ) and NewPrivateDumpV1:G( NewPrivateDumpV1.Settings['ignorefriends'], 1 ) then return false end
		if ( e:Team() == ply:Team() ) and NewPrivateDumpV1:G( NewPrivateDumpV1.Settings['aimteam'], 0 ) then return false end
		if string.find( string.lower( team.GetName( e:Team() ) ), "spec" ) then return false end	
		if ( e:GetMoveType() == MOVETYPE_NONE ) then return false end
		if ( e:GetMoveType() == MOVETYPE_OBSERVER ) then return false end
		return true
	end
	return false
end

--[[--------------------------------------------
	AIMBOT
--]]--------------------------------------------

--[ TARGET LOCATION ]--

NewPrivateDumpV1.ZombieModels = {
	{ "models/zombie/fast_torso.mdl",	  "ValveBiped.HC_BodyCube" },
	{ "models/zombie/fast.mdl",			  "ValveBiped.HC_BodyCube" },
	{ "models/headcrabclassic.mdl",		  "HeadcrabClassic.SpineControl" },
	{ "models/headcrabblack.mdl",		  "HCBlack.body" },
	{ "models/headcrab.mdl",			  "HCFast.body" },
	{ "models/zombie/poison.mdl",		  "ValveBiped.Headcrab_Cube1" },
	{ "models/zombie/classic.mdl",		  "ValveBiped.HC_Body_Bone" },
	{ "models/zombie/classic_torso.mdl",  "ValveBiped.HC_Body_Bone" },
	{ "models/zombie/zombie_soldier.mdl", "ValveBiped.HC_Body_Bone" },
}

function NewPrivateDumpV1:GetPosition( e, pos, typ )
	if ( tostring( typ ) == "attachment" ) then
		return e:GetAttachment( e:LookupAttachment( pos ) )
	elseif ( tostring( typ ) == "bone" ) then
		return e:GetBonePosition( e:LookupBone( pos ) )
	end
end

function NewPrivateDumpV1:GetTargetLocation( e )
	for i = 1, table.Count( NewPrivateDumpV1.ZombieModels ) do
		if ( e:GetModel() == NewPrivateDumpV1.ZombieModels[i][1] ) then return NewPrivateDumpV1:GetPosition( e, NewPrivateDumpV1.ZombieModels[i][2], "bone" ) end
	end
	if ( e:LookupAttachment( "forward" ) ~= 0 ) then -- CSS models.
		local forward = NewPrivateDumpV1:GetPosition( e, "forward", "attachment" )
		if forward and forward.Pos then return forward.Pos end
	end
	if ( e:LookupAttachment( "eyes" ) ~= 0 ) then -- General humanoid models.
		eyes = NewPrivateDumpV1:GetPosition( e, "eyes", "attachment" )
		if eyes and eyes.Pos then return eyes.Pos end
	end
	if e:LookupBone( "ValveBiped.Bip01_Head1" ) then -- Backup head position.
		return NewPrivateDumpV1:GetPosition( e, "ValveBiped.Bip01_Head1", "bone" )
	end
	return e:LocalToWorld( e:OBBCenter() ) -- Anything else.
end

--[ PREDICTION ]--

function NewPrivateDumpV1:GetPredictionPos( e )
return Vector( 0, 0, 0 )
end

--[ AUTOWALL ]--

function NewPrivateDumpV1:IsPenetrable( tr ) -- Thanks noPE.
	local ply, maxpenetration = LocalPlayer(), 16
	local wep = ply:GetActiveWeapon()
	if ( wep.Base == "weapon_mad_base" ) then -- The only widely used weapon base with penetration capability.
		if ( wep.Primary.Ammo == "AirboatGun" ) then -- 5.56mm
			maxpenetration = 18
		elseif ( wep.Primary.Ammo == "Gravity" ) then -- 4.6mm
			maxpenetration = 8
		elseif ( wep.Primary.Ammo == "AlyxGun" ) then -- 5.7mm
			maxpenetration = 12
		elseif ( wep.Primary.Ammo == "Battery" ) then -- 9mm
			maxpenetration = 14
		elseif ( wep.Primary.Ammo == "StriderMinigun" ) or ( wep.Primary.Ammo == "CombineCannon" ) then -- 7.62mm and .50AE respectively.
			maxpenetration = 20
		elseif ( wep.Primary.Ammo == "SniperPenetratedRound" ) then -- .45ACP
			maxpenetration = 16
		else
			maxpenetration = 16
		end
		if not tr.Entity:IsPlayer() then -- Don't ignore what we want to aim at.
			if ( ( tr.MatType == MAT_METAL ) and wep.Ricochet ) or ( tr.MatType == MAT_SAND ) then return false end -- Not penetrable.
			local direction = tr.Normal * maxpenetration
			local surfaces = { MAT_GLASS, MAT_PLASTIC, MAT_WOOD, MAT_FLESH, MAT_ALIENFLESH }
			for i = 1, table.Count( surfaces ) do
				if ( tr.MatType == surfaces[i] ) then direction = tr.Normal * ( maxpenetration * 2 ) end
			end
			local trace = util.TraceLine( {
				start = tr.HitPos + direction,
				endpos = tr.HitPos,
				filter = { wep.Owner },
				mask = MASK_SHOT
			} )
			if trace.StartSolid or ( trace.Fraction >= 1.0 ) or ( tr.Fraction <= 0.0 ) then return false end -- Bullet didn't penetrate.
		end
	else
		return false
	end
	return true
end

--[ VISIBILITY CHECK ]--

function NewPrivateDumpV1:TargetVisible( e )
	local ply = LocalPlayer()
	if NewPrivateDumpV1:G( NewPrivateDumpV1.Settings['ignorevisibility'], 1 ) then return true end
	local trace = util.TraceLine( {
		start = ply:GetShootPos(),
		endpos = NewPrivateDumpV1:GetTargetLocation( e ) + NewPrivateDumpV1:GetPredictionPos( e ),
		filter = { ply, e },
		mask = MASK_SHOT + CONTENTS_WINDOW
	} )
	if ( trace.Fraction >= 0.99 ) or ( NewPrivateDumpV1:G( NewPrivateDumpV1.Settings['autowall'], 1 ) and NewPrivateDumpV1:IsPenetrable( trace ) ) then return true end
	return false
end

--[ CLOSEST-TO-CROSSHAIR TARGETING ]--

function NewPrivateDumpV1:GetAimTarget()
	if NewPrivateDumpV1:IsTargetValid( NewPrivateDumpV1.Vars.target, "aim" ) and NewPrivateDumpV1:TargetVisible( NewPrivateDumpV1.Vars.target ) then return NewPrivateDumpV1.Vars.target else NewPrivateDumpV1.Vars.target = nil end
	local ply, tar = LocalPlayer(), { 0, 0 } -- SlobBot sorting.
	if NewPrivateDumpV1:G( NewPrivateDumpV1.Settings['aim'], 1 ) then
		for i = 1, table.Count( NewPrivateDumpV1.World.players ) do
			local e = NewPrivateDumpV1.World.players[i]
			if NewPrivateDumpV1:IsTargetValid( e, "aim" ) and NewPrivateDumpV1:TargetVisible( e ) then
				local pos = NewPrivateDumpV1:GetTargetLocation( e ) + NewPrivateDumpV1:GetPredictionPos( e )
				local vec = ( pos - ply:GetShootPos() ):GetNormal()
				local d = math.deg( math.acos( ply:GetAimVector():Dot( vec ) ) ) -- AA:AngleBetween.
				if ( d < tar[2] ) or ( tar[1] == 0 ) then -- Check if our distance is shorter than prevously, or if we haven't acquired a target yet.
					tar = { e, d }
				end
			end
		end
	end
	return ( ( tar[1] ~= 0 ) and ( tar[1] ~= ply ) and tar[1] ) or nil
end

--[ SMOOTH AIM ]--

function NewPrivateDumpV1:GetSmoothAngle( ang )
	local ply = LocalPlayer()
	local smoothang = Angle( 0, 0, 0 )
	if NewPrivateDumpV1:G( NewPrivateDumpV1.Settings['aimsmooth'], 1 ) then
		local speed = RealFrameTime() / ( tonumber( NewPrivateDumpV1.Settings['smoothspeed'] ) / 100 )
		smoothang = LerpAngle( speed, ply:GetAimVector():Angle(), ang )
	else
		return Angle( ang.p, ang.y, 0 )
	end
	return Angle( smoothang.p, smoothang.y, 0 )
end

--[ KEEP ANGLES ]--

function NewPrivateDumpV1.OnToggled()
	local ply = LocalPlayer()
	if not IsValid( ply ) then return end
	NewPrivateDumpV1.Vars.aacorrectang = ply:GetAimVector():Angle()
	NewPrivateDumpV1.Vars.fakeang = ply:GetAimVector():Angle()
end
NewPrivateDumpV1:AddHook( "OnToggled", NewPrivateDumpV1.OnToggled )

--[ AIMBOT ]--

function NewPrivateDumpV1.Aimbot( cmd )
	local ply, tar = LocalPlayer(), NewPrivateDumpV1:GetAimTarget()
	local wep = ply:GetActiveWeapon()
	NewPrivateDumpV1.Vars.fakeang.p = math.Clamp( NewPrivateDumpV1.Vars.fakeang.p + ( cmd:GetMouseY() * 0.022 ), -89, 90 )
	NewPrivateDumpV1.Vars.fakeang.y = math.NormalizeAngle( NewPrivateDumpV1.Vars.fakeang.y + ( cmd:GetMouseX() * -0.022 ) )
	if NewPrivateDumpV1:G( NewPrivateDumpV1.Settings['aimsilent'], 1 ) and NewPrivateDumpV1:G( NewPrivateDumpV1.Settings['antiaim'], 0 ) then
		NewPrivateDumpV1.Copy.SetViewAngles( cmd, NewPrivateDumpV1.Vars.fakeang )
	end
	if NewPrivateDumpV1:G( NewPrivateDumpV1.Settings['aim'], 1 ) and ply:Alive() and tar then
		NewPrivateDumpV1.Vars.target = tar
		NewPrivateDumpV1.Vars.found = true
		local pos = NewPrivateDumpV1:GetTargetLocation( tar ) + NewPrivateDumpV1:GetPredictionPos( tar )
		pos = pos + Vector( 0, 0, tonumber( NewPrivateDumpV1.Settings['aimoffset'] ) )
		local ang = ( pos - ply:GetShootPos() ):Angle()
		NewPrivateDumpV1.Vars.aimingang = ang
		ang = NewPrivateDumpV1:GetSmoothAngle( ang )
		if NewPrivateDumpV1:G( NewPrivateDumpV1.Settings['nospread'], 1 ) and NewPrivateDumpV1:G( NewPrivateDumpV1.Settings['aimsmooth'], 0 ) then
			ang = NewPrivateDumpV1:PredictSpread( cmd, ang )
		end
		ang = Angle( math.NormalizeAngle( ang.p ), math.NormalizeAngle( ang.y ), 0 )
		if NewPrivateDumpV1:G( NewPrivateDumpV1.Settings['snaponfire'], 1 ) then
			if cmd:KeyDown( IN_ATTACK ) then
				NewPrivateDumpV1.Copy.SetViewAngles( cmd, ang )
				NewPrivateDumpV1.Vars.aimlocked = true
			else
				NewPrivateDumpV1.Vars.aimlocked = false
			end
		else
			NewPrivateDumpV1.Copy.SetViewAngles( cmd, ang )
			NewPrivateDumpV1.Vars.aimlocked = true
		end
		if NewPrivateDumpV1:G( NewPrivateDumpV1.Settings['autoshoot'], 1 ) and not NewPrivateDumpV1.Vars.firing then
			RunConsoleCommand( "+attack" )
			NewPrivateDumpV1.Vars.firing = true
			timer.Simple( ( wep.Primary and wep.Primary.Delay ) or 0.05, function()
				RunConsoleCommand( "-attack" )
				NewPrivateDumpV1.Vars.firing = false
			end )
		end
	else
		NewPrivateDumpV1.Vars.target = nil
		NewPrivateDumpV1.Vars.aimlocked = false
		NewPrivateDumpV1.Vars.found = false
	end
	if NewPrivateDumpV1:G( NewPrivateDumpV1.Settings['aimsilent'], 1 ) and NewPrivateDumpV1.Vars.aimlocked then
		local move = Vector( cmd:GetForwardMove(), cmd:GetSideMove(), 0 )
		local norm = move:GetNormal()
		local set = ( norm:Angle() + ( NewPrivateDumpV1.Vars.aimingang - NewPrivateDumpV1.Vars.fakeang ) ):Forward() * move:Length()
		cmd:SetForwardMove( set.x )
		cmd:SetSideMove( set.y )
	end
end
concommand.Add("+co_derp", NewPrivateDumpV1.Aimbot)

--[[--------------------------------------------
	CALCVIEW
--]]--------------------------------------------

function NewPrivateDumpV1.CalcView( e, origin, angles )
	local ply = LocalPlayer()
	local wep = ply:GetActiveWeapon()
	if wep.Primary then wep.Primary.Recoil = 0 end
	if wep.Secondary then wep.Secondary.Recoil = 0 end
	local view = GAMEMODE:CalcView( e, origin, angles ) or {}
	if NewPrivateDumpV1:G( NewPrivateDumpV1.Settings['calcview'], 1 ) then
		if NewPrivateDumpV1.Vars.pkfake and NewPrivateDumpV1:IsTTT() then
			view.angles = NewPrivateDumpV1.Vars.pkfakeang
		elseif NewPrivateDumpV1.Vars.aimlocked and NewPrivateDumpV1:G( NewPrivateDumpV1.Settings['aimsmooth'], 1 ) and NewPrivateDumpV1:G( NewPrivateDumpV1.Settings['aimsilent'], 0 ) then
			view.angles = ply:GetAimVector():Angle()
		elseif NewPrivateDumpV1.Vars.aimlocked and NewPrivateDumpV1:G( NewPrivateDumpV1.Settings['aimsilent'], 0 ) then
			view.angles = NewPrivateDumpV1.Vars.aimingang
		elseif NewPrivateDumpV1:G( NewPrivateDumpV1.Settings['aimsilent'], 1 ) or NewPrivateDumpV1:G( NewPrivateDumpV1.Settings['antiaim'], 1 ) then
			view.angles = NewPrivateDumpV1.Vars.fakeang
		elseif NewPrivateDumpV1:G( NewPrivateDumpV1.Settings['aimsilent'], 1 ) and NewPrivateDumpV1:G( NewPrivateDumpV1.Settings['novisrecoil'], 1 ) then
			view.angles = NewPrivateDumpV1.Vars.fakeang
		elseif NewPrivateDumpV1:G( NewPrivateDumpV1.Settings['novisrecoil'], 1 ) and NewPrivateDumpV1:G( NewPrivateDumpV1.Settings['aimsilent'], 0 ) then
			view.angles = ply:GetAimVector():Angle()
		else
			view = GAMEMODE:CalcView( e, origin, angles )
		end
	else
		view = GAMEMODE:CalcView( e, origin, angles )
	end
	return view
end
NewPrivateDumpV1:AddHook( "CalcView", NewPrivateDumpV1.CalcView )


--[[--------------------------------------------
	PLAYERS AND ENTITIES
--]]--------------------------------------------

function NewPrivateDumpV1.GetAllPlayers()
	NewPrivateDumpV1.World.players = {}
	for i = 1, table.Count( player.GetAll() ) do
		local e = player.GetAll()[i]
		if IsValid( e ) then table.insert( NewPrivateDumpV1.World.players, e ) end
	end
end


--[[--------------------------------------------
	BUNNYHOP
--]]--------------------------------------------


function NewPrivateDumpV1.Bunnyhop( cmd )	
	local ply = LocalPlayer()
	if NewPrivateDumpV1:G( NewPrivateDumpV1.Settings['bhop'], 1 ) then
		if ( ply:GetMoveType() ~= MOVETYPE_WALK ) then return end
		if ply and cmd:KeyDown( IN_JUMP ) then
			if ply:IsOnGround() then
				cmd:SetButtons( cmd:GetButtons() , IN_JUMP )
			else
				cmd:SetButtons( cmd:GetButtons() - IN_JUMP )
			end
		end
	end
end


--[[--------------------------------------------
	HOOKED FUNCTIONS
--]]--------------------------------------------

function NewPrivateDumpV1.CreateMove( cmd )
	NewPrivateDumpV1.Aimbot( cmd )
	NewPrivateDumpV1.Bunnyhop( cmd )
end
NewPrivateDumpV1:AddHook( "CreateMove", NewPrivateDumpV1.CreateMove )

function NewPrivateDumpV1.ThinkHook()
	NewPrivateDumpV1.GetAllPlayers()
end
NewPrivateDumpV1:AddHook( "Think", NewPrivateDumpV1.ThinkHook )


--ESP
hook.Add("HUDPaint", "ESP", function()
	for k,v in pairs(player.GetAll()) do
		if _espon then
			if(v ~= LocalPlayer() and MESPCheck(v)) then
				local ESP = (v:GetPos()):ToScreen()
				local ESP2 = (v:EyePos()):ToScreen()
				if v:IsAdmin() and v:IsSuperAdmin() == false then
					draw.DrawText(v:Name(), "Herp", ESP.x, ESP.y +18, team.GetColor(v:Team()), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
					surface.SetMaterial( shield ); surface.SetDrawColor( Color( 255, 255, 255, 255 ) ); surface.DrawTexturedRect( ESP.x - 7, ESP.y + 30, 16, 16 );
				elseif v:IsSuperAdmin() == true then
					draw.DrawText(v:Name(), "Herp", ESP.x, ESP.y +18, team.GetColor(v:Team()), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
					surface.SetMaterial( shieldadd ); surface.SetDrawColor( Color( 255, 255, 255, 255 ) ); surface.DrawTexturedRect( ESP.x - 8, ESP.y + 30, 16, 16 );
				else
					draw.DrawText(v:Name(), "Herp", ESP.x, ESP.y +18, team.GetColor(v:Team()), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
					surface.SetMaterial( user ); surface.SetDrawColor( Color( 255, 255, 255, 255 ) ); surface.DrawTexturedRect( ESP.x - 8, ESP.y + 30, 16, 16 );
				end
				draw.RoundedBox(0, ESP.x - 21, ESP.y +49, 42, 7, Color(0,0,0,255))
				draw.RoundedBox(0, ESP.x - 20, ESP.y +50, 40 * math.Clamp(v:Health(), 0, 100) / 100, 5, Color(255,0,0,255))
				draw.RoundedBox(0, ESP.x - 20, ESP.y +50, 40 * math.Clamp(v:Health(), 0, 100) / 100, 2.5, Color(255,255,255,30))
				draw.DrawText(v:Health(), "Herp", ESP.x, ESP.y +46, Color(255, 255, 255, 255), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
				end 
						end
		end
	end)
hook.Add("HUDPaint", "PERP", function()
	for k,v in pairs(player.GetAll()) do
	if ( gmod.GetGamemode().Name ) == "PERP" or ( gmod.GetGamemode().Name ) == "RealityRoleplay" then
		if _espon then
			if(v ~= LocalPlayer() and MESPCheck(v)) then
				local ESP = (v:GetPos()):ToScreen()
				draw.DrawText(v:GetRPName(), "Herp", ESP.x, ESP.y +7, team.GetColor(v:Team()), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
end
end
end
end
end)

	
 --Crosshair
hook.Add("HUDPaint", "Crosshair", function()
if _crosson then
	 surface.SetDrawColor( Color(0, 80, 255, 255) );
     surface.SetMaterial( Material("vgui/hack/crosshair.png") );
     surface.DrawTexturedRect(ScrW() / 2 - 7, ScrH() / 2 - 7, 15, 15);
 end
 end)
 

--Box
local function coordinates( ent )
local min, max = ent:OBBMins(), ent:OBBMaxs()
local corners = {
    Vector( min.x, min.y, min.z ),
    Vector( min.x, min.y, max.z ),
    Vector( min.x, max.y, min.z ),
    Vector( min.x, max.y, max.z ),
    Vector( max.x, min.y, min.z ),
    Vector( max.x, min.y, max.z ),
    Vector( max.x, max.y, min.z ),
    Vector( max.x, max.y, max.z )
}

local minX, minY, maxX, maxY = ScrW() * 2, ScrH() * 2, 0, 0
for _, corner in pairs( corners ) do
    local onScreen = ent:LocalToWorld( corner ):ToScreen()
    minX, minY = math.min( minX, onScreen.x ), math.min( minY, onScreen.y )
    maxX, maxY = math.max( maxX, onScreen.x ), math.max( maxY, onScreen.y )
end

return minX, minY, maxX, maxY
end
hook.Add("HUDPaint", "BoxESP", function()
if(GetConVarNumber("NewPrivateDumpV1_box") == 1) and _espon then
for k,v in pairs(player.GetAll()) do
if(v ~= LocalPlayer() and MESPCheck(v)) then
    local Box1x,Box1y,Box2x,Box2y = coordinates(v)
    surface.SetDrawColor(team.GetColor(v:Team()))
    surface.DrawLine( Box1x, Box1y, math.min( Box1x + 5, Box2x ), Box1y )
    surface.DrawLine( Box1x, Box1y, Box1x, math.min( Box1y + 5, Box2y ) )
    surface.DrawLine( Box2x, Box1y, math.max( Box2x - 5, Box1x ), Box1y )
    surface.DrawLine( Box2x, Box1y, Box2x, math.min( Box1y + 5, Box2y ) )
    surface.DrawLine( Box1x, Box2y, math.min( Box1x + 5, Box2x ), Box2y )
    surface.DrawLine( Box1x, Box2y, Box1x, math.max( Box2y - 5, Box1y ) )
    surface.DrawLine( Box2x, Box2y, math.max( Box2x - 5, Box1x ), Box2y )
    surface.DrawLine( Box2x, Box2y, Box2x, math.max( Box2y - 5, Box1y ) )
end
end
end
end)
--I know, I was lazy so I used Skittles.


local t = getfenv( 0 )
_R = t.debug.getregistry()
m = t.LocalPlayer()


--AntiAFK
local commands = { "forward" , "back" , "jump" , "moveleft" , "moveright", "duck" }
function AntiAfk()
        if GetConVarNumber("NewPrivateDumpV1_antiafk") == 1 then
                local command1 = table.Random( commands )
                local command2 = table.Random( commands )
                CreateTimer( 1, 1, function()
                        RunConsoleCommand( "+"..command1 )
                        RunConsoleCommand( "+"..command2 )
                end )
                CreateTimer( 2, 1, function()
                        RunConsoleCommand("-"..command1 )
                        RunConsoleCommand("-"..command2 )
                end )
        end
end
CreateTimer( 5 , 0 , function() AntiAfk() end )


do --Convenience functions
	function NewPrivateDumpV1.BonePos( pl, bone )
		return pl:GetBonePosition( pl:LookupBone( bone ) )
	end
	function NewPrivateDumpV1.Dist( p1, p2 )
		return p1:GetPos():Distance( p2:GetPos() )
	end
	function NewPrivateDumpV1.Concat( ... )
		return t.string.format( t.string.rep( '%s', t.table.Count( { ... } ) ), ... )
	end
	function NewPrivateDumpV1.RandString()
		local str, len = '', t.math.random( 1, 7 )
 
		while #str < len do
			NewPrivateDumpV1.Concat( str, t.string.char( t.math.random( 97, 122 ) ) )
		end
		return str
	end
	function NewPrivateDumpV1.IsInSight( pl )
		local tr = t.util.TraceLine( { start = t.LocalPlayer():GetShootPos(), endpos = pl:GetPos() + t.Vector( 0, 0, 40 ), filter = { t.LocalPlayer(), pl } } )
    	return tr.Fraction == 1
    end
	
    function NewPrivateDumpV1.CalcVelocity( target )
    	local hcbow = m:GetActiveWeapon():GetClass() == 'weapon_crossbow'
    	if hcbow then
    		local dist = NewPrivateDumpV1.Dist( target, m )
    		return target:GetVelocity() * ( dist / 3100 ) + t.Vector( 0, 0, dist / 500 )
    	end
    	return target:GetVelocity() * 0.01
    end
	function NewPrivateDumpV1.RankInfo( pl )
		if NewPrivateDumpV1.vars.amod == 1 then
			local rank = evolve.ranks[ pl:EV_GetRank() ]
			return {
				name = rank.Title,
				color = t.Color( rank.Color.r, rank.Color.g, rank.Color.b, 255 )
			}
		elseif NewPrivateDumpV1.vars.amod == 2 then
			return {
				name = t.team.GetName( pl:Team() ),
				color = t.team.GetColor( pl:Team() )
			}
		else
			return {
				name = pl:IsSuperAdmin() and 'Super Admin' or ( pl:IsAdmin() and 'Admin' or 'Player' ),
				color = t.team.GetColor( pl:Team() )
			}
		end
	end
end

NewPrivateDumpV1.RCC = RunConsoleCommand



--TTT Propkill
 
concommand.Add("+Propkill", function()
propkill1 = 1
        end)
 
concommand.Add("-Propkill", function()
propkill1 = 0
        end)
 
function OpenS()
orA = LocalPlayer():EyeAngles() - Angle( 0 , 180 , 0 )
Test = LocalPlayer():EyeAngles()
        end
hook.Add("Think","Tesasd",OpenS)
 
function ReCalc(cmd)
if propkill1 == 1 then
orA.p = math.Clamp(orA.p + (cmd:GetMouseY() * 0.022), -89, 89)
orA.y = math.NormalizeAngle(orA.y + (cmd:GetMouseX() * 0.022 * -1))
orA.r = 0
 
local Forward = ((Vector(cmd:GetForwardMove(), cmd:GetSideMove(), 0):GetNormal():Angle() + (cmd:GetViewAngles() - orA)):Forward() * Vector(cmd:GetForwardMove(), cmd:GetSideMove(), 0):Length())
cmd:SetForwardMove(Forward.x)
cmd:SetSideMove(Forward.y)
 
        end
 end
hook.Add("CreateMove", "StoredAngleRecalc", ReCalc)
 
 
function Calc(ply, pos, angles, fov)
local view = {}
view.origin = pos
if GetViewEntity() == LocalPlayer() and propkill1 == 1 then
view.angles = orA
        end
view.fov = fov
return view
        end
hook.Add("CalcView", "NegTin", Calc)
 
function Throw()
if (LocalPlayer():KeyDown(IN_SPEED)) and propkill1 == 1 then
 
LocalPlayer():SetEyeAngles( Angle ( orA.p , orA.y , orA.r ) )
 
propkill1 = 0
 
                end
        end
hook.Add("Think","ThrowProp1",Throw)


--Traitor Detector
CreateClientConVar( "NewPrivateDumpV1_traitor", 0, true, false )              
local twep = {"spiderman's_swep", "weapon_ttt_trait_defilibrator", "weapon_ttt_xbow", "weapon_ttt_dhook", "weapon_awp", "weapon_ttt_ak47", "weapon_jihadbomb", "weapon_ttt_knife", "weapon_ttt_c4", "weapon_ttt_decoy", "weapon_ttt_flaregun", "weapon_ttt_phammer", "weapon_ttt_push", "weapon_ttt_radio", "weapon_ttt_sipistol", "weapon_ttt_teleport", "weapon_ttt_awp", "weapon_ttt_silencedsniper", "weapon_ttt_turtlenade", "weapon_ttt_death_station", "weapon_ttt_sg552", "weapon_ttt_tripmine"}
if ( gmod.GetGamemode().Name ) == "TTT" or ( gmod.GetGamemode().Name ) == "Trouble in Terrorist Town" and GetConVarNumber("NewPrivateDumpV1_traitor") == 1 then

for _,v in pairs(player.GetAll()) do
        v.HatTraitor = nil
end
for _,v in pairs(ents.GetAll()) do
        v.HatESPTracked = nil
end

hook.Add("PostDrawOpaqueRenderables", "wire_animations_idle", function()
function NewPrivateDumpV1.Notify(dosound,col,msg)
        if col then
                col = col
        end
chat.AddText(Color(0,150,255), "[NewPrivateDumpV1] ", col, msg)
        if dosound == sound then
                local beep = Sound( "/buttons/button17.wav" )
                local beepsound = CreateSound( LocalPlayer(), beep )
                beepsound:Play()
        end
end

        if GAMEMODE.round_state != ROUND_ACTIVE then
                for _,v in pairs(player.GetAll()) do
                        v.HatTraitor = nil
                end
                for _,v in pairs(ents.GetAll()) do
                        v.HatESPTracked = nil
                end
                return
        end
        for _,v in pairs( ents.GetAll() ) do
                if v and IsValid(v) and (table.HasValue(twep, v:GetClass()) and !v.HatESPTracked) then
                        local pl = v.Owner
                        if pl and IsValid(pl) and pl:IsTerror() then
                                if pl:IsDetective() then
                                        v.HatESPTracked = true
                                else
                                        v.HatESPTracked = true
                                        pl.HatTraitor = true
										NewPrivateDumpV1.Notify(true,red,"Player "..pl:Name().." has traitor weapon ".. "[ ".. v:GetClass().." ]")
										surface.PlaySound("buttons/blip1.wav")

                                end
                        end
                end
        end
   end)
   end
                          

function C4ESP()
for k, v in pairs( ents.FindByClass( "ttt_c4" ) ) do
if IsValid( v ) then
 
if GetConVarNumber( "NewPrivateDumpV1_c4" ) >= 1 then
 
local C4ESPPos = ( v:GetPos() ):ToScreen()
 
if !v:GetArmed() then
draw.SimpleText( "C4", "Herp", C4ESPPos.x, C4ESPPos.y - 22, Color( 255, 0, 0, 255 ), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER )
end
 
if v:GetArmed() then
draw.SimpleText( "C4 Time until Explosion: " .. string.FormattedTime( math.max( 0, v:GetExplodeTime() - CurTime() ), "%02i:%02i" ), "Herp", C4ESPPos.x, C4ESPPos.y - 22, Color( 255, 0, 0, 255 ), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER )
   end
end
 
if v:GetPos():Distance( LocalPlayer():GetPos() ) < 1000 and v:GetArmed() then
draw.DrawText( "In range of C4 explosion!", "Herp", ScrW() / 2 / 2 +60, ScrH()/2 * 2 - 20, Color( 255, 0, 0, 255 ), TEXT_ALIGN_LEFT, TEXT_ALIGN_LEFT, 1, Color( 255, 255, 255, 255 ) )
         end
      end
end
end	  
hook.Add( "HUDPaint", "C4ESP", C4ESP )
 
function TraitorESP()
if ( gmod.GetGamemode().Name ) == "TTT" or ( gmod.GetGamemode().Name ) == "Trouble in Terrorist Town" then
for k,v in pairs ( player.GetAll() ) do
if(v ~= LocalPlayer() and MESPCheck(v)) then
if _espon and v.HatTraitor and GetConVarNumber( "NewPrivateDumpV1_traitor" ) >= 1 then 
local ESP = (v:GetPos()):ToScreen()
draw.DrawText("Traitor", "Herp", ESP.x, ESP.y +56, Color(255,0,0,255), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
end
end
end
end
end
hook.Add( "HUDPaint", "TraitorESP", TraitorESP )


--Wallhax
hook.Add("HUDPaint", "WallHax", function()
if not _wallon then return end
	for k,v in pairs(player.GetAll()) do
		if MESPCheck(v) then
			cam.Start3D(EyePos(), EyeAngles())
				render.SetBlend( 0.45 )
				render.SetColorModulation( 1, 1, 1 )
				v:DrawModel()
				cam.End3D()
				elseif ( gmod.GetGamemode().Name ) == "TTT" or ( gmod.GetGamemode().Name ) == "Trouble in Terrorist Town" then
				for k,v in pairs(player.GetAll()) do
				if MESPCheck(v) then
				if v.HatTraitor and GetConVarNumber( "NewPrivateDumpV1_traitor" ) >= 1 then 
				cam.Start3D(EyePos(), EyeAngles())
				v:SetColor(Color(255, 0, 0, 255))
				render.SetColorModulation( 1, 0, 0 )
				v:DrawModel()
			cam.End3D()
		end
	end
	end
	end
	end
	end)
	

function WeedESP()
draw.SimpleText( "NewPrivateDumpV1 by Zerphus", "Herp", ScrW() / 10 - 120, 50, lightblue, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER );

if _enton and GetConVarNumber( "NewPrivateDumpV1_weed" ) >= 1 then
        for k, v in pairs( ents.FindByClass( "ent_pot" ) ) do
                        DrugPos = v:GetPos():ToScreen()
						surface.SetMaterial( weed ); surface.SetDrawColor( Color( 255, 255, 255, 255 ) ); surface.DrawTexturedRect( DrugPos.x - 5, DrugPos.y - 20, 16, 16 );
                        draw.SimpleText( "Weed", "Herp", DrugPos.x, DrugPos.y, Color( 0, 255, 0, 255 ), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER )
					end
			end
	end
hook.Add( "HUDPaint", "WeedESP", WeedESP )


--Coke ESP
function CokeESP()
	if _enton and GetConVarNumber( "NewPrivateDumpV1_coke" ) >= 1 then
        for k, v in pairs( ents.FindByClass( "ent_coca" ) ) do
                        DrugPos = v:GetPos():ToScreen()
                        draw.SimpleText( "Coke", "Herp", DrugPos.x, DrugPos.y, Color( 0, 255, 0, 255 ), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER )
					end
			end
	end
hook.Add( "HUDPaint", "CokeESP", CokeESP )


function SniperESP()
	if _enton and GetConVarNumber( "NewPrivateDumpV1_sniper" ) >= 1 then
        for k, v in pairs( ents.FindByClass( "weapon_zm_rifle" ) ) do
                        DrugPos = v:GetPos():ToScreen()
                        draw.SimpleText( "Sniper", "Herp", DrugPos.x, DrugPos.y, Color( 0, 200, 255, 255 ), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER )
					end
			end
	end
hook.Add( "HUDPaint", "SniperESP", SniperESP )

	local cantrobbank = GetGlobalBool("perp_bank_robbing_timer")
	local moneyinbank = GetGlobalInt("perp_realtor_money")	

hook.Add("HUDPaint", "PERPY", function()

	CreateClientConVar( "NewPrivateDumpV1_dd", 1, true, false )
	if GetConVarNumber("NewPrivateDumpV1_dd") == 1 and ( gmod.GetGamemode().Name ) == "PERP" or ( gmod.GetGamemode().Name ) == "RealityRoleplay" then
	local buying = GetGlobalInt("perp_druggy_buy", 0 )
	local selling = GetGlobalInt("perp_druggy_sell", 0 )	
	local cantrobbank = GetGlobalBool("perp_bank_robbing_timer")
	local moneyinbank = GetGlobalInt("perp_realtor_money")	
			local posx = 17
		local posy = 15
		draw.RoundedBox( 2, ScrW() / 2 * 2 -125, 40, 100, 80, Color(45,45,45,180) )
		draw.RoundedBox( 2, ScrW() / 2 * 2 -125, 40, 100, 20, lightblue )
		draw.SimpleText("Dealer", "Herp", ScrW() /2 * 2 - 75, 45, white, TEXT_ALIGN_CENTER )
			local buyingtbl = {
				"Buying Weed",
				"Buying Meth",
				"Buying Shrooms",
				"Buying LSD",
				"Buying Cocaine",
				"Buying Muscle"
			}
			buyingtbl[0] = "Not Buying"
			draw.SimpleText( buyingtbl[buying], "Herp", ScrW() /2 * 2 - 75, posy + 65, white, TEXT_ALIGN_CENTER, TEXT_ALIGN_TOP )
			local sellingtbl = {
				"Selling Seeds",
				"Selling LSD",
				"Selling Muscle",
				"Selling Shrooms",
				"Selling Cocaine",
			}
			sellingtbl[0] = "Not Selling"
			draw.SimpleText( sellingtbl[selling], "Herp", ScrW() /2 * 2 - 75, posy + 95, white, TEXT_ALIGN_CENTER, TEXT_ALIGN_TOP)
	end
end)

--tiny muscle man
function dance()
if _dancin then
       RunConsoleCommand("act", "muscle")
end
end
timer.Create( "dancin", 4.6, 0, dance)

function PrinterESP()

	if _enton and GetConVarNumber( "NewPrivateDumpV1_printer" ) >= 1 then
        for k, v in pairs( ents.FindByClass( "silver_money_printer" ) ) do
		DrugPos = v:GetPos():ToScreen()
                        draw.SimpleText( "Silver Money Printer", "Herp", DrugPos.x, DrugPos.y, Color( 200, 200, 200, 255 ), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER )
end
end

	if _enton and GetConVarNumber( "NewPrivateDumpV1_printer" ) >= 1 then
        for k, v in pairs( ents.FindByClass( "money_printer_standard" ) ) do
		DrugPos = v:GetPos():ToScreen()
                        draw.SimpleText( "Standard Money Printer", "Herp", DrugPos.x, DrugPos.y, Color( 200, 200, 200, 255 ), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER )
end
end	
	
	
		if _enton and GetConVarNumber( "NewPrivateDumpV1_printer" ) >= 1 then
		for k, v in pairs( ents.FindByClass( "gold_money_printer" ) ) do
		DrugPos = v:GetPos():ToScreen()
                        draw.SimpleText( "Gold Money Printer", "Herp", DrugPos.x, DrugPos.y, Color( 255, 225, 0, 255 ), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER )
end
end	
				
			if _enton and GetConVarNumber( "NewPrivateDumpV1_printer" ) >= 1 then
			for k, v in pairs( ents.FindByClass( "platinum_money_printer" ) ) do
			DrugPos = v:GetPos():ToScreen()
                        draw.SimpleText( "Platinum Money Printer", "Herp", DrugPos.x, DrugPos.y, Color( 0, 191, 255, 255 ), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER )

			end
			end	
			
			if _enton and GetConVarNumber( "NewPrivateDumpV1_printer" ) >= 1 then
			for k, v in pairs( ents.FindByClass( "emerald_money_printer" ) ) do
			DrugPos = v:GetPos():ToScreen()
                        draw.SimpleText( "Emerald Money Printer", "Herp", DrugPos.x, DrugPos.y, Color( 0, 255, 0, 255 ), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER )
					
			end
			end	
			
			if _enton and GetConVarNumber( "NewPrivateDumpV1_printer" ) >= 1 then
			for k, v in pairs( ents.FindByClass( "diamond_money_printer" ) ) do
			DrugPos = v:GetPos():ToScreen()
                        draw.SimpleText( "Diamond Money Printer", "Herp", DrugPos.x, DrugPos.y, Color( 0, 255, 255, 255 ), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER )
			end
	end	
	
				
			if _enton and GetConVarNumber( "NewPrivateDumpV1_printer" ) >= 1 then
			for k, v in pairs( ents.FindByClass( "tuned_diamond_money_printer" ) ) do
			DrugPos = v:GetPos():ToScreen()
                        draw.SimpleText( "Tuned Diamond Money Printer", "Herp", DrugPos.x, DrugPos.y, Color( 0, 255, 255, 255 ), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER )

						end
					end		
						
			if _enton and GetConVarNumber( "NewPrivateDumpV1_printer" ) >= 1 then
			for k, v in pairs( ents.FindByClass( "sapphire_money_printer" ) ) do
			DrugPos = v:GetPos():ToScreen()
                        draw.SimpleText( "Sapphire Money Printer", "Herp", DrugPos.x, DrugPos.y, Color( 0, 255, 255, 255 ), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER )
			
			end
			end	
			
			if _enton and GetConVarNumber( "NewPrivateDumpV1_gmodz" ) >= 1 then
			for k, v in pairs( ents.FindByClass( "gmodz_item" ) ) do
			DrugPos = v:GetPos():ToScreen()
                        draw.SimpleText( "Item", "Herp", DrugPos.x, DrugPos.y, Color( 200, 200, 200, 255 ), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER )
					end
end	

			if _enton and GetConVarNumber( "NewPrivateDumpV1_printer" ) >= 1 then
			for k, v in pairs( ents.FindByClass( "spawned_shipment" ) ) do
			DrugPos = v:GetPos():ToScreen()
                        draw.SimpleText( "Shipment", "Herp", DrugPos.x, DrugPos.y, Color( 200, 200, 200, 255 ), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER )
					end
end	
					
			if _enton and GetConVarNumber( "NewPrivateDumpV1_printer" ) >= 1 then
			for k, v in pairs( ents.FindByClass( "level_printer" ) ) do
			DrugPos = v:GetPos():ToScreen()
                        draw.SimpleText( "Level Printer", "Herp", DrugPos.x, DrugPos.y, Color( 200, 200, 200, 255 ), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER )
					end
					end	
					
			if _espon then
			for k, v in pairs( ents.FindByClass( "weapon_mor_swarm" ) ) do
			DrugPos = v:EyePos():ToScreen()
                        draw.SimpleText( "Alien", "Herp", DrugPos.x, DrugPos.y - 22, Color( 255, 0, 0, 255 ), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER )
					end
					end	
					
					
						if _espon then
			for k, v in pairs( ents.FindByClass( "weapon_mor_brood" ) ) do
			DrugPos = v:EyePos():ToScreen()
                        draw.SimpleText( "Brood Alien", "Herp", DrugPos.x, DrugPos.y - 22, Color( 255, 0, 0, 255 ), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER )
					end
					end	

					
					end


	
		
hook.Add( "HUDPaint", "PrinterESP", PrinterESP )


hook.Add("HUDPaint", "DarkRPESP", function()
		for _, ent in pairs(ents.GetAll()) do
			if _allents then
				local rpepos = ent:GetPos()
				if rpepos:ToScreen().x > 0 and
				rpepos:ToScreen().y > 0 and
				rpepos:ToScreen().x < ScrW() and
				rpepos:ToScreen().y < ScrH() then
	                local rppos1 = (ent:LocalToWorld( Vector(0,0,0)) ):ToScreen()
                    if ent:GetModel() != "models/props_c17/consolebox01a.mdl"  or ent:GetModel() != "models/props_c17/consolebox03a.mdl" then
						draw.DrawText("" .. ent:GetClass(), "Herp", rppos1.x, rppos1.y, Color(255, 255, 255, 255), TEXT_ALIGN_LEFT, TEXT_ALIGN_LEFT)
					else
						draw.DrawText("Money Printer", "Herp", rppos1.x, rppos1.y, Color(255, 255, 255, 255), TEXT_ALIGN_LEFT, TEXT_ALIGN_LEFT)
					end
				end
			end
		end
end)




		hook.Add("HUDPaint", "ShowAdmins", function()
		if GetConVarNumber("NewPrivateDumpV1_dd") == 1 and ( gmod.GetGamemode().Name ) == "PERP" or ( gmod.GetGamemode().Name ) == "RealityRoleplay" then
			Adminy = 140
			Admintext = 145
		else
			Adminy = 40
			Admintext = 45
		end
		end)




 hook.Add("HUDPaint", "ShowAdminss", function()
if GetConVarNumber("NewPrivateDumpV1_showadmins") == 1 then
local Admins = {}
local x = 0
for k,v in pairs(player.GetAll()) do
if v:IsAdmin() or v:IsSuperAdmin() then
table.insert(Admins, v:Name())
end
end
textLength = surface.GetTextSize(table.concat(Admins) ) / 6
draw.RoundedBox(0, ScrW() / 2 * 2 - 125, Adminy, 100, 80 + textLength, Color(45,45,45,180))
draw.RoundedBox(2, ScrW() / 2 * 2 - 125, Adminy, 100, 20, lightblue )
draw.SimpleText("Admins", "Herp", ScrW() /2 * 2 -75, Admintext, white, TEXT_ALIGN_CENTER )
for k, v in pairs(Admins) do
draw.SimpleText(v, "Herp", ScrW() / 2 * 2 -75, Admintext + 25 + x, white, TEXT_ALIGN_CENTER)
x = x + 15
end
end

		if GetConVarNumber("NewPrivateDumpV1_dd") == 1 and ( gmod.GetGamemode().Name ) == "PERP" or ( gmod.GetGamemode().Name ) == "RealityRoleplay" and (GetConVarNumber("NewPrivateDumpV1_showadmins") == 1) then
			Specy = 240 
			Spectext = 245
		elseif GetConVarNumber("NewPrivateDumpV1_dd") == 1 and ( gmod.GetGamemode().Name ) == "PERP" or ( gmod.GetGamemode().Name ) == "RealityRoleplay" or (GetConVarNumber("NewPrivateDumpV1_showadmins") == 1) then
			Specy = 140
			Spectext = 145
		else
			Specy = 40
			Spectext = 45
			end
			
			
			
if GetConVarNumber("NewPrivateDumpV1_showspecs") == 1 then
local Spectators = {}
local x = 0
for k,v in pairs(player.GetAll()) do
if (IsValid(v:GetObserverTarget()) and v:GetObserverTarget():IsPlayer() and v:GetObserverTarget() == LocalPlayer()) and not table.HasValue(Spectators, v:Name()) then
table.insert(Spectators, v:Name())
end
end
textLength2 = surface.GetTextSize(table.concat(Spectators) ) / 6
draw.RoundedBox(0, ScrW() / 2 * 2 - 125, Specy + textLength, 100, 80 + textLength2, Color(45,45,45,180))
draw.RoundedBox( 2, ScrW() / 2 * 2 - 125, Specy + textLength, 100, 20, lightblue )

draw.SimpleText("Spectators", "Herp", ScrW() /2 * 2 - 75, Spectext + textLength, white, TEXT_ALIGN_CENTER )
for k, v in pairs(Spectators) do
draw.SimpleText(v, "Herp", ScrW() / 2 * 2 - 75, Spectext + 25 + x +textLength, white, TEXT_ALIGN_CENTER)
x = x + 15
end
end
end)

local Player = LocalPlayer();
local Weapon = Player:GetActiveWeapon();

function Revie()
if ( gmod.GetGamemode().Name ) == "PERP" or ( gmod.GetGamemode().Name ) == "RealityRoleplay" then
if Player:Alive() == false then
RunConsoleCommand("perp_m_k", LocalPlayer():UniqueID())
end
end
end
hook.Add("Think", "Revie", Revie)

function PlayerInfo()
HP = LocalPlayer():Health()
AR = LocalPlayer():Armor()
if GetConVarNumber("NewPrivateDumpV1_perp_playerinfo") == 1 then
if ( gmod.GetGamemode().Name ) == "PERP" or ( gmod.GetGamemode().Name ) == "RealityRoleplay" then
draw.RoundedBox(0, ScrW() / 2 / 2 - 325, 43, 125, 105, Color(45,45,45,180))
draw.RoundedBox(0, ScrW() / 2 / 2 -325, 43, 125, 20, lightblue )
draw.SimpleText("Player Info", "Herp", ScrW() /2 / 2 -265, 47, white, TEXT_ALIGN_CENTER )

--HP Bar
draw.RoundedBox(0, ScrW() / 2 / 2 - 296, 68, 82, 10, Color(0,0,0,255))
draw.RoundedBox(0, ScrW() / 2 / 2 - 295, 69, 80 * math.Clamp(HP, 0, 100) / 100, 8, Color(255,0,0,255))
draw.RoundedBox(0, ScrW() / 2 / 2 - 295, 69, 80 * math.Clamp(HP, 0, 100) / 100, 4, Color(255,255,255,30))
draw.DrawText(HP .. "%", "Herp", ScrW() / 2 / 2 -256, 67, Color(255, 255, 255, 255), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
surface.SetMaterial( heart ); surface.SetDrawColor( Color( 255, 255, 255, 255 ) ); surface.DrawTexturedRect( ScrW() /2 / 2 -318, 65, 16, 16 );

--Armor Bar
draw.RoundedBox(0, ScrW() / 2 / 2 - 296, 88, 82, 10, Color(0,0,0,255))
draw.RoundedBox(0, ScrW() / 2 / 2 - 295, 89, 80 * math.Clamp(AR, 0, 100) / 100, 8, Color(0,0,255,255))
draw.RoundedBox(0, ScrW() / 2 / 2 - 295, 89, 80 * math.Clamp(AR, 0, 100) / 100, 4, Color(255,255,255,30))
draw.DrawText(AR .. "%", "Herp", ScrW() / 2 / 2 -256, 87, Color(255, 255, 255, 255), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
surface.SetMaterial( shield ); surface.SetDrawColor( Color( 255, 255, 255, 255 ) ); surface.DrawTexturedRect( ScrW() /2 / 2 -318, 85, 16, 16 );

--Name
surface.SetMaterial( user ); surface.SetDrawColor( Color( 255, 255, 255, 255 ) ); surface.DrawTexturedRect( ScrW() /2 / 2 -318, 105, 16, 16 );
draw.DrawText(LocalPlayer():GetRPName(), "Herp", ScrW() / 2 / 2 -256, 108, Color(255, 255, 255, 255), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)


--Money in bank
surface.SetMaterial( money ); surface.SetDrawColor( Color( 255, 255, 255, 255 ) ); surface.DrawTexturedRect( ScrW() /2 / 2 -318, 125, 16, 16 );
draw.DrawText("$".. string.Comma(LocalPlayer():GetBank()), "Herp", ScrW() / 2 / 2 -256, 128, Color(255, 255, 255, 255), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)


end
end
end
hook.Add("HUDPaint", "PlayerInfo", PlayerInfo)

function Ungag()
if(ulx and ulx.gagUser) then
		if GetConVarNumber("NewPrivateDumpV1_ulxgag") == 1 then
		ulx.gagUser(LocalPlayer(),false)
		end
	end
	end
	hook.Add("Think", "Ungag", Ungag)