--[[
	autorun/client/haxor.lua
	Mossimo | (STEAM_0:1:2464554)
	===DStream===
]]

---------------------------
---       HAXOR         ---
---    BY: MOSSIMO      ---
---------------------------

-- These are the default settings. Most are saved when you leave a server.
SPINBOT_ON = false
-- haxor on/off.
haxor_ON = false
-- Only target players.
haxor_PLAYERSONLY = true
-- Only target people who aren't on your team.
haxor_ENEMYSONLY = false
-- haxoresp on/off.
haxoresp_ON = false
-- Default offset to use. This shoots people in the chest area.
haxor_OFFSET = Vector(0,0,45)
-- Aim for the head when target is a player. (ignore offsets)
haxor_HEADSHOTS = true
-- Suicide health threshold. This is the health needed before you suicide.
SUICIDE_HEALTH = 0

-- I've tested it and this seems to be the best I can get. Your ping also plays
-- a factor in lag compensation calculations so you shouldn't have to change this.
haxor_LAGCOMPENSATION = 0.0025

OFFSETPRESETS = {}
OFFSETPRESETS["headshot"] = 55 -- I need to add in some side offsets because the head is hunched.
OFFSETPRESETS["chest"] = 45
OFFSETPRESETS["none"] = 0



--  |             |
-- \|/ Core code \|/


MySelf = LocalPlayer()
haxor_SCANNING = false
haxor_HEADOFFSET = Vector(0,0,58.5)
haxor_HEADOFFSET_CROUCHING = Vector(0,0,34)
surface.CreateFont( "arial", 12, 400, true, false, "haxorSmall" )
surface.CreateFont( "coolvetica", 24, 500, true, false, "haxorBig" )

haxor_TARGET = nil

COLOR_DOT = Color(255, 255, 0,  50)
COLOR_FRIENDLY = Color(0, 255, 0, 255)
COLOR_ENEMY = Color(255, 0, 0, 255)
COLOR_DEAD = Color(0, 0, 0, 255)
COLOR_TRACKING = Color(255, 0, 255, 255)

CreateClientConVar("_haxoresp", 1, true, false)
CreateClientConVar("_haxor", 1, true, false)
CreateClientConVar("_haxor_headshots", 1, true, false)
CreateClientConVar("_haxor_enemysonly", 0, true, false)
CreateClientConVar("_haxor_playersonly", 1, true, false)
CreateClientConVar("_haxor_lagcompensation", haxor_LAGCOMPENSATION, true, false)
CreateClientConVar("_haxor_suicidehealth", SUICIDE_HEALTH, true, false)
CreateClientConVar("_haxor_offset", haxor_OFFSET.z, true, false)

SPINBOT_ON = util.tobool(GetConVarNumber("_spinbot"))
haxoresp_ON = util.tobool(GetConVarNumber("_haxoresp"))
haxor_ON = util.tobool(GetConVarNumber("_haxor"))
haxor_HEADSHOTS = util.tobool(GetConVarNumber("_haxor_headshots"))
haxor_ENEMYSONLY = util.tobool(GetConVarNumber("_haxor_enemysonly"))
haxor_PLAYERSONLY = util.tobool(GetConVarNumber("_haxor_playersonly"))
haxor_LAGCOMPENSATION = GetConVarNumber("_haxor_lagcompensation")
SUICIDE_HEALTH = GetConVarNumber("_haxor_suicidehealth")
haxor_OFFSET = Vector(0,0,GetConVarNumber("_haxor_offset"))


function SPINBOT_On(sender , command , arguments)
	if ValidEntity(LocalPlayer()) then
		AddBotNotify( "SPINBOT On", NOTIFY_HINT, 6)
		SPINBOT_ON = true
		RunConsoleCommand("_haxor", "1")
		RunConsoleCommand("entx_spazon")
	end 
end
concommand.Add("SpinBot_on" , SPINBOT_On)

function haxoresp_On(sender, command, arguments)
	if ValidEntity(LocalPlayer()) then
		AddBotNotify( "haxoresp on!!", NOTIFY_HINT, 6 )
		haxoresp_ON = true
		RunConsoleCommand("_haxoresp", "1")
	end
end
concommand.Add("haxoresp_on", haxoresp_On)

function haxoresp_Off(sender, command, arguments)
	if ValidEntity(LocalPlayer()) then
		AddBotNotify( "haxoresp off!!", NOTIFY_HINT, 6 )
		haxoresp_ON = false
		RunConsoleCommand("_haxoresp", "0")
	end
end
concommand.Add("haxoresp_off", haxoresp_Off)

function haxor_Off(sender, command, arguments)
	if ValidEntity(LocalPlayer()) then
		AddBotNotify( "haxor off!!", NOTIFY_HINT, 6 )
		haxor_ON = false
		haxor_SCANNING = false
		RunConsoleCommand("_haxor", "0")
	end
end
concommand.Add("haxor_off", haxor_Off)

function haxor_On(sender, command, arguments)
	if ValidEntity(LocalPlayer()) then
		AddBotNotify( "haxor on!!", NOTIFY_HINT, 6 )
		haxor_ON = true
		RunConsoleCommand("_haxor", "1")
	end
end
concommand.Add("haxor_on", haxor_On)

function haxor_HeadShotsOff(sender, command, arguments)
	if ValidEntity(LocalPlayer()) then
		AddBotNotify("Headshots off!!", NOTIFY_HINT, 6)
		haxor_HEADSHOTS = false
		RunConsoleCommand("_haxor_headshots", "0")
	end
end
concommand.Add("haxor_headshots_off", haxor_HeadShotsOff)

function haxor_HeadShotsOn(sender, command, arguments)
	if ValidEntity(LocalPlayer()) then
		AddBotNotify("Headshots on!!", NOTIFY_HINT, 6)
		haxor_HEADSHOTS = true
		RunConsoleCommand("_haxor_headshots", "1")
	end
end
concommand.Add("haxor_headshots_on", haxor_HeadShotsOn)

function haxor_EnemysOnly_On(sender, command, arguments)
	if ValidEntity(LocalPlayer()) then
		AddBotNotify( "Targeting enemys only!!", NOTIFY_HINT, 6 )
		haxor_ENEMYSONLY = true
		RunConsoleCommand("_haxor_enemysonly", "1")
	end
end
concommand.Add("haxor_enemysonly_on", haxor_EnemysOnly_On)

function haxor_EnemysOnly_Off(sender, command, arguments)
	if ValidEntity(LocalPlayer()) then
		AddBotNotify( "Targeting friendlies and enemies!!", NOTIFY_HINT, 6 )
		haxor_ENEMYSONLY = false
		RunConsoleCommand("_haxor_enemysonly", "0")
	end
end
concommand.Add("haxor_enemysonly_off", haxor_EnemysOnly_Off)

function haxor_PlayersOnly_On(sender, command, arguments)
	if ValidEntity(LocalPlayer()) then
		AddBotNotify( "Targeting players!!", NOTIFY_HINT, 6 )
		haxor_PLAYERSONLY = true
		RunConsoleCommand("_haxor_playersonly", "1")
	end
end
concommand.Add("haxor_playersonly_on", haxor_PlayersOnly_On)

function haxor_PlayersOnly_Off(sender, command, arguments)
	if ValidEntity(LocalPlayer()) then
		AddBotNotify( "Targeting everything!!", NOTIFY_HINT, 6 )
		haxor_PLAYERSONLY = false
		RunConsoleCommand("_haxor_playersonly", "0")
	end
end
concommand.Add("haxor_playersonly_off", haxor_PlayersOnly_Off)

function haxor_SetLagCompensation(sender, command, arguments)
	if ValidEntity(LocalPlayer()) then
		if arguments[1] == nil then AddBotNotify( "Lag Compensation is currently "..haxor_LAGCOMPENSATION.."!!", NOTIFY_HINT, 6 ) return end
		if tonumber(arguments[1]) == nil then
			AddBotNotify( "Not a number!", NOTIFY_ERROR, 6 )
			return
		end
		haxor_LAGCOMPENSATION = math.Clamp(tonumber(arguments[1]), 0, 2)
		AddBotNotify( "Lag Compensation changed to "..haxor_LAGCOMPENSATION.."!!", NOTIFY_HINT, 6 )
		RunConsoleCommand("_haxor_lagcompensation",haxor_LAGCOMPENSATION)
	end
end
concommand.Add("haxor_lagcompensation", haxor_SetLagCompensation)

function haxor_SetSuicideHealth(sender, command, arguments)
	if ValidEntity(LocalPlayer()) then
		if arguments[1] == nil then AddBotNotify( "Suicide health is currently "..SUICIDE_HEALTH.."!!", NOTIFY_HINT, 6 ) return end
		if tonumber(arguments[1]) == nil then
			AddBotNotify( "Not a number!", NOTIFY_ERROR, 6 )
			return
		end
		SUICIDE_HEALTH = tonumber(arguments[1])
		AddBotNotify("Suicide health changed to "..SUICIDE_HEALTH.."!!", NOTIFY_HINT, 6)
		RunConsoleCommand("_haxor_suicidehealth",SUICIDE_HEALTH)
	end
end
concommand.Add("haxor_suicidehealth", haxor_SetSuicideHealth)

function haxor_SetOffset(sender, command, arguments)
	if ValidEntity(LocalPlayer()) then
		if arguments[1] == nil then AddBotNotify( "Offset is currently "..haxor_OFFSET.z.."!!", NOTIFY_HINT, 6 ) return end
		if tonumber(arguments[1]) == nil then
		    if OFFSETPRESETS[arguments[1] ] then
		        haxor_OFFSET = Vector(0,0, OFFSETPRESETS[arguments[1] ])
				AddBotNotify( "Offset changed to "..haxor_OFFSET.z.."!!", NOTIFY_HINT, 6 )
				return
		    else
				AddBotNotify( "Offset is not a number!", NOTIFY_ERROR, 6 )
				return
			end
		end
		haxor_OFFSET = Vector(0,0, math.Clamp(tonumber(arguments[1]), -512, 512))
		AddBotNotify("Offset changed to "..haxor_OFFSET.z.."!!", NOTIFY_HINT, 6)
		RunConsoleCommand("_haxor_offset",haxor_OFFSET.z)
	end
end
concommand.Add("haxor_offset", haxor_SetOffset)

function haxor_ScanOn(sender, command, arguments)
	haxor_SCANNING = true
end
concommand.Add("+haxor_scan", haxor_ScanOn)

function haxor_ScanOff(sender, command, arguments)
    haxor_SCANNING = false
    haxor_TARGET = nil
end
concommand.Add("-haxor_scan", haxor_ScanOff)

function GetTargetPos(ent)
	if ent:IsPlayer() then
		if haxor_HEADSHOTS then
			return ent:GetAttachment(1).Pos + ent:GetAngles():Forward() * -4
		else
			if ent:Crouching() then
				return ent:GetPos() + (haxor_OFFSET * 0.586)
			else
				return ent:GetPos() + haxor_OFFSET
			end
		end
	else
		return ent:GetPos() + haxor_OFFSET
	end
end

LAST_SUICIDE = CurTime()

function Dohaxor()
	if ValidEntity(LocalPlayer()) then

	if haxoresp_ON then
		local x = ScrW() / 2.0  
		local y = ScrH() / 2.0 
		surface.SetDrawColor(0, 255, 0, 127)
		local gap = 5  
		local length = gap + 9
		surface.DrawLine( x - length, y, x - gap, y )  
		surface.DrawLine( x + length, y, x + gap, y )  
		surface.DrawLine( x, y - length, x, y - gap )  
		surface.DrawLine( x, y + length, x, y + gap )  
	    draw.SimpleText("haxoresp", "haxorBig", ScrW() * 0.5, ScrH() * 0.01, COLOR_ENEMY, TEXT_ALIGN_CENTER)
		 
		for _, pl in pairs(player.GetAll()) do
			if pl == LocalPlayer() then
				-- DO NOTHING
		    elseif pl:Alive() then
		    	local pos = GetTargetPos(pl)
		    	local mypos = LocalPlayer():GetPos()
		    	-- local size = math.Clamp(64 - mypos:Distance(pos) * 0.1, 18, 64)
		    	local size = ScrW() * 0.02
		    	pos = pos:ToScreen()
		    	if haxor_TARGET and pl == haxor_TARGET then
					-- Nothing
		        elseif pl:Team() == LocalPlayer():Team() then
		            surface.SetDrawColor(0, 255, 0, 255)
		        	surface.DrawLine( pos.x - size, pos.y, pos.x + size, pos.y )
					surface.DrawLine( pos.x, pos.y - size, pos.x, pos.y + size)
					draw.SimpleText(pl:Name(), "haxorBig", pos.x, pos.y + size + 10, COLOR_FRIENDLY, TEXT_ALIGN_CENTER)
					draw.SimpleText("HP: "..pl:Health(), "haxorSmall", pos.x, pos.y + size + 30, COLOR_ENEMY, TEXT_ALIGN_LEFT)
					draw.SimpleText("Dist: "..math.floor(pl:GetPos():Distance(mypos)), "haxorSmall", pos.x, pos.y + size + 42, COLOR_ENEMY, TEXT_ALIGN_LEFT)
					draw.DrawText("Group: "..pl:GetNetworkedString("usergroup", "none"), "haxorSmall", pos.x, pos.y + size + 54, colortouse, TEXT_ALIGN_LEFT)
				else
					surface.SetDrawColor(255, 0, 0, 255)
		        	surface.DrawLine( pos.x - size, pos.y, pos.x + size, pos.y )
					surface.DrawLine( pos.x, pos.y - size, pos.x, pos.y + size)
					draw.SimpleText(pl:Name(), "haxorBig", pos.x, pos.y + size + 10, COLOR_ENEMY, TEXT_ALIGN_CENTER)
					draw.SimpleText("HP: "..pl:Health(), "haxorSmall", pos.x, pos.y + size + 30, COLOR_FRIENDLY, TEXT_ALIGN_LEFT)
					draw.SimpleText("Dist: "..math.floor(pl:GetPos():Distance(mypos)), "haxorSmall", pos.x, pos.y + size + 42, COLOR_FRIENDLY, TEXT_ALIGN_LEFT)
					
				end	
				
		    else
		        local pos = GetTargetPos(pl)
		    	local mypos = LocalPlayer():GetPos()
		    	local size = math.Clamp(64 - mypos:Distance(pos) * 0.1, 18, 64)
		    	pos = pos:ToScreen()
		        surface.SetDrawColor(0, 0, 0, 255)
		        surface.DrawLine( pos.x - size, pos.y, pos.x + size, pos.y )
				surface.DrawLine( pos.x, pos.y - size, pos.x, pos.y + size)
				draw.SimpleText(pl:Name(), "haxorBig", pos.x, pos.y + size + 10, COLOR_DEAD, TEXT_ALIGN_CENTER)
				draw.SimpleText("** DEAD **", "haxorSmall", pos.x, pos.y + size + 30, COLOR_DEAD, TEXT_ALIGN_CENTER)
				draw.SimpleText("Dist: "..math.floor(pl:GetPos():Distance(mypos)), "haxorSmall", pos.x, pos.y + size + 42, COLOR_DEAD, TEXT_ALIGN_LEFT)
		    end
		end
	end
	if not LocalPlayer():Alive() then return end
	if LocalPlayer():Health() <= SUICIDE_HEALTH then
	    if CurTime() > LAST_SUICIDE + 0.5 and LocalPlayer():Health() > 0 then
	    	RunConsoleCommand("kill")
	    	AddBotNotify( "Committing Suicide", NOTIFY_ERROR, 6 )
	    	LAST_SUICIDE = CurTime()
	    end
	end
	if haxor_ON then
	    if haxor_TARGET and haxor_TARGET ~= nil and haxor_TARGET:IsValid() then
	    	local wpos = GetTargetPos(haxor_TARGET)
	    	local pos = wpos:ToScreen()
		    local size = ScrW() * 0.018
	        if haxor_LAGCOMPENSATION > 0 then
	            local velocity = haxor_TARGET:GetVelocity() or Vector(0,0,0)
				LocalPlayer():SetEyeAngles(((wpos + velocity * (haxor_LAGCOMPENSATION * LocalPlayer():Ping())) - LocalPlayer():GetShootPos()):Angle())
	            local ppos = ((wpos + velocity * (haxor_LAGCOMPENSATION * LocalPlayer():Ping()))):ToScreen()
	            surface.SetDrawColor(255, 255, 0, 255)
	            surface.DrawLine( ppos.x - size, ppos.y, ppos.x + size, ppos.y )
				surface.DrawLine( ppos.x, ppos.y - size, ppos.x, ppos.y + size)
			else
				LocalPlayer():SetEyeAngles((wpos - LocalPlayer():GetShootPos()):Angle())
			end
			surface.SetDrawColor(255, 0, 255, 255)
		    surface.DrawLine( pos.x - size, pos.y, pos.x + size, pos.y )
			surface.DrawLine( pos.x, pos.y - size, pos.x, pos.y + size)
			if haxor_TARGET:IsPlayer() then
				if haxor_TARGET:Alive() and  haxor_TARGET:GetActiveWeapon():IsValid() then
					draw.SimpleText("TARGET LOCKED", "haxorBig", ScrW() * 0.5, ScrH() * 0.05, COLOR_FRIENDLY, TEXT_ALIGN_CENTER)
			    	draw.SimpleText(haxor_TARGET:Name(), "haxorBig", pos.x, pos.y + size + 10, COLOR_TRACKING, TEXT_ALIGN_CENTER)
			    	draw.SimpleText("HP: "..haxor_TARGET:Health(), "haxorSmall", pos.x, pos.y + size + 30, COLOR_TRACKING, TEXT_ALIGN_LEFT)
					draw.SimpleText("Dist: "..math.floor(haxor_TARGET:GetPos():Distance(LocalPlayer():GetPos())), "haxorSmall", pos.x, pos.y + size + 42, COLOR_TRACKING, TEXT_ALIGN_LEFT)
					draw.SimpleText("Wep: "..haxor_TARGET:GetActiveWeapon():GetPrintName(), "haxorSmall", pos.x, pos.y + size + 54, COLOR_ENEMY, TEXT_ALIGN_LEFT)
					draw.RoundedBox(2,pos.x + size, pos.y + size,8,8,COLOR_DOT)
					
				else
					AddBotNotify("pwned "..haxor_TARGET:Name(), NOTIFY_CLEANUP, 3)
					--surface.PlaySound("buttons/blip1.wav")
					surface.PlaySound("owned.wav")
					DrawMaterialOverlay( "xray/no_entry", 0 )
					haxor_TARGET = nil
					
				end
			else
				draw.SimpleText(tostring(haxor_TARGET), "haxorBig", pos.x, pos.y + size + 10, COLOR_TRACKING, TEXT_ALIGN_CENTER)
				draw.SimpleText("Dist: "..math.floor(haxor_TARGET:GetPos():Distance(LocalPlayer():GetPos())), "haxorSmall", pos.x, pos.y + size + 30, COLOR_TRACKING, TEXT_ALIGN_LEFT)
			end
		else
			if haxor_SCANNING then
				draw.SimpleText("Scanning...", "haxorBig", ScrW() * 0.5, ScrH() * 0.6, COLOR_ENEMY, TEXT_ALIGN_CENTER)
            	local tr = utilx.GetPlayerTrace(LocalPlayer(), LocalPlayer():GetCursorAimVector())
				local trace = util.TraceLine(tr)
				if trace.Hit and trace.HitNonWorld then
					local entity = trace.Entity
					if haxor_PLAYERSONLY then
						if entity:IsValid() and entity:GetPos() then
							if entity:IsPlayer() then
							    if entity:Team() ~= LocalPlayer():Team() or not haxor_ENEMYSONLY then
					        		haxor_TARGET = entity
					        		haxor_SCANNING = false
					        	end
					    	end
					    end
					else
					    if entity:IsValid() and entity:GetPos() then
					        if entity:IsPlayer() then
					        	if entity:Team() ~= LocalPlayer():Team() or not haxor_ENEMYSONLY then
					        		haxor_TARGET = entity
					        		haxor_SCANNING = false
					        	end
							else
					        	haxor_TARGET = entity
					        	haxor_SCANNING = false
					        end
					    end
					end
				end
			else
		    	haxor_TARGET = nil
		    end
		end
	end

	end
end
hook.Add("HUDPaint", "haxor", Dohaxor)

NOTIFY_GENERIC			= 0
NOTIFY_ERROR			= 1
NOTIFY_UNDO			= 2
NOTIFY_HINT			= 3
NOTIFY_CLEANUP			= 4

if NoticeMaterial == nil then
	NoticeMaterial = {}
end
NoticeMaterial[ NOTIFY_GENERIC ] 	= surface.GetTextureID( "vgui/notices/generic" )
NoticeMaterial[ NOTIFY_ERROR ] 		= surface.GetTextureID( "vgui/notices/error" )
NoticeMaterial[ NOTIFY_UNDO ] 		= surface.GetTextureID( "vgui/notices/undo" )
NoticeMaterial[ NOTIFY_HINT ] 		= surface.GetTextureID( "vgui/notices/hint" )
NoticeMaterial[ NOTIFY_CLEANUP ] 	= surface.GetTextureID( "vgui/notices/cleanup" )


HUDNote_c = 0
HUDNote_i = 1
HUDNotes = {}

function AddBotNotify( str, type, length )

	local tab = {}
	tab.text 	= str
	tab.recv 	= CurTime()
	tab.len 	= length
	tab.velx	= -5
	tab.vely	= 0
	tab.x		= ScrW() + 200
	tab.y		= ScrH()
	tab.a		= 255
	tab.type	= type

	table.insert( HUDNotes, tab )

	HUDNote_c = HUDNote_c + 1
	HUDNote_i = HUDNote_i + 1

end

function DrawBotNotice( self, k, v, i )

	local H = ScrH() / 1024
	local x = v.x - 75 * H
	local y = v.y - 300 * H

	if ( !v.w ) then

		surface.SetFont( "haxorBig" )
		v.w, v.h = surface.GetTextSize( v.text )

	end

	local w = v.w
	local h = v.h

	w = w + 16
	h = h + 16

	draw.RoundedBox( 4, x - w - h + 8, y - 8, w + h, h, Color( 30, 30, 30, v.a * 0.4 ) )

	// Draw Icon

	surface.SetDrawColor( 255, 255, 255, v.a )
	surface.SetTexture( NoticeMaterial[ v.type ] )
	surface.DrawTexturedRect( x - w - h + 16, y - 4, h - 8, h - 8 )


	draw.SimpleText( v.text, "haxorBig", x+1, y+1, Color(0,0,0,v.a*0.8), TEXT_ALIGN_RIGHT )
	draw.SimpleText( v.text, "haxorBig", x-1, y-1, Color(0,0,0,v.a*0.5), TEXT_ALIGN_RIGHT )
	draw.SimpleText( v.text, "haxorBig", x+1, y-1, Color(0,0,0,v.a*0.6), TEXT_ALIGN_RIGHT )
	draw.SimpleText( v.text, "haxorBig", x-1, y+1, Color(0,0,0,v.a*0.6), TEXT_ALIGN_RIGHT )
	draw.SimpleText( v.text, "haxorBig", x, y, Color(255,255,255,v.a), TEXT_ALIGN_RIGHT )

	local ideal_y = ScrH() - (HUDNote_c - i) * (h + 4)
	local ideal_x = ScrW()

	local timeleft = v.len - (CurTime() - v.recv)

	// Cartoon style about to go thing
	if ( timeleft < 0.8  ) then
		ideal_x = ScrW() - 50
	end

	// Gone!
	if ( timeleft < 0.5  ) then

		ideal_x = ScrW() + w * 2

	end

	local spd = FrameTime() * 15

	v.y = v.y + v.vely * spd
	v.x = v.x + v.velx * spd

	local dist = ideal_y - v.y
	v.vely = v.vely + dist * spd * 1
	if (math.abs(dist) < 2 && math.abs(v.vely) < 0.1) then v.vely = 0 end
	local dist = ideal_x - v.x
	v.velx = v.velx + dist * spd * 1
	if (math.abs(dist) < 2 && math.abs(v.velx) < 0.1) then v.velx = 0 end

	// Friction.. kind of FPS independant.
	v.velx = v.velx * (0.95 - FrameTime() * 8 )
	v.vely = v.vely * (0.95 - FrameTime() * 8 )

end

function PaintBotNotes()
	if ( !HUDNotes ) then return end
	local i = 0
	for k, v in pairs( HUDNotes ) do
		if ( v != 0 ) then
			i = i + 1
			DrawBotNotice( self, k, v, i)
		end
	end

	for k, v in pairs( HUDNotes ) do
		if ( v != 0 && v.recv + v.len < CurTime() ) then
			HUDNotes[ k ] = 0
			HUDNote_c = HUDNote_c - 1
			if (HUDNote_c == 0) then HUDNotes = {} end
		end
	end
end
hook.Add("HUDPaint", "PaintBotNotes", PaintBotNotes)

local function SpazOn()
	hook.Add("CreateMove", "Spaz", function(cmd)
		cmd:SetViewAngles(cmd:GetViewAngles() * -1)
		return cmd
	end)
end
concommand.Add("entx_spazon", SpazOn)


local function SpazOff()
	hook.Remove("CreateMove", "Spaz")
end
concommand.Add("entx_spazoff", SpazOff)


local function PrintAllEnts()
	PrintTable(ents.GetAll())
end
concommand.Add("entx_printallents", PrintAllEnts)

local function PrintEntTable(sender, command, arguments)
	PrintTable(Entity(tonumber(arguments[1])):GetTable())
end
concommand.Add("entx_printenttable", PrintEntTable)

local function EntSetValue(sender, command, arguments)
	Entity(tonumber(arguments[1])):GetTable()[ arguments[2] ] = arguments[3]
end
concommand.Add("entx_setvalue", EntSetValue)

local function EntRunNone(sender, command, arguments)
	local ent = Entity(tonumber(arguments[1]))
	ent[ arguments[2] ](ent)
end
concommand.Add("entx_run", EntRunNone)

local function EntRun(sender, command, arguments)
	local ent = Entity(tonumber(arguments[1]))
	ent[ arguments[2] ](ent, arguments[3])
end
concommand.Add("entx_run1", EntRun)

local function EntRunTwo(sender, command, arguments)
	local ent = Entity(tonumber(arguments[1]))
	ent[ arguments[2] ](ent, arguments[3], arguments[4])
end
concommand.Add("entx_run2", EntRunTwo)

local function EntRunThree(sender, command, arguments)
	local ent = Entity(tonumber(arguments[1]))
	ent[ arguments[2] ](ent, arguments[3], arguments[4], arguments[5])
end
concommand.Add("entx_run3", EntRunThree)

local function EntRunFour(sender, command, arguments)
	local ent = Entity(tonumber(arguments[1]))
	ent[ arguments[2] ](ent, arguments[3], arguments[4], arguments[5], arguments[6])
end
concommand.Add("entx_run4", EntRunFour)

local function GetEnt(sender, command, arguments)
	if ValidEntity(LocalPlayer()) then
		local tr = util.TraceLine(utilx.GetPlayerTrace(LocalPlayer(), LocalPlayer():GetAimVector()))
		if tr.Entity then
			print(tostring(tr.Entity))
		end
	end
end
concommand.Add("entx_traceget", GetEnt)

local function CamEnable()
	if ValidEntity(LocalPlayer()) then
	MY_VIEW = LocalPlayer():GetAimVector()
	MySelf = LocalPlayer()
	CAM_POS = MySelf:EyePos()
	CAM_ANG = MySelf:GetAimVector()
	hook.Add("CreateMove", "CamStopMove", function(cmd)
		cmd:SetForwardMove(0)
		cmd:SetUpMove(0)
		cmd:SetSideMove(0)
		return cmd
	end)
	function GAMEMODE:CalcView(ply, origin, angles, fov)
		angles = angles:Forward()
		local masktouse = COLLISION_GROUP_WORLD
		if MySelf:KeyDown(IN_FORWARD) then
			local tr = util.TraceLine({start = CAM_POS, endpos = CAM_POS + angles * FrameTime() * 200, mask=masktouse})
			CAM_POS = tr.HitPos
		end
		if MySelf:KeyDown(IN_BACK) then
			local tr = util.TraceLine({start = CAM_POS, endpos = CAM_POS + angles * FrameTime() * -200, mask=masktouse})
			CAM_POS = tr.HitPos
		end
		if MySelf:KeyDown(IN_MOVELEFT) then
			local tr = util.TraceLine({start = CAM_POS, endpos = CAM_POS + angles:Angle():Right() * FrameTime() * -200, mask=masktouse})
			CAM_POS = tr.HitPos
		end
		if MySelf:KeyDown(IN_MOVERIGHT) then
			local tr = util.TraceLine({start = CAM_POS, endpos = CAM_POS + angles:Angle():Right() * FrameTime() * 200, mask=masktouse})
			CAM_POS = tr.HitPos
		end

		local view = {}
		view.origin = CAM_POS
		view.angles = angles:Angle()
		view.fov = fov

		return view
	end
	end
end
concommand.Add("entx_camenable", CamEnable)

local function CamDisable()
	hook.Remove("CreateMove", "CamStopMove")
	function GAMEMODE:CalcView(ply, origin, angles, fov)
		local view = {}
		view.origin = origin
		view.angles = angles
		view.fov = fov
		return view
	end
end
concommand.Add("entx_camdisable", CamDisable)

 
